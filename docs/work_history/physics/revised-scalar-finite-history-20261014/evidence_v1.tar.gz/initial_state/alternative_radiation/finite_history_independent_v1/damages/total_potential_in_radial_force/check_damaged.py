"""Independent full-action finite-history checks; no producer imports or reads.

Hand derivation and controls were frozen before this script was executed.
The older independent all-k spectrum is reused; no claim of rerunning it.
"""
from pathlib import Path
import hashlib, json, sys
import sympy as S
import mpmath as mp

mp.mp.dps = 70
HERE = Path(__file__).resolve().parent
while not (HERE/'SOURCE_MANIFEST_v1.json').exists():
    HERE = HERE.parent
checks, displays = [], []

def eq(name, expr, category='exact'):
    residual = S.cancel(expr)
    ok = residual == 0
    checks.append(dict(id=name, category=category, ok=bool(ok), residual=str(residual)))

def yes(name, condition, evidence, category='domain'):
    checks.append(dict(id=name, category=category, ok=bool(condition), evidence=evidence))

def near(name, residual, tolerance, category='numeric'):
    yes(name, abs(residual) < mp.mpf(tolerance),
        dict(residual=mp.nstr(residual, 65), absolute_tolerance=tolerance), category)

def m(x):
    if isinstance(x, str) and '/' in x:
        n,d=x.split('/'); return mp.mpf(n)/mp.mpf(d)
    return mp.mpf(x)

# Full original three-field action, pulled back algebraically.
k,s,F,J,a,x,w,eta = S.symbols('k s F J a x w eta', positive=True)
d=2*(1+k)/3
A=J/(4*a*F**2)
Binf=(1+s)*2*k/(3*(1+k)*F)
D=1+d*x**2*(1+w**2)
K=S.diag(J/F**2, (1+s)*4*k/(9*F*D), (1+s)*k/(3*F*D))
P=S.Matrix([[1/(2*S.sqrt(a)),0,0],[0,x,0],[0,w*x,x]])
G=(P.T*K*P).applyfunc(S.cancel)
Bfull=Binf/(1+w**2+eta/d)
expected=S.Matrix([[A,0,0],[0,Bfull*(1+3*w**2/4),3*Bfull*w/4],[0,3*Bfull*w/4,3*Bfull/4]])
for i,jj in [(0,0),(0,1),(0,2),(1,1),(1,2),(2,2)]:
    eq(f'action_pullback_{i}{jj}',G[i,jj].subs(x**2,1/eta)-expected[i,jj])
eq('full_metric_determinant',expected.det()-3*A*Bfull**2/4)
reflection=S.diag(1,1,-1)
eq('metric_reflection_equivariance',sum((expected.subs(w,-w)-reflection*expected*reflection).applyfunc(lambda z:z*z)))

# Physical derivatives of the metric must respect eta=x^-2.
th,z=S.symbols('theta z', real=True)
aa=S.Function('A')(th); bb=S.Function('Binf')(th)
dd=S.symbols('d',positive=True)
metric=S.diag(aa,bb*dd/(dd+eta)); inv=metric.inv()
der=[lambda expr:S.diff(expr,th),lambda expr:-2*eta*S.diff(expr,eta)]
def gamma(i,jj,ll):
    return S.cancel(sum(inv[i,n]*(der[jj](metric[n,ll])+der[ll](metric[n,jj])-der[n](metric[jj,ll]))/2 for n in range(2)))
eq('Gamma_theta_theta_theta',gamma(0,0,0)-S.diff(aa,th)/(2*aa))
eq('Gamma_theta_ell_ell',gamma(0,1,1)+S.diff(metric[1,1],th)/(2*aa))
eq('Gamma_ell_theta_ell',gamma(1,0,1)-S.diff(bb,th)/(2*bb))
eq('Gamma_ell_ell_ell',gamma(1,1,1)-eta/(dd+eta))
beta,Wx,rho=S.symbols('beta Wx rho',positive=True)
U0=S.Function('U0')(th)
Wq=Wx*S.exp(2*z-rho*th); Z=beta**2*S.exp(2*z); W=Wq+eta*Z*U0
eq('physical_ell_gradient_cancels_U0',S.diff(W,z)-2*eta*S.diff(W,eta)-2*Wq)
eq('physical_theta_gradient',S.diff(W,th)+rho*Wq-eta*Z*S.diff(U0,th))
eq('discarding_eta_dependence_in_gradient_is_wrong',
   (S.diff(W,z)-2*Wq)-2*eta*Z*U0)

# Exact differentiation at the branch, independent of coefficient jets.
b,A0,r,H0,v0,v1=S.symbols('b A0 r H0 v0 v1',positive=True)
B=b/(1+eta/dd); C2=3*H0*(1-2*b)/2
Hb=2*(C2+b*H0+eta*v0*H0)/(3-4*B)
h=-4*B-4*C2/(3*Hb)
p_rhs=-2*r*B/A0+(2*r*b*H0-eta*v1*H0)/(A0*Hb)
q_rhs=2*(3+h)-4*eta/(dd+eta)-2*b*H0/(B*Hb)
j=(2*v0-4*b/dd)/(3-4*b)
fp=(2*r*b*(1/dd-j)-v1)/A0; fq=4*v0-6/dd
eq('branch_Hbar_normalization',Hb.subs(eta,0)-H0)
eq('branch_h_minus_two',h.subs(eta,0)+2)
eq('branch_p_fixed',p_rhs.subs(eta,0))
eq('branch_q_fixed',q_rhs.subs(eta,0))
eq('Hbar_eta_log_derivative',S.diff(Hb,eta).subs(eta,0)/H0-j)
eq('h_eta_derivative',S.diff(h,eta).subs(eta,0)-(4*b/dd+2*(1-2*b)*j))
eq('forcing_p',S.diff(p_rhs,eta).subs(eta,0)-fp)
eq('forcing_q',S.diff(q_rhs,eta).subs(eta,0)-fq)
qq=S.symbols('q')
eq('eta_growth_linearization',S.diff(-2*qq*eta,eta).subs(qq,-2)-4)
eq('eta_lower_left_row',S.diff(-2*qq*eta,qq).subs(eta,0))

# Prior independently derived M is reused as a mathematical input.  The new
# determinant check concerns the 4I-M tangent, not a fresh all-k proof.
kk=S.symbols('kk',positive=True)
bk=2*kk*(1-kk)/((1+kk)*(1-3*kk))
Ak=3*kk/(4*(1-kk)*(1+3*kk)); rk=1/(1+3*kk); ck=1-rk
Dk=3-4*bk; Lk=2*bk*rk/Ak
M=S.Matrix([[0,0,1,0],[0,0,ck,1],
 [Lk*(-9+6*rk+16*bk-4*bk*rk)/Dk,6*Lk*(1-2*bk)/Dk,-1,3*Lk/Dk],
 [4-2*rk-8*bk,-4+8*bk,-2*rk,-1]]).applyfunc(S.cancel)
nx=5-7*kk-21*kk**2+7*kk**3
Sx=4*nx/((1+kk)*(1-3*kk)*(1+3*kk))
Px=64*kk*(1-kk)**2*(1-6*kk+kk**2)/((1+kk)**2*(1-3*kk)**2*(1+3*kk))
eq('tangent_matrix_determinant', (4*S.eye(4)-M).det(method='domain-ge')-(400+20*Sx+Px))
yes('positive_tangent_determinant_from_reused_bounds', True,
    'Prior sealed proof establishes Sx>46/5 and Px>0; determinant=400+20Sx+Px>584. No new all-k spectrum rerun.')

# Proper time and the physical conformal clock.
HE,CC,LL,hh,ld=S.symbols('HE C L h Lprime',positive=True)
HJ=HE*LL/S.sqrt(CC)
dHJdN=S.diff(HJ,HE)*hh*HE+S.diff(HJ,CC)*2*CC*(LL-1)+S.diff(HJ,LL)*ld
hJfromDerivative=S.cancel((HE/S.sqrt(CC))*dHJdN/HJ**2)
hJformula=(hh+ld/LL-(LL-1))/LL
eq('physical_hubble_derivative',hJfromDerivative-hJformula)
eq('physical_radiation_h_limit',hJformula.subs({hh:-2,LL:1,ld:0})+2)
eq('Kretschmann_limit_prefactor',12*(1+(1+hh)**2).subs(hh,-2)-24)
eq('Ricci_leading_prefactor_cancels',(6*(2+hh)).subs(hh,-2))
hv=S.symbols('Hv',positive=True)
HEas=hv*S.sqrt(H0)/(beta*S.sqrt(eta))
tE=beta*S.sqrt(eta)/(2*hv*S.sqrt(H0)); tJ=S.sqrt(CC)*tE
eq('Einstein_time_integrand',S.diff(tE,eta)*4*eta-1/HEas)
eq('physical_time_integrand',S.diff(tJ,eta)*4*eta-S.sqrt(CC)/HEas)
eq('Einstein_radiation_clock_product',HEas*tE-S.Rational(1,2))
eq('physical_radiation_clock_product',HEas/S.sqrt(CC)*tJ-S.Rational(1,2))
eq('physical_Kretschmann_proper_time_coefficient',24*(HEas/S.sqrt(CC))**4*tJ**4-S.Rational(3,2))
rhoUnit,Q=S.symbols('rho_unit Q',positive=True)
Rstar=rhoUnit/(2*Q*hv**2)
eq('density_dimensionful_translation',rhoUnit/(Rstar*beta**2*eta)-2*Q*hv**2/(beta**2*eta))
eq('leading_log_density_contrast',4*5/(16*kk)-5/(4*kk))
eq('one_slow_efold',S.exp(-S.Rational(16,5)*kk*5/(16*kk))-S.exp(-1))

def parameters(kv,nuv):
    kval,nuv=m(kv),m(nuv)
    av=(1-kval)*(1+3*kval)/4; al=mp.sqrt(av)
    sv=(1+kval)/(kval*(1-3*kval)); ex=(1-3*kval)/(3*(1+kval))
    ux=mp.log(ex)/(2*al); lx=(1-kval)/al; ly=(1+kval)/al
    cx=(1-kval)/(1+kval); b=2*kval*(1-kval)/((1+kval)*(1-3*kval))
    H0=2*cx**2/(3*(1-2*b)); W0=b*H0
    beta2=2*W0*mp.exp(lx*ux)/kval
    return dict(k=kval,nu=nuv,a=av,alpha=al,s=sv,ex=ex,ux=ux,lx=lx,ly=ly,
                cx=cx,b=b,H0=H0,W0=W0,beta2=beta2,d=2*(1+kval)/3)

def original_action_at(u,x,c):
    kval,sv,al=c['k'],c['s'],c['alpha']
    E=mp.exp(2*al*u); F=1+sv*E; J=1+(1-3*c['a'])*sv*E
    D=1+c['d']*x*x
    kuu=J/(F*F); kxx=(1+sv)*4*kval/(9*F*D)
    C=(1+sv)*E/F
    U=mp.mpf(3)/2+3*sv*(E-1)**2/(2*F*F)+c['nu']*(1+sv)*u*u/(2*F*F)+kval*x*x*mp.exp(-c['lx']*u)/2
    return kuu,kxx,C,U

def original_acceleration(state,c,sign):
    theta,z,p,q,eta=state
    al=c['alpha']; u=c['ux']+theta/(2*al); x=sign/mp.sqrt(eta)
    up=p/(2*al); xp=x*q
    kuu,kxx,C,U=original_action_at(u,x,c)
    ku_u=mp.diff(lambda v:original_action_at(v,x,c)[0],u)
    kx_u=mp.diff(lambda v:original_action_at(v,x,c)[1],u)
    kx_x=mp.diff(lambda v:original_action_at(u,v,c)[1],x)
    Cu=mp.diff(lambda v:original_action_at(v,x,c)[2],u)
    Uu=mp.diff(lambda v:original_action_at(v,x,c)[3],u)
    Ux=mp.diff(lambda v:original_action_at(u,v,c)[3],x)
    yb2=1/(c['beta2']*eta*mp.exp(2*z)); sigma=C*C*yb2
    T=kuu*up*up+kxx*xp*xp; HE2=2*(sigma+U)/(3-T)
    h=-T-4*sigma/(3*HE2)
    ua=-(3+h)*up-ku_u*up*up/(2*kuu)+kx_u*xp*xp/(2*kuu)-Uu/(kuu*HE2)
    xa=-(3+h)*xp-kx_u*up*xp/kxx-kx_x*xp*xp/(2*kxx)-Ux/(kxx*HE2)
    physical_clock=1+Cu*up/(2*C)
    flow=mp.matrix([p,q+2*physical_clock,2*al*ua,xa/x-q*q,-2*xp/(x**3)])
    return flow,dict(T=T,HE2=HE2,Hbar=HE2/yb2,h=h,C=C,L=physical_clock)

def u0_theta(theta,c):
    u=c['ux']+theta/(2*c['alpha']); E=c['ex']*mp.exp(theta); F=1+c['s']*E
    return mp.mpf(3)/2+mp.mpf(3)/2*c['s']*(E-1)**2/F**2+c['nu']*(1+c['s'])*u*u/(2*F**2)

def transformed_flow(state,c):
    theta,z,p,q,eta=state
    E=c['ex']*mp.exp(theta); F=1+c['s']*E; J=1+(1-3*c['a'])*c['s']*E
    A=J/(4*c['a']*F**2)
    Jtheta=(1-3*c['a'])*c['s']*E
    At_over_A=Jtheta/J-2*(F-1)/F
    Bi=(1+c['s'])*2*c['k']/(3*(1+c['k'])*F)
    B=Bi/(1+eta/c['d'])
    Bt_over_B=-(F-1)/F
    C=(1+c['s'])*E/F
    Wq=c['W0']*mp.exp(2*z-2*theta/(1+3*c['k']))
    Z=c['beta2']*mp.exp(2*z); U0=u0_theta(theta,c)
    W=Wq+eta*Z*U0
    T=A*p*p+B*q*q; Hbar=2*(C*C+W)/(3-T); h=-T-4*C*C/(3*Hbar)
    pdot=-(3+h)*p-At_over_A*p*p/2+Bt_over_B*B*q*q/(2*A)+(2*Wq/(1+3*c['k'])-eta*Z*mp.diff(lambda t:u0_theta(t,c),theta))/(A*Hbar)
    qdot=-(3+h)*q-Bt_over_B*p*q-eta*q*q/(c['d']+eta)-2*W/(B*Hbar)
    eta_rhs=-2*q*eta
    physical_clock=1+p/(2*F)
    return mp.matrix([p,q+2+p/F,pdot,qdot,eta_rhs]),dict(T=T,Hbar=Hbar,h=h,C=C,F=F,L=physical_clock)

def prior_M(c):
    kval=c['k']; b=c['b']; A0=3*kval/(4*(1-kval)*(1+3*kval)); r=1/(1+3*kval)
    c0=1-r; D=3-4*b; L=2*b*r/A0
    return mp.matrix([[0,0,1,0],[0,0,c0,1],
      [L*(-9+6*r+16*b-4*b*r)/D,6*L*(1-2*b)/D,-1,3*L/D],
      [4-2*r-8*b,-4+8*b,-2*r,-1]])

case_pairs=[('1/37','2/5'),('2/23','7/3'),('4/29','5/7'),('13/79','11/4')]
for ic,(kv,nuv) in enumerate(case_pairs):
    c=parameters(kv,nuv)
    yes(f'case_{ic}_physical_parameter_domain',0<c['k']<3-2*mp.sqrt(2) and c['nu']>0,
        dict(k=kv,nu=nuv))
    for ie,et in enumerate(['1/25','1/10000','1/100000000']):
        state=mp.matrix([m('3/100'),m('-1/50'),m('1/100'),m('-39/20'),m(et)])
        tf,tm=transformed_flow(state,c)
        for sign in [1,-1]:
            of,om=original_acceleration(state,c,sign)
            prefix=f'action_case{ic}_eta{ie}_sign{sign}'
            near(prefix+'_flow',max(abs(v) for v in tf-of),'1e-55')
            near(prefix+'_constraint',tm['Hbar']-om['Hbar'],'1e-55')
            near(prefix+'_physical_clock',tm['L']-om['L'],'1e-55')
            yes(prefix+'_open_physical_domain',tm['T']<3 and tm['Hbar']>0 and tm['L']>0,
                {n:mp.nstr(tm[n],30) for n in ['T','Hbar','L']})
    M=prior_M(c); A0=3*c['k']/(4*(1-c['k'])*(1+3*c['k'])); rr=1/(1+3*c['k'])
    v0=c['beta2']*u0_theta(mp.mpf(0),c)/c['H0']
    v1=c['beta2']*mp.diff(lambda t:u0_theta(t,c),mp.mpf(0))/c['H0']
    jj=(2*v0-4*c['b']/c['d'])/(3-4*c['b'])
    f=mp.matrix([0,0,(2*rr*c['b']*(1/c['d']-jj)-v1)/A0,4*v0-6/c['d']])
    equilibrium=mp.matrix([0,0,0,-2,0])
    Jnumeric=mp.matrix(5,5)
    for row in range(5):
        for col in range(5):
            def component(t,row=row,col=col):
                st=equilibrium.copy(); st[col]=t
                return transformed_flow(st,c)[0][row]
            Jnumeric[row,col]=mp.diff(component,equilibrium[col])
    Jexpected=mp.zeros(5,5)
    for row in range(4):
        for col in range(4): Jexpected[row,col]=M[row,col]
        Jexpected[row,4]=f[row]
    Jexpected[4,4]=4
    near(f'case_{ic}_actual_extended_Jacobian',max(abs(v) for v in Jnumeric-Jexpected),'1e-50')
    mat=4*mp.eye(4)-M
    tangent=mp.lu_solve(mat,f)
    near(f'case_{ic}_tangent_equation',max(abs(v) for v in (4*mp.eye(4)-M)*tangent-f)/(1+max(abs(v) for v in f)),'1e-50')
    residual_norms=[]
    for epsilon in [m('1e-8'),m('2e-8')]:
        state=mp.matrix([tangent[0]*epsilon,tangent[1]*epsilon,tangent[2]*epsilon,-2+tangent[3]*epsilon,epsilon])
        flow,meta=transformed_flow(state,c)
        residual=mp.matrix([flow[ii]-tangent[ii]*flow[4] for ii in range(4)])
        residual_norms.append(max(abs(v) for v in residual))
    ratio=residual_norms[1]/residual_norms[0]
    yes(f'case_{ic}_tangent_quadratic_residual',abs(ratio-4)<m('1e-4'),
        dict(ratio=mp.nstr(ratio,50),norms=[mp.nstr(v,50) for v in residual_norms]))
    # Chart extension is mathematical only; negative eta does not describe x.
    tiny=m('-1e-8'); st=mp.matrix([0,0,0,-2,tiny]); fl,met=transformed_flow(st,c)
    yes(f'case_{ic}_negative_eta_open_extension',1+tiny/c['d']>0 and met['T']<3 and met['Hbar']>0,
        dict(eta=mp.nstr(tiny),T=mp.nstr(met['T'],30),Hbar=mp.nstr(met['Hbar'],30)))
    epsilon=m('1e-8')
    st=mp.matrix([tangent[0]*epsilon,tangent[1]*epsilon,tangent[2]*epsilon,-2+tangent[3]*epsilon,epsilon])
    fl,met=transformed_flow(st,c)
    F=met['F']; p=st[2]; L=met['L']
    Lprime=fl[2]/(2*F)-p*p*(F-1)/(2*F*F)
    hJ=(met['h']+Lprime/L-(L-1))/L
    knorm=(1+(1+hJ)**2)/2
    yes(f'case_{ic}_physical_curvature_limit',abs(knorm-1)<m('1e-4') and L>0,
        dict(hJ=mp.nstr(hJ,50),K_over_24HJ4=mp.nstr(knorm,50)))
    displays.append(dict(k=kv,nu=nuv,v0=mp.nstr(v0,60),v1=mp.nstr(v1,60),
        forcing=[mp.nstr(v,60) for v in f],tangent=[mp.nstr(v,60) for v in tangent],
        residual_ratio=mp.nstr(ratio,60),hJ=mp.nstr(hJ,60),
        tE_over_sqrt_eta=mp.nstr(mp.sqrt(c['beta2'])/(2*mp.sqrt(c['H0'])),60),
        tJ_over_sqrt_eta=mp.nstr(mp.sqrt(c['beta2']*c['cx'])/(2*mp.sqrt(c['H0'])),60)))

source_manifest=json.loads((HERE/'SOURCE_MANIFEST_v1.json').read_text())
for i,row in enumerate(source_manifest['sources']):
    data=(HERE/row['snapshot_path']).read_bytes()
    yes(f'frozen_source_{i}',len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],
        {'snapshot_path':row['snapshot_path'],'sha256':row['sha256']},'binding')

totals={key:sum(c['category']==key for c in checks) for key in sorted({c['category'] for c in checks})}
result=dict(checker='independent finite-history v1',mp_dps=mp.mp.dps,sympy_version=S.__version__,
            total=len(checks),passed=sum(c['ok'] for c in checks),failed=sum(not c['ok'] for c in checks),
            category_counts=totals,checks=checks,display_only_mathematical_cases=displays,
            scope='Pointwise action/normalization/tangent checks, not history integration or a new all-k spectrum proof',
            reused='Sealed independent alternative branch all-k stability and transverse spectrum; see REUSED_EVIDENCE_INTEGRITY_v1.json')
print(json.dumps(result,indent=2))
sys.exit(0 if all(c['ok'] for c in checks) else 1)
