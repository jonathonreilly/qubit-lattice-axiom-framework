"""Independent retrieval of the three already identified primary URLs."""
from pathlib import Path
from datetime import datetime, timezone
from urllib.request import Request, urlopen
import hashlib, json, traceback

here = Path(__file__).resolve().parent
out = here / "references"
out.mkdir(exist_ok=True)
targets = [
    ("mcgehee_sander_author_page.html", "https://www-users.cse.umn.edu/~mcgehee/publications/McGehee1996a/index.html"),
    ("huang_stable_manifold_course.html", "https://personalpages.manchester.ac.uk/staff/yanghong.huang/ads/html/equi-nl.html"),
    ("mcgehee_sander_GCG88.pdf", "https://www-users.cse.umn.edu/~mcgehee/publications/McGehee1996a/GCG88.pdf"),
]
rows = []
for name, url in targets:
    row = {"url": url, "started_utc": datetime.now(timezone.utc).isoformat()}
    try:
        req = Request(url, headers={"User-Agent": "Independent mathematical source verification"})
        with urlopen(req, timeout=15) as response:
            data = response.read()
            row.update(final_url=response.url, status=response.status,
                       content_type=response.headers.get("Content-Type"))
        path = out / name
        assert not path.exists()
        path.write_bytes(data)
        row.update(path=str(path.relative_to(here)), bytes=len(data),
                   sha256=hashlib.sha256(data).hexdigest(), ok=True)
    except Exception:
        row.update(ok=False, traceback=traceback.format_exc())
    row["finished_utc"] = datetime.now(timezone.utc).isoformat()
    rows.append(row)
result = {"purpose": "Theorem statement and hypotheses, not physical state selection", "retrievals": rows}
(here / "REFERENCE_RETRIEVAL_v1.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result, indent=2))
