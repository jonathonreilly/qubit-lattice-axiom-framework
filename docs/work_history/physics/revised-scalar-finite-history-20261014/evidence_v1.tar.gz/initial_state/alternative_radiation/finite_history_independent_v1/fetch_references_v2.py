"""Preserved urllib certificate failures; retry through system curl TLS roots."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

here=Path(__file__).resolve().parent
out=here/'references_v2'
out.mkdir(exist_ok=False)
targets=json.loads((here/'REFERENCE_RETRIEVAL_v1.json').read_text())['retrievals']
names=['mcgehee_sander_author_page.html','huang_stable_manifold_course.html','mcgehee_sander_GCG88.pdf']
rows=[]
for src,name in zip(targets,names):
    dst=out/name
    command=['/usr/bin/curl','--fail','--location','--silent','--show-error','--max-time','12','--output',str(dst),src['url']]
    start=datetime.now(timezone.utc).isoformat()
    p=subprocess.run(command,capture_output=True,timeout=13)
    row={'url':src['url'],'command':command,'started_utc':start,'finished_utc':datetime.now(timezone.utc).isoformat(),'exit_code':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace'),'ok':p.returncode==0}
    if dst.exists():
        b=dst.read_bytes(); row.update(path=str(dst.relative_to(here)),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
    rows.append(row)
result={'prior_attempt':'REFERENCE_RETRIEVAL_v1.json; all three urllib requests failed certificate verification, unaltered','retrievals':rows}
(here/'REFERENCE_RETRIEVAL_v2.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
