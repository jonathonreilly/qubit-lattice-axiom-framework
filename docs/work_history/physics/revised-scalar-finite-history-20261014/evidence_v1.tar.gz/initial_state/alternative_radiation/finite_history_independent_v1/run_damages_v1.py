"""Run real modified copies of the independent checker; preserve all results."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,subprocess,sys

here=Path(__file__).resolve().parent
base=(here/'check_finite_history_v1.py').read_text()
damages=[
 ('total_potential_in_radial_force','-2*Wq/(B*Hbar)','-2*W/(B*Hbar)','action_case0_eta0_sign1_flow'),
 ('omit_finite_connection',"-eta*q*q/(c['d']+eta)",'','action_case0_eta0_sign1_flow'),
 ('reverse_eta_growth','eta_rhs=-2*q*eta','eta_rhs=2*q*eta','case_0_actual_extended_Jacobian'),
 ('wrong_tangent_operator','mat=4*mp.eye(4)-M','mat=4*mp.eye(4)+M','case_0_tangent_equation'),
 ('double_physical_clock_scalar','physical_clock=1+p/(2*F)','physical_clock=1+p/F','action_case0_eta0_sign1_physical_clock'),
 ('drop_finite_metric_factor',"B=Bi/(1+eta/c['d'])",'B=Bi','action_case0_eta0_sign1_flow'),
]
rows=[]
for i,(name,old,new,witness) in enumerate(damages,1):
    assert base.count(old)==1,(name,base.count(old))
    path=here/'damages'/name/'check_damaged.py'
    path.parent.mkdir(parents=True,exist_ok=False)
    text=base.replace(old,new)
    path.write_text(text)
    tag=f'RUN_DAMAGE_{i:02d}_{name}'
    command=[sys.executable,'-B',str(here/'run_recorded_v1.py'),tag,str(path.relative_to(here))]
    proc=subprocess.run(command,cwd=here,capture_output=True,timeout=50)
    assert proc.returncode==0,(name,proc.stderr)
    run=json.loads((here/(tag+'.json')).read_text())
    result=json.loads((here/(tag+'.stdout.txt')).read_text())
    failed=[c['id'] for c in result['checks'] if not c['ok']]
    row=dict(name=name,path=str(path.relative_to(here)),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        original=old,replacement=new,expected_witness=witness,run_metadata=tag+'.json',
        exit_code=run['exit_code'],failed_check_count=len(failed),failed_identities=failed,
        expected_rejection_observed=run['exit_code']==1 and witness in failed)
    rows.append(row)
result=dict(created_utc=datetime.now(timezone.utc).isoformat(),
    baseline_path='check_finite_history_v1.py',baseline_sha256=hashlib.sha256(base.encode()).hexdigest(),
    mutation_count=len(rows),all_rejected_as_expected=all(r['expected_rejection_observed'] for r in rows),mutations=rows)
(here/'MUTATION_RECEIPT_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
sys.exit(0 if result['all_rejected_as_expected'] else 1)
