"""Bounded subprocess wrapper preserving every attempt's exact bytes and code."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, sys

here = Path(__file__).resolve().parent
tag, script = sys.argv[1:3]
target = (here / script).resolve()
assert target.is_relative_to(here)
assert not (here / (tag+".json")).exists()
command = [sys.executable, "-B", str(target), *sys.argv[3:]]
start = datetime.now(timezone.utc).isoformat()
try:
    done = subprocess.run(command, cwd=here, capture_output=True, timeout=45)
    stdout, stderr, code = done.stdout, done.stderr, done.returncode
    timeout = False
except subprocess.TimeoutExpired as exc:
    stdout, stderr = exc.stdout or b"", exc.stderr or b""
    stderr += b"\nRECORDED_TIMEOUT_AFTER_45_SECONDS\n"
    code, timeout = 124, True
row = {"command": command, "cwd": str(here), "started_utc": start,
       "finished_utc": datetime.now(timezone.utc).isoformat(), "exit_code": code,
       "timeout_seconds": 45, "timed_out": timeout,
       "script_sha256": hashlib.sha256(target.read_bytes()).hexdigest()}
for kind, data in [("stdout", stdout), ("stderr", stderr)]:
    name = tag+"."+kind+".txt"
    (here / name).write_bytes(data)
    row[kind] = {"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
(here / (tag+".json")).write_text(json.dumps(row, indent=2)+"\n")
print(json.dumps(row, indent=2))
