"""Seal the bounded independent check after verifying source and evidence bytes."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json

here=Path(__file__).resolve().parent
root=next(p for p in here.parents if (p/'docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md').is_file())
def digest(path):
    b=path.read_bytes()
    return {'path':str(path.relative_to(here)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(name,data):
    path=here/name
    assert not path.exists(),name
    path.write_text(json.dumps(data,indent=2)+'\n')
for name in ['RECEIPT_v1.json','MANIFEST_v1.json','FINAL_BINDING_VERIFICATION_v1.json']:
    assert not (here/name).exists(),name

sources=json.loads((here/'SOURCE_MANIFEST_v1.json').read_text())['sources']+json.loads((here/'SOURCE_V2_MANIFEST_v1.json').read_text())['sources']
for row in sources:
    snap=(here/row['snapshot_path']).read_bytes()
    live=(root/row['original_path']).read_bytes()
    assert snap==live and len(snap)==row['bytes'] and hashlib.sha256(snap).hexdigest()==row['sha256'],row['original_path']
prior=here.parent/'independent_v1'
old_manifest=json.loads((prior/'MANIFEST_v1.json').read_text())
for row in old_manifest['artifacts']:
    b=(prior/row['path']).read_bytes()
    assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'],row['path']
assert len(old_manifest['artifacts'])==29

science=json.loads((here/'RUN_03_INDEPENDENT_ACTION.stdout.txt').read_text())
assert science['passed']==167 and science['failed']==0
assert hashlib.sha256((here/'RUN_03_INDEPENDENT_ACTION.stdout.txt').read_bytes()).hexdigest()=='d917bd5e7958759a50bc891d9a700ecd4df57d64088edce9c68582ca73b475d6'
correspondence=json.loads((here/'RUN_05_DENSITY_V2_CORRESPONDENCE.stdout.txt').read_text())
assert correspondence['passed']==15 and correspondence['failed']==0
mutations=json.loads((here/'MUTATION_RECEIPT_v1.json').read_text())
assert len(mutations['mutations'])==6 and mutations['all_rejected_as_expected']
runs=[]
for p in sorted(here.glob('RUN_*.json')):
    row=json.loads(p.read_text())
    assert 'command' in row,p
    script=Path(row['command'][2])
    assert script.is_relative_to(here)
    assert hashlib.sha256(script.read_bytes()).hexdigest()==row['script_sha256'],p
    for kind in ['stdout','stderr']:
        data=(here/row[kind]['path']).read_bytes()
        assert len(data)==row[kind]['bytes'] and hashlib.sha256(data).hexdigest()==row[kind]['sha256'],p
    assert not row['timed_out'],p
    assert row['exit_code']==(1 if p.name.startswith('RUN_DAMAGE_') else 0),p
    runs.append(dict(metadata=digest(p),command=row['command'],started_utc=row['started_utc'],
        finished_utc=row['finished_utc'],exit_code=row['exit_code'],script_sha256=row['script_sha256'],
        stdout=row['stdout'],stderr=row['stderr']))
assert len(runs)==11
refs1=json.loads((here/'REFERENCE_RETRIEVAL_v1.json').read_text())
refs2=json.loads((here/'REFERENCE_RETRIEVAL_v2.json').read_text())
assert len(refs1['retrievals'])==3 and all(not r['ok'] and 'CERTIFICATE_VERIFY_FAILED' in r['traceback'] for r in refs1['retrievals'])
assert len(refs2['retrievals'])==3 and all(r['ok'] for r in refs2['retrievals'])
for row in refs2['retrievals']:
    b=(here/row['path']).read_bytes()
    assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
now=datetime.now(timezone.utc).isoformat()
save('FINAL_BINDING_VERIFICATION_v1.json',dict(checked_utc=now,source_pairs_verified=len(sources),
    original_alternative_artifacts_verified=29,
    original_manifest_sha256=hashlib.sha256((prior/'MANIFEST_v1.json').read_bytes()).hexdigest(),
    recorded_executions_verified=len(runs),downloaded_primary_reference_files_verified=3,
    baseline_science=dict(passed=167,failed=0),density_correspondence=dict(passed=15,failed=0),
    real_damages=dict(count=6,expected_rejections=6),all_bindings_ok=True))

inventory=[digest(p) for p in sorted(here.rglob('*')) if p.is_file() and p.name not in ['RECEIPT_v1.json','MANIFEST_v1.json']]
receipt=dict(version=1,sealed_utc=now,checker='/root/local_response_check',direct_author='/root',
    scope='Independent finite-amplitude radiation action/forcing/manifold/physical-curvature check; not formal audit',
    disposition='Dynamical claims supported in the explicit local conditional scope; density-symbol ambiguity corrected in preserved v2',
    source_pairs=sources,source_pair_count=len(sources),
    original_science=dict(passed=167,failed=0,category_counts=science['category_counts'],
        output=digest(here/'RUN_03_INDEPENDENT_ACTION.stdout.txt'),script=digest(here/'check_finite_history_v1.py')),
    corrected_source_confirmation=dict(passed=15,failed=0,
        scope='Only density units and byte correspondence; original science reused',
        output=digest(here/'RUN_05_DENSITY_V2_CORRESPONDENCE.stdout.txt'),
        diff=digest(here/'SOURCE_V1_V2_INDEPENDENT.diff')),
    finding=dict(id='density_symbol_normalization',
        original='Canonical rho_J is dimensionless but v1 displayed the dimensionful density formula',
        resolution='v2 names rho_phys=rho_unit*rho_J and y_b^2=rho_phys/(2QHv^2)=Rstar*rho_J',
        corrected_source_sha256='a4ff01679164f9ab28f6b02397a90a79df8044f0e4f8cae97b3bf05c375d3a0c',
        same_checker_confirmed=True),
    reused_evidence=dict(path=str(prior.relative_to(root)),artifact_count=29,verified_not_rerun=True,
        report_sha256=hashlib.sha256((prior/'REPORT_v1.txt').read_bytes()).hexdigest(),
        receipt_sha256=hashlib.sha256((prior/'RECEIPT_v1.json').read_bytes()).hexdigest(),
        manifest_sha256=hashlib.sha256((prior/'MANIFEST_v1.json').read_bytes()).hexdigest(),
        content='All-k alternative plane Hurwitz proof, stable normal spectrum and slow-root coefficient; prior failed attempts retained there'),
    new_recorded_run_count=len(runs),runs=runs,negative_controls=mutations,
    retrieval_failures=dict(count=3,kind='urllib TLS certificate verification',
        preserved=digest(here/'REFERENCE_RETRIEVAL_v1.json'),
        resolved_by='Separate system-curl retrieval with certificate verification enabled; no source or historical record overwritten'),
    packaging_tool_failure=dict(count=1,preserved=digest(here/'TOOL_FAILURES_v1.json'),
        disposition='Invalid patch hunk rejected before creating seal script; fixed patch prefixes, no science rerun'),
    primary_reference_downloads=refs2['retrievals'],
    scope_limits=[
        'Fixed 0<k<3-2sqrt(2), finite nu>0 and supplied action/ideal radiation',
        'Local unstable germ and positive-eta half-curve; no global existence or basin measure',
        'Negative eta used only for a mathematical open extension',
        'This particular past limit is an additional unselected boundary premise',
        'Finite physical proper time and divergent Kretschmann; no nonsingular completion',
        'Pointwise action and tangent residual checks, not a history simulation or rigorous orbit enclosure',
        'Weak-k density contrast only leading logarithmic asymptotics; no O(1/k) tracking theorem',
        'No empirical acceptance, source-model derivation or authority/status promotion'],
    report=digest(here/'REPORT_v1.txt'),pre_receipt_artifact_count=len(inventory),artifact_bindings=inventory)
save('RECEIPT_v1.json',receipt)
artifacts=[digest(p) for p in sorted(here.rglob('*')) if p.is_file() and p.name!='MANIFEST_v1.json']
save('MANIFEST_v1.json',dict(version=1,sealed_utc=now,
    scope='Focused finite-amplitude radiation independent check',
    artifact_count=len(artifacts),artifacts=artifacts,excluded=['MANIFEST_v1.json itself']))
for row in artifacts:
    assert digest(here/row['path'])==row
print(json.dumps(dict(sealed_utc=now,source_pairs_verified=len(sources),old_artifacts_verified=29,
    artifacts_verified=len(artifacts),report=digest(here/'REPORT_v1.txt'),
    receipt=digest(here/'RECEIPT_v1.json'),manifest=digest(here/'MANIFEST_v1.json')),indent=2))

