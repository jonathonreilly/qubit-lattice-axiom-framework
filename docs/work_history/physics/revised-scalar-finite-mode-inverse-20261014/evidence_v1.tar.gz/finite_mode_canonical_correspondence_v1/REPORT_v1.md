# Canonical finite-mode inverse correspondence

The final canonical note and runner agree with the corrected sealed finite-scale, finite-mode inverse and measured-certificate proofs. No new mathematical correction is required. The supplied-action normalization, exact vacuum source equation, weak inverse and uniqueness argument survive the stated premises. The final note correctly distinguishes structural uniqueness from chosen-window rank and attainable precision, and retains source-amplitude/free-wave and observational limitations.

Scientific author: /root. Correspondence checker: /root/local_response_check. This is not a blind new derivation or a formal audit. Producer access was explicitly allowed for this final-source review. The full canonical note, runner, full action, three independent reports, final FIv3, identifiability lemma, FS vacuumv2, measured certificatev2 and their source correspondences were read. Earlier receipt JSON was completely parsed and bound mechanically; their long printed output was truncated, so no claim is made that every repeated numeric receipt entry was read as prose. All referenced original artifacts and source pairs were verified.

The final unit is ready for the parent's separate recovery archive and five-path delivery identity review. No archive, commit, branch identity, current-main integration, PR, retained grade or empirical validation is asserted here. No parent source, prior seal, Git, runtime, lock, settings or audit state was changed. Every new write is within this folder.

## Final source identities

| Source | SHA256 |
|---|---|
| Final canonical note | `d816996a38b6ca65feef503578372058d6d67561fd4c36318f476ca6ba22ee64` |
| Canonical runner | `61a5ebce5cf8d39d1683b257393f6a88c3c37ba05c8626f402caf2358c3112bc` |
| Final cache | `13d36c295c0c5fde1a58dddf6cc17e6d5d19de502cf5e68929c026f1840b0d2e` |
| Complete supplied action | `39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000` |

The final input fingerprint is `ab71e3a488b59a7aede41da80c440486dc97b96cfe23d23c5656f62b2719aa33`. It was recomputed from the exact literal AUDIT_INPUT_PATHS in the runner, using the cache format's documented length-prefixed byte construction. The cache records actual source-bound execution, status ok, exit0 and163/0. Its full parsed result equals the preserved primary result. We did not execute the full primary or any earlier solver.

SOURCE_MANIFEST_v3.json contains128 source/evidence bindings. Two original bindings are explicitly superseded historical sources: the initial canonical note102cd505... and initial cachea42aa333.... Their exact snapshots remain recoverable. The other126 bindings match their current live sources. SOURCE_MANIFEST_v1.json andv2 are preserved.

## Reused independent evidence

| Unit | Manifest payloads verified | Live/snapshot source pairs | Receipt SHA256 |
|---|---:|---:|---|
| finite_scale_v1/independent_v1 | 62 | 8 | `ca9058d51ea21fd9b23225fc836a7ddae4584e0d106189ec6c79b025198ec2d3` |
| finite_mode_inverse_v1/independent_v1 | 63 | 11 | `a6973efcfeacf35bd8e80ed37b0b191c184ecde27d544799ba78f354d24457bb` |
| finite_mode_inverse_v1/measured_certificate_independent_v1 | 30 | 3 | `bdcb714c58e08ae78603463cebdffb448c1938128a15ac66bd03e94b03f48763` |

All155 manifest payloads and22 original source pairs passed byte/size/hash verification. Receipt-to-report and receipt-to-manifest bindings also passed. These are integrity checks, not new science counts. The original source corrections already have the original checker's explicit confirmations:

- FS:125/0 original controls and8/0 prose correspondence. The two corrected spans distinguish scalar excitation density/momentum from the linear metric variation of constant vacuum stress. Its six actual altered formulas remain rejected and preserved.
- FI:80/3 original checks, including all eight passing numerical solver runs;36/0 separately repaired exact checks;10/0 source correspondence. The original domain coefficient42 incorrectly imposed nu>6k. Final18k gives exactly nu>0. The later source-amplitude correction retains the fixed-free-wave change in the ratio. The original failures and four actual changed-formula failures remain unchanged.
- MC:72/0 original exact mathematical controls and6/0 source correspondence. The preservedv2 inserts the real-estimate premise for ordered domain tests. Its actual changed-denominator execution is65/7 and remains rejected. None of these checks was rerun or relabelled here.

The continuous-trace lemma and prior fixed-window rank-loss, source-rescaling, detectable third-window change and moment-null counterexample are reused by source identity. Their histories are not hidden or converted into new counts.

## Action, source, metric and clock normalization

The action has Einstein coefficient Q/2, scalar kinetic coefficient Q and potential2Q Hv^2 U. Direct variation therefore gives mass matrix Hv^2 K^(-1) Hess U at a stationary vacuum, without an extra factor two. In original u coordinates, U_uu(0)=[12as+nu(1+s)]/(1+s)^2, K_uu(0)=J0/(1+s)^2 and b_u=alpha/(1+s). Thus |b|_K^2=a/J0=k and B=4[3(1+k)+nu]/(1-3k). The transverse mass ratios are9/4 and2, with zero mixed Hessians. The new controls differentiate the complete action in u,x,y directly, separately checking the canonical runner's t=alpha*u implementation and its needed factor a.

The selected expanding vacuum has C0=1 and U0=3/2, hence H=Hv and equal background Einstein/Jordan clocks and lengths. This is a selected state premise; it is not an observed-state derivation or a theorem excluding other stationary states.

A weak cold source about zero background density has rho=O(epsilon). Its induced velocity and scalar forces affect momentum/exchange at second order, permitting delta rho proportional to a_E^-3 with zero linear momentum and pressure in this experiment. This would not be a valid generic closure about finite background dust density. A signed Fourier coefficient is not a standalone positive source; the note explicitly places it in a possible small nonnegative localized distribution on a finite weak interval.

The FS proof supplies the Einstein constraint/pressure derivation; the primary checks substitute the resulting identities and do not replace that proof. Phi=-delta rho/(2Qp^2) has Phi_dot=-H Phi. Scalar excitation stress is quadratic at the vacuum, while constant vacuum stress's linear metric variation is already in the background equations. The new reduced-Lagrangian check independently gives scalar source -b delta rho/(2Q), including its sign and factor. Substituting xi=b Phi y produces y_tt+H y_t+[p^2+(B-2)H^2]y=p^2. N=ln a_E and z proportional to exp(-N) give g_NN+g_N+(z^2+A)g=kz^2.

The conformal perturbation b.xi=k Phi y shifts the lapse/spatial potentials by opposite signs. Their sourced mean remains Phi, so g=ky requires its nonzero mean and same-mode signed/phase-consistent data. The two uncoupled scalar directions need not be physically selected to zero; this particular first-order readout does not observe them. Known mode/time geometry, linear validity and access to both metric potentials remain premises.

## Inverse, rank and uncertainty scope

The boundary concomitant w g_N-w_N g+w g and the adjoint w_NN-w_N are correct. Endpoint assumptions constrain weights, not scalar initial data. Both determinant inverses and nu=(A+2)(1-3k)/4-3(1+k) are correct. Admissibility is0<k<1/3 and A>(10+18k)/(1-3k). A complete continuous trace fixes the constants inside this known-z family because constant g/z^2 on an open interval would force k=0. Continuity gives existence of separated small weight supports; it gives no guarantee for an arbitrary preselected pair, no uniform determinant margin and no instrument precision.

Free scalar initial data are eliminated from the parameter inputs, not from the trace. With a fixed absolute free field, scaling the source by f changes g to g_part+(g-g_part)/f. Neither Q nor explicit source amplitude is required by the ideal inverse, but the matter/environment, geometry and observed trace are not thereby supplied.

The measured certificate uses Delta=Delta_hat-(ds2-ds1) and the strict margin |Delta_hat|>E_s. Its A and k identities and bilinear nu cross term are correct; the real-trace qualification makes the ordered sufficient-domain tests meaningful. Adopted deterministic error bounds, sampling/quadrature coverage, known z/time and an exact moment relation are necessary. Failure of the sufficient tests is inconclusive. No confidence level, achieved precision or measured likelihood is derived.

A third reserved functional is only a necessary consistency test. The final note expressly preserves the earlier nonzero moment-null counterexample. There is no claim that passing it proves the full ODE, this action uniquely, or empirical success from synthetic data.

## New targeted computations and actual damages

The new executable check_targeted_v1.py passed39/0 controls. These mix new exact mathematical confirmations with executable-function correspondence; they are not39 new physical predictions. It checks original-coordinate action differentiation, source variation and clock reduction, a distinct exact asymmetric weight1260*x^4*(1-x)^5, and the actual primary helper functions extracted from its AST without calling run_checks.

For helper correspondence the off-grid interval is[2/13,11/13] and the trace is1+2N-N^3+N^5. The primary moment helper is compared with80-digit direct integrals that use the trace's derivatives in the checker, providing an independent adjoint reference. The maximum scaled U,V,L discrepancy is1.82e-16, below the frozen2e-11 diagnostic threshold. This is numerical agreement, not a rigorous enclosure. An exact signed-row inverse at k=7/61,nu=11/17 confirms the executable k,A,nu signs. No ODE integration was performed in this unit.

Only the primary measured_checks function was additionally executed:70/0 of its own callback records, with16 exact rational corners. This is a permitted implementation correspondence to previously independent MC proof, not a new blind independent72-check suite. The actual primary synthetic-profile perturbation bounds remain the older true-A/true-separation formulas. All eight stored record bounds were recomputed from those formulas; no noisy-profile measured-data certificate is claimed.

Two actual changed canonical copies were separately executed through the targeted checker, with code and exact diffs preserved:

| Change | Targeted result | Failed witness |
|---|---:|---|
| Reverse moment adjoint sign |38/1, exit1| Off-grid L; scaled error0.0018457626 |
| Reverse executable A inverse numerator |37/2, exit1| Exact A and nu reconstructions |

Both had empty stderr and no exception. The repeated70 measured callback records pass in those runs because their functions were unchanged; they are not counted as fresh science. The parent five separate actual altered canonical executions were also verified against their one-replacement source protocols, code hashes, command/exit records, stdout/stderr and result files:131/32 wrong adjoint,151/12 wrong mode mass,162/1 wrong domain,131/32 omitted measured rank-error term,159/4 wrong potential mass. They were not rerun here.

The four retained primary profile files each contain1001 stored sites from N=0 to1.4, the expected initial values, finite arrays and matching z=50 exp(-N). Their actual final samples and cross-coordinate discrepancies are recorded in EVIDENCE_CORRESPONDENCE_v1.json. Every discrepancy matches the stored primary summary and is below2e-8. This verifies the recorded synthetic evidence; it is not a new full-history calculation or observational result.

## Preserved version drift and final confirmation

The initial cache read failed because the cache had not yet been supplied. That read failure is recorded. After the first cache was supplied, the parent added a three-line note qualification during this review. Consequently the first evidence run returned67/3, correctly failing the old-note hash, old primary-input/current-note identity and old-cache/current-input fingerprint. The complete failed execution remains unchanged. This is not relabelled70/0.

The first cache-addendum helper also contained an unconditional true metadata flag claiming unchanged note/runner/action. That flag was inaccurate during the detected note drift. SOURCE_DRIFT_DIAGNOSIS_v1.md explicitly preserves and corrects the checker metadata error; the detailed failed rows were always authoritative. It is not used for final freshness.

The separate final_source_v2 correspondence passes147/0. The new canonical note differs from the original only by the declared three lines. Each declared window has exact Delta N=2/5, so at constant vacuum H its background proper duration is0.4/H. Measurement feasibility and obtaining the same mode's time history from redshift bins are correctly left unestablished. No equations, parameters, windows, runner or source physics changed, and no39-control or earlier solver rerun was needed. The final cache's actual08:55:09–08:55:12 execution is source/input-bound to the revised note. Both superseded note/cache snapshots remain preserved and explicitly mapped.

## Source and claim dispositions

- **Supplied complete action, Einstein coefficient Q/2, scalar coefficient Q and selected expanding exact vacuum:** retained as explicit premises; no framework derivation or observed-state selection.
- **Coupling norm k and coupled mass B=4[3(1+k)+nu]/(1-3k)>12:** retained; independently confirmed against full action, including transverse Hessian closure.
- **General rolling covariant finite-scale equations and actual-rate comparison bound:** outside this canonical claim; preserved in original FS sources/evidence.
- **Finite asymptotic residual/preparation-dependent energy certificate:** not promoted into this inverse note; original FS proof/results preserved without rerun.
- **Conserved weak cold source, metric potential and exact finite-mode equation with free waves:** retained with zero-background-density, nonzero mean and weak-interval premises.
- **Weak adjoint, parameter inverse and admissible nu domain:** retained with corrected18k coefficient; original42k failure remains preserved.
- **Source amplitude and scalar preparation:** retained corrected qualification: explicit amplitude disappears from inverse, fixed absolute free wave still changes trace under source rescaling.
- **Continuous structural uniqueness and existence of separating weights:** retained only inside known-z differential-equation family; no guaranteed fixed-window rank or precision.
- **A reserved third moment:** retained as necessary only; moment-null deviations explicitly possible.
- **Old true-parameter amplitude-error bounds:** preserved in old source and primary synthetic-profile checks; not represented as measured-data certificate on those profiles.
- **Measured-data A,k,nu absolute-error certificate:** retained with strict measured-rank margin, adopted deterministic envelopes, exact cross term and explicit real-trace domain.
- **Empirical access and window duration:** explicitly supplied/unestablished; final prose-only duration qualification confirmed.

CLAIM_DISPOSITIONS_v1.json records these mappings. MANIFEST_v1.json and RECEIPT_v1.json seal this correspondence, including all failure history, scripts, actual commands, source snapshots and final correction confirmation. New result counts are kept separate from reused independent counts and primary executions. The report is complete for final-source correspondence; the parent's archive, exact five-file diff and delivery mapping are separate pending work.
