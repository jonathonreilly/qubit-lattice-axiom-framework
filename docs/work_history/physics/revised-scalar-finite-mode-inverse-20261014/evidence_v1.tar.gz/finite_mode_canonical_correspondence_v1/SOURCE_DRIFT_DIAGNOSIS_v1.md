# Preserved correspondence failure and metadata correction

The 08:54:37 first evidence-correspondence execution returned exit1, 67 passed / 3 failed. The parent had changed the live canonical note at08:53:55 from102cd505... to d816996... by adding a three-line observation-duration qualification. The old cache still referred to the original note. The three intended binding guards failed: source.note_hash, primary.input_1 and cache.input_fingerprint. This is a real live-version drift, not a mathematical failure, and not a reason to change any original scientific result.

The complete command, source, stdout, result and failed rows remain unchanged. They are not relabelled70/0. The new final_source_v2 unit must distinguish the original command's historical note from the current source and bind the new source-bound cache.

One helper metadata field also needs correction: CACHE_ADDENDUM_v1.json wrote same_canonical_note_runner_and_action=true unconditionally. That convenience field was inaccurate under the detected note drift. The detailed failed check rows and67/3 exit1 are authoritative. The v2 correspondence uses tested explicit dispositions, and does not reuse that constant as evidence of freshness. This checker metadata mistake is preserved, not erased.

No equation, original independent seal or producer runner changed. The initial absent-cache read is a separate earlier read failure preserved in PRE_BOOTSTRAP_READ_HISTORY_v1.json.
