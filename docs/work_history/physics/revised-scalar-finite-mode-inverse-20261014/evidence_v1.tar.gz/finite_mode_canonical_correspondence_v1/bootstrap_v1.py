from pathlib import Path
import json,hashlib,datetime,sys,shutil
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[4]
PACK=HERE.parent
assert ROOT.name=='New Axioms Lets Go',str(ROOT)
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def info(p):return {'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':h(p)}
def put(name,obj):(HERE/name).write_text(json.dumps(obj,indent=2)+'\n')
selected=set()
for p in [ROOT/'docs/EXPONENTIAL_SCALAR_FINITE_MODE_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md',ROOT/'scripts/exponential_scalar_finite_mode_inverse_check.py',ROOT/'docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md']:
 selected.add(p)
units=[PACK/'rolling_local_response/finite_scale_v1/independent_v1',PACK/'rolling_local_response/finite_mode_inverse_v1/independent_v1',PACK/'rolling_local_response/finite_mode_inverse_v1/measured_certificate_independent_v1']
verification=[]
for unit in units:
 receipt=json.loads((unit/'RECEIPT_v1.json').read_text());manifest=json.loads((unit/'MANIFEST_v1.json').read_text())
 rows=[]
 for item in manifest['artifacts']:
  p=unit/item['path'];actual=info(p)
  rows.append({'kind':'manifest_artifact',**actual,'expected_bytes':item['bytes'],'expected_sha256':item['sha256'],'pass':p.is_file() and not p.is_symlink() and actual['bytes']==item['bytes'] and actual['sha256']==item['sha256']})
 for typ in ['manifest','report']:
  item=receipt[typ];p=unit/item['path'];actual=info(p)
  rows.append({'kind':'receipt_'+typ,**actual,'expected_bytes':item['bytes'],'expected_sha256':item['sha256'],'pass':actual['bytes']==item['bytes'] and actual['sha256']==item['sha256']})
 for item in receipt['source_bindings']:
  live=ROOT/item['original_path'];snap=unit/item['snapshot_path']
  for label,p in [('live',live),('snapshot',snap)]:
   actual=info(p);rows.append({'kind':'source_'+label,**actual,'expected_bytes':item['bytes'],'expected_sha256':item['sha256'],'pass':actual['bytes']==item['bytes'] and actual['sha256']==item['sha256']})
  selected.add(live)
 for p in unit.iterdir():
  if p.is_file() and p.suffix in ['.md','.json'] and (p.name.startswith(('REPORT','RECEIPT','MANIFEST','SOURCE','HAND','IDENTIFIABILITY','FAILURES','EVIDENCE','PROTOCOL'))):selected.add(p)
 verification.append({'unit':str(unit.relative_to(ROOT)),'receipt':info(unit/'RECEIPT_v1.json'),'manifest_artifacts':len(manifest['artifacts']),'source_pairs':len(receipt['source_bindings']),'checks':rows,'failed':sum(not x['pass'] for x in rows)})
for p in (PACK/'finite_mode_packaging').rglob('*'):
 if p.is_file():selected.add(p)
for name in ['DERIVATION_v3.md','IDENTIFIABILITY_LEMMA_v1.md','MEASURED_ERROR_CERTIFICATE_v2.md']:
 selected.add(PACK/'rolling_local_response/finite_mode_inverse_v1'/name)
sources=[]
for p in sorted(selected):
 rel=p.relative_to(ROOT);dest=HERE/'sources'/rel
 dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 sources.append({'original_path':str(rel),'snapshot_path':str(dest.relative_to(HERE)),'bytes':p.stat().st_size,'sha256':h(p)})
put('SOURCE_MANIFEST_v1.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':sources,'cache_supplied':False,'scope':'Source/evidence correspondence; old science is reused, not rerun.'})
put('REUSED_UNIT_BINDINGS_v1.json',{'units':verification,'artifact_total':sum(u['manifest_artifacts'] for u in verification),'source_pair_total':sum(u['source_pairs'] for u in verification),'failed':sum(u['failed'] for u in verification)})
print(json.dumps({'source_count':len(sources),'reused_artifacts':sum(u['manifest_artifacts'] for u in verification),'reused_source_pairs':sum(u['source_pairs'] for u in verification),'failed':sum(u['failed'] for u in verification)},indent=2))
sys.exit(bool(sum(u['failed'] for u in verification)))
