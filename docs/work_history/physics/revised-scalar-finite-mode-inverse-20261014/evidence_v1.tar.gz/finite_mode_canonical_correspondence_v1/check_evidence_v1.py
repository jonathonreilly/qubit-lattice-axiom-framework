from pathlib import Path
import ast,datetime,hashlib,json,shutil,sys
import numpy as np
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[4];PACK=HERE.parent
PKREL=PACK.relative_to(ROOT);PACKAGING=PKREL/'finite_mode_packaging'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(name,value):(HERE/name).write_text(json.dumps(value,indent=2,default=str)+'\n')
rows=[]
def check(name,ok,**kw):rows.append({'name':name,'passed':bool(ok),**kw})
def load(p):return json.loads(p.read_text())
def frozen(rel):return HERE/'sources'/rel
old=load(HERE/'SOURCE_MANIFEST_v1.json');sources=list(old['sources']);new=[]
for rel in [Path('logs/runner-cache/exponential_scalar_finite_mode_inverse_check.txt'),PACKAGING/'CACHE_RUN_v1.json',Path('scripts/runner_cache.py')]:
 src=ROOT/rel;dest=frozen(rel);dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();shutil.copyfile(src,dest)
 row={'original_path':str(rel),'snapshot_path':str(dest.relative_to(HERE)),'bytes':src.stat().st_size,'sha256':h(src)};sources.append(row);new.append(row)
put('SOURCE_MANIFEST_v2.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':sources,'new_sources':new,'preserved_v1':'SOURCE_MANIFEST_v1.json','scope':'Only late cache, cache execution record, and read-only cache-format helper added.'})
runner=ROOT/'scripts/exponential_scalar_finite_mode_inverse_check.py';note=ROOT/'docs/EXPONENTIAL_SCALAR_FINITE_MODE_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md';action=ROOT/'docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md'
check('source.runner_hash',h(runner)=='61a5ebce5cf8d39d1683b257393f6a88c3c37ba05c8626f402caf2358c3112bc');check('source.note_hash',h(note)=='102cd505d6e470a061db3189370f9a10c73c74de439a76bdacf71b75dfbc835b');check('source.action_hash',h(action)=='39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000')
primary=load(frozen(PACKAGING/'canonical_run_v1/RESULTS.json'));run=load(frozen(PACKAGING/'CANONICAL_RUN_v1.json'));command=load(frozen(PACKAGING/'CANONICAL_COMMAND_v1.json'))
check('primary.counts',primary['counts']=={'passed':163,'failed':0} and len(primary['checks'])==163 and all(x['passed'] for x in primary['checks']))
check('primary.command',run['command']==command['command'] and run['exit_code']==0 and run['command'][2]==str(runner))
for i,item in enumerate(run['inputs']):check('primary.input_'+str(i),h(Path(item['path']))==item['sha256'],**item)
check('primary.stdout_hash',h(frozen(PACKAGING/'CANONICAL_RUN_v1.stdout'))==run['stdout_sha256']);check('primary.stderr_hash',h(frozen(PACKAGING/'CANONICAL_RUN_v1.stderr'))==run['stderr_sha256']);check('primary.stdout_result',load(frozen(PACKAGING/'CANONICAL_RUN_v1.stdout'))==primary)
check('primary.four_cases',len(primary['cases'])==4)
profile_rows=[]
for case in primary['cases']:
 p=frozen(PACKAGING/'canonical_run_v1'/(case['label']+'_profiles.npz'))
 with np.load(p,allow_pickle=False) as a:
  N=a['N'];z=a['z'];f=a['DOP853_y_yN'];g=a['Radau_y_yN']
  check(case['label']+'.profile_shape',N.shape==(1001,) and z.shape==(1001,) and f.shape==(2,1001) and g.shape==(2,1001))
  check(case['label']+'.stored_domain',N[0]==0 and N[-1]==1.4 and np.all(np.diff(N)>0) and np.max(abs(z-50*np.exp(-N)))<1e-13)
  check(case['label']+'.finite_profiles',all(np.isfinite(a[key]).all() for key in a.files))
  check(case['label']+'.initial_data',np.max(abs(f[:,0]-[case['initial_y'],-50*case['initial_y_z']]))<1e-12 and np.max(abs(g[:,0]-[case['initial_y'],-50*case['initial_y_z']]))<1e-12)
  err=float(np.max(abs(f-g)/(1+abs(g))));check(case['label']+'.recorded_discrepancy',err==case['coordinate_method_discrepancy'] and err<2e-8)
  profile_rows.append({'label':case['label'],'sha256':h(p),'stored_last_N':float(N[-1]),'stored_last_z':float(z[-1]),'stored_last_DOP_y_yN':f[:,-1].tolist(),'stored_last_Radau_y_yN':g[:,-1].tolist(),'coordinate_discrepancy':err})
 # Explicitly distinguish the old true-centered synthetic profile bound.
 for record in case['records']:
  ms=record['moments'];eps=record['amplitude_error_envelope'];ss=[eps/m['V'] for m in ms[:2]];bs=[eps*m['operator_weight_norm']/m['V'] for m in ms[:2]];kv=float(__import__('fractions').Fraction(case['k']));nv=float(__import__('fractions').Fraction(case['nu']));av=4*(3*(1+kv)+nv)/(1-3*kv)-2
  BA=(sum(bs)+abs(av)*sum(ss))/(abs(ms[1]['s']-ms[0]['s'])-sum(ss));BK=bs[0]+abs(av)*ss[0]+(abs(ms[0]['s'])+ss[0])*BA
  check(case['label']+'.'+record['method']+'.true_centered_bound',BA==record['A_error_bound'] and BK==record['k_error_bound'])
dp=frozen(PACKAGING/'damages_v1');protocol=load(dp/'PROTOCOL.json');summary=load(dp/'SUMMARY.json');base=frozen(Path('scripts/exponential_scalar_finite_mode_inverse_check.py')).read_text();damage_rows=[]
for change,summed in zip(protocol['changes'],summary):
 name=change['name'];d=dp/name;code=dp/(name+'.py');ex=load(d/'EXECUTION.json');result=load(d/'profiles/RESULTS.json');failed=[r['name'] for r in result['checks'] if not r['passed']]
 check(name+'.actual_mutated_bytes',base.count(change['old'])==1 and code.read_text()==base.replace(change['old'],change['new']) and h(code)==ex['code_sha256'])
 check(name+'.actual_exit',ex['exit_code']==1 and ex['command'][2]==str(ROOT/PACKAGING/'damages_v1'/(name+'.py')))
 check(name+'.output_bindings',h(d/'stdout.json')==ex['stdout_sha256'] and h(d/'stderr.txt')==ex['stderr_sha256'] and (d/'stderr.txt').stat().st_size==0 and load(d/'stdout.json')==result)
 check(name+'.failed_records',result['counts']==summed['counts'] and failed==summed['failed_checks'] and len(failed)>0)
 damage_rows.append({'name':name,'code_sha256':h(code),'counts':result['counts'],'failed_checks':failed,'rerun':False})
cache=frozen(Path('logs/runner-cache/exponential_scalar_finite_mode_inverse_check.txt'));text=cache.read_text();head,rest=text.split('----- stdout -----\n',1);body,stderr=rest.split('----- stderr -----\n',1);cached=json.loads(body);meta=dict(line.split(': ',1) for line in head.splitlines() if ': ' in line)
check('cache.hash',h(cache)=='a42aa3330e1af0208d352886b2470caccf0dbf4ede346502f167a53922f8fe9b')
check('cache.source_header',meta['runner_sha256']==h(runner) and meta['status']=='ok' and meta['exit_code']=='0' and meta['timeout_sec']=='120')
tree=ast.parse(runner.read_text());inputs=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in n.targets));digest=hashlib.sha256(b'runner-cache-input-fingerprint-v1\0')
for rel in inputs:
 b=(ROOT/rel).read_bytes();r=rel.encode();digest.update(len(r).to_bytes(8,'big'));digest.update(r);digest.update(len(b).to_bytes(8,'big'));digest.update(b)
check('cache.input_fingerprint',meta['input_fingerprint_sha256']==digest.hexdigest(),computed=digest.hexdigest())
check('cache.full_result_correspondence',cached==primary)
cr=load(frozen(PACKAGING/'CACHE_RUN_v1.json'));check('cache.execution_record',cr['cache_sha256']==h(cache) and cr['status']=='ok' and cr['exit_code']==0 and cr['freshness']=='fresh')
check('cache.empty_stderr',not stderr.strip())
for i,src in enumerate(new):check('cache.new_source_'+str(i),h(ROOT/src['original_path'])==h(HERE/src['snapshot_path'])==src['sha256'])
put('CACHE_ADDENDUM_v1.json',{'scope':'Narrow late-cache source correspondence; initial absent-cache read preserved, no runner execution here.','original_absent_read':'PRE_BOOTSTRAP_READ_HISTORY_v1.json','new_sources':new,'cache_header':meta,'computed_input_fingerprint':digest.hexdigest(),'checks':[r for r in rows if r['name'].startswith('cache.')],'same_canonical_note_runner_and_action':True})
result={'scope':'Read-only recorded evidence/implementation mapping; no primary or old independent solver rerun.','checks':rows,'counts':{'passed':sum(r['passed'] for r in rows),'failed':sum(not r['passed'] for r in rows)},'profiles':profile_rows,'parent_actual_damages':damage_rows,'source_count':len(sources)};put('EVIDENCE_CORRESPONDENCE_v1.json',result);print(json.dumps({'counts':result['counts'],'source_count':len(sources),'failed':[r for r in rows if not r['passed']]},indent=2));sys.exit(bool(result['counts']['failed']))
