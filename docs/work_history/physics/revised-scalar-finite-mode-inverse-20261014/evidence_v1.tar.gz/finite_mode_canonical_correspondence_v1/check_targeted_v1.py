from pathlib import Path
import argparse,ast,hashlib,importlib.util,json,math,sys
import sympy as s
import numpy as np
import mpmath as mp
from scipy.integrate import quad
HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--runner',type=Path,default=HERE/'sources/scripts/exponential_scalar_finite_mode_inverse_check.py');parser.add_argument('--label',default='targeted_baseline_v1');args=parser.parse_args()
runner=args.runner.resolve();assert runner.is_relative_to(HERE)
out=HERE/args.label;out.mkdir(exist_ok=False)
rows=[]
def check(name,ok,**kw):rows.append({'name':name,'passed':bool(ok),**kw})
def zero(name,value):
 value=s.factor(s.simplify(value));check(name,value==0,residual=str(value))
def dump(name,obj):(out/name).write_text(json.dumps(obj,indent=2,default=str)+'\n')
# New direct differentiation in the original field coordinates, not the producer t coordinate.
k,nu=s.symbols('k nu',positive=True);u,x,y=s.symbols('u x y',real=True)
a=(1-k)*(1+3*k)/4;alpha=s.sqrt(a);ss=(1+k)/(k*(1-3*k));E=s.exp(2*alpha*u);F=1+ss*E;J=1+(1-3*a)*ss*E;D=1+2*(1+k)*(x*x+y*y)/3
K=s.diag(J/F**2,(1+ss)*4*k/(9*F*D),(1+ss)*k/(3*F*D));C=(1+ss)*E/F
U=s.Rational(3,2)+3*ss*(E-1)**2/(2*F**2)+k*x*x*s.exp(-(1-k)*u/alpha)/2+k*y*y*s.exp(-(1+k)*u/alpha)/3+nu*(1+ss)*u*u/(2*F**2)
fields=[u,x,y];at={u:0,x:0,y:0};K0=K.subs(at)
hess=s.hessian(U,fields).subs(at);b=s.Matrix([s.diff(s.log(C)/2,v).subs(at) for v in fields]);M=K0.inv()*hess
zero('action.original_u_C',C.subs(at)-1);zero('action.original_u_U',U.subs(at)-s.Rational(3,2))
for i,v in enumerate(fields):zero('action.gradient_'+str(v),s.diff(U,v).subs(at))
zero('action.coupling_norm',(b.T*K0.inv()*b)[0]-k)
B=4*(3*(1+k)+nu)/(1-3*k)
for i,target in enumerate([B,s.Rational(9,4),s.Integer(2)]):zero('action.mass_'+str(i),M[i,i]-target)
for i in range(3):
 for j in range(i+1,3):zero('action.mixed_'+str(i)+str(j),hess[i,j])
zero('action.mass_margin',B-12-(48*k+4*nu)/(1-3*k));zero('domain.corrected_margin',(B-2)*(1-3*k)-10-18*k-4*nu)
# Lagrangian variation gives sign and factor without quoting a matter-scalar equation.
t,H,Q,p0,rho0,bc,Bc=s.symbols('t H Q p0 rho0 bc Bc',positive=True);xi=s.Function('xi')(t);aa=s.exp(H*t);rho=rho0/aa**3;p2=p0*p0/aa**2
lag=aa**3*(Q*s.diff(xi,t)**2-Q*(p2+Bc*H*H)*xi**2-bc*rho*xi)
el=s.diff(s.diff(lag,s.diff(xi,t)),t)-s.diff(lag,xi)
zero('source.euler_lagrange_sign_factor',el/(2*Q*aa**3)-(s.diff(xi,t,2)+3*H*s.diff(xi,t)+(p2+Bc*H*H)*xi+bc*rho/(2*Q)))
Phi=-rho/(2*Q*p2);zero('source.Phi_clock',s.diff(Phi,t)+H*Phi);zero('source.conserved_density',s.diff(rho,t)+3*H*rho)
Y=s.Function('Y')(t);expr=bc*Phi*Y
rescale=(s.diff(expr,t,2)+3*H*s.diff(expr,t)+(p2+Bc*H*H)*expr+bc*rho/(2*Q))/(bc*Phi)
zero('mode.mass_clock_shift',rescale-(s.diff(Y,t,2)+H*s.diff(Y,t)+(p2+(Bc-2)*H*H)*Y-p2))
P,bn,h,yp,f=s.symbols('P bn h yp f',nonzero=True);phiJ=f*P+bn*(f*bn*P*yp+h);psiJ=f*P-bn*(f*bn*P*yp+h)
gf=(phiJ-psiJ)/(phiJ+psiJ);g1=bn*bn*yp+bn*h/P
zero('source.fixed_free_wave_ratio',gf-(bn*bn*yp+(g1-bn*bn*yp)/f))
# Distinct exact weight/trace checks the adjoint, not the ODE generator.
N=s.symbols('N',real=True);left=s.Rational(2,13);right=s.Rational(11,13);T=right-left;xx=(N-left)/T
w=1260*xx**4*(1-xx)**5/T;g=1+2*N-N**3+N**5
zero('weak.asymmetric_weight_norm',s.integrate(w,(N,left,right))-1)
zero('weak.asymmetric_adjoint',s.integrate(w*(s.diff(g,N,2)+s.diff(g,N))-(s.diff(w,N,2)-s.diff(w,N))*g,(N,left,right)))
for endpoint in [left,right]:
 zero('weak.endpoint_'+str(endpoint),w.subs(N,endpoint));zero('weak.endpoint_derivative_'+str(endpoint),s.diff(w,N).subs(N,endpoint))
# The following is implementation correspondence to the actual producer function bytes.
source=runner.read_text();tree=ast.parse(source)
imports=sorted({(n.module or '').split('.')[0] for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)}|{a.name.split('.')[0] for n in ast.walk(tree) if isinstance(n,ast.Import) for a in n.names})
check('implementation.import_closure',set(imports)=={'pathlib','argparse','itertools','json','math','tempfile','numpy','sympy','scipy'},imports=imports)
inputs=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in n.targets))
check('implementation.input_closure',tuple(inputs)==('docs/EXPONENTIAL_SCALAR_FINITE_MODE_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md','docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md'),inputs=inputs)
run=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run_checks')
helpers=[n for n in run.body if isinstance(n,ast.FunctionDef) and n.name in ['weights','moments','inverse']]
assign=lambda name:next(n for n in run.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
x=s.symbols('x',real=True);poly=eval(compile(ast.Expression(assign('polynomial').value),str(runner),'eval'),{'s':s,'x':x})
zero('implementation.weight_polynomial',poly-140*x**3*(1-x)**3)
z0=ast.literal_eval(assign('z0').value);check('implementation.z0',z0==50.)
namespace={'quad':quad,'math':math,'z0':z0,'wv':s.lambdify(x,poly,'numpy'),'wd':s.lambdify(x,s.diff(poly,x),'numpy'),'wdd':s.lambdify(x,s.diff(poly,x,2),'numpy')}
module=ast.fix_missing_locations(ast.Module(body=helpers,type_ignores=[]));exec(compile(module,str(runner),'exec'),namespace)
(out/'EXTRACTED_HELPERS.py').write_text(ast.unparse(module)+'\n')
mp.mp.dps=80;ml=mp.mpf(2)/13;mr=mp.mpf(11)/13;mT=mr-ml
wg=lambda n:140*((n-ml)/mT)**3*(1-(n-ml)/mT)**3/mT
gm=lambda n:1+2*n-n**3+n**5;gmp=lambda n:2-3*n*n+5*n**4;gmpp=lambda n:-6*n+20*n**3
refs={'U':mp.quad(lambda n:wg(n)*gm(n),[ml,mr]),'V':mp.quad(lambda n:wg(n)*mp.mpf(2500)*mp.exp(-2*n),[ml,mr]),'L':mp.quad(lambda n:wg(n)*(gmpp(n)+gmp(n)+mp.mpf(2500)*mp.exp(-2*n)*gm(n)),[ml,mr])}
actual=namespace['moments'](lambda n:1+2*n-n**3+n**5,(float(left),float(right)))
for name in ['U','V','L']:
 err=abs(mp.mpf(actual[name])-refs[name])/(1+abs(refs[name]));check('implementation.offgrid_moment_'+name,err<mp.mpf('2e-11'),scaled_error=str(err),reference=str(refs[name]),actual=actual[name])
kt=s.Rational(7,61);nt=s.Rational(11,17);At=s.factor(B.subs({k:kt,nu:nt})-2)
ms=[]
for ui,vi in [(s.Rational(-7,11),s.Rational(3,7)),(s.Rational(5,13),s.Rational(11,5))]:ms.append({'U':ui,'V':vi,'L':kt*vi-At*ui})
ki,Ai,ni,det=namespace['inverse'](ms)
zero('implementation.signed_exact_inverse_k',ki-kt);zero('implementation.signed_exact_inverse_A',Ai-At);zero('implementation.signed_exact_inverse_nu',ni-nt);check('implementation.signed_exact_inverse_rank',det!=0,determinant=str(det))
# Execute only the measured checker, not run_checks or any solver.
spec=importlib.util.spec_from_file_location('canonical_correspondence_target',runner);producer=importlib.util.module_from_spec(spec);spec.loader.exec_module(producer)
mr=[]
def pc(name,ok,**extra):mr.append({'name':name,'passed':bool(ok),**extra})
def pz(name,value):value=s.factor(s.simplify(value));pc(name,value==0,residual=str(value))
corners=producer.measured_checks(pc,pz)
check('implementation.measured_callback_pass',all(r['passed'] for r in mr),records=len(mr),failed=[r['name'] for r in mr if not r['passed']])
check('implementation.measured_callback_corner_count',len(corners)==16)
check('implementation.measured_callback_real_certificates',all(c['certifies_physical_domain'] for c in corners))
result={'scope':'New exact controls plus producer-helper implementation correspondence, not rerun of sealed independent science or full canonical runner.','runner':{'path':str(runner.relative_to(HERE)),'sha256':hashlib.sha256(runner.read_bytes()).hexdigest()},'checks':rows,'counts':{'passed':sum(r['passed'] for r in rows),'failed':sum(not r['passed'] for r in rows)},'primary_measured_function_records':mr,'primary_measured_function_counts':{'passed':sum(r['passed'] for r in mr),'failed':sum(not r['passed'] for r in mr)},'measured_corners':corners,'actual_helper_moments':actual,'exact_inverse':{'k':str(ki),'A':str(Ai),'nu':str(ni),'D':str(det)},'no_ODE_integrations':True}
dump('RESULTS_v1.json',result);print(json.dumps({'counts':result['counts'],'primary_measured_function_counts':result['primary_measured_function_counts'],'failed':[r for r in rows if not r['passed']]},indent=2));sys.exit(bool(result['counts']['failed']))
