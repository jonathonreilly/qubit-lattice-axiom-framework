from pathlib import Path
import ast,datetime,difflib,hashlib,json,shutil,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[4];PACK=HERE.parent;PKREL=PACK.relative_to(ROOT);P=PKREL/'finite_mode_packaging';OUT=HERE/'final_source_v2';OUT.mkdir(exist_ok=False)
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(path,v):path.write_text(json.dumps(v,indent=2)+'\n')
def load(p):return json.loads(p.read_text())
rows=[]
def check(name,ok,**kw):rows.append({'name':name,'passed':bool(ok),**kw})
rels=[Path('docs/EXPONENTIAL_SCALAR_FINITE_MODE_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md'),Path('logs/runner-cache/exponential_scalar_finite_mode_inverse_check.txt'),P/'CACHE_RUN_v2.json',P/'DURATION_CLARIFICATION_v2.json',P/'DURATION_CLARIFICATION_v2.diff',P/'CACHE_before_duration_clarification_v1.txt']
new=[]
for rel in rels:
 live=ROOT/rel;dest=OUT/'sources'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(live,dest);new.append({'original_path':str(rel),'snapshot_path':str(dest.relative_to(HERE)),'bytes':live.stat().st_size,'sha256':h(live),'disposition':'current_live_source'})
oldnote=HERE/'sources'/rels[0];note=OUT/'sources'/rels[0];oldcache=HERE/'sources'/rels[1];cache=OUT/'sources'/rels[1]
check('source.final_note_hash',h(note)=='d816996a38b6ca65feef503578372058d6d67561fd4c36318f476ca6ba22ee64');check('source.final_cache_hash',h(cache)=='13d36c295c0c5fde1a58dddf6cc17e6d5d19de502cf5e68929c026f1840b0d2e')
insert='The duration of each synthetic window is0.4/H. Observational feasibility\nof that time span and matched-mode access is not established. A set of\nredshift bins does not automatically supply the same mode\'s time history.\n'
check('scope.sole_prose_insertion',note.read_text().count(insert)==1 and note.read_text().replace(insert,'')==oldnote.read_text())
md=load(OUT/'sources'/rels[3]);check('scope.correction_hashes',md['before_sha256']==h(oldnote) and md['after_sha256']==h(note))
diff=''.join(difflib.unified_diff(oldnote.read_text().splitlines(True),note.read_text().splitlines(True),fromfile='canonical_note_v1',tofile='canonical_note_v2'));(OUT/'INDEPENDENT_NOTE_v1_v2.diff').write_text(diff);check('scope.exact_diff',diff==(OUT/'sources'/rels[4]).read_text())
check('scope.old_cache_recovery',h(OUT/'sources'/rels[5])==h(oldcache)=='a42aa3330e1af0208d352886b2470caccf0dbf4ede346502f167a53922f8fe9b')
# Constant de Sitter H gives dt=dN/H. Each declared interval has exact length2/5.
from fractions import Fraction
intervals=[(Fraction(0),Fraction(2,5)),(Fraction(1,2),Fraction(9,10)),(Fraction(1),Fraction(7,5))]
check('scope.exact_window_duration',all(r-l==Fraction(2,5) for l,r in intervals),statement='At constant H=Hv and C0=1, each proper background-time duration is (2/5)/H. No feasibility or source-tracking observation follows.')
runner=ROOT/'scripts/exponential_scalar_finite_mode_inverse_check.py';action=ROOT/'docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md'
check('source.runner_unchanged',h(runner)=='61a5ebce5cf8d39d1683b257393f6a88c3c37ba05c8626f402caf2358c3112bc');check('source.full_action_unchanged',h(action)=='39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000')
run=load(HERE/'sources'/P/'CANONICAL_RUN_v1.json')
for i,inp in enumerate(run['inputs']):
 rel=Path(inp['path']).relative_to(ROOT);snap=HERE/'sources'/rel;check('historical_primary.input_'+str(i),h(snap)==inp['sha256'],historical_snapshot=str(snap.relative_to(HERE)),sha256=inp['sha256'])
first=load(HERE/'EVIDENCE_CORRESPONDENCE_v1.json');failed=[r['name'] for r in first['checks'] if not r['passed']];check('history.three_failed_drift_guards_preserved',first['counts']=={'passed':67,'failed':3} and failed==['source.note_hash','primary.input_1','cache.input_fingerprint'])
text=cache.read_text();head,rest=text.split('----- stdout -----\n',1);body,stderr=rest.split('----- stderr -----\n',1);result=json.loads(body);meta=dict(line.split(': ',1) for line in head.splitlines() if ': ' in line)
tree=ast.parse(runner.read_text());inputs=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in n.targets));digest=hashlib.sha256(b'runner-cache-input-fingerprint-v1\0')
for rel in inputs:
 b=(ROOT/rel).read_bytes();r=rel.encode();digest.update(len(r).to_bytes(8,'big'));digest.update(r);digest.update(len(b).to_bytes(8,'big'));digest.update(b)
check('cache.final_input_fingerprint',meta['input_fingerprint_sha256']==digest.hexdigest(),computed=digest.hexdigest());check('cache.final_runner_header',meta['runner_sha256']==h(runner) and meta['runner']=='scripts/exponential_scalar_finite_mode_inverse_check.py' and meta['status']=='ok' and meta['exit_code']=='0' and meta['timeout_sec']=='120')
primary=load(HERE/'sources'/P/'canonical_run_v1/RESULTS.json');check('cache.same_full_result',result==primary and result['counts']=={'passed':163,'failed':0});check('cache.empty_stderr',not stderr.strip())
cr=load(OUT/'sources'/P/'CACHE_RUN_v2.json');check('cache.real_execution_record',cr['cache_sha256']==h(cache) and cr['status']=='ok' and cr['exit_code']==0 and cr['freshness']=='fresh')
# Final source inventory explicitly retains the two superseded original bindings.
old=load(HERE/'SOURCE_MANIFEST_v2.json');sources=[]
for row in old['sources']:
 row=dict(row);live=ROOT/row['original_path'];snapshot=HERE/row['snapshot_path'];row['current_live_sha256']=h(live)
 if row['original_path'] in [str(rels[0]),str(rels[1])]:
  row['disposition']='superseded_by_declared_duration_note_and_cache_update';row['recovery']=row['snapshot_path'];check('superseded.'+str(len(sources)),h(snapshot)==row['sha256'] and h(live)!=row['sha256'])
 else:
  row['disposition']='current_live_source';check('live.'+str(len(sources)),h(live)==h(snapshot)==row['sha256'] and live.stat().st_size==row['bytes'])
 sources.append(row)
for row in new:
 live=ROOT/row['original_path'];snapshot=HERE/row['snapshot_path'];check('final_live.'+str(len(sources)),h(live)==h(snapshot)==row['sha256']);sources.append(row)
put(HERE/'SOURCE_MANIFEST_v3.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':sources,'original_manifests_preserved':['SOURCE_MANIFEST_v1.json','SOURCE_MANIFEST_v2.json'],'superseded_sources':2,'scope':'Two historical source bindings explicitly superseded; all snapshots retained. No prior science results rerun.'})
res={'scope':'Narrow final prose/cache correspondence only; new math restricted to exact window-duration conversion.','checks':rows,'counts':{'passed':sum(r['passed'] for r in rows),'failed':sum(not r['passed'] for r in rows)},'final_cache_header':meta,'source_count':len(sources),'source_dispositions':{'superseded_historical_sources':2,'current_live_sources':len(sources)-2},'reused_targeted_checks':{'passed':39,'failed':0},'correction':'The untested true metadata flag in CACHE_ADDENDUM_v1.json is superseded by this explicit tested source inventory; original67/3 failure preserved.'};put(OUT/'CORRESPONDENCE_v2.json',res);print(json.dumps({'counts':res['counts'],'source_count':len(sources),'failed':[r for r in rows if not r['passed']]},indent=2));sys.exit(bool(res['counts']['failed']))
