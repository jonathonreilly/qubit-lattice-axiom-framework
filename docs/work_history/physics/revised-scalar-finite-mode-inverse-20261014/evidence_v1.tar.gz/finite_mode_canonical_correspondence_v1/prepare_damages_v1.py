from pathlib import Path
import hashlib,json,difflib,datetime
here=Path(__file__).resolve().parent
p=here/'sources/scripts/exponential_scalar_finite_mode_inverse_check.py'
source=p.read_text();out=here/'actual_helper_damages_v1';out.mkdir(exist_ok=False)
changes=[('wrong_adjoint','return ww, wpp-wp+zz*zz*ww, zz','return ww, wpp+wp+zz*zz*ww, zz','implementation.offgrid_moment_L'),('reversed_inverse_A',"aa=(m2['V']*m1['L']-m1['V']*m2['L'])/det","aa=(m1['V']*m2['L']-m2['V']*m1['L'])/det",'implementation.signed_exact_inverse_A')]
rows=[]
for name,old,new,witness in changes:
 assert source.count(old)==1
 target=out/(name+'.py');target.write_text(source.replace(old,new))
 diff=''.join(difflib.unified_diff(source.splitlines(True),target.read_text().splitlines(True),fromfile='canonical_frozen.py',tofile=target.name));(out/(name+'.diff')).write_text(diff)
 rows.append({'name':name,'old':old,'new':new,'witness':witness,'runner':str(target.relative_to(here)),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
(out/'PROTOCOL_v1.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseline_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'changes':rows,'execution':'Only targeted checker and canonical function snippets; no ODE solve.'},indent=2)+'\n')
print(json.dumps(rows,indent=2))
