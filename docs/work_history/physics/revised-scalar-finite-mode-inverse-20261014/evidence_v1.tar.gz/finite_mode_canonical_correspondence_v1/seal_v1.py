from pathlib import Path
import datetime,hashlib,json,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[4]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def meta(p):return {'path':str(p.relative_to(HERE)),'bytes':p.stat().st_size,'sha256':h(p)}
def put(name,v):(HERE/name).write_text(json.dumps(v,indent=2)+'\n')
assert not (HERE/'MANIFEST_v1.json').exists() and not (HERE/'RECEIPT_v1.json').exists()
start=datetime.datetime.now(datetime.timezone.utc).isoformat();put('SEAL_COMMAND_v1.json',{'started_utc':start,'command':[sys.executable,'-B',*sys.argv],'cwd':str(HERE),'script_sha256':h(Path(__file__)),'scope':'Final local evidence/source verification and immutable receipt seal, no science execution.'})
sm=load(HERE/'SOURCE_MANIFEST_v3.json');source_checks=[]
for row in sm['sources']:
 snap=HERE/row['snapshot_path'];live=ROOT/row['original_path'];actual=h(live);snapshot_ok=h(snap)==row['sha256'] and snap.stat().st_size==row['bytes']
 if row['disposition']=='current_live_source':ok=snapshot_ok and actual==row['sha256'] and live.stat().st_size==row['bytes']
 else:
  matching=[r for r in sm['sources'] if r['original_path']==row['original_path'] and r['disposition']=='current_live_source'];ok=snapshot_ok and len(matching)==1 and matching[0]['sha256']==actual and actual!=row['sha256']
 source_checks.append({'original_path':row['original_path'],'snapshot_path':row['snapshot_path'],'disposition':row['disposition'],'snapshot_sha256':row['sha256'],'current_live_sha256':actual,'passed':ok})
prior=load(HERE/'REUSED_UNIT_BINDINGS_v1.json');prior_checks=[]
for unit in prior['units']:
 for row in unit['checks']:
  p=ROOT/row['path'];prior_checks.append({'path':row['path'],'kind':row['kind'],'passed':h(p)==row['expected_sha256'] and p.stat().st_size==row['expected_bytes']})
commands=[]
for p in sorted(HERE.glob('*execution*.json')):
 row=load(p);script=Path(row['command'][2]);ok=h(script)==row['script_sha256']
 for key in ['stdout','stderr']:
  v=row[key];f=HERE/v['path'];ok=ok and h(f)==v['sha256'] and f.stat().st_size==v['bytes']
 commands.append({'path':p.name,'exit_code':row['exit_code'],'passed':bool(ok)})
fail=sum(not x['passed'] for x in source_checks+prior_checks+commands)
binding={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_bindings':source_checks,'prior_unit_bindings':prior_checks,'execution_bindings':commands,'counts':{'passed':len(source_checks)+len(prior_checks)+len(commands)-fail,'failed':fail},'meaning':'Integrity only; no repeated mathematical/solver results.'};put('FINAL_BINDING_CHECK_v1.json',binding)
if fail:print(json.dumps({'binding_failed':fail},indent=2));sys.exit(1)
files=[]
for p in sorted(HERE.rglob('*')):
 assert not p.is_symlink(),str(p)
 if p.is_file() and p.name not in ['MANIFEST_v1.json','RECEIPT_v1.json']:
  files.append(meta(p))
# Only the root manifest/receipt are excluded, not same-named frozen prior receipts.
files=[]
for p in sorted(HERE.rglob('*')):
 if p.is_file() and p not in [HERE/'MANIFEST_v1.json',HERE/'RECEIPT_v1.json']:files.append(meta(p))
manifest={'schema':'immutable-focused-correspondence-manifest-v1','artifacts':files,'artifact_count':len(files),'excluded':['MANIFEST_v1.json','RECEIPT_v1.json'],'no_symlinks':True};put('MANIFEST_v1.json',manifest)
final=load(HERE/'final_source_v2/CORRESPONDENCE_v2.json');target=load(HERE/'targeted_baseline_v1/RESULTS_v1.json')
receipt={'schema':'focused-final-source-correspondence-receipt-v1','sealed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checker':'/root/local_response_check','scientific_author':'/root','formal_audit':False,'scope':'Canonical finite-mode inverse supplied action, weak conserved-vacuum Fourier response, rank/uniqueness, measured certificate and final implementation/evidence correspondence.','outcome':'No new mathematical correction required. Final prose-only duration qualification and fresh source/input-bound cache confirmed; ready for separate archive/five-path delivery mapping.','root':str(ROOT),'evidence_directory':str(HERE),'source_bindings':sm['sources'],'source_manifest':meta(HERE/'SOURCE_MANIFEST_v3.json'),'report':meta(HERE/'REPORT_v1.md'),'manifest':{**meta(HERE/'MANIFEST_v1.json'),'artifact_count':len(files)},'claim_dispositions':meta(HERE/'CLAIM_DISPOSITIONS_v1.json'),'reused_evidence':{'binding':meta(HERE/'REUSED_UNIT_BINDINGS_v1.json'),'units':[{'unit':u['unit'],'receipt':u['receipt'],'manifest_payloads':u['manifest_artifacts'],'source_pairs':u['source_pairs']} for u in prior['units']],'counts_not_rerun':{'FS_original':'125/0','FS_prose':'8/0','FI_original':'80/3','FI_exact_repair':'36/0','FI_correspondence':'10/0','MC_original':'72/0','MC_correspondence':'6/0'}},'new_targeted_execution':{'code':meta(HERE/'check_targeted_v1.py'),'command':meta(HERE/'targeted_baseline_execution_v1.json'),'result':meta(HERE/'targeted_baseline_v1/RESULTS_v1.json'),'counts':target['counts'],'primary_measured_function_counts':target['primary_measured_function_counts'],'primary_function_not_blind_independent_science':True,'ODE_integrations':0},'new_actual_damages':[{'name':'wrong_adjoint','execution':meta(HERE/'wrong_adjoint_execution_v1.json'),'counts':{'passed':38,'failed':1}},{'name':'reversed_inverse_A','execution':meta(HERE/'reversed_inverse_execution_v1.json'),'counts':{'passed':37,'failed':2}}],'initial_evidence_correspondence':{'result':meta(HERE/'EVIDENCE_CORRESPONDENCE_v1.json'),'counts':{'passed':67,'failed':3},'meaning':'Real version drift correctly detected; inaccurate unconditional helper metadata flag also preserved and explicitly corrected.'},'final_source_confirmation':{'result':meta(HERE/'final_source_v2/CORRESPONDENCE_v2.json'),'counts':final['counts'],'source_supersessions':2,'science_rerun':False,'final_cache_header':final['final_cache_header']},'failure_history':meta(HERE/'FAILURES_v1.json'),'binding':meta(HERE/'FINAL_BINDING_CHECK_v1.json'),'limitations':['Supplied action and exact expanding vacuum remain premises.','Cold first-order conserved source about zero background density; not general rolling or finite-density transfer.','Same-mode potential access, nonzero mean and known geometry/time remain experimental premises.','Structural uniqueness does not guarantee chosen-window rank or finite precision.','Measured error envelopes and exact moment relation are supplied; certificate failure is inconclusive.','One reserved moment is necessary only; synthetic data are not empirical validation.','No archive/commit/five-path delivery or current-main integration identity is assessed by this unit.'],'independence':{'producer_access':'Explicitly permitted final-source correspondence; previous independent receipts reused honestly.','prior_seals_modified':False,'parent_science_modified':False,'git_PR_network_runtime_lock_audit_mutations':False,'writes_outside_this_unit':False,'new_agents':False},'seal_policy':'Immutable. Later source or delivery changes require a separate new evidence unit.'};put('RECEIPT_v1.json',receipt)
print(json.dumps({'report':meta(HERE/'REPORT_v1.md'),'receipt':meta(HERE/'RECEIPT_v1.json'),'manifest':meta(HERE/'MANIFEST_v1.json'),'artifact_count':len(files),'source_bindings':len(sm['sources']),'integrity_counts':binding['counts']},indent=2))
