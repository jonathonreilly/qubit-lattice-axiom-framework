from pathlib import Path
import json,subprocess,hashlib,time
from datetime import datetime,timezone
root=Path.cwd();d=Path(__file__).resolve().parent/'damages_v1';protocol=json.loads((d/'PROTOCOL.json').read_text());rows=[]
for change in protocol['changes']:
 name=change['name'];code=d/(name+'.py');out=d/name;out.mkdir(exist_ok=False)
 cmd=['/usr/local/bin/python3','-B',str(code),'--output',str(out/'profiles')]
 record={'started_at':datetime.now(timezone.utc).isoformat(),'command':cmd,'cwd':str(root),'code_sha256':hashlib.sha256(code.read_bytes()).hexdigest(),'timeout_seconds':120}
 (out/'COMMAND.json').write_text(json.dumps(record,indent=2)+'\n')
 t=time.monotonic();r=subprocess.run(cmd,capture_output=True,timeout=120);(out/'stdout.json').write_bytes(r.stdout);(out/'stderr.txt').write_bytes(r.stderr)
 record.update(exit_code=r.returncode,elapsed_seconds=time.monotonic()-t,ended_at=datetime.now(timezone.utc).isoformat(),stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest())
 (out/'EXECUTION.json').write_text(json.dumps(record,indent=2)+'\n')
 result=json.loads(r.stdout);row={'name':name,'exit_code':r.returncode,'counts':result['counts'],'failed_checks':[q['name'] for q in result['checks'] if not q['passed']],'empty_stderr':not r.stderr}
 rows.append(row);print(json.dumps(row),flush=True)
 if r.returncode!=1 or not result['counts']['failed'] or r.stderr:raise RuntimeError('Invalid damage execution '+name)
(d/'SUMMARY.json').write_text(json.dumps(rows,indent=2)+'\n')
