# Finite-mode reconstruction without a scalar preparation rule

Author: /root, personally derived in this campaign. Actual current status:
conditional-support. The supplied action, exact vacuum, dust source, physical
potential access and geometric mode calibration are premises. No observations
have been fitted and no actual initial state is derived.

The previously derived vacuum equation retains arbitrary scalar initial data.
Write g=(Phi_J-Psi_J)/(Phi_J+Psi_J)=k*y for a nonzero matter-sourced Einstein
potential, z=q_comoving/(aH)>0, N=log a, and

    B=4[3(1+k)+nu]/(1-3k), A=B-2,
    y_zz+(1+A/z^2)y=1,
    g_NN+g_N+(z^2+A)g=k*z^2.                    (1)

Here 0<k<1/3,nu>0, H is the constant physical vacuum Hubble rate (C=1).
The potentials refer to the same Fourier mode on the exact homogeneous vacuum,
not automatically to two independently measured astronomical masses. The
conserved dust Fourier density scales as a^-3; its amplitude cancels in the
potential ratio. Other free scalar directions are uncoupled at this order.
Unknown homogeneous solutions of (1) are retained, not set to zero.

## A derivative identity that keeps the unknown wave

Put s=g/z^2 and b=(g_NN+g_N+z^2*g)/z^2. Then b=k-A*s exactly.
Two epochs with distinct s determine k and A even for unknown scalar-wave
amplitude and phase. This is an equation-based identification, not an
assertion that slow source evolution makes the scalar response slow.
Direct differentiation of noisy observed potentials could be poorly conditioned;
the following weak form avoids demanding their pointwise derivatives.

Choose two real nonnegative C^2 weight functions supported in finite N
intervals, with w=w_N=0 at their endpoints. Define

    U_i=integral w_i*g dN,
    V_i=integral w_i*z^2 dN >0,
    L_i=integral (w_i,NN-w_i,N+z^2*w_i)*g dN.

Twice integrating by parts in (1) gives exactly

    L_i+A*U_i=k*V_i.                            (2)

No scalar initial conditions appear because the endpoint terms vanish;
the measured g inside each interval still includes their physical effect.
With D=V_1*U_2-V_2*U_1 nonzero,

    k=(L_1*U_2-L_2*U_1)/D,
    A=(V_2*L_1-V_1*L_2)/D,
    nu=(A+2)*(1-3k)/4-3*(1+k).                 (3)

A third disjoint interval has residual R_3=L_3+A*U_3-k*V_3 without refitting.
A zero residual is a necessary model-consistency condition, not uniqueness
of this action among all theories. A data set can fail the required parameter
domain: 0<k<1/3 and A>(10+18k)/(1-3k), equivalent to nu>0.
The finite-mode observable eliminates Q and source amplitude only within the
specified potential ratio. It does not derive Q, H, absolute units, a cosmic
state, environmental screening or an instrument's transfer function.

## Amplitude-error bound and identifiability limit

Write s_i=U_i/V_i, b_i=L_i/V_i. If known z and real measurements obey
|g_tilde-g|<=epsilon_i throughout interval i, let

    e_s,i=epsilon_i*integral |w_i|/V_i,
    e_b,i=epsilon_i*integral |w_i,NN-w_i,N+z^2*w_i|/V_i.

Then |delta s_i|<=e_s,i and |delta b_i|<=e_b,i. Put
E_s=e_s,1+e_s,2, E_b=e_b,1+e_b,2 and Delta=s_2-s_1. If |Delta|>E_s,

    |A_tilde-A| <= (E_b+|A|*E_s)/(|Delta|-E_s),
    |k_tilde-k| <= e_b,1+|A|*e_s,1
                          +(abs(s_1)+e_s,1)*bound_A.    (4)

These bounds need a defensible uniform measurement-error model; sampling and
quadrature error must be included in that model or separately controlled.
Narrow windows can amplify errors through w_NN. At high z, the tiny values
and separation of g/z^2 can make A and nu practically unidentifiable even
when the algebraic inverse exists. Dense resolution of a rapid free wave
cannot be replaced by a bound on slow source evolution. Errors in z or time
calibration are additional inputs, not silently covered by (4).

## What has and has not been eliminated

Within this linear vacuum experiment, initial wave amplitude and phase are
nuisance data that need not be supplied to (3). They are neither dynamically
selected nor declared absent. This is a route for testing the supplied action
while respecting its free initial data. It remains conditional on actual
access to time-resolved paired potentials, a stationary vacuum environment,
linear weak-source validity and the known mode/time geometry. A successful
synthetic reconstruction is mathematical validation, not an observational
measurement or an empirical test of the theory.
