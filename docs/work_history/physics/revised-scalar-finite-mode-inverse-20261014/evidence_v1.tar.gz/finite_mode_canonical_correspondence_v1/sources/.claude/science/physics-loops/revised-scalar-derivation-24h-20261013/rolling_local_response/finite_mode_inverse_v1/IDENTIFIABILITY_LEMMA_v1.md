# Structural identifiability with arbitrary coupled scalar preparation

Personally derived by /root after the frozen numerical experiment; an added
mathematical lemma, not a retroactive change to its window protocol. Conditional
on the same exact vacuum Fourier experiment and known z=z0 exp(-N)>0.

Suppose a C^2 real (or complex) trace g on an open N interval solves

    g_NN+g_N+(z^2+A)g=k z^2,

where k>0 and A is constant. Then s(N)=g(N)/z(N)^2 cannot be constant
on any nonempty open subinterval. Indeed, if g=c z^2 there, g_N=-2g,
g_NN=4g, so the equation requires k=c(z^2+A+2). Its derivative is
0=-2c z^2. Thus c=0 and then k=0, contrary to the domain.

Consequently, ideal access to the entire continuous trace on any such interval
identifies k and A uniquely. If the identical trace solves equations for two
constant parameter pairs, subtraction gives

    (A_1-A_2)g=(k_1-k_2)z^2.

Unequal A values would make s constant; equal A values require equal k. The
candidate formula then determines nu uniquely. This is uniqueness of constants
inside this supplied differential-equation family. It is not uniqueness of the
physical action, a noise-tolerant reconstruction or access to all scalar modes.

There also exist two disjoint, nonnegative C^2 compact temporal weights within
any such interval with nonzero D=V_1 U_2-V_2 U_1. Choose points where continuous
s differs and sufficiently small disjoint neighborhoods. Normalized bumps
supported there have U_i/V_i equal to positive weighted averages of s, which
remain separated when the neighborhoods are small enough. For complex s choose
neighborhoods of radius less than one quarter the nonzero complex separation.

Existence does not guarantee a preselected pair of windows works, give a
uniform lower bound on D, or make arbitrarily short/poorly sampled observations
informative. The finite fixed-window experiment preserves its measured
conditioning and error bound. The lemma removes a universal mathematical
nonidentifiability due solely to free-wave preparation; it does not remove
measurement error, unknown geometric calibration, environmental departures,
unobserved scalar directions or the supplied action premise.
