# Turn the weighted inverse error bound into a measured-data certificate

Direct scientific author /root. This is an exact algebraic refinement within
the already checked vacuum same-mode family. No new data or observations are
used. It does not change DERIVATION_v3.md or its sealed independent evidence.
The independent review noted that the earlier error bound involves unknown
true quantities. Here those can be replaced by measured quantities directly.

With true b_i=k-A s_i and measured s_hat_i,b_hat_i, suppose defensible
absolute error bounds |s_hat_i-s_i|<=e_si and |b_hat_i-b_i|<=e_bi are given.
These may be built from the earlier uniform potential-ratio error envelope
and compact-weight norms, but that envelope, the known z/time coordinate,
sampling and quadrature control remain supplied measurement premises.
Set Delta_hat=s_hat2-s_hat1, E_s=e_s1+e_s2, E_b=e_b1+e_b2. If
|Delta_hat|>E_s, both measured and true denominators are nonzero. Compute

 A_hat=(b_hat1-b_hat2)/Delta_hat,
 k_hat=b_hat1+A_hat s_hat1.

Write ds_i=s_hat_i-s_i and db_i=b_hat_i-b_i. The exact relation is

 A-A_hat=[-(db1-db2)+A_hat(ds2-ds1)]
                         /[Delta_hat-(ds2-ds1)].

Therefore a certificate written entirely in measured quantities and adopted
error bounds is

 e_A=(E_b+|A_hat|E_s)/(|Delta_hat|-E_s),
 |A-A_hat|<=e_A,
 |k-k_hat|<=e_k=e_b1+|A_hat|e_s1+(|s_hat1|+e_s1)e_A.   (1)

For the supplied mass relation nu=(A+2)(1-3k)/4-3(1+k), compute nu_hat
by the same relation. Expanding about measured values gives the exact
identity

 nu-nu_hat=[(1-3k_hat)(A-A_hat)-3(A_hat+6)(k-k_hat)
                              -3(A-A_hat)(k-k_hat)]/4.

Thus

 e_nu=[|1-3k_hat|e_A+3|A_hat+6|e_k+3e_A e_k]/4         (2)

bounds the error in nu. Sufficient certified physical-domain conditions are
k_hat-e_k>0, k_hat+e_k<1/3 and nu_hat-e_nu>0. Failure of one condition
means this certificate is inconclusive; it is not proof that the model is
excluded. The potentially severe denominator/noise limitation survives.
Neither interval nor rank margin is an observed value in this campaign.

Use the third reserved moment only as a necessary no-refit check. A nonzero
moment-null deviation can escape that single check, as the sealed independent
counterexample already shows. This certificate does not select an action,
actual initial state or calibrated environment.
