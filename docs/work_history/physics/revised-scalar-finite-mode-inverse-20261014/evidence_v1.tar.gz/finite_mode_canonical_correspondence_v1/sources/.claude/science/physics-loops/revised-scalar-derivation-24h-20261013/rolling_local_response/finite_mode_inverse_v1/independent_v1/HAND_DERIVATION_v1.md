# Independent derivation before the finite-mode inverse checker

Author /root; checker /root/scalar_energy_check. This hand derivation and the companion protocol precede the independent executable. The prior finite-scale receipt is reused by exact hash, without changing it or re-running its science. No producer checker or output file has been read.

The sealed mode equation is y_zz+(1+A/z^2)y=1, A=4[3(1+k)+nu]/(1-3k)-2. The source mean potential is Phi0 proportional to exp(-N), z=z0 exp(-N), and g=(PhiJ-PsiJ)/(PhiJ+PsiJ)=k y. Since d_N=-z d_z, g_NN+g_N=z^2 g_zz. Thus g_NN+g_N+(z^2+A)g=k z^2 exactly, including any homogeneous solution. This is the same-mode linear vacuum equation; it does not assert a fixed-radius force measurement.

For a real compact weight w with w=w_N=0 at the ends, integration by parts gives

    integral w(g_NN+g_N) = integral (w_NN-w_N)g
       + [w g_N-w_N g+w g]_ends.

The boundary term vanishes, independently of g and g_N at the ends. Therefore L+A U=k V with U=integral w g, V=integral w z^2>0 and L=integral (w_NN-w_N+z^2 w)g. A nontrivial nonnegative weight and positive known z ensure V>0. The proof uses measured amplitudes in the interval, not derivatives of those amplitudes. Known derivatives of a selected weight replace data derivatives. C^2 weights suffice; the numerical protocol uses polynomial bumps with at least cubic zeros and zero extension.

Writing s=U/V and b=L/V gives b=k-A s. With Delta=s2-s1 nonzero,

    A=(b1-b2)/Delta,
    k=b1+A s1.

Equivalently D=V1 U2-V2 U1, k=(L1 U2-L2 U1)/D and A=(V2 L1-V1 L2)/D. These are the source's signs. The source's nu inversion is also correct:

    nu=(A+2)(1-3k)/4-3(1+k).

However its v1 domain statement contains an arithmetic error. Expanding gives 4nu=A(1-3k)-10-18k, so with 0<k<1/3 the correct threshold is A>(10+18k)/(1-3k). The printed 42 would impose nu>6k, not merely nu>0. It excludes the valid k=2/17,nu=3/5,A=1234/55 example and the independent k=3/25,nu=2/7,A=291/14 example. This finding was sent to the author before code. Original v1 remains the first executed target; its incorrect domain check will be retained as an actual failure rather than silently repaired.

Unknown initial scalar amplitude and phase are not supplied to these two equations. Their effects remain in g, U and L. They can make D zero or small for fixed windows. For one particular trajectory gp and an arbitrary homogeneous contribution h, Delta(gp+t h)=Delta_p+t Delta_h. If Delta_h is nonzero, t=-Delta_p/Delta_h produces an actual allowed trajectory for which those two fixed weights have D=0. This does not contradict generic reconstruction or identification from a full trace; it disproves any state-independent rank or conditioning guarantee for fixed weights.

There is an additional source-amplitude distinction. With an absolute free canonical scalar wave h held fixed, chi=chi_p+h and Phi0 is proportional to source amplitude. Hence g=sqrt(k)chi/Phi0=gp+sqrt(k)h/Phi0 depends on the source amplitude. Rescaling that amplitude by f while keeping h fixed gives g_f=gp+(g-gp)/f. It is the explicit amplitude in the closed differential equation and inverse that cancels, not every ratio under that physical source change. Source strength and preparation are folded into the nuisance solution. This narrow wording correction was also sent to the author.

For deterministic amplitude errors delta g with |delta g|<=epsilon on a window, direct integral bounds give |delta s|<=epsilon integral |w|/V and |delta b|<=epsilon integral |w_NN-w_N+z^2 w|/V. Let Es=es1+es2, Eb=eb1+eb2 and eta=delta s2-delta s1. The exact perturbation identity is

    Atilde-A = [delta b1-delta b2-A eta]/[Delta+eta].

If |Delta|>Es this gives the stated A bound. Since ktilde-k=delta b1+A delta s1+(s1+delta s1)(Atilde-A), the stated k bound follows. The formula is a true-parameter bound: A, s1 and Delta themselves require trustworthy bounds or a conservative data-based reformulation before it becomes an operational uncertainty certificate. Known z and time calibration are essential. Uniform amplitude error must include unresolved sampling/quadrature effects or those require separate budgets. In particular a small field amplitude or slowly varying source does not bound the rapid scalar phase.

For a third window, R3 is the weighted moment of the differential-equation residual at parameters fitted only from the first two windows. It is a necessary consistency condition. One scalar moment cannot establish the whole differential equation: nonzero smooth deviations orthogonal to its adjoint kernel remain invisible. The controls will include both a detectable compact third-window change and a separately constructed moment-null compact change. These are disclosed synthetic development controls, not a blind or empirical test.

The ratio requires phase-consistent same-mode signed potentials and a nonzero sourced mean. Arbitrary Fourier modes can be complex. The exact algebra extends to complex g with real k,A, but one must retain phasors (or a justified real projection), not replace them by magnitudes. The displayed deterministic error proof is valid in its stated real setting and also extends using complex moduli. Identification of k and nu requires geometric z and the correct vacuum/source/linear-response model; it does not calibrate Q, H, a real instrument or a cosmological state.

The following independent controls generate observables by integrating the canonically normalized field chi, not the inverse equation:

    chi_NN+3chi_N+(z^2+B)chi=sqrt(k) z^2 Phi0,
    Phi0=-eta exp(-N),
    PhiJ=Phi0+sqrt(k)chi, PsiJ=Phi0-sqrt(k)chi.

They use k=3/25,nu=2/7,z0=37 and several specified initial waves and source amplitudes. Compact asymmetric weights and windows differ from the producer's disclosed protocol. Two numerical methods and quadrature refinement control numerical implementation, not observational validity or rigorous solver enclosures.
