# Independent check of the added identifiability lemma

The complete IDENTIFIABILITY_LEMMA_v1.md was read after freezing the numerical protocol, before the executable checker. It does not change that protocol.

For a C^2 real or complex trace on any open interval with z=z0 exp(-N)>0, suppose g/z^2=c on an open subinterval. Substitution gives k=c(z^2+A+2). The equality is differentiable even if only C^2 was assumed initially, since its right side has this explicit smooth form. Differentiation gives 0=-2c z^2, hence c=0 and then k=0. This contradicts k>0. Thus s is nonconstant on every nonempty open subinterval.

Two constant pairs producing the identical full trace satisfy (A1-A2)s=k1-k2. If A1 differs from A2, this contradicts the preceding fact. If A1=A2, then k1=k2. The candidate formula then fixes nu. This is structural identification inside the stipulated known-z equation family, not identification of the action among all theories, or identification of parameters from finitely sampled/noisy data.

Continuity gives two points in any open interval with distinct s values. Choose disjoint sufficiently small neighborhoods inside the interval so all s values in each lie within one quarter of the separation from its center. Nontrivial nonnegative compact C^2 bumps exist on those neighborhoods. U/V is the weighted average of s with positive weight w z^2, hence the two means remain separated. For complex s this is a disk/triangle-inequality statement; no ordering of complex numbers is required. Therefore D is nonzero for some pair of such weights.

This is an existence statement dependent on the trace, not a lower bound on the determinant or a guarantee for prespecified weights. The frozen numerical fixed-window degeneracy construction is compatible with it. Choosing windows after examining a trace also does not convert the already exposed synthetic third-window controls into an empirical prospective test. No correction to the lemma's stated quantifiers is needed.
