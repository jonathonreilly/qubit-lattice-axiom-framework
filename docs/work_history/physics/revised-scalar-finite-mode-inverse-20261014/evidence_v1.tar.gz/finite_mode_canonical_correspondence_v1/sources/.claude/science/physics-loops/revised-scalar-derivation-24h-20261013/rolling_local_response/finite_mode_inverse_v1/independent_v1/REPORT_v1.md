# Independent finite-mode inverse check

Scientific author: /root. Independent checker: /root/scalar_energy_check.

The weak identity, inverse signs, deterministic amplitude-error inequalities and added full-trace identifiability lemma are valid within the specified linear conserved-vacuum Fourier experiment. The original source had one mathematical domain error and one source-amplitude wording error. Both were reported from the independent derivation and are corrected in preserved v2/v3 sources. The original failing execution remains intact.

The correct physical domain is 0<k<1/3 and A>(10+18k)/(1-3k), equivalent to nu>0. Unknown scalar preparation is absent from the parameter equations but remains in the measured trace and can make a chosen pair of weights singular or poorly conditioned. The explicit source amplitude cancels from the closed equation and inverse; a potential ratio containing a fixed absolute free wave still changes when the source amplitude changes. A third weighted residual is a necessary consistency test, not a verification of the entire differential equation or the action.

This is a bounded mathematical check. It does not provide an experiment, observed-gravity completion, selected scalar initial state, full cosmological history or formal audit.

## Sources, independence and reused evidence

The complete initial derivation and parent protocol were read. The sealed finite-scale mode equation and its independent evidence were reused by exact identity. All 62 artifacts in that earlier manifest were rehashed, and its receipt, report and manifest were snapshotted without modification.

| Source | SHA256 |
| --- | --- |
| finite_mode_inverse_v1/DERIVATION_v1.md | cb9fded79347f6cf0c5883a8db491f7503306cc98f651e0d6a981bdc15bbf386 |
| finite_mode_inverse_v1/PROTOCOL_v1.json | 68ff4854405d77b1de981f4d30bc039c4afabdef31c191fd5f5ba1eed284878d |
| finite_scale_v1/VACUUM_MODE_DERIVATION_v2.md | ece0785dd08f0ab6a8c5ac37d97486b37d2a47b149c094069a86ae8103c468a7 |
| Prior independent finite-scale receipt | ca9058d51ea21fd9b23225fc836a7ddae4584e0d106189ec6c79b025198ec2d3 |
| Corrected finite-mode DERIVATION_v3.md | 0c86a7121f5211ff781f415b3bbd5ea5000c368708f217533860ed9656a7bccd |
| IDENTIFIABILITY_LEMMA_v1.md | 1a3d609addc8e3d006a5a8d1f0f0637ec82e40824bdfdc2ea0af39d74d621cf9 |

Paths above are within the campaign's rolling_local_response directory except the descriptive receipt label. SOURCE_MANIFEST_v1.json and SOURCE_CORRESPONDENCE_v2_v3.json give exact live/snapshot paths, sizes and hashes. Full revised derivations and the added lemma were read.

HAND_DERIVATION_v1.md and the independently chosen PROTOCOL_v1.json were saved before the executable. IDENTIFIABILITY_HAND_ADDENDUM_v1.md records the added lemma check before execution without changing the numerical protocol. The original independent checker has SHA256 9010a06222f069ab2021af00496eaa8eab0976a2856d0c9c5a02935fbaad708c.

No producer checker or result file was loaded, imported or executed. The parent disclosed outcomes in messages. After constructing and running the independent original-source checker, the source-correction metadata was read; it contains a short producer checker diff and reported counts. Those disclosures were not used as evidence or an oracle. The source-correction metadata is preserved with that distinction. All actual controls below belong to this independent checker.

## Weak identity and inverse

The reused exact equation is y_zz+(1+A/z^2)y=1, with g=k y and z=z0 exp(-N)>0. Since d_N=-z d_z, g_NN+g_N=z^2 g_zz. This yields

    g_NN+g_N+(z^2+A)g=k z^2.

The independent data generator goes one step back: it integrates the coupled canonical field equation

    chi_NN+3chi_N+(z^2+B)chi=sqrt(k) z^2 Phi0,
    Phi0=-eta exp(-N),  B=A+2,

then constructs PhiJ=Phi0+sqrt(k)chi and PsiJ=Phi0-sqrt(k)chi before taking the ratio. It does not generate data by calling the inverse or its differential equation.

The integration-by-parts identity is

    integral w(g_NN+g_N)
      = integral (w_NN-w_N)g + [w g_N-w_N g+w g]_ends.

Both endpoint values w and w_N must vanish. A C^2 nontrivial nonnegative compact weight and known positive z give V=integral w z^2>0. Therefore L+A U=k V, with exactly the stated L and U. The minus sign before w_N is essential. No scalar boundary value is supplied: the measured interior trace still contains the unknown homogeneous solution.

Let s_i=U_i/V_i and b_i=L_i/V_i. Then b_i=k-A s_i. When Delta=s2-s1 is nonzero,

    A=(b1-b2)/Delta,  k=b1+A s1.

These expressions reproduce both printed determinant formulas with D=V1 U2-V2 U1. The mass inverse nu=(A+2)(1-3k)/4-3(1+k) is correct. The +2 comes from the physical-clock/Phi0 reduction of the canonical scalar equation; deleting it changes the inferred nu.

The source v1 domain threshold was not equivalent to that inverse. Exactly,

    4nu=A(1-3k)-10-18k.

The v1 threshold (10+42k)/(1-3k) would instead require nu>6k. Its boundary has nu=6k rather than zero. It wrongly rejects both the disclosed k=2/17,nu=3/5,A=1234/55 example and the independent k=3/25,nu=2/7,A=291/14 example. This was identified before producer access or independent computation. The first actual run deliberately evaluates the original claim and retains all three resulting failed records.

## Conditioning and preparation

For known z and a defensible uniform amplitude error |delta g|<=epsilon_i, the stated e_s,i and e_b,i follow directly from integral norms. Put eta_s=delta s2-delta s1. The exact identity

    Atilde-A=[delta b1-delta b2-A eta_s]/[Delta+eta_s]

proves the A bound whenever |Delta|>E_s. The exact k error is

    ktilde-k=delta b1+A delta s1+(s1+delta s1)(Atilde-A),

which proves the source's k bound. Sixteen exact rational error-box corner controls and the symbolic perturbation identities agree.

This is a bound involving true A, s1 and Delta. An operational uncertainty calculation needs trustworthy bounds for those quantities, or a conservative reformulation in measured quantities. The source does not claim that they are automatically known. Error in z, the time coordinate, sampling, unresolved oscillations, quadrature, the potential-ratio denominator or the instrument response is not included merely by specifying an amplitude epsilon. A uniform bound on the ratio itself can be difficult when the sourced mean potential is small. Narrow windows move differentiation to a sharply varying weight and can amplify noise.

No initial wave amplitude or phase appears as an input to the inverse. That is an elimination of nuisance parameters through the equation, not their physical selection. A fixed pair of weights still needs D!=0 and a usable noise margin. For an allowed particular trace gp and homogeneous trace h, Delta(gp+t h)=Delta_p+t Delta_h. Whenever Delta_h!=0, t=-Delta_p/Delta_h gives rank loss for that chosen pair. The numerical control evaluates this exact linear construction for the frozen weights; it does not prove that every possible fixed pair must fail.

The source-amplitude clarification is also necessary. With chi=chi_particular+h and h held fixed, rescaling the matter-source amplitude by f changes the ratio to

    g_f=g_particular+(g-g_particular)/f.

The inverse still needs no explicit source-strength input, but the trace need not be invariant. Universal matter coupling, the exact constant-field vacuum, a conserved source and absence of first-order scalar-excitation stress are reused premises. They do not establish environmental applicability.

The potentials must be the same mode with controlled sign and relative phase, and their sourced mean must be nonzero. For a complex Fourier mode the algebra extends to complex amplitudes with real physical parameters, but taking magnitudes instead of the complex ratio is a different operation. A justified real component is enough in the source's stated real-error setting. These ideal inputs are not supplied by two independently estimated astronomical masses.

## Added identifiability lemma

The added lemma is correct with its stated quantifiers. If g/z^2=c on an open subinterval, the equation gives k=c(z^2+A+2). Differentiation yields 0=-2c z^2. Since z>0, c=0 and then k=0, contradicting k>0. This argument works for real or complex c.

If a complete trace solves the equation for two constant parameter pairs, subtraction gives (A1-A2)g=(k1-k2)z^2. Unequal A would make g/z^2 constant; equal A forces equal k. The candidate mass relation then fixes nu. Thus full noiseless continuous data on any open interval are structurally identifying inside this known-z differential-equation family.

Continuity supplies two points with distinct s=g/z^2. Small disjoint neighborhoods keep their s values separated. Positive compact C^2 bumps supported there give U/V as positive weighted averages of s with weight w z^2; those averages remain separated. For complex s, the same statement uses disks and the triangle inequality. This proves existence of separating weights. It does not guarantee the predetermined windows used in a particular experiment, any uniform lower bound on D, usable sampling or a noise-tolerant reconstruction. The fixed-window rank-loss control is compatible with the lemma.

## Actual independent execution

The first original-source execution finished **80 passed / 3 failed** out of 83 records. The only failures are the symbolic incorrect-domain boundary and the two exact valid counterexamples above. All eight numerical solver runs, inverse checks and separate scope controls passed. There were no runtime exceptions, timeouts or warnings.

The independent parameters are k=3/25, nu=2/7, B=319/14, A=291/14, z0=37, N from 0 to 1.38, and reference Phi0 amplitude eta=3/100000. The solver uses chi/eta as a constant numerical normalization; it restores the physical potentials before taking their ratio. The same reference eta is used across source-strength changes, so the held absolute free field is well defined.

The frozen weights are w=normalization*s^p*(1-s)^q/T inside their support and zero outside:

| Role | N interval | p, q | Normalization |
| --- | --- | --- | --- |
| Fit 1 | .07 to .35 | 3, 4 | 280 |
| Fit 2 | .47 to .83 | 4, 3 | 280 |
| Reserved 3 | 1.02 to 1.34 | 4, 4 | 630 |

These weights are normalized, nonnegative and at least C^2 under zero extension. Their endpoint values and first two derivatives were checked exactly. The windows and weights were not retuned after results.

Four preparations/source choices were each integrated with DOP853 and Radau: y0=7/6,y_z0=-2/25; y0=-1/4,y_z0=3/50; a particular reference y0=1,y_z0=0; and source strength multiplied by 5/3 with the first case's absolute free field relative to that particular solution fixed.

DOP853 used rtol=2e-12, atol=3e-14, max_step=.003. Radau used rtol=1e-11, atol=2e-13, max_step=.003. All 801 output sites, physical potentials and field states are retained in eight CSV files. Weighted integrals were computed from those dense field solutions without taking data derivatives. Baseline and refined quadrature settings, all 128 quadrature calls and their reported error estimates are preserved. Cross-method comparison and quadrature refinement passed the predeclared implementation criteria. These are diagnostics, not rigorous interval enclosures or observational thresholds.

All eight preparations/methods recovered k=.12, A=20.7857142857 and nu=.2857142857. The largest A deviation among them was approximately 5.4e-10. The largest magnitude of the scaled reserved residual was approximately 9.47e-13. Parameters were fitted only with the first two windows.

Distinct controls give concrete limits:

- Multiplying source strength by 5/3 with the absolute free field fixed changed g by up to .00886130. The exact scaling relation held numerically to about 2.64e-16, while k and nu were unchanged within solver accuracy.
- The constructed homogeneous coefficient t=-17.8179543 made the frozen-window Delta approximately -2.93e-18 and D approximately -9.88e-13. No inverse was attempted there. The full sampled s trace still ranged over .00728, and all three equation moments remained within about 4e-13. This uses exact solution-space superposition with a numerically evaluated coefficient, not a rigorous quadrature enclosure.
- Deterministic bounded amplitude perturbations of 1e-7 and 2e-7 in the first two windows gave an A error about .00031514 versus its bound .00156304, and a k error about 1.73e-8 versus its bound 3.14e-7. The rank margin was Delta=.000200733 versus E_s=6.62e-10.
- A fixed compact third-window change of amplitude at most 1e-5 changed the reserved residual by approximately -.00028997 with no parameter refit.
- A separate deliberately constructed compact nonzero change, with maximum amplitude about 1.12e-6, had a weighted residual change about -1.36e-20. Its zero endpoint value/derivative and nonzero interior prevent it from being a homogeneous ODE solution. This confirms that one third-window moment is only necessary. It is a disclosed synthetic counterexample, not hidden or empirical data.

## Repair history, actual damaged formulas and final correspondence

The original independent script, 80/3 results, logs and all numerical trajectories are unchanged. A separate copy changes only SOURCE_DOMAIN_COEFFICIENT from 42 to 18 and was executed in exact-only mode: **36/0**. This is not an 83/0 rerun; the unchanged numerical results are reused from their original execution.

Four further actual altered copies of that repaired independent checker were run in exact-only mode. Each exits 1 through its intended mathematical witness:

| Alteration | Passed / failed | Witness |
| --- | --- | --- |
| Reverse adjoint first-derivative sign | 34 / 2 | Exact integration-by-parts identity |
| Reverse A inverse numerator | 34 / 2 | A recovery and intercept consistency |
| Omit +2 in nu reconstruction | 35 / 1 | Actual mass/clock inverse |
| Omit A times the s-error in conditioning numerator | 35 / 1 | Exact perturbed-ratio identity |

Every altered source, diff, command, output and failure list is preserved. No numerical trajectories were rerun for those negative copies. FAILURES_v1.json retains the original material failures, the separate repair and all intentional damaged runs.

The complete v2 and v3 source correspondence has **10/0** checks. V1 to v2 changes only 42k to 18k in the domain inequality. V2 to v3 changes exactly two prose spans about source amplitude; no equation, inverse, weight or original protocol changes. The metadata's preserved source diffs equal independently generated diffs byte for byte. Original sources and prior finite-scale evidence remain unchanged. The new lemma has its own snapshot and handwritten proof; it did not change the fixed-window experiment.

The final revised-source hashes are:

| Source | SHA256 |
| --- | --- |
| DERIVATION_v2.md | 26ed2cf2b0508bea6dd53fe3c955c6e79aabea41d541423192e4731e6a3b61fb |
| DERIVATION_v3.md | 0c86a7121f5211ff781f415b3bbd5ea5000c368708f217533860ed9656a7bccd |
| IDENTIFIABILITY_LEMMA_v1.md | 1a3d609addc8e3d006a5a8d1f0f0637ec82e40824bdfdc2ea0af39d74d621cf9 |

Within these corrected premises, the inverse can identify k and nu without separately specifying the coupled scalar's initial amplitude and phase when the measured moments have adequate rank. It cannot guarantee that rank for a chosen pair, supply a uniform precision floor, derive the geometry or potential access, choose an initial state, or validate an action from one reserved scalar moment. All science authorship remains with /root. No parent/science, prior receipt, git, PR, network, runtime, lock or audit state was changed.
