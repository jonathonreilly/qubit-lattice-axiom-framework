# Independent measured-certificate derivation before executable

Scientific author /root; focused checker /root/scalar_energy_check. Only the new hand source and its protocol are used. No producer code/results or earlier inverse trajectories are read or rerun.

The premise is a real exact pair b_i=k-A s_i, with real measured pairs sh_i,bh_i and finite nonnegative deterministic adopted bounds |ds_i|<=es_i, |db_i|<=eb_i. Here ds_i=sh_i-s_i and db_i=bh_i-b_i. No independence of these errors is assumed; their correlations can make the certificate conservative.

Put Dh=sh2-sh1, d=ds2-ds1, B=bh1-bh2, e_s=es1+es2 and e_b=eb1+eb2. The true denominator is D=Dh-d. Hence

    |D| >= |Dh|-|d| >= |Dh|-e_s.

If |Dh|>e_s, then D and Dh are both nonzero and have the same sign. This strict inequality is sufficient. Equality is not sufficient because d=Dh is then allowed. It is a guard, not a numerical observation.

The measured 2 by 2 solve of bh_i=kh-Ah sh_i yields Ah=B/Dh and kh=bh1+Ah sh1. The true relation B=A(Dh-d)+(db1-db2) gives, without division by A,

    A-Ah = [Ah d-(db1-db2)]/[Dh-d].

Its absolute value is at most (e_b+|Ah|e_s)/(|Dh|-e_s). The unknown true A has disappeared from the bound; the adopted error bounds remain premises.

For k, first use the true first equation, not a differential approximation:

    k-kh=-db1+A(sh1-ds1)-Ah sh1
         =-db1-Ah ds1+(A-Ah)(sh1-ds1).

Thus

    |k-kh| <= eb1+|Ah|es1+(|sh1|+es1)e_A.

The term es1*e_A is required by this triangle-bound argument. One can also use the second row and take the minimum of the two valid bounds, but that optional optimization is not part of the checked source and is not needed for its validity.

Write nu(A,k)=(A+2)(1-3k)/4-3(1+k)
              =(A-10-3k(A+6))/4.
For dA=A-Ah and dk=k-kh, exact polynomial expansion gives

    4(nu-nuh)=(1-3kh)dA-3(Ah+6)dk-3 dA dk.

No small-error approximation has been made. Consequently

    e_nu=[|1-3kh|e_A+3|Ah+6|e_k+3e_A e_k]/4

is a valid deterministic absolute bound. The mixed product is retained.

If kh-e_k>0, kh+e_k<1/3 and nuh-e_nu>0, then every true pair satisfying the premises has 0<k<1/3 and nu>0. These are sufficient conditions only. Failure can occur with a perfectly physical true pair because error bars are conservative or the denominator margin is small. A strict boundary cannot be certified by a non-strict equality. The inverse/error algebra remains meaningful outside this physical region, but physical interpretation must respect the domain separately.

The bound is an algebraic implication conditional on the true moment relation and adopted error envelopes. It does not establish that the measured quantities were obtained from that model, nor justify their envelopes, known z/time coordinate, ratio reconstruction, sampling or quadrature. Real scalar parameters and real moment conventions are implicit in the ordered physical-domain statement. A complex-mode analysis requires extracting consistent real moments or a corresponding real system first. This is consistent with the earlier real weighted inverse.

Distinct exact controls will use k=2/17, nu=5/6, which imply A=788/33, s1=-3/40 and s2=7/60, then reverse the two s values. Unequal error bounds es1=1/5000, es2=1/7000, eb1=1/4000 and eb2=1/6000 yield 16 signed corners for each orientation. These are synthetic algebraic moment tuples, not asserted ODE trajectories or measured windows.

Additional tests cover zero errors, negative or zero measured Ah, strict-margin equality/below-margin counterexamples, margin blow-up, and physical truths near each domain boundary whose certificates can be inconclusive.

An exact attained e_A control uses the same physical k,A, true s1=1/20,s2=1/10, ds1=-1/80,ds2=1/80, db1=db2=0. Then Dh=3/40, e_s=1/40, Ah=2A/3, and |A-Ah|=A/3 equals e_A. Omitting e_s from the denominator gives only 2A/9 and is false. The damaged implementation must actually reject this bound; no producer output will be used as an oracle.

At the guard boundary, take measured sh1=0, sh2=1 and es1=es2=1/2. True s1=s2=1/2 is allowed. With bh1=bh2=-10 and zero b errors, both physical pairs k=1/20,A=201/10 and k=1/10,A=101/5 satisfy the same true moments. Thus no two-point identification follows at equality. The strict guard is essential.

The reserved third moment is still only a necessary no-refit consistency test. This algebra supplies no new completeness theorem for it and no initial-state or environmental selection.
