# Independent measured-error certificate check

The measured-data denominator margin and all three error bounds are correct under their stated deterministic error and moment-model premises. No algebraic sign or coefficient correction was needed. The one source qualification concerns ordered physical-domain conditions: v1 left the real-estimate premise implicit. Preserved v2 explicitly uses a consistent real-trace reconstruction and correctly states the real-part alternative for complex estimates of real parameters.

Scientific authorship remains /root. This is a focused check of the new algebraic extension, with no formal audit grade. No producer checker/results were read, imported or run. Neither the previous inverse nor the fluid check was reviewed or rerun, and their evidence remains untouched by this work. All new writes are confined to measured_certificate_independent_v1. No empirical data, git/PR/runtime/lock or parent science source was changed.

The original new source and protocol were read fully, snapshotted, and used to write HAND_DERIVATION_v1.md and PROTOCOL_v1.json before implementation. The real/complex premise gap was reported before sealing. After the parent supplied v2, its complete text was read and frozen; PROTOCOL_COMPLEX_ADDENDUM_v1.json was also saved before executable construction. The single baseline execution therefore covers the original algebra and the narrow v2 clarification. It is not a relabelled producer run or a rerun of the previous inverse.

| Frozen mathematical source | SHA-256 |
| --- | --- |
| sources/MEASURED_ERROR_CERTIFICATE_v1.md | 5c11511c622e78a87d795c03fb9d6cca43030f94129ece315c927e8cd68dd639 |
| sources/MEASURED_CERTIFICATE_PROTOCOL_v1.json | d29e8d754b7d0233a702edd06e68332944513ca8ef5ae23c1230fcd22463cd59 |
| sources/MEASURED_ERROR_CERTIFICATE_v2.md | baab54939ec02396bc65bbf37ac008e6aea75c75865b808980aec6b1cdde83b3 |

SOURCE_MANIFEST_v1.json preserves the original two bindings. SOURCE_MANIFEST_v2.json adds v2 as a third binding. The exact original repo-relative paths and sizes are recorded there. The live files and snapshots all agree at sealing.

Take the real true moment equations b_i=k-A s_i and the measured values sh_i,bh_i. Define ds_i=sh_i-s_i and db_i=bh_i-b_i, with supplied finite nonnegative deterministic bounds |ds_i|<=es_i and |db_i|<=eb_i. These are bounds, not automatically independent random errors or measured standard deviations. Correlation is allowed and can make the rectangular bound conservative.

Let

    Dh=sh2-sh1, d=ds2-ds1,
    E_s=es1+es2, E_b=eb1+eb2.

The true difference is D=Dh-d. By the reverse triangle inequality,

    |D| >= |Dh|-|d| >= |Dh|-E_s.

Thus |Dh|>E_s makes both measured and true denominators nonzero. For real data their signs also agree. The strict margin matters: equality permits zero true rank. For complex data the nonzero-denominator conclusion remains valid, without a notion of denominator sign.

Independently invert the two-by-two system with rows [1,-sh_i]. It yields

    Ah=(bh1-bh2)/Dh,
    kh=bh1+Ah sh1.

The true model implies bh1-bh2=A(Dh-d)+(db1-db2). Rearranging the exact equation, without expanding in small errors or dividing by A, gives

    A-Ah=[Ah d-(db1-db2)]/[Dh-d].

Applying the two triangle inequalities gives exactly

    e_A=(E_b+|Ah|E_s)/(|Dh|-E_s),
    |A-Ah|<=e_A.

All quantities on the right are measured estimates or adopted error bounds. Unknown true A is absent. This removes that algebraic circularity; it does not supply the measurement envelope or establish its coverage.

Use the first true row to reconstruct k:

    k-kh=-db1-Ah ds1+(A-Ah)(sh1-ds1).

Consequently

    e_k=eb1+|Ah|es1+(|sh1|+es1)e_A

is a valid upper bound on |k-kh|. Both the absolute value on sh1 and the es1*e_A product are retained. No sign assumptions on Ah or sh1 are needed. A second-row version could be used for optional tightening, but the source's stated first-row bound is already valid and was the one checked.

For the supplied mass relation,

    nu(A,k)=(A+2)(1-3k)/4-3(1+k)
            =[A-10-3k(A+6)]/4,

put dA=A-Ah and dk=k-kh. Exact polynomial expansion gives

    4(nu-nuh)=(1-3kh)dA-3(Ah+6)dk-3dA dk.

The coefficient Ah+6 and the minus sign of the mixed term are correct. The expansion is exact; there is no small-error truncation. A triangle bound then gives

    e_nu=[|1-3kh|e_A+3|Ah+6|e_k+3e_A e_k]/4.

The mixed product remains essential to this stated nonlinear bound. The true error pair (dA,dk) is generally correlated, so this bound need not be sharp.

For real estimates, the strict inequalities kh-e_k>0, kh+e_k<1/3 and nuh-e_nu>0 imply 0<k<1/3 and nu>0 for every true parameter pair satisfying the model and adopted envelopes. These conditions are sufficient, not necessary. They cannot certify an open-domain boundary from equality and their failure does not exclude a physical truth. They also do not prove that the data obey the assumed moment model.

The exact error identities and modulus bounds extend to complex moment errors. For real true k,nu, the facts |k-kh|<=e_k and |nu-nuh|<=e_nu imply the corresponding real-part bounds. The sufficient tests then use Re(kh) and Re(nuh). Arbitrary complex numbers cannot be directly ordered by the v1 inequalities.

An exact common imaginary measurement error demonstrates the distinction. With true k=2/17, nu=5/6, A=788/33, s=(-3/40,7/60), ds=(0,0) and db=(i/1000000,i/1000000), the fit gives

    Ah=788/33,
    kh=2/17+i/1000000,
    nuh=5/6-493i/22000000.

The original ordered expressions require a real-estimate restriction, while all absolute error bounds pass and the projected real-part domain conditions are positive. The source's six-line v2 insertion states exactly this distinction. SOURCE_CORRESPONDENCE_v2.json verifies that it is the only insertion and that deleting it reproduces v1 byte-for-byte. All original equations and bounds are unchanged. There are six passing correspondence checks; they are separate from the 72 mathematical checks.

The independent executable uses an exact symbolic two-by-two matrix inverse and exact rational arithmetic, with no finite differences or floating tolerance. Its first and only baseline run passed 72 checks with zero failures using Python 3.12.8 and SymPy 1.14.0. There were no unexpected execution errors. The executed code, argument vector, timestamps, exit status, stdout/stderr and full result object are preserved under baseline_v1.

The main distinct rational truth is

    k=2/17, nu=5/6, A=788/33,
    s1=-3/40, s2=7/60,
    es1=1/5000, es2=1/7000,
    eb1=1/4000, eb2=1/6000.

All sixteen signed ds/db corners were checked, and then all sixteen were checked with the s values reversed. Every one of the 32 corners obeys all three absolute error bounds and certifies the physical domain. This checks both denominator orientations and unequal error bounds. The suite also includes exactly zero errors and negative or zero measured Ah, so no unspoken positivity or division by Ah is used.

These values are synthetic algebraic moment tuples. This check does not assert that they are new solved vacuum trajectories, realizable particular fixed windows, or measured observations. The analytical proof establishes the conditional bounds; the exact corners and mutations probe the implementation and signs.

Several exact boundary controls distinguish validity from conclusiveness:

- At true k=1/500, nu=1 and zero actual errors, the adopted eb1=1/500 gives kh-e_k=0. The physical truth is not excluded; the sufficient lower-domain test is inconclusive.
- At true k=1/3-1/1000, nu=1 and zero actual errors, eb1=1/1000 gives kh+e_k=1/3. The strict upper-domain test is inconclusive despite physical true k.
- At true k=1/9, nu=1/1000000 and zero actual errors, adopted eb1=eb2=1/100000 preserve both k margins while the nu margin fails. This is another physical truth with an inconclusive certificate.
- Exactly k=0, k=1/3 or nu=0 with zero error is correctly not certified as belonging to the strict physical interior.

For a sharp rank-guard control, take measured sh=(0,1), bh=(-10,-10) and es1=es2=1/2, eb1=eb2=0. The equality |Dh|=E_s allows true s=(1/2,1/2), whose denominator is zero. Both k=1/20,A=201/10,nu=1237/800 and k=1/10,A=101/5,nu=117/200 satisfy these same true moment tuples and lie in the physical parameter domain. This is an algebraic two-moment ambiguity; it is not a claim that their complete continuous traces agree. The equality and below-margin guards are correctly rejected.

A measured near-rank sequence also exposes conditioning. Fix sh=(0,1), bh=(0,-2), Ah=2, E_b=0 and E_s=1-epsilon. The analytic bound is exactly 2(1-epsilon)/epsilon and diverges as epsilon approaches zero from above. At epsilon=1/10,1/100,1/1000 the exact certificates are 18,198,1998. The displayed analytic formula proves the divergence; three sampled values alone would not do so. No physical-family or observed-noise claim is attached to this conditioning example.

The actual changed-bound control was a separate source file made by the single replacement DENOMINATOR_MARGIN=1 to zero, which changes only the denominator of e_A from |Dh|-E_s to |Dh|. It was executed and exited one with 65 checks passing and seven failing, without an exception. The intended failed witness was sharp.physical_truth_A_error; two of the small-error-box corners also fail.

The sharp witness retains a physical true parameter pair k=2/17, nu=5/6, A=788/33 and uses

    true s=(1/20,1/10),
    ds=(-1/80,1/80), db=(0,0).

It gives Dh=3/40, E_s=1/40, Ah=2A/3 and

    |A-Ah|=788/99,
    correct e_A=788/99,
    damaged e_A=1576/297.

The correct A bound is attained, whereas the damaged bound is smaller than the true error. The correct k bound is also attained in this case. All seven actual failed check records, the altered code, exact diff, pre-execution damage protocol and complete stdout/stderr remain in damage_v1. This establishes sensitivity of this independent implementation, not coverage of the uninspected producer implementation.

The source's scope limits survive the refinement. The true weighted moment equation, adopted absolute-error envelopes, known z/time coordinate, potential-ratio reconstruction, sampling and quadrature control are supplied premises. The new algebra does not supply them. It produces deterministic conditional bounds, not measured precision, a confidence level, an experimental error budget or an empirical exclusion. A failed sufficient domain test remains inconclusive.

The third reserved moment remains a necessary no-refit consistency test, and this extension adds no theorem making one such check sufficient for the full trace. This review did not rerun the previous inverse or its moment-null counterexample. No actual initial scalar state, action scale, environment or measurement apparatus has been selected.

FAILURES_v1.json preserves both the original real/complex premise gap and the actual changed-bound failures. EVIDENCE_BINDING_v1.json records mechanical source, exact code-change and command/output correspondence. MANIFEST_v1.json covers every regular artifact except itself and RECEIPT_v1.json, and the receipt binds that manifest and the complete source/execution lineage. Subsequent source changes require a separate correspondence addendum.
