# Finite-wavelength equations and a conditional local error bound

Direct author /root. Frozen hand derivation before the checker. The goal is
to replace the phrase "spatial derivatives dominate" with an explicit bound
from the supplied action. This is conditional classical linear mathematics,
not an observation fit, a complete cosmological perturbation solver, or a
derivation of the action or perturbation initial state.

Use Einstein proper time t, a spatially flat homogeneous background, metric
K on field space, v=dot(phi), V=Hv^2 grad_K U, b=grad_K log sqrt(C), and
S=b Tbar/(2Q). D_t is the covariant derivative of K. The background equation
is D_t v+3H v+V=S. For dust, Tbar=-rhobar. Let the scalar metric perturbations
in Newtonian gauge be Phi,Psi, and let xi be the linear field-space tangent
perturbation. For zero linear anisotropic stress Psi=Phi. A nonzero comoving
Fourier wave number has Einstein physical wave number p=q/a. All quantities
below are evaluated on one regular background, with fixed k,nu,Q,Hv.

We treat delta rho and delta T=-delta rho as the TOTAL Einstein-frame dust
perturbations. They include the density changes required by matter dynamics;
they are not independently held-fixed Jordan number density plus an extra
scalar mass correction. A physical perturbation also obeys the momentum
constraint and matter conservation. Arbitrarily chosen forcing functions
need not do so. The equations used here are necessary equations of any such
solution, sufficient for the conditional inequality but not a substitute for
the remaining evolution equations.

## Covariant variation and metric constraints

Define R(X,Y)Z = nabla_X nabla_Y Z - nabla_Y nabla_X Z - nabla_[X,Y] Z.
Variation of D_t v along xi gives D_t^2 xi+R(xi,v)v. Variation of the source
separates nabla_xi b Tbar/(2Q) from b delta T/(2Q). Consequently define

    M xi = nabla_xi V + R(xi,v)v - Tbar nabla_xi b/(2Q).

Each term is self-adjoint in the positive K inner product. The exact linear
scalar equation in this gauge is

    D_t^2 xi+3H D_t xi+(p^2 I+M)xi
      =4v dot(Phi)+2(S-V)Phi-b delta rho/(2Q).           (1)

The lapse variation contributes 2Phi(D_t v+3H v), which becomes
2(S-V)Phi by the background equation. The connection variation, the trace
Hessian, and this background equation must all be included; a flat Hessian
of U by itself is not M on a rolling background.

The scalar energy density perturbation following from the same action is

    delta rho_phi/(2Q)=<v,D_t xi>-Phi |v|^2+<V,xi>.

The Einstein 00 constraint is therefore

    p^2 Phi+3H(dot(Phi)+H Phi)
       =-delta rho/(2Q)-<v,D_t xi>+Phi |v|^2-<V,xi>.    (2)

For completeness, with delta T^0_i=partial_i delta q_m for matter,
dot(Phi)+H Phi=<v,xi>-delta q_m/(2Q). These signs and 1/(2Q)
normalization can be cross-checked against the general Einstein equations
(23a,b,d) in [Ma and Bertschinger](https://arxiv.org/pdf/astro-ph/9506072),
after converting their conformal time to t and setting Gstar=1/(8pi Q).
Field-space curvature in covariant scalar variations is independently
documented by [Gong and Tanaka](https://arxiv.org/html/1101.4809v3).
The model-specific equations and bound here are direct derivations; neither
paper establishes this model's physical state or measurement applicability.

## A pointwise sufficient bound, with its rate premises visible

For a mode with delta rho !=0 let Phi0=-delta rho/(2Q p^2), xi0=b Phi0,
alpha=|b|=sqrt(g)>0. Suppose, at the time of interest,

    |dot(Phi)| <= Omega |Phi|,
    |D_t xi| <= Omega |xi|,
    |D_t^2 xi| <= Omega^2 |xi|.                       (3)

These are bounds on the actual perturbation, not only on the homogeneous
background or driving source. They are NOT derived from slow background
evolution. They can fail for free waves, a switched source, or at zeros.
Use induced K operator norm for M. Define nonnegative dimensionless numbers

    A=(3H^2+|v|^2+3|H|Omega)/p^2,
    B=(|v|Omega+|V|)/p^2,
    Cc=(4|v|Omega+2|S-V|)/p^2,
    Dd=(Omega^2+3|H|Omega+||M||)/p^2,
    R=[[A,alpha B],[Cc/alpha,Dd]],
    r=max(A+alpha B,Cc/alpha+Dd).

Triangle inequalities applied to (1),(2) give, for
e=(|Phi-Phi0|/|Phi0|, |xi-xi0|/(alpha |Phi0|)),

    e <= R(ones+e).

If r<1, taking the maximum component gives

    max(e) <= epsilon = r/(1-r).                     (4)

This is a sufficient, generally conservative pointwise bound. A coefficient
table computed at a background state, with a chosen Omega, does not verify
(3) for an actual solution. The bound is not a uniform theorem near k's
endpoints, singular backgrounds, p=0 or zero density amplitude.

The physical metric potentials on the same background conformal-time slice
are PhiJ=Phi+b_lower.xi and PsiJ=Phi-b_lower.xi. Thus the relative error
of the mean potential Phi, and that of PhiJ relative to (1+g)Phi0, are
each <=epsilon. For epsilon<1, the inferred same-mode excess

    g_mode=PhiJ/Phi-1

obeys |g_mode-g|<=2g epsilon/(1-epsilon). A nonzero complex Fourier
coefficient is allowed; the moduli version of the inequality still applies.
This is a potential coefficient statement, not an automatic orbit, clock,
finite-body force, remote lensing, or frequency-response measurement.

The algebraic bound alone does not control its time derivatives. In
particular it cannot be inserted as a first- or second-rate uncertainty in
the earlier inverses without additional derivative estimates. The next
subcase derives such estimates using an actual evolving mode equation.

## Why source slowness is not an initial-state selector

Linearity admits homogeneous solutions in addition to driven ones. At the
candidate's exact vacuum, scalar stress has no linear perturbation, while
the conformal scalar still changes PhiJ-PsiJ. Arbitrarily small freely chosen
scalar waves therefore change the force-side response without changing the
Einstein mean potential at this order. Their frequencies grow with p, so
large p alone does not establish (3). Causality of the equations does not set
their initial amplitudes to zero. Retarded response with fixed initial data
can be defined as a functional derivative with respect to a changed source;
using it observationally requires a specified source variation and controlled
common state. That is an operational hypothesis, not a derived cosmological
initial condition. No claim of an implemented experiment is made.
