# An exact evolving vacuum mode and a preparation-dependent error certificate

Direct author /root. This solvable subcase tests finite-wavelength corrections
and their derivatives using the supplied action, rather than an arbitrary
matrix. It does not identify the actual environment with that vacuum or
derive the perturbation preparation. No new observations are fitted.

At phi=0, C=1, H=Hv, |b|^2=k, and the matter-coupled canonical scalar has
B=m_u^2/H^2=4[3(1+k)+nu]/(1-3k)>12. Scalar stress starts at quadratic order.
Consider a weak prescribed cold comoving density distribution, conserved to
first order on de Sitter. Its Einstein density Fourier component is
delta rho_q proportional to a^-3, with zero first-order momentum and pressure.
An individual Fourier mode is a calculation device; it may be part of a
nonnegative localized dust distribution. A signed sinusoid on zero background
is not asserted to be a positive standalone material source. Perturbative
amplitudes must remain small over the finite time interval used.

The density and momentum constraints and spatial pressure Einstein equation
are all solved by Phi=Phi0=-delta rho_q/(2Q p^2), proportional to a^-1,
p=q/a. Thus dot(Phi0)=-H Phi0. The coupled scalar mode can be written
xi=b Phi0 y; the other two independent scalar directions are set to zero
for this particular response. Equation(1) of the companion derivation gives

    y_tt+H y_t+[p^2+(B-2)H^2]y=p^2.

With z=p/H>0 and A=B-2>0 this is exactly

    y_zz+[1+A/z^2]y=1.                              (1)

The physical potential mean remains Phi0, while PhiJ=(1+k y)Phi0,
PsiJ=(1-k y)Phi0. At finite z the coefficient g_mode=k y differs from the
principal value k even though the homogeneous C and k are constant. This is
a comoving Fourier potential response, not a static fixed physical-radius
force measurement. The earlier curved static-patch result has a different
source/readout and is not contradicted.

## A finite asymptotic approximation with a real residual bound

For any integer n>=0 define a FINITE sum

    P_n(z)=sum_{j=0}^n c_j z^(-2j), c_0=1,
    c_(j+1)=-[A+2j(2j+1)]c_j.

Then L P_n-1=R_n(z), where L=d_z^2+1+A/z^2 and

    R_n=c_n[A+2n(2n+1)] z^(-2n-2).

No convergence of the infinite asymptotic series is claimed. The first
three terms are 1-A/z^2+A(A+6)/z^4. Let z decrease with physical time from
a finite z0 to z>0. For e=y-P_n define initial discrepancies
e0=e(z0), e0p=e_z(z0), omega(z)=sqrt(1+A/z^2), and

    D0=sqrt(|e0|^2+|e0p|^2/omega(z0)^2),
    D(z)=D0+|c_n[A+2n(2n+1)]|/(2n+1)
                       *[z^(-2n-1)-z0^(-2n-1)].     (2)

For a homogeneous solution h, E=(|h_z|^2+omega^2|h|^2)/2 obeys
E_z=-A|h|^2/z^3. It follows, in the decreasing-z direction, that
sqrt(2E(z))/omega(z) <= sqrt(2E(w))/omega(w) for z<=w.
A unit derivative impulse at w therefore has amplitude and normalized
derivative bounded by 1/omega(w). Duhamel's formula, the triangle inequality
in this two-component energy norm, and 1/omega(w)<=1 prove

    |e| <= D(z),
    |e_z| <= omega(z) D(z),
    |e_zz| <= omega(z)^2 D(z)+|R_n(z)|.             (3)

For real or complex modes the same norm argument holds. With N=log a,
d_N=-z d_z, these imply

    |e_N| <= z omega D,
    |e_NN| <= z^2[omega^2 D+|R_n|]+z omega D.        (4)

Multiplying by H and H^2 converts to Einstein/physical vacuum time rates.
For the dynamical coefficient (1+k y)/(1+k) normalized to its principal
value, the corresponding coefficient and its N derivatives have errors
bounded by k/(1+k) times (3)'s first and (4)'s respective expressions.
These are differences from the approximation P_n, not bounds on the entire
finite-z deviation from y=1. The finite-z approximation must itself be
included when predicting a response.

## What this does and does not remove

Equation(2) exposes the independent preparation error D0. Increasing z0 or
z does not force an arbitrarily supplied D0 to vanish. The exact theory
therefore supplies a finite-wavelength error certificate conditional on an
initial preparation bound. It does not supply that bound from the background
action. Small coefficient errors can still permit larger derivative errors.

For a frozen synthetic test take k=1/20,nu=1, Q=H=1; n=2; intervals
(z0,z1)=(1000,100),(100,10). Integrate the exact e equation
e_zz+(1+A/z^2)e=-R_n with e0=e0p=0, and also the first interval with
e0=1/10,e0p=0. Baseline DOP853 rtol1e-10,atol1e-12, max |delta z|=.2;
independent-method numerical control Radau rtol2e-11,atol2e-13,max .2.
Use 301 equally spaced output z sites. Compare solutions, exact residual
identities and bounds (3),(4). Internal comparison threshold 1e-7 on scaled
state differences is not an observational acceptance criterion. Preserve
all actual solver outputs and failures. Code, exact numerical values and
independent checking follow; none is counted as completed in this source.
