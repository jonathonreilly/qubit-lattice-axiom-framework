# Independent derivation frozen before code

Scientific author /root; checker /root/scalar_energy_check. This derivation uses the complete supplied action and the two frozen source narratives, without producer code or outputs. It checks conditional linear mathematics, not a realized background/source, full perturbation solver, empirical readout or formal audit.

1. Vary -Q K_AB partial(phi^A) partial(phi^B)-2Q Hv^2 U plus universal matter coupling. In covariant form Box(phi)-V=-b T/(2Q), where V=Hv^2 grad U and b=grad log sqrt(C). For a homogeneous background, Box(phi)=-(D_t v+3Hv), so D_t v+3Hv+V=S=b Tbar/(2Q). The same factor 2Q is essential in the scalar source and in the Einstein density constraint.

For a two-parameter family with commuting variation/time coordinates, nabla_xi v=D_t xi. Using R(X,Y)Z=nabla_X nabla_Y Z-nabla_Y nabla_X Z-nabla_[X,Y] Z gives

    nabla_xi(D_t v)=D_t^2 xi+R(xi,v)v.

The sign is positive. A positive-curvature sphere gives a positive transverse geodesic-deviation restoring term with this convention. The source variation is (Tbar nabla_xi b+b delta T)/(2Q). Therefore M xi=nabla_xi V+R(xi,v)v-Tbar nabla_xi b/(2Q). The first and third terms lower to covariant Hessians, and the Jacobi curvature operator is symmetric by the Riemann tensor symmetries. Thus M is K-self-adjoint, without any positivity claim for M.

Newtonian-gauge metric factors are g_tt=-(1+2Phi), g_ij=a^2(1-2Psi)delta_ij. Expanding the covariant wave operator gives the metric terms -(dot Phi+3 dot Psi)v-2Phi(D_t v+3Hv) on the time-acceleration side. For Psi=Phi, moving them right and using the background equation gives 4v dot Phi+2(S-V)Phi. The scalar perturbation equation is therefore

    D_t^2 xi+3H D_t xi+(p^2 I+M)xi
      =4v dot Phi+2(S-V)Phi+b delta T/(2Q),

and delta T=-delta rho for total Einstein-frame dust. The lapse sign cannot be obtained by varying only a potential Hessian.

The density perturbation is delta rho_phi=2Q[<v,D_t xi>-Phi|v|^2+<V,xi>]. The -Phi term comes from the inverse lapse in the kinetic energy. Einstein 00 then gives p^2 Phi+3H(dot Phi+H Phi)=-delta rho/(2Q)-<v,D_t xi>+Phi|v|^2-<V,xi>. The scalar momentum is delta q_phi=-2Q<v,xi>, giving dot Phi+H Phi=<v,xi>-delta q_m/(2Q). Scalar and dust first-order anisotropic stress vanish on the stipulated homogeneous background.

Total delta rho is important: the scalar mass dependence of Einstein-frame dust, lapse and volume changes already belong to its density dynamics. If one instead chooses a held-fixed number-density variable, its conversion adds a b tensor b term to the coupled equations through delta T. Adding that term again while also retaining total delta rho would double-count it. Neither the two necessary equations nor arbitrary prescribed delta rho(t) replace matter conservation and the remaining Einstein constraints.

2. Put Phi0=-delta rho/(2Qp^2), xi0=b Phi0 and alpha=|b|. Subtract the principal responses. The 00 residual is bounded by A|Phi|+B|xi| after division by p^2, and the scalar residual by Cc|Phi|+Dd|xi|. The exact source A uses a conservative sum 3H^2+|v|^2 rather than the smaller absolute difference. The actual-solution rate hypotheses justify these terms; background slowness alone does not.

Writing e1=|Phi-Phi0|/|Phi0| and e2=|xi-xi0|/(alpha|Phi0|) yields

    e <= [[A,alpha B],[Cc/alpha,Dd]] (1+e).

All entries are nonnegative. The maximum row sum r<1 implies ||e||_infinity<=r/(1-r). This is a sufficient bound, not a necessary spectral-radius condition or an existence theorem for a physical solution. For complex modes use Hermitian K norms and moduli. Cauchy-Schwarz bounds the conformal error by alpha times the field error. Thus the physical mean potential and PhiJ/(1+g) each have relative error <=epsilon. If epsilon<1, |Phi|>=(1-epsilon)|Phi0| and |g_mode-g|<=2g epsilon/(1-epsilon). No derivative error follows from this amplitude inequality. Rate assumptions can fail at zeros, in transients or for small free high-frequency waves.

3. At phi=0, C=1, H=Hv, v=0, grad U=0 and background dust is zero. The action gives g=k, the coupled u mass B=m_u^2/H^2=4[3(1+k)+nu]/(1-3k)>12, and transverse masses 9H^2/4 and 2H^2. There is no linear scalar stress, although the nonzero constant vacuum energy provides the de Sitter background. The other two homogeneous scalar directions can be set to zero as a preparation choice; their existence is not excluded.

About zero background dust, a first-order weak cold comoving density is conserved as delta rho_q proportional to a^-3, with zero first-order momentum and pressure. A metric/scalar acceleration produces a first-order peculiar velocity, but multiplying it by the first-order source density gives second-order momentum. The matter/scalar exchange also starts at second order because dot(phi_background)=0. Thus a comoving first-order source is not made inconsistent by its own first-order force. This reasoning would fail if a nonzero background dust density were silently added. A Fourier sinusoid is a component, not a positive standalone source; the underlying localized density can be positive. A finite interval and small source amplitude are required.

The momentum constraint gives dot Phi+H Phi=0. With p=q/a, 00 is solved by Phi0=-delta rho_q/(2Qp^2), proportional to a^-1. The zero-pressure spatial equation is Phi_ddot+4H Phi_dot+3H^2 Phi=0 and is also satisfied. All required constraints are therefore consistent in this vacuum subcase.

Write xi=b Phi0 y. Since Phi0_dot=-H Phi0 and b,H are constant,

    y_tt+H y_t+[p^2+(B-2)H^2]y=p^2.

Let z=p/H and A=B-2>10. Since dot z=-Hz, the first-derivative z terms cancel and the exact mode equation is y_zz+(1+A/z^2)y=1. A fixed comoving q redshifts p; it is not a fixed physical wavelength or a static fixed-radius experiment. For a point source, recovering a fixed physical-radius field requires Fourier recombination and the changing relation between comoving and physical position, together with boundary/preparation information. A single comoving-mode transfer cannot be equated to a static Yukawa/curved-patch force coefficient.

4. For finite P_n=sum c_j z^-2j, differentiating each term gives L(c_j z^-2j)=c_j z^-2j+c_j[A+2j(2j+1)]z^-2j-2. Cancel adjacent powers with c_(j+1)=-[A+2j(2j+1)]c_j. Only the last term remains: R_n=c_n[A+2n(2n+1)]z^-2n-2. This is a finite identity. No convergent infinite series or z->0 uniformity is implied.

For e=y-P_n, e_zz+omega^2 e=-R_n and omega^2=1+A/z^2. Instead of relying on a Green-function normalization, differentiate the squared normalized energy directly:

    W^2=|e|^2+|e_z|^2/omega^2,
    (W^2)_z=2A|e_z|^2/(z^3 omega^4)
               -2 Re(conj(e_z) R_n)/omega^2.

For the homogeneous equation this is nonnegative with increasing z, hence W(z)<=W(w) for z<=w. For a driven solution, changing direction to decreasing z gives -W_z<=|R_n|/omega<=|R_n|, using |e_z|<=omega W. At W=0 the same statement follows by regularizing sqrt(W^2+eta^2) and passing eta to zero. Thus

    W(z)<=D0+integral_z^z0 |R_n(w)|dw=D(z).

This yields |e|<=D, |e_z|<=omega D, and the equation itself gives |e_zz|<=omega^2 D+|R_n|. The integral is exactly the finite expression in the source with exponent 2n+1. It grows as z decreases. Real and complex errors obey the same argument.

Because d_N=-z d_z, e_N=-z e_z and e_NN=z^2 e_zz+z e_z. The plus z e_z term in the second derivative matters. The bounds are z omega D and z^2(omega^2 D+|R_n|)+z omega D. These bound errors relative to P_n, not the full deviation from y=1. For F_dyn=(1+k y)/(1+k), multiply by k/(1+k). H and H^2 convert coefficient derivatives to proper-time derivatives only because H is constant and C=1 here; potential-amplitude derivatives would additionally differentiate Phi0.

D0 is independent preparation data. Adding a homogeneous scalar mode leaves the Einstein potential unchanged at first order but changes the physical potential difference. Large z does not suppress an arbitrary D0, and N derivatives can be enhanced by z and z^2. For example at z0=1000, e0=1/10, e0p=0, the homogeneous contribution to e_NN is approximately -100000; small coefficient errors do not imply slow perturbations. A retarded source-response functional can cancel a common prepared homogeneous state between controlled variations, but causality alone does not select that state for an observation.

Independent exact controls will check the metric connection/curvature commutator on a nontrivial jet of the supplied K, the trace-source variation, lapse expansion, stress normalization, action masses, conserved vacuum constraints, the residual recurrence, normalized energy derivative and N chain rule. Numerical controls use different parameters k=2/17,nu=3/5 (B=1344/55), intervals 80->12 and 40->7, finite n=1 and n=3, zero and complex preparation errors. One requested parameter case k=1/20,nu=1 on 100->10 with n=2 is also checked. Numerical agreement and sampled inequalities are diagnostics alongside the exact energy proof, not certified solver enclosures. Deliberately altered formula copies will retain the exact reference targets and all failures.
