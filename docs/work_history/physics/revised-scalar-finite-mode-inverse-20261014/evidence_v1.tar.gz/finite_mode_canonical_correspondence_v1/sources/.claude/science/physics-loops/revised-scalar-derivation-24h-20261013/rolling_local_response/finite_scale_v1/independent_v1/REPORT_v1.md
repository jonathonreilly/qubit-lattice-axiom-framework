# Independent finite-scale and vacuum-mode check

Scientific author: /root. Independent checker: /root/scalar_energy_check.

The scalar/metric equations, sufficient pointwise comparison bound, exact vacuum comoving-mode reduction, finite residual identity and preparation-dependent energy/derivative certificate agree with the independently reconstructed mathematics. No equation correction was found. One narrow wording clarification was sent to the author: “Scalar stress starts at quadratic order” means scalar-excitation stress beyond the constant vacuum energy. That vacuum energy is already included correctly in the de Sitter equations and has a metric-dependent covariant stress tensor. Both preserved v2 sources now contain this clarification; their narrow correspondence is checked below without rerunning or relabeling the original computations.

This is a focused mathematical check, not a formal audit, complete perturbation solver, derived preparation, cosmological history or observational result. The author’s producer checker and outputs were neither read nor imported nor executed. The complete action and two source narratives were snapshotted, and the handwritten derivation and protocol were saved before constructing the independent checker. All writes were confined to this evidence directory.

## Frozen sources and exact checked scope

The initial source manifest binds these live files to byte-identical snapshots:

| Source | SHA256 |
| --- | --- |
| rolling_local_response/finite_scale_v1/DERIVATION_v1.md | 4b6fdaadcefc6232f675395e187b863a2311186c005288fb4925727e8bb5d94f |
| rolling_local_response/finite_scale_v1/VACUUM_MODE_DERIVATION_v1.md | a3709c3abfc6ab97e5eea4adcf4eda15d8cc55cac76476713e72e3c5f5de2eb5 |
| docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md | 39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000 |

The first two paths are relative to the revised-scalar campaign pack; the third is repository relative. Exact original and snapshot paths, byte counts and hashes are in SOURCE_MANIFEST_v1.json. The source narrative’s external citations were not used as an oracle or represented as independently checked sources. The local action, direct variation, general differential geometry and independently implemented controls supply this check.

HAND_DERIVATION_v1.md contains the full derivation frozen before code. The executable check_independent_v1.py has SHA256 12aa5db2141a4806905ef65264b05b714ede0d1f7abc77181f873320b11c4c09. It constructs K, C and U directly from the supplied action; it does not call producer functions. Its metric-jet control uses k=2/17, nu=3/5 at the origin with nonzero rolling velocity and variation vectors. This is a nontrivial exact coordinate check of the general handwritten commutator proof, not exhaustive sampling of every background. The action’s vacuum mass and coupling identities are checked symbolically in k and nu.

## Covariant variation and normalization

The action gives Box(phi)-V=-b T/(2Q), hence the homogeneous equation D_t v+3H v+V=S with S=b Tbar/(2Q). For the stated convention R(X,Y)Z=nabla_X nabla_Y Z-nabla_Y nabla_X Z-nabla_[X,Y] Z, commuting the time and variation coordinates gives

    nabla_xi(D_t v) = D_t^2 xi + R(xi,v)v.

The positive curvature sign is correct. Direct jets of the actual K produce a nonzero curvature witness, so the check cannot pass merely because the test point has a vanishing Jacobi operator. Its lowered form is symmetric. V and b are gradients, so their covariant derivatives lower to Hessians. Consequently

    M xi = nabla_xi V + R(xi,v)v - Tbar nabla_xi b/(2Q)

is K-self-adjoint. This asserts neither positivity nor a bound on its eigenvalues on an arbitrary rolling background.

The source variation is (Tbar nabla_xi b+b delta T)/(2Q); therefore the minus sign in M is required when moving the background-trace Hessian to the left. The actual-action trace-Hessian witness is nonzero. With total Einstein-frame dust density, delta T=-delta rho. A held Einstein number density would instead give delta rho=rho b_lower.xi from the conformally varying mass; a held Jordan physical density gives delta rho=4rho b_lower.xi because rho_E=C^2 rho_J. Those are distinct choices of independent variable. Adding either extra term while already using total delta rho would double-count it. The parent source uses the total-density convention explicitly.

Expanding sqrt(-g) g^00 directly in the Newtonian metric produces -(dot Phi+3 dot Psi)v-2Phi(D_t v+3H v) on the time-acceleration side. Setting Psi=Phi and moving these terms right gives 4v dot Phi+2(S-V)Phi. The complete scalar equation is therefore

    D_t^2 xi + 3H D_t xi + (p^2 I+M)xi
      = 4v dot Phi + 2(S-V)Phi - b delta rho/(2Q).

The lapse sign and factor four agree. No “slow perturbation” substitution was used to derive this equation.

The action gives

    delta rho_phi/(2Q) = <v,D_t xi> - Phi |v|^2 + <V,xi>.

The inverse lapse supplies the minus kinetic term. The Einstein coefficient is Q/2, so the ADM Hamiltonian constraint gives delta rho_total/(2Q)=-p^2 Psi-3H(dot Psi+H Phi). This independently fixes the sign and factor in the stated 00 equation. The scalar momentum is delta q_phi=-2Q<v,xi>, giving dot Phi+H Phi=<v,xi>-delta q_m/(2Q). The supplied zero-anisotropic-stress scalar/dust setting is necessary when replacing Psi with Phi.

The two displayed evolution/constraint equations do not close the general physical perturbation problem. The other Einstein equations and matter conservation still restrict allowable delta rho and delta q. The source says this explicitly, and this check does not treat arbitrary forcing histories as physically realized dust.

## Sufficient rate-dependent comparison

Subtracting Phi0=-delta rho/(2Qp^2) and xi0=b Phi0 from the equations gives the stated residual inequalities. The coefficient A conservatively uses 3H^2+|v|^2 rather than the smaller absolute difference of the corresponding terms. Cauchy-Schwarz and the induced K norm give the other coefficients exactly as stated.

With alpha=|b|>0, the nonnegative matrix

    R = [[A, alpha B], [Cc/alpha, Dd]]

obeys e<=R(1+e). If its maximum row sum r<1, then max(e)<=r/(1-r). The exact rational comparison witness is R=[[1/8,1/20],[1/12,1/7]], r=19/84, epsilon=19/65; its equality solution is [271/1253,51/179], below that bound. This is only an algebraic comparison witness, not a synthetic physical perturbation.

The derivation requires actual-solution bounds on dot Phi, D_t xi and D_t^2 xi. It neither derives them from background/source slowness nor proves they hold near zeros, after switching a source, for free waves, or uniformly toward a singular parameter/background limit. There must also be nonzero density amplitude, p>0, finite coefficients and a positive field metric. The row-sum condition is sufficient and conservative, not necessary.

The conformal transformations PhiJ=Phi+b_lower.xi and PsiJ=Phi-b_lower.xi preserve the mean potential. They give the advertised relative mean and normalized dynamical-potential errors <=epsilon. If epsilon<1, the denominator Phi cannot vanish and

    |g_mode-g| <= 2g epsilon/(1-epsilon).

The moduli version also holds for complex Fourier coefficients. No derivative uncertainty follows from this amplitude inequality alone. These are same-mode potential coefficients; orbit, clock, finite-body, remote lensing and other calibrated readouts require additional response and measurement assumptions.

## Conserved vacuum subcase and measurement distinction

Direct action differentiation gives C=1, |b|^2=k, grad U=0 and the diagonal scalar mass matrix

    m^2/H^2 = diag(4[3(1+k)+nu]/(1-3k), 9/4, 2).

Thus B-12=4(12k+nu)/(1-3k)>0 for the supplied 0<k<1/3 and nu>0. The constant vacuum energy is 3Q H^2. Perturbations of the scalar fields about this stationary constant-field state carry no first-order excitation density or momentum. The background vacuum energy is not zero and is not omitted.

The cold comoving source is consistent at first order specifically about zero background dust. Its density is order epsilon. Its induced peculiar velocity and scalar/metric force are also order epsilon, so the associated momentum and coupling exchange start at order epsilon^2. At first order delta rho_q is proportional to a^-3, with delta q_m=delta P=0. This argument would fail if a finite background dust density were silently added. It also does not justify arbitrary prescribed density histories on a rolling background.

Phi0=-delta rho_q/(2Qp^2) is proportional to a^-1. It solves the density constraint, dot Phi+H Phi=0, and the zero-pressure spatial equation Phi_ddot+4H Phi_dot+3H^2 Phi=0. The separate scalar directions can be set to zero as initial/preparation data; the theory does not remove their homogeneous solutions.

Writing xi=b Phi0 y gives

    y_tt+H y_t+[p^2+(B-2)H^2]y=p^2.

Since p=q/a and z=p/H, dot z=-Hz and the first z-derivative terms cancel exactly:

    y_zz+[1+(B-2)/z^2]y=1.

Then PhiJ=(1+k y)Phi0, PsiJ=(1-k y)Phi0 and g_mode=k y. A fixed comoving Fourier label q has a redshifting physical wave number. This is different from a static source observed at fixed physical radius, or a sequence of experiments at fixed physical wavelength. A position-space readout requires Fourier recombination, the time-dependent comoving/physical-coordinate relation, the actual source distribution, and boundary/preparation information. It cannot be substituted directly into the previous static-patch inverse. A single signed sinusoid is not a positive standalone source on zero background; it can be a Fourier component of a positive localized distribution. The source’s finite-interval small-amplitude limitation is essential.

## Finite residual and independent energy proof

Differentiating each term of the finite polynomial gives the recurrence c_(j+1)=-[A+2j(2j+1)]c_j and

    L P_n-1 = c_n[A+2n(2n+1)]z^(-2n-2) = R_n.

The checker independently verifies this exact identity for n=0 through 6 and the displayed P2. The handwritten term-by-term derivation proves it for each finite integer n. These checks do not claim convergence of an infinite asymptotic series or a small-z uniform approximation.

An independent proof uses the normalized energy directly, rather than the source’s impulse-response presentation. For e_zz+omega^2 e=-R_n, omega^2=1+A/z^2, put W^2=|e|^2+|e_z|^2/omega^2. Then

    (W^2)_z = 2A |e_z|^2/(z^3 omega^4)
                - 2 Re(conj(e_z) R_n)/omega^2.

The homogeneous normalized energy contracts when z decreases. More generally -W_z<=|R_n|/omega<=|R_n|. At W=0 this follows by regularization. Integrating in the decreasing-z direction proves W(z)<=D0+integral_z^z0 |R_n(w)|dw, exactly the stated D(z). The orientation of that integral is consequential.

It follows that |e|<=D, |e_z|<=omega D and |e_zz|<=omega^2 D+|R_n|. Applying d_N=-z d_z gives e_N=-z e_z and e_NN=z^2 e_zz+z e_z, with the stated bounds. The plus z e_z term is indispensable. Multiplication by k/(1+k) converts to errors in the normalized dynamical coefficient relative to its finite-P_n approximation. Constant H and C=1 permit multiplication by H and H^2 for proper-time derivatives of that coefficient. Full potential derivatives additionally differentiate Phi0.

The result is conditional on the independently supplied preparation norm D0. It is not a derived smallness statement for D0, a bound on the full deviation from y=1, or a claim that scalar rates are slow. The exact initial-data witness k=1/20, nu=1, n=2, z0=1000, e0=1/10, e0p=0 gives |xi_NN/xi|=614129009982724765/6755267350033, approximately 90911.13, despite Phi0_N=-Phi0. Thus an attempted Omega=2H rate bound fails. The absolute source amplitude can be made small while retaining this ratio on the finite interval. A common-state retarded functional derivative is a possible controlled response definition, not an initial-state selector or an implemented measurement.

## Actual execution and numerical controls

The unchanged independent checker completed 125 passing and zero failing records: 65 symbolic/algebraic/domain/scope records and 60 numerical diagnostics across eight actual solver executions. These counts are bookkeeping, not 125 independent theorems. RUN_v1.json records the original command, observed zero exit and source/output hashes. No unexpected runtime, timeout or mathematical failure occurred in this check.

The frozen numerical controls are:

| Case | k, nu | n | Decreasing z interval | Initial error |
| --- | --- | --- | --- | --- |
| distinct_n1 | 2/17, 3/5 | 1 | 80 to 12 | e0=e0p=0 |
| distinct_n3 | 2/17, 3/5 | 3 | 40 to 7 | e0=e0p=0 |
| distinct_complex_preparation | 2/17, 3/5 | 3 | 80 to 12 | e0=(1+2i)/100, e0p=(-3+i)/200 |
| requested_k | 1/20, 1 | 2 | 100 to 10 | e0=e0p=0 |

The first three have A=1234/55; the last has A=298/17. DOP853 used rtol=2e-11, atol=3e-13, max_step=.125; Radau used rtol=1e-11, atol=2e-13, max_step=.125. Both methods retained all 257 requested output sites for each case. All eight CSV files include complex error, first/second z and N derivatives, residual, normalized energy and bounds. Solver statistics and tolerances are preserved. Maximum scaled state disagreements were respectively 9.89e-14, 1.96e-13, 4.72e-14 and 8.66e-14, below the predeclared internal 1e-7 comparison criterion.

All sampled energy, amplitude and derivative inequalities held using an explicitly recorded numerical allowance 2e-10*(1+bound). This allowance is an implementation diagnostic, not a rigorous interval enclosure. The all-z mathematical certificate is the analytic energy proof, not solver agreement or sampling.

For the complex-preparation case the largest sampled amplitude error was approximately .02256, while the largest second N derivative was approximately 143.79; the corresponding certificate was approximately 177.98 at its maximum. For the zero-preparation n=3 case, the largest amplitude error was approximately .11878, with D reaching .30263 at z=7. These examples also show that a valid bound need not be a useful small-error bound over every requested interval.

## Executed damaged-formula controls and limitations

Six actual altered copies of the independent checker were executed in exact-only mode. Each retains all 65 non-numerical records and exits 1 through its intended mathematical witness. Their entire source, one-target diff, command, log, result and failure list are preserved. Numerical trajectories were not repeated for these negative copies.

| Alteration | Passed / failed records | Intended rejected witness |
| --- | --- | --- |
| Reverse curvature term | 64 / 1 | Actual-metric covariant commutator |
| Reverse dust trace-Hessian term | 64 / 1 | Total-trace mass sign |
| Reverse lapse forcing | 64 / 1 | Direct metric expansion |
| Replace 2j(2j+1) by 2j(2j-1) | 59 / 6 | Finite residual starting at n=2 |
| Reverse residual integral direction | 51 / 14 | Integral derivative and positivity |
| Omit z e_z in e_NN | 63 / 2 | Generic chain rule and nonzero witness |

These failures are expected, preserved and not relabeled clean runs. They check the independent mathematical implementation; they do not claim anything about an unseen producer’s damage coverage.

The remaining limitations are substantive. The general bound assumes actual perturbation rates and full physical consistency; it does not infer either from a coefficient table. The vacuum source solution uses zero background matter, a specified comoving source, finite interval and selected scalar initial data. The finite certificate leaves homogeneous waves and their preparation norm free and does not establish a common preparation in any observation. It bounds linear coefficient errors relative to a finite approximation, not nonlinear backreaction or second-order matter/metric corrections. No actual finite-body, fixed-radius, observational, cosmological-history or initial-state selection claim follows.

## Narrow v2 correspondence

After the independent executions, the author preserved DERIVATION_v2.md and VACUUM_MODE_DERIVATION_v2.md. The general note replaces its short “no linear scalar stress” sentence with a statement about excitation density and momentum beyond the constant vacuum term. The vacuum note explicitly states that the constant potential supplies de Sitter curvature and its covariant stress tensor has a linear metric variation already accounted for in the Einstein equations.

Both complete revised notes were read. Exact replacement checks show that only those two prose spans changed; their actual preserved diffs match freshly generated diffs byte for byte. Every equation, bound, domain, initial condition, readout limitation and numerical protocol remains unchanged. The original v1 live files, their frozen snapshots and the executed independent checker remain byte-identical. SOURCE_CORRESPONDENCE_v2.json records eight passing correspondence checks with zero failures and snapshots the revised notes, both diffs and the author's clarification record.

The final revised source hashes are:

| Source | SHA256 |
| --- | --- |
| DERIVATION_v2.md | 57c0b5a9fad04cb35295db71ccc073ac7e1b0c4927871577f358fd811f4aff3b |
| VACUUM_MODE_DERIVATION_v2.md | ece0785dd08f0ab6a8c5ac37d97486b37d2a47b149c094069a86ae8103c468a7 |

This resolves the wording precision raised above. The original independent 125/0 execution and six altered-formula runs are reused as their actual unchanged history. There was no new science execution for v2. The author reports no producer computation change; no producer checker or output was accessed to verify any producer-execution claim.

The receipt binds this report, the unchanged hand derivation, original and clarified sources, execution history and full artifact manifest. Any later science source revision requires its own correspondence rather than changing these original runs.
