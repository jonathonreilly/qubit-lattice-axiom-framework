def weights(nn, interval):
    left, right = interval
    T = right - left
    t = (nn - left) / T
    return (float(wv(t)) / T, float(wd(t)) / T ** 2, float(wdd(t)) / T ** 3)

def moments(gf, interval):
    left, right = interval

    def parts(nn):
        ww, wp, wpp = weights(nn, interval)
        zz = z0 * math.exp(-nn)
        return (ww, wpp + wp + zz * zz * ww, zz)
    U, Uerr = quad(lambda nn: parts(nn)[0] * gf(nn), left, right, epsabs=2e-11, epsrel=2e-12, limit=400)
    V, Verr = quad(lambda nn: parts(nn)[0] * parts(nn)[2] ** 2, left, right, epsabs=2e-11, epsrel=2e-12, limit=400)
    L, Lerr = quad(lambda nn: parts(nn)[1] * gf(nn), left, right, epsabs=2e-11, epsrel=2e-12, limit=400)
    norm, normerr = quad(lambda nn: abs(parts(nn)[1]), left, right, epsabs=2e-10, epsrel=2e-12, limit=400)
    return dict(U=U, V=V, L=L, s=U / V, b=L / V, weight_norm=1.0, operator_weight_norm=norm, quad_error_estimates=[Uerr, Verr, Lerr, normerr])

def inverse(ms):
    m1, m2 = ms[:2]
    det = m1['V'] * m2['U'] - m2['V'] * m1['U']
    kk = (m1['L'] * m2['U'] - m2['L'] * m1['U']) / det
    aa = (m2['V'] * m1['L'] - m1['V'] * m2['L']) / det
    return (kk, aa, (aa + 2) * (1 - 3 * kk) / 4 - 3 * (1 + kk), det)
