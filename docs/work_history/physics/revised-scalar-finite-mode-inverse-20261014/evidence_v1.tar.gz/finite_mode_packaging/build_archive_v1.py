"""Freeze milestone7 derivations and actual evidence, never overwrite."""
import datetime,gzip,hashlib,io,json,pathlib,tarfile
p=pathlib.Path('.claude/science/physics-loops/revised-scalar-derivation-24h-20261013')
rr=p/'rolling_local_response';out=pathlib.Path('docs/work_history/physics/revised-scalar-finite-mode-inverse-20261014/evidence_v1.tar.gz')
assert not out.exists()
assert (p/'finite_mode_canonical_correspondence_v1/RECEIPT_v1.json').exists()
folders=[rr/'finite_scale_v1',rr/'finite_mode_inverse_v1',p/'finite_mode_packaging',p/'finite_mode_canonical_correspondence_v1']
files=set();omitted=[]
for folder in folders:
 for f in folder.rglob('*'):
  if not f.is_file() or '__pycache__' in f.parts or f.suffix=='.pyc':continue
  if f.name=='DESI_2411_12026_v2.html':
   omitted.append({'path':f.relative_to(p).as_posix(),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'reason':'External paper full text not republished; original source URL/access receipt retained.'});continue
  files.add(f)
rows=[];payloads={}
for f in sorted(files):
 assert not f.is_symlink(),f
 rel=f.relative_to(p).as_posix();assert not pathlib.PurePosixPath(rel).is_absolute() and '..' not in pathlib.PurePosixPath(rel).parts
 data=f.read_bytes();payloads[rel]=data;rows.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema':'campaign-recovery-manifest-v1','campaign':'revised-scalar-derivation-24h-20261013','milestone':7,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Exact vacuum finite-mode inverse and measured-error certificate. Earlier general rolling bounds are preserved as antecedent context, not newly claimed by this note. Matter/kinetic/covariance work is separate.','payload_count':len(rows),'files':rows,'external_fulltext_omitted':omitted}
payloads['RECOVERY_MANIFEST_v1.json']=(json.dumps(manifest,indent=2)+'\n').encode();out.parent.mkdir(parents=True,exist_ok=True)
with out.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for name,b in sorted(payloads.items()):
  info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b))
with tarfile.open(out,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(payloads) and len(set(m.name for m in members))==len(members)
 for m in members:
  assert m.isfile() and not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts
  assert tar.extractfile(m).read()==payloads[m.name]
r={'created_utc':manifest['created_utc'],'archive':str(out),'archive_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'archive_bytes':out.stat().st_size,'payload_count':len(rows),'member_count':len(payloads),'manifest_sha256':hashlib.sha256(payloads['RECOVERY_MANIFEST_v1.json']).hexdigest(),'safe_relative_regular_members':True,'all_payload_bytes_reverified':True,'omissions':omitted}
(p/'finite_mode_packaging/ARCHIVE_BUILD_v1.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
