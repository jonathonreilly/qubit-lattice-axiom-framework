# Direct-author weighted inverse experiment

Protocol was saved before production. All data are synthetic. The first run
completed78/1, rejecting the erroneous nu-positive threshold10+42k. Both source
and output remain unchanged. The corrected threshold10+18k produced79/0 in a
separate v2 run, with the inverse equations and frozen windows unchanged.
An independent reviewer separately raised the same domain error before seeing
producer outputs. A later prose clarification distinguishes an equation with
no explicit source amplitude from a slip ratio that still depends on the
relative amplitude of a free wave. No computation changed for that clarification.

The four cases used k=1/20,nu=1 and k=2/17,nu=3/5, each with two freely chosen
initial y,y_z pairs. The second pair adds(+.37,-.11) to the first; these shifts
were fixed in source before the first run. Each case was solved in decreasing z
with DOP853 and independently in increasing N with Radau. Their maximum scaled
state discrepancies lie between2.79e-13 and3.47e-13; all eight1001-site profiles
are preserved together in four NPZ files for each source version. Tolerances,
step caps, actual commands, durations, source and output hashes are recorded.
Adaptive quadrature estimates are diagnostic errors, not rigorous enclosures.

Weights in [0,.4] and [.5,.9] calibrate k,A. The [1,1.4] interval is reserved
as a synthetic equation test with no refitting. Across all runs, recovered k
agreed to about2e-15 and recovered nu to about6e-12. Third-window unnormalized
residuals were below8.3e-13. A smooth added slip perturbation of amplitude1e-3
confined to that third interval gives residuals about.1104 or.1141, while the
calibration remains unchanged. This is an intentional off-equation data
control, not an empirical detection threshold.

Under the explicit hypothetical uniform slip-error envelope1e-8, conservative
A-error bounds range from1.52e-4 to4.30e-4; k-error bounds range from2.06e-8 to
2.27e-8. The bounded sine-bias trials fall inside those bounds. These are
synthetic conditional bounds; no instrument has supplied that error envelope.
No precision forecast, calibrated physical potential reconstruction or actual
same-mode observations have been established.

Four actual damaged copies of the corrected producer were executed separately:
wrong weak adjoint47/32, reversed A inverse55/24, missing N drag59/20, and
missing clock mass shift71/8. Each fails its intended mathematical/coordinate
or known-parameter control. Their full sources, output, profiles and run
metadata remain in damages_v1. Counts are bookkeeping, not independent theorems.

The additional IDENTIFIABILITY_LEMMA_v1.md was derived after this fixed
experiment and does not alter its protocol. It proves ideal continuous-trace
uniqueness within the specified ODE family and existence of useful localized
weights, while allowing a fixed pair to be singular or ill-conditioned.
Independent checking of the revised source and lemma is in progress.

The displayed windows each span0.4 e-folds, hence physical duration0.4/H in
this exact constant-H vacuum. The full trace spans1.4/H. These are not supplied
laboratory times or an available observational baseline. Cosmological
light-cone surveys do not automatically provide the same Fourier mode on
successive homogeneous time slices. Shorter windows would require a new
conditioning study; the exact uniqueness lemma supplies no practical rate or
precision guarantee for them.
