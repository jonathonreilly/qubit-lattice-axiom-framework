# Map the ideal temporal inverse to the observation interface

Source access protocol was frozen before browsing. All inspected material is
exposed development context, not reserved test data. No likelihood was run and
no published confidence interval was used as a bound on k or nu.

The primary [DESI modified-gravity analysis](https://arxiv.org/html/2411.12026v2)
uses power-spectrum multipoles, survey windows, cosmological and nuisance
parameters, with CMB and weak-lensing combinations (sections2.1–2.3). Its
mu,Sigma,eta describe perturbed Einstein equations with a matter background.
The functional fits assume specific time/scale dependence; binned fits are
also described. These are parameter inferences under a background and transfer
model, not a raw time series of two potentials. Equations1–7 fix the notation
and normalization used below. No claim of the latest or strongest bound is made.

## Direct algebraic dictionary, personally checked

The paper's Psi is the time potential, while its Phi is the spatial potential.
Our time/space potentials are named Phi_J/Psi_J respectively. Thus

    eta_DESI = Psi_J/Phi_J,
    g = (Phi_J-Psi_J)/(Phi_J+Psi_J)
      = (1-eta_DESI)/(1+eta_DESI)
      = mu_DESI/Sigma_DESI - 1.

The last equality uses the paper's low-anisotropic-stress relation
Sigma=mu(1+eta)/2 and common matter source normalization. The functions mu,Sigma
must not be confused with the fitted departure amplitudes mu0,Sigma0: those
amplitudes vanish at the GR reference, whereas the functions equal one there.
Neither the paper's wavenumber symbol k nor its phenomenological amplitudes
are our scalar-theory coupling k.

## The missing physical bridge

This dictionary is an interface, not permission to insert reported mu0 and
Sigma0 into the ideal temporal inverse. Our closed equation assumes zero
background dust, exact constant-H scalar vacuum, a conserved weak source,
known z=q/(aH), and resolved same-mode potential evolution. The survey analysis
has nonzero background matter and a cosmological transfer history. Our general
rolling scalar/Einstein equations therefore have additional background and
matter-response terms; the simple vacuum two-parameter equation has not been
shown to describe that data-generating problem.

A useful next route is to derive the coupled matter, scalar and metric transfer
system on the candidate's matter/radiation histories, then form survey-level
readouts with their windows and covariance. Unknown initial scalar modes must
be retained or separately constrained in that system. Until then, a fit to a
published modified-gravity summary would supply the missing bridge rather than
derive it. The current result is a checked conditional inverse and a precise
observation-interface obligation, not an empirical test of the revised theory.

A&A HTML/PDF access attempts returned internal errors. A local urllib copy of
the arXiv HTML failed certificate verification; the ordinary system-curl route
was attempted separately with TLS checks intact. Original failures are in the
access records. No inaccessible A&A full-text claims were used.
