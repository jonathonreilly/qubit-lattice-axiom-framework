import json,itertools
import sympy as s
Ah,kh,sh1,sh2,bh1,bh2,ds1,ds2,db1,db2,dA,dk=s.symbols('Ah kh sh1 sh2 bh1 bh2 ds1 ds2 db1 db2 dA dk',real=True)
checks=[]
def zero(name,e):
 z=s.factor(e);checks.append({'name':name,'pass':z==0,'residual':str(z)})
def check(name,b,**kw):checks.append({'name':name,'pass':bool(b),**kw})
D=sh2-sh1;trueA=((bh1-db1)-(bh2-db2))/((sh2-ds2)-(sh1-ds1))
zero('measured_A_error_identity',(trueA-Ah-(-(db1-db2)+Ah*(ds2-ds1))/(D-(ds2-ds1))).subs(bh1,bh2+Ah*D))
truek=bh1-db1+(Ah+dA)*(sh1-ds1)
zero('measured_k_error_identity',truek-(bh1+Ah*sh1)-(-db1-Ah*ds1+dA*(sh1-ds1)))
nu=lambda A,k:(A+2)*(1-3*k)/4-3*(1+k)
zero('nu_exact_error',nu(Ah+dA,kh+dk)-nu(Ah,kh)-((1-3*kh)*dA-3*(Ah+6)*dk-3*dA*dk)/4)
k=s.Rational(1,20);n=s.Integer(1);A=4*(3*(1+k)+n)/(1-3*k)-2;s1=s.Rational(1,100);s2=s.Rational(1,40);b1=k-A*s1;b2=k-A*s2
es1=s.Rational(1,100000);es2=s.Rational(1,200000);eb1=eb2=s.Rational(1,100000);Es=es1+es2;Eb=eb1+eb2
corners=[];badwitness=None
for i,signs in enumerate(itertools.product([-1,1],repeat=4)):
 dx1,dx2,dy1,dy2=[sign*err for sign,err in zip(signs,[es1,es2,eb1,eb2])]
 hs1=s1+dx1;hs2=s2+dx2;hb1=b1+dy1;hb2=b2+dy2;hd=hs2-hs1
 ha=(hb1-hb2)/hd;hk=hb1+ha*hs1;hn=nu(ha,hk)
 ea=(Eb+abs(ha)*Es)/(abs(hd)-Es);ek=eb1+abs(ha)*es1+(abs(hs1)+es1)*ea;en=(abs(1-3*hk)*ea+3*abs(ha+6)*ek+3*ea*ek)/4
 check(f'corner{i}_rank',abs(hd)>Es)
 for name,error,bound in [('A',abs(A-ha),ea),('k',abs(k-hk),ek),('nu',abs(n-hn),en)]:check(f'corner{i}_{name}',error<=bound,error=str(error),bound=str(bound))
 corners.append({'signs':signs,'Ahat':str(ha),'khat':str(hk),'nuhat':str(hn),'eA':str(ea),'ek':str(ek),'enu':str(en),'certifies_physical_domain':bool(hk-ek>0 and hk+ek<s.Rational(1,3) and hn-en>0)})
 wrong=Eb/(abs(hd)-Es)
 if abs(A-ha)>wrong:badwitness={'corner':i,'error':str(abs(A-ha)),'wrong_bound':str(wrong)}
check('omit_Ahat_times_rank_error_rejected',badwitness is not None,witness=badwitness)
zero('nu_cross_term_is_necessary',nu(Ah+dA,kh+dk)-nu(Ah,kh)-((1-3*kh)*dA-3*(Ah+6)*dk)/4+3*dA*dk/4)
check('strict_rank_margin_not_automatic',not(abs(s.Rational(1,1000000))>Es))
r={'passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks),'checks':checks,'synthetic_corners':corners,'role':'Parent exact measured-error refinement and rational counterexamples; no observed precision'}
print(json.dumps(r,indent=2));raise SystemExit(1 if r['failed'] else 0)
