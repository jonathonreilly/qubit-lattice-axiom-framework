from pathlib import Path
import json,sys,hashlib,math
import numpy as np
import sympy as s
from scipy.integrate import solve_ivp,quad
out=Path(sys.argv[1]);out.mkdir(exist_ok=False)
rows=[]
def check(name,ok,**extra):rows.append(dict(name=name,passed=bool(ok),**extra))
def zero(name,x):check(name,s.simplify(x)==0,residual=str(s.simplify(x)))
# Independent symbolic differentiation and parameter inversion.
z,N,A,k,nu=s.symbols('z N A k nu',positive=True); f=s.Function('f')(z)
DN=lambda x:-z*s.diff(x,z)
zero('clock.z_to_N',DN(DN(f))+DN(f)-z*z*s.diff(f,z,2))
B=4*(3*(1+k)+nu)/(1-3*k)
zero('potential.nu_inverse',(B*(1-3*k)/4-3*(1+k))-nu)
zero('domain.A_lower_margin',(B-2)-(10+18*k)/(1-3*k)-4*nu/(1-3*k))
w=s.Function('w')(N);g=s.Function('g')(N)
# Boundary concomitant explicitly differentiated: integral proof needs its zero endpoints.
boundary=w*s.diff(g,N)-s.diff(w,N)*g+w*g
zero('weak.integration_by_parts',w*(s.diff(g,N,2)+s.diff(g,N))-(s.diff(w,N,2)-s.diff(w,N))*g-s.diff(boundary,N))
U1,U2,V1,V2,L1,L2=s.symbols('U1 U2 V1 V2 L1 L2')
D=V1*U2-V2*U1
kinv=(L1*U2-L2*U1)/D; Ainv=(V2*L1-V1*L2)/D
zero('inverse.row1',L1+Ainv*U1-kinv*V1)
zero('inverse.row2',L2+Ainv*U2-kinv*V2)
zero('inverse.original_k',kinv.subs({L1:k*V1-A*U1,L2:k*V2-A*U2})-k)
zero('inverse.original_A',Ainv.subs({L1:k*V1-A*U1,L2:k*V2-A*U2})-A)
x=s.symbols('x',real=True); polynomial=140*x**3*(1-x)**3
zero('weight.unit_integral',s.integrate(polynomial,(x,0,1))-1)
for n in range(3):
 for b in [0,1]:zero(f'weight.endpoint_{n}_{b}',s.diff(polynomial,x,n).subs(x,b))
wv=s.lambdify(x,polynomial,'numpy');wd=s.lambdify(x,s.diff(polynomial,x),'numpy');wdd=s.lambdify(x,s.diff(polynomial,x,2),'numpy')
windows=[(0,.4),(.5,.9),(1,1.4)];z0=50.; zend=z0*math.exp(-1.4)
def weights(nn,interval):
 left,right=interval;T=right-left;t=(nn-left)/T
 return float(wv(t))/T,float(wd(t))/T**2,float(wdd(t))/T**3

def moments(gf,interval):
 left,right=interval
 def parts(nn):
  ww,wp,wpp=weights(nn,interval); zz=z0*math.exp(-nn)
  return ww, wpp+wp+zz*zz*ww, zz
 U,Uerr=quad(lambda nn:parts(nn)[0]*gf(nn),left,right,epsabs=2e-11,epsrel=2e-12,limit=400)
 V,Verr=quad(lambda nn:parts(nn)[0]*parts(nn)[2]**2,left,right,epsabs=2e-11,epsrel=2e-12,limit=400)
 L,Lerr=quad(lambda nn:parts(nn)[1]*gf(nn),left,right,epsabs=2e-11,epsrel=2e-12,limit=400)
 norm,normerr=quad(lambda nn:abs(parts(nn)[1]),left,right,epsabs=2e-10,epsrel=2e-12,limit=400)
 return dict(U=U,V=V,L=L,s=U/V,b=L/V,weight_norm=1.,operator_weight_norm=norm,quad_error_estimates=[Uerr,Verr,Lerr,normerr])
def inverse(ms):
 m1,m2=ms[:2];det=m1['V']*m2['U']-m2['V']*m1['U']
 kk=(m1['L']*m2['U']-m2['L']*m1['U'])/det
 aa=(m2['V']*m1['L']-m1['V']*m2['L'])/det
 return kk,aa,((aa+2)*(1-3*kk)/4-3*(1+kk)),det
cases=[]
# Alternate preparations fixed as additions before any computation; not fitted.
for ks,ns,y0,yp0 in [('1/20','1',.9,.03),('2/17','3/5',1.2,-.07)]:
 kv=float(s.Rational(ks));nv=float(s.Rational(ns));av=4*(3*(1+kv)+nv)/(1-3*kv)-2
 for prep in [0,1]:
  yy=y0+.37*prep;yyz=yp0-.11*prep
  label=f'k_{ks.replace("/","_")}_prep_{prep}';records=[]
  def rhs_z(zz,state):return [state[1],1-(1+av/zz**2)*state[0]]
  def rhs_N(nn,state):
   zz=z0*math.exp(-nn)
   return [state[1],zz*zz-state[1]-(zz*zz+av)*state[0]]
  solz=solve_ivp(rhs_z,(z0,zend),[yy,yyz],method='DOP853',rtol=1e-11,atol=1e-13,max_step=.1,dense_output=True)
  soln=solve_ivp(rhs_N,(0,1.4),[yy,-z0*yyz],method='Radau',rtol=2e-12,atol=2e-14,max_step=.002,dense_output=True)
  check(label+'.solvers',solz.success and soln.success)
  samples=np.linspace(0,1.4,1001);zs=z0*np.exp(-samples)
  yz=solz.sol(zs);yn=soln.sol(samples)
  transformed=np.stack([yz[0],-zs*yz[1]])
  discrepancy=float(np.max(np.abs(transformed-yn)/(1+np.abs(yn))))
  check(label+'.coordinate_method_agreement',discrepancy<2e-8,max_scaled_error=discrepancy)
  np.savez_compressed(out/(label+'_profiles.npz'),N=samples,z=zs,DOP853_y_yN=transformed,Radau_y_yN=yn)
  for method,gf in [('DOP853_z',lambda nn:kv*float(solz.sol(z0*math.exp(-nn))[0])),('Radau_N',lambda nn:kv*float(soln.sol(nn)[0]))]:
   ms=[moments(gf,win) for win in windows]; kk,aa,nn,det=inverse(ms)
   check(label+'.'+method+'.k',abs(kk-kv)<2e-8,recovered=kk,expected=kv)
   check(label+'.'+method+'.A',abs(aa-av)<2e-6,recovered=aa,expected=av)
   check(label+'.'+method+'.nu',abs(nn-nv)<2e-6,recovered=nn,expected=nv)
   test=ms[2]['L']+aa*ms[2]['U']-kk*ms[2]['V']
   check(label+'.'+method+'.reserved_window',abs(test)<2e-7,residual=test)
   # Exact amplitude perturbation bound, using a declared synthetic error envelope.
   eps=1e-8;esm=[eps/m['V'] for m in ms[:2]];ebm=[eps*m['operator_weight_norm']/m['V'] for m in ms[:2]]
   Es=sum(esm);Eb=sum(ebm);sep=abs(ms[1]['s']-ms[0]['s'])
   check(label+'.'+method+'.error_denominator',sep>Es,separation=sep,error_sum=Es)
   BA=(Eb+abs(av)*Es)/(sep-Es)
   BK=ebm[0]+abs(av)*esm[0]+(abs(ms[0]['s'])+esm[0])*BA
   noisy=lambda tt:gf(tt)+eps*math.sin(13*tt+.2)
   mn=[moments(noisy,win) for win in windows];kn,an,_,_=inverse(mn)
   check(label+'.'+method+'.bounded_bias',abs(an-aa)<=BA+2e-7 and abs(kn-kk)<=BK+2e-9,A_error=abs(an-aa),A_bound=BA,k_error=abs(kn-kk),k_bound=BK)
   # An alternate third-window data trace; calibration moments remain identical.
   interval=windows[2];T=interval[1]-interval[0]
   shifted=lambda tt:gf(tt)+1e-3*(wv((tt-interval[0])/T)/wv(.5))
   mt=moments(shifted,interval);bad=mt['L']+aa*mt['U']-kk*mt['V']
   check(label+'.'+method+'.altered_reserved_window',abs(bad)>1e-3,residual=bad)
   records.append(dict(method=method,moments=ms,recovered=dict(k=kk,A=aa,nu=nn,det=det),reserved_residual=test,altered_reserved_residual=bad,amplitude_error_envelope=eps,A_error_bound=BA,k_error_bound=BK,quadrature_error_is_estimate_not_rigorous_enclosure=True))
  cases.append(dict(label=label,k=ks,nu=ns,initial_y=yy,initial_y_z=yyz,coordinate_method_discrepancy=discrepancy,source_amplitude_arbitrarily_small_on_finite_interval=True,records=records,solver_stats=dict(DOP853_z=dict(nfev=solz.nfev,steps=len(solz.t)),Radau_N=dict(nfev=soln.nfev,njev=soln.njev,steps=len(soln.t)))))
result=dict(scope='Conditional finite comoving mode, supplied action and exact vacuum. Synthetic development/calibration and reserved synthetic interval only; no empirical test.',checks=rows,counts=dict(passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows)),cases=cases)
(out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));raise SystemExit(bool(result['counts']['failed']))
