#!/usr/bin/env python3
"""Independent weighted inverse from canonical-field generated potentials.

The original-source domain defect is intentionally retained for the first run.
No producer functions or result files are imported. All tolerances are internal
numerical diagnostics, not observational thresholds or interval enclosures.
"""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
import time
import warnings

import numpy as np
import scipy
from scipy.integrate import quad, solve_ivp
from scipy.optimize import brentq
import sympy as sp

SOURCE_DOMAIN_COEFFICIENT = 18
ADJOINT_FIRST_SIGN = 1
INVERSE_A_SIGN = 1
NU_CLOCK_SHIFT = 2
CONDITION_A_TERM = 1

parser = argparse.ArgumentParser()
parser.add_argument("--output-dir",required=True)
parser.add_argument("--exact-only",action="store_true")
args = parser.parse_args()
out = Path(args.output_dir)
out.mkdir(parents=True,exist_ok=True)
started = time.time()
checks = []
details = {}
quadrature_records = []
warning_records = []


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(name,passed,witness=None):
    row = {"name":name,"passed":bool(passed)}
    if witness is not None:
        row["witness"] = witness
    checks.append(row)
    print(("PASS " if passed else "FAIL ")+name,flush=True)


def zero(name,expr):
    rr = sp.factor(sp.simplify(expr))
    record(name,rr == 0,str(rr))


def integrate(fun,left,right,label,refined=False):
    epsabs,epsrel = (2e-13,5e-13) if refined else (1e-11,2e-11)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        value,error = quad(fun,left,right,epsabs=epsabs,epsrel=epsrel,limit=400)
    warning_records.extend({"label":label,"category":w.category.__name__,
                            "message":str(w.message)} for w in caught)
    quadrature_records.append({"label":label,"left":left,"right":right,
        "value":float(value),"estimated_absolute_error":float(error),
        "epsabs":epsabs,"epsrel":epsrel,"refined":refined})
    return float(value)


N = sp.symbols("N",real=True)
z0,k,A,B,eta = sp.symbols("z0 k A B eta",positive=True)
z = z0*sp.exp(-N)
g = sp.Function("g")(N)
w = sp.Function("w")(N)
Phi0 = -eta*sp.exp(-N)
chi = Phi0*g/sp.sqrt(k)
scalar_residual = sp.diff(chi,N,2)+3*sp.diff(chi,N)+(z*z+B)*chi-sp.sqrt(k)*z*z*Phi0
mode_residual = sp.diff(g,N,2)+sp.diff(g,N)+(z*z+B-2)*g-k*z*z
zero("mode.canonical_field_to_ratio",scalar_residual-Phi0/sp.sqrt(k)*mode_residual)
f = sp.symbols("f",positive=True)
X,PP = sp.symbols("X PP",real=True,nonzero=True)
PhiJ,PsiJ = PP+sp.sqrt(k)*X,PP-sp.sqrt(k)*X
zero("mode.paired_potential_ratio",(PhiJ-PsiJ)/(PhiJ+PsiJ)-sp.sqrt(k)*X/PP)
zz = sp.symbols("zz",positive=True)
gz = sp.Function("gz")(zz)
DN = lambda expr:-zz*sp.diff(expr,zz)
zero("mode.N_z_chain",DN(DN(gz))+DN(gz)-zz*zz*sp.diff(gz,zz,2))

boundary = w*sp.diff(g,N)-sp.diff(w,N)*g+w*g
adjoint = sp.diff(w,N,2)+ADJOINT_FIRST_SIGN*sp.diff(w,N)
zero("weak.adjoint_and_boundary",
     w*(sp.diff(g,N,2)+sp.diff(g,N))-adjoint*g-sp.diff(boundary,N))
zero("weak.retaining_mass_and_known_geometry",
     w*(sp.diff(g,N,2)+sp.diff(g,N)+(z*z+A)*g-k*z*z)
     -((adjoint+z*z*w)*g+A*w*g-k*z*z*w+sp.diff(boundary,N)))
record("weak.nonvanishing_boundary_counterexample",
       sp.integrate(sp.diff(N*N,N,2)+sp.diff(N*N,N),(N,0,1)) == 3,
       "w=1, g=N^2 on [0,1] gives boundary 3; omitting endpoint conditions is invalid.")

weights = [
    {"name":"fit1","left":.07,"right":.35,"p":3,"q":4,"norm":280},
    {"name":"fit2","left":.47,"right":.83,"p":4,"q":3,"norm":280},
    {"name":"reserved3","left":1.02,"right":1.34,"p":4,"q":4,"norm":630},
]
s = sp.symbols("s",real=True)
for spec in weights:
    poly = spec["norm"]*s**spec["p"]*(1-s)**spec["q"]
    zero("weight."+spec["name"]+".normalization",sp.integrate(poly,(s,0,1))-1)
    for j in range(3):
        zero(f"weight.{spec['name']}.endpoint_derivative{j}",
             sp.diff(poly,s,j).subs(s,0)**2+sp.diff(poly,s,j).subs(s,1)**2)
    spec["functions"] = [sp.lambdify(s,sp.diff(poly,s,j),"numpy") for j in range(3)]

U1,U2,V1,V2 = sp.symbols("U1 U2 V1 V2",nonzero=True,real=True)
L1,L2 = k*V1-A*U1,k*V2-A*U2
D = V1*U2-V2*U1
kinv = (L1*U2-L2*U1)/D
Ainv = INVERSE_A_SIGN*(V2*L1-V1*L2)/D
zero("inverse.k_sign",kinv-k)
zero("inverse.A_sign",Ainv-A)
zero("inverse.intercept_consistency",kinv-(L1/V1+Ainv*U1/V1))
nu = sp.symbols("nu",positive=True)
Aactual = 4*(3*(1+k)+nu)/(1-3*k)-2
nuinv = (Aactual+NU_CLOCK_SHIFT)*(1-3*k)/4-3*(1+k)
zero("inverse.nu_clock_shift",nuinv-nu)
zero("domain.correct_expansion",Aactual-(10+18*k+4*nu)/(1-3*k))
threshold = (10+SOURCE_DOMAIN_COEFFICIENT*k)/(1-3*k)
nu_at_printed_threshold = (threshold+2)*(1-3*k)/4-3*(1+k)
zero("source_v1.claimed_domain_boundary_equivalence",nu_at_printed_threshold)
for name,kv,nv in [("exposed",sp.Rational(2,17),sp.Rational(3,5)),
                   ("distinct",sp.Rational(3,25),sp.Rational(2,7))]:
    av = sp.factor(Aactual.subs({k:kv,nu:nv}))
    tv = threshold.subs(k,kv)
    record("source_v1.valid_"+name+"_domain",av > tv,
           {"k":str(kv),"nu":str(nv),"A":str(av),"printed_threshold":str(tv),
            "exact_nu_from_A":str(sp.factor((av+2)*(1-3*kv)/4-3*(1+kv)))})
details["source_domain"] = {"printed_coefficient":SOURCE_DOMAIN_COEFFICIENT,
    "nu_on_printed_boundary":str(sp.factor(nu_at_printed_threshold)),
    "correct_threshold":"(10+18*k)/(1-3*k)"}

# Conditioning proof independently follows the exact perturbed ratio.
s1,s2,ds1,ds2,db1,db2 = sp.symbols("s1 s2 ds1 ds2 db1 db2",real=True)
b1,b2 = k-A*s1,k-A*s2
Delta = s2-s1
eta_s = ds2-ds1
At = ((b1+db1)-(b2+db2))/(Delta+eta_s)
errA_formula = (db1-db2-CONDITION_A_TERM*A*eta_s)/(Delta+eta_s)
zero("conditioning.exact_A_error",At-A-errA_formula)
kt = b1+db1+At*(s1+ds1)
zero("conditioning.exact_k_error",
     kt-k-(db1+A*ds1+(s1+ds1)*(At-A)))
zero("conditioning.exact_delta_denominator",((s2+ds2)-(s1+ds1))-(Delta+eta_s))
ar,kr,sr1,sr2 = sp.Rational(291,14),sp.Rational(3,25),sp.Rational(1,100),sp.Rational(3,100)
es1,es2,eb1,eb2 = map(sp.Rational,["1/10000","1/5000","1/1000","1/800"])
BA = (eb1+eb2+ar*(es1+es2))/(sr2-sr1-es1-es2)
BK = eb1+ar*es1+(sr1+es1)*BA
corner_failures = []
for signs in np.ndindex(2,2,2,2):
    vals=[(1 if sg else -1)*lim for sg,lim in zip(signs,[es1,es2,eb1,eb2])]
    sub={k:kr,A:ar,s1:sr1,s2:sr2,ds1:vals[0],ds2:vals[1],db1:vals[2],db2:vals[3]}
    ae = sp.factor((At-A).subs(sub))
    ke = sp.factor((kt-k).subs(sub))
    if not(abs(ae)<=BA and abs(ke)<=BK):
        corner_failures.append(str(signs))
record("conditioning.rational_error_box_corners",not corner_failures,
       {"corners":16,"failed":corner_failures,"bound_A":str(BA),"bound_k":str(BK)})

# Source strength is absent from the equation, but not from a fixed-free-wave ratio.
gp,gh = sp.symbols("gp gh",real=True)
gf = gp+gh/f
zero("source_rescaling.fixed_wave_relation",gf-gp-(gp+gh-gp)/f)
record("source_rescaling.ratio_not_invariant",
       sp.simplify((gf-(gp+gh)).subs({f:sp.Rational(5,3),gh:sp.Rational(2,7)})) != 0,
       str(sp.simplify((gf-(gp+gh)).subs({f:sp.Rational(5,3),gh:sp.Rational(2,7)}))))

# Added lemma: no fixed-window assumptions or numerical protocol changes.
c = sp.symbols("c",real=True)
gc = c*z*z
constant_s_res = sp.diff(gc,N,2)+sp.diff(gc,N)+(z*z+A)*gc-k*z*z
zero("lemma.constant_s_substitution",constant_s_res/z**2-(c*(z*z+A+2)-k))
zero("lemma.constant_s_derivative",sp.diff(c*(z*z+A+2),N)+2*c*z*z)
a1,a2,k1,k2 = sp.symbols("a1 a2 k1 k2",real=True)
zero("lemma.two_pair_subtraction",
     ((sp.diff(g,N,2)+sp.diff(g,N)+(z*z+a1)*g-k1*z*z)
      -(sp.diff(g,N,2)+sp.diff(g,N)+(z*z+a2)*g-k2*z*z))
     -((a1-a2)*g-(k1-k2)*z*z))
record("lemma.quantifier_scope",True,
       "Existence of separating positive compact bumps follows from continuity; no fixed-window or uniform noise margin follows.")

num = {}
if not args.exact_only:
    kv,nv = 3/25,2/7
    av,bv = 291/14,319/14
    sqrtk = math.sqrt(kv)
    source_unit = 3/100000
    z_start = 37.0
    Nend = 1.38
    grid = np.linspace(0,Nend,801)

    def initial(y,yz):
        # Solver field X=chi/source_unit, a constant numerical normalization.
        return np.array([-sqrtk*y,-sqrtk*(-z_start*yz-y)],dtype=float)

    particular0 = initial(1,0)
    wave10 = initial(7/6,-2/25)
    cases = [
        ("wave1",1.0,wave10),
        ("wave2",1.0,initial(-1/4,3/50)),
        ("particular_reference",1.0,particular0),
        ("rescaled_source_fixed_free_wave",5/3,(5/3)*particular0+(wave10-particular0))
    ]
    method_specs = [
        ("DOP853",{"rtol":2e-12,"atol":3e-14,"max_step":.003}),
        ("Radau",{"rtol":1e-11,"atol":2e-13,"max_step":.003}),
    ]
    solutions = {}
    moments_store = {}
    numeric_records = []

    def geom(nn):
        return z_start*z_start*math.exp(-2*nn)

    def weight(spec,nn):
        T=spec["right"]-spec["left"]
        ss=(nn-spec["left"])/T
        return tuple(float(fun(ss))/T**(j+1) for j,fun in enumerate(spec["functions"]))

    def moments(fun,label,refined=False):
        values=[]
        for spec in weights:
            lo,hi=spec["left"],spec["right"]
            prefix=label+"."+spec["name"]
            U=integrate(lambda nn:weight(spec,nn)[0]*fun(nn),lo,hi,prefix+".U",refined)
            V=integrate(lambda nn:weight(spec,nn)[0]*geom(nn),lo,hi,prefix+".V",refined)
            L=integrate(lambda nn:(weight(spec,nn)[2]+ADJOINT_FIRST_SIGN*weight(spec,nn)[1]
                      +geom(nn)*weight(spec,nn)[0])*fun(nn),lo,hi,prefix+".L",refined)
            values.append({"name":spec["name"],"U":U,"V":V,"L":L,"s":U/V,"b":L/V})
        return values

    def inverse(m):
        r1,r2=m[:2]
        DD=r1["V"]*r2["U"]-r2["V"]*r1["U"]
        kk=(r1["L"]*r2["U"]-r2["L"]*r1["U"])/DD
        aa=INVERSE_A_SIGN*(r2["V"]*r1["L"]-r1["V"]*r2["L"])/DD
        nn=(aa+NU_CLOCK_SHIFT)*(1-3*kk)/4-3*(1+kk)
        R3=m[2]["L"]+aa*m[2]["U"]-kk*m[2]["V"]
        scaled=R3/(1+abs(m[2]["L"])+abs(aa*m[2]["U"])+abs(kk*m[2]["V"]))
        return {"k":kk,"A":aa,"nu":nn,"D":DD,"Delta":r2["s"]-r1["s"],
                "reserved_residual":R3,"reserved_scaled_residual":scaled}

    for name,source_factor,state0 in cases:
        for method,params in method_specs:
            key=name+"."+method
            def rhs(nn,state):
                pp=geom(nn)
                # Exact canonical-field equation from the sealed action check.
                return [state[1],-3*state[1]-(pp+bv)*state[0]
                        -sqrtk*source_factor*pp*math.exp(-nn)]
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                sol=solve_ivp(rhs,(0,Nend),state0,method=method,dense_output=True,
                              t_eval=grid,**params)
            warning_records.extend({"label":key,"category":ww.category.__name__,
                "message":str(ww.message)} for ww in caught)
            record("numeric."+key+".solver_success",sol.success,sol.message)
            if not sol.success:
                numeric_records.append({"name":key,"success":False,"t":sol.t.tolist(),
                                        "y":sol.y.tolist(),"message":sol.message})
                continue
            solutions[(name,method)]=(sol,source_factor)

            def measured_g(nn,solution=sol,ff=source_factor):
                phi=-source_unit*ff*math.exp(-nn)
                chi_abs=source_unit*float(solution.sol(nn)[0])
                pj=phi+sqrtk*chi_abs
                ps=phi-sqrtk*chi_abs
                return (pj-ps)/(pj+ps)

            mm=moments(measured_g,key)
            inv=inverse(mm)
            moments_store[(name,method)]=(measured_g,mm,inv)
            record("numeric."+key+".recovered_parameters",
                   max(abs(inv["k"]-kv),abs(inv["A"]-av),abs(inv["nu"]-nv))<2e-6,inv)
            record("numeric."+key+".reserved_third",
                   abs(inv["reserved_scaled_residual"])<1e-8,inv["reserved_scaled_residual"])
            values=[]
            for jj,nn in enumerate(grid):
                phi=-source_unit*source_factor*math.exp(-nn)
                chi_abs=source_unit*sol.y[0,jj]
                pj,ps=phi+sqrtk*chi_abs,phi-sqrtk*chi_abs
                values.append([nn,math.sqrt(geom(nn)),sol.y[0,jj],sol.y[1,jj],
                    phi,chi_abs,pj,ps,(pj-ps)/(pj+ps)])
            datafile=out/(name+"_"+method+".csv")
            with datafile.open("w",newline="") as stream:
                writer=csv.writer(stream)
                writer.writerow(["N","z","chi_over_source_unit","chiN_over_source_unit",
                    "Phi0","chi","PhiJ","PsiJ","g"])
                writer.writerows(values)
            info={"name":key,"success":True,"source_factor":source_factor,
                "initial_normalized_canonical_field":state0.tolist(),
                "solver":method,"settings":params,"nfev":sol.nfev,"njev":sol.njev,"nlu":sol.nlu,
                "message":sol.message,"moments":mm,"inverse":inv,
                "data_file":datafile.name,"data_sha256":sha(datafile)}
            numeric_records.append(info)
        if (name,"DOP853") in solutions and (name,"Radau") in solutions:
            ss1=solutions[(name,"DOP853")][0].y
            ss2=solutions[(name,"Radau")][0].y
            diff=float(np.max(abs(ss1-ss2)/(1+np.maximum(abs(ss1),abs(ss2)))))
            record("numeric."+name+".cross_method",diff<1e-8,diff)
            fn,m0,i0=moments_store[(name,"DOP853")]
            refined=moments(fn,name+".quadrature_refined",True)
            inv_refined=inverse(refined)
            invdiff=max(abs(inv_refined[p]-i0[p]) for p in ["k","A","nu"])
            record("numeric."+name+".quadrature_refinement",invdiff<2e-6,
                   {"maximum_parameter_difference":invdiff,"refined_inverse":inv_refined})

    g1,m1,i1=moments_store[("wave1","DOP853")]
    gp,mp,ip=moments_store[("particular_reference","DOP853")]
    gf,mf,ifit=moments_store[("rescaled_source_fixed_free_wave","DOP853")]
    scale_diff=max(abs(gf(nn)-(gp(nn)+(g1(nn)-gp(nn))/(5/3))) for nn in grid)
    changed=max(abs(gf(nn)-g1(nn)) for nn in grid)
    record("amplitude.actual_fixed_free_wave_scaling",scale_diff<1e-9,
           {"max_scaling_residual":scale_diff})
    record("amplitude.ratio_really_changes",changed>1e-3,{"max_ratio_change":changed})
    record("amplitude.inverse_survives",max(abs(ifit["k"]-kv),abs(ifit["nu"]-nv))<2e-6,ifit)

    # Fixed-window rank degeneracy: exact linear solution space, sampled numerically.
    delta_p=mp[1]["s"]-mp[0]["s"]
    delta_h=(m1[1]["s"]-m1[0]["s"])-delta_p
    record("rank.nonzero_homogeneous_functional",abs(delta_h)>1e-7,delta_h)
    coeff=-delta_p/delta_h
    g_rank=lambda nn:gp(nn)+coeff*(g1(nn)-gp(nn))
    mr=moments(g_rank,"constructed_rank_failure",True)
    delta_rank=mr[1]["s"]-mr[0]["s"]
    record("rank.fixed_windows_can_fail",abs(delta_rank)<1e-12,
           {"homogeneous_coefficient":coeff,"Delta":delta_rank,
            "D":mr[0]["V"]*mr[1]["U"]-mr[1]["V"]*mr[0]["U"]})
    point_s=[g_rank(nn)/geom(nn) for nn in grid]
    record("rank.full_trace_still_nonconstant",max(point_s)-min(point_s)>1e-5,
           {"sampled_s_range":max(point_s)-min(point_s)})
    rank_equation_moments=[row["L"]+av*row["U"]-kv*row["V"] for row in mr]
    record("rank.superposition_remains_solution",
           max(abs(x) for x in rank_equation_moments)<1e-7,rank_equation_moments)
    rank_info={"homogeneous_coefficient":coeff,"moments":mr,"inverse_attempted":False,
        "scope":"Actual solution-space superposition, constructed with fixed predeclared weights; no state-independent rank guarantee."}

    # Bounded amplitude errors, affecting only the first two fit windows.
    epsilons=[1e-7,2e-7]
    phases=[.3,-.8]
    noisy=[]
    budgets=[]
    for j,spec in enumerate(weights):
        if j==2:
            noisy.append(m1[j].copy())
            continue
        epsj=epsilons[j]
        fnoise=lambda nn,jj=j:g1(nn)+epsilons[jj]*math.sin(13*nn+phases[jj])
        lo,hi=spec["left"],spec["right"]
        U=integrate(lambda nn:weight(spec,nn)[0]*fnoise(nn),lo,hi,f"noise{j}.U",True)
        V=m1[j]["V"]
        L=integrate(lambda nn:(weight(spec,nn)[2]-weight(spec,nn)[1]+geom(nn)*weight(spec,nn)[0])
                    *fnoise(nn),lo,hi,f"noise{j}.L",True)
        noisy.append({"name":spec["name"],"U":U,"V":V,"L":L,"s":U/V,"b":L/V})
        wn=integrate(lambda nn:abs(weight(spec,nn)[0]),lo,hi,f"noise{j}.norm_w",True)
        kernel=lambda nn:weight(spec,nn)[2]-weight(spec,nn)[1]+geom(nn)*weight(spec,nn)[0]
        # Find kernel sign changes solely to divide the absolute-integral quadrature.
        root_grid=np.linspace(lo,hi,513)
        roots=[]
        for left,right in zip(root_grid[:-1],root_grid[1:]):
            if kernel(left)*kernel(right)<0:
                roots.append(brentq(kernel,left,right,xtol=1e-14))
        partitions=[lo]+roots+[hi]
        kn=sum(integrate(lambda nn:abs(kernel(nn)),left,right,
                         f"noise{j}.norm_kernel.{seg}",True)
               for seg,(left,right) in enumerate(zip(partitions[:-1],partitions[1:])))
        budgets.append({"epsilon":epsj,"e_s":epsj*wn/V,"e_b":epsj*kn/V,
                        "norm_w":wn,"norm_kernel":kn,"kernel_sign_change_roots":roots})
        record(f"noise.window{j}.amplitude_to_moments",
               abs(noisy[j]["s"]-m1[j]["s"])<=budgets[-1]["e_s"]+1e-12
               and abs(noisy[j]["b"]-m1[j]["b"])<=budgets[-1]["e_b"]+1e-12,
               {"delta_s":noisy[j]["s"]-m1[j]["s"],"delta_b":noisy[j]["b"]-m1[j]["b"],
                "budget":budgets[-1]})
    noisy_inv=inverse(noisy)
    Es=sum(x["e_s"] for x in budgets)
    Eb=sum(x["e_b"] for x in budgets)
    Delta_num=m1[1]["s"]-m1[0]["s"]
    record("noise.rank_margin",abs(Delta_num)>Es,{"Delta":Delta_num,"Es":Es})
    bA=(Eb+av*Es)/(abs(Delta_num)-Es)
    bk=budgets[0]["e_b"]+av*budgets[0]["e_s"]+(abs(m1[0]["s"])+budgets[0]["e_s"])*bA
    record("noise.A_parameter_bound",abs(noisy_inv["A"]-i1["A"])<=bA+1e-10,
           {"actual_error":abs(noisy_inv["A"]-i1["A"]),"bound":bA})
    record("noise.k_parameter_bound",abs(noisy_inv["k"]-i1["k"])<=bk+1e-10,
           {"actual_error":abs(noisy_inv["k"]-i1["k"]),"bound":bk})
    noise_info={"moments":noisy,"budgets":budgets,"inverse":noisy_inv,
                "bound_A":bA,"bound_k":bk,
                "scope":"Known deterministic amplitude perturbations; numerical approximation separately diagnosed."}

    # Prospective third window uses parameters fixed by clean windows 1 and 2.
    third=weights[2]
    lo,hi=third["left"],third["right"]
    TT=hi-lo
    def bump(nn):
        tt=(nn-lo)/TT
        return 256*tt**4*(1-tt)**4
    def Kthird(nn):
        ww,wd,wdd=weight(third,nn)
        return wdd-wd+(geom(nn)+i1["A"])*ww
    moment_bump=integrate(lambda nn:Kthird(nn)*bump(nn),lo,hi,"third.bump_moment",True)
    detected=1e-5*moment_bump
    record("third.fixed_compact_damage_detected",abs(detected)>1e-6,
           {"residual_change":detected,"amplitude_bound":1e-5,"parameters_refit":False})
    moment_t=integrate(lambda nn:Kthird(nn)*bump(nn)*(nn-lo)/TT,lo,hi,"third.t_bump_moment",True)
    center=moment_t/moment_bump
    nullchange=lambda nn:1e-5*bump(nn)*((nn-lo)/TT-center)
    nullmoment=integrate(lambda nn:Kthird(nn)*nullchange(nn),lo,hi,"third.null_moment",True)
    maxnull=max(abs(nullchange(nn)) for nn in np.linspace(lo,hi,257))
    record("third.nonzero_moment_null_deviation",
           maxnull>1e-8 and abs(nullmoment)<1e-12,
           {"maximum_deviation":maxnull,"residual_change":nullmoment,"center":center})
    # This compact nonzero smooth deviation cannot solve the homogeneous ODE:
    # its zero initial value and derivative would imply the identically zero solution.
    record("third.moment_not_full_equation",maxnull>1e-8,
           "Compact bump has zero value/derivative at endpoints; uniqueness forbids a nonzero homogeneous solution. One null moment is insufficient.")
    third_info={"detectable_residual_change":detected,"null_residual_change":nullmoment,
                "null_max_amplitude":maxnull,"null_center":center,
                "parameters_from_windows_1_2":i1,
                "scope":"Disclosed synthetic controls; third data not fitted. Null change is a deliberate moment-null counterexample, not blind evidence."}
    num={"parameters":{"k":kv,"nu":nv,"A":av,"B":bv,"z0":z_start,"N_end":Nend,
                       "source_unit":source_unit},
         "canonical_normalization":"Solver integrates chi/source_unit; potentials restored before taking ratio. Constant source_unit is common across amplitude variants.",
         "runs":numeric_records,"rank_control":rank_info,"noise_control":noise_info,
         "third_window_controls":third_info}

result={"schema":"independent-finite-mode-inverse-control-results-v1",
    "checker":"/root/scalar_energy_check","scientific_author":"/root",
    "producer_checker_or_outputs_accessed":False,
    "exact_only":args.exact_only,"code_sha256":sha(__file__),
    "versions":{"python":sys.version,"platform":platform.platform(),"sympy":sp.__version__,
                "numpy":np.__version__,"scipy":scipy.__version__},
    "constants":{"source_domain_coefficient":SOURCE_DOMAIN_COEFFICIENT,
                 "adjoint_first_sign":ADJOINT_FIRST_SIGN,"inverse_A_sign":INVERSE_A_SIGN,
                 "nu_clock_shift":NU_CLOCK_SHIFT,"conditioning_A_term":CONDITION_A_TERM},
    "counts":{"passed":sum(c["passed"] for c in checks),
              "failed":sum(not c["passed"] for c in checks),"total":len(checks)},
    "checks":checks,"details":details,"numerical":num,
    "quadrature":quadrature_records,"warnings":warning_records,
    "elapsed_seconds":time.time()-started,
    "limitations":["Known geometry and paired signed/phase-consistent potentials are premises.",
        "Initial waves remain physical nuisance data; fixed windows can lose rank.",
        "Third weighted residual is necessary, not sufficient or action-unique.",
        "Synthetic solver/quadrature checks are not rigorous numerical enclosures or empirical tests.",
        "No inference of absolute calibration, environmental applicability or selected initial state."]}
(out/"RESULTS_v1.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result["counts"]),flush=True)
sys.exit(0 if result["counts"]["failed"]==0 else 1)
