#!/usr/bin/env python3
"""Retain original-domain failures; execute one repair and four actual damages."""
import datetime
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

base=Path(__file__).resolve().parent
original=base/"check_independent_v1.py"
oldtext=original.read_text()
old="SOURCE_DOMAIN_COEFFICIENT = 42"
new="SOURCE_DOMAIN_COEFFICIENT = 18"
assert oldtext.count(old)==1
repaired_text=oldtext.replace(old,new,1)
repair=base/"domain_repair_v2"
repair.mkdir(exist_ok=True)
repaired=repair/"check_domain_repair_v2.py"
assert not repaired.exists()
repaired.write_text(repaired_text)
(repair/"SOURCE.diff").write_text("".join(difflib.unified_diff(
    oldtext.splitlines(True),repaired_text.splitlines(True),
    fromfile="check_independent_v1.py",tofile="domain_repair_v2/check_domain_repair_v2.py")))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
root=base/"damages_v1"
root.mkdir(exist_ok=True)
specs=[
    ("wrong_adjoint_sign","ADJOINT_FIRST_SIGN = -1","ADJOINT_FIRST_SIGN = 1",
     "weak.adjoint_and_boundary"),
    ("wrong_A_inverse_sign","INVERSE_A_SIGN = 1","INVERSE_A_SIGN = -1",
     "inverse.A_sign"),
    ("missing_clock_shift","NU_CLOCK_SHIFT = 2","NU_CLOCK_SHIFT = 0",
     "inverse.nu_clock_shift"),
    ("missing_conditioning_term","CONDITION_A_TERM = 1","CONDITION_A_TERM = 0",
     "conditioning.exact_A_error"),
]
protocol={"created_before_execution":True,
    "original_sha256":sha(original),"repaired_sha256":sha(repaired),
    "repair":"Only 42->18 in claimed A-domain coefficient. Exact-only run; no repeat or relabel of original numerical trajectories.",
    "damage_scope":"Four actual altered copies of repaired independent checker, exact-only.",
    "controls":[{"name":name,"old":old,"new":new,"intended_witness":witness}
                for name,old,new,witness in specs]}
(root/"PROTOCOL_v1.json").write_text(json.dumps(protocol,indent=2)+"\n")


def execute(code,folder,intended=None):
    target=folder/"output"
    command=[sys.executable,"-u",str(code),"--exact-only","--output-dir",str(target)]
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    tic=time.monotonic()
    try:
        proc=subprocess.run(command,text=True,stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT,timeout=120,check=False)
        output=proc.stdout
        status=proc.returncode
        failure=None
    except subprocess.TimeoutExpired as exc:
        output=exc.stdout or ""
        if isinstance(output,bytes):
            output=output.decode(errors="replace")
        status=None
        failure=str(exc)
    logfile=folder/"EXECUTION.log"
    logfile.write_text(output)
    resultfile=target/"RESULTS_v1.json"
    result=json.loads(resultfile.read_text()) if resultfile.exists() else None
    failed=[c["name"] for c in result["checks"] if not c["passed"]] if result else []
    row={"command":command,"started_utc":started,
         "finished_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
         "wall_seconds":time.monotonic()-tic,"timeout_seconds":120,
         "exit_code":status,"exception":failure,
         "code_sha256":sha(code),"log_sha256":sha(logfile),
         "result_sha256":sha(resultfile) if result else None,
         "counts":result["counts"] if result else None,
         "failed_checks":failed,"intended_witness":intended,
         "intended_rejection":status==1 and intended in failed if intended else None}
    (folder/"EXECUTION_v1.json").write_text(json.dumps(row,indent=2)+"\n")
    print(json.dumps(row),flush=True)
    return row


repair_run=execute(repaired,repair)
damage_runs=[]
for name,old,new,witness in specs:
    assert repaired_text.count(old)==1
    folder=root/name
    folder.mkdir(exist_ok=True)
    code=folder/"check_damaged_v1.py"
    assert not code.exists()
    modified=repaired_text.replace(old,new,1)
    code.write_text(modified)
    (folder/"SOURCE.diff").write_text("".join(difflib.unified_diff(
        repaired_text.splitlines(True),modified.splitlines(True),
        fromfile="domain_repair_v2/check_domain_repair_v2.py",
        tofile=name+"/check_damaged_v1.py")))
    result=execute(code,folder,witness)
    damage_runs.append(dict(result,name=name))
summary={"repair":repair_run,"damages":damage_runs,
         "detected":sum(r["intended_rejection"] for r in damage_runs),
         "total":len(damage_runs),
         "original_source_code_sha256":sha(original)}
(root/"RESULTS_v1.json").write_text(json.dumps(summary,indent=2)+"\n")
sys.exit(0 if repair_run["exit_code"]==0 and summary["detected"]==summary["total"] else 1)
