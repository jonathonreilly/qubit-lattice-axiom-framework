#!/usr/bin/env python3
"""Seal only this bounded independent evidence, retaining all original failures."""
import csv
import datetime
import difflib
import hashlib
import json
import math
from pathlib import Path

base=Path(__file__).resolve().parent
root=base
while not (root/"docs"/"EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md").exists():
    if root==root.parent:
        raise RuntimeError("Known repository action not found")
    root=root.parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads((base/path).read_text())


def entry(path):
    ff=base/path
    return {"path":str(path),"bytes":ff.stat().st_size,"sha256":sha(ff)}


def save(path,data):
    ff=base/path
    if ff.exists():
        raise RuntimeError("Refusing to overwrite "+str(ff))
    ff.write_text(json.dumps(data,indent=2)+"\n")


checks=[]


def check(name,condition,detail=None):
    checks.append({"name":name,"passed":bool(condition),"detail":detail})


initial_sources=load("SOURCE_MANIFEST_v1.json")
correspondence=load("SOURCE_CORRESPONDENCE_v2_v3.json")
sources=initial_sources["sources"]+correspondence["source_bindings"]
for row in sources:
    live=root/row["original_path"]
    frozen=base/row["snapshot_path"]
    check("source:"+row["snapshot_path"],
          not live.is_symlink() and not frozen.is_symlink()
          and live.stat().st_size==frozen.stat().st_size==row["bytes"]
          and sha(live)==sha(frozen)==row["sha256"])

previous_receipt=load("sources/PREVIOUS_RECEIPT_v1.json")
previous_manifest=load("sources/PREVIOUS_MANIFEST_v1.json")
previous_path=root/".claude/science/physics-loops/revised-scalar-derivation-24h-20261013/rolling_local_response/finite_scale_v1/independent_v1"
check("reused_receipt.expected_identity",
      sha(base/"sources/PREVIOUS_RECEIPT_v1.json")
      =="ca9058d51ea21fd9b23225fc836a7ddae4584e0d106189ec6c79b025198ec2d3")
check("reused_manifest.receipt_bound",
      sha(base/"sources/PREVIOUS_MANIFEST_v1.json")==previous_receipt["manifest"]["sha256"])
check("reused_evidence.all_62_unchanged",
      len(previous_manifest["artifacts"])==62 and all(
          sha(previous_path/item["path"])==item["sha256"]
          and (previous_path/item["path"]).stat().st_size==item["bytes"]
          for item in previous_manifest["artifacts"]))

run=load("RUN_v1.json")
result=load("original_source_run_v1/RESULTS_v1.json")
failed=[c["name"] for c in result["checks"] if not c["passed"]]
expected_failures=["source_v1.claimed_domain_boundary_equivalence",
                   "source_v1.valid_exposed_domain","source_v1.valid_distinct_domain"]
check("original.counts_and_actual_failures",
      result["counts"]=={"passed":80,"failed":3,"total":83}
      and failed==expected_failures and run["observed_exit_code"]==1)
check("original.executed_code",
      sha(base/"check_independent_v1.py")==result["code_sha256"]==run["code_sha256"])
check("original.results_and_log",
      sha(base/"original_source_run_v1/RESULTS_v1.json")==run["results_sha256"]
      and sha(base/"original_source_run_v1.log")==run["log_sha256"])
check("original.no_warnings",result["warnings"]==[])
check("original.eight_solver_runs",
      len(result["numerical"]["runs"])==8 and all(r["success"] for r in result["numerical"]["runs"]))
for row in result["numerical"]["runs"]:
    ff=base/"original_source_run_v1"/row["data_file"]
    with ff.open() as stream:
        rows=list(csv.reader(stream))
    check("numeric.payload:"+row["data_file"],
          sha(ff)==row["data_sha256"] and len(rows)==802
          and all(len(item)==9 for item in rows))
    ratio_ok=True
    mean_ok=True
    for item in rows[1:]:
        nn,zz,XX,XN,phi,chi,pj,ps,gg=map(float,item)
        ratio_ok &= abs(gg-(pj-ps)/(pj+ps))<1e-12
        mean_ok &= abs(phi+3e-5*row["source_factor"]*math.exp(-nn))<1e-16
        mean_ok &= abs((pj+ps)/2-phi)<1e-16
    check("numeric.readout_binding:"+row["data_file"],ratio_ok and mean_ok)

repairs=load("damages_v1/RESULTS_v1.json")
damage_protocol=load("damages_v1/PROTOCOL_v1.json")
original_text=(base/"check_independent_v1.py").read_text()
repair_text=(base/"domain_repair_v2/check_domain_repair_v2.py").read_text()
expected_repair=original_text.replace("SOURCE_DOMAIN_COEFFICIENT = 42",
                                    "SOURCE_DOMAIN_COEFFICIENT = 18",1)
expected_diff="".join(difflib.unified_diff(
    original_text.splitlines(True),expected_repair.splitlines(True),
    fromfile="check_independent_v1.py",tofile="domain_repair_v2/check_domain_repair_v2.py"))
check("repair.only_domain_coefficient",
      original_text.count("SOURCE_DOMAIN_COEFFICIENT = 42")==1
      and repair_text==expected_repair
      and (base/"domain_repair_v2/SOURCE.diff").read_text()==expected_diff)
rr=load("domain_repair_v2/output/RESULTS_v1.json")
check("repair.exact_only_36",
      rr["exact_only"] and rr["counts"]=={"passed":36,"failed":0,"total":36}
      and all(c["passed"] for c in rr["checks"])
      and repairs["repair"]["exit_code"]==0)
check("repair.execution_binding",
      sha(base/"domain_repair_v2/check_domain_repair_v2.py")==rr["code_sha256"]==repairs["repair"]["code_sha256"]
      and sha(base/"domain_repair_v2/output/RESULTS_v1.json")==repairs["repair"]["result_sha256"]
      and sha(base/"domain_repair_v2/EXECUTION.log")==repairs["repair"]["log_sha256"])
for rec,spec in zip(repairs["damages"],damage_protocol["controls"]):
    name=rec["name"]
    folder=base/"damages_v1"/name
    damaged=folder/"check_damaged_v1.py"
    dd=load(str((folder/"output/RESULTS_v1.json").relative_to(base)))
    check("damage.single_formula:"+name,
          name==spec["name"] and repair_text.count(spec["old"])==1
          and damaged.read_text()==repair_text.replace(spec["old"],spec["new"],1))
    check("damage.actual_output:"+name,
          sha(damaged)==rec["code_sha256"]==dd["code_sha256"]
          and sha(folder/"EXECUTION.log")==rec["log_sha256"]
          and sha(folder/"output/RESULTS_v1.json")==rec["result_sha256"]
          and dd["exact_only"] and dd["counts"]["total"]==36
          and rec["exit_code"]==1 and rec["exception"] is None
          and rec["intended_rejection"]
          and spec["intended_witness"] in rec["failed_checks"])
check("damage.all_four_detected",repairs["detected"]==repairs["total"]==4)
check("source_correspondence.ten_checks",
      correspondence["counts"]=={"passed":10,"failed":0}
      and all(c["passed"] for c in correspondence["checks"]))

binding={"scope":"Source identity, preserved original-domain failure, exact repair and actual independent output correspondence",
         "checks":checks,"counts":{"passed":sum(c["passed"] for c in checks),
                                  "failed":sum(not c["passed"] for c in checks)},
         "producer_results_validated":False}
save("EVIDENCE_BINDING_v1.json",binding)
if not all(c["passed"] for c in checks):
    raise RuntimeError("Binding failure preserved; receipt not issued")

files=sorted(f for f in base.rglob("*") if f.is_file()
             and f.name not in {"MANIFEST_v1.json","RECEIPT_v1.json"})
if any(f.is_symlink() for f in files):
    raise RuntimeError("Unexpected symlink")
manifest={"schema":"focused-independent-evidence-manifest-v1",
          "scope":"All current payloads; manifest/receipt excluded to avoid self-hash cycles",
          "artifacts":[entry(f.relative_to(base)) for f in files],
          "artifact_count":len(files)}
save("MANIFEST_v1.json",manifest)
receipt={
    "schema":"focused-independent-mathematical-check-receipt-v1",
    "sealed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "checker":"/root/scalar_energy_check","scientific_author":"/root","formal_audit":False,
    "scope":"Weak finite-mode inverse, physical domain, deterministic amplitude conditioning, preparation/source dependence and full-trace identifiability inside the specified known-geometry vacuum equation.",
    "outcome":"Original domain arithmetic and source-amplitude wording were corrected in preserved v2/v3 sources. Weak identity, inverse and conditional error formulas agree; full-trace lemma is valid with existential weight quantifiers.",
    "source_bindings":sources,
    "reused_science":{"receipt":entry("sources/PREVIOUS_RECEIPT_v1.json"),
        "manifest":entry("sources/PREVIOUS_MANIFEST_v1.json"),"prior_payloads_verified":62,
        "mode_source":entry("sources/SEALED_VACUUM_MODE_DERIVATION_v2.md"),
        "science_rerun":False,"previous_evidence_changed":False},
    "hand_derivation":entry("HAND_DERIVATION_v1.md"),
    "lemma_hand_addendum":entry("IDENTIFIABILITY_HAND_ADDENDUM_v1.md"),
    "protocol":entry("PROTOCOL_v1.json"),"report":entry("REPORT_v1.md"),
    "manifest":dict(entry("MANIFEST_v1.json"),artifact_count=len(files)),
    "original_execution":{"run":entry("RUN_v1.json"),
        "code":entry("check_independent_v1.py"),
        "result":entry("original_source_run_v1/RESULTS_v1.json"),
        "log":entry("original_source_run_v1.log"),
        "counts":result["counts"],"exit_code":1,
        "failed_checks":failed,"non_numerical_records":36,"numerical_records":47,
        "actual_solver_executions":8,"quadrature_calls":128,
        "warning_count":len(result["warnings"]),
        "status":"Preserved actual domain failures; never relabeled a clean run."},
    "domain_repair":{"source":entry("domain_repair_v2/check_domain_repair_v2.py"),
        "diff":entry("domain_repair_v2/SOURCE.diff"),
        "result":entry("domain_repair_v2/output/RESULTS_v1.json"),
        "execution":repairs["repair"],
        "counts":rr["counts"],"scope":"Only42->18; exact-only. No numerical trajectory repeat."},
    "actual_damaged_executions":{"protocol":entry("damages_v1/PROTOCOL_v1.json"),
        "results":entry("damages_v1/RESULTS_v1.json"),
        "controls":repairs["damages"],"all_detected":True,
        "scope":"Four executed altered independent formulas, exact-only; no producer-coverage claim."},
    "source_correspondence":{"record":entry("SOURCE_CORRESPONDENCE_v2_v3.json"),
        "counts":correspondence["counts"],
        "v2":"Domain coefficient42->18 only.",
        "v3":"Two source-amplitude prose clarifications only.",
        "lemma":"Independent proof, separately frozen source; fixed numerical weights unchanged."},
    "failure_history":entry("FAILURES_v1.json"),
    "evidence_binding":dict(entry("EVIDENCE_BINDING_v1.json"),counts=binding["counts"]),
    "conclusions":{
        "weak_identity":"Adjoint is w_NN-w_N; compact endpoint value and first derivative remove boundary data without removing the physical initial wave.",
        "domain":"nu>0 is equivalent to A>(10+18k)/(1-3k) on0<k<1/3. Original42 implied the stronger and incorrect nu>6k restriction.",
        "inverse":"Two measured moments identify k and A when D!=0. The inverse needs no supplied initial scalar phase/amplitude or explicit source amplitude.",
        "conditioning":"Displayed deterministic amplitude inequalities are correct with actual rank/error premises, known geometry and bounded true coefficients.",
        "source_amplitude":"Keeping an absolute free wave fixed while rescaling source amplitude changes g; the closed equation/inverse still eliminate explicit source strength.",
        "fixed_window_rank":"Allowed homogeneous data can remove rank for the chosen frozen pair; no inverse was attempted in the constructed nearly singular control.",
        "full_trace":"With known z and k>0, s=g/z² cannot be constant on an open interval, giving full-trace parameter uniqueness and existence of separating positive compact weights.",
        "third_window":"A reserved residual is a necessary model moment. A nonzero compact moment-null deviation exists; one residual does not verify the full ODE or action."
    },
    "numerical_summary":result["numerical"],
    "limitations":[
        "Same-mode signed/phase-consistent time-resolved paired potentials, nonzero sourced mean and known z/time geometry are premises.",
        "Exact vacuum and linear conserved weak comoving-source setting are reused; no actual environmental applicability or instrument response is derived.",
        "Unknown preparation is eliminated from parameter inputs, not physically selected; prechosen windows may lose rank.",
        "Amplitude-error bounds need defensible data/calibration budgets; true-parameter factors need reliable bounds for operational use.",
        "Numerical quadrature and solver checks are diagnostics, not rigorous enclosures, blind data or empirical tests.",
        "No fixed-radius force readout, observed-gravity completion, full cosmological history or unique physical action follows."
    ],
    "independence":{
        "hand_derivation_and_protocol_before_checker":True,
        "producer_code_or_outputs_before_independent_derivation_and_code":False,
        "full_producer_checker_or_result_files_loaded_imported_executed":False,
        "post_control_embedded_producer_diff_disclosure":correspondence["producer_access_disclosure"],
        "canonical_field_data_generation_separate_from_inverse":True,
        "own_parameters_weights_initial_waves_and_source_rescaling":True,
        "new_empirical_data_network_or_subagents":False,
        "other_chats_or_parent_science_git_PR_runtime_lock_audit_mutations":False,
        "writes_outside_this_folder":False,"prior_evidence_changed":False},
    "seal_policy":"Immutable evidence; subsequent changes need a new correspondence addendum."
}
save("RECEIPT_v1.json",receipt)
print(json.dumps({"artifact_count":len(files),"source_pairs":len(sources),
                  "binding_counts":binding["counts"],
                  "report":entry("REPORT_v1.md"),"manifest":entry("MANIFEST_v1.json"),
                  "receipt":entry("RECEIPT_v1.json")},indent=2))
