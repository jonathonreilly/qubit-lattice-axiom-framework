#!/usr/bin/env python3
"""Independent exact measured-error inverse check. No producer imports or trajectories."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import platform
import sys
import time
import sympy as s

DENOMINATOR_MARGIN = 0
parser=argparse.ArgumentParser()
parser.add_argument("--output-dir",required=True)
args=parser.parse_args()
out=Path(args.output_dir)
out.mkdir(parents=True,exist_ok=True)
start=time.time()
checks=[]
cases=[]
Q=s.Rational

def serial(value):
    if isinstance(value,dict):
        return {k:serial(v) for k,v in value.items()}
    if isinstance(value,(tuple,list)):
        return [serial(v) for v in value]
    if isinstance(value,(str,int,float,bool)) or value is None:
        return value
    return str(value)

def record(name,passed,witness=None):
    row={"name":name,"passed":bool(passed)}
    if witness is not None:
        row["witness"]=serial(witness)
    checks.append(row)
    print(("PASS " if passed else "FAIL ")+name,flush=True)

def zero(name,expression):
    residual=s.factor(s.cancel(expression))
    record(name,residual==0,{"residual":residual})

def nonnegative(expression):
    value=s.simplify(expression)
    result=value.is_nonnegative
    if result is None:
        raise ValueError("Undecided exact sign: "+str(value))
    return bool(result)

def positive(expression):
    value=s.simplify(expression)
    result=value.is_positive
    if result is None:
        raise ValueError("Undecided exact strict sign: "+str(value))
    return bool(result)

def nu_of(A,k):
    return s.expand((A+2)*(1-3*k)/4-3*(1+k))

def A_of(k,nu):
    return s.cancel(4*(nu+3*(1+k))/(1-3*k)-2)

def fit(sh,bh):
    # Independent matrix inversion of b_i=k-A*s_i.
    answer=s.Matrix([[1,-sh[0]],[1,-sh[1]]]).inv()*s.Matrix(bh)
    return tuple(s.simplify(x) for x in answer)

def certificate(sh,bh,es,eb):
    if not all(nonnegative(e) for e in [*es,*eb]):
        raise ValueError("Adopted absolute error bounds must be nonnegative.")
    Dh=s.simplify(sh[1]-sh[0])
    Es=sum(es)
    Eb=sum(eb)
    margin=s.simplify(s.Abs(Dh)-Es)
    if not positive(margin):
        return {"guard":False,"Delta_hat":Dh,"E_s":Es,"E_b":Eb,"margin":margin}
    kh,Ah=fit(sh,bh)
    eA=s.simplify((Eb+s.Abs(Ah)*Es)/(s.Abs(Dh)-DENOMINATOR_MARGIN*Es))
    ek=s.simplify(eb[0]+s.Abs(Ah)*es[0]+(s.Abs(sh[0])+es[0])*eA)
    nuh=s.simplify(nu_of(Ah,kh))
    enu=s.simplify((s.Abs(1-3*kh)*eA+3*s.Abs(Ah+6)*ek+3*eA*ek)/4)
    domain_margins=[s.simplify(s.re(kh)-ek),
                    s.simplify(Q(1,3)-s.re(kh)-ek),
                    s.simplify(s.re(nuh)-enu)]
    return {"guard":True,"Delta_hat":Dh,"E_s":Es,"E_b":Eb,"margin":margin,
        "A_hat":Ah,"k_hat":kh,"nu_hat":nuh,"e_A":eA,"e_k":ek,"e_nu":enu,
        "domain_margins":domain_margins,
        "physical_certified":all(positive(m) for m in domain_margins),
        "estimates_real":bool(Ah.is_real and kh.is_real and nuh.is_real)}

def evaluate(name,k,A,st,ds,db,es,eb,expect_domain=None):
    bt=[k-A*si for si in st]
    sh=[si+di for si,di in zip(st,ds)]
    bh=[bi+di for bi,di in zip(bt,db)]
    cert=certificate(sh,bh,es,eb)
    if not cert["guard"]:
        raise ValueError("Unexpected rejected denominator in "+name)
    actual=[s.Abs(A-cert["A_hat"]),s.Abs(k-cert["k_hat"]),
            s.Abs(nu_of(A,k)-cert["nu_hat"])]
    bounds=[cert["e_A"],cert["e_k"],cert["e_nu"]]
    margins=[s.simplify(bound-error) for bound,error in zip(bounds,actual)]
    premise=all(nonnegative(e-s.Abs(d)) for e,d in zip([*es,*eb],[*ds,*db]))
    passed=premise and all(nonnegative(m) for m in margins)
    if expect_domain is not None:
        passed=passed and cert["physical_certified"]==expect_domain
    row={"name":name,"truth":{"k":k,"A":A,"nu":nu_of(A,k),"s":st,"b":bt},
        "actual_errors":{"ds":ds,"db":db},"adopted_bounds":{"es":es,"eb":eb},
        "measured":{"s_hat":sh,"b_hat":bh},"certificate":cert,
        "actual_parameter_errors":actual,"bound_slack":margins,
        "premise_holds":premise,"expected_domain_result":expect_domain}
    cases.append(serial(row))
    record(name,passed,{"bound_slack":margins,"physical_certified":cert["physical_certified"]})
    return cert,row

# Symbolic identities are reconstructed from the true and measured matrix systems.
sh1,sh2,bh1,bh2,ds1,ds2,db1,db2=s.symbols(
    "sh1 sh2 bh1 bh2 ds1 ds2 db1 db2",real=True)
kh,Ah=fit([sh1,sh2],[bh1,bh2])
kt,At=fit([sh1-ds1,sh2-ds2],[bh1-db1,bh2-db2])
Dh=sh2-sh1
d=ds2-ds1
zero("symbolic.measured_A_matrix_inverse",Ah-(bh1-bh2)/Dh)
zero("symbolic.measured_k_matrix_inverse",kh-bh1-Ah*sh1)
zero("symbolic.true_denominator",(sh2-ds2)-(sh1-ds1)-(Dh-d))
zero("symbolic.exact_A_error",At-Ah-(Ah*d-(db1-db2))/(Dh-d))
zero("symbolic.exact_k_error",kt-kh-(-db1-Ah*ds1+(At-Ah)*(sh1-ds1)))
Aa,ka,da,dk=s.symbols("Aa ka da dk",real=True)
zero("symbolic.exact_nu_error",
    4*(nu_of(Aa+da,ka+dk)-nu_of(Aa,ka))
       -((1-3*ka)*da-3*(Aa+6)*dk-3*da*dk))
zero("symbolic.nu_cross_coefficient",
    s.diff(nu_of(Aa+da,ka+dk),da,dk)+Q(3,4))

# Distinct rational physical truth; no numerical ODE or data window is asserted.
k0=Q(2,17)
nu0=Q(5,6)
A0=A_of(k0,nu0)
zero("rational.distinct_A",A0-Q(788,33))
es=[Q(1,5000),Q(1,7000)]
eb=[Q(1,4000),Q(1,6000)]
for orientation,st in [
    ("positive",[Q(-3,40),Q(7,60)]),
    ("negative",[Q(7,60),Q(-3,40)])]:
    for index,signs in enumerate(itertools.product([-1,1],repeat=4)):
        ds=[signs[0]*es[0],signs[1]*es[1]]
        db=[signs[2]*eb[0],signs[3]*eb[1]]
        evaluate(f"corners.{orientation}.{index:02d}",k0,A0,st,ds,db,es,eb,True)

zero_cert,_=evaluate("zero_error.all_bounds",k0,A0,[Q(-3,40),Q(7,60)],
    [0,0],[0,0],[0,0],[0,0],True)
record("zero_error.exact_zero_certificates",
       all(zero_cert[n]==0 for n in ["e_A","e_k","e_nu"]))

negative_cert,_=evaluate("absolute_values.negative_measured_A",k0,A0,[0,Q(1,10)],
    [0,0],[-4,1],[0,0],[4,1],False)
record("absolute_values.negative_A_witness",negative_cert["A_hat"]<0)
zeroA_cert,_=evaluate("absolute_values.zero_measured_A",k0,A0,[Q(-3,40),Q(7,60)],
    [0,0],[0,A0*Q(23,120)],[0,0],[0,A0*Q(23,120)],False)
zero("absolute_values.zero_A_witness",zeroA_cert["A_hat"])

# Strict physical-domain boundaries and physical truths with conservative certificates.
kl=Q(1,500)
Al=A_of(kl,1)
low_cert,_=evaluate("domain.physical_lower_k_inconclusive",kl,Al,[0,1],
    [0,0],[0,0],[0,0],[kl,0],False)
zero("domain.lower_margin_equality",low_cert["domain_margins"][0])
ku=Q(1,3)-Q(1,1000)
Au=A_of(ku,1)
upper_cert,_=evaluate("domain.physical_upper_k_inconclusive",ku,Au,[0,1],
    [0,0],[0,0],[0,0],[Q(1,1000),0],False)
zero("domain.upper_margin_equality",upper_cert["domain_margins"][1])
kn=Q(1,9)
An=A_of(kn,Q(1,1000000))
nu_cert,_=evaluate("domain.physical_small_nu_inconclusive",kn,An,[0,1],
    [0,0],[0,0],[0,0],[Q(1,100000),Q(1,100000)],False)
record("domain.only_nu_margin_fails",
    positive(nu_cert["domain_margins"][0]) and positive(nu_cert["domain_margins"][1])
    and not positive(nu_cert["domain_margins"][2]))
for name,k,A in [("k_zero",s.Integer(0),s.Integer(14)),
                 ("k_one_third",Q(1,3),s.Integer(20)),
                 ("nu_zero",Q(1,9),A_of(Q(1,9),0))]:
    cert,_=evaluate("domain.exact_boundary."+name,k,A,[0,1],
        [0,0],[0,0],[0,0],[0,0],False)
    record("domain.exact_boundary_not_certified."+name,not cert["physical_certified"])

# The equality guard permits zero true denominator and multiple physical true pairs.
eqguard=certificate([0,1],[-10,-10],[Q(1,2),Q(1,2)],[0,0])
belowguard=certificate([0,1],[-10,-10],[Q(3,5),Q(3,5)],[0,0])
record("guard.equality_rejected",not eqguard["guard"] and eqguard["margin"]==0,eqguard)
record("guard.below_margin_rejected",not belowguard["guard"] and belowguard["margin"]<0,belowguard)
rankzero_pairs=[]
for kg,Ag in [(Q(1,20),Q(201,10)),(Q(1,10),Q(101,5))]:
    rankzero_pairs.append({"k":kg,"A":Ag,"nu":nu_of(Ag,kg)})
record("guard.equality_has_two_physical_truths",
    all(kg>0 and kg<Q(1,3) and nu_of(Ag,kg)>0 and kg-Ag/2==-10
        for kg,Ag in [(Q(1,20),Q(201,10)),(Q(1,10),Q(101,5))]),
    {"true_s":[Q(1,2),Q(1,2)],"actual_ds":[Q(-1,2),Q(1,2)],"pairs":rankzero_pairs})
try:
    certificate([0,1],[0,1],[-1,0],[0,0])
    rejected_negative=False
except ValueError:
    rejected_negative=True
record("guard.negative_adopted_bound_rejected",rejected_negative)

# The prescribed wrong denominator has a sharp counterexample with physical truth.
sharp_cert,sharp_row=evaluate("sharp.physical_truth_A_error",k0,A0,
    [Q(1,20),Q(1,10)],[Q(-1,80),Q(1,80)],[0,0],
    [Q(1,80),Q(1,80)],[0,0])
record("sharp.correct_eA_attained",sharp_row["bound_slack"][0]==0,
    {"actual_A_error":sharp_row["actual_parameter_errors"][0],"e_A":sharp_cert["e_A"]})
record("sharp.omitting_margin_is_false",
    positive(sharp_row["actual_parameter_errors"][0]
      -(sharp_cert["E_b"]+s.Abs(sharp_cert["A_hat"])*sharp_cert["E_s"])
        /s.Abs(sharp_cert["Delta_hat"])),
    {"actual_A_error":sharp_row["actual_parameter_errors"][0],
     "bad_eA":s.simplify((sharp_cert["E_b"]+s.Abs(sharp_cert["A_hat"])*sharp_cert["E_s"])
                         /s.Abs(sharp_cert["Delta_hat"]))})

# Entirely measured, rational near-rank sequence: no physical claim for this family.
sequence=[]
for eps in [Q(1,10),Q(1,100),Q(1,1000)]:
    cert=certificate([0,1],[0,-2],[(1-eps)/2,(1-eps)/2],[0,0])
    sequence.append(cert["e_A"])
    zero("conditioning.margin_"+str(eps.q),cert["e_A"]-2*(1-eps)/eps)
record("conditioning.bound_diverges_along_sequence",
       sequence[0]<sequence[1]<sequence[2],{"e_A":sequence})

# V2's real-part qualification, using an exact common imaginary measurement error.
eps=Q(1,1000000)
complex_cert,complex_row=evaluate("complex.absolute_bounds",k0,A0,
    [Q(-3,40),Q(7,60)],[0,0],[s.I*eps,s.I*eps],[0,0],[eps,eps],True)
record("complex.ordered_real_estimate_premise_fails",
    not complex_cert["estimates_real"] and complex_cert["k_hat"].is_real is False,
    {"k_hat":complex_cert["k_hat"],"nu_hat":complex_cert["nu_hat"]})
record("complex.projected_domain_certifies",
    complex_cert["physical_certified"] and positive(k0) and positive(Q(1,3)-k0) and positive(nu0),
    {"projected_domain_margins":complex_cert["domain_margins"]})

result={"schema":"independent-measured-error-certificate-results-v1",
    "scientific_author":"/root","checker":"/root/scalar_energy_check",
    "producer_code_or_results_accessed":False,
    "previous_inverse_or_fluid_reviewed_or_rerun":False,
    "formula_constants":{"denominator_margin":DENOMINATOR_MARGIN},
    "code_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "versions":{"python":sys.version,"sympy":s.__version__,"platform":platform.platform()},
    "counts":{"passed":sum(r["passed"] for r in checks),"failed":sum(not r["passed"] for r in checks),"total":len(checks)},
    "checks":checks,"cases":cases,"elapsed_seconds":time.time()-start,
    "exact_arithmetic_only":True,
    "limitations":["Synthetic algebraic moment tuples, not new ODE trajectories or measured windows.",
        "The true moment model and adopted deterministic error envelopes remain assumptions.",
        "No statistical error independence, measurement calibration or observational precision inferred.",
        "Failed sufficient conditions are inconclusive, not exclusion.",
        "Third-moment completeness and initial-state selection are outside the result.",
        "No formal audit or empirical result."]}
(out/"RESULTS_v1.json").write_text(json.dumps(serial(result),indent=2)+"\n")
print(json.dumps(result["counts"]),flush=True)
sys.exit(0 if result["counts"]["failed"]==0 else 1)
