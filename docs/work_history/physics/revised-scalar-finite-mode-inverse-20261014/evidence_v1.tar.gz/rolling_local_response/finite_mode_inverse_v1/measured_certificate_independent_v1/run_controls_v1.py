#!/usr/bin/env python3
"""Preserve baseline and one actual changed-bound execution."""
import argparse
import datetime as dt
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
CODE=ROOT/"check_independent_v1.py"
parser=argparse.ArgumentParser()
parser.add_argument("phase",choices=["baseline","damage"])
args=parser.parse_args()

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def execute(code,folder):
    folder.mkdir(parents=True,exist_ok=False)
    cmd=[sys.executable,str(code),"--output-dir",str(folder)]
    record={"argv":cmd,"cwd":str(ROOT),"code_sha256":sha(code),
        "started_utc":dt.datetime.now(dt.timezone.utc).isoformat()}
    (folder/"COMMAND.json").write_text(json.dumps(record,indent=2)+"\n")
    start=time.monotonic()
    proc=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,timeout=90)
    (folder/"stdout.txt").write_text(proc.stdout)
    (folder/"stderr.txt").write_text(proc.stderr)
    record.update(returncode=proc.returncode,elapsed_seconds=time.monotonic()-start,
        completed_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
        stdout_sha256=sha(folder/"stdout.txt"),stderr_sha256=sha(folder/"stderr.txt"))
    if (folder/"RESULTS_v1.json").exists():
        result=json.loads((folder/"RESULTS_v1.json").read_text())
        record.update(results_sha256=sha(folder/"RESULTS_v1.json"),
            counts=result["counts"],
            failed_checks=[r["name"] for r in result["checks"] if not r["passed"]])
    (folder/"EXECUTION.json").write_text(json.dumps(record,indent=2)+"\n")
    print(json.dumps(record,indent=2),flush=True)
    return record

if args.phase=="baseline":
    execution=execute(CODE,ROOT/"baseline_v1")
    sys.exit(execution["returncode"])

baseline=json.loads((ROOT/"baseline_v1/EXECUTION.json").read_text())
if baseline["returncode"]!=0:
    raise RuntimeError("Resolve and preserve baseline failures before a changed-bound control.")
folder=ROOT/"damage_v1"
folder.mkdir(exist_ok=False)
old=CODE.read_text()
needle="DENOMINATOR_MARGIN = 1"
replacement="DENOMINATOR_MARGIN = 0"
assert old.count(needle)==1
new=old.replace(needle,replacement)
code=folder/"omit_denominator_margin.py"
code.write_text(new)
(folder/"CHANGE.diff").write_text("".join(difflib.unified_diff(
    old.splitlines(keepends=True),new.splitlines(keepends=True),
    fromfile=CODE.name,tofile=code.name)))
protocol={"name":"omit_denominator_margin","baseline_sha256":sha(CODE),
    "replace":needle,"with":replacement,
    "required_failure":"sharp.physical_truth_A_error",
    "pre_execution":True,"producer_code_or_results_accessed":False}
(folder/"PROTOCOL.json").write_text(json.dumps(protocol,indent=2)+"\n")
execution=execute(code,folder/"output")
execution["required_failure"]=protocol["required_failure"]
execution["detected"]=execution["returncode"]==1 and protocol["required_failure"] in execution.get("failed_checks",[])
(folder/"SUMMARY.json").write_text(json.dumps(execution,indent=2)+"\n")
sys.exit(0 if execution["detected"] else 1)
