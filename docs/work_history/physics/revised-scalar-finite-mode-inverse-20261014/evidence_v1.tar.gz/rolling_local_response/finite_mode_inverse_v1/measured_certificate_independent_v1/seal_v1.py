#!/usr/bin/env python3
"""Seal only this completed independent algebraic extension and correspondence."""
import datetime as dt
import difflib
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[6]
assert (REPO/"docs").is_dir()
for name in ["REPORT_v1.md","MANIFEST_v1.json","RECEIPT_v1.json"]:
    if (ROOT/name).exists():
        raise RuntimeError("Refusing to overwrite existing seal: "+name)

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def item(path):
    p=ROOT/path
    return {"path":str(path),"bytes":p.stat().st_size,"sha256":sha(p)}
def read(path):
    return json.loads((ROOT/path).read_text())
def write(path,value):
    (ROOT/path).write_text(json.dumps(value,indent=2)+"\n")

sources=read("SOURCE_MANIFEST_v2.json")["sources"]
baseline=read("baseline_v1/RESULTS_v1.json")
execution=read("baseline_v1/EXECUTION.json")
damaged=read("damage_v1/output/RESULTS_v1.json")
damage_run=read("damage_v1/SUMMARY.json")
damage_protocol=read("damage_v1/PROTOCOL.json")

v1=(ROOT/"sources/MEASURED_ERROR_CERTIFICATE_v1.md").read_text()
v2=(ROOT/"sources/MEASURED_ERROR_CERTIFICATE_v2.md").read_text()
lines1=v1.splitlines(keepends=True)
lines2=v2.splitlines(keepends=True)
changes=[op for op in difflib.SequenceMatcher(a=lines1,b=lines2).get_opcodes() if op[0]!="equal"]
inserted="".join(lines2[changes[0][3]:changes[0][4]]) if len(changes)==1 else ""
correspondence_checks=[
    {"name":"single_insert_only","passed":len(changes)==1 and changes[0][0]=="insert"},
    {"name":"original_source_and_equations_byte_preserved",
     "passed":bool(inserted) and v2.replace(inserted,"",1)==v1},
    {"name":"real_moment_domain_premise_explicit",
     "passed":"take real moment data" in inserted and "real-trace reconstruction" in inserted},
    {"name":"complex_absolute_bounds_explicit",
     "passed":"absolute\nerror bounds themselves also hold for complex data" in inserted},
    {"name":"complex_domain_real_part_centers_explicit",
     "passed":"Re(k_hat) and Re(nu_hat)" in inserted and "real true parameters" in inserted},
    {"name":"saved_diff_is_exact",
     "passed":(ROOT/"SOURCE_V1_V2.diff").read_text()=="".join(difflib.unified_diff(
         lines1,lines2,fromfile="MEASURED_ERROR_CERTIFICATE_v1.md",tofile="MEASURED_ERROR_CERTIFICATE_v2.md"))}
]
correspondence={"schema":"narrow-source-correspondence-v1",
    "source_v1_sha256":sha(ROOT/"sources/MEASURED_ERROR_CERTIFICATE_v1.md"),
    "source_v2_sha256":sha(ROOT/"sources/MEASURED_ERROR_CERTIFICATE_v2.md"),
    "original_finding":"Ordered inequalities require real estimates; generic complex estimates require projected real centers.",
    "inserted_text":inserted,"checks":correspondence_checks,
    "counts":{"passed":sum(c["passed"] for c in correspondence_checks),
              "failed":sum(not c["passed"] for c in correspondence_checks)},
    "execution_lineage":"V1 hand derivation and protocol preserved. V2 and complex-control addendum were frozen before the single independent 72-check execution. No producer run was inspected or relabelled.",
    "old_inverse_and_fluid_evidence_changed":False}
write("SOURCE_CORRESPONDENCE_v2.json",correspondence)

binding=[]
def check(name,passed):
    binding.append({"name":name,"passed":bool(passed)})
for source in sources:
    live=REPO/source["original_path"]
    snapshot=ROOT/source["snapshot_path"]
    check("source.snapshot."+snapshot.name,sha(snapshot)==source["sha256"] and snapshot.stat().st_size==source["bytes"])
    check("source.live."+snapshot.name,sha(live)==source["sha256"] and live.read_bytes()==snapshot.read_bytes())
check("baseline.code_binding",execution["code_sha256"]==baseline["code_sha256"]==sha(ROOT/"check_independent_v1.py"))
check("baseline.results_binding",execution["results_sha256"]==sha(ROOT/"baseline_v1/RESULTS_v1.json"))
check("baseline.stdout_binding",execution["stdout_sha256"]==sha(ROOT/"baseline_v1/stdout.txt"))
check("baseline.stderr_binding",execution["stderr_sha256"]==sha(ROOT/"baseline_v1/stderr.txt"))
check("baseline.actual_success",execution["returncode"]==0 and baseline["counts"]=={"passed":72,"failed":0,"total":72})
check("baseline.no_exception",(ROOT/"baseline_v1/stderr.txt").read_text()=="")
check("baseline.stdout_checks",sum(x.startswith("PASS ") for x in (ROOT/"baseline_v1/stdout.txt").read_text().splitlines())==72)
check("baseline.all_32_corners",
    len([c for c in baseline["checks"] if c["name"].startswith("corners.")])==32
    and all(c["passed"] for c in baseline["checks"] if c["name"].startswith("corners.")))
old=(ROOT/"check_independent_v1.py").read_text()
new=(ROOT/"damage_v1/omit_denominator_margin.py").read_text()
check("damage.exact_one_constant_change",old.count(damage_protocol["replace"])==1
    and new==old.replace(damage_protocol["replace"],damage_protocol["with"]))
check("damage.baseline_binding",damage_protocol["baseline_sha256"]==sha(ROOT/"check_independent_v1.py"))
check("damage.code_binding",damage_run["code_sha256"]==damaged["code_sha256"]==sha(ROOT/"damage_v1/omit_denominator_margin.py"))
check("damage.results_binding",damage_run["results_sha256"]==sha(ROOT/"damage_v1/output/RESULTS_v1.json"))
check("damage.stdout_binding",damage_run["stdout_sha256"]==sha(ROOT/"damage_v1/output/stdout.txt"))
check("damage.stderr_binding",damage_run["stderr_sha256"]==sha(ROOT/"damage_v1/output/stderr.txt"))
check("damage.actual_named_failure",damage_run["returncode"]==1 and damage_run["detected"]
    and damage_protocol["required_failure"] in damage_run["failed_checks"])
check("damage.counts",damaged["counts"]=={"passed":65,"failed":7,"total":72})
check("damage.no_exception",(ROOT/"damage_v1/output/stderr.txt").read_text()=="")
check("damage.stdout_failures",sum(x.startswith("FAIL ") for x in (ROOT/"damage_v1/output/stdout.txt").read_text().splitlines())==7)
check("source_correspondence.six_passes",correspondence["counts"]=={"passed":6,"failed":0})
binding_record={"schema":"focused-evidence-binding-v1","checks":binding,
    "counts":{"passed":sum(c["passed"] for c in binding),"failed":sum(not c["passed"] for c in binding)},
    "scope":"Source/code/output/command correspondence, not a scientific grade."}
write("EVIDENCE_BINDING_v1.json",binding_record)
if binding_record["counts"]["failed"]:
    raise RuntimeError("Evidence binding failed; full record retained.")

failures={"schema":"complete-focused-check-failure-history-v1",
    "source_findings":[{"source":"MEASURED_ERROR_CERTIFICATE_v1.md",
        "type":"Missing explicit real-moment premise for ordered domain conditions",
        "status":"Resolved by preserved MEASURED_ERROR_CERTIFICATE_v2.md",
        "exact_witness":"k_hat=2/17+i/1000000, nu_hat=5/6-493i/22000000 are nonreal under an allowed absolute-error envelope.",
        "resolution":"Use consistent real moments for ordered inequalities, or Re(k_hat), Re(nu_hat) for complex estimates of real true parameters.",
        "formula_error":False}],
    "unexpected_execution_failures":[],
    "baseline":{"counts":baseline["counts"],"exit_code":0,"run":"baseline_v1/EXECUTION.json"},
    "actual_changed_bound":{"name":"omit_denominator_margin","exit_code":1,
        "counts":damaged["counts"],"required_failure":damage_protocol["required_failure"],
        "failed_checks":[c for c in damaged["checks"] if not c["passed"]],
        "sharp_physical_truth":{"k":"2/17","nu":"5/6","A":"788/33",
            "actual_A_error":"788/99","damaged_bound":"1576/297"}},
    "all_failures_preserved":True,"producer_failures_or_results_claimed":False,
    "prior_inverse_or_fluid_rerun":False}
write("FAILURES_v1.json",failures)

source_rows="\n".join("| "+row["snapshot_path"]+" | "+row["sha256"]+" |" for row in sources)
report=r"""# Independent measured-error certificate check

The measured-data denominator margin and all three error bounds are correct under their stated deterministic error and moment-model premises. No algebraic sign or coefficient correction was needed. The one source qualification concerns ordered physical-domain conditions: v1 left the real-estimate premise implicit. Preserved v2 explicitly uses a consistent real-trace reconstruction and correctly states the real-part alternative for complex estimates of real parameters.

Scientific authorship remains /root. This is a focused check of the new algebraic extension, with no formal audit grade. No producer checker/results were read, imported or run. Neither the previous inverse nor the fluid check was reviewed or rerun, and their evidence remains untouched by this work. All new writes are confined to measured_certificate_independent_v1. No empirical data, git/PR/runtime/lock or parent science source was changed.

The original new source and protocol were read fully, snapshotted, and used to write HAND_DERIVATION_v1.md and PROTOCOL_v1.json before implementation. The real/complex premise gap was reported before sealing. After the parent supplied v2, its complete text was read and frozen; PROTOCOL_COMPLEX_ADDENDUM_v1.json was also saved before executable construction. The single baseline execution therefore covers the original algebra and the narrow v2 clarification. It is not a relabelled producer run or a rerun of the previous inverse.

| Frozen mathematical source | SHA-256 |
| --- | --- |
__SOURCE_ROWS__

SOURCE_MANIFEST_v1.json preserves the original two bindings. SOURCE_MANIFEST_v2.json adds v2 as a third binding. The exact original repo-relative paths and sizes are recorded there. The live files and snapshots all agree at sealing.

Take the real true moment equations b_i=k-A s_i and the measured values sh_i,bh_i. Define ds_i=sh_i-s_i and db_i=bh_i-b_i, with supplied finite nonnegative deterministic bounds |ds_i|<=es_i and |db_i|<=eb_i. These are bounds, not automatically independent random errors or measured standard deviations. Correlation is allowed and can make the rectangular bound conservative.

Let

    Dh=sh2-sh1, d=ds2-ds1,
    E_s=es1+es2, E_b=eb1+eb2.

The true difference is D=Dh-d. By the reverse triangle inequality,

    |D| >= |Dh|-|d| >= |Dh|-E_s.

Thus |Dh|>E_s makes both measured and true denominators nonzero. For real data their signs also agree. The strict margin matters: equality permits zero true rank. For complex data the nonzero-denominator conclusion remains valid, without a notion of denominator sign.

Independently invert the two-by-two system with rows [1,-sh_i]. It yields

    Ah=(bh1-bh2)/Dh,
    kh=bh1+Ah sh1.

The true model implies bh1-bh2=A(Dh-d)+(db1-db2). Rearranging the exact equation, without expanding in small errors or dividing by A, gives

    A-Ah=[Ah d-(db1-db2)]/[Dh-d].

Applying the two triangle inequalities gives exactly

    e_A=(E_b+|Ah|E_s)/(|Dh|-E_s),
    |A-Ah|<=e_A.

All quantities on the right are measured estimates or adopted error bounds. Unknown true A is absent. This removes that algebraic circularity; it does not supply the measurement envelope or establish its coverage.

Use the first true row to reconstruct k:

    k-kh=-db1-Ah ds1+(A-Ah)(sh1-ds1).

Consequently

    e_k=eb1+|Ah|es1+(|sh1|+es1)e_A

is a valid upper bound on |k-kh|. Both the absolute value on sh1 and the es1*e_A product are retained. No sign assumptions on Ah or sh1 are needed. A second-row version could be used for optional tightening, but the source's stated first-row bound is already valid and was the one checked.

For the supplied mass relation,

    nu(A,k)=(A+2)(1-3k)/4-3(1+k)
            =[A-10-3k(A+6)]/4,

put dA=A-Ah and dk=k-kh. Exact polynomial expansion gives

    4(nu-nuh)=(1-3kh)dA-3(Ah+6)dk-3dA dk.

The coefficient Ah+6 and the minus sign of the mixed term are correct. The expansion is exact; there is no small-error truncation. A triangle bound then gives

    e_nu=[|1-3kh|e_A+3|Ah+6|e_k+3e_A e_k]/4.

The mixed product remains essential to this stated nonlinear bound. The true error pair (dA,dk) is generally correlated, so this bound need not be sharp.

For real estimates, the strict inequalities kh-e_k>0, kh+e_k<1/3 and nuh-e_nu>0 imply 0<k<1/3 and nu>0 for every true parameter pair satisfying the model and adopted envelopes. These conditions are sufficient, not necessary. They cannot certify an open-domain boundary from equality and their failure does not exclude a physical truth. They also do not prove that the data obey the assumed moment model.

The exact error identities and modulus bounds extend to complex moment errors. For real true k,nu, the facts |k-kh|<=e_k and |nu-nuh|<=e_nu imply the corresponding real-part bounds. The sufficient tests then use Re(kh) and Re(nuh). Arbitrary complex numbers cannot be directly ordered by the v1 inequalities.

An exact common imaginary measurement error demonstrates the distinction. With true k=2/17, nu=5/6, A=788/33, s=(-3/40,7/60), ds=(0,0) and db=(i/1000000,i/1000000), the fit gives

    Ah=788/33,
    kh=2/17+i/1000000,
    nuh=5/6-493i/22000000.

The original ordered expressions require a real-estimate restriction, while all absolute error bounds pass and the projected real-part domain conditions are positive. The source's six-line v2 insertion states exactly this distinction. SOURCE_CORRESPONDENCE_v2.json verifies that it is the only insertion and that deleting it reproduces v1 byte-for-byte. All original equations and bounds are unchanged. There are six passing correspondence checks; they are separate from the 72 mathematical checks.

The independent executable uses an exact symbolic two-by-two matrix inverse and exact rational arithmetic, with no finite differences or floating tolerance. Its first and only baseline run passed 72 checks with zero failures using Python 3.12.8 and SymPy 1.14.0. There were no unexpected execution errors. The executed code, argument vector, timestamps, exit status, stdout/stderr and full result object are preserved under baseline_v1.

The main distinct rational truth is

    k=2/17, nu=5/6, A=788/33,
    s1=-3/40, s2=7/60,
    es1=1/5000, es2=1/7000,
    eb1=1/4000, eb2=1/6000.

All sixteen signed ds/db corners were checked, and then all sixteen were checked with the s values reversed. Every one of the 32 corners obeys all three absolute error bounds and certifies the physical domain. This checks both denominator orientations and unequal error bounds. The suite also includes exactly zero errors and negative or zero measured Ah, so no unspoken positivity or division by Ah is used.

These values are synthetic algebraic moment tuples. This check does not assert that they are new solved vacuum trajectories, realizable particular fixed windows, or measured observations. The analytical proof establishes the conditional bounds; the exact corners and mutations probe the implementation and signs.

Several exact boundary controls distinguish validity from conclusiveness:

- At true k=1/500, nu=1 and zero actual errors, the adopted eb1=1/500 gives kh-e_k=0. The physical truth is not excluded; the sufficient lower-domain test is inconclusive.
- At true k=1/3-1/1000, nu=1 and zero actual errors, eb1=1/1000 gives kh+e_k=1/3. The strict upper-domain test is inconclusive despite physical true k.
- At true k=1/9, nu=1/1000000 and zero actual errors, adopted eb1=eb2=1/100000 preserve both k margins while the nu margin fails. This is another physical truth with an inconclusive certificate.
- Exactly k=0, k=1/3 or nu=0 with zero error is correctly not certified as belonging to the strict physical interior.

For a sharp rank-guard control, take measured sh=(0,1), bh=(-10,-10) and es1=es2=1/2, eb1=eb2=0. The equality |Dh|=E_s allows true s=(1/2,1/2), whose denominator is zero. Both k=1/20,A=201/10,nu=1237/800 and k=1/10,A=101/5,nu=117/200 satisfy these same true moment tuples and lie in the physical parameter domain. This is an algebraic two-moment ambiguity; it is not a claim that their complete continuous traces agree. The equality and below-margin guards are correctly rejected.

A measured near-rank sequence also exposes conditioning. Fix sh=(0,1), bh=(0,-2), Ah=2, E_b=0 and E_s=1-epsilon. The analytic bound is exactly 2(1-epsilon)/epsilon and diverges as epsilon approaches zero from above. At epsilon=1/10,1/100,1/1000 the exact certificates are 18,198,1998. The displayed analytic formula proves the divergence; three sampled values alone would not do so. No physical-family or observed-noise claim is attached to this conditioning example.

The actual changed-bound control was a separate source file made by the single replacement DENOMINATOR_MARGIN=1 to zero, which changes only the denominator of e_A from |Dh|-E_s to |Dh|. It was executed and exited one with 65 checks passing and seven failing, without an exception. The intended failed witness was sharp.physical_truth_A_error; two of the small-error-box corners also fail.

The sharp witness retains a physical true parameter pair k=2/17, nu=5/6, A=788/33 and uses

    true s=(1/20,1/10),
    ds=(-1/80,1/80), db=(0,0).

It gives Dh=3/40, E_s=1/40, Ah=2A/3 and

    |A-Ah|=788/99,
    correct e_A=788/99,
    damaged e_A=1576/297.

The correct A bound is attained, whereas the damaged bound is smaller than the true error. The correct k bound is also attained in this case. All seven actual failed check records, the altered code, exact diff, pre-execution damage protocol and complete stdout/stderr remain in damage_v1. This establishes sensitivity of this independent implementation, not coverage of the uninspected producer implementation.

The source's scope limits survive the refinement. The true weighted moment equation, adopted absolute-error envelopes, known z/time coordinate, potential-ratio reconstruction, sampling and quadrature control are supplied premises. The new algebra does not supply them. It produces deterministic conditional bounds, not measured precision, a confidence level, an experimental error budget or an empirical exclusion. A failed sufficient domain test remains inconclusive.

The third reserved moment remains a necessary no-refit consistency test, and this extension adds no theorem making one such check sufficient for the full trace. This review did not rerun the previous inverse or its moment-null counterexample. No actual initial scalar state, action scale, environment or measurement apparatus has been selected.

FAILURES_v1.json preserves both the original real/complex premise gap and the actual changed-bound failures. EVIDENCE_BINDING_v1.json records mechanical source, exact code-change and command/output correspondence. MANIFEST_v1.json covers every regular artifact except itself and RECEIPT_v1.json, and the receipt binds that manifest and the complete source/execution lineage. Subsequent source changes require a separate correspondence addendum.
"""
report=report.replace("__SOURCE_ROWS__",source_rows)
(ROOT/"REPORT_v1.md").write_text(report)
artifacts=[item(p.relative_to(ROOT)) for p in sorted(ROOT.rglob("*"))
    if p.is_file() and p.name not in {"MANIFEST_v1.json","RECEIPT_v1.json"}]
write("MANIFEST_v1.json",{"schema":"focused-evidence-manifest-v1",
    "artifacts":artifacts,"artifact_count":len(artifacts),
    "excluded":["MANIFEST_v1.json","RECEIPT_v1.json"],
    "no_symlinks":not any(p.is_symlink() for p in ROOT.rglob("*"))})
receipt={"schema":"focused-independent-mathematical-check-receipt-v1",
    "sealed_utc":dt.datetime.now(dt.timezone.utc).isoformat(),
    "checker":"/root/scalar_energy_check","scientific_author":"/root","formal_audit":False,
    "scope":"Measured-denominator weighted-inverse error certificate, exact e_A/e_k/e_nu, sufficient physical domain, conditioning and real/complex source qualification.",
    "outcome":"Algebraic bounds correct. V2 resolves the explicit real-estimate premise for ordered physical-domain conditions; no bound/sign coefficient change needed.",
    "source_bindings":sources,
    "hand_derivation":item("HAND_DERIVATION_v1.md"),
    "protocol":item("PROTOCOL_v1.json"),
    "complex_addendum":item("PROTOCOL_COMPLEX_ADDENDUM_v1.json"),
    "report":item("REPORT_v1.md"),
    "manifest":dict(item("MANIFEST_v1.json"),artifact_count=len(artifacts)),
    "main_execution":{"execution":item("baseline_v1/EXECUTION.json"),
        "code":item("check_independent_v1.py"),"result":item("baseline_v1/RESULTS_v1.json"),
        "stdout":item("baseline_v1/stdout.txt"),"stderr":item("baseline_v1/stderr.txt"),
        "counts":baseline["counts"],"observed_exit_code":0,
        "actual_error_box_corners":32,"exact_symbolic_rational_only":True,
        "prior_inverse_or_fluid_trajectories_executed":0},
    "actual_damaged_execution":{"protocol":item("damage_v1/PROTOCOL.json"),
        "code":item("damage_v1/omit_denominator_margin.py"),"diff":item("damage_v1/CHANGE.diff"),
        "execution":item("damage_v1/output/EXECUTION.json"),
        "result":item("damage_v1/output/RESULTS_v1.json"),
        "stdout":item("damage_v1/output/stdout.txt"),"stderr":item("damage_v1/output/stderr.txt"),
        "counts":damaged["counts"],"observed_exit_code":1,
        "required_failure":damage_protocol["required_failure"],
        "failed_checks":damage_run["failed_checks"],"detected":True},
    "source_v2_correspondence":dict(item("SOURCE_CORRESPONDENCE_v2.json"),counts=correspondence["counts"]),
    "failure_history":item("FAILURES_v1.json"),
    "evidence_binding":dict(item("EVIDENCE_BINDING_v1.json"),counts=binding_record["counts"]),
    "conclusions":{
        "signs":"A-A_hat=[A_hat(ds2-ds1)-(db1-db2)]/[Delta_hat-(ds2-ds1)].",
        "denominator":"Strict measured margin |Delta_hat|>E_s ensures a nonzero true denominator; equality does not.",
        "A_bound":"The displayed measured-only e_A follows from exact rearrangement and reverse triangle inequality.",
        "k_bound":"Exact error is -db1-A_hat ds1+(A-A_hat)(s_hat1-ds1); the displayed e_k follows.",
        "nu_bound":"The exact expansion contains -3(A_hat+6) delta k and -3 delta A delta k, with the displayed absolute bound.",
        "physical_domain":"Strict interval conditions are sufficient only; physical truths can remain uncertified.",
        "complex":"Use consistent real moments or real parts of complex estimated centers for real true parameters.",
        "conditioning":"The e_A bound can diverge near the measured rank margin; the demonstrated good bound is attained."},
    "limitations":[
        "True moment relation and deterministic measurement envelopes are premises.",
        "No real measurements, ODE trajectories, window realizability or empirical precision claimed for synthetic tuples.",
        "No statistical independence or confidence level inferred.",
        "No third-moment completeness, actual initial-state selection, scale or environment completion.",
        "No producer implementation coverage or formal audit verdict."],
    "independence":{
        "source_and_protocol_read_before_implementation":True,
        "hand_derivation_and_protocol_saved_before_checker":True,
        "producer_checker_or_results_read_imported_or_run":False,
        "prior_inverse_or_fluid_reviewed_or_rerun":False,
        "prior_evidence_changed_by_this_check":False,
        "new_empirical_data_or_network_access":False,
        "subagents_or_other_chats":False,
        "writes_outside_this_folder":False,
        "parent_science_git_PR_runtime_lock_or_audit_state_changed":False},
    "seal_policy":"Immutable focused evidence; later source changes require a new correspondence addendum."}
write("RECEIPT_v1.json",receipt)
print(json.dumps({"artifact_count":len(artifacts),"source_pairs":len(sources),
    "report":item("REPORT_v1.md"),"manifest":item("MANIFEST_v1.json"),
    "receipt":item("RECEIPT_v1.json"),"correspondence_counts":correspondence["counts"],
    "binding_counts":binding_record["counts"]},indent=2))
