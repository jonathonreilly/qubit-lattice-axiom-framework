from pathlib import Path
import json,hashlib,datetime
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent;out=p/'runs_v2';d=json.loads((out/'RESULTS.json').read_text())
fig,axs=plt.subplots(1,2,figsize=(11.5,4.2),constrained_layout=True)
colors=['#156082','#D06B25']
for i,c in enumerate(d['cases'][:2]):
 a=np.load(out/(c['label']+'_profiles.npz'));g=.05*a['DOP853_y_yN'][0]
 axs[0].plot(a['N'],g,color=colors[i],label=f'Preparation {i+1}',lw=1.6)
 m=c['records'][0]['moments'];xx=np.array([j['s'] for j in m]);yy=np.array([j['b'] for j in m]);
 axs[1].scatter(xx[:2]*1e4,yy[:2],s=50,color=colors[i],marker='o',label=f'Calibration, prep {i+1}')
 axs[1].scatter(xx[2:]*1e4,yy[2:],s=90,color=colors[i],marker='*',label=f'Reserved window, prep {i+1}')
axs[0].axhline(.05,color='#444444',ls='--',lw=1,label='Principal coupling k = 0.05')
for left,right in [(0,.4),(.5,.9)]:axs[0].axvspan(left,right,color='#888888',alpha=.1)
axs[0].axvspan(1,1.4,color='#4B945B',alpha=.13)
axs[0].set(xlabel='E-fold time N',ylabel='Same-mode potential slip g(N)',title='Unknown initial waves remain in the response')
xx=np.linspace(0,max(m['s'] for c in d['cases'][:2] for m in c['records'][0]['moments'])*1.05,200)
axs[1].plot(xx*1e4,.05-(298/17)*xx,color='#333333',lw=1,label='Derived relation: b = k − A s')
axs[1].set(xlabel='Weighted s = U/V  (×10⁻⁴)',ylabel='Weighted b = L/V',title='Both preparations give the same parameter line')
for ax in axs:ax.grid(alpha=.15);ax.legend(fontsize=7.5,loc='best')
fig.suptitle('Synthetic vacuum-mode experiment — no observational data',fontsize=12)
for ext in ['png','pdf']:fig.savefig(p/f'WEIGHTED_INVERSE_v1.{ext}',dpi=180)
(p/'FIGURE_PROVENANCE_v1.json').write_text(json.dumps(dict(created_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),source='runs_v2/RESULTS.json',source_sha256=hashlib.sha256((out/'RESULTS.json').read_bytes()).hexdigest(),parameters='k=1/20, nu=1; two unknown preparations, fixed two calibration windows and one reserved window',meaning='Shows synthetic nuisance waves and invariant weighted relation; no empirical comparison or precision forecast.'),indent=2)+'\n')
