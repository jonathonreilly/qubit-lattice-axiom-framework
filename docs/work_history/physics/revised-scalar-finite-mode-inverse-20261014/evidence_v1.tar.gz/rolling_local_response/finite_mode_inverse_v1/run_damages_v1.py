from pathlib import Path
import json,hashlib,subprocess,datetime,time
p=Path(__file__).resolve().parent;root=p/'damages_v1';root.mkdir(exist_ok=False)
src=(p/'check_inverse_v2.py').read_text()
variants=[('wrong_weak_adjoint','wpp-wp+zz*zz*ww','wpp+wp+zz*zz*ww'),('wrong_inverse_A_sign',"aa=(m2['V']*m1['L']-m1['V']*m2['L'])/det","aa=(m1['V']*m2['L']-m2['V']*m1['L'])/det"),('missing_N_drag','zz*zz-state[1]-(zz*zz+av)*state[0]','zz*zz-(zz*zz+av)*state[0]'),('wrong_clock_mass_shift','nv)/(1-3*kv)-2','nv)/(1-3*kv)')]
records=[]
for name,old,new in variants:
 assert src.count(old)==1,(name,src.count(old))
 d=root/name;d.mkdir();f=d/'damaged.py';f.write_text(src.replace(old,new));cmd=['/usr/local/bin/python3',str(f),str(d/'profiles')];t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
 (d/'stdout.json').write_text(r.stdout);(d/'stderr.txt').write_text(r.stderr)
 data=json.loads(r.stdout);rec=dict(name=name,command=cmd,cwd=str(Path.cwd()),started_at=start,elapsed_seconds=time.monotonic()-t,timeout_seconds=180,source_sha256=hashlib.sha256(f.read_bytes()).hexdigest(),exit_code=r.returncode,counts=data['counts'],failed_witnesses=[x['name'] for x in data['checks'] if not x['passed']]);records.append(rec);(d/'RUN.json').write_text(json.dumps(rec,indent=2)+'\n');print(name,r.returncode,data['counts'],flush=True)
(root/'RESULTS.json').write_text(json.dumps(dict(original_sha256=hashlib.sha256(src.encode()).hexdigest(),actual_damages=records,all_rejected=all(x['exit_code'] and x['counts']['failed'] for x in records)),indent=2)+'\n')
