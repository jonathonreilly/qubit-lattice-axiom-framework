# Computed finite-wavelength controls

Direct author /root. New computations are mathematical controls and synthetic
examples; no experiment, fit, independent observation or realized source
preparation is claimed. The two hand sources were frozen before code.

Geometry v1 completed 53/0. Before damaged-copy tests, v2 added direct
covariant differentiation of the complete action force to bind the combined
mass matrix, increasing the count to 71/0. Vacuum-mode v1 completed 34/0;
v2 explicitly bound the numerical mass, coupling and B-2 clock shift to the
supplied action, increasing it to 37/0. Original sources and runs remain.
Each geometry run includes only two prescribed background coefficient states;
its assumed Omega values are not measured or verified perturbation rates.

The 7 actual damaged scripts were all rejected: reversing the mass curvature
sign failed18 controls, dropping its trace Hessian failed6, doubling the
source coupling failed2, omitting the clock mass shift failed1, changing the
asymptotic residual failed1, changing time damping failed1, and reversing the
energy identity sign failed1. Vacuum damages ran only the16 symbolic controls;
no numerical trajectory is claimed for those damaged copies. Exact commands,
outputs, source hashes and exit codes are preserved in damages_v1.

At the two prescribed rolling background points, using units Q=Hv=1,
k=1/20,nu=1,rhobar/Q=1/5, the K-orthonormal mass spectra are approximately
(1.89781,2.13521,19.42858) and (5.03075,6.72918,30.21286).
Those are local synthetic spectra, not a global stability result. If the
actual rates obeyed Omega<=Hv, at p=100Hv the sufficient relative-potential
bounds would be0.002433 and0.004183 respectively. The antecedent has not
been established for a realized perturbation. At p=Hv the maximum-row test
fails; this does not prove a physical instability or the absence of a better
approximation.

For the exact evolving vacuum subcase, B=332/17 and A=298/17. All six solver
profiles (3 initial/interval cases, DOP853 and Radau each) completed. Both
versions retain full301-site state profiles for each method. The maximum
scaled method difference in v2 is approximately1.48e-11. The bound checks
allow2e-11 numerical tolerance; the continuum certificate follows from the
energy proof rather than treating301 sampled sites as a uniform proof.

With the supplied P2 preparation and z=p/H falling from1000 to100, the final
exact numerical response is y=0.9982511680030767 and g_mode=0.04991255840015384,
compared with the principal coupling0.05. The P2 amplitude error is about
1.54e-8; its proved certificate is3.10e-7. The first and second N-derivative
certificates are3.10e-5 and0.003287. These are errors relative to P2; the
finite-z correction already present in P2 must also be included. For the
interval100to10 the amplitude error grows to0.01024, within a0.03096
certificate, with much weaker derivative certificates.

Adding initial homogeneous error0.1 leaves that term explicitly in the
certificate, despite the same action, background, source and wave-number
interval. This is the remaining preparation assumption. No imaginary
observational significance is assigned to the example. The physical source
amplitude can be scaled down to remain linear on each finite interval.

These results begin a quantitative finite-scale bridge. They do not turn
the prior drift/two-epoch inverses into validated observational estimators.
The calculation concerns a comoving Fourier potential mode; finite bodies,
fixed physical baselines, actual calibration and measured initial waves
still need their own response and readout models. A focused independent
check of the frozen hand sources is in progress, separate from these parent
counts and output files.
