#!/usr/local/bin/python3
"""Direct-author checks; coefficient examples do not establish rate premises."""
import json
import sympy as s
import numpy as np

checks = []
def check(name, value):
    ok = bool(value)
    checks.append({'name': name, 'pass': ok})
    return ok
def zero(name, expr):
    return check(name, s.simplify(expr) == 0)

u, x, y = q = s.symbols('u x y', real=True)
k=s.Rational(1,20); nu=s.Integer(1); Q=Hv=s.Integer(1)
a=(1-k)*(1+3*k)/4; alpha=s.sqrt(a); ss=(1+k)/(k*(1-3*k))
EE=s.exp(2*alpha*u); F=1+ss*EE; J=1+(1-3*a)*ss*EE
DD=1+2*(1+k)*(x*x+y*y)/3
metric=[J/F**2,(1+ss)*4*k/(9*F*DD),(1+ss)*k/(3*F*DD)]
coupling=(1+ss)*EE/F
U=s.Rational(3,2)+s.Rational(3,2)*ss*(EE-1)**2/F**2+k*x*x*s.exp(-(1-k)*u/alpha)/2+k*y*y*s.exp(-(1+k)*u/alpha)/3+nu*(1+ss)*u*u/(2*F**2)
blog=[alpha/F,s.Integer(0),s.Integer(0)]
states=[([0,0,0],[s.Rational(1,5),s.Rational(1,7),-s.Rational(1,11)]),
        ([0,1,-s.Rational(1,2)],[-s.Rational(1,10),s.Rational(1,4),s.Rational(1,6)])]
rows=[]
for site,(pos,vel) in enumerate(states):
    sub=dict(zip(q,pos)); ev=lambda z:s.simplify(z.subs(sub))
    d=[ev(t) for t in metric]
    d1=[[ev(s.diff(t,z)) for z in q] for t in metric]
    d2=[[[ev(s.diff(t,z,w)) for w in q] for z in q] for t in metric]
    G=[[[s.simplify(((d1[i][j] if i==l else 0)+(d1[i][l] if i==j else 0)-(d1[j][i] if j==l else 0))/(2*d[i])) for l in range(3)] for j in range(3)] for i in range(3)]
    G1=[[[[s.simplify(((d2[i][j][m] if i==l else 0)+(d2[i][l][m] if i==j else 0)-(d2[j][i][m] if j==l else 0))/(2*d[i])-G[i][j][l]*d1[i][m]/d[i]) for m in range(3)] for l in range(3)] for j in range(3)] for i in range(3)]
    # R^i_ljk is [R(d_j,d_k)d_l]^i, with the convention in the note.
    R=[[[[s.simplify(G1[i][h][l][j]-G1[i][j][l][h]+sum(G[i][j][m]*G[m][h][l]-G[i][h][m]*G[m][j][l] for m in range(3))) for h in range(3)] for j in range(3)] for l in range(3)] for i in range(3)]
    Jac=s.Matrix(3,3,lambda i,j:s.simplify(sum(R[i][l][j][h]*vel[l]*vel[h] for l in range(3) for h in range(3))))
    # Direct coordinate variation plus covariant correction, independently
    # arranged from the D_t^2+R expression. Acceleration is arbitrary here.
    acc=[s.Rational(1,13),-s.Rational(1,17),s.Rational(1,19)]
    conn=s.Matrix(3,3,lambda i,l:sum(G[i][j][l]*vel[j] for j in range(3)))
    conn_dt=s.Matrix(3,3,lambda i,l:sum(G1[i][j][l][m]*vel[j]*vel[m] for j in range(3) for m in range(3))+sum(G[i][j][l]*acc[j] for j in range(3)))
    geod=[acc[i]+sum(G[i][j][l]*vel[j]*vel[l] for j in range(3) for l in range(3)) for i in range(3)]
    coord=s.Matrix(3,3,lambda i,m:sum(G1[i][j][l][m]*vel[j]*vel[l] for j in range(3) for l in range(3))+sum(G[i][m][l]*geod[l] for l in range(3)))
    for i in range(3):
        for j in range(3):
            zero(f'site{site}_Jacobi_coordinate_{i}{j}',(conn_dt+conn*conn+Jac-coord)[i,j])
    Ud=[ev(s.diff(U,z)) for z in q]
    Ud2=s.Matrix(3,3,lambda i,j:ev(s.diff(U,q[i],q[j]))-sum(G[l][i][j]*Ud[l] for l in range(3)))
    bl=[ev(z) for z in blog]
    bH=s.Matrix(3,3,lambda i,j:ev(s.diff(blog[j],q[i]))-sum(G[l][i][j]*bl[l] for l in range(3)))
    gm=s.diag(*d); ig=gm.inv()
    bv=ig*s.Matrix(bl); V=ig*s.Matrix(Ud)
    T=-s.Rational(1,5); S=bv*T/2
    M=ig*Ud2+Jac-T*ig*bH/2
    for i in range(3):
        for j in range(i+1,3):
            zero(f'site{site}_self_adjoint_{i}{j}',(gm*M-M.T*gm)[i,j])
    for m in range(3):
        zero(f'site{site}_stress_covariance_{m}',sum(d[i]*vel[i]*G[i][j][m]*vel[j] for i in range(3) for j in range(3))-sum(d1[i][m]*vel[i]**2/2 for i in range(3)))
    v2=(s.Matrix(vel).T*gm*s.Matrix(vel))[0]
    H=s.sqrt((v2+2*ev(U)-T)/3)
    zero(f'site{site}_Friedmann',3*H**2-v2-2*ev(U)+T)
    g=(bv.T*gm*bv)[0]
    zero(f'site{site}_coupling',g-a/ev(J))
    dflt=np.array([float(z) for z in d]); half=np.diag(np.sqrt(dflt))
    Mn=half@np.array(M.evalf(),dtype=float)@np.linalg.inv(half)
    check(f'site{site}_numeric_symmetry',np.max(np.abs(Mn-Mn.T))<1e-12)
    eig=np.linalg.eigvalsh(Mn); mnorm=float(max(abs(eig)))
    norm=lambda vv:float(s.sqrt((vv.T*gm*vv)[0]))
    vn=float(s.sqrt(v2)); Vn=norm(V); SVn=norm(S-V); al=float(s.sqrt(g)); hn=float(H)
    if site==0:
        Mvac=ig*Ud2
        for i,val in enumerate([4*(3*(1+k)+nu)/(1-3*k),s.Rational(9,4),s.Integer(2)]):
            zero('vacuum_mass_'+str(i),Mvac[i,i]-val)
        zero('vacuum_b_derivative',bH[0,0]/d[0]+1+k)
    table=[]
    for Om in [1.,3.]:
        for p in [1.,10.,100.,1000.]:
            A=(3*hn**2+vn**2+3*abs(hn)*Om)/p**2
            B=(vn*Om+Vn)/p**2
            Cc=(4*vn*Om+2*SVn)/p**2
            Dd=(Om**2+3*abs(hn)*Om+mnorm)/p**2
            R2=np.array([[A,al*B],[Cc/al,Dd]])
            rr=float(np.max(np.sum(R2,axis=1)))
            eps=rr/(1-rr) if rr<1 else None
            table.append({'Omega_assumed':Om,'p':p,'r':rr,'epsilon_if_applicable':eps})
            # Comparison matrix saturation: exact (I-R)^-1 R 1 must obey
            # the max-row bound, when applicable. This tests algebra only.
            if rr<1:
                ee=np.linalg.solve(np.eye(2)-R2,R2@np.ones(2))
                check(f'site{site}_comparison_O{Om}_p{p}',min(ee)>=0 and max(ee)<=eps+1e-13)
    rows.append({'state':[str(z) for z in pos],'velocity':[str(z) for z in vel],'K':[str(z) for z in d],
                 'H':hn,'g':float(g),'speed_K':vn,'V_norm_K':Vn,'S_minus_V_norm_K':SVn,
                 'M_orthonormal':Mn.tolist(),'M_eigenvalues':eig.tolist(),'M_norm':mnorm,'conditional_table':table})

# Direct lapse and scalar-density normalization without model-specific data.
t,eps=s.symbols('t eps',real=True)
aa=s.Function('aa')(t); ph=s.Function('phi')(t); xi=s.Function('xi')(t)
Phi=s.Function('Phi')(t); Psi=s.Function('Psi')(t)
det=aa**3*(1+eps*(Phi-3*Psi)); invtt=-1+2*eps*Phi
box=s.diff(det*invtt*s.diff(ph+eps*xi,t),t)/det
lin=s.diff(box,eps).subs(eps,0)
expect=-s.diff(xi,t,2)-3*s.diff(aa,t)/aa*s.diff(xi,t)+2*Phi*(s.diff(ph,t,2)+3*s.diff(aa,t)/aa*s.diff(ph,t))+(s.diff(Phi,t)+3*s.diff(Psi,t))*s.diff(ph,t)
zero('lapse_direct_volume_variation',lin-expect)

result={'role':'exact identities and actual model coefficient samples; no realized perturbation rate bound','passed':sum(c['pass'] for c in checks),'failed':sum(not c['pass'] for c in checks),'checks':checks,'coefficient_states':rows}
print(json.dumps(result,indent=2))
raise SystemExit(1 if result['failed'] else 0)
