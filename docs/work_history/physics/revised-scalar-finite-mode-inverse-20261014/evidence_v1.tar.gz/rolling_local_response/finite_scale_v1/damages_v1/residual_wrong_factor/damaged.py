#!/usr/local/bin/python3
"""Exact residual identities and source-bound finite-interval solver controls."""
from pathlib import Path
import json
import time
import sys
import sympy as s
import numpy as np
from scipy.integrate import solve_ivp

out=Path(__file__).resolve().parent/'vacuum_runs_v2'
out.mkdir(exist_ok=False)
checks=[]
def check(name,x):
    checks.append({'name':name,'pass':bool(x)})
def zero(name,x):check(name,s.simplify(x)==0)
z,A=s.symbols('z A',positive=True)
k=s.Rational(1,20); nu=s.Integer(1)
B=4*(3*(1+k)+nu)/(1-3*k); Av=B-2
P=1-A/z**2+A*(A+6)/z**4
res=A*(A+6)*(A+21)/z**6
zero('n2_residual',s.diff(P,z,2)+(1+A/z**2)*P-1-res)
for n in range(5):
    coeff=s.Integer(1); poly=coeff
    for j in range(n):
        coeff=-coeff*(A+2*j*(2*j+1));poly+=coeff/z**(2*j+2)
    zero(f'finite_residual_n{n}',s.diff(poly,z,2)+(1+A/z**2)*poly-1-coeff*(A+2*n*(2*n+1))/z**(2*n+2))
yy=s.Function('yy')(z)
zero('N_clock_operator',z*s.diff(z*s.diff(yy,z),z)-z*s.diff(yy,z)-z*z*s.diff(yy,z,2))
# Volume-lapse derived scalar mode: xi=a^-1 y(t), constant H.
t,H=s.symbols('t H',positive=True); f=s.Function('f')(t); pp=s.symbols('pp',positive=True)
xx=s.exp(-H*t)*f
zero('vacuum_factoring',s.exp(H*t)*(s.diff(xx,t,2)+3*H*s.diff(xx,t)+(pp**2+(A+2)*H**2)*xx)-(s.diff(f,t,2)+H*s.diff(f,t)+(pp**2+A*H**2)*f))
zero('Einstein_momentum',s.diff(s.exp(-H*t),t)+H*s.exp(-H*t))
zero('Einstein_pressure',s.diff(s.exp(-H*t),t,2)+4*H*s.diff(s.exp(-H*t),t)+3*H**2*s.exp(-H*t))
hp,h=s.symbols('hp h',real=True); om2=1+A/z**2
energy=(hp*hp+om2*h*h)/2
ed=s.diff(energy,z)+s.diff(energy,h)*hp+s.diff(energy,hp)*(-om2*h)
zero('energy_derivative',ed+A*h*h/z**3)
scaled=h*h+hp*hp/om2
sd=s.diff(scaled,z)+s.diff(scaled,h)*hp+s.diff(scaled,hp)*(-om2*h)
zero('normalized_energy_derivative',sd-2*A*hp*hp/(z**3*om2**2))
check('candidate_A_positive',Av>0)

# Bind the actual mass and clock shift to the supplied action before using A.
uu=s.symbols('uu',real=True)
aa=(1-k)*(1+3*k)/4; al=s.sqrt(aa); ss=(1+k)/(k*(1-3*k))
ee=s.exp(2*al*uu); ff=1+ss*ee; jj=1+(1-3*aa)*ss*ee
Ku=jj/ff**2
U0=s.Rational(3,2)+3*ss*(ee-1)**2/(2*ff**2)+nu*(1+ss)*uu**2/(2*ff**2)
zero('actual_mass_from_action',(s.diff(U0,uu,2)/Ku).subs(uu,0)-B)
zero('actual_clock_shift',Av-B+2)
zero('actual_coupling_from_action',((al/ff)**2/Ku).subs(uu,0)-k)
if '--symbolic-only' in sys.argv:
    result={'role':'symbolic controls only; no numerical trajectories rerun','passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks),'checks':checks}
    print(json.dumps(result,indent=2));raise SystemExit(1 if result['failed'] else 0)

af=float(Av); coef=af*(af+6)*(af+20)
summary=[]
for tag,z0,z1,e0 in [('short',1000.,100.,0.),('stress',100.,10.,0.),('free_wave',1000.,100.,.1)]:
    sites=np.linspace(z0,z1,301)
    def rhs(zv,ev):return [ev[1],-(1+af/zv**2)*ev[0]-coef/zv**6]
    runs=[]
    for method,rtol,atol in [('DOP853',1e-10,1e-12),('Radau',2e-11,2e-13)]:
        start=time.monotonic()
        sol=solve_ivp(rhs,(z0,z1),[e0,0.],method=method,rtol=rtol,atol=atol,max_step=.2,t_eval=sites)
        elapsed=time.monotonic()-start
        rec={'method':method,'success':bool(sol.success),'message':sol.message,'nfev':sol.nfev,'seconds':elapsed,'rtol':rtol,'atol':atol,'max_step':.2,'z':sol.t.tolist(),'e':sol.y[0].tolist(),'e_z':sol.y[1].tolist()}
        (out/f'{tag}_{method}.json').write_text(json.dumps(rec,indent=2)+'\n')
        check(f'{tag}_{method}_complete',sol.success and len(sol.t)==301 and abs(sol.t[-1]-z1)<1e-12)
        if not sol.success: raise RuntimeError(f'{tag} {method}: {sol.message}')
        runs.append(sol)
    rel=float(np.max(np.abs(runs[0].y-runs[1].y)/(1+np.abs(runs[1].y))))
    check(tag+'_method_agreement',rel<1e-7)
    bound=abs(e0)+coef/5*(sites**-5-z0**-5)
    omega=np.sqrt(1+af/sites**2)
    ev,ep=runs[1].y
    epp=-omega**2*ev-coef/sites**6
    en=-sites*ep; enn=sites**2*epp+sites*ep
    first=sites*omega*bound
    second=sites**2*(omega**2*bound+coef/sites**6)+sites*omega*bound
    for name,observed,bb in [('coefficient',ev,bound),('z_derivative',ep,omega*bound),('N_first',en,first),('N_second',enn,second)]:
        check(tag+'_'+name+'_bound',np.all(np.abs(observed)<=bb+2e-11))
    poly=1-af/sites**2+af*(af+6)/sites**4
    actual=poly+ev
    excess=float(k)*actual
    rec={'tag':tag,'z0':z0,'z1':z1,'initial_error':e0,'max_method_scaled_discrepancy':rel,
         'end_y':float(actual[-1]),'end_g_mode':float(excess[-1]),'end_principal_g':float(k),
         'end_y_error_from_P2':float(ev[-1]),'end_error_certificate':float(bound[-1]),
         'end_N_first_error_certificate':float(first[-1]),'end_N_second_error_certificate':float(second[-1]),
         'max_abs_preparation_plus_truncation_error':float(np.max(np.abs(ev))),
         'D0_is_supplied':True}
    summary.append(rec)
result={'role':'conditional exact evolving-mode certificates and synthetic prepared histories, no observed state or experimental comparison','A_exact':str(Av),'B_exact':str(B),'passed':sum(x['pass'] for x in checks),'failed':sum(not x['pass'] for x in checks),'checks':checks,'cases':summary}
print(json.dumps(result,indent=2))
raise SystemExit(1 if result['failed'] else 0)
