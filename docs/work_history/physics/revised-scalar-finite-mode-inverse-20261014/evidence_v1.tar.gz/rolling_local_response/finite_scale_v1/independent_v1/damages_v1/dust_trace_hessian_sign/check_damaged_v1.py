#!/usr/bin/env python3
"""Independent finite-scale controls; no producer imports or source execution.

The six visible formula constants are actual damaged-copy targets. Reference
identities are derived independently below. Numerical results are diagnostics,
not rigorous numerical enclosures. The analytic energy proof is in the hand file.
"""
import argparse
import csv
import hashlib
import json
import platform
import sys
import time
from pathlib import Path

import numpy as np
import scipy
import sympy as sp
from scipy.integrate import solve_ivp

CURVATURE_SIGN = 1
DUST_HESSIAN_SIGN = 1
LAPSE_SIGN = 1
RECURRENCE_LINEAR_SIGN = 1
INTEGRAL_DIRECTION = 1
N_SECOND_CHAIN_TERM = 1

parser = argparse.ArgumentParser()
parser.add_argument("--output-dir", required=True)
parser.add_argument("--exact-only", action="store_true")
args = parser.parse_args()
out = Path(args.output_dir)
out.mkdir(parents=True, exist_ok=True)
checks = []
details = {}
start = time.time()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def record(name, passed, witness=None):
    item = {"name": name, "passed": bool(passed)}
    if witness is not None:
        item["witness"] = witness
    checks.append(item)
    print(("PASS " if passed else "FAIL ") + name, flush=True)


def zero(name, expression):
    vals = list(expression) if isinstance(expression, sp.MatrixBase) else [expression]
    residual = [sp.factor(sp.simplify(v)) for v in vals]
    record(name, all(v == 0 for v in residual), [str(v) for v in residual])


def action(k, nu):
    u, x, y = sp.symbols("u x y", real=True)
    aa = (1-k)*(1+3*k)/4
    alpha = sp.sqrt(aa)
    ss = (1+k)/(k*(1-3*k))
    EE = sp.exp(2*alpha*u)
    FF = 1+ss*EE
    JJ = 1+(1-3*aa)*ss*EE
    DD = 1+sp.Rational(2, 3)*(1+k)*(x*x+y*y)
    KK = sp.diag(JJ/FF**2,
                 (1+ss)*4*k/(9*FF*DD),
                 (1+ss)*k/(3*FF*DD))
    CC = (1+ss)*EE/FF
    UU = (sp.Rational(3, 2)+3*ss*(EE-1)**2/(2*FF**2)
          +k*x*x*sp.exp(-(1-k)*u/alpha)/2
          +k*y*y*sp.exp(-(1+k)*u/alpha)/3
          +nu*(1+ss)*u*u/(2*FF**2))
    return (u, x, y), KK, CC, UU


# Actual supplied-action metric jets at a nontrivial permitted coupling.
k0, nu0 = sp.Rational(2, 17), sp.Rational(3, 5)
coords, KK, CC, UU = action(k0, nu0)
origin = dict.fromkeys(coords, 0)
ev = lambda expr: sp.simplify(expr.subs(origin))
K = KK.applyfunc(ev)
Ki = K.inv()
dK = [KK.diff(c).applyfunc(ev) for c in coords]
ddK = [[KK.diff(c).diff(d).applyfunc(ev) for d in coords] for c in coords]
dKi = [-Ki*dK[l]*Ki for l in range(3)]
G = [[[sp.simplify(sum(Ki[i, m]*(dK[j][m, k]+dK[k][m, j]-dK[m][j, k])
                           for m in range(3))/2)
       for k in range(3)] for j in range(3)] for i in range(3)]
dG = [[[[sp.simplify(sum(
            dKi[l][i, m]*(dK[j][m, k]+dK[k][m, j]-dK[m][j, k])
            +Ki[i, m]*(ddK[l][j][m, k]+ddK[l][k][m, j]-ddK[l][m][j, k])
            for m in range(3))/2)
         for k in range(3)] for j in range(3)] for i in range(3)] for l in range(3)]


def conn(vv, ww):
    return sp.Matrix([sum(G[i][j][k]*vv[j]*ww[k] for j in range(3) for k in range(3))
                      for i in range(3)])


# R^i_{m j k}: derivative j then k, R(X,Y)Z has X^j Y^k Z^m.
R = [[[[sp.simplify(dG[j][i][k][m]-dG[k][i][j][m]
        +sum(G[i][j][n]*G[n][k][m]-G[i][k][n]*G[n][j][m] for n in range(3)))
        for k in range(3)] for j in range(3)] for m in range(3)] for i in range(3)]
v = sp.Matrix([sp.Rational(2, 7), -sp.Rational(1, 5), sp.Rational(3, 11)])
xi = sp.Matrix([sp.Rational(1, 13), sp.Rational(2, 9), -sp.Rational(1, 8)])
w = sp.Matrix([-sp.Rational(2, 9), sp.Rational(1, 7), sp.Rational(3, 5)])
w2 = sp.Matrix([sp.Rational(1, 4), -sp.Rational(2, 3), sp.Rational(5, 17)])
vdot = sp.Matrix([-sp.Rational(3, 8), sp.Rational(2, 11), sp.Rational(1, 6)])
av = vdot+conn(v, v)
variation_acc = w2+sp.Matrix([
    sum(dG[l][i][j][k]*xi[l]*v[j]*v[k]
        for l in range(3) for j in range(3) for k in range(3))
    for i in range(3)])+2*conn(v, w)+conn(xi, av)
dt2xi = w2+sp.Matrix([
    sum(dG[l][i][j][k]*v[l]*v[j]*xi[k]
        for l in range(3) for j in range(3) for k in range(3))
    for i in range(3)])+conn(vdot, xi)+2*conn(v, w)+conn(v, conn(v, xi))
jacobi = sp.Matrix(3, 3, lambda i, j: sp.simplify(
    sum(R[i][m][j][k]*v[m]*v[k] for m in range(3) for k in range(3))))
zero("geometry.actual_metric_covariant_commutator",
     variation_acc-dt2xi-CURVATURE_SIGN*jacobi*xi)
record("geometry.curvature_witness_nonzero", any(sp.simplify(x) != 0 for x in jacobi*xi))
zero("geometry.lowered_jacobi_self_adjoint", K*jacobi-(K*jacobi).T)
record("geometry.positive_metric", all(K[i, i] > 0 for i in range(3)),
       [str(K[i, i]) for i in range(3)])

f = sp.log(CC)/2
bf = sp.Matrix([sp.diff(f, c) for c in coords]).applyfunc(ev)
hf = sp.hessian(f, coords).applyfunc(ev)
b = Ki*bf
db = sp.Matrix(3, 3, lambda i, j: sp.simplify(
    (dKi[j]*bf+Ki*hf[:, j])[i]+sum(G[i][j][m]*b[m] for m in range(3))))
zero("source.trace_hessian_self_adjoint", K*db-(K*db).T)
Tbar, Q = -sp.Rational(7, 5), sp.Rational(11, 6)
delta_T = sp.Rational(3, 8)
# This derivative is obtained by differentiating b*T, not by assuming a mass.
cov_delta_source = (Tbar*db*xi+b*delta_T)/(2*Q)
source_mass_piece = DUST_HESSIAN_SIGN*Tbar*db/(2*Q)
zero("source.total_trace_mass_sign",
     cov_delta_source+source_mass_piece*xi-b*delta_T/(2*Q))
record("source.trace_hessian_witness_nonzero", any(x != 0 for x in db*xi))
rho = sp.Rational(7, 5)
number_fixed_delta_rho = rho*(bf.dot(xi))
jordan_rho_fixed_delta_rho = 4*rho*(bf.dot(xi))
zero("source.fixed_number_density_conversion",
     number_fixed_delta_rho-rho*sum(sp.diff(sp.sqrt(CC), coords[i]).subs(origin)
                                  *xi[i] for i in range(3)))
zero("source.fixed_Jordan_density_conversion",
     jordan_rho_fixed_delta_rho-rho*sum(sp.diff(CC**2, coords[i]).subs(origin)
                                      *xi[i] for i in range(3)))
record("source.number_density_extra_rank_one_is_nonzero",
       sp.simplify(number_fixed_delta_rho) != 0,
       {"held_number_delta_rho":str(number_fixed_delta_rho),
        "held_Jordan_rho_delta_rho":str(jordan_rho_fixed_delta_rho)})

# Independent first-order wave-operator expansion of the Newtonian metric.
t, eps = sp.symbols("t eps", real=True)
af = sp.Function("af")(t)
pf = sp.Function("Phi")(t)
sf = sp.Function("Psi")(t)
phif = sp.Function("phi")(t)
xf = sp.Function("xi")(t)
sqrtg = af**3*(1+eps*(pf-3*sf))
dens_gtt = -af**3*(1-eps*(pf+3*sf))
minus_box = -sp.diff(dens_gtt*sp.diff(phif+eps*xf, t), t)/sqrtg
delta_acc = sp.simplify(sp.diff(minus_box, eps).subs(eps, 0))
plain_delta = sp.diff(xf, t, 2)+3*sp.diff(af,t)/af*sp.diff(xf,t)
force = ((sp.diff(pf,t)+3*sp.diff(sf,t))*sp.diff(phif,t)
         +2*pf*(sp.diff(phif,t,2)+3*sp.diff(af,t)/af*sp.diff(phif,t)))
zero("metric.direct_lapse_forcing_sign", delta_acc-plain_delta+LAPSE_SIGN*force)
sameforce = force.subs(sf, pf).doit()
zero("metric.zero_anisotropic_stress_factor_four",
     sameforce-4*sp.diff(pf,t)*sp.diff(phif,t)
     -2*pf*(sp.diff(phif,t,2)+3*sp.diff(af,t)/af*sp.diff(phif,t)))

# Density from the action, with lapse, metric variation and field variation.
Phi, Hv = sp.symbols("Phi Hv", real=True)
Kvar = sum((dK[j]*xi[j] for j in range(3)), sp.zeros(3))
Ugrad = sp.Matrix([sp.diff(UU, c) for c in coords]).applyfunc(ev)
delta_kin = sp.simplify(2*(v.T*K*w)[0]+(v.T*Kvar*v)[0]-2*Phi*(v.T*K*v)[0])
delta_density_over_2Q = delta_kin/2+Hv**2*Ugrad.dot(xi)
V = Hv**2*Ki*Ugrad
cov_density = (v.T*K*(w+conn(v,xi)))[0]-Phi*(v.T*K*v)[0]+(V.T*K*xi)[0]
zero("stress.action_density_covariance_and_lapse", delta_density_over_2Q-cov_density)
rho_phi_at_vac = 2*Q*sp.Rational(3, 2)*Hv**2
zero("stress.vacuum_energy_normalization", rho_phi_at_vac-3*Q*Hv**2)
# Hamiltonian ADM constraint with the action's Einstein coefficient Q/2.
H, p, Psidot, Psi = sp.symbols("H p Psidot Psi", real=True)
hloc = (H-eps*Psidot)/(1+eps*Phi)
R3 = -4*eps*p*p*Psi
rho_constraint_over_2Q = (R3+6*hloc**2)/4
delta_constraint = sp.diff(rho_constraint_over_2Q,eps).subs(eps,0)
zero("einstein.00_ADM_normalization_and_sign",
     delta_constraint+p*p*Psi+3*H*(Psidot+H*Phi))
details["metric_jet"] = {"k":str(k0), "nu":str(nu0), "K0":str(K),
    "b0":str(b), "Jacobi_times_xi":str((jacobi*xi).applyfunc(sp.simplify)),
    "trace_Hessian_times_xi":str((db*xi).applyfunc(sp.simplify))}

# Comparison theorem: exact residual subtraction plus one rational matrix witness.
Pr, Prd, Phi0, vd, vx, v2, srcV, MM, xid, xidd, X, bb = sp.symbols(
    "Pr Prd Phi0 vd vx v2 srcV MM xid xidd X bb", real=True)
einstein_equation = p*p*(Pr-Phi0)+3*H*(Prd+H*Pr)+vd-v2*Pr+vx
metric_residual = (Pr-Phi0)-(-3*H*Prd-3*H*H*Pr-vd+v2*Pr-vx)/(p*p)
zero("bound.metric_residual_subtraction", metric_residual-einstein_equation/(p*p))
vscalar = sp.symbols("vscalar", real=True)
scalar_equation = xidd+3*H*xid+(p*p+MM)*X-4*vscalar*Prd-2*srcV*Pr-p*p*bb*Phi0
scalar_residual = X-bb*Phi0-(4*vscalar*Prd+2*srcV*Pr-xidd-3*H*xid-MM*X)/(p*p)
zero("bound.scalar_residual_subtraction", scalar_residual-scalar_equation/(p*p))
Rt = sp.Matrix([[sp.Rational(1,8),sp.Rational(1,20)],
                [sp.Rational(1,12),sp.Rational(1,7)]])
one = sp.ones(2,1)
equality_e = (sp.eye(2)-Rt).inv()*Rt*one
r = max(sum(Rt.row(i)) for i in range(2))
bound_e = r/(1-r)
record("bound.rational_row_norm_witness",
       all(x >= 0 and x <= bound_e for x in equality_e),
       {"R":str(Rt),"e":str(equality_e),"r":str(r),"epsilon":str(bound_e),
        "scope":"algebraic comparison witness, not a physical solution"})
de1, de2, gg = sp.symbols("de1 de2 gg", real=True)
phij = (1+de1)+gg*(1+de2)
zero("bound.excess_ratio_error_identity",
     phij/(1+de1)-1-gg-gg*(de2-de1)/(1+de1))
record("bound.hypotheses_not_inferred", True,
       "Actual solution rates, nonzero source, alpha>0 and r<1 are premises; no derivative conclusion from amplitude bound.")

# Exact action vacuum masses, g, linear stress and conserved first-order source.
k, nu = sp.symbols("k nu", positive=True)
cs, Km, Cm, Um = action(k, nu)
org = dict.fromkeys(cs,0)
KV = Km.subs(org).applyfunc(sp.factor)
KVI = KV.inv().applyfunc(sp.factor)
bVl = sp.Matrix([sp.diff(sp.log(Cm)/2,c).subs(org) for c in cs])
UVg = sp.Matrix([sp.diff(Um,c).subs(org) for c in cs])
mass = (KVI*sp.hessian(Um,cs).subs(org)).applyfunc(sp.factor)
Bvac = 4*(3*(1+k)+nu)/(1-3*k)
zero("vacuum.coupling_norm_from_action", (bVl.T*KVI*bVl)[0]-k)
zero("vacuum.actual_action_stationarity", UVg)
zero("vacuum.mass_coupled_from_action", mass[0,0]-Bvac)
zero("vacuum.mass_transverse_x_from_action", mass[1,1]-sp.Rational(9,4))
zero("vacuum.mass_transverse_y_from_action", mass[2,2]-2)
zero("vacuum.mass_offdiagonal", mass-sp.diag(Bvac,sp.Rational(9,4),2))
zero("vacuum.B_minus_12_positive_form", Bvac-12-4*(12*k+nu)/(1-3*k))
N = sp.symbols("N", real=True)
rhohat, q, Qs, Hs = sp.symbols("rhohat q Qs Hs", positive=True)
rhomode = rhohat*sp.exp(-3*N)
pmode = q*sp.exp(-N)
phimode = -rhomode/(2*Qs*pmode**2)
zero("vacuum.dust_conservation", sp.diff(rhomode,N)+3*rhomode)
zero("vacuum.momentum_constraint", sp.diff(phimode,N)+phimode)
zero("vacuum.density_constraint", pmode**2*phimode+rhomode/(2*Qs))
zero("vacuum.spatial_pressure_equation",
     sp.diff(phimode,N,2)+4*sp.diff(phimode,N)+3*phimode)
small = sp.symbols("small")
rho_first, vel_first, phi_first = sp.symbols("rho_first vel_first phi_first")
zero("vacuum.dust_induced_momentum_is_second_order",
     sp.diff((small*rho_first)*(small*vel_first),small).subs(small,0))
zero("vacuum.dust_scalar_exchange_is_second_order",
     sp.diff((small*rho_first)*(small*phi_first),small).subs(small,0))
yn = sp.Function("yn")(N)
field_mode = phimode*yn
divided = sp.simplify((sp.diff(field_mode,N,2)+3*sp.diff(field_mode,N)
                      +(pmode**2/Hs**2+Bvac)*field_mode-pmode**2/Hs**2*phimode)/phimode)
zero("vacuum.factor_Phi0_reduction",
     divided-(sp.diff(yn,N,2)+sp.diff(yn,N)+(pmode**2/Hs**2+Bvac-2)*yn-pmode**2/Hs**2))

z, AA = sp.symbols("z AA", positive=True)
yz = sp.Function("yz")(z)
DN = lambda expr: -z*sp.diff(expr,z)
zero("vacuum.redshift_ODE",
     DN(DN(yz))+DN(yz)+(z*z+AA)*yz-z*z
     -z*z*(sp.diff(yz,z,2)+(1+AA/z**2)*yz-1))
zero("vacuum.physical_mean_exact",
     ((1+k*yz)+(1-k*yz))/2-1)
zero("vacuum.same_mode_excess", (1+k*yz)-1-k*yz)
details["vacuum_action"] = {"K0":str(KV),"mass_over_H2":str(mass),
                           "g":str(sp.factor((bVl.T*KVI*bVl)[0]))}


def finite_coeff(A, n):
    coeff = [sp.Integer(1)]
    for j in range(n):
        coeff.append(sp.expand(-(A+2*j*(2*j+RECURRENCE_LINEAR_SIGN))*coeff[-1]))
    return coeff


# Finite identities; analytic reference derivative has the untouched 2j(2j+1).
for n in range(7):
    coeff = finite_coeff(AA,n)
    poly = sum(coeff[j]*z**(-2*j) for j in range(n+1))
    residual = coeff[-1]*(AA+2*n*(2*n+1))*z**(-2*n-2)
    zero(f"residual.finite_n{n}",
         sp.diff(poly,z,2)+(1+AA/z**2)*poly-1-residual)
    z0 = sp.symbols("z0",positive=True)
    coeff_abs = (-1)**n*coeff[-1]*(AA+2*n*(2*n+1))
    integral_bound = INTEGRAL_DIRECTION*coeff_abs/(2*n+1)*(z**(-2*n-1)-z0**(-2*n-1))
    zero(f"energy.integral_derivative_n{n}",
         sp.diff(integral_bound,z)+coeff_abs*z**(-2*n-2))
    record(f"energy.integral_positive_n{n}",
           integral_bound.subs({AA:sp.Rational(1234,55),z:12,z0:80}) >= 0)
zero("residual.explicit_P2",
     sum(finite_coeff(AA,2)[j]*z**(-2*j) for j in range(3))
     -(1-AA/z**2+AA*(AA+6)/z**4))

# Direct complex forced-energy derivative, independent of Green-function claims.
er, ei, pr, pi, rr, ri = sp.symbols("er ei pr pi rr ri",real=True)
om2 = 1+AA/z**2
W2 = er*er+ei*ei+(pr*pr+pi*pi)/om2
W2prime = (sp.diff(W2,z)+sp.diff(W2,er)*pr+sp.diff(W2,ei)*pi
           +sp.diff(W2,pr)*(-om2*er-rr)+sp.diff(W2,pi)*(-om2*ei-ri))
energy_reference = 2*AA*(pr*pr+pi*pi)/(z**3*om2**2)-2*(pr*rr+pi*ri)/om2
zero("energy.normalized_complex_derivative", W2prime-energy_reference)
zero("energy.unscaled_homogeneous_derivative",
     sp.diff((pr*pr+pi*pi+om2*(er*er+ei*ei))/2,z)
     +(om2*er*pr+om2*ei*pi)+pr*(-om2*er)+pi*(-om2*ei)
     +AA*(er*er+ei*ei)/z**3)
zero("derivative.N_first_chain", DN(yz)+z*sp.diff(yz,z))
zero("derivative.N_second_chain",
     DN(DN(yz))-z*z*sp.diff(yz,z,2)-N_SECOND_CHAIN_TERM*z*sp.diff(yz,z))
# Explicit nonzero witness makes the missed chain term consequential.
test_e = z*z+3*z
zero("derivative.N_second_nonzero_witness",
     DN(DN(test_e))-z*z*sp.diff(test_e,z,2)-N_SECOND_CHAIN_TERM*z*sp.diff(test_e,z))

# A tiny physical potential amplitude can coexist with a rapidly varying scalar.
# This is exact initial data in the vacuum equation, not an arbitrary rate table.
Aw = sp.Rational(298,17)
zw = sp.Integer(1000)
cw = finite_coeff(Aw,2)
Pw = sum(cw[j]*z**(-2*j) for j in range(3))
Rw = cw[-1]*(Aw+20)*z**-6
ew, epw = sp.Rational(1,10),sp.Integer(0)
yw = Pw.subs(z,zw)+ew
yNz = DN(Pw).subs(z,zw)-zw*epw
eNNw = -zw**2*(1+Aw/zw**2)*ew-zw**2*Rw.subs(z,zw)+zw*epw
yNNw = DN(DN(Pw)).subs(z,zw)+eNNw
xiNN_over_xi = sp.factor((yNNw-2*yNz+yw)/yw)
record("preparation.slow_source_does_not_bound_scalar_second_rate",
       abs(xiNN_over_xi) > 4,
       {"Omega_over_H_attempt":2,"abs_xi_NN_over_xi":str(abs(xiNN_over_xi)),
        "abs_xi_NN_over_xi_float":float(abs(xiNN_over_xi)),
        "e0":"1/10","e0p":"0","z0":1000,
        "scope":"Violates |xi_tt|<=4 H^2 |xi| despite Phi0_t=-H Phi0."})

numerical_summaries = []
if not args.exact_only:
    specs = [
        ("distinct_n1",k0,nu0,1,80.,12.,0j,0j),
        ("distinct_n3",k0,nu0,3,40.,7.,0j,0j),
        ("distinct_complex_preparation",k0,nu0,3,80.,12.,.01+.02j,-.015+.005j),
        ("requested_k",sp.Rational(1,20),sp.Integer(1),2,100.,10.,0j,0j),
    ]
    methods = [
        ("DOP853",{"rtol":2e-11,"atol":3e-13,"max_step":.125}),
        ("Radau",{"rtol":1e-11,"atol":2e-13,"max_step":.125}),
    ]
    for label,kv,nv,n,z_start,z_end,e_start,ep_start in specs:
        Aval = sp.factor(4*(3*(1+kv)+nv)/(1-3*kv)-2)
        coeffs = finite_coeff(Aval,n)
        signed_rcoeff = coeffs[-1]*(Aval+2*n*(2*n+1))
        Afloat, rc = float(Aval),float(signed_rcoeff)
        grid = np.linspace(z_start,z_end,257)
        omega2 = 1+Afloat/grid**2
        residuals = rc*grid**(-2*n-2)
        D0 = np.sqrt(abs(e_start)**2+abs(ep_start)**2/(1+Afloat/z_start**2))
        D = D0+abs(rc)/(2*n+1)*(grid**(-2*n-1)-z_start**(-2*n-1))
        solutions = {}
        local_summary = {"name":label,"k":str(kv),"nu":str(nv),"n":n,
            "A":str(Aval),"residual_coefficient":str(signed_rcoeff),
            "z0":z_start,"z1":z_end,"D0":float(D0),"methods":[]}
        def rhs(zz, state):
            o = 1+Afloat/zz**2
            rr_here = rc*zz**(-2*n-2)
            return [state[2],state[3],-o*state[0]-rr_here,-o*state[1]]
        initial = [e_start.real,e_start.imag,ep_start.real,ep_start.imag]
        for method,kwargs in methods:
            sol = solve_ivp(rhs,(z_start,z_end),initial,method=method,t_eval=grid,**kwargs)
            record(f"numeric.{label}.{method}.success",sol.success,sol.message)
            info = {"method":method,"success":bool(sol.success),"message":sol.message,
                    "nfev":sol.nfev,"njev":sol.njev,"nlu":sol.nlu,"parameters":kwargs}
            if not sol.success or sol.y.shape != (4,257):
                info["actual_t"] = sol.t.tolist()
                info["actual_y"] = sol.y.tolist()
                local_summary["methods"].append(info)
                continue
            solutions[method] = sol.y.copy()
            error = sol.y[0]+1j*sol.y[1]
            error_prime = sol.y[2]+1j*sol.y[3]
            error_second = -omega2*error-residuals
            error_N = -grid*error_prime
            error_NN = grid**2*error_second+grid*error_prime
            energy_norm = np.sqrt(abs(error)**2+abs(error_prime)**2/omega2)
            measured = [energy_norm,abs(error),abs(error_prime),abs(error_second),
                        abs(error_N),abs(error_NN)]
            bounds = [D,D,np.sqrt(omega2)*D,omega2*D+abs(residuals),
                      grid*np.sqrt(omega2)*D,
                      grid**2*(omega2*D+abs(residuals))+grid*np.sqrt(omega2)*D]
            names = ["normalized_energy","amplitude","z_first","z_second","N_first","N_second"]
            info["bounds"] = {}
            for name,actual,limit in zip(names,measured,bounds):
                # This tolerance is explicitly diagnostic roundoff allowance.
                allowance = 2e-10*(1+limit)
                violations = int(np.count_nonzero(actual > limit+allowance))
                record(f"numeric.{label}.{method}.{name}",violations == 0,
                       {"violations":violations,
                        "max_excess":float(np.max(actual-limit)),
                        "max_measurement":float(np.max(actual)),
                        "max_bound":float(np.max(limit)),
                        "diagnostic_allowance":"2e-10*(1+bound)"})
                info["bounds"][name] = {"violations":violations,
                    "max_measurement":float(np.max(actual)),"max_bound":float(np.max(limit))}
            datafile = out/f"{label}_{method}.csv"
            with datafile.open("w",newline="") as stream:
                writer = csv.writer(stream)
                writer.writerow(["z","e_re","e_im","ez_re","ez_im","ezz_re","ezz_im",
                    "eN_re","eN_im","eNN_re","eNN_im","D","omega","residual","energy_norm",
                    "bound_ez","bound_ezz","bound_eN","bound_eNN"])
                writer.writerows(zip(grid,error.real,error.imag,error_prime.real,error_prime.imag,
                    error_second.real,error_second.imag,error_N.real,error_N.imag,
                    error_NN.real,error_NN.imag,D,np.sqrt(omega2),residuals,energy_norm,
                    bounds[2],bounds[3],bounds[4],bounds[5]))
            info["data_file"] = datafile.name
            info["data_sha256"] = digest(datafile)
            local_summary["methods"].append(info)
        if len(solutions) == 2:
            s1,s2 = solutions["DOP853"],solutions["Radau"]
            difference = float(np.max(abs(s1-s2)/(1+np.maximum(abs(s1),abs(s2)))))
            record(f"numeric.{label}.independent_method_agreement",difference < 1e-7,
                   {"scaled_max_difference":difference,"internal_threshold":1e-7})
            local_summary["scaled_method_disagreement"] = difference
        numerical_summaries.append(local_summary)

passed = sum(item["passed"] for item in checks)
result = {
    "scope":"Independent conditional linear mathematics and finite vacuum mode controls",
    "scientific_author":"/root","checker":"/root/scalar_energy_check",
    "producer_code_or_results_read":False,
    "exact_only":args.exact_only,
    "code_sha256":digest(__file__),
    "versions":{"python":sys.version,"platform":platform.platform(),
                "sympy":sp.__version__,"numpy":np.__version__,"scipy":scipy.__version__},
    "formula_constants":{"curvature":CURVATURE_SIGN,"trace_Hessian":DUST_HESSIAN_SIGN,
        "lapse":LAPSE_SIGN,"recurrence_linear":RECURRENCE_LINEAR_SIGN,
        "integral_direction":INTEGRAL_DIRECTION,"N_second_chain":N_SECOND_CHAIN_TERM},
    "counts":{"passed":passed,"failed":len(checks)-passed,"total":len(checks)},
    "checks":checks,"details":details,"numerical_summaries":numerical_summaries,
    "elapsed_seconds":time.time()-start,
    "limitations":["No full physical perturbation solver or cosmology integration",
        "Pointwise rate assumptions are not inferred from source/background slowness",
        "Finite initial preparation data remain free",
        "Numerical checks are diagnostics, not interval-certified solver bounds",
        "Fixed comoving mode is not a fixed physical-radius measurement",
        "No empirical, initial-state selection or formal audit conclusion"]
}
(out/"RESULTS_v1.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result["counts"]),flush=True)
sys.exit(0 if passed == len(checks) else 1)
