#!/usr/bin/env python3
"""Execute actual damaged independent formulas; retain sources, diffs and logs."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

base = Path(__file__).resolve().parent
source = base/"check_independent_v1.py"
text = source.read_text()
sha = lambda data: hashlib.sha256(data).hexdigest()
root = base/"damages_v1"
root.mkdir(exist_ok=True)
specs = [
    ("curvature_sign","CURVATURE_SIGN = 1","CURVATURE_SIGN = -1",
     "geometry.actual_metric_covariant_commutator"),
    ("dust_trace_hessian_sign","DUST_HESSIAN_SIGN = -1","DUST_HESSIAN_SIGN = 1",
     "source.total_trace_mass_sign"),
    ("lapse_forcing_sign","LAPSE_SIGN = 1","LAPSE_SIGN = -1",
     "metric.direct_lapse_forcing_sign"),
    ("finite_recurrence","RECURRENCE_LINEAR_SIGN = 1","RECURRENCE_LINEAR_SIGN = -1",
     "residual.finite_n2"),
    ("energy_integral_direction","INTEGRAL_DIRECTION = 1","INTEGRAL_DIRECTION = -1",
     "energy.integral_derivative_n0"),
    ("N_second_chain_term","N_SECOND_CHAIN_TERM = 1","N_SECOND_CHAIN_TERM = 0",
     "derivative.N_second_nonzero_witness"),
]
protocol = {
    "baseline_source":source.name,"baseline_sha256":sha(source.read_bytes()),
    "created_before_damage_execution":True,
    "scope":"Exact-only reruns of the independent checker; numerical trajectories are not rerun for these copies.",
    "expected":"Each actual altered formula must exit 1 through its named mathematical witness, not a syntax/runtime error.",
    "controls":[{"name":name,"old":old,"new":new,"named_witness":witness}
                for name,old,new,witness in specs],
}
(root/"PROTOCOL_v1.json").write_text(json.dumps(protocol,indent=2)+"\n")
records = []
for name,old,new,witness in specs:
    assert text.count(old) == 1, (name,"ambiguous damage target")
    folder = root/name
    folder.mkdir(exist_ok=True)
    damaged = text.replace(old,new,1)
    code = folder/"check_damaged_v1.py"
    code.write_text(damaged)
    (folder/"SOURCE.diff").write_text("".join(difflib.unified_diff(
        text.splitlines(True),damaged.splitlines(True),
        fromfile=source.name,tofile=name+"/check_damaged_v1.py")))
    command = [sys.executable,"-u",str(code),"--exact-only","--output-dir",str(folder/"output")]
    started = time.time()
    try:
        run = subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                             timeout=120,check=False,text=True)
        exit_code = run.returncode
        output = run.stdout
        exception = None
    except subprocess.TimeoutExpired as failure:
        output = failure.stdout or ""
        if isinstance(output,bytes):
            output = output.decode(errors="replace")
        exit_code = None
        exception = str(failure)
    logfile = folder/"EXECUTION.log"
    logfile.write_text(output)
    result_path = folder/"output"/"RESULTS_v1.json"
    result = json.loads(result_path.read_text()) if result_path.exists() else None
    failures = [c["name"] for c in result["checks"] if not c["passed"]] if result else []
    record = {"name":name,"named_witness":witness,
              "source_sha256":sha(code.read_bytes()),"log_sha256":sha(logfile.read_bytes()),
              "command":command,"exit_code":exit_code,"exception":exception,
              "elapsed_seconds":time.time()-started,
              "counts":result["counts"] if result else None,
              "failed_mathematical_checks":failures,
              "intended_witness_failed":witness in failures,
              "successfully_detected":exit_code == 1 and witness in failures,
              "output_sha256":sha(result_path.read_bytes()) if result else None}
    (folder/"EXECUTION_v1.json").write_text(json.dumps(record,indent=2)+"\n")
    records.append(record)
    print(json.dumps(record),flush=True)
summary = {"baseline_sha256":sha(source.read_bytes()),"controls":records,
           "detected":sum(r["successfully_detected"] for r in records),"total":len(records),
           "scope":"Six executed altered independent formulas. No producer damage claim is made."}
(root/"RESULTS_v1.json").write_text(json.dumps(summary,indent=2)+"\n")
sys.exit(0 if summary["detected"] == summary["total"] else 1)
