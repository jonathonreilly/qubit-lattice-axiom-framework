#!/usr/bin/env python3
"""Bind current independent evidence without changing any original artifact."""
import csv
import datetime
import difflib
import hashlib
import json
from pathlib import Path

base = Path(__file__).resolve().parent
root = base
while not (root/"docs"/"EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md").exists():
    if root == root.parent:
        raise RuntimeError("Cannot find known action in repository")
    root = root.parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def entry(relative):
    file = base/relative
    return {"path":str(relative),"bytes":file.stat().st_size,"sha256":digest(file)}


def load(relative):
    return json.loads((base/relative).read_text())


def save_new(relative, value):
    path = base/relative
    if path.exists():
        raise RuntimeError("Refusing to overwrite "+str(path))
    path.write_text(json.dumps(value,indent=2)+"\n")


checks = []


def check(name, condition, detail=None):
    checks.append({"name":name,"passed":bool(condition),"detail":detail})


sources = load("SOURCE_MANIFEST_v1.json")["sources"]
corr = load("SOURCE_CORRESPONDENCE_v2.json")
sources = sources+corr["source_bindings"]
for row in sources:
    original, snapshot = root/row["original_path"], base/row["snapshot_path"]
    check("source:"+row["snapshot_path"],
          original.is_file() and not original.is_symlink()
          and snapshot.is_file() and not snapshot.is_symlink()
          and original.stat().st_size == snapshot.stat().st_size == row["bytes"]
          and digest(original) == digest(snapshot) == row["sha256"])

run = load("RUN_v1.json")
baseline = load("baseline_v1/RESULTS_v1.json")
check("baseline.code_hash",
      digest(base/"check_independent_v1.py") == run["code_sha256"] == baseline["code_sha256"])
check("baseline.result_hash",digest(base/"baseline_v1/RESULTS_v1.json") == run["results_sha256"])
check("baseline.original_log_hash",digest(base/"baseline_v1.log") == run["log_sha256"])
check("baseline.counts",baseline["counts"] == {"passed":125,"failed":0,"total":125}
      and all(c["passed"] for c in baseline["checks"]))
check("baseline.original_exit",run["observed_exit_code"] == 0)
check("baseline.log_counts",
      (base/"baseline_v1.log").read_text().splitlines()[-1]
      == '{"passed": 125, "failed": 0, "total": 125}')
check("correspondence.eight_only_prose_checks",
      corr["counts"] == {"passed":8,"failed":0}
      and all(c["passed"] for c in corr["checks"]))
for case in baseline["numerical_summaries"]:
    for method in case["methods"]:
        csvpath = base/"baseline_v1"/method["data_file"]
        with csvpath.open() as stream:
            rows = list(csv.reader(stream))
        check("numeric:"+method["data_file"],
              digest(csvpath) == method["data_sha256"]
              and len(rows) == 258 and all(len(row) == 19 for row in rows)
              and method["success"]
              and all(v["violations"] == 0 for v in method["bounds"].values()),
              {"rows_including_header":len(rows),"columns":len(rows[0])})

damage = load("damages_v1/RESULTS_v1.json")
protocol = load("damages_v1/PROTOCOL_v1.json")
source_text = (base/"check_independent_v1.py").read_text()
check("damage.original_source",
      digest(base/"check_independent_v1.py")
      == damage["baseline_sha256"] == protocol["baseline_sha256"])
for record, spec in zip(damage["controls"],protocol["controls"]):
    name = record["name"]
    folder = base/"damages_v1"/name
    modified = folder/"check_damaged_v1.py"
    result = load(str((folder/"output/RESULTS_v1.json").relative_to(base)))
    expected_text = source_text.replace(spec["old"],spec["new"],1)
    expected_diff = "".join(difflib.unified_diff(
        source_text.splitlines(True),expected_text.splitlines(True),
        fromfile="check_independent_v1.py",tofile=name+"/check_damaged_v1.py"))
    check("damage.source_and_diff:"+name,
          modified.read_text() == expected_text
          and source_text.count(spec["old"]) == 1
          and (folder/"SOURCE.diff").read_text() == expected_diff
          and digest(modified) == record["source_sha256"] == result["code_sha256"])
    check("damage.output_binding:"+name,
          digest(folder/"EXECUTION.log") == record["log_sha256"]
          and digest(folder/"output/RESULTS_v1.json") == record["output_sha256"]
          and record["exit_code"] == 1 and record["exception"] is None
          and record["successfully_detected"] and record["intended_witness_failed"]
          and result["exact_only"]
          and result["counts"]["total"] == 65
          and spec["named_witness"] in record["failed_mathematical_checks"])
check("damage.six_actual_detections",
      damage["detected"] == damage["total"] == len(damage["controls"]) == 6)
binding = {
    "scope":"Source/snapshot and actual independent execution artifact correspondence",
    "checks":checks,
    "counts":{"passed":sum(c["passed"] for c in checks),
              "failed":sum(not c["passed"] for c in checks)},
    "producer_execution_claim":False,
}
save_new("EVIDENCE_BINDING_v1.json",binding)
if not all(c["passed"] for c in checks):
    raise RuntimeError("Binding failure retained; receipt not sealed")

artifact_paths = sorted(p for p in base.rglob("*") if p.is_file()
                        and p.name not in {"MANIFEST_v1.json","RECEIPT_v1.json"})
if any(p.is_symlink() for p in artifact_paths):
    raise RuntimeError("Unexpected symlink")
manifest = {
    "schema":"focused-independent-evidence-manifest-v1",
    "scope":"All current evidence payloads; manifest and receipt excluded to avoid self-hash cycles",
    "artifacts":[entry(p.relative_to(base)) for p in artifact_paths],
    "artifact_count":len(artifact_paths)
}
save_new("MANIFEST_v1.json",manifest)
receipt = {
    "schema":"focused-independent-mathematical-check-receipt-v1",
    "sealed_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "checker":"/root/scalar_energy_check","scientific_author":"/root",
    "formal_audit":False,
    "scope":"Exact covariant linear scalar/metric equations; conditional rate-dependent comparison; conserved first-order vacuum comoving-source mode; finite residual, preparation-dependent energy and N-derivative bounds.",
    "outcome":"No equation correction found. Two narrowly clarified v2 prose spans distinguish scalar-excitation density/momentum from constant vacuum stress. Preparation, actual-rate and readout limitations remain essential.",
    "source_bindings":sources,
    "hand_derivation":entry("HAND_DERIVATION_v1.md"),
    "protocol":entry("PROTOCOL_v1.json"),
    "report":entry("REPORT_v1.md"),
    "manifest":dict(entry("MANIFEST_v1.json"),artifact_count=len(artifact_paths)),
    "main_execution":{
        "run":entry("RUN_v1.json"),
        "result":entry("baseline_v1/RESULTS_v1.json"),
        "code":entry("check_independent_v1.py"),
        "log":entry("baseline_v1.log"),
        "counts":baseline["counts"],
        "non_numerical_records":65,"numerical_records":60,
        "actual_solver_executions":8,
        "observed_exit_code":0,
        "numerical_summaries":baseline["numerical_summaries"],
        "numerical_status":"Diagnostics with stated tolerance; no rigorous numerical enclosure claimed."
    },
    "actual_damaged_executions":{
        "protocol":entry("damages_v1/PROTOCOL_v1.json"),
        "results":entry("damages_v1/RESULTS_v1.json"),
        "controls":damage["controls"],
        "scope":"Six actual altered independent formulas, exact-only executions; no damaged numeric trajectories or producer coverage claim."
    },
    "source_v2_correspondence":{
        "record":entry("SOURCE_CORRESPONDENCE_v2.json"),
        "counts":corr["counts"],
        "mathematics_rerun":False,
        "original_v1_executions_preserved":True,
        "change":"Only scalar-excitation versus constant-vacuum-stress prose; equations and numerical protocol unchanged."
    },
    "failure_history":entry("FAILURES_v1.json"),
    "evidence_binding":dict(entry("EVIDENCE_BINDING_v1.json"),counts=binding["counts"]),
    "conclusions":{
        "covariant_signs":"Positive R(xi,v)v, negative Tbar nabla_xi b/(2Q) in M, and positive 4v Phi_dot+2(S-V)Phi forcing follow from direct variation.",
        "normalization":"Action Einstein coefficient Q/2 and scalar kinetic coefficient Q give the displayed density and 00 factors.",
        "conditional_bound":"Nonnegative maximum-row-sum argument is valid under actual solution rate and nonzero-amplitude premises; it does not establish those premises.",
        "source_conservation":"Cold comoving density proportional to a^-3 with zero linear momentum/pressure is consistent about zero background dust; induced exchange and momentum enter at second order.",
        "mode_equation":"For fixed comoving q on the stated vacuum, y_zz+[1+(B-2)/z^2]y=1 and g_mode=k y.",
        "energy":"A direct normalized forced-energy identity proves the finite decreasing-z certificate for real or complex errors; e_NN=z^2 e_zz+z e_z.",
        "preparation":"Free initial error D0 is not selected. Exact initial data give |xi_NN/xi| about 90911 despite the slow Phi0 source.",
        "readout":"The comoving Fourier potential coefficient does not equal a static fixed physical-radius readout without further source, transform, boundary and measurement work."
    },
    "limitations":[
        "General equations and inequality do not close the full constrained matter/metric perturbation problem.",
        "General actual-rate hypotheses are not inferred from source or background slowness.",
        "Vacuum source has zero background matter and explicitly chosen scalar initial data on a finite weak-field interval.",
        "Finite asymptotic sum only; no convergence, small-z uniformity or nonlinear error theorem.",
        "Numerical sampling and cross-solver agreement are diagnostics alongside the analytic proof.",
        "No finite-body, orbit, clock, remote lensing or other calibrated observational transfer inferred.",
        "No empirical data, full cosmological history, initial-state selection or formal audit conclusion."
    ],
    "independence":{
        "hand_derivation_and_protocol_saved_before_checker":True,
        "producer_checker_or_results_read_imported_or_run":False,
        "action_functions_independently_implemented":True,
        "distinct_parameters_and_complex_initial_data":True,
        "new_empirical_data":False,"subagents_or_other_chats":False,
        "writes_outside_this_folder":False,
        "parent_science_git_PR_runtime_lock_or_audit_state_changed":False,
        "prior_evidence_changed":False
    },
    "seal_policy":"Immutable evidence. Later source changes require a new correspondence addendum."
}
save_new("RECEIPT_v1.json",receipt)
print(json.dumps({"artifact_count":len(artifact_paths),"source_pairs":len(sources),
                  "binding_counts":binding["counts"],
                  "report":entry("REPORT_v1.md"),
                  "manifest":entry("MANIFEST_v1.json"),
                  "receipt":entry("RECEIPT_v1.json")},indent=2))
