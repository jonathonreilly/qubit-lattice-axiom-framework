#!/usr/local/bin/python3
from pathlib import Path
import hashlib,json,subprocess,datetime,time
p=Path(__file__).resolve().parent
out=p/'damages_v1';out.mkdir(exist_ok=False)
spec=[
 ('mass_curvature_sign','check_geometry_v2.py','M=ig*Ud2+Jac-T*ig*bH/2','M=ig*Ud2-Jac-T*ig*bH/2',[]),
 ('omit_trace_hessian','check_geometry_v2.py','M=ig*Ud2+Jac-T*ig*bH/2','M=ig*Ud2+Jac',[]),
 ('double_matter_coupling','check_geometry_v2.py','bv=ig*s.Matrix(bl);','bv=2*ig*s.Matrix(bl);',[]),
 ('omit_clock_mass_shift','check_vacuum_mode_v2.py','Av=B-2','Av=B',['--symbolic-only']),
 ('residual_wrong_factor','check_vacuum_mode_v2.py','res=A*(A+6)*(A+20)/z**6','res=A*(A+6)*(A+21)/z**6',['--symbolic-only']),
 ('wrong_time_damping','check_vacuum_mode_v2.py','s.diff(xx,t,2)+3*H*s.diff(xx,t)','s.diff(xx,t,2)+2*H*s.diff(xx,t)',['--symbolic-only']),
 ('wrong_energy_sign','check_vacuum_mode_v2.py',"zero('energy_derivative',ed+A*h*h/z**3)","zero('energy_derivative',ed-A*h*h/z**3)",['--symbolic-only'])
]
records=[]
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
for label,filename,before,after,args in spec:
    src=p/filename;body=src.read_text();assert body.count(before)==1,(label,body.count(before))
    folder=out/label;folder.mkdir()
    copy=folder/'damaged.py';copy.write_text(body.replace(before,after))
    cmd=['/usr/local/bin/python3',str(copy),*args]
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
    rr=subprocess.run(cmd,cwd=folder,text=True,capture_output=True,timeout=45)
    op=folder/'stdout.json';ep=folder/'stderr.txt';op.write_text(rr.stdout);ep.write_text(rr.stderr)
    parsed=json.loads(rr.stdout)
    record={'label':label,'before':before,'after':after,'command':cmd,'cwd':str(folder),'started_at':started,'elapsed_seconds':time.monotonic()-t,'timeout_seconds':45,'exit_code':rr.returncode,'passed':parsed['passed'],'failed':parsed['failed'],'rejected':rr.returncode!=0 and parsed['failed']>0,'original_source_sha256':sha(src),'damaged_source_sha256':sha(copy),'stdout_sha256':sha(op),'stderr_sha256':sha(ep)}
    (folder/'RUN.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
result={'actual_executed_damages':len(records),'all_rejected':all(r['rejected'] for r in records),'records':records}
(out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'actual_executed_damages':len(records),'all_rejected':result['all_rejected'],'counts':[(r['label'],r['passed'],r['failed']) for r in records]},indent=2))
raise SystemExit(0 if result['all_rejected'] else 1)
