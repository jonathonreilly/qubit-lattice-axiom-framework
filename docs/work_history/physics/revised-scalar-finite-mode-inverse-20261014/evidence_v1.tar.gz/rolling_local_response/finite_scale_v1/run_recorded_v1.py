#!/usr/local/bin/python3
"""Preserve exact executions; never overwrite existing output records."""
from pathlib import Path
import subprocess,hashlib,json,datetime,time,sys
p=Path(__file__).resolve().parent
for name in sys.argv[1:]:
    script=p/name;stem=script.stem.upper()
    record=p/(stem+'_RUN_v1.json')
    if record.exists(): raise FileExistsError(record)
    cmd=['/usr/local/bin/python3',str(script)]
    start=datetime.datetime.now(datetime.timezone.utc).isoformat();timer=time.monotonic()
    try:
        r=subprocess.run(cmd,cwd=p,capture_output=True,text=True,timeout=180)
        stdout=r.stdout;stderr=r.stderr;code=r.returncode;timed=False
    except subprocess.TimeoutExpired as e:
        stdout=e.stdout or '';stderr=e.stderr or '';code=None;timed=True
        if isinstance(stdout,bytes):stdout=stdout.decode(errors='replace')
        if isinstance(stderr,bytes):stderr=stderr.decode(errors='replace')
    op=p/(stem+'_stdout_v1.json');ep=p/(stem+'_stderr_v1.txt')
    op.write_text(stdout);ep.write_text(stderr)
    sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
    d={'command':cmd,'cwd':str(p),'started_at':start,'elapsed_seconds':time.monotonic()-timer,'timeout_seconds':180,'timeout':timed,'exit_code':code,'source_sha256':sha(script),'stdout_path':str(op),'stdout_sha256':sha(op),'stderr_path':str(ep),'stderr_sha256':sha(ep)}
    record.write_text(json.dumps(d,indent=2)+'\n')
    print(json.dumps(d))
    if code!=0: print(stderr[-3000:]);raise SystemExit(1)
