#!/usr/bin/env python3
"""Exact barrier algebra and future histories from fixed decimal endpoints."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, time, traceback
import numpy as np
import sympy as sp
from scipy.integrate import solve_ivp

P=Path(__file__).resolve().parent; PACK=P.parent
spec=importlib.util.spec_from_file_location('parent_initial_probe',P/'check_initial_state_v1.py')
init=importlib.util.module_from_spec(spec);spec.loader.exec_module(init)
ex,lim=init.ex,init.lim

def exact_checks():
    k,E,chi,w=sp.symbols('k E chi w',positive=True)
    a=(1-k)*(1+3*k)/4;s=(1+k)/(k*(1-3*k));F=1+s*E;J=1+(1-3*a)*s*E;C=(1+s)*E/F
    items={
        'potential_coupling_coordinate':C-1-(E-1)/F,
        'coupling_rational_identity':a/J-k*(1-s*(C-1))/(1-3*k*s*(C-1)),
        'coupling_derivative':sp.diff(k*(1-chi)/(1-3*k*chi),chi)-k*(3*k-1)/(1-3*k*chi)**2,
        'coordinate_inverse':(s*(E-1)/(1+s*E)-chi).subs(E,(1+chi/s)/(1-chi)),
        'potential_barrier':(sp.Rational(3,2)*s*(E-1)**2/F**2-sp.Rational(3,2)*chi**2/s).subs(E,(1+chi/s)/(1-chi)),
        'Phi_derivative_in_w':sp.diff(3*(w-sp.log(1+w)),w)-3*w/(1+w),
        's_greater_one':s-1-(1+3*k*k)/(k*(1-3*k)),
        'critical_nu_range':6*a-sp.Rational(3,2)-3*k*(2-3*k)/2,
    }
    # Exact completing-the-square identity used in the work bound.
    H,z,f=sp.symbols('H z f',positive=True)
    items['young_energy_bound']=-3*H*H*z*z+f*z-(f*f/(12*H*H)-3*H*H*(z-f/(6*H*H))**2)
    N=sp.symbols('N',nonnegative=True)
    items['future_exponential_integral']=sp.integrate(sp.exp(-6*N)/12,(N,0,sp.oo))-sp.Rational(1,72)
    return [{'name':n,'passed':sp.cancel(v)==0,'reduced':str(sp.factor(sp.cancel(v)))} for n,v in items.items()]

def Phi(z):
    w=np.sqrt(2*z/3)
    return 3*(w-np.log1p(w))

def energy(L,z,k,c):
    if k==0:
        q=lim.quantities(L,z);Z=.5*q['B']*q['T']+q['W'];S=q['sig']
        return dict(Z=float(Z),sigma=float(q['sig']),C=1.,S=float(S),coefficient=1.,H2=float(q['B']),chart=True)
    q=ex.quantities(L,z,c,256);u,x,y=q['phi'];a,b,s,nu=[c[t] for t in ['a','b','s','nu']];E=np.exp(2*np.sqrt(a)*u);F=1+s*E
    # Avoid subtracting the constant3/2 from a rounded total potential.
    dU=1.5*s*np.expm1(2*np.sqrt(a)*u)**2/F**2+b*x*x*np.exp(-c['lambda_x']*u)/2+b*y*y*np.exp(-c['lambda_y']*u)/3+nu*(1+s)*u*u/(2*F**2)
    Z=s*(.5*q['H2']*q['norm']+dU);S=q['sigma']*np.sqrt(((1+s)/s)/q['CB'])
    return dict(Z=float(Z),sigma=float(q['sigma']),C=float(q['CB']),S=float(S),coefficient=float(s*k),H2=float(q['H2']),chart=bool(q['njp']>0 and q['norm']<3 and min(q['K'])>0))

def run(case,solver,protocol,out):
    source=json.loads((PACK/case['path']).read_text());k=source['case']['k'];startrow=source['rows'][-1];L0=startrow['L'];z0=np.array(startrow['state']);c=lim.c if k==0 else ex.cfg(k,256)
    e0=energy(L0,z0,k,c);budget=e0['coefficient']*e0['S']**2/72;bound=Phi(e0['Z'])+budget;cap=Phi(1.5);begin=time.monotonic();last={}
    def rhs(L,z):
        last.update(L=float(L),state=z.tolist())
        if time.monotonic()-begin>protocol['wall_seconds_per_case']:raise TimeoutError('Frozen future case wall cap')
        return lim.rhs(L,z) if k==0 else ex.rhs(L,z,c,256)
    label=source['case']['id']+'_'+solver['method'];rows=[]
    try:
        sol=solve_ivp(rhs,(L0,L0+protocol['future_L_span']),z0,method=solver['method'],rtol=solver['rtol'],atol=solver['atol'],max_step=solver['max_step'],t_eval=np.linspace(L0,L0+protocol['future_L_span'],protocol['sites']))
        success=bool(sol.success and len(sol.t)==protocol['sites']);message=sol.message
        for L,z in zip(sol.t,sol.y.T):
            e=energy(L,z,k,c);rows.append({'L':float(L),'state':z.tolist(),**e,'Phi':float(Phi(e['Z'])),'strict_barrier_margin':float(cap-Phi(e['Z'])),'global_budget_excess':float(Phi(e['Z'])-bound)})
    except Exception as exc:
        success=False;message=repr(exc);(out/(label+'.traceback.txt')).write_text(traceback.format_exc())
    row={'id':label,'k':k,'solver':solver,'initial_source':case,'initial_L':L0,'initial_state':z0.tolist(),'initial_energy':e0,'strict_theorem_margin':float(cap-bound),'success':success,'message':message,'seconds':time.monotonic()-begin,'last_evaluation':last,'rows':rows}
    (out/(label+'.json')).write_text(json.dumps(row,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'case':label,'success':success,'margin':row['strict_theorem_margin'],'seconds':row['seconds'],'end_Z':rows[-1]['Z'] if rows else None}),flush=True)
    return row

def main(protocol_path,out):
    out.mkdir(exist_ok=False);protocol=json.loads(protocol_path.read_text());checks=exact_checks()
    for r in protocol['inputs']:checks.append({'name':'input.'+r['path'],'passed':hashlib.sha256((PACK/r['path']).read_bytes()).hexdigest()==r['sha256']})
    if not all(r['passed'] for r in checks):raise RuntimeError('Frozen algebra or source check failed before histories')
    runs=[]
    for case in protocol['cases']:
        pair=[run(case,s,protocol,out) for s in protocol['solvers']];runs+=pair
        for r in pair:
            checks.append({'name':r['id']+'.complete','passed':r['success']})
            checks.append({'name':r['id']+'.strict_initial_region','passed':r['strict_theorem_margin']>0})
            if r['success']:
                excess=max(row['global_budget_excess'] for row in r['rows']);checks.append({'name':r['id']+'.sampled_bound','passed':excess<protocol['energy_tolerance'],'max_excess':excess})
                checks.append({'name':r['id']+'.chart','passed':all(x['chart'] for x in r['rows'])})
        if all(r['success'] for r in pair):
            A,B=[np.array([x['state'] for x in r['rows']]) for r in pair];err=float(np.max(abs(A-B)/np.maximum(1,abs(B))));checks.append({'name':case['path']+'.solver_agreement','passed':err<protocol['state_tolerance'],'error':err})
    for r in protocol['inputs']:checks.append({'name':'unchanged.'+r['path'],'passed':hashlib.sha256((PACK/r['path']).read_bytes()).hexdigest()==r['sha256']})
    summary={'scope':'Conditional future integrations from exact stored decimal initial states; not rigorous enclosure of earlier histories, not empirical tests. Exact algebra complements the handwritten proof.','checks':checks,'counts':{'passed':sum(r['passed'] for r in checks),'failed':sum(not r['passed'] for r in checks)},'runs':[{k:v for k,v in r.items() if k not in ['rows','last_evaluation']}|{'endpoint':r['rows'][-1] if r['rows'] else None} for r in runs]}
    (out/'SUMMARY.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n');print(summary['counts'],flush=True);return int(summary['counts']['failed']>0)

if __name__=='__main__':
    pa=argparse.ArgumentParser();pa.add_argument('--protocol',type=Path,required=True);pa.add_argument('--out',type=Path,required=True);args=pa.parse_args();raise SystemExit(main(args.protocol,args.out))
