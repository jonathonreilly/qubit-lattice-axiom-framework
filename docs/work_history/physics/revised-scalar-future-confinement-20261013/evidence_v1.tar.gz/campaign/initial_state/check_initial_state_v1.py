#!/usr/bin/env python3
"""Parent-authored frozen initial-state probe; independent review is separate."""
from pathlib import Path
import argparse, hashlib, importlib.util, json, time, traceback
import numpy as np
from scipy.integrate import solve_ivp
import sympy as sp

P=Path(__file__).resolve().parent
PACK=P.parent
INH=PACK/'inherited/cosmology/direct_exponential_completion'
spec=importlib.util.spec_from_file_location('inherited_limit',INH/'check_regular_limit_v1.py')
lim=importlib.util.module_from_spec(spec);spec.loader.exec_module(lim)
ex=lim.ex

def exact_radiation():
    u,z,p,q,c=sp.symbols('u z p q c',real=True)
    f=sp.Matrix([p,q+2,-p+p*p/2-q*q+4*sp.exp(2*z-u),-q+p*q-2*sp.exp(2*z-u)])
    fixed={u:c,z:c/2,p:0,q:-2};J=f.jacobian([u,z,p,q]).subs(fixed)
    lam=sp.Symbol('lambda');cp=sp.factor(J.charpoly(lam).as_expr())
    return {'jacobian':str(J),'characteristic_polynomial':str(cp),
            'fixed_residual':[str(sp.simplify(v)) for v in f.subs(fixed)],
            'checks':{'fixed_family':f.subs(fixed)==sp.zeros(4,1),
                      'characteristic':sp.expand(cp-lam*(lam+1)*(lam*lam+lam+16))==0}}

def solve(case,protocol,out):
    name=case['id'];start=time.monotonic();last={};k=case['k'];n=protocol['nodes']
    c=lim.c if k==0 else ex.cfg(k,n)
    def rhs(L,z):
        last.update(L=float(L),state=z.tolist())
        if time.monotonic()-start>protocol['wall_seconds_per_case']:raise TimeoutError('Frozen per-case wall cap')
        return lim.rhs(L,z) if k==0 else ex.rhs(L,z,c,n)
    rows=[]
    try:
        sol=solve_ivp(rhs,(0,c['Lf']),case['initial'],method=protocol['method'],rtol=protocol['rtol'],atol=protocol['atol'],max_step=protocol['max_step'],t_eval=np.linspace(0,c['Lf'],protocol['sites']))
        success=bool(sol.success and len(sol.t)==protocol['sites']);message=sol.message
        for L,z in zip(sol.t,sol.y.T):
            v=lim.quantities(L,z) if k==0 else ex.quantities(L,z,c,n)
            row={'L':float(L),'state':z.tolist(),'NJ':v['gas']['NJ']}
            if k==0:
                row.update(C_exp=float(v['C']),energy=float(.5*v['B']*v['T']+v['W']),potential=float(v['W']))
            else:row.update(Hratio=float(v['Hratio']),GNratio=float(v['GNratio']),kinetic_norm=float(v['norm']))
            rows.append(row)
    except Exception as error:
        success=False;message=repr(error);(out/(name+'.traceback.txt')).write_text(traceback.format_exc())
    result={'case':case,'success':success,'message':message,'seconds':time.monotonic()-start,'last_evaluation':last,'rows':rows}
    (out/(name+'.json')).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'case':name,'success':success,'seconds':result['seconds'],'last_L':last.get('L'),'endpoint':rows[-1] if rows else None}),flush=True)
    return result

def main(protocol_path,out):
    out.mkdir(exist_ok=False)
    protocol=json.loads(protocol_path.read_text());checks=[]
    for row in protocol['inputs']:
        actual=hashlib.sha256((PACK/row['path']).read_bytes()).hexdigest()
        checks.append({'name':'input.'+row['path'],'passed':actual==row['sha256']})
    if not all(x['passed'] for x in checks):raise RuntimeError('Frozen source identity mismatch')
    algebra=exact_radiation();runs=[solve(case,protocol,out) for case in protocol['cases']]
    checks += [{'name':'radiation.'+n,'passed':bool(v)} for n,v in algebra['checks'].items()]
    for row in protocol['inputs']:
        checks.append({'name':'unchanged.'+row['path'],'passed':hashlib.sha256((PACK/row['path']).read_bytes()).hexdigest()==row['sha256']})
    summary={'scope':'Fixed conditional model development; deterministic initial-state probes, no selected-state or empirical acceptance claim.','algebra':algebra,'runs':[{'case':r['case'],'success':r['success'],'seconds':r['seconds'],'endpoint':r['rows'][-1] if r['rows'] else None} for r in runs],'checks':checks,'completed':sum(r['success'] for r in runs),'attempted':len(runs),'check_failures':sum(not x['passed'] for x in checks)}
    (out/'SUMMARY.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    return int(summary['check_failures']>0 or summary['completed']!=summary['attempted'])

if __name__=='__main__':
    pa=argparse.ArgumentParser();pa.add_argument('--protocol',type=Path,required=True);pa.add_argument('--out',type=Path,required=True);a=pa.parse_args();raise SystemExit(main(a.protocol,a.out))
