# Independent hand derivation: finite-k future confinement

Checker: `/root/scalar_energy_check`. The parent remains the science author.
This is a focused mathematical check, not a formal audit or a change of status.
Sources are the two byte-pinned snapshots in `SOURCE_MANIFEST_v1.json`.
The derivation below starts with the supplied action, not the author's runner.
It checks the conditional homogeneous statement; it does not derive the action
or certify an observed, fitted, or numerically reconstructed initial state.

## 1. Normalization and direct variation

Fix `0<k<1/3`, `nu>0`, `Q=Q0(1+k)>0`, and `Hv>0`. The dimensional action is

    S = Q int sqrt(-g)[R/2 - K_AB g^{mu nu} d_mu phi^A d_nu phi^B
                      - 2 Hv^2 U] + Sm[C g,psi].

Take signature `(-,+,+,+)`, an isotropic fluid, and an expanding flat FLRW
solution. Write `theta=Hv t_hat`, `v=dphi/dtheta`, `H=Hhat/Hv`, and
`N=log a_hat`. If rho_J and P_J are dimensional physical densities, then

    sigma = C^2 rho_J/(2 Q Hv^2), pi=C^2 P_J/(2 Q Hv^2).

If the displayed densities have instead been divided by a fixed positive
rho_unit, insert rho_unit in both numerators. This is the needed definition
of Rstar. V1 uses Rstar without defining it; positivity of this coefficient
is necessary for its nonnegative-matter arguments. No measured normalization
follows from this definition.

With `A=sqrt(C)`, `q_A=d_A log A=alpha_B delta_Au`, the matter variation is
`delta Sm=int sqrt(-g) T_E q_A delta phi^A`, where
`T_E=-rho_E+3P_E=-2QHv^2 tau`, `tau=sigma-3pi`. Thus direct scalar variation
and the Einstein constraint give

    D_theta v^A + 3H v^A + K^{AB} U_B = -K^{AB}q_B tau,
    3H^2 = K_AB v^A v^B + 2U + 2sigma.

The factor of two in the action and density normalization matters. For
example, replacing the force by `-2 K^{-1}q tau` is not this action's equation.
For a diagonal metric, define independent lowered momenta `m_i=K_i v_i`.
The same variation gives

    d_theta m_i = -3H m_i + (1/2) sum_j (d_i K_j) v_j^2
                  - U_i - q_i tau.

The numerical checker evolves this last system. Its coefficients and
derivatives are generated directly from the action expressions.

Metric compatibility, or explicit cancellation using the momentum equation,
gives for `e=(1/2)Kv^2+U-3/2`

    d_theta e = -3H Kv^2 - alpha_B tau v_u,
    e' = -3H^2 T - alpha_B tau p_u,
    3H^2 = 2(e+3/2+sigma),        T=Kp^2, p=v/H.

The scalar and fluid exchange terms have opposite signs. Their sum implies

    H'/H = -T - (sigma+pi)/H^2.

This also verifies the acceleration coefficient used below independently of
the energy-bound manipulation.

## 2. Domains, clock orientation, and density dilution

Algebra at fixed k gives

    a=(1+2k-3k^2)/4 in (1/4,1/3),
    1-3a=(1-3k)^2/4>0,
    s-1=(1+3k^2)/(k(1-3k))>0.

For every finite field value, `E>0`, `F>1`, `J>1`, `D>=1`, so all diagonal
entries of K are positive. Every extra potential term is nonnegative, hence
`e>=0`, `U>=3/2`, and `H>=1` on the expanding branch. Dividing Friedmann by
H^2 shows `T=3-2(U+sigma)/H^2<3`.

Since `alpha_B^2/K_u=a/J<a`,

    |alpha_B p_u| <= sqrt((a/J)T) < sqrt(3a)<1,
    N_J'=1+alpha_B p_u >= delta_k=1-sqrt(3a)>0.

No prior compactness hypothesis is used here. The lower bound is positive for
each fixed admissible k, but degenerates as k approaches 1/3. It is not a
uniform endpoint statement.

Physical conservation along this oriented clock gives

    rho_J(N_J) <= rho_J0 exp[-3(N_J-N_J0)]

when `P_J>=0`. Because
`N_J-N_J0=N-N0+(1/2)log(C/C0)` and `rho_E=C^2 rho_J`,

    sigma <= sigma0 sqrt(C/C0) exp[-3(N-N0)]
          <= S exp[-3(N-N0)],
    S=sigma0 sqrt(Cmax/C0), Cmax=(1+s)/s.

This includes vacuum sigma0=0. The upper pressure condition is used separately
to ensure `0<=tau<=sigma`; the dilution inequality itself needs only
nonnegative pressure. Neither tau nor C must be monotone. Differentiating
sigma directly gives `sigma'=-3(sigma+pi)+alpha_B tau p_u`, confirming the
exchange identity above.

## 3. An exact variable links coupling and the potential

Define `chi=s(C-1)=s(E-1)/F`, which is unrelated to the field x. Its exact
range is `(-s,1)`, its derivative with respect to E is positive, and

    E=(1+chi/s)/(1-chi),
    Z=s e >= (3/2)chi^2,
    a/J=k(1-chi)/(1-3k chi).

The last denominator is positive on the physical range. The derivative of
the rational expression with respect to chi is

    k(3k-1)/(1-3k chi)^2 < 0.

Write `w=sqrt(2Z/3)>=|chi|`. Monotonicity between `-w` and chi therefore
gives

    a/J <= k(1+w)/(1+3kw) <= k(1+w).

This remains valid when w exceeds s, even though `-w` then lies outside the
physical chi range: the rational function is defined and decreasing along
the entire comparison interval, with positive denominator. This detail
prevents the comparison step from silently presupposing trapping.

## 4. The integrated barrier and its constants

With `t=sqrt(T)`, the exchange term satisfies

    -alpha_B tau p_u <= sigma sqrt(a/J)t,
    -3H^2 t^2 + sigma sqrt(a/J)t <= sigma^2(a/J)/(12H^2).

The maximum is over the larger domain `t>=0`; the actual constraint `t<sqrt(3)`
can only make it smaller. Thus

    Z' <= s k sigma^2 (1+w)/(12H^2).

Let `Phi(Z)=3[w-log(1+w)]`. Differentiation gives
`Phi'(Z)=1/(1+w)`, with continuous right derivative 1 at zero. Phi is C1
on the energy half-line, strictly increasing, and unbounded. Extending it
locally as a C1 function at zero makes the ordinary chain rule immediate;
alternatively, apply the one-sided chain rule to the nonnegative C1 energy.
No second derivative at zero is required.

Consequently

    (Phi(Z))' <= s k S^2 exp[-6(N-N0)]/12,
    Phi(Z(N)) <= Phi(Z0)+s k S^2(1-exp[-6(N-N0)])/72.

The factor 72 is the product 12*6. All bounds used so far hold on any local
finite-field solution, with no circular appeal to the desired compact set.
If `B=Phi(Z0)+s k S^2/72 < Phi(3/2)`, monotonicity supplies the finite
`Zstar=Phi^{-1}(B)<3/2`, and then `Z<=Zstar`, `wstar=sqrt(2Zstar/3)<1`.
Equality at the threshold is intentionally excluded; it does not give a
strict finite upper bound on u through this argument.

## 5. Explicit compact box and continuation

Monotonic inversion of chi gives the positive finite bounds

    Elo=(1-wstar/s)/(1+wstar),
    Ehi=(1+wstar/s)/(1-wstar),
    ulo=log(Elo)/(2alpha), uhi=log(Ehi)/(2alpha).

Then the transverse potential terms give, for example,

    x^2 <= 2Zstar exp(lambda_x uhi)/(s k),
    y^2 <= 3Zstar exp(lambda_y uhi)/(s k).

The fixed positive exponents and k are finite. K and its inverse, first
derivatives, and connection are bounded on a slightly larger finite field
box. The minimum eigenvalue of K is strictly positive there. Since
`Kv^2<=2Zstar/s`, velocities and p are bounded. Furthermore

    1 <= H^2 <= 1+(2/3)(Zstar/s+S).

For a given smooth fluid history on all `N_J>=N_J0`, use state
`(phi,m,N_J)` and N as time. Its equations are smooth; H is the positive
square root of the constraint. On a hypothetical finite maximal N interval,
`N_J'<=1+sqrt(3a)` bounds N_J as well. Thus the trajectory lies in a compact
subset of a smooth ODE chart and extends across that endpoint. This proves
existence for every future N. Also `N_J>=N_J0+delta_k(N-N0)` tends to infinity.
H's upper bound implies infinite Einstein proper future time too.

The word “future” in the fluid hypothesis must mean a history defined for
all future N_J (or a smooth EOS whose conservation solution is globally
defined there). Smoothness merely on an arbitrarily truncated open interval
would not itself be a global continuation premise. No globally bounded
derivative of the EOS is needed: the state equations use rho and P values.

This is dynamical confinement for the supplied solution; it neither completes
the target metric geometrically nor covers arbitrary starting states.

## 6. Dissipation, critical points, and convergence

Retaining half the negative quadratic term gives

    e' <= -(3/2)H^2 T + sigma^2(a/J)/(6H^2)
        <= -(3/2)T + a S^2 exp[-6(N-N0)]/6.

After integration and use of `e>=0`,

    int_{N0}^infty T dN <= (2/3)(e0+a S^2/36) < infinity.

The exact p equation derived from the action is

    p'^A = -(3-T-(sigma+pi)/H^2)p^A - Gamma^A_BC p^B p^C
           - H^(-2) K^{AB}(U_B+q_B tau).

Every coefficient is bounded in the compact field box, and `0<=pi<=sigma/3`.
Thus p' is bounded without a bound on the time derivative of pi. Uniform
positive definiteness of K and square-integrability of p imply `p->0`:
a nonzero sequence of excursions would, by the common Lipschitz bound,
contain disjoint intervals of common positive width and common positive
L2 cost. This is the elementary uniform-continuity argument, not an
unjustified inference from integrability alone.

For completeness, if `phi(N_n)->phi*` but `dU(phi*)!=0`, choose a component
of `K^{-1}dU` nonzero at phi*. In a fixed neighborhood it has fixed sign and
is bounded away from zero. For sufficiently large n, `p->0` keeps the field
inside that neighborhood for a fixed short interval. Terms proportional to
p, p^2, and tau vanish uniformly; H is bounded above and below. Hence the
same component of p' has a fixed sign and a fixed nonzero lower magnitude
throughout the interval. Its integral contradicts `p->0`. Every accumulation
point is consequently a critical point of U.

At a critical point, `U_x=k x exp(-lambda_x u)=0` and
`U_y=(2k/3)y exp(-lambda_y u)=0`, so x=y=0. Set `t=2alpha u`. Direct
differentiation, including the u-dependence of F, gives

    U_u = (1+s)s exp(t)/(2alpha F^3) G(t),
    G(t)=12a(exp(t)-1)+nu t(1-t)+nu t/(s exp(t)).

The prefactor is strictly positive. Every term is negative for t<0. For t>0,
`exp(t)-1>=t+t^2/2` gives

    G(t)>=(12a+nu)t+(6a-nu)t^2+nu t/(s exp(t))>0

under `0<nu<=6a`. Hence only `(u,x,y)=(0,0,0)` is critical. Compactness and
uniqueness of the accumulation point imply convergence of the complete
trajectory. With p->0, H bounded, and sigma->0, the constraint gives H^2->1;
the coupling gives C->1. Since `6a>3/2`, the stated choice nu=1 is included.

## 7. Scope and attempted objections

- Positive gravitational/density normalization must be explicit; defining
  Rstar handles units but does not determine Q0, Hv, or a measured density.
- Nonnegative potential/kinetic terms, an expanding flat branch, fixed k,
  and a future fluid history are indispensable premises of this proof.
- No monotonicity of the trace, no bounded EOS derivatives, no initial
  scalar-fluid matching, and no pre-existing compactness is needed.
- `k->0`, `k->1/3`, a threshold-equality basin, inhomogeneous perturbations,
  quantum stability, observed initial-state selection, and certified prior
  numerical integration are not proved.
- The sufficient nu range is not established as necessary. Numerical and
  sign-bracket controls outside it test that unconditional convergence is
  not accidentally claimed.
- The source proof and the reasoning here are ordinary mathematical proofs,
  not a Lean certificate. The floating-point trajectories are diagnostics,
  not an interval-enclosed existence proof.

The core conditional argument is consistent under these explicit premises.
Any subsequent source correction must be checked against its new bytes;
the V1 snapshot alone cannot confer coverage on a later version.
