# Why convergence must retain a restriction on nu

This is an expected negative control outside the proposed theorem's
convergence hypotheses, not a finding against that theorem. It uses only the
already checked action and G factorization. It does not establish that the
particular sufficient range `nu<=6a` is sharp.

Set `k=1/100`, `nu=100`, `x=y=0`, `sigma=0`, and set all velocities to zero.
The future dynamics are stationary at every zero of

    G(t)=12a(exp(t)-1)+nu t(1-t)+nu t/(s exp(t)), t=2alpha u.

The checker `check_nu_scope_v1.py` bounds exp(7) and exp(8) by exact rational
Taylor partial sums and geometric tail bounds. It proves

    G(7)<0, G(8)>0,
    h(7)>0, h'(7)>0,
    h(t)=6exp(t)+3(1/s-1)-nu t^2/(4a).

The intermediate value theorem gives a zero t* in (7,8). Since exp(t)/t
increases for t>1, h'(7)>0 implies h'(t)>0 for every t>=7; therefore
h(t*)>0. Direct algebra at zero velocity and x=y=0 gives

    3/2-Z = s(1+s) h(t)/(2F^2).

Consequently this nonzero stationary state has `Z<3/2` and obeys the strict
confinement inequality (S=0). It does not converge to u=0. Exact rational
sign evidence is preserved; no decimal root is required for the argument.
The 80-digit auxiliary root diagnostic is

    t* approximately 7.32289047931366376339,
    u* approximately 7.25180853643795254712,
    Z* approximately 1.49915815084586275327.

This checks that the source correctly separates confinement for arbitrary
positive nu from convergence under an additional sufficient nu condition.
