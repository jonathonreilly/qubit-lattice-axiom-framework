# Actual operational record

- Read both assigned derivations fully, repository AGENTS pointer, current origin/ai/execution AGENTS, current origin/main SCIENCE_WORKFLOW, and scoped workhorse mechanism.
- First file inventory command exited 2 because it included nonexistent top-level inherited/ and initial_state/ paths alongside the actual .claude/ tree. Relevant assigned paths were found.
- First workflow lookup used origin/ai/execution; git reported that the workflow does not exist on that planning branch. Corrected to origin/main as directed by planning AGENTS.
- One workflow-read call used a workdir missing its leading slash and failed before process creation. Reran with the correct absolute workdir.
- Fetched origin ai/execution for the instructed planning read. No commit, push, merge, audit mutation, producer import, or edit outside the assigned independent_energy_v1 folder was performed.
- Python available: 3.12.8; SymPy 1.14.0; SciPy 1.17.0; mpmath 1.3.0.

Scientific check runs and mutations are recorded separately in results/. A mutation intentionally rejected by the checker is an expected negative control, not a failure of the source theorem.

## Completed scientific commands

- `python3 check_action_identity_v1.py --output results/action_identity_run01.json`: exit 0; full stdout/stderr preserved.
- `python3 check_future_flow_v1.py --output results/future_flow_run01.json`: exit 1 after first trajectory, due to NumPy boolean JSON serialization; original code, traceback, and first trajectory preserved.
- Converted check flags to built-in bool; no equation, tolerance, initial state, or criterion changed.
- `python3 check_future_flow_v1.py --output results/future_flow_run02.json`: exit 0; all five original cases completed.
- Froze two supplementary cases in CONTROL_PROTOCOL_supplement_v1.json to exercise Z0=0 and actual matter-driven energy growth, after inspecting the original controls.
- `python3 check_future_flow_v1.py --protocol CONTROL_PROTOCOL_supplement_v1.json --output results/future_flow_run03_supplement.json`: exit 0; both cases completed.
- `python3 check_nu_scope_v1.py --output results/nu_scope_run01.json`: exit 0; exact rational sign controls succeeded.
- Read full parent v2 and diff against v1: only positive normalization/units clarification changed. The diff command returned 1 because files differ; this is expected. Preserved complete diff.
- Parent acknowledged explicit all-future fluid-history domain for a forthcoming canonical packaging. That package was not requested or inspected in this first frozen check.
