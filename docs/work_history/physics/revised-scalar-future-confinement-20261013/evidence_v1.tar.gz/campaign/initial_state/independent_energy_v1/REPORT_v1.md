# Focused independent check: future confinement and convergence

The conditional finite-k proof checks out with a positive gravitational and
density normalization and a smooth conserved fluid history defined for every
future physical e-fold `N_J>=N_J0`. I found no counterexample or incorrect
constant in the energy identity, dilution estimate, exact chi relation,
integrated barrier, continuation argument, or convergence proof within that
scope. This is an independent mathematical check, not a formal audit verdict.

## Findings and source corrections

1. **Normalization precision, resolved in v2.** V1 used `Rstar` without
   defining it and inferred nonnegative sigma from a nonnegative physical
   density. Direct action variation requires `Q0>0`, `Hv>0`, and a positive
   fixed density conversion. The parent added
   `Rstar=rho_unit/[2Q(k)Hv^2]>0`, with positive supplied Q0, Hv, and rho_unit.
   I read v2 completely and checked its exact v1-to-v2 difference. This fixes
   the issue; none of the proof's algebra or dynamical steps changed.
2. **Future fluid domain, explicit wording recommended.** The proof uses a
   history defined on all future N_J, as naturally intended by “smooth
   future” and by the source's no-finite-N-singularity assertion. Smoothness
   on only an arbitrarily truncated interval would be insufficient as a
   general ODE continuation premise. The parent acknowledged this and plans
   an explicit all-future domain in the canonical packaging. That future
   package is not covered by this receipt. No uniform bound on derivatives
   of the equation of state is needed; the ODE uses only rho and P values.
3. **Keep the convergence nu condition.** At `k=.01`, `nu=100`, there is a
   nonzero stationary scalar vacuum with `t=2alpha u` in `(7,8)` and
   `Z<3/2`. Exact rational exponential bounds establish the sign bracket and
   sub-barrier energy. It satisfies confinement but does not approach u=0.
   This is outside `nu<=6a`, so it supports the stated scope rather than
   refuting the theorem. It does not establish that `6a` is a sharp cutoff.

## Exactly what was checked

- The complete supplied action and both complete versions of the future
  derivation were read. Inputs are frozen in `source_snapshot/` and identified
  by `SOURCE_MANIFEST_v2.json` and `RECEIPT_v1.json`.
- Direct variation gives the scalar matter force
  `-K^{-1}d(log sqrt(C)) tau`; contraction gives
  `e'=-3H^2 T-alpha_B tau p_u` with the source's density normalization.
  The independent computation uses lowered momenta and direct differentiation
  of the Hamiltonian energy, with no producer functions imported or read.
- The physical clock is strictly oriented for each fixed `0<k<1/3`.
  Integrating Jordan conservation gives the square-root C factor and the
  `exp(-3 Delta N)` density bound. Zero density and zero initial scalar energy
  are included.
- `chi=s(C-1)` gives both the exact vacuum energy and exact coupling ratio.
  The rational comparison remains valid even when the auxiliary comparison
  point `-sqrt(2Z/3)` lies outside the physical chi interval. Thus the
  integrated bound does not circularly assume confinement.
- Completing the square gives denominator 12; integrating `exp(-6 Delta N)`
  gives denominator 72. Phi is C1 at zero with derivative 1. A strict
  threshold yields a finite field box and uniform positive metric bounds.
- The bounded-state ODE extends at every finite N. Its physical clock tends
  to infinity. Dissipation yields `int T dN<infinity`; bounded p' then yields
  p->0. Every field accumulation point is critical. Direct differentiation
  verifies the G(t) factor and its unique zero for `0<nu<=6a`, completing
  convergence to `(u,x,y,p)=0`, `H^2=1`, `C=1`.

The detailed handwritten reconstruction is `HAND_DERIVATION_v1.md`. It spells
out the normalization, momentum equations, continuation chart, and
accumulation-point argument that the short source leaves implicit.

## Independent computational controls

| Control | Actual result |
|---|---|
| Symbolic action identities | 13 exact zero residuals |
| 80-digit local action/energy checks | Six states, including k=1e-12, near k=1/3, and unconfined fields |
| Largest scaled energy identity residual | 3.45e-70 |
| Planted defects | All six rejected: matter-force sign, doubled matter force, omitted metric derivative, wrong density power, wrong chi denominator, wrong integrated factor |
| Full finite-N controls | Seven trajectories through N=12, 601 output sites each |
| Largest scaled integrated action-energy residual | 7.20e-12 |
| Nontrivial matter work control | Z0=0 rises to max Z=0.0656405459, below Zstar=0.301284985 |
| Exact zero-vacuum control | Z remains exactly zero in the floating-point run |
| Out-of-range nu control | Exact rational sign brackets establish a nonzero stationary sub-barrier state |

All seven completed trajectory runs met their predeclared diagnostic
inequalities. The first five cases were frozen before any trajectory result;
two supplementary cases were frozen after noticing that the first five did
not exceed their initial energy. The supplementary protocol records that
reason. Their tests exercise matter work and the Phi endpoint rather than
merely repeating the same positive-energy cases.

Floating-point trajectories are diagnostics, not interval enclosures,
asymptotic proofs, or certified reconstructions of a previous history. The
mathematical implication comes from the handwritten proof check. No
observational values or original thermal-history trajectories were used.

## Failures preserved and commands actually run

The first flow run completed the first dust trajectory, then failed while
serializing a NumPy boolean to JSON. Its original source, full stderr, empty
stdout, first trajectory archive, and failure explanation remain in
`results/`. Only conversion of the diagnostic booleans to built-in bool was
changed. The unchanged frozen cases then completed under a fresh output path.
No scientific check failure was hidden by that repair.

From this evidence directory, the actual scientific commands were:

```text
python3 check_action_identity_v1.py --output results/action_identity_run01.json
python3 check_future_flow_v1.py --output results/future_flow_run01.json
python3 check_future_flow_v1.py --output results/future_flow_run02.json
python3 check_future_flow_v1.py --protocol CONTROL_PROTOCOL_supplement_v1.json --output results/future_flow_run03_supplement.json
python3 check_nu_scope_v1.py --output results/nu_scope_run01.json
```

Each command's stdout and stderr were redirected to matching files in
`results/`. Run01 of the flow is intentionally preserved as a failed run;
it must not be counted as completed evidence. Reproduction uses fresh output
names because the scripts refuse to overwrite existing results. Operational
path/read mistakes are also retained in `OPERATIONAL_LOG_v1.md`.

## Coverage limits and independence

The checker was a separate focused child context but inherited campaign
context and the proposed statement; this is not a blinded audit. I developed
the variation, inequalities, momentum implementation, and controls without
reading or importing the parent's computational implementation. I made no
commit, push, merge, authoritative source edit, or audit-status change.

Coverage is the exact action/proof snapshots, the explicit positive
normalization, and the all-future fluid-history interpretation above. It does
not include later canonical packaging, a uniform k limit, threshold equality,
the full basin volume, selection of the observed initial state, earlier
numerical integration error, inhomogeneous or quantum stability, derivation
of the supplied action, an empirical identification, or determination of Hv.
No formal proof assistant or interval ODE solver was run.

The source's conservative scope statements are appropriate. The proposed
condition can replace a bare future-compactness assumption only for exact
initial states satisfying its strict inequality and the stated model/fluid
premises.
