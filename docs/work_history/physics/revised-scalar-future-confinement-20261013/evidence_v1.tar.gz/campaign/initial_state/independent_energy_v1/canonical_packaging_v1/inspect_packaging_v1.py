#!/usr/bin/env python3
"""Inspect frozen packaging and existing outputs; execute no producer runner."""
import ast
import difflib
import hashlib
import json
from collections import defaultdict
from decimal import Decimal
from pathlib import Path
import sympy as sp


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    out=Path(__file__).resolve().parent
    old=out.parent
    manifest=json.loads((out/'SOURCE_MANIFEST_v1.json').read_text())
    snapshots={entry['repo_relative']:out/entry['snapshot'] for entry in manifest['sources']}
    note_rel='docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md'
    runner_rel='scripts/exponential_scalar_future_confinement_check.py'
    prefix='.claude/science/physics-loops/revised-scalar-derivation-24h-20261013/initial_state/'
    note=snapshots[note_rel]; runner=snapshots[runner_rel]
    cache=snapshots['logs/runner-cache/exponential_scalar_future_confinement_check.txt']
    mutation_receipt=json.loads(snapshots[prefix+'canonical_controls_v1/MUTATION_RECEIPT.json'].read_text())
    checks=[]
    def record(name,ok,details=None):
        checks.append({'name':name,'ok':bool(ok),'details':details})

    original_receipt=old/'RECEIPT_v1.json'
    record('original_receipt_unchanged',digest(original_receipt)==manifest['reused_proof_receipt_sha256'])
    original=json.loads(original_receipt.read_text())
    for row in original['artifacts']:
        record('original_artifact:'+row['path'],digest(old/row['path'])==row['sha256'])
    for row in manifest['sources']:
        record('snapshot_identity:'+row['repo_relative'],digest(out/row['snapshot'])==row['sha256'])
        record('live_identity:'+row['repo_relative'],digest(Path(row['source']))==row['sha256'])

    old_note=(old/'source_snapshot/initial_state/FUTURE_CONFINEMENT_DERIVATION_v2.md').read_text()
    new_note=note.read_text()
    begin='## Exact energy and matter bounds'; end='## What this retires and what remains'
    old_proof=old_note[old_note.index(begin):old_note.index(end)]
    new_proof=new_note[new_note.index(begin):new_note.index(end)]
    record('proof_body_identical_to_reviewed_v2',old_proof==new_proof)
    (out/'reviewed_v2_to_canonical.diff').write_text(''.join(difflib.unified_diff(old_note.splitlines(True),new_note.splitlines(True),fromfile='reviewed_v2',tofile=note_rel)))

    k=sp.symbols('k',positive=True); a=(1-k)*(1+3*k)/4
    s=(1+k)/(k*(1-3*k)); alpha=sp.sqrt(a)
    lx=sp.simplify(2*alpha*(1+s*k)/(k*(1+s))-(1-k)/alpha)
    ly=sp.simplify(4*alpha*s/(1+s)-(1+k)/alpha)
    record('lambda_x_exact_equivalence',lx==0,str(lx))
    record('lambda_y_exact_equivalence',ly==0,str(ly))

    cache_text=cache.read_text()
    header_text,outputs=cache_text.split('----- stdout -----',1)
    stdout,stderr=outputs.split('----- stderr -----',1)
    header={line.split(':',1)[0].strip():line.split(':',1)[1].strip() for line in header_text.splitlines() if ':' in line}
    canonical_result=json.loads(stdout)
    record('cache_success_header',header['exit_code']=='0' and header['status']=='ok')
    record('cache_runner_hash',header['runner_sha256']==digest(runner))
    record('cache_stderr_empty',stderr.strip()=='')
    # Recreate the inspected v1 cache-input serialization, without importing
    # or invoking the repository's cache helper.
    tree=ast.parse(runner.read_text())
    paths=None
    for node in tree.body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in node.targets):
            paths=ast.literal_eval(node.value)
    record('declared_input_scope',paths==(note_rel,),list(paths or ()))
    fp=hashlib.sha256();fp.update(b'runner-cache-input-fingerprint-v1\0')
    for rel in paths:
        body=snapshots[rel].read_bytes();pathbytes=rel.encode()
        fp.update(len(pathbytes).to_bytes(8,'big'));fp.update(pathbytes)
        fp.update(len(body).to_bytes(8,'big'));fp.update(body)
    record('cache_input_fingerprint',fp.hexdigest()==header['input_fingerprint_sha256'],fp.hexdigest())
    emitted=canonical_result['checks']
    record('canonical_counts_and_unique_names',len(emitted)==22 and len(set(x['name'] for x in emitted))==22 and all(x['passed'] for x in emitted) and canonical_result['counts']=={'passed':22,'failed':0})
    symbolic=[q for q in emitted if not q['name'].startswith('action.off_orbit_energy.')]
    local=[q for q in emitted if q['name'].startswith('action.off_orbit_energy.')]
    record('canonical_residuals_classify_correctly',len(symbolic)==17 and all(q['residual']=='0' for q in symbolic) and len(local)==5 and all(Decimal(q['residual'])<Decimal('1e-55') for q in local))
    record('mutation_receipt_original_hashes',mutation_receipt['original_runner_sha256']==digest(runner) and mutation_receipt['original_note_sha256']==digest(note))
    record('mutation_receipt_original_results',mutation_receipt['original_exit_code']==0 and mutation_receipt['original_counts']==canonical_result['counts'])

    mutation_details=[]; differences=[]
    baseline=runner.read_text()
    for row in mutation_receipt['damaged_copies']:
        name=row['mutation'];path=prefix+'canonical_controls_v1/'+name
        damaged=snapshots[path+'.py']; damaged_text=damaged.read_text()
        output=json.loads(snapshots[path+'.stdout.txt'].read_text())
        error=snapshots[path+'.stderr.txt'].read_text()
        failed=[q['name'] for q in output['checks'] if not q['passed']]
        delta=list(difflib.unified_diff(baseline.splitlines(True),damaged_text.splitlines(True),fromfile='canonical_runner',tofile=name))
        differences.extend(delta)
        removed=[line[1:] for line in delta if line.startswith('-') and not line.startswith('---')]
        added=[line[1:] for line in delta if line.startswith('+') and not line.startswith('+++')]
        one_change=len(removed)==len(added)==1 and baseline.replace(removed[0],added[0],1)==damaged_text
        residuals_ok=all((q['passed']==(Decimal(q['residual'])<Decimal('1e-55'))) if q['name'].startswith('action.off_orbit_energy.') else (q['passed']==(sp.simplify(sp.sympify(q['residual']))==0)) for q in output['checks'])
        record('mutation:'+name,digest(damaged)==row['source_sha256'] and one_change and failed==row['failed_checks'] and bool(failed) and row['exit_code']==1 and output['counts']['failed']==len(failed) and output['counts']['passed']+output['counts']['failed']==22 and len(output['checks'])==22 and error=='' and residuals_ok)
        mutation_details.append({'name':name,'one_changed_line':one_change,'removed':removed,'added':added,'failed_checks':failed,'failure_residuals':[q for q in output['checks'] if not q['passed']],'source_sha256':digest(damaged)})
    record('seven_actual_damaged_copies',len(mutation_details)==7)
    (out/'actual_mutation_diffs.patch').write_text(''.join(differences))

    # Count evidence only; neither inspect nor rerun the trajectory producer.
    summary=json.loads(snapshots[prefix+'future_evidence_v1/SUMMARY.json'].read_text())
    protocol=json.loads(snapshots[prefix+'FUTURE_PROTOCOL_v1.json'].read_text())
    grouped=defaultdict(list)
    for run in summary['runs']:
        grouped[run['initial_source']['path']].append(run['solver']['method'])
    count_details={'recorded_solver_runs':len(summary['runs']),'initial_states':len(grouped),'methods_by_state':dict(grouped),'recorded_successes':sum(bool(q['success']) for q in summary['runs']),'k_zero_runs':sum(q['k']==0 for q in summary['runs']),'positive_k_runs':sum(q['k']>0 for q in summary['runs'])}
    record('campaign_18_run_count',len(summary['runs'])==18 and len(grouped)==9 and all(sorted(v)==['DOP853','Radau'] for v in grouped.values()) and len(protocol['cases'])==9 and len(protocol['solvers'])==2 and all(q['success'] for q in summary['runs']),count_details)
    result={'scope':'Affected canonical packaging comparison; prior theorem check reused. No producer or trajectory runner executed.', 'checks':checks,'failures':[q['name'] for q in checks if not q['ok']], 'lambda_residuals':{'x':str(lx),'y':str(ly)},'canonical_residual_summary':{'symbolic_identities':len(symbolic),'off_orbit_states':len(local),'max_scaled_energy_residual':canonical_result['max_scaled_energy_residual']},'mutations':mutation_details,'campaign_run_count':count_details,'original_proof_artifact_count':len(original['artifacts'])}
    (out/'PACKAGING_CHECK_v1.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'checked_items':len(checks),'failures':result['failures'],'proof_body_identical':old_proof==new_proof,'lambda_residuals':result['lambda_residuals'],'canonical_counts':canonical_result['counts'],'damaged_copies':len(mutation_details),'campaign_run_count':count_details,'original_proof_artifact_count':len(original['artifacts'])},indent=2))
    if result['failures']:raise SystemExit(1)


if __name__=='__main__':main()
