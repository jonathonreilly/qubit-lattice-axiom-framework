#!/usr/bin/env python3
"""Independent action reconstruction; imports no producer or repo module."""
import argparse
import hashlib
import json
import platform
from pathlib import Path
import mpmath as mp
import sympy as sp


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', required=True)
    args = ap.parse_args()
    target = Path(args.output)
    if target.exists():
        raise RuntimeError('Refusing to overwrite a preserved check run')
    mp.mp.dps = 80
    result = {'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'python': platform.python_version(), 'sympy': sp.__version__,
              'mpmath': mp.__version__, 'mp_dps': mp.mp.dps,
              'symbolic': [], 'local_states': [], 'mutation_controls': [],
              'failures': []}

    def save():
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(result, indent=2) + '\n')

    def symbolic(name, expression):
        residual = sp.factor(sp.cancel(expression))
        ok = residual == 0
        result['symbolic'].append({'name': name, 'residual': str(residual), 'ok': ok})
        if not ok:
            result['failures'].append(name)
        save()

    k, E, chi, w, NN = sp.symbols('k E chi w NN', positive=True)
    a = (1-k)*(1+3*k)/4
    s = (1+k)/(k*(1-3*k))
    F = 1+s*E
    J = 1+(1-3*a)*s*E
    C = (1+s)*E/F
    chi_action = s*(C-1)
    symbolic('one_minus_three_a', 1-3*a-(1-3*k)**2/4)
    symbolic('s_minus_one', s-1-(1+3*k*k)/(k*(1-3*k)))
    symbolic('chi_from_C', chi_action-s*(E-1)/F)
    symbolic('chi_inverse', chi_action.subs(E,(1+chi/s)/(1-chi))-chi)
    symbolic('vacuum_potential', 3*s*(E-1)**2/(2*F**2)-3*chi_action**2/(2*s))
    symbolic('exact_coupling', a/J-k*(1-chi_action)/(1-3*k*chi_action))
    symbolic('chi_monotone_derivative', sp.diff(k*(1-chi)/(1-3*k*chi),chi)-k*(3*k-1)/(1-3*k*chi)**2)
    symbolic('phi_chain_derivative', sp.diff(3*(w-sp.log(1+w)),w)/(3*w)-1/(1+w))
    symbolic('barrier_integral_coefficient', sp.diff((1-sp.exp(-6*NN))/72,NN)-sp.exp(-6*NN)/12)

    # Direct potential derivative and the critical-point factorization.
    uu, nu = sp.symbols('uu nu', real=True)
    al = sp.symbols('al', positive=True)
    ss = sp.symbols('ss', positive=True)
    ee = sp.exp(2*al*uu)
    ff = 1+ss*ee
    potential_line = sp.Rational(3,2)+3*ss*(ee-1)**2/(2*ff**2)+nu*(1+ss)*uu**2/(2*ff**2)
    t = 2*al*uu
    G = 12*al**2*(ee-1)+nu*t*(1-t)+nu*t/(ss*ee)
    symbolic('critical_point_G_factor', sp.diff(potential_line,uu)-(1+ss)*ss*ee*G/(2*al*ff**3))

    # Matter conservation from C^r rho_J and NJ'=1+alpha p_u.
    alphap, eos = sp.symbols('alphap eos', real=True)
    symbolic('fluid_exchange', 4*alphap-3*(1+eos)*(1+alphap)-(-3*(1+eos)+alphap*(1-3*eos)))
    beta, H, sig, tt = sp.symbols('beta H sig tt', positive=True)
    symbolic('Young_complete_square', -3*H**2*tt**2+sig*sp.sqrt(beta)*tt-
             (sig**2*beta/(12*H**2)-3*H**2*(tt-sig*sp.sqrt(beta)/(6*H**2))**2))
    symbolic('Young_half_dissipation', -3*H**2*tt**2+sig*sp.sqrt(beta)*tt-
             (-sp.Rational(3,2)*H**2*tt**2+sig**2*beta/(6*H**2)-
              sp.Rational(3,2)*H**2*(tt-sig*sp.sqrt(beta)/(3*H**2))**2))

    def action_fields(fields, kval, nval):
        u,x,y = fields
        aval=(1-kval)*(1+3*kval)/4
        alpha=mp.sqrt(aval)
        sval=(1+kval)/(kval*(1-3*kval))
        ex=mp.exp(2*alpha*u)
        f=1+sval*ex
        j=1+(1-3*aval)*sval*ex
        d=1+2*(1+kval)*(x*x+y*y)/3
        metric=[j/f**2,(1+sval)*4*kval/(9*f*d),(1+sval)*kval/(3*f*d)]
        lx=2*alpha*(1+sval*kval)/(kval*(1+sval))
        ly=4*alpha*sval/(1+sval)
        U=mp.mpf('1.5')+3*sval*mp.expm1(2*alpha*u)**2/(2*f**2)+kval*x*x*mp.exp(-lx*u)/2+kval*y*y*mp.exp(-ly*u)/3+nval*(1+sval)*u*u/(2*f**2)
        return metric,U,(1+sval)*ex/f,alpha/f,aval,sval

    states = [
      ('vacuum_origin','0.01','1',['0','0','0'],['0','0','0'],'0','0'),
      ('mixed_small_k','1e-12','1',['-0.8','0.7','-0.4'],['0.2','-0.3','0.1'],'2.1','0.11'),
      ('mixed_medium_k','0.02','1',['0.35','0.6','-0.3'],['-0.7','0.2','0.9'],'1.3','0.27'),
      ('near_upper_k','0.333333333333','1',['-1.2','1.7','0.6'],['0.4','-0.8','0.2'],'3.4','0.23'),
      ('large_positive_u','0.08','0.1',['20','1.4','-0.7'],['0.2','0.5','-0.4'],'0.7','0'),
      ('unconfined_negative_u','0.08','1',['-9','2','-3'],['0.6','-0.1','0.5'],'0.4','0.33333333333333333333333333333333333333333333333333')
    ]
    maxres=mp.mpf(0)
    for name,ks,ns,fs,vs,ssig,ww in states:
        kval,nval=mp.mpf(ks),mp.mpf(ns)
        fields=list(map(mp.mpf,fs)); v=list(map(mp.mpf,vs))
        sigma,eosw=mp.mpf(ssig),mp.mpf(ww)
        metric,U,coupling,alphaB,aval,sval=action_fields(fields,kval,nval)
        mom=[metric[i]*v[i] for i in range(3)]
        Hval=mp.sqrt((sum(metric[i]*v[i]**2 for i in range(3))+2*U+2*sigma)/3)
        tau=sigma*(1-3*eosw)
        dK=[[mp.diff(lambda z,j=j,i=i: action_fields(fields[:i]+[z]+fields[i+1:],kval,nval)[0][j],fields[i]) for j in range(3)] for i in range(3)]
        dU=[mp.diff(lambda z,i=i: action_fields(fields[:i]+[z]+fields[i+1:],kval,nval)[1],fields[i]) for i in range(3)]
        momentum_dot=[-3*Hval*mom[i]+sum(dK[i][j]*v[j]**2 for j in range(3))/2-dU[i]-(alphaB*tau if i==0 else 0) for i in range(3)]
        def mechanical_energy(z):
            Km,Um,*_=action_fields(z[:3],kval,nval)
            return sum(z[i+3]**2/Km[i] for i in range(3))/2+Um-mp.mpf('1.5')
        z0=fields+mom
        direction=v+momentum_dot
        # Differentiate the full Hamiltonian energy along the action vector field.
        observed=mp.diff(lambda h: mechanical_energy([z0[i]+h*direction[i] for i in range(6)]),mp.mpf(0))/Hval
        expected=-3*sum(metric[i]*v[i]**2 for i in range(3))-alphaB*tau*v[0]/Hval
        residual=abs(observed-expected)/(1+abs(observed)+abs(expected))
        maxres=max(maxres,residual)
        e=mechanical_energy(z0); Z=sval*e
        wval=mp.sqrt(2*Z/3)
        chival=sval*(coupling-1)
        beta_action=alphaB**2/metric[0]
        beta_rational=kval*(1-chival)/(1-3*kval*chival)
        beta_upper=kval*(1+wval)/(1+3*kval*wval)
        T=sum(metric[i]*(v[i]/Hval)**2 for i in range(3))
        NJp=1+alphaB*v[0]/Hval
        entry={'name':name,'k':ks,'nu':ns,'fields':fs,'v':vs,'sigma':ssig,'w_eos':ww,
               'energy_derivative_scaled_residual':str(residual),
               'energy_derivative_observed':str(observed),'energy_derivative_expected':str(expected),
               'Z':str(Z),'chi':str(chival),'sqrt_2Z_over_3':str(wval),
               'beta_direct':str(beta_action),'beta_exact_chi':str(beta_rational),'beta_bound':str(beta_upper),
               'T':str(T),'NJ_prime':str(NJp),'clock_lower_bound':str(1-mp.sqrt(3*aval))}
        tests={'energy_identity':residual<mp.mpf('1e-60'),
               'coupling_identity':abs(beta_action-beta_rational)<mp.mpf('1e-60')*(1+abs(beta_action)),
               'coupling_bound':beta_action<=beta_upper+mp.mpf('1e-70'),
               'chi_energy':abs(chival)<=wval+mp.mpf('1e-70'),
               'clock':NJp>=1-mp.sqrt(3*aval), 'T_lt_3':T<3, 'H_ge_1':Hval>=1}
        entry['checks']=tests
        result['local_states'].append(entry)
        for key,ok in tests.items():
            if not ok: result['failures'].append(name+':'+key)

        if name=='mixed_medium_k':
            # Each changed equation is actually differentiated, not inferred
            # rejected from its source label.
            for mutation,multiplier,omit_metric in [('reversed_matter_force',-1,False),('doubled_matter_force',2,False),('omitted_metric_derivative',1,True)]:
                wrong_dot=[-3*Hval*mom[i]+(0 if omit_metric else sum(dK[i][j]*v[j]**2 for j in range(3))/2)-dU[i]-(multiplier*alphaB*tau if i==0 else 0) for i in range(3)]
                wrong_direction=v+wrong_dot
                wrong_obs=mp.diff(lambda h: mechanical_energy([z0[i]+h*wrong_direction[i] for i in range(6)]),mp.mpf(0))/Hval
                defect=abs(wrong_obs-expected)
                rejected=defect>mp.mpf('1e-12')
                result['mutation_controls'].append({'name':mutation,'defect':str(defect),'rejected':rejected})
                if not rejected: result['failures'].append('undetected_mutation:'+mutation)
        save()

    for name,defect in [
       ('density_conformal_power_one', (2*alphap-3*(1+eos)*(1+alphap)-(-3*(1+eos)+alphap*(1-3*eos))).subs({alphap:sp.Rational(1,7),eos:sp.Rational(1,8)})),
       ('wrong_chi_denominator', (k*(1-chi)/(1-2*k*chi)-k*(1-chi)/(1-3*k*chi)).subs({k:sp.Rational(1,10),chi:sp.Rational(-1,2)})),
       ('wrong_barrier_integral_144', (sp.diff((1-sp.exp(-6*NN))/144,NN)-sp.exp(-6*NN)/12).subs(NN,0))
    ]:
        defect=sp.simplify(defect); rejected=defect!=0
        result['mutation_controls'].append({'name':name,'exact_defect':str(defect),'rejected':bool(rejected)})
        if not rejected: result['failures'].append('undetected_mutation:'+name)

    # Out-of-range nuance control: nu=100 gives an extra stationary point
    # below the trapping energy. This is NOT a counterexample to nu<=6a.
    kval=mp.mpf('0.01'); nval=mp.mpf(100)
    aval=(1-kval)*(1+3*kval)/4; alval=mp.sqrt(aval)
    sval=(1+kval)/(kval*(1-3*kval))
    def gg(t): return 12*aval*mp.expm1(t)+nval*t*(1-t)+nval*t/(sval*mp.exp(t))
    root=mp.findroot(gg,(mp.mpf(7),mp.mpf(8)),solver='anderson')
    _,ucrit,*_=action_fields([root/(2*alval),mp.mpf(0),mp.mpf(0)],kval,nval)
    zcrit=sval*(ucrit-mp.mpf('1.5'))
    # 1.5-Z has sign of h(t); h and h' are positive for t>=7 here,
    # since e^t/t is increasing there and h'(7)>0.
    def hh(t): return 6*mp.exp(t)+3*(1/sval-1)-nval*t*t/(4*aval)
    hp7=6*mp.exp(7)-nval*7/(2*aval)
    neg={'name':'nu_outside_sufficient_range','k':str(kval),'nu':str(nval),'6a':str(6*aval),
         'G7':str(gg(mp.mpf(7))),'G8':str(gg(mp.mpf(8))),
         'h7':str(hh(mp.mpf(7))),'hprime7':str(hp7),
         'stationary_t':str(root),'stationary_u':str(root/(2*alval)),
         'stationary_Z':str(zcrit),'G_root':str(gg(root)),
         'outcome':'Extra stationary point below Z=3/2; refutes extending convergence to all positive nu.'}
    negok=gg(mp.mpf(7))<0<gg(mp.mpf(8)) and hh(mp.mpf(7))>0 and hp7>0 and zcrit<mp.mpf('1.5')
    neg['checks_ok']=bool(negok)
    if not negok: result['failures'].append('nu_negative_control_failed')
    result['outside_hypothesis_control']=neg
    result['max_scaled_energy_identity_residual']=str(maxres)
    result['status']='completed_no_check_failures' if not result['failures'] else 'completed_with_failures'
    save()
    print(json.dumps({'status':result['status'],'symbolic_identities':len(result['symbolic']),
                      'local_states':len(result['local_states']),'mutation_controls':len(result['mutation_controls']),
                      'max_scaled_energy_identity_residual':str(maxres),'failures':result['failures'],
                      'outside_nu_stationary_Z':str(zcrit)},indent=2))
    if result['failures']: raise SystemExit(1)


if __name__ == '__main__':
    main()
