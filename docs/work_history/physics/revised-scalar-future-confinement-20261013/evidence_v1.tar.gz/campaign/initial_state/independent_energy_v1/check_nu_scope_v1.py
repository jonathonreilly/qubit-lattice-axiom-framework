#!/usr/bin/env python3
"""Exact rational sign brackets for a control OUTSIDE the theorem's nu range."""
import argparse
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path


def exp_bracket(x, order=60):
    # L=sum_{j=0}^order x^j/j! < exp(x).
    # Tail ratios beyond the first omitted term are at most x/(order+2).
    term=F(1); lower=term
    for n in range(1,order+1):
        term*=x/n; lower+=term
    first_omitted=term*x/(order+1)
    ratio=x/(order+2)
    assert 0<ratio<1
    return lower,lower+first_omitted/(1-ratio)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output',required=True)
    args=ap.parse_args(); out=Path(args.output)
    if out.exists(): raise RuntimeError('Refusing to overwrite preserved evidence')
    k=F(1,100); nu=F(100)
    a=(1-k)*(1+3*k)/4; s=(1+k)/(k*(1-3*k))
    l7,u7=exp_bracket(F(7)); l8,u8=exp_bracket(F(8))
    bounds={
      'G7_upper':12*a*(u7-1)+nu*7*(1-7)+nu*7/(s*l7),
      'G8_lower':12*a*(l8-1)+nu*8*(1-8)+nu*8/(s*u8),
      'h7_lower':6*l7+3*(1/s-1)-nu*49/(4*a),
      'hprime7_lower':6*l7-nu*7/(2*a)
    }
    checks={'G7_negative':bounds['G7_upper']<0,
            'G8_positive':bounds['G8_lower']>0,
            'h7_positive':bounds['h7_lower']>0,
            'hprime7_positive':bounds['hprime7_lower']>0,
            'nu_outside_stated_range':nu>6*a}
    result={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'arithmetic':'fractions.Fraction, exact rational arithmetic',
      'k':str(k),'nu':str(nu),'a':str(a),'s':str(s),'exp_series_order':60,
      'bounds':{key:{'exact_rational':str(val),'float_for_display_only':float(val)} for key,val in bounds.items()},
      'checks':checks,
      'proof':'Continuity gives a root of G in (7,8). For h(t)=6exp(t)+3(1/s-1)-nu*t^2/(4a), h(7)>0 and hprime(7)>0. Since exp(t)/t increases for t>1, hprime stays positive on [7,infinity), hence h(root)>0. The exact identity 3/2-Z = s(1+s)h(t)/(2F^2) makes the stationary state strictly sub-barrier. Vacuum and zero velocities then produce a constant nonzero-u solution satisfying confinement but not convergence to u=0.',
      'scope':'This falsifies convergence for arbitrary positive nu. It does not falsify the source theorem, which assumes 0<nu<=6a for convergence.',
      'status':'completed_no_check_failures' if all(checks.values()) else 'completed_with_failures'}
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'checks':checks,'bounds_for_display':{q:float(v) for q,v in bounds.items()}},indent=2))
    if not all(checks.values()): raise SystemExit(1)


if __name__=='__main__': main()
