#!/usr/bin/env python3
"""Full finite-k momentum trajectories generated from action expressions.

No producer functions or repository modules are imported. These are
floating-point diagnostics; they are not rigorous trajectory enclosures.
"""
import argparse
import hashlib
import json
import platform
from pathlib import Path
import numpy as np
import scipy
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
import sympy as sp


def action_model(k, nu):
    u,x,y = sp.symbols('u x y', real=True)
    coords=(u,x,y)
    kk=sp.Rational(str(k)); nn=sp.Rational(str(nu))
    a=(1-kk)*(1+3*kk)/4
    al=sp.sqrt(a); s=(1+kk)/(kk*(1-3*kk))
    E=sp.exp(2*al*u); F=1+s*E
    J=1+(1-3*a)*s*E
    D=1+sp.Rational(2,3)*(1+kk)*(x*x+y*y)
    K=[J/F**2,(1+s)*4*kk/(9*F*D),(1+s)*kk/(3*F*D)]
    lx=2*al*(1+s*kk)/(kk*(1+s)); ly=4*al*s/(1+s)
    excess=3*s*(E-1)**2/(2*F**2)+kk*x*x*sp.exp(-lx*u)/2+kk*y*y*sp.exp(-ly*u)/3+nn*(1+s)*u*u/(2*F**2)
    C=(1+s)*E/F; alphaB=al/F
    # Symbolic derivatives of the raw action, not supplied analytic forces.
    fun=sp.lambdify(coords, K+[excess,C,alphaB]+[sp.diff(q,z) for z in coords for q in K]+[sp.diff(excess,z) for z in coords], 'numpy', cse=True)
    def evaluate(fields):
        values=np.asarray(fun(*fields), dtype=float)
        return values[:3],values[3],values[4],values[5],values[6:15].reshape(3,3),values[15:18]
    return evaluate,float(a),float(s)


def phi(Z):
    w=np.sqrt(np.maximum(0.0, 2*np.asarray(Z)/3))
    return 3*(w-np.log1p(w))


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--output',required=True)
    ap.add_argument('--protocol',default='CONTROL_PROTOCOL_v1.json')
    args=ap.parse_args()
    output=Path(args.output)
    if output.exists(): raise RuntimeError('Refusing to overwrite a preserved check run')
    protocol_path=Path(args.protocol)
    protocol=json.loads(protocol_path.read_text())
    result={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'protocol_sha256':hashlib.sha256(protocol_path.read_bytes()).hexdigest(),
            'python':platform.python_version(),'numpy':np.__version__,
            'scipy':scipy.__version__,'sympy':sp.__version__,
            'independence':'Raw action symbolic differentiation; lowered momenta divided by constant k; analytic physical-fluid history.',
            'scope':'Finite N diagnostics only. No interval enclosure and no proof of asymptotic convergence from numerics.',
            'cases':[],'failures':[]}
    def save():
        output.parent.mkdir(parents=True,exist_ok=True)
        output.write_text(json.dumps(result,indent=2)+'\n')
    for case in protocol['flow_cases']:
        kval=case['k']; aval=(1-kval)*(1+3*kval)/4
        nval=6*aval if case['nu']=='6a' else case['nu']
        model,a,s=action_model(kval,nval)
        fields0=np.asarray(case['fields'],dtype=float)
        K0,V0,C0,ab0,*_=model(fields0)
        direction=np.asarray(case['direction'],dtype=float)
        v0=direction*np.sqrt(2*case['kinetic_Z']/(s*np.sum(K0*direction**2)))
        scaled_m0=K0*v0/kval
        sigma0=case['sigma0']; Cmax=(1+s)/s
        S=sigma0*np.sqrt(Cmax/C0)
        Z0=case['kinetic_Z']+s*V0
        B=float(phi(Z0))+s*kval*S*S/72
        entry={'name':case['name'],'k':kval,'nu':nval,'sigma0':sigma0,
               'Z0':float(Z0),'Phi_Z0':float(phi(Z0)),'B':B,
               'Phi_barrier':float(phi(1.5)),'strict_margin':float(phi(1.5))-B}
        if not B<float(phi(1.5)):
            entry['status']='frozen_initial_condition_does_not_meet_hypothesis'
            result['failures'].append(case['name']+':not_in_sufficient_region')
            result['cases'].append(entry); save(); continue
        Zstar=brentq(lambda z:float(phi(z))-B,0,1.5,xtol=1e-14)
        wstar=np.sqrt(2*Zstar/3)
        umin=np.log((1-wstar/s)/(1+wstar))/(2*np.sqrt(a))
        umax=np.log((1+wstar/s)/(1-wstar))/(2*np.sqrt(a))
        def fluid(N,fields,C):
            NJ=N+0.5*np.log(C/C0)
            if case['fluid']=='radiation':
                w=1/3; density_ratio=np.exp(-4*NJ)
            elif case['fluid'].startswith('w='):
                w=(1+np.sin(37*NJ))/6
                density_ratio=np.exp(-3.5*NJ+(np.cos(37*NJ)-1)/74)
            else:
                w=0.; density_ratio=np.exp(-3*NJ)
            sigma=sigma0*(C/C0)**2*density_ratio
            return sigma,w*sigma,NJ
        def rhs(N,state):
            fields=state[:3]; mom=kval*state[3:6]
            K,V,C,ab,dK,dV=model(fields)
            v=mom/K
            sigma,pi,NJ=fluid(N,fields,C)
            energy=np.dot(mom,v)/2+V
            H=np.sqrt(1+2*(energy+sigma)/3)
            p=v/H; tau=sigma-3*pi
            force=0.5*(dK@(v*v))-dV-np.array([ab*tau,0.,0.])
            scaled_m_prime=-3*state[3:6]+force/(kval*H)
            T=np.dot(K,p*p)
            return np.r_[p,scaled_m_prime,T,s*H*H*T,s*ab*tau*p[0]]
        initial=np.r_[fields0,scaled_m0,0.,0.,0.]
        sites=np.linspace(*protocol['flow_interval_N'],protocol['flow_sample_count'])
        tolerances=protocol['flow_tolerances']
        sol=solve_ivp(rhs,protocol['flow_interval_N'],initial,method=protocol['flow_solver'],t_eval=sites,**tolerances)
        entry['solver']={'success':bool(sol.success),'message':sol.message,'nfev':int(sol.nfev),'actual_last_N':float(sol.t[-1])}
        if not sol.success:
            result['failures'].append(case['name']+':solver_failed')
        rows=[]
        for i,N in enumerate(sol.t):
            fields=sol.y[:3,i]; mom=kval*sol.y[3:6,i]
            K,V,C,ab,dK,dV=model(fields); v=mom/K
            sigma,pi,NJ=fluid(N,fields,C)
            energy=np.dot(mom,v)/2+V; Z=s*energy
            H=np.sqrt(1+2*(energy+sigma)/3); p=v/H
            T=np.dot(K,p*p)
            rows.append([N,*fields,*p,energy,Z,H,C,sigma,pi,NJ,1+ab*p[0],T,
                         float(phi(Z)),float(phi(Z0))+s*kval*S*S*(-np.expm1(-6*N))/72,
                         S*np.exp(-3*N),Z-Z0+3*sol.y[7,i]+sol.y[8,i],np.linalg.norm(dV)])
        columns=['N','u','x','y','p_u','p_x','p_y','e','Z','H','C','sigma','pi','NJ','NJ_prime','T','Phi_Z','Phi_bound','density_bound','scaled_energy_balance_residual','grad_U_norm']
        table=np.asarray(rows)
        values={name:table[:,i] for i,name in enumerate(columns)}
        archive=output.parent/(output.stem+'__'+case['name']+'.npz')
        np.savez_compressed(archive,columns=np.array(columns),table=table,raw_solver_state=sol.y)
        checks={
          'strict_initial_region':B<float(phi(1.5)),
          'integrated_barrier':float(np.max(values['Phi_Z']-values['Phi_bound']))<1e-7,
          'Zstar':float(np.max(values['Z']-Zstar))<1e-7,
          'density_bound':float(np.max(values['sigma']-values['density_bound']))<1e-7,
          'clock_lower_bound':float(np.min(values['NJ_prime']))>=1-np.sqrt(3*a)-1e-12,
          'H_ge_1':float(np.min(values['H']))>=1-1e-12,
          'u_compact_interval':float(np.min(values['u']))>=umin-1e-7 and float(np.max(values['u']))<=umax+1e-7,
          'action_energy_balance':float(np.max(np.abs(values['scaled_energy_balance_residual'])))<1e-7,
          'integrated_T_bound':float(sol.y[6,-1])<=(2/3)*(Z0/s+a*S*S/36)+1e-7
        }
        entry.update({'status':'completed','Zstar':float(Zstar),'u_trapping_bounds':[float(umin),float(umax)],
           'checks':checks,'max_Phi_minus_bound':float(np.max(values['Phi_Z']-values['Phi_bound'])),
           'max_Z':float(np.max(values['Z'])),'min_clock_prime':float(np.min(values['NJ_prime'])),
           'max_scaled_energy_balance_residual':float(np.max(np.abs(values['scaled_energy_balance_residual']))),
           'integral_T':float(sol.y[6,-1]),'integral_T_bound':float((2/3)*(Z0/s+a*S*S/36)),
           'last_fields':sol.y[:3,-1].tolist(),'last_p':table[-1,4:7].tolist(),
           'last_Z':float(values['Z'][-1]),'last_H':float(values['H'][-1]),'last_C':float(values['C'][-1]),
           'trajectory_archive':archive.name,'trajectory_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()})
        for name,ok in checks.items():
            if not ok: result['failures'].append(case['name']+':'+name)
        result['cases'].append(entry); save()
        print(json.dumps({'name':case['name'],'success':bool(sol.success),'strict_margin':entry['strict_margin'],
                          'max_scaled_energy_balance_residual':entry['max_scaled_energy_balance_residual'],
                          'last_Z':entry['last_Z'],'checks':checks}),flush=True)
    result['status']='completed_no_check_failures' if not result['failures'] else 'completed_with_failures'
    save()
    print(json.dumps({'status':result['status'],'case_count':len(result['cases']),'failures':result['failures']}),flush=True)
    if result['failures']: raise SystemExit(1)


if __name__=='__main__':
    main()
