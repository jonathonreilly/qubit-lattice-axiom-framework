#!/usr/bin/env python3
"""Verify frozen evidence hashes; optional live-source comparison."""
import argparse
import hashlib
import json
from pathlib import Path


def verify(receipt, root, live=False):
    failures=[]
    root=root.resolve()
    for entry in receipt['artifacts']:
        path=(root/entry['path']).resolve()
        if not path.is_relative_to(root):
            failures.append('path_outside_bundle:'+entry['path']); continue
        if not path.is_file():
            failures.append('missing:'+entry['path']); continue
        data=path.read_bytes()
        if len(data)!=entry['bytes'] or hashlib.sha256(data).hexdigest()!=entry['sha256']:
            failures.append('hash_mismatch:'+entry['path'])
    if live:
        for entry in receipt['sources']:
            path=Path(entry['source'])
            if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:
                failures.append('live_source_changed:'+entry['source'])
    return failures


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--receipt',default='RECEIPT_v1.json')
    ap.add_argument('--live-sources',action='store_true')
    ap.add_argument('--mutation-self-test',action='store_true')
    args=ap.parse_args()
    receipt_path=Path(args.receipt).resolve(); root=receipt_path.parent
    receipt=json.loads(receipt_path.read_text())
    failures=verify(receipt,root,args.live_sources)
    mutation_rejected=None
    if args.mutation_self_test:
        mutation=json.loads(json.dumps(receipt))
        mutation['artifacts'][0]['sha256']='0'*64
        mutation_rejected=bool(verify(mutation,root,False))
        if not mutation_rejected: failures.append('tampered_manifest_not_rejected')
    print(json.dumps({'artifact_count':len(receipt['artifacts']),
                      'live_sources_checked':args.live_sources,
                      'tampered_manifest_rejected':mutation_rejected,
                      'failures':failures},indent=2))
    if failures: raise SystemExit(1)


if __name__=='__main__': main()
