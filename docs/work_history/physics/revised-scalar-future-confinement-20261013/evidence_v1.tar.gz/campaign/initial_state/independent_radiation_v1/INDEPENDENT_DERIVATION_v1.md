# Independent derivation of the restricted radiation reduction

This calculation checks the supplied exponential action and its normalized weak-coupling equations. It introduces no new action, calibration, empirical likelihood, or initial-state prescription. Its domain is an expanding homogeneous ideal-radiation regime, y>0, with x=x'=0, fixed positive nu, and fixed finite u,z,p,q during the large-density limit. N is the forward e-fold variable. All field coordinates, e-fold derivatives, and normalized potentials below are dimensionless.

## 1. Action variation before the logarithmic coordinate change

For a diagonal homogeneous field metric g, the scalar action written in N has Lagrangian proportional to

    L_N = a_E^3 H [sum_i g_i(phi) phi_i'^2 - 2 W(phi)/B],
    B=H^2/H_v^2,   h=H'/H.

In field derivatives B is a time-dependent external coefficient, not a function of the field being varied. Dividing the Euler–Lagrange equation by 2 a_E^3 H gives

    g_i phi_i'' +(3+h)g_i phi_i'
      +phi_i' sum_j (partial_j g_i) phi_j'
      -(1/2)sum_j (partial_i g_j) phi_j'^2
      +(partial_i W)/B = 0.

The ideal-radiation matter trace is zero. This removes the trace force but does not remove the scalar kinetic connection or scalar potential force. The weak-coupling equation is obtained after dividing the scalar equation by k and taking its limit; it is not the Euler–Lagrange equation of a literal action with zero kinetic coefficient.

At x=0 the x derivative of every relevant diagonal metric coefficient and of W vanishes. Therefore x=x'=0 is an invariant restriction of the ideal-fluid equations. This checks consistency of the restriction, not stability against omitted x or dust perturbations.

For the remaining (u,y) coordinates, set t=exp(-u) and D=1+2y²/3. Then

    g_u=t/4,   g_y=t/(3D),
    W=3(1-t)²/2+t²(y²/3+nu u²/2),
    W_u=3t(1-t)+t²(nu u-nu u²-2y²/3),
    W_y=2t² y/3.

Set p=u' and q=y'/y. Vary at fixed physical y first, then use q'=y''/y-q². The exact restricted weak-coupling equations before the large-y limit are

    p'=-(3+h)p+p²/2-[2y²/(3D)]q²-4W_u/(tB),
    q'=-(3+h)q+pq-q²/D-2tD/B.

The pq and q² terms follow from the metric derivatives. They must not be replaced by a flat-field force law.

## 2. The ordered radiation scaling limit

Write Y=y_b>0, Y²=R0 rho_r, Y'=-2Y and y=exp(z)Y. For ideal radiation,

    B=1+2Y²/3,   h=-4Y²/(3B).

First use the normalized weak-coupling theory, then take Y to infinity while u,z,p,q and nu remain fixed. Thus D/B tends to exp(2z), 2y²/(3D) tends to one, 1/D tends to zero, W_u/B tends to -exp(-2u+2z), and h tends to -2. The result is

    u'=p,
    z'=q+2,
    p'=-p+p²/2-q²+4 exp(2z-u),
    q'=-q+pq-2 exp(2z-u).

Since dy=y d(ell), the y metric coefficient becomes g_y y², tending to t/2. Hence the reduced target metric is t[du²/4+dell²/2]. Also W/B tends to exp(-2u+2z)/2. These limits agree with the action calculation rather than being assumptions substituted into the expected flow.

The inherited fixed-compact-field convergence result does not by itself supply a joint k→0, Y→infinity theorem: y and y'=yq leave its compact sets. The ordered reduction is valid as stated, but a uniform joint estimate or a full finite-history comparison requires separate evidence. The approximation also does not cover annihilation, massive-neutrino transitions, traceful dust, or vacuum domination. An arbitrarily long forward-N extrapolation of this autonomous reduction eventually leaves a finite radiation era.

## 3. Fixed family and linearization

At a fixed point of (u,z,p,q), the first two equations require p=0 and q=-2. The fourth then requires exp(2z-u)=1. The third is automatically satisfied. Thus every and only fixed point of this restricted real coordinate system is

    (u,z,p,q)=(c,c/2,0,-2),   c real and finite.

Differentiating the independently obtained vector field gives

    M = [[ 0, 0, 1, 0],
         [ 0, 0, 0, 1],
         [-4, 8,-1, 4],
         [ 2,-4,-2,-1]].

Its characteristic polynomial is lambda(lambda+1)(lambda²+lambda+16). The neutral vector is (1,1/2,0,0). The remaining eigenvalues are -1 and (-1±i sqrt(63))/2, referring to forward expanding N.

For w=2z-u the closed three-dimensional system is

    w'=2q+4-p,
    p'=-p+p²/2-q²+4 exp(w),
    q'=-q+pq-2 exp(w).

At (w,p,q)=(0,0,-2), its Jacobian is

    [[0,-1, 2],
     [4,-1, 4],
     [-2,-2,-1]].

The characteristic polynomial is lambda³+2lambda²+17lambda+16. Its positive coefficients and 2*17-16=18 satisfy the strict cubic Hurwitz condition. This supplies linear transverse damping. Smoothness plus a Hurwitz matrix also supports the usual existence of a local nonlinear stable neighborhood, but this check does not construct an explicit radius, global basin, or finite-duration selection bound. The exact fixed family already prevents unique c selection within this limiting system. It does not imply the full finite-k theory shares that degeneracy.

## 4. Physical first expansion coefficient

Reduce the actual inherited constraint/readout coefficient, retaining its physical-clock term t p:

    C_exp=2[W+sigma0(1-2t)]/(3B)+Tbar/3+t p-1+t,
    Tbar=t[p²/4+y²q²/(3D)],   sigma0=Y².

The radiation limit is

    C_rad=t[exp(2z-u)/3+p²/12+q²/6+p-1].

At the family, exp(2z-u)=1, p=0 and q²=4, so the bracket is 1/3+2/3-1=0. Equivalently W/B=t/2, sigma0/B=3/2 and Tbar=2t. The first-order physical expansion coefficient vanishes for every finite c. This is an exact statement about this reduced first coefficient, not all observables, an exact finite-k equality, or later epochs. In particular a diagnostic evaluated only on p=0 cannot separately test the generic physical-clock term.

## 5. Fixed finite-k constant-u scaling condition

Now hold 0<k<1/3 fixed in the supplied action, with b=k, a=(1-k)(1+3k)/4, alpha=sqrt(a), s=(1+k)/[k(1-3k)], E=exp(2alpha u), F=1+sE and J=1+(1-3a)sE. All these theory parameters are held fixed during field differentiation. In the large-y radiation reduction,

    K_u=J/F²,
    c_y=lim(y² K_y)=(1+s)k/[2(1+k)F],
    V_y=(k/3)y² exp(-lambda_y u),
    lambda_y=4alpha s/(1+s).

V_y denotes a potential contribution. It is not partial U/partial y. Define the dimensionless Hubble square scriptH²=Hhat²/H_v². The (u,ell) homogeneous action has kinetic term K_u p²+c_y q². At constant u and q=-2, all retained scalar and radiation energy densities scale as a_E^-4; h=-2. The ell equation gives

    -2c_y+2V_y/scriptH²=0,
    scriptH²=V_y/c_y=y(partial U/partial y)/(2c_y).

The lowered u equation gives

    -2c_y' -lambda_y V_y/scriptH²=0,
    2c_y'+lambda_y c_y=0.

Here c_y' means derivative with respect to u, unlike the e-fold primes on histories. Explicitly,

    2c_y'+lambda_y c_y
      =2alpha s k(1-E)/[(1+k)F²].

For 0<k<1/3 the prefactor is strictly positive and finite at finite u, so its sole zero is E=1, hence u=0. The exceptional degenerate k=0 theory is excluded from this uniqueness argument. In the retained leading radiation system the Friedmann equation also fixes sigma=y² at u=0, with scriptH²=2(1+k)y²/3. Thus the scalar equations and constraint admit the known matched radiation amplitude; the algebra is not merely an inconsistent necessary root.

As a direct check of the singular selection inference, at fixed u,

    (2c_y'+lambda_y c_y)/k² → exp(-2u)-exp(-u),
    [(2c_y'+lambda_y c_y)/K_u]/k → 4(exp(-u)-1).

The finite-k root condition disappears at leading normalized weak order. These limits quantify degeneration of this frozen-state condition, not an attraction rate of the full coupled system. Unique constant-u scaling at each positive k cannot by itself retire an initial-state assumption over a finite cosmological duration.

## 6. Original finding and affected-source confirmation

The original radiation note wrote Hhat²=U_y/c_y without defining a new use of U_y or normalizing Hhat by H_v. In the inherited note U_y is a field derivative. That literal reading fails: substituting scriptH²=(partial U/partial y)/c_y leaves lowered ell residual c_y(y-2). For u=0, k=1/10 and y=3 it is 1/22 rather than zero. The unique-u algebra following that line was nevertheless correct when U_y was intended as the potential contribution.

The complete parent RADIATION_DERIVATION_v2.md now defines V_y and scriptH², and supplies the equivalent derivative formula. Its exact diff changes only this paragraph. I read the complete corrected note and confirm the repair. The v1 source, original finding, concrete failed literal-notation probe, and both source hashes remain preserved.
