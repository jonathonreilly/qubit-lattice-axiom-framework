# Focused independent radiation-reduction review

The corrected radiation derivation is mathematically consistent with the supplied inherited action in its declared restricted, ordered limit. The single identified source issue, an ambiguous potential derivative and Hubble normalization in the finite-k paragraph, is repaired in the separately preserved v2. There is no remaining requested correction within this scope.

The complete independent argument is in `INDEPENDENT_DERIVATION_v1.md`. It derives the equations from the homogeneous action in physical (u,y) coordinates before transforming to log y. It independently checks the invariant x=0 restriction, the fixed family, every Jacobian entry, characteristic polynomials, physical C_exp cancellation, and the finite-k constant-u condition, including the compatible leading Friedmann amplitude. No producer code or function is used as an oracle.

## Findings and scope

1. **Original finite-k notation/normalization issue; corrected.** In v1, `Hhat²=U_y/c_y` conflicted with the inherited meaning U_y=partial U/partial y. The correct dimensionless relation is Hhat²/H_v²=V_y/c_y=y(partial U/partial y)/(2c_y), where V_y=(k/3)y² exp(-lambda_y u). A concrete literal-reading probe leaves residual 1/22. Parent v2 defines precisely this contribution and normalization. The affected full-text review and exact diff confirm the narrow correction; no later equation changes.
2. **Reduced equations and fixed family agree.** The independently varied action gives the four stated radiation equations, fixed family (c,c/2,0,-2), neutral tangent (1,1/2,0,0), and eigenvalues 0, -1, (-1±i sqrt(63))/2. The three-dimensional quotient is smooth and has a strictly Hurwitz linearization. No explicit nonlinear neighborhood, global basin, finite-time relaxation bound, or physical state measure is supplied by this computation.
3. **C_exp cancellation agrees.** The general reduced readout is exp(-u)[exp(2z-u)/3+p²/12+q²/6+p-1]. Its family restriction vanishes identically. This prevents selection of c using this first expansion coefficient in this limit; it does not show equality of all observables, finite-k histories, or later-time readouts.
4. **Finite-k uniqueness is restricted and correctly scoped.** For fixed 0<k<1/3, the constant-u radiation scaling condition factors as 2alpha s k(1-E)/[(1+k)F²]. Its unique root is u=0. The root condition becomes degenerate at normalized weak order. Neither this algebra nor the weak-limit transverse spectrum proves rapid selection during a finite radiation era.
5. **Order and domain remain essential.** The inherited compact-state weak-coupling theorem does not automatically cover y or y'=yq tending to infinity. This check validates the stated iterated weak-then-large-radiation limit for fixed finite normalized state. It does not exchange that limit with infinite evolution time, prove a joint uniform estimate, or cover traceful thermal transitions, dust, or vacuum domination. No claim about the parent's new counterfactual histories or later energy proof is included.

The supplied action, its kinetic/matter readout normalization, ideal radiation, expanding e-fold clock, positive y chart, fixed model parameters, and the x=x'=0 restriction are explicit conditions. No observational data, new fitted quantity, empirical likelihood, retained-grade premise, or framework-origin assertion enters this check. The action remains supplied. The algebraic reduction is closed under those conditions; physical initial-state selection remains open as stated.

## Independent computation and preserved failures

The successful reviewer-only `independent_radiation_check_v2.py` completed in about one second and passed 54 exact identities. All complete result rows were inspected. Three actual damaged-equation probes were rejected:

- Differentiating the radiation potential after imposing the family halves the u force, producing fixed-family p' residual -2.
- Dropping the pq metric-connection term preserves the fixed family but changes the Jacobian by +2 in its q',p entry. This demonstrates why a fixed-family test alone is insufficient.
- Replacing radiation friction by three produces fixed-family q' residual 4.

These are explicit independent algebraic mutations, not a claim about end-to-end producer-runner coverage. The separate literal-v1-notation probe intentionally remains a failed zero-residual assertion, recorded distinctly from the 54 successful corrected-formula checks.

The first reviewer execution failed at a coefficient assertion because SymPy's `Matrix.charpoly` produced an assumption-free `lambda` generator distinct from the reviewer-created real `lambda`. The two apparent polynomial residuals, failed coefficient extraction, original script, stderr, frozen inputs and exit code are preserved. The v2 reviewer script changes only that symbol identity and the output filename. It does not change any mathematical expression, expected coefficient, or tolerance. The corrected symbol yields the exact original target coefficients. There is no numerical tolerance in these checks.

Two parent-reported stream disconnect requests are separately recorded in `ATTEMPT_HISTORY_v1.json`. They caused no parent source modification or discarded computation. The surviving successful symbolic computation was inspected, not rerun after the recovery request. A truncated procedural-reference tool response was recovered by reading the needed references in smaller calls; it did not affect scientific input or output.

## Source disposition and review boundary

Complete sources read and snapshotted: original radiation v1, corrected radiation v2, inherited exponential DERIVATION_v1, and inherited REGULAR_LIMIT_DERIVATION_v1. The inherited notes retain their exact prior hashes. All four current files match the frozen snapshots at final confirmation. `SOURCE_DISPOSITIONS_v1.json` maps each original to its immutable recovery and current hash. `FINAL_RECEIPT_v1.json` binds every input and evidence artifact, including failed attempts and both reviewer scripts.

This was one focused initial review plus same-session correction confirmation. No parent source was edited, no author history or positive producer runner was executed, and no audit, branch integration, PR, or formal claim-status operation was performed. Applicable proof, physical-scope, import, and source-identity lenses were used from the review-loop guidance; landing-only pipeline and publication steps are outside the explicitly assigned task. There is one corrected finding and no unresolved finding within the checked radiation reduction. This is not an initial-state-selection proof or an empirical validation.
