"""Independent radiation reduction from the homogeneous N-clock action.
No parent source code or produced equation helper is imported.
"""
from pathlib import Path
import datetime, hashlib, json, sys, time
import sympy as s
OUT=Path(__file__).resolve().parent
checks=[]
def equal(name,a,b):
    z=s.simplify(a-b)
    checks.append({'name':name,'actual':str(a),'expected':str(b),'residual':str(z),'passed':z==0})
def components(name,a,b):
    for i,(aa,bb) in enumerate(zip(a,b)):equal(name+'.'+str(i),aa,bb)

def el_lowered(gdiag,V,coords,speeds,accels,B,h):
    """Euler-Lagrange/(2 a^3 H) for L_N/(a^3 H)=g v.v-2V/B.
    B=H^2/Hv^2 is a time-only external coefficient in field derivatives.
    """
    lag=sum(gi*vi**2 for gi,vi in zip(gdiag,speeds))-2*V/B
    momentum=s.Matrix([s.diff(lag,vi) for vi in speeds])
    dt=momentum.jacobian(coords)*s.Matrix(speeds)+momentum.jacobian(speeds)*s.Matrix(accels)
    grad=s.Matrix([s.diff(lag,qi) for qi in coords])
    return (dt+(3+h)*momentum-grad)/2

started=datetime.datetime.now(datetime.timezone.utc).isoformat();start=time.monotonic()
u,x,y,p,v,ax,ay,nu0,B,h=s.symbols('u x y p v ax ay nu B h',real=True)
yb,Z=s.symbols('yb Z',positive=True)
q,z,c,lam,w=s.symbols('q z c lambda w',real=True)
t=s.exp(-u)
D=1+s.Rational(2,3)*y*y
G=[t/4,t/(3*D)]
W=s.Rational(3,2)*(1-t)**2+t*t*(y*y/3+nu0*u*u/2)
el=el_lowered(G,W,[u,y],[p,v],[ax,ay],B,h)
sol=s.solve(el,[ax,ay],simplify=False)
full_p=s.factor(sol[ax]);full_q=s.factor(sol[ay]/y-q*q)
replace={v:y*q,h:-s.Rational(4,3)*yb**2/(1+s.Rational(2,3)*yb**2),B:1+s.Rational(2,3)*yb**2}
def rad_limit(expr):
    return s.simplify(s.limit(expr.subs(replace).subs(y,Z*yb),yb,s.oo).subs(Z,s.exp(z)))
rp=rad_limit(full_p);rq=rad_limit(full_q)
Ew=s.exp(2*z-u)
expected_p=-p+p*p/2-q*q+4*Ew
expected_q=-q+p*q-2*Ew
equal('large_y_u_equation_from_action',rp,expected_p)
equal('large_y_log_y_equation_from_action',rq,expected_q)
equal('log_y_metric_limit',s.limit((G[1]*y*y).subs(y,Z*yb),yb,s.oo),t/2)
equal('u_metric',G[0],t/4)
equal('potential_over_B_limit',rad_limit(W/B),s.exp(2*z-2*u)/2)
# The restriction x=p_x=0 has no scalar x-force or kinetic-connection source.
D3=1+s.Rational(2,3)*(x*x+y*y)
G3=[t/4,t*s.Rational(4,9)/D3,t/(3*D3)]
W3=s.Rational(3,2)*(1-t)**2+t*t*(x*x/2+y*y/3+nu0*u*u/2)
equal('x_potential_restriction',s.diff(W3,x).subs(x,0),0)
for i,gi in enumerate(G3):equal('x_metric_restriction_'+str(i),s.diff(gi,x).subs(x,0),0)
# Exact fixed family and full Jacobian are generated from the independent flow.
f=s.Matrix([p,q+2,rp,rq]);state=[u,z,p,q]
fam={u:c,z:c/2,p:0,q:-2}
components('fixed_family',f.subs(fam),s.zeros(4,1))
M=s.simplify(f.jacobian(state).subs(fam))
Mclaimed=s.Matrix([[0,0,1,0],[0,0,0,1],[-4,8,-1,4],[2,-4,-2,-1]])
components('full_Jacobian',M,Mclaimed)
poly=s.factor(M.charpoly(lam).as_expr())
equal('full_characteristic_polynomial',poly,lam*(lam+1)*(lam*lam+lam+16))
components('neutral_tangent',M*s.Matrix([1,s.Rational(1,2),0,0]),s.zeros(4,1))
# Quotient by the exact u,z translation, without solving an empirical history.
f3=s.Matrix([2*(q+2)-p,rp,rq]).subs(z,(w+u)/2)
f3=s.simplify(f3)
for i,fi in enumerate(f3):equal('quotient_independent_of_u_'+str(i),s.diff(fi,u),0)
J3=f3.jacobian([w,p,q]).subs({w:0,p:0,q:-2})
equal('transverse_characteristic_polynomial',J3.charpoly(lam).as_expr(),(lam+1)*(lam*lam+lam+16))
# Preserve the exact Hurwitz information, not merely a numerical eigenvalue sign.
coeffs=s.Poly(J3.charpoly(lam).as_expr(),lam).all_coeffs()
assert coeffs==[1,2,17,16]
equal('Hurwitz_strict_margin_a1a2_minus_a3',coeffs[1]*coeffs[2]-coeffs[3],18)
# C_exp is reduced directly from the inherited constraint/readout expression.
T=G[0]*p*p+G[1]*y*y*q*q
sigma=yb*yb
C=2*(W+sigma*(1-2*t))/(3*B)+T/3+t*p-1+t
Cr=rad_limit(C)
Cgeneric=t*(s.exp(2*z-u)/3+p*p/12+q*q/6+p-1)
equal('generic_radiation_C_from_constraint',Cr,Cgeneric)
equal('C_on_entire_family',Cr.subs(fam),0)
equal('W_over_B_on_family',rad_limit(W/B).subs(fam),s.exp(-c)/2)
equal('sigma_over_B_radiation',s.limit(sigma/(1+s.Rational(2,3)*yb**2),yb,s.oo),s.Rational(3,2))
equal('T_on_family',rad_limit(T).subs(fam),2*s.exp(-c))
# Finite coupling: independent homogeneous-action equations in (u,ell).
k,alpha,ss,E=s.symbols('k alpha s E',positive=True)
ell=s.symbols('ell',real=True)
H2=s.symbols('H2',positive=True)
lamy=4*alpha*ss/(1+ss)
F=1+ss*s.exp(2*alpha*u)
J=1+(1-3*alpha**2)*ss*s.exp(2*alpha*u)
Ku=J/F**2
cy=(1+ss)*k/(2*(1+k)*F)
Ky=(1+ss)*k/(3*F*(1+s.Rational(2,3)*(1+k)*y*y))
equal('finite_k_log_metric',s.limit(y*y*Ky,y,s.oo),cy)
Vy=k*s.exp(2*ell-lamy*u)/3
elf=el_lowered([Ku,cy],Vy,[u,ell],[p,q],[ax,ay],H2,-2)
fixed_el=s.simplify(elf.subs({p:0,q:-2,ax:0,ay:0}))
H2solve=s.solve(fixed_el[1],H2)[0]
equal('finite_k_y_equation_normalized_H',H2solve,Vy/cy)
u_el=s.factor(fixed_el[0].subs(H2,H2solve))
condition=s.factor(2*s.diff(cy,u)+lamy*cy)
equal('finite_k_u_lowered_equation',u_el,-condition)
factor=2*alpha*ss*k*(1-s.exp(2*alpha*u))/((1+k)*F**2)
equal('finite_k_unique_root_factor',condition,factor)
equal('finite_k_root_u0',condition.subs(u,0),0)
# Friedmann consistency fixes the radiation amplitude after the u=0 root.
H20=s.simplify(H2solve.subs(u,0));cy0=s.simplify(cy.subs(u,0));Vy0=Vy.subs(u,0)
sigma_required=s.simplify((3-4*cy0)*H20/2-Vy0)
equal('finite_k_scaling_radiation_amplitude',sigma_required,s.exp(2*ell))
equal('finite_k_u0_H_normalization',H20,s.Rational(2,3)*(1+k)*s.exp(2*ell))
# Weak-coupling degeneration of this exact fixed-state condition.
a=(1-k)*(1+3*k)/4
specific={alpha:s.sqrt(a),ss:(1+k)/(k*(1-3*k))}
equal('finite_k_condition_leading_order',s.limit(condition.subs(specific)/k**2,k,0,dir='+'),s.exp(-2*u)-s.exp(-u))
equal('finite_k_acceleration_residual_leading_order',s.limit((condition/Ku).subs(specific)/k,k,0,dir='+'),4*(s.exp(-u)-1))
# Original inherited notation U_y means partial_y U. Its literal reuse fails.
physicalUy=2*k*y*s.exp(-lamy*u)/3
Vyphysical=k*y*y*s.exp(-lamy*u)/3
literal_ell_residual=s.factor((-2*cy+2*Vyphysical/H2).subs(H2,physicalUy/cy))
equal('literal_derivative_notation_residual_formula',literal_ell_residual,cy*(y-2))
example=s.simplify(literal_ell_residual.subs({u:0,k:s.Rational(1,10),y:3}))
notation_probe={'interpretation':'Treat U_y as inherited partial derivative, and put H2=U_y/c_y','fixture':{'u':0,'k':'1/10','y':3},'actual_lowered_ell_residual':str(example),'expected':'0','passed':example==0,'classification':'original notation ambiguity; not a change to the subsequent unique-root algebra'}
# Deliberate independent damaged-equation probes, with exact outcomes preserved.
mut=[]
for name,mut_f in [
    ('differentiate_potential_after_imposing_family',s.Matrix([p,q+2,-p+p*p/2-q*q+2*Ew,rq])),
    ('drop_log_y_pq_connection',s.Matrix([p,q+2,rp,-q-2*Ew])),
    ('replace_radiation_friction_by_three',s.Matrix([p,q+2,rp-2*p,rq-2*q]))]:
    family_res=s.simplify(mut_f.subs(fam))
    jacres=s.simplify(mut_f.jacobian(state).subs(fam)-M)
    rejected=any(vv!=0 for vv in family_res) or any(vv!=0 for vv in jacres)
    mut.append({'name':name,'family_residual':[str(vv) for vv in family_res],'Jacobian_residual':str(jacres),'rejected':rejected})
res={'started_at_utc':started,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-start,'python':sys.version,'sympy':s.__version__,'method':'Euler-Lagrange from homogeneous action in (u,y), then asymptotic substitution and coordinate conversion; independent finite-k (u,ell) action','checks':checks,'counts':{'passed':sum(vv['passed'] for vv in checks),'failed':sum(not vv['passed'] for vv in checks)},'full_u_equation':str(full_p),'full_log_y_equation':str(full_q),'radiation_flow':[str(vv) for vv in f],'Jacobian':str(M),'characteristic_polynomial':str(poly),'transverse_flow':[str(vv) for vv in f3],'transverse_Jacobian':str(J3),'generic_C':str(Cr),'finite_k_condition':str(condition),'original_notation_failure_probe':notation_probe,'mutations':mut}
(OUT/'SYMBOLIC_RESULTS_v1.json').write_text(json.dumps(res,indent=2)+'\n')
print(json.dumps({'counts':res['counts'],'notation_probe':notation_probe,'mutations_rejected':[vv['rejected'] for vv in mut],'elapsed_seconds':res['elapsed_seconds']}))
raise SystemExit(any(not vv['passed'] for vv in checks) or any(not vv['rejected'] for vv in mut))
