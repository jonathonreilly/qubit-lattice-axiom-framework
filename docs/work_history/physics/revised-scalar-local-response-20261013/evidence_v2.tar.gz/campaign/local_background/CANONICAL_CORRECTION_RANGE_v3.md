# Vacuum-range scope repair

The independent canonical review found a substantive prose overclaim introduced during packaging: cosmological Hv alone does not imply a cosmological scalar range on the entire nu>0,0<k<1/3 domain. The exact dimensionless mass factor can be unbounded. The final paragraph now restores the original local-force qualification nu=1 and small k, explicitly explains the nonuniform limits, and keeps Hv as a supplied calibration. All Hessian equations and runner bytes are unchanged. Both earlier canonical versions/cache snapshots remain preserved.
