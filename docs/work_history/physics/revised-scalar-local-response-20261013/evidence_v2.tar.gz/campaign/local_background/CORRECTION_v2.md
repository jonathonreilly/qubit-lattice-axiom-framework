# Clarification in v2

The parent identified and the independent checker confirmed that the elementary sphere formula (13) is the mu=0 limit, not the solution at general mu. Version2 explicitly says so and identifies the mass as the integral of the prescribed background Einstein density. No formula or parent runner changed. The frozen v1 and all its outputs remain preserved.
