# Coupling, local gravity and the scalar energy away from the vacuum

Direct author: /root. Conditional mathematics from the inherited candidate
action; no new action, parameter fit or independent observational test.
This block removes the exact-vacuum restriction from the coupling algebra.
The finite-distance cosmological/environmental matching remains a separate
physical requirement. The previously exposed Cassini interval is used to ask
which scalar backgrounds would be required, rather than selecting u=0.

## Principal weak-source response

Use the full action and definitions in the canonical future-confinement note,
with 0<k<1/3, nu>0, A=sqrt(C), and Gstar=1/(8 pi Q). The scalar action has
normalization -2 K_AB partial(phi^A)partial(phi^B) inside 1/(16 pi Gstar).
At any finite background b=(u,x,y), the matter covector is

    alpha_A = partial_A log A = (sqrt(a)/F,0,0).

Its squared field-metric norm, not a chosen field coordinate, controls the
leading weak-source strength:

    g = alpha_A K^{AB} alpha_B = a/J > 0.                 (1)

There is no x,y dependence in (1). In a locally frozen background, the
principal static equation in Einstein coordinates is

    Delta delta_phi^A = 4 pi Gstar K^{AB} alpha_B rho_E/c^2.

For an isolated weak source, negligible mass/mixing and time-dependent
terms on the tested length scale, and a perturbation decaying to that
background, its monopole is delta_phi^A=-alpha^A Ustar. At constant A_b,
M_E=A_b M_J and r_J=A_b r_E, so Ustar=Gstar C_b M_J/(r_J c^2).
Conformal multiplication of the Einstein metric then gives

    Phi_J=Ustar(1+g), Psi_J=Ustar(1-g),
    G_loc=Gstar C_b(1+g), gamma_eff-1=-2g/(1+g).          (2)

This is a conditional short-distance/long-range weak-source coefficient,
not a reconstructed Cassini light-time likelihood. A rolling background
need not be a critical point of U. Potential Hessians, background velocities,
metric constraints, environmental profiles and finite-source corrections
must be controlled before (2) becomes a finite-distance prediction for a
particular cosmological history. No vacuum mass is substituted at non-vacuum
points. The principal response itself follows from the action without a
vacuum choice; the omitted-terms estimate is not proved here.

## Exact relation to the future energy variable

Let s=(1+k)/(k(1-3k)), alpha=sqrt(a), chi=s(C-1). Then

    chi=s(E-1)/(1+sE), -s<chi<1,
    E=(1+chi/s)/(1-chi),
    g=k(1-chi)/(1-3k chi),
    dg/dchi=-k(1-3k)/(1-3k chi)^2 < 0.                  (3)

All finite real fields lie in this domain. The positive scalar energy is
e=K_AB v^A v^B/2+U-3/2, where v=dphi/d(Hv t_E), and Z=s e. Positivity of
the other potential and kinetic terms gives the exact necessary inequality

    Z >= 3 chi^2/2.                                    (4)

Consequently Z<=Zstar<3/2 implies |chi|<=w=sqrt(2 Zstar/3)<1 and

    k(1-w)/(1-3k w) <= g <= k(1+w)/(1+3k w).             (5)

The previous future theorem supplies one sufficient way to stay in this
region. It is not a necessary condition for a viable physical history.
Failing that theorem's criterion cannot be treated as an exclusion.

If (2) applies and an observation requires g<=b, with 0<b<k<1/3, then

    chi >= chi_req=(k-b)/(k(1-3b)) in (0,1),
    u >= log[(1+chi_req/s)/(1-chi_req)]/(2 alpha),
    Z >= 3 chi_req^2/2.                                 (6)

For k<=b there is no positive universal energy floor from this argument:
the vacuum already has g=k. In particular, squaring a negative chi_req to
claim a positive lower bound would be an error. For 0<nu<=6a a sharper
bound follows from the already proved monotonicity of U(u,0,0) for u>0:

    Z >= 3 chi_req^2/2
       + nu s u_req^2(1-chi_req)^2/[2(1+s)].             (7)

Other fields and kinetic energy cannot lower (7). This uses the stated nu
condition, not monotonicity of each separate summand in the potential.
As b/k becomes small at fixed k, the necessary lower bound approaches the
finite-field boundary energy 3/2. This is an energy cost of suppressing
the coupling by the background, not a proof that such a state is impossible.

For illustration only, the already exposed published value
gamma-1=(2.1+-2.3)e-5 (one quoted error) has a two-quoted-error lower edge
-2.5e-5. Under (2), that interval gives b=1/79999. This is a conditional
interval proxy, not a new confidence limit or a fit to raw radio data.
Source: Bertotti, Iess and Tortora, Nature425,374 (2003),
https://doi.org/10.1038/nature01997. The campaign has read the publisher's
abstract value, not the complete experimental likelihood. All such evidence
was already exposed during model development.

## An exact local-gravity cancellation, not absence of a scalar force

Since Q(k)=Q0(1+k), put G0=1/(8 pi Q0). The conditional coefficient in (2)
satisfies exactly

    R_G=G_loc/G0=C(1+g)/(1+k)
       =1-B chi^2/(1-3k chi),
    B=4k^2(1-3k)/(1+k)^2.                              (8)

Thus 0<R_G<=1, with equality only at u=0. The first derivative there
vanishes even though g=k remains nonzero. This explains why near agreement
of the inferred Newton strength alone cannot establish a small light-time
deviation. At fixed compact chi as k->0, R_G-1 is O(k^2) while g is O(k).
The assertion is not uniform near the moving lower boundary chi=-s.

For a homogeneous history p_u=du/dN and N_J=N+log A, differentiation gives

    chi_u=2 alpha (s+chi)(1-chi)/(1+s),
    d log R_G/dN_J = [-B chi(2-3k chi)/(1-3k chi)^2]
                    chi_u p_u/[R_G(1+alpha_B p_u)],
    alpha_B=alpha(1-chi)/(1+s).                         (9)

This is a derivative of the conditional coefficient, not a complete
prediction for an environmental measurement of dot G. No mass or time
calibration is needed to evaluate the dimensionless expression (9).

## The density-feedback sign throughout the trapped region

The u-coordinate lines at fixed x,y are field-space geodesics, since K_u
depends only on u and the kinetic metric is diagonal. Along them choose
dvarphi/du=sqrt(K_u). Then alpha_m=d log A/dvarphi=sqrt(g), and

    beta_m=dalpha_m/dvarphi
          =-[1+k+k(1-3k)chi]/(1-3k chi)^2,
    (1/A) d^2 A/dvarphi^2 = beta_m+g
          =-(1-k chi)(1+3k chi)/(1-3k chi)^2.           (10)

For every |chi|<1 and 0<k<1/3 this expression is strictly negative.
Therefore the negative density-mass feedback found at the vacuum does
not disappear by moving within the energy region Z<3/2. Holding conserved
Einstein-coordinate rest density rho0 fixed, rho_E=A_b rho0, gives the
one-direction, locally frozen linear prescribed-source problem

    (Delta-mu^2+4 pi Gstar rho_E eta/c^2) delta_varphi
       =4 pi Gstar alpha_m rho_E/c^2,
    eta=-(beta_m+g)>0.                                 (11)

Here a nonnegative mu^2 is a specified operator coefficient; (11) does not
assert that the full coupled cosmological perturbations have one such
mass. Taking mu=0 is the principal approximation. Pressure, gravity and
source redistribution are omitted, as in the earlier finite-source block.

For that scalar operator, define the positive Yukawa integral operator
T_mu using rho_E and Gstar/c^2. If q=sup T_0 1 and eta q<1, the solution
decaying at infinity is

    delta_varphi=-alpha_m sum_(n>=0) eta^n T_mu^(n+1) 1,
    ||delta_varphi||_infinity <= alpha_m q/(1-eta q).    (12)

Its field amplitude and effective source are enhanced relative to the
no-feedback problem. This says nothing about arbitrary force-vector
ordering, the omitted terms, or all nonlinear compact objects. In the mu=0 limit, for a
uniform ball let Phi=Gstar M_E/(Rc^2) and z=sqrt(3 eta Phi), with
M_E=integral rho_E d^3r evaluated at the prescribed background. Then

    delta_varphi_in/alpha_m=(1/eta)[1-sin(zr/R)/((zr/R)cos z)],
    delta_varphi_out=-alpha_m Gstar M_E F_body/(r c^2),
    F_body=3(tan z-z)/z^3=1+(6/5)eta Phi+O(Phi^2).      (13)

The same derivative-sign argument fails sufficiently far outside the
trapped region. Equation (10) changes sign at chi=-1/(3k), corresponding
to E=2k/(1+k). No blanket no-screening theorem is claimed.

## Frozen computation and remaining assumptions

Check (1),(3)-(10) directly from A,K and U with exact algebra and independent
high-precision derivatives. Check the generalized ball matching, not only
eta=1. Evaluate (3),(8),(9) at all ten finite-k endpoints of the already
completed27-history set. These are exposed theory-development histories;
no endpoint selection, fit, new data or complete history rerun is involved.
Use exact decimal stored endpoint values, not the last internal RHS call.
Keep the weak k=0 reference out of finite-k action conclusions.

The action and matter metric still remain candidate assumptions. The block
replaces a vacuum choice in the coupling algebra with explicit state
dependence and a necessary energy cost. It does not derive k, nu, Hv, the
observed initial state, a cosmological-to-local matching solution, or a TOE.
