#!/usr/bin/env python3
"""Direct-author conditional coupling/energy block; no fit or ODE rerun."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import mpmath as mp
import sympy as sp

HERE = Path(__file__).resolve().parent
PACK = HERE.parent
CHECKS = []


def check(name, ok, **detail):
    CHECKS.append(dict(name=name, passed=bool(ok), **detail))


def identity(name, value):
    residue = sp.factor(sp.cancel(sp.trigsimp(value)))
    check(name, residue == 0, residue=str(residue))


def near(name, actual, expected, tolerance):
    error = abs(actual - expected) / max(mp.mpf(1), abs(expected))
    check(name, mp.isfinite(error) and error <= mp.mpf(tolerance),
          scaled_error=mp.nstr(error, 12), tolerance=tolerance)


def exact():
    k, E = sp.symbols('k E', positive=True)
    chi, w, b = sp.symbols('chi w b', real=True)
    a = (1-k)*(1+3*k)/4
    s = (1+k)/(k*(1-3*k))
    d = 1-3*a
    F, J = 1+s*E, 1+d*s*E
    C, Ku = (1+s)*E/F, J/F**2
    # d/du = 2 sqrt(a) E d/dE. This is the exact derivative of log sqrt(C).
    ab = sp.sqrt(a)*E*sp.diff(sp.log(C), E)
    raw_g = sp.cancel(ab**2/Ku)
    raw_beta = -a*d*s*E*F/J**2
    Em = (1+chi/s)/(1-chi)
    gm = k*(1-chi)/(1-3*k*chi)
    betam = -(1+k+k*(1-3*k)*chi)/(1-3*k*chi)**2
    etam = (1-k*chi)*(1+3*k*chi)/(1-3*k*chi)**2
    B = 4*k**2*(1-3*k)/(1+k)**2
    Rm = 1-B*chi**2/(1-3*k*chi)
    chiu = 2*sp.sqrt(a)*(s+chi)*(1-chi)/(1+s)
    chiE = s*(E-1)/F
    identities = {
        'coupling_from_A_and_K': raw_g-a/J,
        'inverse_field_map': chiE.subs(E, Em)-chi,
        'coupling_chi': raw_g.subs(E, Em)-gm,
        'coupling_monotonic_derivative': sp.diff(gm, chi)+k*(1-3*k)/(1-3*k*chi)**2,
        'vacuum_beta': raw_beta.subs(E, 1)+(1+k),
        'beta_chi': raw_beta.subs(E, Em)-betam,
        'density_feedback': betam+gm+etam,
        'density_sign_change': etam.subs(chi, -1/(3*k)),
        'density_sign_change_field': Em.subs(chi, -1/(3*k))-2*k/(1+k),
        'eta_monotonic': sp.diff(etam, chi)-8*k/(1-3*k*chi)**3,
        'Newton_strength_cancellation': (C*(1+raw_g)/(1+k)).subs(E, Em)-Rm,
        'Newton_strength_derivative': sp.diff(Rm, chi)+B*chi*(2-3*k*chi)/(1-3*k*chi)**2,
        'Newton_vacuum_derivative': sp.diff(Rm, chi).subs(chi, 0),
        'chi_u': (2*sp.sqrt(a)*E*sp.diff(chiE, E)).subs(E, Em)-chiu,
        'vacuum_energy_floor': sp.Rational(3, 2)*s**2*(E-1)**2/F**2-sp.Rational(3, 2)*chiE**2,
        'observational_inversion': gm.subs(chi, (k-b)/(k*(1-3*b)))-b,
        'trapped_minimum': gm.subs(chi, w)-k*(1-w)/(1-3*k*w),
        'trapped_maximum': gm.subs(chi, -w)-k*(1+w)/(1+3*k*w),
        'weak_limit_Newton_second_order': sp.limit((Rm-1)/k**2, k, 0)+4*chi**2,
        'weak_limit_coupling_first_order': sp.limit(gm/k, k, 0)-(1-chi),
    }
    for name, value in identities.items():
        identity('exact.'+name, value)
    # Generalized eta, not only the previously checked vacuum eta=1 case.
    z, r, eta = sp.symbols('z r eta', positive=True)
    interior = (1-sp.sin(z*r)/(z*r*sp.cos(z)))/eta
    exterior = -(sp.tan(z)/z-1)/(eta*r)
    identity('ball.ODE', sp.diff(interior, r, 2)+2*sp.diff(interior, r)/r+z**2*interior-z**2/eta)
    identity('ball.field_match', interior.subs(r, 1)-exterior.subs(r, 1))
    identity('ball.derivative_match', sp.diff(interior, r).subs(r, 1)-sp.diff(exterior, r).subs(r, 1))
    identity('ball.center_regular', sp.limit(sp.diff(interior, r), r, 0))
    identity('ball.charge_series', sp.series(3*(sp.tan(z)-z)/z**3, z, 0, 6).removeO()-(1+2*z**2/5+17*z**4/105))
    # Algebraic negative controls, not damaged full-script runs.
    for name, residual in {
        'wrong_Newton_linear_term': Rm-(1-k*chi),
        'wrong_density_sign': 2*etam,
        'wrong_coupling_denominator': gm-k*(1-chi)/(1-2*k*chi),
        'wrong_inversion': gm.subs(chi, (k-b)/k)-b,
    }.items():
        val = residual.subs({k:sp.Rational(1, 100), chi:sp.Rational(1, 3), b:sp.Rational(1, 79999)})
        check('algebraic_negative_control.'+name, sp.cancel(val) != 0, residue=str(sp.cancel(val)))
    return {'g':str(gm), 'beta':str(betam), 'eta':str(etam), 'Newton_ratio':str(Rm), 'chi_u':str(chiu)}


def quantities(k, u):
    a=(1-k)*(1+3*k)/4; al=mp.sqrt(a); s=(1+k)/(k*(1-3*k))
    E=mp.exp(2*al*u); F=1+s*E; J=1+(1-3*a)*s*E
    C=(1+s)*E/F; chi=s*(E-1)/F; g=a/J
    beta=-a*(1-3*a)*s*E*F/J**2
    eta=(1-k*chi)*(1+3*k*chi)/(1-3*k*chi)**2
    B=4*k*k*(1-3*k)/(1+k)**2
    delta_R=-B*chi*chi/(1-3*k*chi)
    return dict(a=a,al=al,s=s,E=E,F=F,J=J,C=C,Ku=J/F**2,
                chi=chi,g=g,beta=beta,eta=eta,delta_R=delta_R,R=1+delta_R,
                ab=al/F,chi_u=2*al*(s+chi)*(1-chi)/(1+s),B=B)


def high_precision(protocol):
    rows=[]
    for ks in protocol['derivative_k']:
        k=mp.mpf(ks)
        for us in protocol['derivative_u']:
            u=mp.mpf(us); q=quantities(k,u)
            # Actual numerical differentiation of A and K, not the closed beta.
            A=lambda v:mp.sqrt(quantities(k,v)['C'])
            K=lambda v:quantities(k,v)['Ku']
            alpha=lambda v:mp.diff(lambda w:mp.log(A(w)),v)/mp.sqrt(K(v))
            beta=mp.diff(alpha,u)/mp.sqrt(K(u))
            tag=f'high_precision.k{ks}.u{us}'
            near(tag+'.alpha',alpha(u),mp.sqrt(q['g']),'1e-60')
            near(tag+'.beta',beta,q['beta'],'1e-60')
            near(tag+'.density_feedback',beta+alpha(u)**2,-q['eta'],'1e-60')
            near(tag+'.Newton',q['C']*(1+q['g'])/(1+k),q['R'],'1e-60')
            direct_derivative=mp.diff(lambda v:mp.log(quantities(k,v)['C']*(1+quantities(k,v)['g'])/(1+k)),u)
            factor=-q['B']*q['chi']*(2-3*k*q['chi'])/(1-3*k*q['chi'])**2
            near(tag+'.Newton_derivative',direct_derivative,factor*q['chi_u']/q['R'],'1e-60')
            check(tag+'.positive_G',0<q['R']<=1)
            if abs(q['chi'])<1:
                check(tag+'.trapped_negative_feedback',q['eta']>0)
            rows.append({'k':ks,'u':us,**{n:mp.nstr(q[n],35) for n in ['chi','g','eta','delta_R']}})
    return rows


def observational_costs(protocol):
    b=mp.mpf(1)/int(protocol['conditional_interval']['b_denominator'])
    nu=mp.mpf(protocol['nu_for_cost'])
    out=[]
    for ks in protocol['cost_k']:
        k=mp.mpf(ks);q0=quantities(k,mp.mpf(0))
        if k<=b:
            out.append(dict(k=ks,positive_energy_floor=False,lower_Z='0'))
            continue
        chi=(k-b)/(k*(1-3*b))
        u=mp.log((1+chi/q0['s'])/(1-chi))/(2*q0['al'])
        q=quantities(k,u);Z=mp.mpf('1.5')*chi**2
        stronger=Z+nu*q0['s']*u*u*(1-chi)**2/(2*(1+q0['s']))
        near('cost.k'+ks+'.saturation',q['g'],b,'1e-60')
        check('cost.k'+ks+'.domain',0<chi<1 and 0<Z<mp.mpf('1.5'))
        check('cost.k'+ks+'.nu_range',0<nu<=6*q['a'])
        out.append(dict(k=ks,positive_energy_floor=True,chi_required=mp.nstr(chi,40),
                        u_required=mp.nstr(u,40),lower_Z=mp.nstr(Z,40),
                        lower_Z_with_nu_condition=mp.nstr(stronger,40),
                        remaining_gap_to_boundary=mp.nstr(mp.mpf('1.5')-stronger,40)))
    return out


def endpoints(protocol):
    out=[];b=mp.mpf(1)/int(protocol['conditional_interval']['b_denominator'])
    for name in protocol['endpoint_files']:
        d=json.loads((PACK/name).read_text()); case=d['case'];last=d['rows'][-1]
        k=mp.mpf(str(case['k']));u=mp.mpf(str(last['state'][0]));pu=mp.mpf(str(last['state'][3]))
        check('endpoint.'+case['id']+'.finite_complete',k>0 and d['success'] and len(d['rows'])==241)
        q=quantities(k,u);njp=1+q['ab']*pu
        derivative=(-q['B']*q['chi']*(2-3*k*q['chi'])/(1-3*k*q['chi'])**2)*q['chi_u']*pu/(q['R']*njp)
        near('endpoint.'+case['id']+'.stored_Newton',q['R'],mp.mpf(str(last['GNratio'])),'2e-14')
        check('endpoint.'+case['id']+'.positive_clock',njp>0)
        # Required by energy trapping, but only the scalar potential floor is evaluated here.
        row={'case':case['id'],'k':str(k),'u':str(u),'p_u':str(pu),
             'actual_stored_endpoint_L':last['L'],'scalar_potential_energy_floor_Z':mp.nstr(mp.mpf('1.5')*q['chi']**2,35),
             'conditional_gamma_minus_one':mp.nstr(-2*q['g']/(1+q['g']),35),
             'conditional_interval_proxy_satisfied':bool(q['g']<=b),
             'conditional_dlogG_dNJ':mp.nstr(derivative,35),
             **{n:mp.nstr(q[n],35) for n in ['chi','g','eta','delta_R']}}
        out.append(row)
    return out


def main(protocol_path,out):
    out.mkdir(exist_ok=False)
    protocol=json.loads(protocol_path.read_text());bindings=[]
    for row in protocol['inputs']:
        ok=hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
        bindings.append({'path':row['path'],'passed':ok})
    if not all(z['passed'] for z in bindings):
        raise RuntimeError('Frozen source mismatch')
    mp.mp.dps=80
    result={'scope':'Conditional non-vacuum weak-source algebra; exposed endpoints, no fit or ODE rerun.',
            'omitted_bridge':'Finite-distance cosmological/environmental matching and complete source corrections remain open.',
            'exact':exact(),'high_precision':high_precision(protocol),
            'conditional_energy_costs':observational_costs(protocol),'endpoints':endpoints(protocol)}
    result['checks']=CHECKS
    result['counts']={'passed':sum(z['passed'] for z in CHECKS),'failed':sum(not z['passed'] for z in CHECKS),'total':len(CHECKS)}
    result['source_bindings']=bindings
    result['unchanged_sources']=all(hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'] for row in protocol['inputs'])
    result['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    (out/'RESULTS.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'counts':result['counts'],'energy_costs':result['conditional_energy_costs'],'endpoints':result['endpoints']},indent=2),flush=True)
    return int(result['counts']['failed']>0 or not result['unchanged_sources'])


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--protocol',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    args=p.parse_args();raise SystemExit(main(args.protocol,args.out))
