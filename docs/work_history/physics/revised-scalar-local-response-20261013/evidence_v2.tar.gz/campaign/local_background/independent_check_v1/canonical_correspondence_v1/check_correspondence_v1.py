#!/usr/bin/env python3
"""Evidence/source correspondence only; does not execute any author runner."""
from pathlib import Path
from fractions import Fraction
import ast
import datetime
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
RECORDS = []


def sha(body):
    return hashlib.sha256(body).hexdigest()


def record(name, passed, **evidence):
    RECORDS.append({"name": name, "passed": bool(passed), "evidence": evidence})


def load_snapshot(entry):
    return (HERE / entry["snapshot_path"]).read_bytes()


def parse_cache(body):
    header, remainder = body.decode().split("----- stdout -----\n", 1)
    stdout, stderr = remainder.split("----- stderr -----\n", 1)
    fields = dict(line.split(": ", 1) for line in header.splitlines() if ": " in line)
    return fields, json.loads(stdout), stderr


def fingerprint(paths, bodies):
    # Independently transcribed from the retained cache implementation, not imported.
    digest = hashlib.sha256(b"runner-cache-input-fingerprint-v1\0")
    for path, body in zip(paths, bodies):
        encoded = path.encode()
        digest.update(len(encoded).to_bytes(8, "big"))
        digest.update(encoded)
        digest.update(len(body).to_bytes(8, "big"))
        digest.update(body)
    return digest.hexdigest()


def cache_check(label, cache_body, note_body, primary_body, paths):
    fields, result, stderr = parse_cache(cache_body)
    expected = fingerprint(paths, [note_body])
    checks = result["checks"]
    passed = sum(c["passed"] is True for c in checks)
    failed = len(checks) - passed
    record(label + ".source_binding", fields["runner_sha256"] == sha(primary_body)
           and fields["input_fingerprint_sha256"] == expected,
           runner_sha256=fields["runner_sha256"], note_sha256=sha(note_body),
           recorded_fingerprint=fields["input_fingerprint_sha256"],
           recomputed_fingerprint=expected)
    record(label + ".retained_result", fields["exit_code"] == "0"
           and fields["status"] == "ok" and not stderr.strip()
           and result["counts"] == {"passed": passed, "failed": failed}
           and passed == 204 and failed == 0
           and len({c["name"] for c in checks}) == len(checks),
           reported_exit=fields["exit_code"], counts=result["counts"],
           actual_check_count=len(checks), cache_sha256=sha(cache_body),
           provenance="Existing author execution record inspected; not re-executed here.")
    return fields


def main():
    final_manifest = json.loads((HERE / "SOURCE_MANIFEST_FINAL_v1.json").read_text())
    entries = {e["label"]: e for e in final_manifest["files"]}
    body = {label: load_snapshot(entry) for label, entry in entries.items()}
    for label, entry in entries.items():
        record("snapshot." + label, sha(body[label]) == entry["sha256"]
               and len(body[label]) == entry["bytes"], sha256=sha(body[label]))
        source = Path(entry["source_path"])
        record("live_source." + label, source.read_bytes() == body[label],
               source_path=str(source), symlink=source.is_symlink())

    initial_manifest = json.loads((HERE / "SOURCE_MANIFEST_v1.json").read_text())
    for entry in initial_manifest["files"]:
        record("initial_snapshot." + entry["snapshot_path"],
               sha(load_snapshot(entry)) == entry["sha256"],
               frozen_sha256=entry["sha256"])

    primary = body["primary_runner"]
    tree = ast.parse(primary)
    inputs = None
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name)
                and t.id == "AUDIT_INPUT_PATHS" for t in node.targets):
            inputs = ast.literal_eval(node.value)
    note_path = "docs/EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md"
    record("primary.sole_declared_input", inputs == [note_path] or inputs == (note_path,),
           inputs=inputs)
    imports = [alias.name for n in ast.walk(tree) if isinstance(n, ast.Import)
               for alias in n.names]
    from_imports = [n.module for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)]
    calls = sorted({ast.unparse(n.func) for n in ast.walk(tree) if isinstance(n, ast.Call)})
    forbidden = {"open", "eval", "exec", "__import__", "compile"}
    record("primary.inspected_dependency_closure", set(imports) == {"json", "sys", "mpmath", "sympy"}
           and not from_imports and not (forbidden & set(calls)),
           imports=imports, from_imports=from_imports,
           note="Full source was also read manually. No endpoint/calibration file reads or local model imports.")
    record("primary.unchanged_since_first_packaging", primary ==
           (HERE / "snapshots/03_exponential_scalar_local_response_check.py").read_bytes(),
           sha256=sha(primary))

    final_fields = cache_check("final_cache", body["final_cache"], body["final_note"], primary, inputs)
    cache_check("initial_cache",
                (HERE / "snapshots/04_exponential_scalar_local_response_check.txt").read_bytes(),
                (HERE / "snapshots/02_EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md").read_bytes(),
                primary, inputs)
    for version in ("v1", "v2"):
        prefix = "parent_preserved_" + version + "_"
        note = body[prefix + Path(note_path).stem]
        cache = body[prefix + "exponential_scalar_local_response_check"]
        cache_check("preserved_" + version, cache, note, primary, inputs)
        receipt = json.loads(body[prefix + "MANIFEST"])
        source_dir = Path(entries[prefix + "MANIFEST"]["source_path"]).parent
        for row in receipt["sources"]:
            saved = source_dir / Path(row["path"]).name
            record("preserved_manifest." + version + "." + saved.name,
                   sha(saved.read_bytes()) == row["sha256"], sha256=row["sha256"])

    for label in ("original_background_manifest", "original_force_manifest"):
        original_dir = Path(entries[label]["source_path"]).parent
        manifest = json.loads(body[label])
        rows = manifest["files"]
        mismatches = [row["path"] for row in rows
                      if sha((original_dir / row["path"]).read_bytes()) != row["sha256"]]
        record("reused_evidence_integrity." + label, not mismatches,
               checked_files=len(rows), mismatches=mismatches,
               manifest_sha256=sha(body[label]))
    independent = json.loads(body["original_background_result"])
    record("reused_independent_background.result", independent["summary"] ==
           {"count": 115, "satisfied": 115, "unsatisfied": 0}
           and len(independent["records"]) == 115
           and all(r["satisfied"] for r in independent["records"]),
           summary=independent["summary"],
           provenance="Previously executed independent science; no rerun in correspondence phase.")
    vacuum = json.loads(body["original_force_result"])
    record("reused_independent_vacuum.result", vacuum["summary"] ==
           {"checks": 73, "satisfied": 73, "not_satisfied": 0},
           summary=vacuum["summary"],
           note="71 computed checks and two documentary entries, as original receipt specifies.")

    mutations = {
        "coupling_denominator": ("COUPLING_DENOMINATOR = 3", "COUPLING_DENOMINATOR = 2",
            ["exact.coupling_chi", "exact.coupling_monotonic_derivative", "exact.density_feedback",
             "exact.observational_inversion", "exact.trapped_minimum", "exact.trapped_maximum",
             "algebraic_negative_control.wrong_coupling_denominator"]),
        "Newton_linear_term": ("NEWTON_LINEAR_COEFFICIENT = 0", "NEWTON_LINEAR_COEFFICIENT = 1",
            ["exact.Newton_strength_cancellation", "exact.Newton_strength_derivative",
             "exact.Newton_vacuum_derivative", "exact.weak_limit_Newton_second_order"]),
        "density_feedback_sign": ("DENSITY_FEEDBACK_SIGN = -1", "DENSITY_FEEDBACK_SIGN = 1",
            ["exact.density_feedback"]),
        "ball_source_sign": ("BALL_SOURCE_SIGN = 1", "BALL_SOURCE_SIGN = -1", ["ball.ODE"]),
        "vacuum_mass": ("VACUUM_MASS_NUMERATOR = 4", "VACUUM_MASS_NUMERATOR = 2", ["vacuum.mass.0"]),
    }
    mutation_receipt = json.loads(body["mutation_receipt"])
    record("mutations.primary_binding", mutation_receipt["primary_sha256"] == sha(primary),
           primary_sha256=sha(primary))
    for name, (before, after, expected_failures) in mutations.items():
        script = body["mutation_" + name + ".py"]
        result = json.loads(body["mutation_" + name + ".stdout.txt"])
        stderr = body["mutation_" + name + ".stderr.txt"]
        retained = next(r for r in mutation_receipt["controls"] if r["name"] == name)
        failed = [c["name"] for c in result["checks"] if not c["passed"]]
        counts = {"passed": sum(c["passed"] is True for c in result["checks"]), "failed": len(failed)}
        expected_script = primary.decode().replace(before, after, 1).encode()
        record("mutation." + name, primary.decode().count(before) == 1
               and script == expected_script and sha(script) == retained["mutated_source_sha256"]
               and failed == expected_failures == retained["failed_checks"]
               and counts == result["counts"] == retained["counts"]
               and len(result["checks"]) == 204 and retained["exit_code"] == 1
               and not stderr.strip(),
               changed_assignment=[before, after], source_sha256=sha(script),
               stdout_sha256=sha(body["mutation_" + name + ".stdout.txt"]),
               actual_failed_identities=failed, counts=counts,
               reported_exit_code=retained["exit_code"],
               provenance="Existing damaged-copy source, stdout, stderr and execution receipt inspected; not rerun.")

    # New, small mathematical negative controls for the actual range-scope finding.
    # Exact rational arithmetic; no history integration or primary code use.
    def mass_squared_ratio(k, nu):
        return 4 * (3 * (1 + k) + nu) / (1 - 3 * k)
    cases = [("large_nu", Fraction(1, 100), Fraction(10**12)),
             ("near_upper_k", Fraction(1, 3) - Fraction(1, 10**12), Fraction(1)),
             ("qualified_small_k", Fraction(1, 10**10), Fraction(1))]
    controls = []
    for label, k, nu in cases:
        ratio2 = mass_squared_ratio(k, nu)
        controls.append({"case": label, "k": str(k), "nu": str(nu),
                         "m_squared_over_Hv_squared_exact": str(ratio2),
                         "m_over_Hv_approx": float(ratio2)**0.5})
    record("new_range_scope_negative_controls", controls[0]["m_over_Hv_approx"] > 10**6
           and controls[1]["m_over_Hv_approx"] > 10**6
           and abs(controls[2]["m_over_Hv_approx"] - 4) < 10**-8,
           cases=controls,
           analytic_reason="The exact ratio is unbounded as nu grows at fixed k, or as k tends to 1/3 from below; the small-k nu=1 limit is 4.")

    note = body["final_note"].decode()
    markers = ["1+alpha_B p_u nonzero", "requires it to be positive",
               "nonnegative, bounded and compactly", "On L-infinity(R^3)",
               "exp(-mu|r-r_prime|) f(r_prime)/|r-r_prime|", "delta_varphi->0",
               "In the mu=0 limit", "evaluated at the prescribed background",
               "For nu=1 and small k", "no uniform range statement holds"]
    record("corrected_source.explicit_qualifications", all(m in note for m in markers),
           checked_markers=markers,
           note="Correspondence markers supplement the manual equation/domain review; they are not mathematical tests.")

    n_passed = sum(r["passed"] for r in RECORDS)
    output = {"completed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "scope": "Final-source evidence correspondence and three explicit mass-range controls; no author runner or history re-executed.",
              "final_note_sha256": sha(body["final_note"]),
              "primary_runner_sha256": sha(primary),
              "final_cache_sha256": sha(body["final_cache"]),
              "final_cache_fingerprint": final_fields["input_fingerprint_sha256"],
              "records": RECORDS,
              "summary": {"checks": len(RECORDS), "passed": n_passed,
                          "failed": len(RECORDS) - n_passed}}
    print(json.dumps(output, indent=2))
    return 0 if n_passed == len(RECORDS) else 1


if __name__ == "__main__":
    sys.exit(main())
