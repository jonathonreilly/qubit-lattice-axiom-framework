#!/usr/bin/env python3
"""Narrow source-trace correction check; executes no parent science runner."""
from pathlib import Path
from fractions import Fraction
import ast
import datetime
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
CHECKS = []


def sha(body):
    return hashlib.sha256(body).hexdigest()


def check(name, passed, **evidence):
    CHECKS.append({"name": name, "passed": bool(passed), "evidence": evidence})


def fingerprint(path, body):
    result = hashlib.sha256(b"runner-cache-input-fingerprint-v1\0")
    encoded = path.encode()
    result.update(len(encoded).to_bytes(8, "big"))
    result.update(encoded)
    result.update(len(body).to_bytes(8, "big"))
    result.update(body)
    return result.hexdigest()


def main():
    manifest = json.loads((HERE / "SOURCE_MANIFEST_v1.json").read_text())
    rows = {r["label"]: r for r in manifest["files"]}
    bodies = {label: (HERE / r["snapshot_path"]).read_bytes() for label, r in rows.items()}
    check("twelve_frozen_sources", len(rows) == 12 and all(
          sha(bodies[label]) == r["sha256"] and len(bodies[label]) == r["bytes"]
          for label, r in rows.items()), source_manifest_sha256=sha((HERE / "SOURCE_MANIFEST_v1.json").read_bytes()))
    check("live_sources_unchanged_since_capture", all(
          Path(r["source_path"]).read_bytes() == bodies[label] for label, r in rows.items()))
    expected_hashes = {
        "note_v4": "b4080f1e5c63109f66a4a8b15c2e4888c5331384654ddcbca5c9c0eb97a3cd68",
        "note_v3": "05852f51144629abe793f72d3469b3cf1e93b1878b5ac4d653d66ffca9235efb",
        "primary_runner": "11548263e792cdbb1720f4fb6049205cc7bbb21c557c767de6719e949285681f",
        "cache_v4": "69b43b20253d6d02a8ffcb37682208b13cb777ad2c0a8d22affba7be46b9b800",
        "cache_v3": "76686649f0700a1926e874b08249f5241665679fb5663378ca0ca0cf3f5e26d5",
        "sealed_prior_receipt": "f5a9670108fbe1e3fb54169a7fd8d8b46e947d4b5484c6affe22b87a19cfec60",
        "sealed_prior_manifest": "cc4d8a2651be92dba205017e44850b341e73414f95da0667f2a8549f699916d3",
    }
    check("expected_source_identities", all(sha(bodies[label]) == value
          for label, value in expected_hashes.items()), hashes=expected_hashes)
    prior = json.loads(bodies["sealed_prior_receipt"])
    previous_confirmation = prior["final_source_confirmation"]
    check("prior_confirmation_preserved", previous_confirmation["note"]["sha256"] == sha(bodies["note_v3"])
          and previous_confirmation["cache"]["sha256"] == sha(bodies["cache_v3"])
          and previous_confirmation["primary_runner"]["sha256"] == sha(bodies["primary_runner"]))
    prior_manifest = json.loads(bodies["sealed_prior_manifest"])
    prior_dir = Path(rows["sealed_prior_manifest"]["source_path"]).parent
    mismatches = [r["path"] for r in prior_manifest["files"]
                  if sha((prior_dir / r["path"]).read_bytes()) != r["sha256"]]
    check("all_prior_sealed_artifacts_unchanged", not mismatches,
          files_checked=len(prior_manifest["files"]), mismatches=mismatches)

    old = bodies["note_v3"].decode()
    expected = old
    replacements = [
        ("history. The local readout additionally requires a weak source, a frozen\n",
         "history. The local readout additionally requires a weak nonrelativistic\nsource with negligible pressure and stress, a frozen\n"),
        ("For an isolated weak source, negligible mass/mixing and time-dependent\n",
         "For an isolated weak nonrelativistic source with negligible pressure and\nstress, negligible mass/mixing and time-dependent\n"),
    ]
    exact_counts = all(old.count(a) == 1 for a, _ in replacements)
    for a, b in replacements:
        expected = expected.replace(a, b, 1)
    check("only_two_authorized_prose_replacements", exact_counts and expected.encode() == bodies["note_v4"],
          replacements=[{"old": a, "new": b} for a, b in replacements])
    check("author_diff_matches_independent_diff", bodies["author_diff"] ==
          (HERE / "INDEPENDENT_v3_v4.diff").read_bytes())
    preservation = json.loads(bodies["parent_preservation_manifest"])
    saved_dir = Path(rows["parent_preservation_manifest"]["source_path"]).parent
    check("author_v3_preservation_manifest", len(preservation["files"]) == 2 and all(
          sha((saved_dir / r["snapshot"]).read_bytes()) == r["sha256"]
          for r in preservation["files"]))

    paths = None
    for node in ast.parse(bodies["primary_runner"]).body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name)
                and t.id == "AUDIT_INPUT_PATHS" for t in node.targets):
            paths = ast.literal_eval(node.value)
    note_path = "docs/EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md"
    check("unchanged_primary_sole_note_input", paths in ([note_path], (note_path,)))
    cache_bindings = {}
    for version in ("v3", "v4"):
        header, remainder = bodies["cache_" + version].decode().split("----- stdout -----\n", 1)
        stdout, stderr = remainder.split("----- stderr -----\n", 1)
        fields = dict(line.split(": ", 1) for line in header.splitlines() if ": " in line)
        result = json.loads(stdout)
        fp = fingerprint(note_path, bodies["note_" + version])
        cache_bindings[version] = {"recorded": fields["input_fingerprint_sha256"], "recomputed": fp}
        check("cache_binding_" + version, fields["input_fingerprint_sha256"] == fp
              and fields["runner_sha256"] == sha(bodies["primary_runner"]), **cache_bindings[version])
        checks = result["checks"]
        check("retained_author_result_" + version, fields["exit_code"] == "0"
              and fields["status"] == "ok" and not stderr.strip()
              and result["counts"] == {"passed": 204, "failed": 0}
              and len(checks) == len({c["name"] for c in checks}) == 204
              and all(c["passed"] is True for c in checks),
              provenance="Existing author cache inspected, not re-executed here.",
              recorded_exit=fields["exit_code"], counts=result["counts"])

    # Small algebraic controls for the new source-class issue only.
    # Overall scalar source is -4*pi*Gstar*alpha^A*T_E in natural units.
    energy = Fraction(1)
    dust_trace = -energy
    radiation_trace = -energy + 3 * energy / 3
    anisotropic_trace = -energy + energy + 0 + 0
    check("trace_source_dust_normalization", -dust_trace == energy,
          trace=str(dust_trace), source_factor_relative_to_energy=str(-dust_trace / energy))
    check("negative_control_weak_isotropic_trace_free", radiation_trace == 0
          and -radiation_trace != energy,
          trace=str(radiation_trace), p_over_energy="1/3",
          implication="Weakness alone does not justify replacing -T_E by energy density.")
    check("negative_control_weak_anisotropic_trace_free", anisotropic_trace == 0
          and -anisotropic_trace != energy,
          principal_stresses=["1", "0", "0"], trace=str(anisotropic_trace))
    passed = sum(c["passed"] for c in CHECKS)
    print(json.dumps({"completed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      "scope": "Narrow v3-to-v4 source-trace/correspondence check; no physics/history runner executed.",
                      "cache_bindings": cache_bindings, "checks": CHECKS,
                      "counts": {"passed": passed, "failed": len(CHECKS) - passed}}, indent=2))
    return 0 if passed == len(CHECKS) else 1


if __name__ == "__main__":
    sys.exit(main())
