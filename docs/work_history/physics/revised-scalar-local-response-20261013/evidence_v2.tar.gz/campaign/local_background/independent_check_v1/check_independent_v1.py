#!/usr/bin/env python3
"""Bounded independent background check: no parent code or results imported."""
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import platform
import sys
import traceback

import mpmath as mp
import numpy as np
import scipy
from scipy.integrate import solve_bvp
import sympy as sp

HERE = Path(__file__).resolve().parent
mp.mp.dps = 80
records = []
outputs = {}


def record(name, condition, evidence, kind="positive_control"):
    records.append({"name": name, "kind": kind, "satisfied": bool(condition), "evidence": evidence})


def equal(name, actual, expected):
    difference = sp.factor(sp.simplify(actual-expected))
    record(name, difference == 0, {"derived": str(sp.factor(actual)),
                                  "expected": str(expected), "residual": str(difference)}, "symbolic_identity")


def num(x):
    return mp.nstr(x, 65)


def err(x, y):
    return abs(x-y)/(1+abs(y))


def symbolic():
    k, E, chi, nu = sp.symbols("k E chi nu", positive=True)
    a = (1-k)*(1+3*k)/4
    s = (1+k)/(k*(1-3*k))
    alpha = sp.sqrt(a)
    F, J = 1+s*E, 1+(1-3*a)*s*E
    Ku = J/F**2
    C = (1+s)*E/F
    D_u = lambda expression: 2*alpha*E*sp.diff(expression, E)
    B_u = D_u(sp.log(C)/2)
    g = B_u**2/Ku
    beta = (D_u(B_u)-B_u*D_u(Ku)/(2*Ku))/Ku
    A = sp.sqrt(C)
    density = (D_u(D_u(A))-D_u(A)*D_u(Ku)/(2*Ku))/(Ku*A)
    chi_of_E = s*(C-1)
    E_of_chi = (1+chi/s)/(1-chi)
    in_chi = lambda expression: sp.factor(expression.subs(E, E_of_chi))
    equal("g_metric_norm", g, a/J)
    equal("alpha_B_raw", B_u, alpha/F)
    equal("chi_definition", chi_of_E, s*(E-1)/F)
    equal("chi_inverse", in_chi(chi_of_E), chi)
    equal("s_minus_one_positive_form", s-1, (1+3*k*k)/(k*(1-3*k)))
    equal("g_chi", in_chi(g), k*(1-chi)/(1-3*k*chi))
    equal("g_chi_derivative", sp.diff(in_chi(g), chi), -k*(1-3*k)/(1-3*k*chi)**2)
    equal("beta_chi", in_chi(beta), -(1+k+k*(1-3*k)*chi)/(1-3*k*chi)**2)
    equal("A_second_over_A", in_chi(density), -(1-k*chi)*(1+3*k*chi)/(1-3*k*chi)**2)
    equal("beta_plus_g", beta+g, density)
    equal("density_sign_flip_E", E_of_chi.subs(chi, -1/(3*k)), 2*k/(1+k))
    equal("chi_u", in_chi(D_u(chi_of_E)), 2*alpha*(s+chi)*(1-chi)/(1+s))
    equal("alpha_B_chi", in_chi(B_u), alpha*(1-chi)/(1+s))
    RG = C*(1+g)/(1+k)
    BB = 4*k*k*(1-3*k)/(1+k)**2
    equal("Newton_strength_cancellation", in_chi(RG), 1-BB*chi*chi/(1-3*k*chi))
    equal("Newton_strength_chi_derivative", sp.diff(in_chi(RG), chi), -BB*chi*(2-3*k*chi)/(1-3*k*chi)**2)
    p = sp.symbols("p", real=True)
    drift_raw = D_u(RG)*p/(RG*(1+B_u*p))
    chi_u = 2*alpha*(s+chi)*(1-chi)/(1+s)
    drift_claim = (-BB*chi*(2-3*k*chi)/(1-3*k*chi)**2)*chi_u*p/(in_chi(RG)*(1+in_chi(B_u)*p))
    equal("Jordan_clock_drift", in_chi(drift_raw), drift_claim)
    equal("vacuum_RG", RG.subs(E, 1), 1)
    equal("vacuum_RG_first_derivative", D_u(RG).subs(E, 1), 0)
    equal("vacuum_g_nonzero", g.subs(E, 1), k)
    equal("small_k_RG_order2", sp.limit((in_chi(RG)-1)/k**2, k, 0, dir="+"), -4*chi**2)
    equal("small_k_g_order1", sp.limit(in_chi(g)/k, k, 0, dir="+"), 1-chi)

    # Energy and monotonicity directly from the raw potential.
    equal("vacuum_potential_energy_identity", in_chi(s*3*s*(E-1)**2/(2*F**2)), 3*chi**2/2)
    b = sp.symbols("b", positive=True)
    chi_req = (k-b)/(k*(1-3*b))
    equal("coupling_requirement_inverse", in_chi(g).subs(chi, chi_req), b)
    equal("one_minus_required_chi", 1-chi_req, b*(1-3*k)/(k*(1-3*b)))
    u = sp.symbols("u", real=True)
    equal("nu_energy_in_chi", in_chi(nu*s*(1+s)*u*u/(2*F**2)), nu*s*u*u*(1-chi)**2/(2*(1+s)))
    t = sp.symbols("t", real=True)
    Ft = 1+s*sp.exp(t)
    U0t = sp.Rational(3, 2)+3*s*(sp.exp(t)-1)**2/(2*Ft**2)+nu*(1+s)*t*t/(8*a*Ft**2)
    Gt = 12*a*(sp.exp(t)-1)+nu*t*(1-t)+nu*t/(s*sp.exp(t))
    equal("potential_monotonicity_factor", sp.diff(U0t, t), (1+s)*s*sp.exp(t)*Gt/(4*a*Ft**3))
    equal("lambda_x_premise_equivalence", 2*alpha*(1+s*k)/(k*(1+s)), (1-k)/alpha)
    equal("lambda_y_premise_equivalence", 4*alpha*s/(1+s), (1+k)/alpha)

    # Jordan coordinate conversion carries two powers of A_b.
    Ab, MJ, rJ, Gstar = sp.symbols("Ab MJ rJ Gstar", positive=True)
    equal("Jordan_mass_and_radius_conversion", Gstar*(Ab*MJ)/(rJ/Ab), Gstar*Ab**2*MJ/rJ)
    epsilon, Ustar, glocal = sp.symbols("epsilon Ustar g", real=True)
    conformal = 1-2*epsilon*glocal*Ustar
    g00 = sp.series(conformal*(-1+2*epsilon*Ustar), epsilon, 0, 2).removeO()
    gii = sp.series(conformal*(1+2*epsilon*Ustar), epsilon, 0, 2).removeO()
    equal("physical_Phi", (g00+1)/(2*epsilon), Ustar*(1+glocal))
    equal("physical_Psi", (gii-1)/(2*epsilon), Ustar*(1-glocal))
    equal("gamma_shift", (1-glocal)/(1+glocal)-1, -2*glocal/(1+glocal))

    # General eta ball is massless; retaining mu produces a nonzero residual.
    r, z, eta, mur = sp.symbols("r z eta mur", positive=True)
    field = (1-sp.sin(z*r)/(z*r*sp.cos(z)))/eta
    w = r*field
    equal("eta_ball_massless_interior", sp.diff(w, r, 2)+z*z*w, z*z*r/eta)
    equal("eta_ball_regular_origin", sp.limit(w, r, 0), 0)
    equal("eta_ball_surface_derivative", sp.diff(w, r).subs(r, 1), 0)
    factor = 3*(sp.tan(z)-z)/z**3
    equal("eta_ball_exterior_charge", field.subs(r, 1), -z*z*factor/(3*eta))
    equal("eta_ball_first_charge_correction", sp.limit((factor-1)/z**2, z, 0), sp.Rational(2, 5))
    residual = sp.simplify(sp.diff(w, r, 2)+(z*z-mur*mur)*w-z*z*r/eta)
    equal("eta_ball_nonzero_mass_residual", residual, -mur*mur*w)
    record("negative_control_finite_mu_sphere", sp.simplify(residual) != 0,
           {"residual": str(sp.factor(residual)), "scope": "Displayed equation (13) needs mu=0."}, "negative_control")


def raw_action(k, u, x=mp.mpf(0), y=mp.mpf(0), nu=mp.mpf(1)):
    a = (1-k)*(1+3*k)/4
    s = (1+k)/(k*(1-3*k))
    al = mp.sqrt(a)
    E = mp.exp(2*al*u)
    F, J = 1+s*E, 1+(1-3*a)*s*E
    D = 1+2*(1+k)*(x*x+y*y)/3
    K = [J/F**2, (1+s)*4*k/(9*F*D), (1+s)*k/(3*F*D)]
    C = (1+s)*E/F
    U = (mp.mpf("1.5")+3*s*(E-1)**2/(2*F**2)
         + k*x*x*mp.exp(-(1-k)*u/al)/2+k*y*y*mp.exp(-(1+k)*u/al)/3
         + nu*(1+s)*u*u/(2*F**2))
    return {"a": a, "s": s, "alpha": al, "E": E, "F": F, "J": J, "K": K, "C": C, "U": U}


def raw_g(k, u):
    f = raw_action(k, u)
    derivative = mp.diff(lambda v: mp.log(raw_action(k, v)["C"])/2, u)
    return derivative**2/f["K"][0]


def raw_RG(k, u):
    return raw_action(k, u)["C"]*(1+raw_g(k, u))/(1+k)


def raw_drift(k, u, p):
    Bu = mp.diff(lambda v: mp.log(raw_action(k, v)["C"])/2, u)
    return mp.diff(lambda v: mp.log(raw_RG(k, v)), u)*p/(1+Bu*p)


def closed_values(k, u, p):
    f = raw_action(k, u)
    s, al = f["s"], f["alpha"]
    chi = s*(f["C"]-1)
    g = k*(1-chi)/(1-3*k*chi)
    beta = -(1+k+k*(1-3*k)*chi)/(1-3*k*chi)**2
    curvature = -(1-k*chi)*(1+3*k*chi)/(1-3*k*chi)**2
    BB = 4*k*k*(1-3*k)/(1+k)**2
    RG = 1-BB*chi*chi/(1-3*k*chi)
    chi_u = 2*al*(s+chi)*(1-chi)/(1+s)
    Bu = al*(1-chi)/(1+s)
    drift = -BB*chi*(2-3*k*chi)*chi_u*p/((1-3*k*chi)**2*RG*(1+Bu*p))
    return {"chi": chi, "g": g, "beta": beta, "curvature": curvature, "eta": -curvature,
            "RG": RG, "drift": drift, "clock": 1+Bu*p, "Bu": Bu}


def derivative_controls():
    protocol = json.loads((HERE/"CONTROL_PROTOCOL_v1.json").read_text())
    for ks in protocol["raw_action_derivative_cases"]["k"]:
        for us in protocol["raw_action_derivative_cases"]["u"]:
            k, u, p = mp.mpf(ks), mp.mpf(us), mp.mpf("0.17")
            f = raw_action(k, u)
            Ku = f["K"][0]
            def am(v):
                Bu = mp.diff(lambda q: mp.log(raw_action(k, q)["C"])/2, v)
                return Bu/mp.sqrt(raw_action(k, v)["K"][0])
            def dA(v):
                return mp.diff(lambda q: mp.sqrt(raw_action(k, q)["C"]), v)/mp.sqrt(raw_action(k, v)["K"][0])
            actual = [am(u)**2, mp.diff(am, u)/mp.sqrt(Ku),
                      mp.diff(dA, u)/(mp.sqrt(Ku)*mp.sqrt(f["C"])), raw_RG(k, u), raw_drift(k, u, p)]
            cv = closed_values(k, u, p)
            target = [cv[key] for key in ["g", "beta", "curvature", "RG", "drift"]]
            discrepancies = [err(a, b) for a, b in zip(actual, target)]
            Eback = (1+cv["chi"]/f["s"])/(1-cv["chi"])
            discrepancies.append(err(Eback, f["E"]))
            record(f"direct_80digit_k={ks}_u={us}", max(discrepancies) < mp.mpf("1e-55")
                   and -f["s"] < cv["chi"] < 1 and 0 < cv["RG"] <= 1+mp.mpf("1e-70"),
                   {"max_scaled_error": num(max(discrepancies)), **{key:num(value) for key,value in cv.items()}})


def energy_controls():
    k, nu, b = mp.mpf("0.01"), mp.mpf(1), mp.mpf(1)/79999
    f0 = raw_action(k, mp.mpf(0))
    chi_req = (k-b)/(k*(1-3*b))
    u_req = mp.log((1+chi_req/f0["s"])/(1-chi_req))/(2*f0["alpha"])
    lo, hi = mp.mpf(0), mp.mpf(20)
    for _ in range(260):
        mid = (lo+hi)/2
        if raw_g(k, mid) > b:
            lo = mid
        else:
            hi = mid
    u_bisect = (lo+hi)/2
    basic = 3*chi_req**2/2
    nu_term = nu*f0["s"]*u_req*u_req*(1-chi_req)**2/(2*(1+f0["s"]))
    sharp = basic+nu_term
    direct = f0["s"]*(raw_action(k, u_bisect, nu=nu)["U"]-mp.mpf("1.5"))
    record("conditional_energy_cost_k=.01_b=1/79999", err(u_req,u_bisect) < mp.mpf("1e-60")
           and err(direct,sharp) < mp.mpf("1e-60") and 0 < basic < sharp < mp.mpf("1.5")
           and 0 < nu <= 6*f0["a"],
           {"k":num(k),"b":num(b),"nu":num(nu),"chi_req":num(chi_req),"u_req":num(u_req),
            "u_independent_bisection":num(u_bisect),"basic_Z_floor":num(basic),"nu_extra":num(nu_term),
            "sharp_Z_floor":num(sharp),"direct_action_Z_at_root":num(direct),
            "g_at_root":num(raw_g(k,u_bisect)),"boundary_gap":num(mp.mpf("1.5")-sharp)})
    outputs["required_energy_cost"] = records[-1]["evidence"]
    for us in ["-1.1","-0.3","0","0.8","2"]:
        u = mp.mpf(us); x=mp.mpf("0.2");y=mp.mpf("-0.4")
        v=[mp.mpf("0.07"),mp.mpf("-0.12"),mp.mpf("0.09")]
        f = raw_action(k,u,x,y,nu)
        Z=f["s"]*(sum(Ki*vi*vi for Ki,vi in zip(f["K"],v))/2+f["U"]-mp.mpf("1.5"))
        chi=f["s"]*(f["C"]-1)
        floor=3*chi*chi/2
        record("off_orbit_energy_u="+us,Z>=floor,{"Z":num(Z),"floor":num(floor),"excess":num(Z-floor)})
    # A genuine counterexample to removing the stated nu condition.
    badnu=mp.mpf(100)
    u2=mp.mpf(2)/(2*f0["alpha"]);u3=mp.mpf(3)/(2*f0["alpha"])
    Z2=f0["s"]*(raw_action(k,u2,nu=badnu)["U"]-mp.mpf("1.5"))
    Z3=f0["s"]*(raw_action(k,u3,nu=badnu)["U"]-mp.mpf("1.5"))
    slope=mp.diff(lambda u:raw_action(k,u,nu=badnu)["U"],u2)
    record("negative_control_remove_nu_condition",badnu>6*f0["a"] and slope<0 and Z3<Z2 and raw_g(k,u3)<raw_g(k,u2),
           {"nu":num(badnu),"6a":num(6*f0["a"]),"u_req_example":num(u2),"u_larger":num(u3),
            "b_example":num(raw_g(k,u2)),"g_larger_u":num(raw_g(k,u3)),"Z_at_requirement":num(Z2),
            "Z_at_larger_u":num(Z3),"Uu_at_requirement":num(slope)},"negative_control")
    nu_term_func=lambda u:f0["s"]*nu*(1+f0["s"])*u*u/(2*raw_action(k,u)["F"]**2)
    term_slope=mp.diff(nu_term_func,u2)
    total_slope=mp.diff(lambda u:raw_action(k,u,nu=nu)["U"],u2)
    record("total_potential_not_each_summand_monotone",term_slope<0 and total_slope>0,
           {"nu":num(nu),"u":num(u2),"nu_summand_Z_slope":num(term_slope),"total_U_slope":num(total_slope)})
    littlek=mp.mpf("0.000001")
    wrong_req=(littlek-b)/(littlek*(1-3*b))
    Zvac=raw_action(littlek,mp.mpf(0))["s"]*(raw_action(littlek,mp.mpf(0))["U"]-mp.mpf("1.5"))
    record("negative_control_square_negative_requirement",littlek<b and wrong_req<0 and Zvac==0 and 3*wrong_req**2/2>Zvac,
           {"k":num(littlek),"b":num(b),"chi_req":num(wrong_req),"wrong_squared_floor":num(3*wrong_req**2/2),"actual_vacuum_Z":num(Zvac)},"negative_control")


def additional_negative_controls():
    k=mp.mpf("0.01"); f0=raw_action(k,mp.mpf(0))
    E=k/(1+k)
    u=mp.log(E)/(2*f0["alpha"])
    cv=closed_values(k,u,mp.mpf("0.17"))
    record("negative_control_density_sign_outside_trap",cv["chi"]<-1/(3*k) and cv["curvature"]>0,
           {"u":num(u),"E":num(E),**{key:num(cv[key]) for key in ["chi","curvature","eta"]}},"negative_control")
    k=mp.mpf("0.2");u=mp.mpf("0.7");p=mp.mpf("0.17")
    f=raw_action(k,u);cv=closed_values(k,u,p)
    badg=k*(1-cv["chi"])
    badRG=(1+raw_g(k,u))/(1+k)
    baddrift=mp.diff(lambda t:mp.log(raw_RG(k,t)),u)*p
    record("negative_control_drop_g_denominator",abs(badg-cv["g"])>mp.mpf("1e-6"),
           {"wrong":num(badg),"correct":num(cv["g"])},"negative_control")
    record("negative_control_drop_Jordan_C",abs(badRG-cv["RG"])>mp.mpf("1e-6"),
           {"wrong":num(badRG),"correct":num(cv["RG"])},"negative_control")
    record("negative_control_drop_Jordan_clock",abs(baddrift-cv["drift"])>mp.mpf("1e-8"),
           {"wrong":num(baddrift),"correct":num(cv["drift"]),"clock":num(cv["clock"])},"negative_control")


def eta_ball_controls():
    for etas,phis in [("0.25","0.04"),("1.7","0.02"),("3.5","0.08")]:
        eta,Phi=mp.mpf(etas),mp.mpf(phis)
        z=mp.sqrt(3*eta*Phi);h=float(3*Phi);etaf=float(eta)
        def rhs(t, state):
            return np.vstack((state[1],h*(t-etaf*state[0])))
        def bc(left,right):
            return np.array([left[0],right[1]])
        mesh=np.linspace(0,1,81)
        sol=solve_bvp(rhs,bc,mesh,np.zeros((2,mesh.size)),tol=1e-10,max_nodes=10000)
        grid=np.linspace(0,1,101);values=sol.sol(grid)
        actual=np.concatenate(([values[1,0]],values[0,1:]/grid[1:]))
        expected=np.array([float((1-1/mp.cos(z))/eta) if t==0 else
                           float((1-mp.sin(z*mp.mpf(str(t)))/(z*mp.mpf(str(t))*mp.cos(z)))/eta) for t in grid])
        discrepancy=float(np.max(np.abs(actual-expected)/(1+np.abs(expected))))
        q=3*Phi/2;bound=q/(1-eta*q);norm=(1/mp.cos(z)-1)/eta
        record(f"eta_ball_eta={etas}_Phi={phis}",sol.success and discrepancy<5e-9 and eta*q<1 and norm<=bound,
               {"success":bool(sol.success),"solver_status":int(sol.status),"nodes":int(sol.x.size),"scaled_profile_error":discrepancy,
                "z":num(z),"eta_q":num(eta*q),"field_norm_over_alpha":num(norm),"bound_over_alpha":num(bound),
                "source_mass":"Frozen background M_E=integral A_b rho0; no density redistribution."})


def endpoint_controls():
    manifest=json.loads((HERE/"SOURCE_MANIFEST_v1.json").read_text())
    endpoints=[]
    for item in manifest["files"]:
        if "/initial_state/evidence_v1/" not in item["source_path"]:
            continue
        d=json.loads((HERE/item["snapshot_path"]).read_text(),parse_float=Decimal)
        endpoint=d["rows"][-1]
        k=mp.mpf(str(d["case"]["k"]))
        u=mp.mpf(str(endpoint["state"][0]));p=mp.mpf(str(endpoint["state"][3]))
        cv=closed_values(k,u,p)
        direct={"g":raw_g(k,u),"RG":raw_RG(k,u),"drift":raw_drift(k,u,p)}
        errors=[err(direct[key],cv[key]) for key in direct]
        GNstored=mp.mpf(str(endpoint["GNratio"]))
        last=d["last_evaluation"]
        last_u=mp.mpf(str(last["state"][0]));last_p=mp.mpf(str(last["state"][3]))
        wrong_g=raw_g(k,last_u)
        result={"id":d["case"]["id"],"source_sha256":item["sha256"],"row_index":len(d["rows"])-1,
                "k":str(d["case"]["k"]),"L":str(endpoint["L"]),"NJ":str(endpoint["NJ"]),
                "u":str(endpoint["state"][0]),"p_u":str(endpoint["state"][3]),
                **{key:num(value) for key,value in cv.items()},"gamma_minus_one":num(-2*cv["g"]/(1+cv["g"])),
                "necessary_energy_floor_only":num(3*cv["chi"]**2/2),"reported_GNratio":str(endpoint["GNratio"]),
                "computed_minus_reported_GNratio":num(direct["RG"]-GNstored),"max_direct_formula_error":num(max(errors)),
                "last_RHS_L_rejected":str(last["L"]),"last_RHS_u_rejected":str(last["state"][0]),
                "last_RHS_g_minus_endpoint_g":num(wrong_g-direct["g"]),
                "last_RHS_drift_minus_endpoint_drift":num(raw_drift(k,last_u,last_p)-direct["drift"])}
        endpoints.append(result)
        record("actual_endpoint_"+d["case"]["id"],d["success"] and len(d["rows"])==241 and k>0
               and max(errors)<mp.mpf("1e-55") and abs(direct["RG"]-GNstored)<mp.mpf("1e-14")
               and cv["clock"]>0 and last["L"]!=endpoint["L"],result,"endpoint_control")
        record("negative_control_last_RHS_"+d["case"]["id"],abs(wrong_g-direct["g"])>mp.mpf("1e-15"),
               {"g_error_from_wrong_state":num(wrong_g-direct["g"])},"negative_control")
    outputs["actual_endpoints"]=endpoints
    record("finite_k_endpoint_inventory",len(endpoints)==10,{"count":len(endpoints),"k0_reference_used":False})


started=datetime.now(timezone.utc).isoformat()
for suite in [symbolic,derivative_controls,energy_controls,additional_negative_controls,eta_ball_controls,endpoint_controls]:
    try:
        suite()
    except Exception as error:
        record(suite.__name__+"_exception",False,{"exception":repr(error),"traceback":traceback.format_exc()},"checker_failure")
manifest=json.loads((HERE/"SOURCE_MANIFEST_v1.json").read_text())
for item in manifest["files"]:
    data=(HERE/item["snapshot_path"]).read_bytes()
    actual=hashlib.sha256(data).hexdigest()
    record("source_hash_"+item["snapshot_path"],actual==item["sha256"],{"sha256":actual},"identity_control")
result={"started_utc":started,"finished_utc":datetime.now(timezone.utc).isoformat(),
        "scope":"Principal frozen-background mathematics, energy lower bounds, and exact stored endpoint evaluation; no empirical exclusion or full environmental/cosmological matching.",
        "environment":{"python":sys.version,"platform":platform.platform(),"sympy":sp.__version__,"mpmath":mp.__version__,"numpy":np.__version__,"scipy":scipy.__version__},
        "records":records,"outputs":outputs,"summary":{"count":len(records),"satisfied":sum(r["satisfied"] for r in records),"unsatisfied":sum(not r["satisfied"] for r in records)},
        "source_finding":"Equation (13) must explicitly state mu=0. Its profile solves the massless equation and has residual -mu^2 delta_varphi for nonzero mu.",
        "no_parent_code_read":True,"no_history_rerun":True}
print(json.dumps(result,indent=2))
sys.exit(0 if result["summary"]["unsatisfied"]==0 else 1)
