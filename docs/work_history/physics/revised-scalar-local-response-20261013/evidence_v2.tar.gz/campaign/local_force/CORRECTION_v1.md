# Preserved checker failure and narrow correction

The first local-response run completed both numerical solver routes for all five prescribed-body compactness values, but failed one of 59 controls. The failed exact.sphere_charge residual compared -w(1) with a quantity that should be compared with w(1). With w(1)=1-tan(z)/z, the exterior matching identity is w(1)+tan(z)/z-1=0. V2 changes only this expression; no physical formula, case, tolerance or inherited source changes. The v1 script, protocol and full output remain unchanged. This is a checker transcription error, not evidence that every original control passed.

The v2 run again recorded 58 passes and one failure: its corrected charge identity remained in an equivalent unreduced trigonometric form. V3 adds trigsimp after rational reduction. This is recorded separately from the genuine sign error in v1. The body model and source note are unchanged by either checker correction.
