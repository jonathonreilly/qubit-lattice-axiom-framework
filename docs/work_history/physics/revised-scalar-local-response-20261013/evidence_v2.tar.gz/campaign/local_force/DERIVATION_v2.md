# Local force and finite-source response from the revised scalar action

Author: /root, direct campaign author. Status: provisional conditional calculation,
not yet independently checked. This addresses an observation-facing assumption:
the previous Cassini comparison used a long-range, weak-source scalar formula.
Here the scalar range and source response are derived from the same proposed
action. The action, physical matter metric and local background are still inputs.

## Source, normalization, and vacuum Hessian

Use the full exponential action in ../inherited/cosmology/direct_exponential_completion/DERIVATION_v1.md.
Write A=sqrt(C), Gstar=1/(8 pi Q), in c=1 units. The action is

    (16 pi Gstar)^-1 integral sqrt(-g) [R - 2 K_AB dphi^A dphi^B - 4 Hv^2 U]
       + S_m[A^2 g, matter].

This factor convention fixes the mass and source normalizations. The subspace
x=y=0 is invariant: U_x=U_y=0 there, partial_x K_u=partial_y K_u=0, and matter
couples only through u. On this subspace choose the canonical field varphi
with dvarphi/du=sqrt(K_u)>0 and varphi(0)=0. This is the conventional
Einstein scalar normalization -2(dvarphi)^2, not -1/2(dvarphi)^2. Define
alpha_m=d log A/dvarphi and beta_m=dalpha_m/dvarphi.

At u=x=y=0, U_i=0 and C=1. Direct differentiation gives

    alpha_m^2 = k, alpha_m=+sqrt(k), beta_m=-(1+k),
    beta_m+alpha_m^2=-1,
    m_u^2/Hv^2 = 4[3(1+k)+nu]/(1-3k),
    m_x^2/Hv^2 = 9/4, m_y^2/Hv^2 = 2.

Here m_i are inverse-time frequencies. The squared mass eigenvalues are the
eigenvalues of Hv^2 K^-1 Hess(U); at this critical point the connection
correction vanishes and the matrices are diagonal. Only the u mode has a
linear matter coupling at this vacuum. The inverse length of that mode is
mu=m_u/c. A physical mass in kilograms would additionally multiply by hbar/c^2.
There is no tunable short-range mass added for the local calculation.

For nu=1 and small k, m_u is about 4 Hv. Thus an observationally calibrated
Hv of cosmological size produces a cosmological Compton length. This does not
derive Hv. Nor has today's cosmological state been proved to equal this vacuum;
the 27 initial-state probes explicitly show remaining state dependence.

## The matter density held fixed must be stated

The exact scalar equation in this invariant sector is

    box varphi = Hv^2 U_,varphi - 4 pi Gstar alpha_m T_E.

For nonrelativistic particles with fixed Einstein-coordinate number density,
let rho0 denote conserved rest mass density before multiplication by A. Then
rho_E=rho0 A, T_E=-rho_E to the dust approximation. At the vacuum A=1 and

    d(alpha_m rho_E)/dvarphi = (beta_m+alpha_m^2) rho0 = -rho0.

Holding rho_E fixed instead would give beta_m rather than beta_m+alpha_m^2;
that is a different prescribed-source approximation. Fluid structure and
stress support must be solved to go beyond either approximation.

In a locally flat, quasistatic, prescribed dust profile, linearization around
the vacuum therefore gives

    (Delta - mu^2 + 4 pi Gstar rho0) delta_varphi
        = 4 pi Gstar sqrt(k) rho0,                         (1)

with rho0 in mass density and Gstar/c^2 inserted in spatial SI units.
The density changes the squared inverse length to mu^2-4 pi Gstar rho0.
Its sign is opposite to a positive density-induced mass that would suppress
the force. A negative local coefficient is not by itself a global instability:
the finite spatial operator and boundary conditions decide that question.

Equation (1) retains a density feedback term which is next order in weak
compactness. Solving it exactly is useful as an operator diagnostic. It is
not a consistent complete first-post-Newtonian body calculation because
metric, pressure, density redistribution and other corrections of that order
have not been included. It is also not a claim about all nonlinear solutions.

## Finite radius, rather than density alone, controls this response

Let a prescribed uniform ball have radius R, background rest mass M=M0=integral rho0 d^3r at A=1, and
Phi_star=Gstar M0/(R c^2). The perturbed Einstein matter mass
integral A rho0 d^3r differs at the feedback order and is not the M in (2). In the mu R=0 limit of (1), set
z=sqrt(3 Phi_star). Regularity at r=0, decay at infinity, and continuity of
field and radial derivative at R give exactly

    delta_varphi_in/sqrt(k) = 1 - sin(z r/R)/[(z r/R) cos z],
    delta_varphi_out/sqrt(k) = -(R/r)[tan(z)/z - 1].        (2)

The center uses the continuous sinc value. These formulas hold away from
cos z=0. On the small positive compactness branch, the scalar charge factor
relative to sqrt(k)M is

    F_body = 3[tan(z)-z]/z^3
           = 1 + (6/5) Phi_star + (51/35) Phi_star^2 + O(Phi_star^3).

It is an enhancement in this approximation. The central field displacement
is sqrt(k)(1-sec z)=-3 sqrt(k)Phi_star/2+O(sqrt(k)Phi_star^2).
High material density alone does not justify replacing a finite weak body
by the minimum of an infinite homogeneous density-dependent potential.
The small parameter here contains radius: 4 pi Gstar rho0 R^2/c^2=3 Phi_star.

A shape-independent version applies to the linear prescribed source. Let
T_mu f(r)=Gstar/c^2 integral rho0(r') exp(-mu|r-r'|) f(r')/|r-r'| d^3r',
and q=sup_r T_0 1(r). For nonnegative bounded compactly supported density,
||T_mu||_infinity<=q. If q<1, (I-T_mu)delta_varphi=-sqrt(k)T_mu1 has a unique
bounded solution with a convergent Neumann series and

    ||delta_varphi||_infinity <= sqrt(k) q/(1-q).

Every term in that series has nonpositive sign, so this feedback does not
screen the source on that branch. This is a precise bound for (1), not a
nonlinear elliptic existence theorem for the full Einstein/matter system.
For the uniform ball q=3 Phi_star/2, so q is very small at solar compactness.

## Metric readout and the observational comparison

At leading weak-source order drop the density feedback and solve
(Delta-mu^2)delta_varphi=4 pi Gstar sqrt(k)rho0. A spherical source produces

    delta_varphi = -sqrt(k) Gstar M F_Y exp(-mu r)/(r c^2),
    F_Y = (1/M) integral rho0(r') sinh(mu r')/(mu r') d^3r'.

For a uniform ball F_Y=3[(mu R)cosh(mu R)-sinh(mu R)]/(mu R)^3,
with F_Y=1+(mu R)^2/10+O((mu R)^4). Finite source shape has no leading
massless charge suppression. In Einstein coordinates Ustar=Gstar M/(r c^2),
the linear metric has g00=-(1-2Ustar), gij=(1+2Ustar)delta_ij.
Conformal multiplication by 1+2sqrt(k)delta_varphi gives physical potentials

    Phi_J=Ustar[1+k F_Y exp(-mu r)],
    Psi_J=Ustar[1-k F_Y exp(-mu r)].

Consequently their ratio is (1-k F_Y exp(-mu r))/(1+k F_Y exp(-mu r)).
For mu r<<1 and weak-source self-gravity corrections neglected, this becomes

    G_N=Gstar(1+k), gamma-1=-2k/(1+k).                    (3)

When mu r is not small, that ratio varies with radius and cannot simply be
inserted as a constant PPN gamma into the Cassini analysis. An orbitally
inferred mass would involve the force factor (1+mu r)exp(-mu r) as well.
No fitted radio data likelihood is reconstructed here.

The already exposed Cassini result is gamma-1=(2.1+-2.3)e-5 (quoted one-sigma
uncertainty), Bertotti, Iess and Tortora, Nature425,374 (2003), DOI10.1038/nature01997.
It is model-development evidence, not a newly independent test. Formula (3)
at the stated vacuum would require k<=1.2500156252e-5 merely to lie within
the two-quoted-error interval. That is a conditional interval comparison,
not a new confidence limit or a preferred fitted value of k. The one-error
edge near k=1e-6 is too close to support a robust pass/fail claim after omitted
background and body corrections. No observation has selected k or this action.

## Required next checks and open physical assumptions

Check the derivatives, normalization, Green-operator sign, sphere matching,
and small-parameter scales independently. Freeze exact nominal constants and
the already used Hv calibration before numerical evaluation. Evaluate
perturbed exterior backgrounds, including the actual present states, before
extending (3) to the campaign's cosmological histories. A realistic Sun,
its pressure/density profile, weak metric corrections, ambient cosmological
matching and the experimental light-time model remain open bridge work.
The three scalar fields, universal conformal matter
coupling, action form, k, nu, and vacuum/gravity hierarchy are still supplied.
