#!/usr/bin/env python3
"""Parent local-force derivation controls and prescribed-body diagnostics."""
from pathlib import Path
import argparse, hashlib, importlib.util, json
import mpmath as mp
import numpy as np
import sympy as s
from scipy.integrate import solve_bvp,solve_ivp
P=Path(__file__).resolve().parent;PACK=P.parent

def main(protocol_path,out):
    protocol=json.loads(protocol_path.read_text());out.mkdir(exist_ok=False);checks=[]
    def check(name,ok,**kw):checks.append(dict(name=name,passed=bool(ok),**kw))
    for row in protocol['inputs']:check('source.'+row['path'],hashlib.sha256((PACK/row['path']).read_bytes()).hexdigest()==row['sha256'])
    if not all(x['passed'] for x in checks):raise RuntimeError('Input changed before execution')
    k,nu,u,x,y=s.symbols('k nu u x y',positive=True);a=(1-k)*(1+3*k)/4;al=s.sqrt(a);ss=(1+k)/(k*(1-3*k));E=s.exp(2*al*u);F=1+ss*E;J=1+(1-3*a)*ss*E;D=1+2*(1+k)*(x*x+y*y)/3
    K=[J/F**2,(1+ss)*4*k/(9*F*D),(1+ss)*k/(3*F*D)];C=(1+ss)*E/F;ab=s.diff(s.log(C),u)/2
    U=s.Rational(3,2)+s.Rational(3,2)*ss*(E-1)**2/F**2+k*x*x*s.exp(-(1-k)*u/al)/2+k*y*y*s.exp(-(1+k)*u/al)/3+nu*(1+ss)*u*u/(2*F**2)
    zero={u:0,x:0,y:0};beta=s.diff(ab,u)/K[0]-ab*s.diff(K[0],u)/(2*K[0]**2)
    identities={'alpha_squared':(ab**2/K[0]).subs(zero)-k,'beta':beta.subs(zero)+(1+k),'source_density_curvature':(beta+ab**2/K[0]).subs(zero)+1}
    expected=[4*(3*(1+k)+nu)/(1-3*k),s.Rational(9,4),s.Integer(2)]
    for i,q in enumerate([u,x,y]):identities['mass_'+str(q)]=(s.diff(U,q,2)/K[i]).subs(zero)-expected[i]
    z,t=s.symbols('z t',positive=True);w=t-s.sin(z*t)/(z*s.cos(z));inside=w/t
    identities.update(sphere_equation=s.diff(w,t,2)+z*z*w-z*z*t,sphere_origin=s.limit(w,t,0),sphere_boundary=s.diff(w,t).subs(t,1),sphere_center=s.limit(inside,t,0)-(1-1/s.cos(z)),sphere_charge=w.subs(t,1)+(s.tan(z)/z-1))
    identities['charge_expansion']=s.series(3*(s.tan(z)-z)/z**3,z,0,6).removeO()-(1+2*z*z/5+17*z**4/105)
    q=s.symbols('q',positive=True);form=3*(q*s.cosh(q)-s.sinh(q))/q**3
    identities['Yukawa_shape_limit']=s.limit(form,q,0)-1
    identities['Yukawa_shape_expansion']=s.series(form,q,0,6).removeO()-(1+q*q/10+q**4/280)
    exact=[]
    for name,residual in identities.items():
        reduced=s.factor(s.cancel(residual));check('exact.'+name,reduced==0,residual=str(reduced));exact.append({'name':name,'residual':str(reduced)})
    # The inherited calibration remains a supplied empirical scale. Re-evaluate
    # it from its unchanged thermal inputs, rather than using H0 as a scalar mass.
    src=PACK/'inherited/cosmology/direct_exponential_completion/check_exponential_v1.py';spec=importlib.util.spec_from_file_location('local_inherited_calibration',src);ex=importlib.util.module_from_spec(spec);spec.loader.exec_module(ex)
    c=protocol['constants']['c_m_s'];R=protocol['constants']['solar_radius_nominal_m'];GM=protocol['constants']['solar_mass_parameter_nominal_SI'];AU=protocol['constants']['AU_m']
    scales=[]
    for kk in protocol['k_values']:
        cc=ex.cfg(kk,256);Hv=np.sqrt(cc['Hv2']);mu=Hv*np.sqrt(4*(3*(1+kk)+protocol['nu'])/(1-3*kk))/c;phi=GM/((1+kk)*R*c*c)
        rr=dict(k=kk,nu=protocol['nu'],Hv_per_second=float(Hv),mass_u_per_second=float(mu*c),Compton_length_m=float(1/mu),mu_R_sun=float(mu*R),mu_100_AU=float(mu*100*AU),Phi_star_nominal_sun=float(phi),Green_norm_bound=float(1.5*phi),gamma_minus_one_vacuum=float(-2*kk/(1+kk)))
        scales.append(rr)
    body=[];mp.mp.dps=70
    phis=protocol['synthetic_compactness']+[scales[-1]['Phi_star_nominal_sun']]
    for i,phi in enumerate(phis):
        nodes=np.linspace(0,1,81);zz=3*phi
        # Divide w=t delta_varphi/alpha by Phi to avoid losing the weak signal.
        def fun(t,Y):return np.vstack([Y[1],3*t-zz*Y[0]])
        def bc(A,B):return np.array([A[0],B[1]])
        guess=np.vstack([.5*nodes**3-1.5*nodes,1.5*nodes**2-1.5])
        bvp=solve_bvp(fun,bc,nodes,guess,tol=1e-11,max_nodes=10000)
        def shoot(t,Y):return [Y[1],3*t-zz*Y[0],Y[3],-zz*Y[2]]
        ivp=solve_ivp(shoot,(0,1),[0,0,0,1],method='DOP853',rtol=2e-12,atol=2e-14,dense_output=True,max_step=.02)
        final=ivp.y[:,-1];slope=-final[1]/final[3];grid=np.linspace(0,1,301);yy=ivp.sol(grid);ivp_w=yy[0]+slope*yy[2];zmp=mp.sqrt(3*mp.mpf(str(phi)))
        analytic=np.array([float((mp.mpf(str(t))-mp.sin(zmp*mp.mpf(str(t)))/(zmp*mp.cos(zmp)))/mp.mpf(str(phi))) for t in grid])
        bvp_w=bvp.sol(grid)[0];err1=float(np.max(abs(bvp_w-analytic)));err2=float(np.max(abs(ivp_w-analytic)));factor=float(3*(mp.tan(zmp)-zmp)/zmp**3)
        check('body.'+str(i)+'.bvp',bvp.success and err1<2e-9,max_error_scaled_by_Phi=err1,message=bvp.message)
        check('body.'+str(i)+'.shooting',ivp.success and err2<2e-9,max_error_scaled_by_Phi=err2,message=ivp.message)
        check('body.'+str(i)+'.charge',abs(-bvp.sol(1.)[0]-factor)<2e-9,error=float(abs(-bvp.sol(1.)[0]-factor)))
        body.append(dict(Phi_star=phi,scalar_charge_factor=factor,central_delta_varphi_over_alpha=float(1-1/mp.cos(zmp)),bvp_success=bool(bvp.success),shooting_success=bool(ivp.success),max_bvp_error=err1,max_shooting_error=err2,rows=[dict(r_over_R=float(t),w_over_Phi_bvp=float(v),w_over_Phi_shooting=float(iv),w_over_Phi_exact=float(av)) for t,v,iv,av in zip(grid,bvp_w,ivp_w,analytic)]))
    for row in protocol['inputs']:check('unchanged.'+row['path'],hashlib.sha256((PACK/row['path']).read_bytes()).hexdigest()==row['sha256'])
    result={'scope':'Action derivatives and prescribed flat weak-body diagnostics at an exact vacuum; no actual present-background matching, no realistic solar-body solution, no fitted light-time likelihood, no new independent observation test.','checks':checks,'counts':{'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks)},'mass_and_solar_scales':scales,'body_controls':body,'exact':exact}
    (out/'RESULTS.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps({'counts':result['counts'],'mass_and_solar_scales':scales,'body_controls':[{k:v for k,v in b.items() if k!='rows'} for b in body]},indent=2));return int(result['counts']['failed']>0)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--protocol',type=Path,required=True);p.add_argument('--out',type=Path,required=True);args=p.parse_args();raise SystemExit(main(args.protocol,args.out))
