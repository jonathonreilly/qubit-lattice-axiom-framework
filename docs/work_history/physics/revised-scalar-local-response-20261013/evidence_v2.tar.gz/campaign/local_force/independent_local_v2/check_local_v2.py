#!/usr/bin/env python3
"""Independent check from the two frozen prose premises, with no parent imports.

This is evidence for conditional mathematics, not an audit or a relativistic
body/stability calculation. It reads its own frozen input snapshots and prints
one JSON record. Run with python3 -B check_local.py.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys
import traceback

import mpmath as mp
import numpy as np
import scipy
from scipy.integrate import solve_bvp
import sympy as sp


HERE = Path(__file__).resolve().parent
mp.mp.dps = 80
checks = []


def record(name, ok, evidence):
    checks.append({"name": name, "satisfied": bool(ok), "evidence": evidence})


def equal(name, actual, expected):
    residual = sp.simplify(actual - expected)
    record(name, residual == 0, {"derived": str(sp.factor(actual)),
                                "claimed": str(expected),
                                "exact_residual": str(residual)})


def decimals(value):
    return mp.nstr(value, 65)


def scaled_error(a, b):
    return abs(a - b) / (1 + abs(b))


def symbolic_action():
    k, u, x, y, nu = sp.symbols("k u x y nu", real=True)
    a = (1-k)*(1+3*k)/4
    b = k
    s = (1+k)/(k*(1-3*k))
    alpha = sp.sqrt(a)
    E = sp.exp(2*alpha*u)
    F = 1+s*E
    D = 1+2*(1+b)*(x*x+y*y)/3
    J = 1+(1-3*a)*s*E
    K = sp.diag(J/F**2, (1+s)*4*b/(9*F*D), (1+s)*b/(3*F*D))
    C = (1+s)*E/F
    lx = 2*alpha*(1+s*b)/(b*(1+s))
    ly = 4*alpha*s/(1+s)
    U = (sp.Rational(3, 2) + 3*s*(E-1)**2/(2*F**2)
         + b*x*x*sp.exp(-lx*u)/2 + b*y*y*sp.exp(-ly*u)/3
         + nu*(1+s)*u*u/(2*F**2))
    origin = {u: 0, x: 0, y: 0}
    Ku = K[0, 0]
    K0 = K.subs(origin).applyfunc(sp.factor)
    H0 = sp.hessian(U, [u, x, y]).subs(origin).applyfunc(sp.factor)
    masses = (K0.inv()*H0).applyfunc(sp.factor)
    equal("kinetic_positivity_identity", 1-3*a, (1-3*k)**2/4)
    equal("vacuum_C", C.subs(origin), 1)
    equal("vacuum_U", U.subs(origin), sp.Rational(3, 2))
    for v in [u, x, y]:
        equal("vacuum_gradient_"+str(v), sp.diff(U, v).subs(origin), 0)
    for v in [x, y]:
        equal("invariant_sector_U_"+str(v), sp.diff(U, v).subs({x: 0, y: 0}), 0)
        equal("invariant_sector_Ku_"+str(v), sp.diff(Ku, v), 0)
        equal("matter_coupling_"+str(v), sp.diff(C, v), 0)
    equal("vacuum_Ku", K0[0, 0], k*(1-3*k)**2/(16*a))
    equal("vacuum_Uuu", H0[0, 0], k*(1-3*k)*(3*(1+k)+nu)/(4*a))
    expected = sp.diag(4*(3*(1+k)+nu)/(1-3*k), sp.Rational(9, 4), 2)
    for i in range(3):
        for j in range(3):
            equal(f"vacuum_mass_matrix_{i}_{j}", masses[i, j], expected[i, j])

    # D_varphi = Ku^(-1/2) D_u. Avoid a branch-ambiguous sqrt simplification:
    # sign(alpha_m) follows separately from alpha/F>0 and sqrt(Ku)>0.
    B = sp.log(C)/2
    alpha_squared = (sp.diff(B, u)**2/Ku).subs(origin)
    beta = ((sp.diff(B, u, 2)-sp.diff(B, u)*sp.diff(Ku, u)/(2*Ku))/Ku).subs(origin)
    equal("alpha_m_squared", alpha_squared, k)
    equal("beta_m", beta, -(1+k))
    equal("beta_plus_alpha_squared", alpha_squared+beta, -1)
    A = sp.sqrt(C)
    A2 = ((sp.diff(A, u, 2)-sp.diff(A, u)*sp.diff(Ku, u)/(2*Ku))/Ku).subs(origin)
    equal("conserved_density_A_second_derivative", A2, -1)
    equal("small_k_mu2_Hv2", sp.limit(masses[0, 0], k, 0, dir="+"), 4*(3+nu))
    record("action_normalization_record", True, {
        "Einstein_coefficient": "Q/2 = 1/(16*pi*Gstar)",
        "scalar_variation_coefficient": "2*Q*box(varphi)-2*Q*Hv^2*U_varphi+alpha_m*T_E=0",
        "equation": "box(varphi)=Hv^2*U_varphi-4*pi*Gstar*alpha_m*T_E",
        "density_linearization": "T_E=-rho0*A; (alpha_m*A)'=A''=-1 at the vacuum",
        "spatial_equation": "(Delta-mu^2+sigma)*delta_varphi=sigma*sqrt(k), sigma=4*pi*Gstar*rho0/c^2",
        "verification_kind": "algebraic variation recorded explicitly; no observational inputs"})


def symbolic_radial_and_metric():
    t, z = sp.symbols("t z", positive=True)
    f = 1-sp.sin(z*t)/(z*t*sp.cos(z))
    w = t*f
    exterior_amplitude = 1-sp.tan(z)/z
    equal("radial_interior_equation", sp.diff(w, t, 2)+z*z*w, z*z*t)
    equal("radial_regular_center_w", sp.limit(w, t, 0), 0)
    equal("radial_exterior_matching_wprime", sp.diff(w, t).subs(t, 1), 0)
    equal("radial_surface_value", f.subs(t, 1), exterior_amplitude)
    equal("radial_surface_derivative", sp.diff(f, t).subs(t, 1), -exterior_amplitude)
    equal("radial_center_value", sp.limit(f, t, 0), 1-1/sp.cos(z))
    factor = sp.simplify(3*sp.integrate(t*t*(1-f), (t, 0, 1)))
    equal("radial_charge_from_volume_source", factor, 3*(sp.tan(z)-z)/z**3)
    phi = sp.symbols("Phi", nonnegative=True)
    series = sp.series(factor, z, 0, 5).removeO().subs(z*z, 3*phi).expand()
    equal("radial_charge_expansion_through_Phi2", series,
          1+sp.Rational(6, 5)*phi+sp.Rational(51, 35)*phi**2)
    equal("radial_center_leading_term", sp.limit((1-1/sp.cos(z))/z**2, z, 0), -sp.Rational(1, 2))

    # A second route to the charge series uses repeated Poisson Green operators.
    s = sp.symbols("s", nonnegative=True)
    def T_poly(p):
        return sp.expand(z*z*(sp.integrate(s*s*p.subs(t, s), (s, 0, t))/t
                               + sp.integrate(s*p.subs(t, s), (s, t, 1))))
    term = sp.Integer(1)
    neumann_field = 0
    for _ in range(3):
        term = T_poly(term)
        neumann_field -= term
    neumann_charge = sp.expand(-3*neumann_field.subs(t, 1)/z**2)
    equal("charge_series_independent_Poisson_iteration", neumann_charge,
          1+sp.Rational(2, 5)*z*z+sp.Rational(17, 105)*z**4)
    equal("uniform_ball_T1_inside", T_poly(sp.Integer(1)), z*z*(sp.Rational(1, 2)-t*t/6))
    equal("uniform_ball_q", T_poly(sp.Integer(1)).subs(t, 0), z*z/2)

    eta = sp.symbols("eta", positive=True)
    FY = 3*sp.integrate(t*sp.sinh(eta*t)/eta, (t, 0, 1))
    equal("Yukawa_uniform_ball_factor", FY, 3*(eta*sp.cosh(eta)-sp.sinh(eta))/eta**3)
    equal("Yukawa_FY_limit", sp.limit(FY, eta, 0), 1)
    equal("Yukawa_FY_first_correction", sp.limit((FY-1)/eta**2, eta, 0), sp.Rational(1, 10))

    eps, Ustar, ac, d, k, Y = sp.symbols("eps Ustar alpha delta k Y", real=True)
    g00 = sp.series((1+2*eps*ac*d)*(-1+2*eps*Ustar), eps, 0, 2).removeO()
    gii = sp.series((1+2*eps*ac*d)*(1+2*eps*Ustar), eps, 0, 2).removeO()
    PhiJ = sp.expand((g00+1)/(2*eps))
    PsiJ = sp.expand((gii-1)/(2*eps))
    equal("conformal_PhiJ", PhiJ, Ustar-ac*d)
    equal("conformal_PsiJ", PsiJ, Ustar+ac*d)
    equal("sourced_PhiJ", PhiJ.subs(d, -ac*Ustar*Y).subs(ac*ac, k), Ustar*(1+k*Y))
    equal("sourced_PsiJ", PsiJ.subs(d, -ac*Ustar*Y).subs(ac*ac, k), Ustar*(1-k*Y))
    equal("massless_gamma_minus_one", (1-k)/(1+k)-1, -2*k/(1+k))
    r, mu, fy = sp.symbols("r mu FY", positive=True)
    force_factor = -r*r*sp.diff((1+k*fy*sp.exp(-mu*r))/r, r)
    equal("finite_range_force_factor", force_factor, 1+k*fy*(1+mu*r)*sp.exp(-mu*r))
    record("quoted_interval_arithmetic_only", True, {
        "input": "gamma-1=(2.1 +/- 2.3)*10^-5, as quoted in the source; observation not independently checked",
        "two_error_lower_edge": "-0.000025",
        "two_error_k_max_exact": "1/79999",
        "two_error_k_max_decimal": str(sp.N(sp.Rational(1, 79999), 30)),
        "one_error_k_max_exact": "1/999999",
        "one_error_k_max_decimal": str(sp.N(sp.Rational(1, 999999), 30)),
        "no_likelihood_or_astronomical_fit": True})


def numerical_action():
    # Raw numerical action is independently typed from the premise, not lambdified
    # from the symbolic Hessian and not imported from any campaign runner.
    cases = [("0.000001", "1"), ("0.00001", "1"), ("0.01", "1"),
             ("0.2", "1"), ("0.32", "1"), ("0.1", "0.25"), ("0.1", "3")]
    for ks, ns in cases:
        k, nu = mp.mpf(ks), mp.mpf(ns)
        a = (1-k)*(1+3*k)/4
        s = (1+k)/(k*(1-3*k))
        ax = 2*mp.sqrt(a)*(1+s*k)/(k*(1+s))
        ay = 4*mp.sqrt(a)*s/(1+s)
        def ingredients(u, x=mp.mpf("0"), y=mp.mpf("0")):
            e = mp.exp(2*mp.sqrt(a)*u)
            f = 1+s*e
            d = 1+2*(1+k)*(x*x+y*y)/3
            j = 1+(1-3*a)*s*e
            kinetic = [j/(f*f), (1+s)*4*k/(9*f*d), (1+s)*k/(3*f*d)]
            coupling = (1+s)*e/f
            potential = (mp.mpf("1.5")+3*s*(e-1)**2/(2*f*f)
                         + k*x*x*mp.exp(-ax*u)/2 + k*y*y*mp.exp(-ay*u)/3
                         + nu*(1+s)*u*u/(2*f*f))
            return kinetic, coupling, potential
        zero = mp.mpf("0")
        K0 = ingredients(zero)[0]
        h = [mp.diff(lambda u: ingredients(u)[2], zero, 2),
             mp.diff(lambda x: ingredients(zero, x)[2], zero, 2),
             mp.diff(lambda y: ingredients(zero, zero, y)[2], zero, 2)]
        masses = [h[i]/K0[i] for i in range(3)]
        def log_A(u):
            return mp.log(ingredients(u)[1])/2
        def am(u):
            return mp.diff(log_A, u)/mp.sqrt(ingredients(u)[0][0])
        alpha = am(zero)
        beta = mp.diff(am, zero)/mp.sqrt(K0[0])
        def DA(u):
            return mp.diff(lambda v: mp.sqrt(ingredients(v)[1]), u)/mp.sqrt(ingredients(u)[0][0])
        A2 = mp.diff(DA, zero)/mp.sqrt(K0[0])
        target = [4*(3*(1+k)+nu)/(1-3*k), mp.mpf(9)/4, mp.mpf(2), mp.sqrt(k), -(1+k), -mp.mpf(1)]
        values = masses+[alpha, beta, A2]
        errors = [scaled_error(a, b) for a, b in zip(values, target)]
        record(f"80digit_raw_action_k={ks}_nu={ns}", max(errors) < mp.mpf("1e-55"), {
            "K0": [decimals(v) for v in K0], "H0_diagonal": [decimals(v) for v in h],
            "masses_Hv2": [decimals(v) for v in masses], "alpha_m": decimals(alpha),
            "beta_m": decimals(beta), "A_second": decimals(A2),
            "max_scaled_error": decimals(max(errors)), "threshold": "1e-55"})


def numerical_bvp():
    # Numerically solve a boundary-value problem without using the proposed
    # closed-form profile as an initial guess or as boundary data.
    for z in [0.001, 0.02, 0.3, 1.0, 1.4, 1.55]:
        def rhs(t, state):
            return np.vstack((state[1], z*z*(t-state[0])))
        def bc(left, right):
            return np.array([left[0], right[1]])
        mesh = np.linspace(0, 1, 81)
        solution = solve_bvp(rhs, bc, mesh, np.zeros((2, mesh.size)), tol=1e-10, max_nodes=10000)
        points = np.linspace(0, 1, 101)
        sol = solution.sol(points)
        actual = np.concatenate(([sol[1, 0]], sol[0, 1:]/points[1:]))
        zm = mp.mpf(str(z))
        expected = np.array([float(1-1/mp.cos(zm)) if t == 0 else
                             float(1-mp.sin(zm*mp.mpf(str(t)))/(zm*mp.mpf(str(t))*mp.cos(zm)))
                             for t in points])
        err = float(np.max(np.abs(actual-expected)/(1+np.abs(expected))))
        boundary = float(np.max(np.abs(bc(solution.y[:, 0], solution.y[:, -1]))))
        record(f"independent_radial_BVP_z={z}", solution.success and err < 5e-9 and boundary < 1e-12, {
            "success": bool(solution.success), "solver_status": int(solution.status),
            "solver_message": solution.message, "nodes": int(solution.x.size),
            "max_scaled_profile_error": err, "threshold": 5e-9,
            "boundary_residual": boundary, "q": z*z/2,
            "center": float(actual[0]), "surface": float(actual[-1]),
            "scope": "prescribed-flat radial equation only; z=1.55 is outside contraction guarantee, not a physical-body prediction"})


def numerical_green_and_yukawa():
    for zs in ["0.01", "0.5", "1.3"]:
        z = mp.mpf(zs)
        def f(t):
            if t == 0:
                return 1-1/mp.cos(z)
            if t <= 1:
                return 1-mp.sin(z*t)/(z*t*mp.cos(z))
            return (1-mp.tan(z)/z)/t
        residuals = []
        signs = []
        for ts in ["0", "0.3", "1", "2"]:
            t = mp.mpf(ts)
            if t == 0:
                Tf = z*z*mp.quad(lambda s: s*f(s), [0, 1])
                T1 = z*z/2
            elif t <= 1:
                Tf = z*z*(mp.quad(lambda s: s*s*f(s), [0, t])/t
                          + mp.quad(lambda s: s*f(s), [t, 1]))
                T1 = z*z*(mp.mpf("0.5")-t*t/6)
            else:
                Tf = z*z*mp.quad(lambda s: s*s*f(s), [0, 1])/t
                T1 = z*z/(3*t)
            residuals.append(abs(f(t)-Tf+T1))
            signs.append(f(t) <= -T1)
        q = z*z/2
        bound = q/(1-q)
        exact_norm = 1/mp.cos(z)-1  # On 0<z<sqrt(2), f increases from the center.
        record(f"Green_integral_and_bound_z={zs}", max(residuals) < mp.mpf("1e-60")
               and all(signs) and exact_norm <= bound, {
                   "max_absolute_integral_residual": decimals(max(residuals)),
                   "q": decimals(q), "normalized_field_sup": decimals(exact_norm),
                   "normalized_Neumann_bound": decimals(bound),
                   "no_screening_sample_signs": signs})
    for etas in ["0.001", "0.4", "3"]:
        eta = mp.mpf(etas)
        from_integral = 3*mp.quad(lambda t: t*mp.sinh(eta*t)/eta, [0, 1])
        from_formula = 3*(eta*mp.cosh(eta)-mp.sinh(eta))/eta**3
        error = scaled_error(from_integral, from_formula)
        record(f"Yukawa_volume_integral_eta={etas}", error < mp.mpf("1e-60"), {
            "integral": decimals(from_integral), "formula": decimals(from_formula),
            "scaled_error": decimals(error)})


started = datetime.now(timezone.utc).isoformat()
for suite in [symbolic_action, symbolic_radial_and_metric, numerical_action, numerical_bvp, numerical_green_and_yukawa]:
    try:
        suite()
    except Exception as error:
        record(suite.__name__+"_unhandled_failure", False,
               {"exception": repr(error), "traceback": traceback.format_exc()})

sources = json.loads((HERE/"SOURCE_SNAPSHOT.json").read_text())
for source in sources["inputs"]:
    data = (HERE/source["snapshot_path"]).read_bytes()
    record("frozen_input_hash_"+source["snapshot_path"], hashlib.sha256(data).hexdigest() == source["sha256"],
           {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})

result = {
    "started_utc": started, "finished_utc": datetime.now(timezone.utc).isoformat(),
    "scope": "Independent mathematical/normalization check of the frozen local-force derivation; not formal audit, full relativistic screening, stability, cosmological-state identification, or empirical validation.",
    "environment": {"python": sys.version, "executable": sys.executable,
                    "platform": platform.platform(), "sympy": sp.__version__,
                    "mpmath": mp.__version__, "numpy": np.__version__, "scipy": scipy.__version__},
    "sources": sources["inputs"], "checks": checks,
    "summary": {"checks": len(checks), "satisfied": sum(c["satisfied"] for c in checks),
                "not_satisfied": sum(not c["satisfied"] for c in checks)},
    "required_clarifications": [
        "M in the exact prescribed-density ball calculation must be M0=integral rho0 d^3x, the conserved/background mass. The field-dependent Einstein matter mass integral A*rho0 d^3x differs at the retained feedback order.",
        "The whole-space Green inverse imposes zero perturbation at infinity. At mu=0, boundedness alone is not a PDE boundary condition, although the displayed integral equation itself has a unique bounded solution when q<1.",
        "The Neumann no-screening result is a statement about equation (1), not a nonlinear Einstein-fluid body or a temporal stability theorem.",
        "All listed vacuum response and gamma formulas require that vacuum as exterior background; the present cosmological state is not established here."
    ],
    "previous_stream_failures": "Preserved by exact snapshot; these absent computations were neither retried nor counted as evidence."
}
print(json.dumps(result, indent=2))
sys.exit(0 if result["summary"]["not_satisfied"] == 0 else 1)
