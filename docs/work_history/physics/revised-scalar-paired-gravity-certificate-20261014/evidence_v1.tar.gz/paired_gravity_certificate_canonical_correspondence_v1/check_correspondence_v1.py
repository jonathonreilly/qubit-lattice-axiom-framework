"""Staged source/output correspondence only; never executes science functions."""
from pathlib import Path
from datetime import datetime,timezone
import ast,base64,copy,difflib,hashlib,json,zlib

HERE=Path(__file__).resolve().parent
B=json.loads((HERE/'SOURCE_BINDINGS_v1.json').read_text());WT=Path(B['worktree']);PK=HERE.parent
sources=B['sources']+json.loads((HERE/'ADDITIONAL_BINDINGS_v1.json').read_text())['sources']
lookup={r['original_path']:Path(r['snapshot_path']) for r in sources}
def snap(p):return lookup[str(p)]
def load(p):return json.loads(snap(p).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[];facts={};dispositions=[]
def ck(name,b,detail=None):rows.append(dict(name=name,passed=bool(b),detail=detail))
def dump(name,obj):
 p=HERE/name;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2)+'\n')
pack=PK/'paired_gravity_certificate_packaging';original=PK/'rolling_local_response/paired_gravity_certificate_v1';shared=PK/'claim_type_format_correspondence_v1'
note=pack/'staged/EXPONENTIAL_SCALAR_PAIRED_GRAVITY_CERTIFICATE_BOUNDED_THEOREM_NOTE_2026-10-14.md'
formatted=pack/'formatted_v2'/note.name;runner=pack/'staged/exponential_scalar_paired_gravity_certificate_check.py';origcode=original/'check_certificate_v1.py'
lineage=load(pack/'CANONICAL_LINEAGE_v1.json')
ck('staged_note_lineage_hash',sha(snap(note))==lineage['note_sha256'])
ck('staged_runner_lineage_hash',sha(snap(runner))==lineage['runner_sha256'])
ck('producer_source_lineage_hash',sha(snap(origcode))==lineage['code_sources'][0]['sha256'])
hand=snap(original/'DERIVATION_v1.md').read_text()
port='\n'.join('#'+line if line.startswith('#') else line for line in hand.splitlines())+'\n'
ck('full_hand_proof_body_original_stage',port in snap(note).read_text())
ck('full_hand_proof_body_formatted_stage',port in snap(formatted).read_text())
old=snap(note).read_bytes();new=snap(formatted).read_bytes();offsets=[i for i,(a,b) in enumerate(zip(old,new)) if a!=b]
ck('format_exact_single_space_to_newline',len(old)==len(new) and offsets==[83] and old[83:84]==b' ' and new[83:84]==b'\n')
for name,expected in [('OLD.md',old),('NEW.md',new),('INSTALL.md',new),('CURRENT_SOURCE.md',old)]:ck('shared_format_snapshot:'+name,snap(shared/'sources/paired_gravity_certificate'/name).read_bytes()==expected)

tree0=ast.parse(snap(origcode).read_text());tree1=ast.parse(snap(runner).read_text())
scientific=[copy.deepcopy(n) for n in tree0.body if isinstance(n,(ast.Import,ast.ImportFrom,ast.Assign,ast.FunctionDef))]
for n in scientific:
 if isinstance(n,ast.FunctionDef) and n.name=='run':n.name='check_certificate'
start=next(i for i,n in enumerate(tree1.body) if isinstance(n,ast.ImportFrom) and n.module=='pathlib')
end=next(i for i,n in enumerate(tree1.body) if isinstance(n,ast.FunctionDef) and n.name=='check_certificate')+1
dumpast=lambda ns:ast.dump(ast.Module(body=ns,type_ignores=[]),include_attributes=False)
ck('entire_scientific_AST_identity',dumpast(scientific)==dumpast(tree1.body[start:end]))
facts['scientific_ast_sha256']=hashlib.sha256(dumpast(scientific).encode()).hexdigest()
ck('lineage_ast_hash',facts['scientific_ast_sha256']==lineage['code_sources'][0]['transformed_ast_sha256'])
imports=[]
for n in tree1.body:
 if isinstance(n,ast.Import):imports.extend(x.name for x in n.names)
 if isinstance(n,ast.ImportFrom):imports.append(n.module)
facts['imports']=imports
ck('runtime_imports_isolated',set(imports)==set(['contextlib','tempfile','io','zlib','base64','pathlib','argparse','json','hashlib','itertools','sympy','mpmath']))
inputs=next(ast.literal_eval(n.value) for n in tree1.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in n.targets))
facts['declared_inputs']=[]
for rel in inputs:
 p=WT/rel;facts['declared_inputs'].append(dict(path=rel,present_live=p.exists(),sha256=sha(p) if p.exists() else None))
ck('declared_inputs_four_unique_notes',len(inputs)==len(set(inputs))==4 and all(x.startswith('docs/') and x.endswith('.md') for x in inputs))
ck('paired_live_source_still_absent',not (WT/inputs[0]).exists())
ck('calibrated_premise_live_still_absent',not (WT/inputs[3]).exists())
ck('cache_cap_actual_helper','stdout_tail = stdout[-200_000:]' in snap(WT/'scripts/runner_cache.py').read_text())

def scientific_unit(d):return {k:v for k,v in d.items() if k!='checker_sha256'}
def decode_and_check(label,outer,full,script,stdout):
 payload=outer['complete_unit_payload'];encoded=base64.b64decode(payload['data'],validate=True);raw=zlib.decompress(encoded);unit=json.loads(raw)
 ck(label+':codec',payload['codec']=='zlib-base64-json-v1')
 ck(label+':length',len(raw)==payload['uncompressed_bytes'])
 ck(label+':sha256',hashlib.sha256(raw).hexdigest()==payload['sha256'])
 ck(label+':exact_compact_serialization',raw==json.dumps(unit,sort_keys=True,separators=(',',':')).encode())
 ck(label+':complete_profile_equal',unit==full)
 ck(label+':outer_count_identity',(outer['passed'],outer['failed'])==(unit['passed'],unit['failed']))
 ck(label+':inner_checker_identity',unit['checker_sha256']==sha(snap(script)))
 ck(label+':outer_checker_identity',outer['checker_sha256']==sha(snap(script)))
 ck(label+':all_condition_rows',len(unit['checks'])==576 and sum(x['passed'] for x in unit['checks'])==unit['passed'] and sum(not x['passed'] for x in unit['checks'])==unit['failed'])
 ck(label+':all_cases_and_damages',len(unit['noise_cases'])==81 and len(unit['third_epoch_data_damages'])==9)
 readable=json.loads(outer['unit_stdout']);ck(label+':captured_complete_summary',readable['passed']==unit['passed'] and readable['failed']==unit['failed'] and readable['noise_cases']==81 and readable['failed_checks']==[x for x in unit['checks'] if not x['passed']])
 ck(label+':whole_stdout_equal',json.loads(stdout)==outer and stdout==json.dumps(outer,indent=2)+'\n')
 ck(label+':under_actual_cache_cap',len(stdout)<200000)
 dest=HERE/'decoded'/label;dest.mkdir(parents=True,exist_ok=False);(dest/'RAW_COMPACT.json').write_bytes(raw);(dest/'FULL_UNIT.json').write_text(json.dumps(unit,indent=2)+'\n')
 facts[label]=dict(compact_bytes=len(raw),compact_sha256=payload['sha256'],compressed_bytes=len(encoded),outer_characters=len(stdout),pretty_profile_bytes=len(json.dumps(unit,indent=2)+'\n'),passed=unit['passed'],failed=unit['failed'],noise_cases=81,third_epoch_damages=9)
 return unit
outer=load(pack/'STAGED_RESULTS_v1.json');full=load(pack/'profiles_v1/certificate/RESULTS.json');baseline=load(original/'baseline_v1/RESULTS.json')
unit=decode_and_check('staged',outer,full,runner,snap(pack/'STAGED_stdout_v1.txt').read_text())
ck('all_scientific_fields_equal_original_except_hash',scientific_unit(unit)==scientific_unit(baseline))
ck('profile_pretty_bytes_equal_saved',snap(pack/'profiles_v1/certificate/RESULTS.json').read_bytes()==(json.dumps(unit,indent=2)+'\n').encode())
ck('original_baseline_counts',baseline['passed']==576 and baseline['failed']==0)
ck('original_baseline_checker_hash',baseline['checker_sha256']==sha(snap(origcode)))
ck('original_copied_earlier_hand',snap(original/'EARLIER_TWO_EPOCH_DERIVATION_v1.md').read_bytes()==snap(PK/'rolling_local_response/TWO_EPOCH_DERIVATION_v1.md').read_bytes())
run=load(pack/'STAGED_RUN_v1.json');ck('staged_actual_command_return',run['returncode']==0 and run['args'][1]==str(runner));ck('staged_stderr_preserved',snap(pack/'STAGED_stderr_v1.txt').read_bytes()==b'')

for rec in load(pack/'damages_v1/EXECUTIONS_v1.json'):
 script=Path(rec['args'][1]);name=script.stem;outpath=Path(rec['args'][rec['args'].index('--out')+1]);profile=Path(rec['args'][rec['args'].index('--profiles')+1])/'certificate/RESULTS.json'
 d=decode_and_check('staged_damage_'+name,load(outpath),load(profile),script,snap(pack/f'damages_v1/{name}_stdout.txt').read_text())
 ck('staged_damage_actual_failure:'+name,rec['returncode']==1 and rec['passed']==d['passed'] and rec['failed']==d['failed']>0 and rec['source_sha256']==sha(snap(script)))
 ck('staged_damage_stderr:'+name,snap(pack/f'damages_v1/{name}_stderr.txt').read_bytes()==b'')
 origdamage=load(original/f'damages_v1/{name}/RESULTS.json');ck('staged_damage_full_equal_original:'+name,scientific_unit(d)==scientific_unit(origdamage))
 diff=''.join(difflib.unified_diff(snap(runner).read_text().splitlines(True),snap(script).read_text().splitlines(True),fromfile='baseline',tofile=name))
 out=HERE/'diffs'/('staged_'+name+'.diff');out.parent.mkdir(exist_ok=True);out.write_text(diff)
for rec in load(original/'damages_v1/EXECUTIONS_v1.json'):
 script=Path(rec['args'][1]);name=script.stem;d=load(original/f'damages_v1/{name}/RESULTS.json')
 ck('original_damage_actual_failure:'+name,rec['returncode']==1 and rec['passed']==d['passed'] and rec['failed']==d['failed']>0 and d['checker_sha256']==rec['source_sha256']==sha(snap(script)))
 ck('original_damage_all_cases:'+name,len(d['checks'])==576 and len(d['noise_cases'])==81 and len(d['third_epoch_data_damages'])==9)
 ck('original_damage_stdout:'+name,json.loads(snap(original/f'damages_v1/{name}_stdout.txt').read_text())['failed_checks']==[r for r in d['checks'] if not r['passed']])
 diff=''.join(difflib.unified_diff(snap(origcode).read_text().splitlines(True),snap(script).read_text().splitlines(True),fromfile='baseline',tofile=name))
 (HERE/'diffs'/('original_'+name+'.diff')).write_text(diff)

def verify_seal(root,receipt_expected):
 receipt=load(root/'RECEIPT_v1.json');ck('reused_receipt:'+root.name,sha(snap(root/'RECEIPT_v1.json'))==receipt_expected)
 manifest_path=Path(receipt['manifest']['path']);manifest_path=manifest_path if manifest_path.is_absolute() else root/manifest_path
 report_path=Path(receipt['report']['path']);report_path=report_path if report_path.is_absolute() else root/report_path
 ck('reused_manifest:'+root.name,sha(snap(manifest_path))==receipt['manifest']['sha256'])
 ck('reused_report:'+root.name,sha(snap(report_path))==receipt['report']['sha256'])
 man=load(manifest_path)
 for a in man['artifacts']:
  p=Path(a['path']);p=p if p.is_absolute() else root/p
  ck('reused_artifact:'+str(p.relative_to(root)),snap(p).stat().st_size==a['bytes'] and sha(snap(p))==a['sha256'])
 facts['reused_'+root.name]=dict(receipt_sha256=receipt_expected,report_sha256=receipt['report']['sha256'],manifest_sha256=receipt['manifest']['sha256'],artifact_count=len(man['artifacts']))
verify_seal(original/'independent_v1','c0fa29fa2ea8e824f2cd294572a6e666a41aa2c9d42d37b76db4293279eb473d')
verify_seal(shared,'b9e818a451d31c5f3a692d9859250754a904aeaea8e80a26a7f7003087f5ffd7')
for s in sources:
 p=Path(s['original_path']);ss=Path(s['snapshot_path']);ck('frozen_source_identity:'+s['relative_path'],p.stat().st_size==ss.stat().st_size==s['bytes'] and sha(p)==sha(ss)==s['sha256'])
 dispositions.append(dict(original_path=str(p),original_sha256=s['sha256'],disposition='Preserved exact reviewed stage/source/evidence version; no final live delivery claimed.',recovery=str(ss),final_path=None,final_sha256=None))
for oldpath,newpath in [(note,formatted)]:
 for d in dispositions:
  if d['original_path']==str(oldpath):d.update(disposition='Original staged source preserved; one-byte metadata-format successor separately confirmed.',final_path=str(newpath),final_sha256=sha(snap(newpath)))
dump('SOURCE_DISPOSITIONS_v1.json',dict(scope='All reviewed original versions recoverable within this unit; final fields denote only an explicit formatted-stage successor, not a delivered canonical unit.',original_dispositions=dispositions))
dump('CORRESPONDENCE_RESULTS_v1.json',dict(at=datetime.now(timezone.utc).isoformat(),scope='Source, complete payload, preserved producer execution and reused independent-seal correspondence only. No scientific function executed.',passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),checks=rows,facts=facts))
print(json.dumps(dict(passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),failed_checks=[r for r in rows if not r['passed']],facts=facts),indent=2))
raise SystemExit(any(not r['passed'] for r in rows))
