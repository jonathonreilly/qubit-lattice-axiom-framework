"""Narrow correction of one reviewer serialization expectation; no science run."""
from pathlib import Path
from datetime import datetime,timezone
import base64,hashlib,json,zlib
HERE=Path(__file__).resolve().parent
B=json.loads((HERE/'SOURCE_BINDINGS_v1.json').read_text());lookup={r['original_path']:Path(r['snapshot_path']) for r in B['sources']};pack=HERE.parent/'paired_gravity_certificate_packaging'
def source(rel):return lookup[str(pack/rel)]
outer=json.loads(source('STAGED_RESULTS_v1.json').read_text());payload=outer['complete_unit_payload'];raw=zlib.decompress(base64.b64decode(payload['data'],validate=True));unit=json.loads(raw)
original_pretty=source('profiles_v1/certificate/RESULTS.json').read_bytes();full=json.loads(original_pretty)
checks=[]
def ck(n,b):checks.append(dict(name=n,passed=bool(b)))
ck('complete_decoded_JSON_equals_profile',unit==full)
ck('original_pretty_serialization_exact',original_pretty==(json.dumps(full,indent=2)+'\n').encode())
ck('sorted_compact_serialization_exact',raw==json.dumps(full,sort_keys=True,separators=(',',':')).encode())
ck('sorted_pretty_preserves_data_not_original_order',original_pretty!=(json.dumps(unit,indent=2)+'\n').encode() and json.loads(original_pretty)==unit)
ck('all_checks_arrays_equal',unit['checks']==full['checks'])
ck('all_noise_arrays_equal',unit['noise_cases']==full['noise_cases'])
ck('all_third_damage_arrays_equal',unit['third_epoch_data_damages']==full['third_epoch_data_damages'])
ck('payload_bound_length_and_hash',len(raw)==payload['uncompressed_bytes'] and hashlib.sha256(raw).hexdigest()==payload['sha256'])
result=dict(at=datetime.now(timezone.utc).isoformat(),scope='Supersedes only profile_pretty_bytes_equal_saved from preserved correspondence 417/1: payload preserves complete JSON data, not incidental pretty-file object ordering. No source/result change or science rerun.',passed=sum(r['passed'] for r in checks),failed=sum(not r['passed'] for r in checks),checks=checks,original_pretty_sha256=hashlib.sha256(original_pretty).hexdigest(),decoded_compact_sha256=hashlib.sha256(raw).hexdigest(),prior_result_sha256=hashlib.sha256((HERE/'CORRESPONDENCE_RESULTS_v1.json').read_bytes()).hexdigest())
out=HERE/'SERIALIZATION_FOLLOWUP_RESULTS_v1.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));raise SystemExit(bool(result['failed']))
