"""Execute only actual packaging main with independent synthetic stub units."""
from pathlib import Path
from datetime import datetime,timezone
from contextlib import redirect_stdout,redirect_stderr
import argparse,base64,copy,difflib,hashlib,io,json,sys,tempfile,traceback,types,zlib
HERE=Path(__file__).resolve().parent
B=json.loads((HERE/'SOURCE_BINDINGS_v1.json').read_text());lookup={r['original_path']:Path(r['snapshot_path']) for r in B['sources']}
original=HERE.parent/'paired_gravity_certificate_packaging/staged/exponential_scalar_paired_gravity_certificate_check.py';source=lookup[str(original)]
ROOT=HERE/'wrapper_only_v1';ROOT.mkdir(exist_ok=False);rows=[];runs=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(n,b,detail=None):rows.append(dict(name=n,passed=bool(b),detail=detail))
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def decode(o):
 p=o['complete_unit_payload'];assert p['codec']=='zlib-base64-json-v1';raw=zlib.decompress(base64.b64decode(p['data'],validate=True));assert len(raw)==p['uncompressed_bytes'];assert hashlib.sha256(raw).hexdigest()==p['sha256'];return json.loads(raw)

def exercise(name,script,mode,expected_exception=None):
 root=ROOT/name;root.mkdir();module=types.ModuleType('isolated_wrapper_'+name);module.__file__=str(script);module.__name__='isolated_wrapper_'+name
 exec(compile(script.read_text(),str(script),'exec'),module.__dict__)
 stub_events=[];expected_units=[];temporary=[]
 def stub(out):
  stub_events.append(str(out));out.mkdir(parents=True,exist_ok=False)
  failed=1 if mode in ['failed_unit','return_mismatch'] else 0
  unit=dict(passed=2-failed,failed=failed,checks=[dict(name='stub_a',passed=True,detail=None),dict(name='stub_b',passed=not bool(failed),detail='synthetic failure only' if failed else None)],noise_cases=[dict(index=1,nested={'z':[None,True,False,1.25,'λ'], 'a':{'frozen':'rational 2/7'}},full_text='αβγ '+('abc123\n'*20000))],third_epoch_data_damages=[dict(index=9,fixture='stub only')],checker_sha256=sha(script),scope='Wrapper-only synthetic JSON fixture; no science function executed.',additional_unknown_field={'preserve':list(range(100))})
  expected_units.append(unit)
  if mode=='missing_profile':return failed
  (out/'RESULTS.json').write_text('{malformed' if mode=='malformed_profile' else json.dumps(unit,indent=2)+'\n')
  print('stub progress λ\ncomplete stub output')
  return 0 if mode=='return_mismatch' else failed
 module.check_certificate=stub
 def tempfactory(**kwargs):
  t=tempfile.TemporaryDirectory(dir=root,**kwargs);temporary.append(t.name);return t
 module.TemporaryDirectory=tempfactory
 profile=root/'profiles';outfile=root/'outer.json';args=[str(script)]
 if mode!='temporary':args+=['--profiles',str(profile)]
 args+=['--out',str(outfile)]
 if mode=='profiles_collision':profile.mkdir()
 if mode=='output_collision':outfile.write_text('sentinel unchanged\n')
 stdout=io.StringIO();stderr=io.StringIO();exc=None;ret=None;started=datetime.now(timezone.utc).isoformat();oldargv=sys.argv
 try:
  sys.argv=args
  with redirect_stdout(stdout),redirect_stderr(stderr):ret=module.main()
 except Exception as e:
  exc=type(e).__name__;stderr.write(traceback.format_exc())
 finally:sys.argv=oldargv
 ended=datetime.now(timezone.utc).isoformat();(root/'stdout.txt').write_text(stdout.getvalue());(root/'stderr.txt').write_text(stderr.getvalue())
 record=dict(name=name,script=str(script),script_sha256=sha(script),argv=args,mode=mode,started_utc=started,ended_utc=ended,return_value=ret,exception=exc,stub_calls=stub_events,temporary_paths=temporary,science_function_executed=False)
 save(root/'EXECUTION.json',record);runs.append(record)
 ck(name+':expected_exception',exc==expected_exception,dict(expected=expected_exception,actual=exc))
 if expected_exception is None:
  outer=json.loads(stdout.getvalue());restored=decode(outer)
  ck(name+':complete_stub_equality',restored==expected_units[0])
  ck(name+':stdout_output_exact',outfile.read_text()==stdout.getvalue())
  ck(name+':return_failure_propagation',bool(ret)==bool(expected_units[0]['failed']))
  ck(name+':captured_stdout_lossless',outer['unit_stdout']=='stub progress λ\ncomplete stub output\n')
  ck(name+':outer_inner_sha',outer['checker_sha256']==restored['checker_sha256']==sha(script))
  if mode=='temporary':ck(name+':temporary_cleanup',len(temporary)==1 and not Path(temporary[0]).exists())
  else:ck(name+':saved_profile_equality',json.loads((profile/'certificate/RESULTS.json').read_text())==restored)
  save(root/'EXPECTED_UNIT.json',expected_units[0])
 elif mode=='profiles_collision':ck(name+':no_stub_call',not stub_events)
 elif mode=='output_collision':ck(name+':existing_output_preserved',outfile.read_text()=='sentinel unchanged\n')
 return record

for name,mode,exc in [('persistent_success','persistent',None),('temporary_success','temporary',None),('failed_rows_preserved','failed_unit',None),('count_mismatch_rejected','return_mismatch','AssertionError'),('existing_profiles_rejected','profiles_collision','AssertionError'),('existing_output_rejected','output_collision','AssertionError'),('missing_profile_rejected','missing_profile','FileNotFoundError'),('malformed_profile_rejected','malformed_profile','JSONDecodeError')]:exercise(name,source,mode,exc)

# Actual altered wrapper source copies, with the scientific function replaced
# by the same stub before calling main. No producer science is executed.
text=source.read_text();changes=[('payload_length','uncompressed_bytes=len(raw)','uncompressed_bytes=len(raw)+1'),('payload_hash','sha256=hashlib.sha256(raw).hexdigest()','sha256="0"*64'),('payload_field_loss','raw=json.dumps(unit,sort_keys=True','raw=json.dumps({k:v for k,v in unit.items() if k!="noise_cases"},sort_keys=True')]
for name,before,after in changes:
 assert text.count(before)==1,(name,text.count(before));p=ROOT/(name+'.py');p.write_text(text.replace(before,after));(ROOT/(name+'.diff')).write_text(''.join(difflib.unified_diff(text.splitlines(True),p.read_text().splitlines(True),fromfile='original',tofile=name)))
 exercise('damage_'+name,p,'persistent','AssertionError')

outer=json.loads((ROOT/'persistent_success/outer.json').read_text())
for name in ['length','hash','data']:
 damaged=copy.deepcopy(outer)
 if name=='length':damaged['complete_unit_payload']['uncompressed_bytes']+=1
 elif name=='hash':damaged['complete_unit_payload']['sha256']='0'*64
 else:
  p=damaged['complete_unit_payload'];raw=zlib.decompress(base64.b64decode(p['data']));changed=bytearray(raw);changed[len(changed)//2]^=1;p['data']=base64.b64encode(zlib.compress(bytes(changed))).decode()
 save(ROOT/('tampered_'+name+'.json'),damaged);error=None
 try:decode(damaged)
 except Exception as e:error=type(e).__name__;(ROOT/('tampered_'+name+'.traceback.txt')).write_text(traceback.format_exc())
 ck('external_payload_tamper_rejected:'+name,error is not None,error)

result=dict(at=datetime.now(timezone.utc).isoformat(),scope='Independent wrapper-only actual executions with synthetic JSON stub. No original scientific function run, no physics/observations added.',passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,executions=runs,actual_wrapper_source_sha256=sha(source),actual_damaged_copies=3,external_payload_tampers=3)
save(HERE/'WRAPPER_RESULTS_v1.json',result);print(json.dumps(dict(passed=result['passed'],failed=result['failed'],failed_checks=[x for x in rows if not x['passed']],actual_wrapper_executions=len(runs),actual_damaged_copies=3,external_payload_tampers=3),indent=2));raise SystemExit(bool(result['failed']))
