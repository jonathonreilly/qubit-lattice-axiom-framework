"""Close source-version recovery and narrow profile-byte correspondence."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
HERE=Path(__file__).resolve().parent;PK=HERE.parent
B=json.loads((HERE/'SOURCE_BINDINGS_v1.json').read_text());WT=Path(B['worktree']);sources=B['sources']+json.loads((HERE/'ADDITIONAL_BINDINGS_v1.json').read_text())['sources'];lookup={r['original_path']:Path(r['snapshot_path']) for r in sources}
def snap(p):return lookup[str(p)]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def ck(n,b,d=None):checks.append(dict(name=n,passed=bool(b),detail=d))
def save(name,obj):p=HERE/name;assert not p.exists();p.write_text(json.dumps(obj,indent=2)+'\n')
pack=PK/'paired_gravity_certificate_packaging';orig=PK/'rolling_local_response/paired_gravity_certificate_v1';shared=PK/'claim_type_format_correspondence_v1'
oldprofile=snap(orig/'baseline_v1/RESULTS.json').read_bytes();newprofile=snap(pack/'profiles_v1/certificate/RESULTS.json').read_bytes();oldhash=sha(snap(orig/'check_certificate_v1.py'));newhash=sha(snap(pack/'staged/exponential_scalar_paired_gravity_certificate_check.py'))
ck('only_one_old_checker_identity_in_pretty_profile',oldprofile.count(oldhash.encode())==1)
ck('original_to_staged_full_profile_bytes_after_identity_only',oldprofile.replace(oldhash.encode(),newhash.encode())==newprofile)
dispositions=json.loads((HERE/'SOURCE_DISPOSITIONS_v1.json').read_text())['original_dispositions'];seen={(x['original_path'],x['original_sha256']) for x in dispositions}
historical=[]
science=snap(orig/'independent_v1/RECEIPT_v1.json');sr=json.loads(science.read_text())
for r in sr['source_bindings']:
 recovery=snap(Path(r['snapshot_path']));ck('original_blind_source_recovered:'+r['original_path'],sha(recovery)==r['sha256'])
 row=dict(original_path=r['original_path'],original_sha256=r['sha256'],disposition='Original blind-math source version reused by sealed receipt; exact recovery independently copied.',recovery=str(recovery),final_path=None,final_sha256=None)
 key=(row['original_path'],row['original_sha256']);historical.append(row)
 if key not in seen:dispositions.append(row);seen.add(key)
for r in json.loads(snap(shared/'SOURCE_BINDINGS_v1.json').read_text())['bindings']:
 recovery=snap(Path(r['recovery']));ck('shared_format_historical_recovery:'+r['original_path'],sha(recovery)==r['original_sha256']==r['recovery_sha256'])
 row=dict(original_path=r['original_path'],original_sha256=r['original_sha256'],disposition='Historical source version retained by shared format-only seal; recovery verified, no new science review of unrelated milestones.',recovery=str(recovery),final_path=None,final_sha256=None)
 key=(row['original_path'],row['original_sha256']);historical.append(row)
 if key not in seen:dispositions.append(row);seen.add(key)
for r in dispositions:
 ck('closed_disposition_recovery:'+r['original_path']+':'+r['original_sha256'],sha(Path(r['recovery']))==r['original_sha256'])

note_name='EXPONENTIAL_SCALAR_PAIRED_GRAVITY_CERTIFICATE_BOUNDED_THEOREM_NOTE_2026-10-14.md'
stage=pack/'staged'/note_name;formatted=pack/'formatted_v2'/note_name
future=[dict(final_path='docs/'+note_name,role='Self note; formatted stage successor to install',available_source=str(formatted),available_sha256=sha(snap(formatted)),present_live=(WT/'docs'/note_name).exists()),dict(final_path='docs/EXPONENTIAL_SCALAR_CALIBRATED_GRAVITY_TURNING_BOUNDED_THEOREM_NOTE_2026-10-14.md',role='Declared calibrated-response premise; format seal recovery only, no new scientific review in this unit',available_source=str(shared/'sources/calibrated_gravity_turning/INSTALL.md'),available_sha256=sha(snap(shared/'sources/calibrated_gravity_turning/INSTALL.md')),present_live=(WT/'docs/EXPONENTIAL_SCALAR_CALIBRATED_GRAVITY_TURNING_BOUNDED_THEOREM_NOTE_2026-10-14.md').exists())]
ck('both_future_declared_notes_remain_uninstalled',all(not r['present_live'] for r in future))
save('SOURCE_DISPOSITIONS_v2.json',dict(at=datetime.now(timezone.utc).isoformat(),scope='Complete version recovery for reviewed stage/science evidence and reused format metadata. No live delivery mapping or final canonical-cache identity is asserted.',original_dispositions=dispositions,historical_bindings=historical,prospective_declared_input_mapping=future))
save('CLOSURE_RESULTS_v1.json',dict(at=datetime.now(timezone.utc).isoformat(),passed=sum(r['passed'] for r in checks),failed=sum(not r['passed'] for r in checks),checks=checks,direct_source_pairs=len(sources),unique_version_dispositions=len(dispositions),historical_bindings=len(historical),stage_note_sha256=sha(snap(stage)),formatted_note_sha256=sha(snap(formatted)),runner_sha256=newhash,original_pretty_profile_sha256=hashlib.sha256(oldprofile).hexdigest(),staged_pretty_profile_sha256=hashlib.sha256(newprofile).hexdigest(),future_declared_inputs=future))
print(json.dumps(dict(passed=sum(r['passed'] for r in checks),failed=sum(not r['passed'] for r in checks),unique_version_dispositions=len(dispositions),historical_bindings=len(historical),stage_note_sha256=sha(snap(stage)),formatted_note_sha256=sha(snap(formatted)),runner_sha256=newhash,failed_checks=[r for r in checks if not r['passed']]),indent=2));raise SystemExit(any(not r['passed'] for r in checks))
