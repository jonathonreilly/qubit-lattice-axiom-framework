from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
HERE=Path(__file__).resolve().parent
PK=HERE.parent
WT=PK.parents[3]
assert WT.name=='New Axioms Lets Go',str(WT)
roots=[PK/'paired_gravity_certificate_packaging',PK/'rolling_local_response/paired_gravity_certificate_v1',PK/'claim_type_format_correspondence_v1']
extra=[PK/'rolling_local_response/TWO_EPOCH_DERIVATION_v1.md',PK/'rolling_local_response/DERIVATION_v2.md',WT/'docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md']
files=sorted(set(extra+[p for root in roots for p in root.rglob('*') if p.is_file()]))
rows=[]
for p in files:
    assert not p.is_symlink();raw=p.read_bytes();dest=HERE/'sources'/p.relative_to(WT)
    assert not dest.exists();dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
    assert p.read_bytes()==raw==dest.read_bytes()
    rows.append(dict(original_path=str(p),snapshot_path=str(dest),relative_path=str(p.relative_to(WT)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),disposition='Full preserved source/evidence snapshot for staged correspondence; science histories reused without execution.'))
out=HERE/'SOURCE_BINDINGS_v1.json';assert not out.exists();out.write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),worktree=str(WT),sources=rows),indent=2)+'\n')
print(json.dumps(dict(source_files=len(rows),total_bytes=sum(x['bytes'] for x in rows)),indent=2))
