from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
HERE=Path(__file__).resolve().parent
prefix=HERE/sys.argv[1];assert prefix.resolve().is_relative_to(HERE)
argv=sys.argv[2:]
files=[Path(p) for p in argv if Path(p).is_file()]
for name in ['SOURCE_BINDINGS_v1.json','ADDITIONAL_BINDINGS_v1.json']:
 for r in json.loads((HERE/name).read_text())['sources']:files.extend([Path(r['original_path']),Path(r['snapshot_path'])])
def ident(p):return dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
before=[ident(p) for p in files];started=datetime.now(timezone.utc).isoformat();r=subprocess.run(argv,cwd=HERE,capture_output=True)
prefix.parent.mkdir(parents=True,exist_ok=True)
for ext,raw in [('.stdout.txt',r.stdout),('.stderr.txt',r.stderr)]:
 p=Path(str(prefix)+ext);assert not p.exists();p.write_bytes(raw)
record=dict(argv=argv,cwd=str(HERE),started_utc=started,ended_utc=datetime.now(timezone.utc).isoformat(),returncode=r.returncode,actual_inputs=before,inputs_unchanged=before==[ident(p) for p in files])
p=Path(str(prefix)+'.EXECUTION.json');assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(returncode=r.returncode,inputs_unchanged=record['inputs_unchanged']),indent=2));print(r.stdout.decode());print(r.stderr.decode(),file=sys.stderr)
raise SystemExit(r.returncode)
