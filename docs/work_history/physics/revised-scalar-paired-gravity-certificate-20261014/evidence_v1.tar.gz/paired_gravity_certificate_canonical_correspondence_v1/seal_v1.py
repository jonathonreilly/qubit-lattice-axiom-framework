"""Seal staged correspondence only; no science, parent-source or runtime writes."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
HERE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def identity(p):return dict(path=str(p),relative_path=str(p.relative_to(HERE)),bytes=p.stat().st_size,sha256=sha(p))
for name in ['MANIFEST_v1.json','RECEIPT_v1.json','FINAL_VERIFICATION_v1.json']:assert not (HERE/name).exists(),name
sources=json.loads((HERE/'SOURCE_BINDINGS_v1.json').read_text())['sources']+json.loads((HERE/'ADDITIONAL_BINDINGS_v1.json').read_text())['sources']
assert len(sources)==188
for r in sources:
 for k in ['original_path','snapshot_path']:
  p=Path(r[k]);assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],str(p)
cor=json.loads((HERE/'CORRESPONDENCE_RESULTS_v1.json').read_text());ser=json.loads((HERE/'SERIALIZATION_FOLLOWUP_RESULTS_v1.json').read_text());wrap=json.loads((HERE/'WRAPPER_RESULTS_v1.json').read_text());closure=json.loads((HERE/'CLOSURE_RESULTS_v1.json').read_text())
assert (cor['passed'],cor['failed'])==(417,1)
assert [r['name'] for r in cor['checks'] if not r['passed']]==['profile_pretty_bytes_equal_saved']
assert (ser['passed'],ser['failed'])==(8,0) and ser['prior_result_sha256']==sha(HERE/'CORRESPONDENCE_RESULTS_v1.json')
assert (wrap['passed'],wrap['failed'])==(34,0) and len(wrap['executions'])==11
assert (closure['passed'],closure['failed'])==(264,0)
for name,expected in [('correspondence_run_v1',1),('serialization_followup_run_v1',0),('wrapper_run_v1',0),('closure_run_v1',0)]:
 r=json.loads((HERE/(name+'.EXECUTION.json')).read_text());assert r['returncode']==expected and r['inputs_unchanged']
 for x in r['actual_inputs']:
  p=Path(x['path']);assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256'],str(p)
dispositions=json.loads((HERE/'SOURCE_DISPOSITIONS_v2.json').read_text())['original_dispositions'];assert len(dispositions)==220
for r in dispositions:assert sha(Path(r['recovery']))==r['original_sha256']
for r in wrap['executions']:
 assert sha(Path(r['script']))==r['script_sha256'] and r['science_function_executed'] is False
for p in HERE.rglob('*'):assert not p.is_symlink(),str(p)
now=datetime.now(timezone.utc).isoformat()
final=dict(at=now,scope='Final source/version/execution identity only; no science rerun.',source_pair_count=188,version_dispositions=220,all_original_and_snapshot_bytes_unchanged=True,all_version_recoveries_exact=True,preserved_initial_correspondence=[417,1],affected_serialization_followup=[8,0],wrapper_only=[34,0],source_closure=[264,0],unexpected_unresolved_failures=[],prior_reviewer_failure='Only the preserved pretty-serialization key-order expectation; narrow correction verified without changing prior results.',stage_note_sha256=closure['stage_note_sha256'],formatted_note_sha256=closure['formatted_note_sha256'],runner_sha256=closure['runner_sha256'],seal_argv=[sys.executable,*sys.argv],live_delivery_pending=True)
(HERE/'FINAL_VERIFICATION_v1.json').write_text(json.dumps(final,indent=2)+'\n')
artifacts=[identity(p) for p in sorted(HERE.rglob('*')) if p.is_file()]
manifest=dict(created_utc=now,root=str(HERE),scope='Frozen staged canonical source/evidence correspondence. Manifest excludes itself and receipt to avoid circular hashes.',artifact_count=len(artifacts),artifacts=artifacts)
mp=HERE/'MANIFEST_v1.json';mp.write_text(json.dumps(manifest,indent=2)+'\n')
receipt=dict(sealed_utc=now,root=str(HERE),scope='Milestone 23 paired-gravity certificate staged canonical correspondence only.',disposition='Original/formatted hand port, entire scientific AST and full scientific output preserved. No scientific source correction requested. Live install/cache/archive/delivery not yet reviewed.',report=identity(HERE/'REPORT_v1.md'),manifest=identity(mp),source_bindings=[identity(HERE/'SOURCE_BINDINGS_v1.json'),identity(HERE/'ADDITIONAL_BINDINGS_v1.json')],source_pair_count=188,artifact_count=len(artifacts),original_dispositions=identity(HERE/'SOURCE_DISPOSITIONS_v2.json'),original_dispositions_json_pointer='/original_dispositions',source_version_count=220,final_sources=dict(original_stage_note_sha256=closure['stage_note_sha256'],formatted_stage_note_sha256=closure['formatted_note_sha256'],staged_runner_sha256=closure['runner_sha256']),reused_science=cor['facts']['reused_independent_v1'],reused_format=cor['facts']['reused_claim_type_format_correspondence_v1'],checks=dict(original_correspondence=[417,1],affected_serialization_followup=[8,0],wrapper_only=[34,0],source_recovery_closure=[264,0]),new_science_execution=False,producer_evidence='Preserved original 576/0 and separate staged 576/0 were inspected, not rerun; original four and staged three actual damages are kept with their original identities.',new_wrapper_execution='Eleven actual staged-main executions with a synthetic scientific-entry stub. Three actual damaged wrapper source copies and three external tampered payloads rejected. No producer scientific function executed.',failure_history='Initial reviewer pretty-byte assertion failed because compact sort_keys JSON changes object insertion order. The original 417/1 and full streams remain; the separate 8/0 follow-up resolves only that assertion. All expected wrapper exceptions/tracebacks and prior source failure histories remain preserved.',limitations=['Staged source versions only; no live cache, archive or delivery map exists for this unit at seal.','Paired and calibrated-turning declared note paths are absent live; complete runtime input closure must be verified after installation.','Complete JSON data are preserved; original pretty whitespace/object-key order are not the compact payload representation.','Fixed synthetic checker helpers are not promoted to a validated arbitrary-input measurement API.','No real matched measurements, observational fit, unique action, absolute scale, initial-state or physical-history inference.'],same_session_confirmation='All 188 direct live/snapshot pairs and 220 recovered versions were verified unchanged before this seal.',seal_policy='Immutable after sealing; subsequent live-cache/delivery work requires a new unit and must preserve this one.')
rp=HERE/'RECEIPT_v1.json';rp.write_text(json.dumps(receipt,indent=2)+'\n')
for r in artifacts:
 p=Path(r['path']);assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
for r in sources:assert sha(Path(r['original_path']))==sha(Path(r['snapshot_path']))==r['sha256']
print(json.dumps(dict(sealed=True,artifact_count=len(artifacts),source_pair_count=188,source_version_count=220,report=identity(HERE/'REPORT_v1.md'),manifest=identity(mp),receipt=identity(rp)),indent=2))
