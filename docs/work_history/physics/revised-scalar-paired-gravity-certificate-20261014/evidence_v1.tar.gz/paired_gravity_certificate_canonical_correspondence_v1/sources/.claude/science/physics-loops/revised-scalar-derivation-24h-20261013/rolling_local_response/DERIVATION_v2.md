# Local force and lensing on a rolling scalar background

Direct author /root. Hand derivation frozen before the associated checker.
The observation-motivated question is which gravity measurement should
normalize a cosmological expansion history. The earlier radiation diagnostic
used a specified hypothetical vacuum dynamical readout. This block derives
a leading local response on a smooth homogeneous rolling background, then
asks whether the resulting force and lensing measurements identify k.

The supplied action is the same complete action as the campaign: Q=Q0(1+k),
Einstein gravity Q R/2, scalar kinetic -Q K_AB partial(phi^A)partial(phi^B),
potential -2Q Hv^2 U, and matter universally coupled to g_J=C g_E.
The scalars, K,U,C, k,nu and Q0,Hv remain inputs. The new calculation does
not infer a measured environment, an absolute scale or the action itself.

## Explicit local regime

Choose one smooth finite point of a homogeneous classical solution in the
positive-metric chart, with fixed 0<k<1/3. Consider a weak, slowly moving,
weakly self-gravitating nonrelativistic source with independently known
physical rest mass. Its scalar charge is the universal weak-source charge;
compact-body sensitivities and nonlinear screening are outside this regime.
Take spatial wavelengths short compared with the curvature and coefficient
variation scales, and short compared with all relevant scalar Compton scales.
Equivalently the spatial principal operator must dominate the scalar mass,
turn-rate, background time derivative and gravitational constraint corrections.
Source evolution is slow compared with propagation across that wavelength.

These are explicit scale-separation conditions, not consequences of the
cosmological fixed point. Their applicability at an actual experimental
distance remains to be checked. At each fixed regular point they define a
formal short-distance limit; no uniform estimate as k approaches a boundary
or as a history becomes singular is claimed. A homogeneous perturbation or a
finite-range laboratory experiment is not automatically in this limit.

## Derivation from the principal field equations

Let b_A=partial_A log sqrt(C), and let quantities below be evaluated on the
local background. Freezing the positive K at leading spatial order is
equivalent to using its local orthonormal scalar coordinates. The leading
Einstein and scalar equations for the source perturbations are

    Laplacian_E Phi_E=rho_E/(2Q), Psi_E=Phi_E,
    K_AB Laplacian_E delta phi^B=b_A rho_E/(2Q).

The scalar normalization follows directly by variation: the exact scalar
equation has source -b^A T_E/(2Q), and T_E=-rho_E at this order. Thus
delta phi^A=b^A Phi_E, up to free homogeneous solutions which are excluded
by the local sourced/decaying boundary response. The scalar contribution to
the physical conformal perturbation is b_A delta phi^A=g Phi_E, where

    g=b_A K^{AB} b_B.

The physical potentials are Phi_J=Phi_E+b_A delta phi^A and
Psi_J=Phi_E-b_A delta phi^A. The constant background rescaling must also
transform mass and radius: M_E=sqrt(C)M_J, r_J=sqrt(C)r_E. Therefore

    Phi_J= -[C(1+g)/(8pi Q)] M_J/r_J,
    Psi_J= -[C(1-g)/(8pi Q)] M_J/r_J,
    G_dyn=C(1+g)/(8pi Q),
    G_lens=C/(8pi Q), Psi_J/Phi_J=(1-g)/(1+g).       (1)

Here G_lens means the coefficient in (Phi_J+Psi_J)/2 for a known source
mass. It is not a separately fit lens mass. The potential ratio is the
leading local limit under these hypotheses, not a completed timing model
or a finite-range PPN data analysis. The source response of the rolling
fields, including mixing and masses, first requires further terms when
the stated principal-operator limit does not hold.

The constant-background limit and normalization agree with equation(4.12a)
of Damour and Esposito-Farese, Tensor-multi-scalar theories of gravitation,
the author preprint at
https://repo-archives.ihes.fr/FONDS_IHES/I_Prepublications/DAMOUR/1988-1993/P_91_93/P_91_93_web.pdf
(PDF page22). Their A^2=C, scalar metric gamma_AB=K_AB and
G_star=1/(8pi Q). This is a source cross-check of the weak-field normalization;
it does not establish the rolling-background scale separation for this model.
The primary PDF was retrieved with curl after the web fetch timed out; both
outcomes and extracted source pages are preserved separately.

## A model-specific exact bound in this local limit

For the supplied action, a=(1-k)(1+3k)/4, s=(1+k)/[k(1-3k)],
E=exp(2alpha u), F=1+sE and J=1+(1-3a)sE. Only b_u=alpha/F is nonzero,
and K_uu=J/F^2. Thus g=a/J. Since a<1/3 and E>0, 0<g<a<1/3.
Eliminating E using C=(1+s)E/F gives the exact algebraic identity

    g=[4a-(1+k)C]/[4-3(1+k)C].                       (2)

The physical chart has 0<C<4a/(1+k), and the denominator in(2) is
strictly positive. Normalize to the same hypothetical C=1 vacuum dynamical
reference G_vac=1/(8pi Q0), and define

    Sigma=G_lens/G_vac=C/(1+k),
    mu=G_dyn/G_vac=C(1+g)/(1+k).

The action relation 4a=1+2k-3k^2 makes

    1-mu=4(C-1)^2/[4-3(1+k)C] >=0.                 (3)

Consequently 0<mu<=1 in this leading local response; equality holds precisely
at C=1, equivalently u=0. A non-vacuum field can change its coupling norm and
lensing response at first order while the dynamical strength changes only
quadratically around C=1. The first time derivative of dynamical gravity can therefore vanish at an
instant with C=1 even when C is moving. A finite-precision near-constant
measurement alone need not establish a fixed coupled scalar u. Exact
constancy of this leading G_dyn on a connected time interval at fixed k
does force continuous C, and hence u, to be constant: each value of mu has
at most two C roots, so a continuous history within one level set is a
single point. This does not force the other scalar fields x,y to be fixed.
The statements use a known common reference normalization and local regime.

For the alternative radiation point C_x=(1-k)/(1+k), equation(3) gives

    mu_x=1-16k^2/[(1+k)^2(1+3k)],
    Sigma_x=(1-k)/(1+k)^2,
    g_x=3k(1-k)/(1+3k).

For the limiting dust point u=0,C=1, one has mu_m=1, Sigma_m=1/(1+k),
and g_m=k. These statements derive the leading point-source local response
in the new regime, not a full density-growth, finite-body, range or nonlinear
screening prediction. The revised radiation expansion relative to a local
same-epoch dynamical reference would be R_H/mu_x; it differs from R_H defined
with G_vac. Its physical applicability still requires the source conditions.

## Even two ideal readouts can leave a discrete ambiguity

If Sigma and mu are both known relative to the stipulated G_vac, then
g=mu/Sigma-1 follows from(1). Let v=1+k and define

    Aobs=3+(1-3g)Sigma.

Eliminating C=Sigma v from(2) gives

    Aobs v^2-8v+4(1+g)=0,
    v=[4 +/- 2sqrt((1-3g)(1-mu))]/Aobs.             (4)

At mu=1 the inverse roots coincide: with Sigma known, the exact solution
is uniquely C=1 and k=1/Sigma-1, when admissible. The differential inverse
is singular there, but algebraic uniqueness at that exact readout remains.
Away from that maximum, the two roots
need not both satisfy 0<k<1/3 and E>0; admissibility must be checked, never
assumed. But there can be two admissible states. As a frozen mathematical
control, take k=1/20,C=49/50, compute Sigma,g,mu by(2)-(3), then compute the
other quadratic root and C_other=Sigma(1+k_other). Check both charts and
their identical force/lensing readouts exactly. These are synthetic values,
not measurements. Requiring the radiation branch further restricts
k<3-2sqrt(2), which must also be checked for this example.

Thus deriving the forward force law need not derive a unique model coupling
or environment from two measurements. An independent clock/environment
condition, a history or another response observable may break the ambiguity,
but supplying one as a selector would not count as deriving it. With an
unknown reference G_vac or unknown source mass, more degeneracies remain.

The exact identities and example will be computed next. This hand source
does not count an unexecuted test, independent check or actual measurement
as completed. It advances a conditional forward bridge while preserving
the real observational and initial-state assumptions.
