# A finite-epoch consistency test without an inserted scalar selector

Direct author /root. Hand derivation frozen before the checker. The preceding
drift inverse motivates a more direct observation relation: avoid differentiating
small noisy changes, and use two distinct epochs to calibrate, then a third to
test. This is a proposed conditional measurement protocol. No measurements have
been obtained or retrospectively declared independent.

Retain the supplied action and every local weak-body/principal-response
hypothesis of DERIVATION_v2.md, including their validity throughout the interval.
At each epoch obtain the same-source force and lensing coefficients G_D,G_L,
with source-mass evolution independently controlled. Define

    g=G_D/G_L-1, Y=1/(1-3g), a=(1-k)(1+3k)/4.

The exact forward relation g=[4a-(1+k)C]/[4-3(1+k)C] implies

    Y=B0+B1 G_L,
    B0=4/(1-3k)^2,
    B1=-24 pi Q (1+k)/(1-3k)^2.                     (1)

This follows by substitution of C=8 pi Q G_L. The intercept depends only
on k; an unknown constant multiplicative calibration of every G_L rescales
the slope but leaves the intercept unchanged. A common unknown source mass
therefore cancels only when its normalization is stable or independently
corrected over the interval. An arbitrary time-dependent calibration does
not cancel. Universal weak-body scalar charge is still a premise.

For two epochs with G_L2 != G_L1, write r=G_L2/G_L1. Then

    B0=(r Y1-Y2)/(r-1),
    k=(1-2/sqrt(B0))/3.                              (2)

B0>4 is necessary and sufficient for the reconstructed 0<k<1/3 at this
step; the individual states still must satisfy 0<g_i<a and E_i>0. In
particular the slope must be negative: increasing G_L decreases Y and g.
Once k is reconstructed, the conformal field values follow from

    C_i=4(1-Y_i/B0)/[3(1+k)],
    E_i=(a-g_i)/[s g_i(1-3a)], s=(1+k)/[k(1-3k)].    (3)

These identities infer a state inside the chosen action family instead of
stipulating one. They neither derive the family nor a physically realized
history. Q0 remains unmeasured without an absolute gravity calibration.
Other actions can share relation(1), so passing it cannot establish a unique
potential or TOE. nu,Hv and finite-range validity are not inferred here.

A third epoch, excluded from the two-point calibration, must obey

    Y3=Y1+(Y2-Y1)(G_L3-G_L1)/(G_L2-G_L1).            (4)

This is the prospective test, together with the physical-domain and scale
requirements. Do not fit all three and call the third independent. No third
epoch is presently a real held-out dataset. The following exact synthetic
control is exposed development evidence only: choose fixed k=1/20 and
C1=49/50,C2=1,C3=51/50, use the original E-dependent K,C functions to
construct three g_i,G_Li, recover k from the first two, then check(4) at the
third. A deliberate g3 shift of1/1000 must violate (4); it is a generated
data-damage control, not a measured anomaly. Set Q0's common normalization
to an arbitrary fixed synthetic unit; varying it must leave inferred k fixed.

## Limits and connection to the drift inverse

If G_L1=G_L2, this construction is singular; exact constant-C radiation
or dust branches do not supply two independent readings. For nearby epochs,
small differences still amplify errors despite avoiding numerical derivatives:

    dB0/dY1=r/(r-1), dB0/dY2=-1/(r-1),
    dB0/dr=(Y2-Y1)/(r-1)^2.

This is a structural conditioning statement, not a measurement forecast.
As x=ln G_L varies smoothly, (1) is equivalently the differential identity

    g_xx-g_x+6 g_x^2/(1-3g)=0.                       (5)

The drift inverse reconstructs B0 from the first jet of the same curve;
the finite-epoch construction reconstructs it from two distinct points.
Both leave the actual availability, precision, source/environment matching
and finite-wavelength control of those observations open. They do not supply
an assumed initial state or count an extra observational input as a first-
principles derivation.
