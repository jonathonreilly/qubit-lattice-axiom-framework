# Independent hand derivation before computation

The full supplied action gives b_u=alpha/F and K_uu=J/F^2, hence q=|d ln A|_K^2=a/J. I reuse the explicitly conditional leading common-source response G=C(1+q)/(8 pi Q), gamma=(1-q)/(1+q), and G_lens=C/(8 pi Q). This is a principal-operator weak-body premise, not a finite-body or experimental derivation in this check.

Let d=1-3a>0. Then 1-3q=dF/J and a-q=a d s E/J. Direct substitution therefore gives H=G(2gamma-1)=C(1-3q)/(8 pi Q)=P(a-q), with P=(1+s)/(8 pi Q a s)=4/[(8 pi Q)(1+k)]. The same hypothetical vacuum force scale is Gref=(1+k)/(8 pi Q), so P=4Gref/(1+k)^2. This derives the affine relation from the original E-dependent action functions without using the producer implementation.

For two different q values, D=P(q2-q1) and N=P a(q2-q1). Thus a=N/D and P=D/(q2-q1). Since da/dk=(1-3k)/2>0, the interior physical chart maps 0<k<1/3 to 1/4<a<1/3. Solving its quadratic gives k=(1-2sqrt(1-3a))/3, while the plus branch is outside the chart. dk/da=1/sqrt(1-3a), so the inverse becomes ill-conditioned at the excluded upper endpoint. Exact interval mapping is preferable to a linearized k error.

Writing Y=1/(1-3q) and G_lens=HY gives G_lens=P[(a-1/3)Y+1/3], equivalent to Y=B0+B1 G_lens with B0=1/(1-3a)=4/(1-3k)^2 and B1=-3/[P(1-3a)]. The old and new reconstructions contain the same two-point information. Their distinct-coordinate denominator failures describe the same constant-state degeneracy within the admissible family. The force G alone can coincide at two distinct q values; that does not make D vanish.

For measured gamma write r=1+gammahat>e_gamma and delta=gamma-gammahat. The exact error is q-qhat=-2delta/[r(r+delta)]. Its maximum absolute value over |delta|<=e_gamma occurs at delta=-e_gamma, yielding exactly the displayed e_q. No physical small-error expansion is involved.

For the product H=G(2gamma-1), H-Hhat=(2gammahat-1)deltaG+2Ghat deltagamma+2deltaG deltagamma. The three absolute-value terms give e_H. When measured G and 2gammahat-1 are positive and both errors are positive, the bound is saturated; omitting the finite cross term then fails even within a positive, admissible local-state range.

Likewise N-Nhat is the sum of qhat2 deltaH1+Hhat1 deltaq2+deltaq2 deltaH1 minus the three corresponding epoch-1/epoch-2 terms. Product cross terms remain in the full triangle bound. No independence assumption is used, and the q and H errors may be correlated. The resulting bound is conservative because it discards those correlations; no sharp global confidence region is asserted.

The exact ratio identity is a-ahat=[(N-Nhat)-ahat(D-Dhat)]/D. If |Dhat|>e_D, the true denominator obeys |D|>=|Dhat|-e_D>0. This gives the stated measured-input e_a without any unknown true a on the right. If the entire a interval lies in the open physical interval, monotonicity maps it to the k interval. The q field checks and common sign of separately separated D and q2-q1 intervals are additional sufficient gates, not consequences of the ratio formula alone. Failed gates are inconclusive. Equality in the denominator gate is inadequate.

For the third-epoch determinant, expanding each of the two difference-products gives three terms: measured first factor times second error, measured second factor times first error, and their error product. The e_Z formula follows directly by the triangle inequality even though the epoch-1 errors are shared. If the conditional law holds, Z=0, so |Zhat|>e_Z contradicts that law together with its claimed error envelopes. Non-rejection proves neither physical validity nor a unique action.

Under a common positive scale lambda, Ghat and e_G scale together. Hhat,e_H,Dhat,Nhat,e_D,e_N,P,Zhat,e_Z scale with lambda; qhat,e_q,ahat,e_a and k intervals do not. Different epoch scales do not share this invariance. In fact, with fixed q_i below both a and a', choosing lambda_i=(a'-q_i)/(a-q_i)>0 makes a perfectly straight alternative line with the wrong a' and zero third residual. This exposes why a stable or independently corrected common calibration is a necessary premise, not an inferred result.

The proposed independent computations use rational arithmetic for finite error inequalities and separate exact symbolic action identities. They are synthetic controls, not observations. The hand proof does not establish a shared physical source, total calibrated mass, range hierarchy, time-constant nuisance normalization, realized scalar history or deterministic error budgets from reported statistical standard deviations.
