from pathlib import Path
from datetime import datetime,timezone
import difflib,hashlib,json
HERE=Path(__file__).resolve().parent
source=(HERE/'check_independent_v1.py').read_text();root=HERE/'damages_v1';root.mkdir(exist_ok=False)
changes=[('half_q_error','Q_ERROR_FACTOR=2','Q_ERROR_FACTOR=1','q_bound_sharp_negative_corner'),('wrong_H_transform','H=G*(2*gamma+H_OFFSET)','H=G*(2*gamma-H_OFFSET)','paired_H_from_action'),('wrong_k_root','K_ROOT_SIGN=-1','K_ROOT_SIGN=1','physical_k_root'),('omit_H_cross','H_CROSS_FACTOR=2','H_CROSS_FACTOR=0','H_bound_sharp_positive_corner'),('weak_D_gate','STRICT_DENOMINATOR=True','STRICT_DENOMINATOR=False','strict_denominator_gate:1/10:1/10'),('omit_Z_cross','Z_CROSS_FACTOR=1','Z_CROSS_FACTOR=0','residual_finite_cross_sharp')]
records=[]
for name,before,after,witness in changes:
    assert source.count(before)==1,(name,source.count(before))
    changed=source.replace(before,after);path=HERE/('damaged_'+name+'_v1.py');path.write_text(changed)
    d=root/name;d.mkdir();(d/'CHANGE.diff').write_text(''.join(difflib.unified_diff(source.splitlines(True),changed.splitlines(True),fromfile='original_independent',tofile='actual_altered')))
    records.append(dict(name=name,source=str(path),sha256=hashlib.sha256(changed.encode()).hexdigest(),before=before,after=after,required_failed_witness=witness,mode='--focused: exact proof/counterexample controls plus two corners per fixture, not the full 192-profile baseline.'))
(root/'PROTOCOL_v1.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),original_sha256=hashlib.sha256(source.encode()).hexdigest(),actual_changes=records),indent=2)+'\n')
print(json.dumps(dict(actual_changes=len(records))))
