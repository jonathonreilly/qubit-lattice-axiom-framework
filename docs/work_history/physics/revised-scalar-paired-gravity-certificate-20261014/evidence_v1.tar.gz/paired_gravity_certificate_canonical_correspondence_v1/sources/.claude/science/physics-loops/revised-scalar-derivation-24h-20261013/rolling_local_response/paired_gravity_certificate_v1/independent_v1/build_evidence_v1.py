"""Produce the independent report from preserved controls; no science rerun."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime, timezone
import hashlib,json

HERE=Path(__file__).resolve().parent
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
put=lambda name,data:(HERE/name).write_text(json.dumps(data,indent=2)+'\n')
def fresh(name): assert not (HERE/name).exists(),name
checks=[]
def ck(name,condition): checks.append(dict(name=name,passed=bool(condition)))
sources=json.loads((HERE/'SOURCE_BINDINGS_v1.json').read_text())['sources']
for r in sources:
    for key in ['original_path','snapshot_path']:
        p=Path(r[key]);ck('source:'+key+':'+p.name,p.stat().st_size==r['bytes'] and digest(p)==r['sha256'])
base=json.loads((HERE/'baseline_v1/RESULTS_v1.json').read_text())
profiles=json.loads((HERE/'baseline_v1/FULL_PROFILES_v1.json').read_text())
ck('baseline_counts',base['passed']==2772 and base['failed']==0 and len(base['checks'])==2772)
ck('baseline_profile_recovery',base['profiles']==profiles and len(profiles)==192)
ck('baseline_checker',base['checker_sha256']==digest(HERE/'check_independent_v1.py'))
supp=json.loads((HERE/'THIRD_DOMAIN_RESULTS_v1.json').read_text())
ck('third_domain_counts',supp['passed']==1155 and supp['failed']==0 and len(supp['checks'])==1155)
ck('third_domain_profile_input',supp['profile_input_sha256']==digest(HERE/'baseline_v1/FULL_PROFILES_v1.json'))
ck('third_domain_checker',supp['checker_sha256']==digest(HERE/'check_third_domain_v1.py'))
damage_protocol=json.loads((HERE/'damages_v1/PROTOCOL_v1.json').read_text())
ck('damage_original_binding',damage_protocol['original_sha256']==digest(HERE/'check_independent_v1.py'))
damage_rows=[]
expected={'half_q_error':(149,19),'wrong_H_transform':(167,1),'wrong_k_root':(160,8),'omit_H_cross':(158,10),'weak_D_gate':(164,4),'omit_Z_cross':(167,1)}
execution_prefixes=['baseline_v1_run','third_domain_v1_run']
original=(HERE/'check_independent_v1.py').read_text()
for d in damage_protocol['actual_changes']:
    name=d['name'];script=Path(d['source']);r=json.loads((HERE/f'damages_v1/{name}/execution/RESULTS_v1.json').read_text());failed=[x['name'] for x in r['checks'] if not x['passed']]
    ck('actual_single_damage:'+name,original.count(d['before'])==1 and original.replace(d['before'],d['after'])==script.read_text())
    ck('damage_source_hash:'+name,digest(script)==d['sha256']==r['checker_sha256'])
    ck('damage_expected_counts:'+name,(r['passed'],r['failed'])==expected[name] and len(r['checks'])==168)
    ck('damage_required_witness:'+name,d['required_failed_witness'] in failed)
    ck('damage_full_profiles:'+name,json.loads((HERE/f'damages_v1/{name}/execution/FULL_PROFILES_v1.json').read_text())==r['profiles'] and len(r['profiles'])==6)
    prefix=f'damages_v1/{name}/run';execution_prefixes.append(prefix)
    damage_rows.append(dict(name=name,passed=r['passed'],failed=r['failed'],actual_exit_code=1,source=str(script),source_sha256=digest(script),required_failed_witness=d['required_failed_witness'],failed_checks=failed,result_path=f'damages_v1/{name}/execution/RESULTS_v1.json',result_sha256=digest(HERE/f'damages_v1/{name}/execution/RESULTS_v1.json'),execution_path=prefix+'.EXECUTION.json',scope='Focused exact witnesses plus six complete finite-error profiles; not a full baseline rerun.'))
for prefix in execution_prefixes:
    execution=json.loads((HERE/(prefix+'.EXECUTION.json')).read_text())
    expect=1 if prefix.startswith('damages_v1/') else 0
    ck('actual_exit:'+prefix,execution['exit_code']==expect and execution['inputs_unchanged'])
    for i in execution['actual_inputs']:
        p=Path(i['path']);ck('execution_input:'+prefix+':'+p.name,p.stat().st_size==i['bytes'] and digest(p)==i['sha256'])
    ck('stderr_preserved_empty:'+prefix,(HERE/(prefix+'.stderr.txt')).read_bytes()==b'')
    stdout=json.loads((HERE/(prefix+'.stdout.txt')).read_text());ck('raw_stdout_counts:'+prefix,stdout['failed']>0 if expect else stdout['failed']==0)

statistics={}
for i in range(3):
    ps=[p for p in profiles if p['case']==i]
    statistics[str(i)]=dict(k=ps[0]['true']['k'],a=ps[0]['true']['a'],eight_pi_Q=ps[0]['true']['Q8'],profiles=len(ps),ea_min=str(min(F(p['certificate']['ea']) for p in ps)),ea_max=str(max(F(p['certificate']['ea']) for p in ps)),max_actual_a_error_over_bound=float(max(abs(F(p['true']['a'])-F(p['certificate']['ahat']))/F(p['certificate']['ea']) for p in ps)),max_true_third_residual_over_bound=float(max(abs(F(p['third_residual']))/F(p['third_error_bound']) for p in ps)),min_damaged_third_residual_over_bound=float(min(abs(F(p['damaged_third_residual']))/F(p['damaged_third_bound']) for p in ps)))
for n in ['DAMAGE_SUMMARY_v1.json','RUN_SUMMARY_v1.json','PRESEAL_VERIFICATION_v1.json','REPORT_v1.md']:fresh(n)
put('DAMAGE_SUMMARY_v1.json',dict(at=datetime.now(timezone.utc).isoformat(),damages=damage_rows,unexpected_failures=[],scope='All six actual deliberate altered programs rejected for intended mathematical witnesses; sources/diffs/raw streams retained.'))
put('RUN_SUMMARY_v1.json',dict(at=datetime.now(timezone.utc).isoformat(),independent_baseline=dict(passed=2772,failed=0,profiles=192),separate_domain_followup=dict(passed=1155,failed=0,scope='Saved-profile domain coverage and exact counterexample, no baseline rerun.'),profile_statistics=statistics,no_producer_code_or_results_read=True,no_observations=True,unexpected_failures=[]))
put('PRESEAL_VERIFICATION_v1.json',dict(at=datetime.now(timezone.utc).isoformat(),scope='Artifact/source/execution correspondence only, not new science counts.',passed=sum(r['passed'] for r in checks),failed=sum(not r['passed'] for r in checks),checks=checks))
assert all(r['passed'] for r in checks)

source_lines='\n'.join('- '+Path(r['original_path']).name+' — `'+r['sha256']+'` ('+str(r['bytes'])+' bytes); exact live and snapshot paths in SOURCE_BINDINGS_v1.json.' for r in sources)
damage_lines='\n'.join('- '+r['name']+': '+str(r['passed'])+' passed / '+str(r['failed'])+' failed, actual exit 1; required witness `'+r['required_failed_witness']+'`.' for r in damage_rows)
stat_lines='\n'.join('- k='+r['k']+': maximum |a−ahat|/ea '+format(r['max_actual_a_error_over_bound'],'.8g')+'; maximum undamaged |Zhat|/eZ '+format(r['max_true_third_residual_over_bound'],'.8g')+'; minimum deliberately shifted-third |Zhat|/eZ '+format(r['min_damaged_third_residual_over_bound'],'.8g')+'.' for r in statistics.values())
report='''# Focused independent paired-gravity certificate check

The supplied finite-error certificate is mathematically consistent under its stated conditional local-response, common-source, fixed-parameter and deterministic-error premises. No source correction was required. This is an independent focused mathematical check, not a formal audit, an observed gravity calibration, an action-selection result or a physical history calculation. Scientific authorship remains with /root.

## Inputs, independence and execution

I completely read the new hand derivation and frozen protocol, the earlier two-epoch hand derivation, the corrected rolling-response hand source and the supplied complete action. I did not read, import, run or inspect producer checker code, results, profiles, execution records or implementation metadata for this route. The parent protocol was visible, so the independent fixtures deliberately use other k values, field ratios, normalizations, error sizes, calibration factors and third-point damage. The hand derivation and independent protocol were saved before implementing or executing the independent checker.

SOURCE_BINDINGS_v1.json binds five complete source snapshots to their live originals:

'''+source_lines+'''

The original source versions remained unchanged throughout every actual execution and at final verification. All outputs are within this independent_v1 directory. No parent science, Git, runtime, locks, settings or prior sealed evidence was modified. The supplied action/readout is reused as a conditional premise; this check does not claim a fresh derivation of full finite-body response or source/environment applicability.

## Independent mathematical reconstruction

The action gives K_uu=J/F² and b_u=alpha/F, so q=b K^-1 b=a/J. Let d=1−3a>0. Direct substitution gives 1−3q=dF/J and a−q=a d s E/J. With the conditional principal response G=C(1+q)/(8πQ) and gamma=(1−q)/(1+q), the transformed amplitude is

    H=G(2gamma−1)=C(1−3q)/(8πQ)=P(a−q),
    P=(1+s)/(8πQ a s)=4/[(8πQ)(1+k)].

The hypothetical vacuum scale is Gref=(1+k)/(8πQ), giving exactly the displayed P=4Gref/(1+k)². It is not an inserted measured reference. The normalization uses the supplied no-one-half kinetic convention and one common positive source-amplitude scale.

Then D=P(q2−q1) and N=aD. The parameter chart 0<k<1/3 maps monotonically onto 1/4<a<1/3; the minus quadratic root is the unique admissible one. The plus root lies outside that chart. The derivative dk/da=1/sqrt(1−3a) exposes upper-boundary conditioning; the certificate correctly maps the whole a interval with the exact monotone root instead of a linearized k error.

Writing Y=1/(1−3q), G_lens=HY gives G_lens=P[(a−1/3)Y+1/3], hence the old intercept B0=1/(1−3a)=4/(1−3k)² and slope B1=−3/[P(1−3a)]. This confirms exact equivalence to TWO_EPOCH_DERIVATION_v1.md. No additional independent action selector has been created. Equal force coefficients alone need not cause paired degeneracy: the independent exact k=1/8 fixture has q1=1/16 and q2=9/52, both G=1037/2340, yet D=92/585 and the paired inverse returns k=1/8.

For r=1+gammahat>egamma>=0, the exact q error is −2 deltagamma/[r(r+deltagamma)], so the maximum magnitude occurs at the negative gamma error and equals 2egamma/[r(r−egamma)]. The exact H error is (2gammahat−1)deltaG+2Ghat deltagamma+2deltaG deltagamma. The displayed eH is a direct triangle bound. Error radii must be nonnegative, as is already implicit in nonempty absolute-error envelopes. No independent-error assumption or small-error expansion is used.

The N bound follows by expanding both qH products, retaining both finite cross terms. The ratio identity

    a−ahat=[deltaN−ahat deltaD]/(Dhat+deltaD)

gives the displayed ea whenever |Dhat|>eD. Equality is insufficient. The bound contains measured ahat, not an unknown true parameter. The separate same-sign D and q-gap intervals, the complete open a interval, and the individual q intervals provide the stated sufficient certificate. They are not necessary conditions for the truth of a model with correlated errors; failure of a sufficient gate is inconclusive. The independent examples include an exact same-family near-coincident pair whose true k is valid but whose noisy denominator cannot be certified, as well as a formally admissible a with negative P.

The third-epoch determinant and eZ follow by expanding each difference-product, including its product of errors. Shared epoch-1 errors create correlations but do not invalidate the triangle inequality. The third point is evaluated after fixing the first two; no refit is performed. Non-rejection is only compatibility with the conditional affine relation and supplied envelopes. Every epoch still needs its own physical-domain check: a separate exact counterexample has a=3/10, P=2, q=(1/20,1/10,−1/50), positive G at all three points and Z=0, while the third q is outside the action chart. The source already requires the individual field domains; this is a confirming limitation, not a source correction.

Under common lambda>0, the measured G values AND eG must scale together. H, eH, D, N, their error bounds, P, Z and eZ then scale with lambda; q, a, ea and the k interval are invariant. Epoch-dependent calibration does not cancel. The independent exact counterexample uses original k=1/13, a=48/169, q=(16/507,96/845,42/169) and positive unequal scales (1361/1280,35/32,29/20). These produce the alternative admissible a'=3/10 with zero third residual. Thus even a successful third test cannot detect arbitrary coherent time-dependent calibration; the source explicitly excludes that freedom from the common-calibration premise.

## Actual controls and finite terms

The independent baseline completed 2772 passed / 0 failed checks, with 192 complete stored profiles: three rational fixtures and all 64 signs of six input errors per fixture. The k fixtures are 1/13, 2/11 and 5/17; the q/a triples, positive 8πQ scales and exact absolute error sizes are in INDEPENDENT_PROTOCOL_v1.json. Symbolic action identities use SymPy. All finite error comparisons use exact Fraction arithmetic. Only k endpoint display/comparison uses 90-digit Decimal arithmetic, backed by the analytic monotonicity proof. No solver, observational fit, stochastic sampling or empirical precision forecast is involved.

A separate affected follow-up completed 1155 passed / 0 failed checks of all three field/input domains in the already saved profiles and the exact positive-force/out-of-chart third-point counterexample. This reuses the profiles; it is not a rerun or relabeling of the baseline.

The saved profile summaries are:

'''+stat_lines+'''

These are synthetic diagnostics only. Exact values and every input, transformed quantity, radius, interval, residual and deliberately shifted-third residual remain in baseline_v1/FULL_PROFILES_v1.json and RESULTS_v1.json. An actual shift of gamma3 by 1/400 is rejected in every baseline profile while leaving the first-two-epoch inverse and its error interval unchanged.

The finite-term witnesses are nonzero. At gammahat=3/4 and egamma=1/20, the negative corner saturates eq=4/119. With Ghat=1, eG=1/10 and the positive gamma corner, the actual H error is 4/25, whereas omitting the cross term gives only 3/20. A separate composite-moment box saturates eN at 13/500 and fails without its cross term. A determinant box with zero measured first-order terms has actual |deltaZ|=1/1000, entirely from the finite cross term. The N/Z witnesses test the general composite-moment error lemma; they are not asserted to be physically realized same-family cosmological histories.

Six genuine altered independent programs were executed after the baseline was frozen. Each is an actual source copy with one recorded formula change; raw source, exact diff, command, exit status, input hashes, full output profiles and streams are preserved. Each used the declared focused mode with six profiles plus exact witnesses (168 rows), not the full 192-profile baseline:

'''+damage_lines+'''

The wrong-H copy changes the symbolic H transformation used in the raw-action identity; the intended identity fails algebraically. The other damages alter the q error coefficient, inverse root, H cross term, denominator gate and residual cross terms. All intended witnesses were observed. There were no unexpected baseline, execution or metadata failures in this unit. The 43 deliberate failed rows across the six programs are retained as expected negative-control evidence, not discarded or reported as successful science.

## Scope and evidence closure

The proof presupposes a weak nonrelativistic common source with controlled complete physical mass, universal unscreened weak charge, a matched smooth background, the specified short-distance/principal-operator hierarchy, fixed action parameters and an actually common or independently corrected calibration. It does not derive any of those conditions from observations. The three local states need not constitute an established cosmological trajectory. Absolute Q or Gref, potential parameters, physical history, initial-state selection and a unique action remain unselected. The action family relation can be shared by other models.

The deterministic envelopes must cover the relevant measurement AND forward-model discrepancy. A Gaussian standard error, an unrelated experiment or a prospective apparent precision is not automatically such a bound. No real measurements, Cassini/LLR combination, observational likelihood or empirical exclusion was performed. Aggregate bounds are deliberately conservative and need not be optimal under correlations. Their failure cannot be promoted to a theory exclusion; residual rejection is conditional on the forward relation and claimed envelopes.

COMMANDS_v1.json preserves the detailed command ledger through the initial controls; COMMANDS_FINAL_v1.json adds the later report/seal preparation commands. *.EXECUTION.json files bind actual subprocess arguments, times and all declared hand/source/checker inputs; corresponding raw stdout/stderr are retained even when empty. SOURCE_BINDINGS_v1.json gives exact live/snapshot recovery paths. DAMAGE_SUMMARY_v1.json, RUN_SUMMARY_v1.json and PRESEAL_VERIFICATION_v1.json preserve final counts and metadata correspondence separately from mathematical evidence. MANIFEST_v1.json will bind every artifact except itself and RECEIPT_v1.json; the receipt binds the manifest, report, source set and execution summaries. No producer evidence is adopted as independent evidence, and no prior science counts are relabeled as new runs.

This report is ready for the author's bounded use of the preserved v1 source and its conditional finite-error result. It does not authorize or claim any delivery, formal audit outcome or new scientific authority.
'''
(HERE/'REPORT_v1.md').write_text(report)
print(json.dumps(dict(metadata_passed=sum(r['passed'] for r in checks),metadata_failed=sum(not r['passed'] for r in checks),report_sha256=digest(HERE/'REPORT_v1.md'),statistics=statistics),indent=2))
