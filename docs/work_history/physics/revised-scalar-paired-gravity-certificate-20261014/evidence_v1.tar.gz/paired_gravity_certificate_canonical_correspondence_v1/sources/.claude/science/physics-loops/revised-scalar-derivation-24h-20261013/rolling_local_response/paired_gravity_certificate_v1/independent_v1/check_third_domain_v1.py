"""Focused all-epoch domain check of already frozen independent profiles."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime, timezone
import hashlib, json

HERE=Path(__file__).resolve().parent
rows=[]
def ck(name,condition,detail=None): rows.append(dict(name=name,passed=bool(condition),detail=detail))
profiles=json.loads((HERE/'baseline_v1/FULL_PROFILES_v1.json').read_text())
for p in profiles:
    c=p['certificate']; lower=F(c['a_interval'][0])
    for i in range(3):
        ck(f"all_epoch_field_domain:{p['case']}:{p['corner']}:{i}",F(c['q'][i])-F(c['eq'][i])>0 and F(c['q'][i])+F(c['eq'][i])<lower)
        ck(f"all_epoch_input_domain:{p['case']}:{p['corner']}:{i}",1+F(p['measured_gamma'][i])>F(p['egamma'][i])>=0 and F(p['eG'][i])>=0)

# A positive force coefficient at every epoch and exact line membership do not
# replace the third point's own physical q-domain test.
a=F(3,10);P=F(2);q=[F(1,20),F(1,10),F(-1,50)]
H=[P*(a-x) for x in q];gamma=[(1-x)/(1+x) for x in q]
G=[H[i]*(1+q[i])/(1-3*q[i]) for i in range(3)]
Z=(q[1]-q[0])*(H[2]-H[0])-(H[1]-H[0])*(q[2]-q[0])
ck('third_outside_field_chart_has_positive_forces',all(x>0 for x in G))
ck('third_outside_field_chart_passes_line',Z==0)
ck('third_outside_field_chart_requires_own_gate',all(0<x<a for x in q[:2]) and not 0<q[2]<a)

result=dict(at=datetime.now(timezone.utc).isoformat(),scope='Affected independent control: all three field/input domains in saved exact corners, plus a synthetic domain counterexample. No original science rerun.',passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),checks=rows,witness=dict(a=str(a),P=str(P),q=list(map(str,q)),H=list(map(str,H)),G=list(map(str,G)),gamma=list(map(str,gamma)),Z=str(Z)),profile_input_sha256=hashlib.sha256((HERE/'baseline_v1/FULL_PROFILES_v1.json').read_bytes()).hexdigest(),checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
out=HERE/'THIRD_DOMAIN_RESULTS_v1.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['passed','failed','witness']},indent=2))
raise SystemExit(bool(result['failed']))
