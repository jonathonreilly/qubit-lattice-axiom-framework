"""Blind independent exact certificate controls; no producer import or output access."""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal,localcontext
from itertools import product
from datetime import datetime,timezone
import argparse,hashlib,json
import sympy as S

Q_ERROR_FACTOR=2
H_OFFSET=-1
K_ROOT_SIGN=-1
H_CROSS_FACTOR=0
STRICT_DENOMINATOR=True
Z_CROSS_FACTOR=1

HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--focused',action='store_true');args=p.parse_args()
assert args.out.resolve().is_relative_to(HERE);args.out.mkdir(parents=True,exist_ok=False)
rows=[];profiles=[];witnesses={}
def encode(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,Decimal):return str(x)
    if isinstance(x,Path):return str(x)
    raise TypeError(type(x))
def ck(name,b,detail=None):rows.append(dict(name=name,passed=bool(b),detail=detail))
def eq(name,expr):
    simplified=S.factor(S.cancel(expr));ck(name,simplified==0,str(simplified))
def qhat(gamma):return (1-gamma)/(1+gamma)
def hh(G,gamma):return G*(2*gamma+H_OFFSET)
def qerr(gamma,egamma):return Q_ERROR_FACTOR*egamma/((1+gamma)*(1+gamma-egamma))
def herr(G,gamma,eG,egamma):return abs(2*gamma+H_OFFSET)*eG+2*abs(G)*egamma+H_CROSS_FACTOR*eG*egamma
def kmap(a):
    with localcontext() as c:
        c.prec=90;v=Decimal(a.numerator)/Decimal(a.denominator)
        return (1+K_ROOT_SIGN*2*(1-3*v).sqrt())/3
def dgate(D,eD):return abs(D)>eD if STRICT_DENOMINATOR else abs(D)>0
def moments(q,H,eqv,eHv):
    D=H[0]-H[1];N=q[1]*H[0]-q[0]*H[1];eD=eHv[0]+eHv[1]
    eN=abs(q[1])*eHv[0]+abs(H[0])*eqv[1]+eqv[1]*eHv[0]+abs(q[0])*eHv[1]+abs(H[1])*eqv[0]+eqv[0]*eHv[1]
    return D,N,eD,eN
def certify(G,gamma,eG,egamma):
    if not all(1+gamma[i]>egamma[i]>=0 and eG[i]>=0 for i in range(2)):return dict(status='input_domain')
    q=[qhat(x) for x in gamma];H=[hh(G[i],gamma[i]) for i in range(len(G))]
    eqv=[qerr(gamma[i],egamma[i]) for i in range(len(G))];eHv=[herr(G[i],gamma[i],eG[i],egamma[i]) for i in range(len(G))]
    D,N,eD,eN=moments(q,H,eqv,eHv);out=dict(q=q,H=H,eq=eqv,eH=eHv,D=D,N=N,eD=eD,eN=eN)
    if not dgate(D,eD):return {**out,'status':'denominator_unresolved'}
    if abs(D)-eD<=0:return {**out,'status':'invalid_admitted_denominator'}
    ah=N/D;ea=(eN+abs(ah)*eD)/(abs(D)-eD);lo=ah-ea;hi=ah+ea
    gap=q[1]-q[0];egap=eqv[1]+eqv[0]
    ppositive=(D-eD>0 and gap-egap>0) or (D+eD<0 and gap+egap<0)
    physical=F(1,4)<lo<hi<F(1,3) or (ea==0 and F(1,4)<lo==hi<F(1,3))
    fields=all(q[i]-eqv[i]>0 and q[i]+eqv[i]<lo for i in range(2))
    out.update(ahat=ah,ea=ea,a_interval=[lo,hi],gap=gap,egap=egap,P_hat=D/gap if gap else None,P_positive_certified=ppositive,physical_a_certified=physical,fields_certified=fields,status='certified' if ppositive and physical and fields else 'domain_unresolved')
    if physical:out['k_interval']=[kmap(lo),kmap(hi)]
    return out
def residual(q,H):return (q[1]-q[0])*(H[2]-H[0])-(H[1]-H[0])*(q[2]-q[0])
def residual_error(q,H,eqv,eHv):
    Q21=q[1]-q[0];Q31=q[2]-q[0];H21=H[1]-H[0];H31=H[2]-H[0]
    EQ21=eqv[1]+eqv[0];EQ31=eqv[2]+eqv[0];EH21=eHv[1]+eHv[0];EH31=eHv[2]+eHv[0]
    return abs(Q21)*EH31+abs(H31)*EQ21+Z_CROSS_FACTOR*EQ21*EH31+abs(H21)*EQ31+abs(Q31)*EH21+Z_CROSS_FACTOR*EH21*EQ31
def true_state(k,qfractions,Q8):
    a=(1-k)*(1+3*k)/4;s=(1+k)/(k*(1-3*k));qs=[a*r for r in qfractions];E=[(a-q)/(s*q*(1-3*a)) for q in qs]
    C=[(1+s)*e/(1+s*e) for e in E];G=[C[i]*(1+qs[i])/Q8 for i in range(3)];gam=[(1-q)/(1+q) for q in qs];H=[G[i]*(2*gam[i]-1) for i in range(3)];P=4/(Q8*(1+k))
    return dict(k=k,a=a,s=s,q=qs,E=E,C=C,G=G,gamma=gam,H=H,P=P,Q8=Q8)

# Direct raw-action symbolic checks, independently transformed before any numerical controls.
k,e,Q8=S.symbols('k E Q8',positive=True);a=(1-k)*(1+3*k)/4;s=(1+k)/(k*(1-3*k));Ff=1+s*e;J=1+(1-3*a)*s*e;K=J/Ff**2;b=S.sqrt(a)/Ff
q=b*b/K;C=(1+s)*e/Ff;G=C*(1+q)/Q8;gamma=(1-q)/(1+q);P=4/(Q8*(1+k));H=G*(2*gamma+H_OFFSET)
eq('action_coupling_norm',q-a/J)
eq('paired_H_from_action',H-P*(a-q))
eq('gamma_q_transform',(1-gamma)/(1+gamma)-q)
eq('P_vacuum_scale',P-4*((1+k)/Q8)/(1+k)**2)
Y=1/(1-3*q);Glens=G/(1+q);B0=1/(1-3*a);B1=-3/(P*(1-3*a))
eq('old_affine_relation',Y-B0-B1*Glens)
eq('old_intercept_normalization',B0-4/(1-3*k)**2)
t=S.symbols('t',positive=True)
eq('physical_k_root',(1+K_ROOT_SIGN*t)/3-(1-t)/3)
q1,q2,q3,aa,PP=S.symbols('q1 q2 q3 a P');hh1=PP*(aa-q1);hh2=PP*(aa-q2);hh3=PP*(aa-q3)
eq('two_epoch_a_numerator',q2*hh1-q1*hh2-aa*(hh1-hh2))
eq('two_epoch_slope',hh1-hh2-PP*(q2-q1))
eq('third_epoch_determinant',(q2-q1)*(hh3-hh1)-(hh2-hh1)*(q3-q1))
gh,dg,GG,dG=S.symbols('gammahat deltagamma Ghat deltaG')
eq('q_exact_finite_difference',(1-(gh+dg))/(1+gh+dg)-(1-gh)/(1+gh)+2*dg/((1+gh)*(1+gh+dg)))
eq('H_full_finite_product',(GG+dG)*(2*(gh+dg)-1)-GG*(2*gh-1)-((2*gh-1)*dG+2*GG*dg+2*dG*dg))
NN,DD,dN,dD=S.symbols('Nhat Dhat deltaN deltaD')
eq('measured_ratio_identity',(NN+dN)/(DD+dD)-NN/DD-(dN-(NN/DD)*dD)/(DD+dD))

# Sharp finite witnesses, including valid positive local q/H ranges.
gm=F(3,4);eg=F(1,20);GG=F(1);eGG=F(1,10)
qdiff=abs(qhat(gm-eg)-qhat(gm));qbound=qerr(gm,eg)
ck('q_bound_sharp_negative_corner',qdiff==qbound,dict(actual=qdiff,bound=qbound))
Hdiff=abs((GG+eGG)*(2*(gm+eg)-1)-GG*(2*gm-1));Hbound=herr(GG,gm,eGG,eg)
ck('H_bound_sharp_positive_corner',Hdiff==Hbound,dict(actual=Hdiff,bound=Hbound))
linearH=abs(2*gm-1)*eGG+2*GG*eg
ck('omitting_H_cross_term_really_fails',Hdiff>linearH)
ck('finite_corner_physical_q',F(0)<qhat(gm+eg)<F(3,10) and F(0)<qhat(gm)<F(3,10))
qm=[F(1,20),F(1,10)];Hm=[F(1),F(1,2)];eqm=[F(0),F(1,50)];eHm=[F(1,20),F(0)]
Dn,Nn,eDn,eNn=moments(qm,Hm,eqm,eHm);qt=[qm[0],qm[1]+eqm[1]];Ht=[Hm[0]+eHm[0],Hm[1]];Ntrue=qt[1]*Ht[0]-qt[0]*Ht[1]
ck('moment_product_cross_sharp',abs(Ntrue-Nn)==eNn)
ck('moment_product_without_cross_fails',abs(Ntrue-Nn)>eNn-eqm[1]*eHm[0])
qz=[F(1,10)]*3;Hz=[F(1)]*3;eqz=[F(0),F(1,50),F(0)];eHz=[F(0),F(0),F(1,20)];qzt=[qz[i]+eqz[i] for i in range(3)];Hzt=[Hz[i]+eHz[i] for i in range(3)]
zdiff=abs(residual(qzt,Hzt)-residual(qz,Hz));ez=residual_error(qz,Hz,eqz,eHz)
ck('residual_finite_cross_sharp',zdiff==ez,dict(actual=zdiff,bound=ez))
witnesses['finite_cross_terms']=dict(q_actual=qdiff,q_bound=qbound,H_actual=Hdiff,H_bound=Hbound,H_linear_only=linearH,N_actual=abs(Ntrue-Nn),N_bound=eNn,Z_actual=zdiff,Z_bound=ez,scope='N and Z witnesses test general composite-moment error boxes, not a claimed coupled three-epoch cosmological solution.')
for D,eD,want in [(F(0),F(0),False),(F(1,10),F(1,10),False),(F(-1,10),F(1,10),False),(F(1,20),F(1,10),False),(F(11,100),F(1,10),True)]:
    ck('strict_denominator_gate:'+str(D)+':'+str(eD),dgate(D,eD)==want)

# Equal-force two-state construction: distinct scalar ratios still identify k.
turn=true_state(F(1,8),[F(1,16)/F(77,256),F(9,52)/F(77,256),F(1,4)],F(5,2))
ck('equal_force_distinct_q',turn['G'][0]==turn['G'][1] and turn['q'][0]!=turn['q'][1])
turncert=certify(turn['G'],turn['gamma'],[F(0)]*3,[F(0)]*3)
ck('equal_force_paired_inverse',turncert['status']=='certified' and turncert['ahat']==turn['a'])
with localcontext() as c:
    c.prec=90;ck('equal_force_recovers_k',abs(kmap(turncert['ahat'])-Decimal(1)/8)<Decimal('1e-80'))
witnesses['equal_force_distinct_states']=dict(state=turn,certificate=turncert)

ks=[F(1,13),F(2,11),F(5,17)];fractions=[[F(1,9),F(2,5),F(7,8)],[F(1,8),F(3,7),F(4,5)],[F(1,6),F(5,9),F(11,12)]];Qs=[F(7,3),F(11,4),F(19,6)]
for index,(kv,fr,Qv) in enumerate(zip(ks,fractions,Qs)):
    state=true_state(kv,fr,Qv);a0=state['a'];qs=state['q'];Gs=state['G'];gs=state['gamma'];Hs=state['H']
    ck('action_all_states_admissible:'+str(index),all(E>0 for E in state['E']) and all(0<q<a0 for q in qs))
    ck('action_affine_all_epochs:'+str(index),all(Hs[i]==state['P']*(a0-qs[i]) for i in range(3)))
    ck('true_third_residual_zero:'+str(index),residual(qs,Hs)==0)
    zero=certify(Gs,gs,[F(0)]*3,[F(0)]*3);ck('exact_inverse:'+str(index),zero['status']=='certified' and zero['ahat']==a0 and zero['P_hat']==state['P'])
    base_eG=[F(i+1,1000000) for i in range(3)];base_eg=[F(i+1,2000000) for i in range(3)]
    corner_signs=list(product([-1,1],repeat=6)) if not args.focused else [(-1,-1,-1,-1,-1,-1),(1,1,1,1,1,1)]
    for ci,signs in enumerate(corner_signs):
        Gm=[Gs[i]+signs[i]*base_eG[i] for i in range(3)];gm=[gs[i]+signs[i+3]*base_eg[i] for i in range(3)]
        cert=certify(Gm,gm,base_eG,base_eg);label=str(index)+':'+str(ci)
        ck('corner_certified:'+label,cert['status']=='certified')
        for i in range(3):
            ck('q_finite_envelope:'+label+':'+str(i),abs(qs[i]-cert['q'][i])<=cert['eq'][i])
            ck('H_finite_envelope:'+label+':'+str(i),abs(Hs[i]-cert['H'][i])<=cert['eH'][i])
        trueD=Hs[0]-Hs[1];trueN=qs[1]*Hs[0]-qs[0]*Hs[1]
        ck('D_finite_envelope:'+label,abs(trueD-cert['D'])<=cert['eD'])
        ck('N_finite_envelope:'+label,abs(trueN-cert['N'])<=cert['eN'])
        ck('a_finite_envelope:'+label,abs(a0-cert['ahat'])<=cert['ea'])
        with localcontext() as ctx:
            ctx.prec=90;ktr=Decimal(kv.numerator)/Decimal(kv.denominator);ck('k_exact_monotone_interval:'+label,cert['k_interval'][0]<=ktr<=cert['k_interval'][1])
        z=residual(cert['q'],cert['H']);ez=residual_error(cert['q'],cert['H'],cert['eq'],cert['eH']);ck('third_epoch_finite_envelope:'+label,abs(z)<=ez)
        # One off-corner finite perturbation at the third epoch; two calibration epochs untouched.
        damaged_gamma=list(gm);damaged_gamma[2]+=F(1,400);dam=certify(Gm,damaged_gamma,base_eG,base_eg);zdam=residual(dam['q'],dam['H']);ezdam=residual_error(dam['q'],dam['H'],dam['eq'],dam['eH'])
        ck('third_epoch_no_refit:'+label,dam['ahat']==cert['ahat'] and dam['ea']==cert['ea'])
        ck('deliberate_third_epoch_rejected:'+label,abs(zdam)>ezdam)
        if ci==0:
            for scale in [F(2,9),F(1),F(11,2)]:
                scaled=certify([scale*g for g in Gm],gm,[scale*e for e in base_eG],base_eg)
                ck('common_calibration_interval_invariant:'+label+':'+str(scale),all(scaled[n]==cert[n] for n in ['q','eq','ahat','ea','a_interval','k_interval','status']))
                ck('common_calibration_amplitude_covariant:'+label+':'+str(scale),all(scaled[n]==scale*cert[n] for n in ['D','N','eD','eN','P_hat']))
                ck('common_calibration_residual_covariant:'+label+':'+str(scale),residual(scaled['q'],scaled['H'])==scale*z and residual_error(scaled['q'],scaled['H'],scaled['eq'],scaled['eH'])==scale*ez)
        profiles.append(dict(case=index,corner=ci,signs=signs,true=state,measured_G=Gm,measured_gamma=gm,eG=base_eG,egamma=base_eg,certificate=cert,third_residual=z,third_error_bound=ez,damaged_third_residual=zdam,damaged_third_bound=ezdam))

# Insufficient gates and a calibration counterexample do not become exclusions.
st=true_state(F(1,13),fractions[0],Qs[0]);G0=st['G'][0];g0=st['gamma'][0]
equal=certify([G0,G0,G0],[g0,g0,g0],[F(0)]*3,[F(0)]*3)
ck('equal_epoch_unidentifiable',equal['status']=='denominator_unresolved')
closeq=[st['q'][0],st['q'][0]+F(1,10**12),st['q'][2]];close=true_state(st['k'],[q/st['a'] for q in closeq],st['Q8'])
close_cert=certify(close['G'],close['gamma'],[F(1,1000000)]*3,[F(1,1000000)]*3)
ck('true_model_can_fail_separation_gate',close_cert['status']=='denominator_unresolved')
badq=[F(1,10),F(1,5),F(1,4)];badH=[F(-1,5),F(-1,10),F(-1,20)];badG=[badH[i]*(1+badq[i])/(1-3*badq[i]) for i in range(3)];badgamma=[(1-q)/(1+q) for q in badq]
bad=certify(badG,badgamma,[F(0)]*3,[F(0)]*3);ck('a_alone_does_not_certify_positive_P',bad['ahat']==F(3,10) and not bad['P_positive_certified'] and bad['status']=='domain_unresolved')
invalid=certify([F(1)]*3,[F(-1)]*3,[F(0)]*3,[F(0)]*3);ck('gamma_denominator_domain_rejected',invalid['status']=='input_domain')
for av in [F(1,4),F(1,3),F(1,5),F(7,20)]:
    qs0=[F(1,20),F(1,10),F(3,20)];Hs0=[av-q for q in qs0];Gs0=[Hs0[i]*(1+qs0[i])/(1-3*qs0[i]) for i in range(3)];gs0=[(1-q)/(1+q) for q in qs0]
    cc=certify(Gs0,gs0,[F(0)]*3,[F(0)]*3);ck('strict_a_chart_gate:'+str(av),not cc['physical_a_certified'])
qs0=[F(0),F(1,10),F(1,5)];av=F(3,10);Hs0=[av-q for q in qs0];Gs0=[Hs0[i]*(1+qs0[i])/(1-3*qs0[i]) for i in range(3)];gs0=[(1-q)/(1+q) for q in qs0]
cc=certify(Gs0,gs0,[F(0)]*3,[F(0)]*3);ck('strict_field_q_gate',not cc['fields_certified'])
alternative_a=F(3,10);scales=[(alternative_a-q)/(st['a']-q) for q in st['q']];changedG=[scales[i]*st['G'][i] for i in range(3)];fake=certify(changedG,st['gamma'],[F(0)]*3,[F(0)]*3)
ck('epoch_scales_positive_nonconstant',all(x>0 for x in scales) and len(set(scales))==3)
ck('time_dependent_scale_can_fake_admissible_parameter',fake['status']=='certified' and fake['ahat']==alternative_a!=st['a'])
ck('time_dependent_scale_can_pass_third_epoch',residual(fake['q'],fake['H'])==0)
witnesses['epoch_dependent_calibration']=dict(original=st,scales=scales,alternative_a=alternative_a,changed_force=changedG,false_certificate=fake,third_residual=residual(fake['q'],fake['H']))
witnesses['gates']=dict(equal_epoch=equal,near_equal_true_model=close_cert,negative_P=bad,invalid_gamma=invalid)

for row in json.loads((HERE/'SOURCE_BINDINGS_v1.json').read_text())['sources']:
    original=Path(row['original_path']);snapshot=Path(row['snapshot_path']);ck('hand_source_unchanged:'+original.name,hashlib.sha256(original.read_bytes()).hexdigest()==row['sha256']==hashlib.sha256(snapshot.read_bytes()).hexdigest())
result=dict(at=datetime.now(timezone.utc).isoformat(),scope='Independent synthetic exact finite-error controls. No observed data or producer implementation/results read.',passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),focused=args.focused,checks=rows,profiles=profiles,witnesses=witnesses,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(args.out/'RESULTS_v1.json').write_text(json.dumps(result,indent=2,default=encode)+'\n')
(args.out/'FULL_PROFILES_v1.json').write_text(json.dumps(profiles,indent=2,default=encode)+'\n')
print(json.dumps(dict(passed=result['passed'],failed=result['failed'],profiles=len(profiles),failed_checks=[r for r in rows if not r['passed']]),indent=2,default=encode))
raise SystemExit(bool(result['failed']))
