from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
HERE=Path(__file__).resolve().parent;UNIT=HERE.parent;RR=UNIT.parent;PK=RR.parent;WT=PK.parents[3]
files=[UNIT/'DERIVATION_v1.md',UNIT/'PROTOCOL_v1.json',RR/'TWO_EPOCH_DERIVATION_v1.md',RR/'DERIVATION_v2.md',WT/'docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md']
rows=[]
for p in files:
    raw=p.read_bytes();target=HERE/'sources'/p.relative_to(WT);assert not target.exists();target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    rows.append(dict(original_path=str(p),snapshot_path=str(target),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
assert rows[0]['sha256']=='a0da9e8bc18328422393e3c85169d2acf64f6549260bedf7ce03bf88441575c4'
(HERE/'SOURCE_BINDINGS_v1.json').write_text(json.dumps(dict(at=datetime.now(timezone.utc).isoformat(),scope='Blind hand-source inputs only; no producer code, execution records, outputs or new-route directory inventory read.',sources=rows),indent=2)+'\n')
print(json.dumps(dict(source_pairs=len(rows),hand_sha256=rows[0]['sha256'])))
