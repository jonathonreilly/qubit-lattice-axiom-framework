from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
HERE=Path(__file__).resolve().parent
prefix=HERE/sys.argv[1];assert prefix.resolve().is_relative_to(HERE)
argv=sys.argv[2:];inputs=[Path(x) for x in argv if Path(x).is_file()]
for r in json.loads((HERE/'SOURCE_BINDINGS_v1.json').read_text())['sources']:inputs.extend([Path(r['original_path']),Path(r['snapshot_path'])])
inputs.extend([HERE/'HAND_DERIVATION_v1.md',HERE/'INDEPENDENT_PROTOCOL_v1.json'])
ident=lambda p:dict(path=str(p.resolve()),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
before=[ident(p) for p in inputs];started=datetime.now(timezone.utc).isoformat()
r=subprocess.run(argv,cwd=HERE,capture_output=True)
prefix.parent.mkdir(parents=True,exist_ok=True)
for suffix,raw in [('.stdout.txt',r.stdout),('.stderr.txt',r.stderr)]:
    p=Path(str(prefix)+suffix);assert not p.exists();p.write_bytes(raw)
record=dict(argv=argv,cwd=str(HERE),started_utc=started,ended_utc=datetime.now(timezone.utc).isoformat(),exit_code=r.returncode,actual_inputs=before,inputs_unchanged=(before==[ident(p) for p in inputs]))
p=Path(str(prefix)+'.EXECUTION.json');assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(argv=argv,exit_code=r.returncode,inputs_unchanged=record['inputs_unchanged']),indent=2));print(r.stdout.decode());print(r.stderr.decode(),file=sys.stderr)
raise SystemExit(r.returncode)
