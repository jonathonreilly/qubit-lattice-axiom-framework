"""Seal this completed focused independent unit; no source changes or science run."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,sys

HERE=Path(__file__).resolve().parent
for name in ['MANIFEST_v1.json','RECEIPT_v1.json','SEAL_VALIDATION_v1.json']:
    assert not (HERE/name).exists(),name
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def identity(p):return dict(path=str(p.resolve()),relative_path=str(p.relative_to(HERE)),bytes=p.stat().st_size,sha256=sha(p))
sources=json.loads((HERE/'SOURCE_BINDINGS_v1.json').read_text())['sources']
assert len(sources)==5
for s in sources:
    for key in ['original_path','snapshot_path']:
        p=Path(s[key]);assert p.stat().st_size==s['bytes'] and sha(p)==s['sha256'],str(p)
baseline=json.loads((HERE/'baseline_v1/RESULTS_v1.json').read_text())
assert (baseline['passed'],baseline['failed'])==(2772,0)
assert baseline['checker_sha256']==sha(HERE/'check_independent_v1.py')
assert baseline['profiles']==json.loads((HERE/'baseline_v1/FULL_PROFILES_v1.json').read_text())
domain=json.loads((HERE/'THIRD_DOMAIN_RESULTS_v1.json').read_text())
assert (domain['passed'],domain['failed'])==(1155,0)
assert domain['checker_sha256']==sha(HERE/'check_third_domain_v1.py')
assert domain['profile_input_sha256']==sha(HERE/'baseline_v1/FULL_PROFILES_v1.json')
metadata=json.loads((HERE/'PRESEAL_VERIFICATION_v1.json').read_text())
assert metadata['failed']==0
damages=json.loads((HERE/'DAMAGE_SUMMARY_v1.json').read_text())['damages']
assert len(damages)==6
for d in damages:
    assert sha(Path(d['source']))==d['source_sha256']
    assert sha(HERE/d['result_path'])==d['result_sha256']
    assert json.loads((HERE/d['execution_path']).read_text())['exit_code']==1
for p in HERE.rglob('*'):
    assert not p.is_symlink(),str(p)

now=datetime.now(timezone.utc).isoformat()
validation=dict(at=now,scope='Final immutable source and artifact correspondence only; no science rerun.',five_source_snapshot_pairs_unchanged=True,baseline_profiles=192,baseline_counts=[2772,0],separate_saved_profile_domain_counts=[1155,0],six_actual_damages_rejected=True,all_paths_regular_and_within_unit=True,preseal_metadata_counts=[metadata['passed'],metadata['failed']],seal_command_argv=[sys.executable,*sys.argv],no_producer_evidence_read=True)
(HERE/'SEAL_VALIDATION_v1.json').write_text(json.dumps(validation,indent=2)+'\n')
artifacts=[identity(p) for p in sorted(HERE.rglob('*')) if p.is_file()]
manifest=dict(schema_version=1,created_utc=now,root=str(HERE),scope='Frozen focused independent paired-gravity certificate evidence. Manifest excludes itself and RECEIPT_v1.json to avoid circular hashes.',artifact_count=len(artifacts),artifacts=artifacts)
mp=HERE/'MANIFEST_v1.json';mp.write_text(json.dumps(manifest,indent=2)+'\n')
receipt=dict(schema_version=1,sealed_utc=now,root=str(HERE),task='Blind focused independent paired-gravity finite-error certificate check',disposition='Conditional mathematical source confirmed; no source correction required. No formal audit or empirical/action-selection conclusion.',report=identity(HERE/'REPORT_v1.md'),manifest=identity(mp),artifact_count=len(artifacts),source_bindings=sources,independent_baseline=dict(passed=2772,failed=0,complete_profiles=192,result=identity(HERE/'baseline_v1/RESULTS_v1.json'),profiles=identity(HERE/'baseline_v1/FULL_PROFILES_v1.json')),separate_domain_followup=dict(passed=1155,failed=0,result=identity(HERE/'THIRD_DOMAIN_RESULTS_v1.json'),scope='Domain checks of the frozen profiles plus one exact domain counterexample; not a rerun of baseline science.'),actual_damages=damages,source_corrections=[],unexpected_failures=[],failure_history='Six deliberate altered programs all exit 1; full failed rows, source copies, diffs and raw streams retained. Own draft report wording clarified before seal with draft and exact change retained; no mathematical source/result changed.',reuse='Supplied action and conditional leading common-source response are premises; no full-body/physical hierarchy or previous science rerun claimed.',independence='Only five hand/protocol/action sources were read; no producer implementation/results/metadata inspected.',limitations=['Synthetic exact fixtures, not observed gravity/LLR data or precision forecast.','All deterministic error envelopes and weak common-source/background/calibration premises remain conditional.','Failed sufficient gates are inconclusive; nonzero third residual rejects only conditional relation plus claimed envelopes.','Epoch-dependent calibration can mimic another admissible parameter and pass the third residual.','Every epoch needs its own field-domain gate; line membership and positive G are insufficient.','Other actions may share the relation; no unique action, potential, initial-state or history selection.'],final_source_confirmation='All five live/snapshot source pairs match the originally frozen hashes in the same session.',seal_policy='No further writes under this unit after this receipt; any followup must use a new sibling/subfolder and preserve this seal.')
rp=HERE/'RECEIPT_v1.json';rp.write_text(json.dumps(receipt,indent=2)+'\n')
for r in artifacts:
    p=Path(r['path']);assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256']
for s in sources:
    assert sha(Path(s['original_path']))==sha(Path(s['snapshot_path']))==s['sha256']
print(json.dumps(dict(sealed=True,artifact_count=len(artifacts),source_pairs=len(sources),report=identity(HERE/'REPORT_v1.md'),manifest=identity(mp),receipt=identity(rp)),indent=2))
