# A physical radiation clock without a chosen vacuum scale

Direct author /root. This derives a conditional physical proper-time interval
bound using positive energy and the conformal coupling. It does not derive a
cosmic state, a measured gravity environment, matter conservation across all
real thermal epochs, or an age of the actual universe.

## Observational question and stated domain

The earlier positive-radiation comparison used a supplied vacuum scale Hv and
bounded A by a global field-space maximum. Can physical elapsed time instead
be bounded by the measured-clock density at one event and a proved coupling
constraint? A real application still needs the appropriate gravitational
normalization and matter history. No observed number is fitted here.

Take a regular connected spatially flat homogeneous Einstein-frame history with

    3Q H^2 = Q w_phi + V + rho_B,E + rho_o,
    w_phi=|dot phi|_K^2>=0, Q>0, V>=0, rho_o>=0.

The selected bath has rho_B,E>0. Let A>0, C=A^2, b=d ln A,
q=|b|_K^2<=qmax<1/3, and c=sqrt(3qmax)<1. Assume fixed Q and one fixed
qmax for this history. Physical clocks obey dt_J=A dt_E,
a_J=A a_E, H_J=(H+L)/A, L=dot A/A=b.dot phi.

The final event0 has H_J,0>0, positive bath density and finite field values.
For every earlier event in the interval assume the finite charge comparison

    D(t)=rho_B,E(t) a_E(t)^4 >= D0/R,       R>=1.       (1)

Separately conserved positive traceless radiation gives R=1. The proved
isolated fixed-entropy ideal photon/pair bath gives R=(11/4)^(1/3) even
through its finite-mass transition. More general matter requires its own
uniform past-to-final charge bound. A postulated R is an assumption unless
such a matter argument is provided. No monotone A is assumed.

## Expansion and clock control follow from the constraint

Cauchy-Schwarz and the positive-energy constraint give

    |L|<=sqrt(q w_phi)<=sqrt(3qmax)|H|=c|H|.           (2)

The bath makes H nonzero on every regular event. If H<0, then H+L<0,
contradicting positive H_J at the final event. Continuity of nonzero H
therefore forces H>0 throughout the connected interval. Also H+L>0,
so physical expansion is positive throughout. Set x=a_E/a_E,0 in (0,1]
for earlier events. Dividing (2) by positive H yields

    -c<=d ln A/d ln a_E<=c,
    A(t)<=A0 x^-c.                                  (3)

The upper past bound uses the lower logarithmic derivative -c. Reversing
integration endpoints would give a wrong clock estimate. This bound permits
A to grow toward the past; no global maximum of A has entered.

Equation (1) and Friedmann give

    rho_B,E(t)>=rho_B,E,0 x^-4/R,
    H(t)>=sqrt[rho_B,E,0/(3Q R)] x^-2.               (4)

For any earlier regular event with Einstein ratio x_i>0, physical duration is

    Delta t_J = integral_(x_i)^1 A(x)/(x H(x)) dx
       <= A0 sqrt[3Q R/rho_B,E,0]
                       (1-x_i^(2-c))/(2-c)
       <  A0 sqrt[3Q R/rho_B,E,0]/(2-c).             (5)

Thus the supremum of regular past physical duration is bounded by

    T_J,max <= sqrt[3Q R/(C0 rho_B,J,0)]/(2-c).       (6)

We used rho_B,E,0=C0^2 rho_B,J,0 and A0=sqrt(C0).
The bound does not require V to have a strictly positive floor or specify Hv.
It holds if an earlier chart boundary occurs at finite positive a_E as well;
it does not classify that boundary or prove an extension impossible. A supremum
can saturate the limiting inequality even though each finite interval is strict.
The positive final bath, charge control, spatial flatness and c<1 remain
substantive conditions. Positive spatial curvature changes Friedmann and is
outside this proof; previously found regular curved histories are not excluded.

The integral alone converges for c<2, but expansion/sign control used c<1.
This derivation does not claim the same theorem merely from c<2. For the
candidate supplied metric q=a/J<a, a=(1-k)(1+3k)/4 with0<k<1/3, choose
qmax=a. Then c=sqrt(3a)<1 is uniform over its finite field chart and positive
kinetic domain. Choosing this envelope is action algebra, not selecting a state.

## What a positive measured gravity normalization would add

Define G_bare,0=C0/(8piQ), and for a specified positive G_cal define
 gamma0=G_cal/G_bare,0>0. Equation(6) becomes the identity-bound

    T_J,max <= sqrt[3 R gamma0/(8pi G_cal rho_B,J,0)]/(2-c). (7)

The local laboratory coefficient and cosmological coefficient are not equated.
If the same-background weak-source calibration and an independently justified
error ceiling eta>=0 give gamma0<=(1+eta)(1+q0)<4(1+eta)/3, then

    T_J,max < sqrt[R(1+eta)/(2pi G_cal rho_B,J,0)]/(2-c)
            < sqrt[R(1+eta)/(2pi G_cal rho_B,J,0)].    (8)

The second inequality uses2-c>1. This removes C0 and Hv from that conditional
upper estimate. At different environmental backgrounds the previous principal
ceiling is gamma0<=(1+eta)(1+k)/C0; it does not cancel C0 and cannot be silently
replaced by Eq8. A real numerical age statement requires actual calibration
and a valid bath interval. Present radiation alone does not establish them.

## Controls and limits

For A constant (c=0) and a spatially flat pure-radiation model with V=0,
a_E proportional tosqrt(t_E), the sharp physical elapsed time to its zero-radius
boundary is A0 sqrt(3Q/rho_E0)/2. It equals Eq6 with R=1, and provides a
normalization control in the general action class. It is not an exact member
of the candidate with Hv>0; that candidate has a positive potential floor.
A constant-scalar radiation-plus-vacuum history instead has an elapsed time
below the same floor-free bound. Neither example proves a nonsingular origin.

Equations(3) and(4) are separate necessary envelopes and need not saturate
simultaneously in a scalar history: saturating the coupling-speed envelope
would require scalar kinetic energy, while saturation of the Friedmann lower
bound would leave no such energy. The bound is sufficient and is not claimed
optimal for c>0. Power-law envelope controls below verify its integration and
signs only; they are not passed off as complete solutions. No chosen six-state,
fixed-point past boundary, finite density cutoff, entropy selector, new scale
or empirical acceptance has been supplied by this argument.
