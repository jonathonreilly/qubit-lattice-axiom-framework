from pathlib import Path
import json, sys, hashlib
import sympy as S

out=Path(sys.argv[1]); assert not out.exists(); rows=[]
def eq(name,expr):
    value=S.factor(S.simplify(expr)); rows.append(dict(name=name,passed=value==0,residual=str(value)))
def ck(name,value,detail=None): rows.append(dict(name=name,passed=bool(value),detail=detail))

Q,H,q,L,w,V,ro,rho=S.symbols('Q H q L w V rho_other rho_B',positive=True)
# The equality follows from Friedmann; no independent H/w choice is inferred.
rhoc=3*Q*H**2-Q*w-V-ro
square=(3*q*H+2*L)**2/(3*q)+(4-3*q)*(w-L**2/q)/3+(4-3*q)*(V+ro)/(3*Q)
eq('joint_Friedmann_coupling_square',(2*H+L)**2-(4-3*q)*rhoc/(3*Q)-square)
gap=S.symbols('gap',nonnegative=True)
qp=1/(3*(1+S.symbols('z',positive=True)))
eq('positive_transverse_coefficient',4-3*qp-(3+S.symbols('z',positive=True)*4)/(1+S.symbols('z',positive=True)))
ck('positive_joint_coefficients', S.factor(4-3*qp).is_positive)
# Exact square saturation at a local constraint state is not a full solution.
Lopt=-3*q*H/2; wopt=Lopt**2/q
eq('local_square_minimizer',square.subs({L:Lopt,w:wopt,V:0,ro:0}))
eq('local_minimizer_bath_density',rhoc.subs({L:Lopt,w:wopt,V:0,ro:0})-3*Q*H**2*(1-3*q/4))

A,a,D,R=S.symbols('A a D R',positive=True)
eq('Phi_physical_time_derivative',(A*a**2*L+2*A*a**2*H)/A-a**2*(2*H+L))
eq('constant_duration_integrand',a**4*(4-3*q)*(D/(R*a**4))/(3*Q)-(4-3*q)*D/(3*Q*R))
C,rj,a0=S.symbols('C rhoJ a0',positive=True)
D0=C**2*rj*a0**4
sharp=S.sqrt(C)*a0**2*S.sqrt(3*Q*R/((4-3*q)*D0))
eq('physical_endpoint_density_conversion',sharp**2-3*Q*R/(C*rj*(4-3*q)))
G,gamma,eta=S.symbols('G gamma eta',positive=True)
qsub=gamma*C/(8*S.pi*G)
eq('positive_gravity_calibration',sharp.subs(Q,qsub)**2-3*R*gamma/(8*S.pi*G*rj*(4-3*q)))
eq('same_background_upper_coefficient',sharp.subs(Q,qsub).subs(gamma,S.Rational(4,3)*(1+eta))**2-R*(1+eta)/(2*S.pi*G*rj*(4-3*q)))
eq('zero_coupling_radiation_normalization',sharp.subs(q,0)**2-3*Q*R/(4*C*rj))
ck('candidate_uniform_domain',S.factor(1-3*qp).is_positive)

c,x,xi=S.symbols('c x xi',positive=True)
envelope=x**(2-c)/(2-c)
eq('separate_envelope_integral',S.diff(envelope,x)-x**(1-c))
eq('sharp_vs_separate_squared_denominators',(4-c**2)-(2-c)**2-2*c*(2-c))
# A second independent algebraic route: optimize the energy-weighted clock.
ell=S.symbols('ell',real=True)
eq('weighted_clock_ratio_square',(2+ell)**2-(4-c**2)*(1-ell**2/c**2)-(2*ell+c**2)**2/c**2)
eq('weighted_clock_optimal_log_slope',((2+ell)**2-(4-c**2)*(1-ell**2/c**2)).subs(ell,-c**2/2))

examples=[]
for kval in [S.Rational(1,100),S.Rational(1,10),S.Rational(1,5),S.Rational(3,10)]:
    qa=(1-kval)*(1+3*kval)/4; cv=S.sqrt(3*qa)
    ck('candidate_qmax_'+str(kval),0<qa<S.Rational(1,3))
    ck('candidate_clock_sign_'+str(kval),0<cv<1)
    ck('sharp_improves_separate_'+str(kval),S.sqrt(4-3*qa)>2-cv)
    for hv in [S.Rational(1),S.Rational(3,2)]:
        for frac in [-S.Rational(2,3),S.Rational(1,4)]:
            lv=frac*hv; ww=lv**2/qa+S.Rational(1,10); bath=3*hv**2-ww-S.Rational(1,20)
            if bath<=0:continue
            resid=(2*hv+lv)**2-(4-3*qa)*bath/3
            ck('positive_local_constraint_'+str((kval,hv,frac)),resid>=0 and 2*hv+lv>0)
    examples.append(dict(k=str(kval),qmax=str(qa),sharp_coefficient=str(S.N(1/S.sqrt(4-3*qa),20)),separate_coefficient=str(S.N(1/(2-cv),20))))

# Exact homogeneous radiation+vacuum solution within candidate origin domain:
# a^2=sinh(2Hv t), rho=3Q Hv^2/a^4, C=1, scalar velocity zero.
t,hv=S.symbols('t Hv',positive=True)
aa=S.sqrt(S.sinh(2*hv*t)); hh=hv*S.coth(2*hv*t); rr=3*Q*hv**2/S.sinh(2*hv*t)**2
eq('origin_radiation_vacuum_Friedmann',3*Q*hh**2-3*Q*hv**2-rr)
eq('origin_radiation_continuity',S.diff(rr,t)+4*hh*rr)
eq('origin_Phi_derivative',S.diff(aa**2,t)-2*hv*S.cosh(2*hv*t))
for tt in [S.Rational(1,10),S.Rational(1,2),S.Rational(2)]:
    # sinh(2t)>2t, analytic from derivative cosh-1; evaluated as a control.
    ck('origin_duration_below_floor_free_bound_'+str(tt),S.sinh(2*tt)>2*tt)
z=S.symbols('z',positive=True)
eq('sinh_gap_at_zero',(S.sinh(z)-z).subs(z,0))
eq('sinh_gap_positive_derivative',S.diff(S.sinh(z)-z,z)-2*S.sinh(z/2)**2)
ck('sinh_gap_derivative_positive',(2*S.sinh(z/2)**2).is_positive)

# Prescribed de Sitter geometry with constant positive density fails the charge
# premise. This is a bookkeeping probe, not an asserted full scalar solution.
rho0=S.symbols('rho0',positive=True)
eq('deSitter_nonconserved_positive_bath_charge',S.diff(rho0*S.exp(4*t),t)-4*rho0*S.exp(4*t))
ck('deSitter_charge_bound_fails_in_past',S.limit(S.exp(4*t),t,-S.oo)==0)
# Curved full-action constant-origin histories were established separately.
# This script makes no assertion that algebraic q>=1/3 data solve the action.
Hneg=-S.Rational(1); Llarge=S.Rational(6,5); qlarge=S.Rational(3,4); wlarge=Llarge**2/qlarge
ck('large_q_kinematic_sign_counterexample',Hneg+Llarge>0 and 3*Hneg**2-wlarge>0)
ck('large_q_outside_candidate_domain',qlarge>S.Rational(1,3))
result={'passed':sum(r['passed'] for r in rows),'failed':sum(not r['passed'] for r in rows),'checks':rows,'candidate_envelopes':examples,'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Exact conditional physical-clock identities and finite rational/known-history controls; no measured age, actual environment or state selection. Envelope controls are not full histories.'}
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
for row in rows:
    if not row['passed']:print('FAILED',row)
sys.exit(bool(result['failed']))
