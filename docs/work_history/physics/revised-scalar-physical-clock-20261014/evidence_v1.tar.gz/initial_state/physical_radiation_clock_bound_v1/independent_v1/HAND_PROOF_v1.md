# Independent hand derivation before executable controls

This unit checks the supplied clock source/protocol v2 without author code or results. The prior finite-mass proof is reused only through its frozen report, corrected source and receipt af527b7be8f1c0e00d30b4118e24b6436332e3e08de03d7ad5e7ffded6b82098. Its92 artifacts/five source pairs were rehashed, and its180/0 is not rerun or counted as new science.

## Orientation and the preliminary estimate

The action has scalar density Qw+V and pressure Qw-V, because there is no extra1/2 before K. In the stipulated flat homogeneous sector, positive selected bath and nonnegative remaining energy imply 3H^2>w>=0. With L=b.v and q<=qbar<1/3, Cauchy gives |L|<=sqrt(qbar w)<sqrt(3qbar)|H| for qbar>0. At qbar=0, L=0. H is nonzero at every regular event. Its sign is constant on a connected regular interval; positive final H_J=(H+L)/A therefore selects H>0 and then H_J>0 throughout. No choice of an expanding branch at all past points is inserted independently.

Let x=a_E/a_E0. Since H>0, x in(0,1] is a good earlier-event coordinate. From -c<=d ln A/d ln a_E<=c, integration from the earlier point to the final point gives A(x)<=A0 x^-c. The lower logarithmic slope, not the upper one, gives this past upper envelope. The same fixed R for all past events gives H>=sqrt(rho_E0/(3QR))x^-2. Integrating physical dt_J=A dx/(xH) proves the preliminary expression, with integrand x^(1-c) and denominator2-c. The integral would converge for c<2, but its physical sign argument uses the narrower c<1. These envelopes are not assumed simultaneously attainable in a scalar solution.

## Joint completion and physical clock

For qbar>0, w-L^2/qbar>=0. Expanding the claimed right side of Eq9 gives

 3qbar H^2+4HL+L^2+(4-3qbar)(w+(V+rho_o)/Q)/3.

Substituting 3H^2=w+(V+rho_o+rho_B)/Q converts it exactly to

 (2H+L)^2-(4-3qbar)rho_B/(3Q).

Each remaining square/energy term is nonnegative. The root sign is justified separately: H>0 and |L|<=cH imply 2H+L>=(2-c)H>0. Taking a square root before proving that sign would be invalid.

For Phi=A a_E^2, ordinary differentiation gives dot_E Phi=A a_E^2(L+2H). Dividing by dt_J/dt_E=A cancels A exactly:

 dPhi/dt_J=a_E^2(L+2H)
    >=sqrt[(4-3qbar)rho_B a_E^4/(3Q)]
    >=vmin=sqrt[(4-3qbar)D0/(3QR)]>0.

Integrating from any earlier finite regular event i gives vmin Delta t_J<=Phi0-Phi_i<Phi0. Since Phi_i>0, the finite interval bound is strict; a supremum over intervals may equal Phi0/vmin. No point with Phi=0 or a regular infinite endpoint is assumed to exist. A chart boundary at positive a_E does not weaken the interval estimate, but its type or extendibility is not determined.

The normalization is Phi0/sqrt(D0)=A0/sqrt(rho_E0)=1/sqrt(C0 rho_J0), because rho_E0=A0^4 rho_J0 and C0=A0^2. Consequently the denominator is sqrt(4-3qbar). The exact comparison [4-c^2]-(2-c)^2=2c(2-c)>0 for0<c<1 proves improvement over the preliminary bound. qbar=0 must be handled directly with L=0; the same endpoint expression has denominator2 and does not require dividing by qbar.

The instantaneous algebraic equality configuration has V+rho_o=0, w=L^2/qbar and L=-3qbar H/2. It costs scalar kinetic energy: rho_B/(3Q)=H^2(1-3qbar/4)>0. This configuration does not by itself solve an evolution problem or saturate the integrated inequality. In the candidate, q=a/J<a at finite fields, so even this equality with qbar=a is generally only an envelope equality, not a realized finite-field state.

## Candidate metric and calibration

For the supplied finite chart, b=(alpha/F,0,0) and K_uu=J/F^2 give q=a/J, with J=1+(1-3a)sE>1, a=(1-k)(1+3k)/4 and 1-3a=(1-3k)^2/4>0. Thus qbar=a<1/3 is valid throughout the finite chart at fixed0<k<1/3. All kinetic diagonal entries and all added potential terms are positive/nonnegative in the supplied domain. The proof uses V>=0, not the candidate's stronger Hv-dependent floor. It uses neither a global maximum for A nor a derived value of Hv. It still retains Q/C0 or a supplied calibration at the final event.

G_bare0=C0/(8piQ) and gamma=G_cal/G_bare0 give Q/C0=gamma/(8piG_cal), not its reciprocal. The same-background ceiling gamma<=(1+eta)(1+q0)<4(1+eta)/3 is an additional stipulated principal-response/error hypothesis, not a measured fact proved by the clock inequality. Substituting it and qbar<1/3 gives exactly the two strict inequalities of Eq13. The strictness comes from q0<1/3 and sqrt(4-3qbar)>sqrt3; a supremum on the first bound creates no gap in this chain.

For a distinct calibration environment, the candidate's action algebra also gives the useful global identity

 (1+k)-C(1+q(C))=4(1+k)(C-1)^2/[4-3(1+k)C]>=0,

where q(C)=(4a-(1+k)C)/[4-3(1+k)C] and0<C<Cmax=4a/(1+k). The denominator is positive because12a<4. Thus the stated principal ceiling (1+eta)(1+k)/C0 is consistent with a common fixed-k action, but it retains C0. Applying it still needs the separate calibration/error premise. No parent local-response code or data is used here.

## Charge reuse and explicit failure domains

The fixed-entropy finite-mass report supplies D_final/D_earlier<=R with R=(11/4)^(1/3) for the same total isolated equilibrium bath. Inverting this positive inequality gives the exact required D_earlier>=D0/R, irrespective of temperature ordering or conformal nonmonotonicity. Its species, fixed physical masses, zero chemical potentials, reversible equilibrium and isolation assumptions are all retained. No quadrature or thermodynamic proof is rerun. A different epoch/component, entropy transfer, decoupled temperature sector or unbounded past-dependent R is not covered automatically.

With positive spatial curvature the Friedmann substitution instead gives Eq9-left=Eq9-right-(4-3qbar)kappa. Dropping this term is invalid. A direct counterprobe is the exact constant-origin candidate history Q=Hv=1, a_E^2=3+2cosh(2t_E), Kc=6 and conserved radiation charge D=15. It satisfies the curved constraint and Raychaudhuri equations, has a future expanding event and unbounded past proper time with A=1. It is outside the flatness premise, not a counterexample to the theorem.

Without the subcritical coupling premise, positive H_J alone does not fix the Einstein sign: q=1/2,H=-1,L=11/10,w=L^2/q=121/50,rho_B/Q=29/50,V=rho_o=0 satisfies the flat constraint but H_J>0 and2H+L=-9/10<0 for A=1. This local state exposes the unsafe positive square root, not a complete history.

Without a uniform charge floor, flat de Sitter with A=1,H=1,Q=1,V=0 and a positive vacuum-like selected fluid rho_B=3,p_B=-3 has arbitrary past duration and D/D0=exp[4(t-t0)]->0. It satisfies positive-energy and coupling premises but violates every finite-R past charge floor. It is deliberately not a radiation or photon/pair bath. It shows what the abstract charge condition supplies; it does not propose a matter repair.

## Planned exact and numerical controls

A constant-coupling toy model supplies independent complete general-class controls without an A cap. Set Q=1,K=1,V=0, radiation charge D=3, a_E0=A0=1, and conserved scalar momentum P!=0. Then

 v=P/a_E^3,
 H=sqrt(P^2+3a_E^2)/(sqrt3 a_E^3),
 phi(a)-phi(1)=sign(P)sqrt3 ln[a(sqrt(P^2+3)+|P|)/(sqrt(P^2+3a^2)+|P|)],
 A=exp(sqrt(qbar)[phi(a)-phi(1)]).

These obey the free-scalar, radiation and flat Einstein equations because radiation has zero trace. For P<0, A grows without bound as a->0 while Phi~a^(2-sqrt(3qbar))->0; the physical elapsed time is still integrable. I will verify the equations and integrate physical time in a and log a independently for qbar=1/12,P=-sqrt(1/5); qbar=1/4,P=-1; and qbar=1/5,P=3/5. These are exposed general-action controls, not members of the supplied positive-Hv candidate or selected cosmologies.

Pure radiation at qbar=0 provides the sharp limiting normalization. Constant-scalar radiation plus positive vacuum gives a strict lower age than its no-vacuum comparator. Power-law envelope tests are only envelope tests. Actual damaged scripts will change the joint square sign, coefficient, physical clock conversion, Phi exponent, endpoint C normalization, past-A orientation and calibration substitution. All failed attempts and original sources will be retained.
