# Independent check of the physical radiation clock bound

The conditional bound in DERIVATION_v2.md is supported. The joint Friedmann/coupling square is exact, the positive-root choice follows from the stated orientation assumptions, and physical-time differentiation of Phi=A a_E^2 cancels A correctly. The endpoint normalization is

    T_J,max <= sqrt[3Q R/(C0 rho_B,J,0)]/sqrt(4-3qmax).

This bound requires no separately supplied global cap on A or positive vacuum-energy scale. It still requires flatness, positive selected bath density, nonnegative remaining energy, a uniform subcritical coupling bound, a uniform charge comparison and the stated physical final-event/calibration conditions. No source correction was identified.

The new independent calculation completed **186/0**, and all seven actual damaged scripts exited 1 with their intended failed identities. The finite-mass charge result is reused through its immutable source/report/receipt; its **180/0 was not rerun or added** to the new count. Final evidence verification completed **198/0 metadata checks**, not a second science run. No producer code, results, profile or grid was read or run.

## Frozen inputs and honest dependency reuse

| Input | SHA-256 |
| --- | --- |
| Current DERIVATION_v2.md | 512fcbb9c7bdf1a61f47c16386b6f030ca233bb15297ba227afe7ed1134df7d3 |
| Current PROTOCOL_v2.json | 8a0795b00de10e68fcd56e36c0bca7c0ac6907009fe289972facec89bf44f1a3 |
| Supplied complete-action confinement note | 39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000 |
| Reused finite-mass REPORT_v1.md | d1d48e0b25d653505dc75747dad60217bcf7cf28d90d88b7b4b4e552c86d3808 |
| Reused frozen finite-mass DERIVATION_v2.md | 356b3cdbc71d862223da2e6197f09eab816807afcf40bd17a3ec3335e8da6e23 |
| Reused finite-mass RECEIPT_v1.json | af527b7be8f1c0e00d30b4118e24b6436332e3e08de03d7ad5e7ffded6b82098 |
| Reused finite-mass MANIFEST_v1.json | e7a805ff48e89d68c6e09079eee59af5d97bb73b3c1a7b317ea087131ac53459 |
| Reused finite-mass correction receipt | 7f9e357ebf4df089d220cfc442e8d1bd1ac9fac174685024e70bfea0f8001883 |

SOURCE_MANIFEST_v1.json gives all eight original/snapshot paths, byte counts and roles. These copies preceded the independent hand derivation and computation. HAND_PROOF_v1.md and CONTROL_PROTOCOL_v1.json were frozen before checker implementation. The supplied canonical note contributes its complete action, not its separate future-confinement theorem.

The finite-mass dependency was verified by rehashing its 92 artifacts and five live/snapshot source pairs: 97/0 initial identity checks. The same originals were checked again during final metadata validation. Its original 177/0 checker-quality defect and corrected 180/0 remain in the bound original receipt; they are neither relabeled nor rerun here. Only its fixed-entropy total-bath charge range is used.

## Orientation and the weaker preliminary bound

The action has scalar energy density Qw_phi+V, because its kinetic Lagrangian contains -Q K_AB partial phi^A partial phi^B without an additional 1/2. The flat positive-energy constraint and positive bath imply H is nonzero and w_phi<3H^2. Cauchy-Schwarz gives |L|<=sqrt(qmax w_phi)<=c|H|, where c=sqrt(3qmax)<1. At qmax=0, L=0 directly.

A negative H at the final event would imply H+L<0, contradicting H_J,0>0. Since H is continuous and nowhere zero on the connected regular interval, H>0 throughout. Then H+L>0 throughout as well. This sign conclusion is derived rather than inserted as an expanding branch at every past point.

For x=a_E/a_E0 in (0,1], integrating the lower logarithmic slope d ln A/d ln a_E>=-c from an earlier event to the final event gives A<=A0 x^-c. Reversing the integration orientation would incorrectly replace this upper past envelope by x^c. The charge condition gives H>=sqrt[rho_E0/(3QR)]x^-2. Physical dt_J=A dx/(xH) therefore integrates with x^(1-c), giving the source's denominator 2-c and finite-interval factor 1-x_i^(2-c).

The integral converges for c<2, but that fact does not supply the source's physical orientation conclusion. The source correctly retains c<1. The two preliminary envelopes also need not be jointly attainable in a scalar solution, since conformal motion costs scalar kinetic energy.

## Exact joint completion and supremum

For qbar=qmax>0, w_phi-L^2/qbar>=0. Expanding the claimed right side of Eq. 9 gives

    3qbar H^2+4HL+L^2
       +(4-3qbar)[w_phi+(V+rho_o)/Q]/3.

Using the flat Friedmann equation converts this exactly to

    (2H+L)^2-(4-3qbar)rho_B,E/(3Q).

Every term in the unexpanded right side is nonnegative. The root sign is a distinct required step: the already established H>0 and |L|<=cH imply 2H+L>=(2-c)H>0. A squared inequality alone would not justify taking the positive root.

Differentiating Phi=A a_E^2 in Einstein time gives A a_E^2(L+2H). Dividing by dt_J/dt_E=A yields

    dPhi/dt_J=a_E^2(L+2H)
       >=sqrt[(4-3qbar)D0/(3QR)]=v_min>0.

There is no bound on A in this step. Integrating between finite regular events yields

    v_min Delta t_J<=Phi0-Phi_i<Phi0.

Strictness at a finite earlier event follows from Phi_i>0. The supremum over regular past intervals may reach the non-strict limiting upper bound; no regular event with Phi=0 is asserted. A chart boundary at positive Einstein radius does not invalidate the interval inequality, but its geometric type or extendibility is not determined.

The frame conversion rho_E0=A0^4 rho_J0 gives

    Phi0/sqrt(D0)=A0/sqrt(rho_E0)=1/sqrt(C0 rho_J0).

The rho_J0 here is a physical density, not the normalized density variable appearing elsewhere in the canonical action note. This proves the stated endpoint coefficient. At qbar=0, L=0 gives denominator 2 directly, without the division by qbar in Eq. 9.

The improvement over the weaker result follows from

    (4-c^2)-(2-c)^2=2c(2-c)>0,       0<c<1.

Instantaneous algebraic equality is possible in the general class with V+rho_o=0, w=L^2/qbar and L=-3qbar H/2. Its positive bath fraction is rho_B/(3Q)=H^2(1-3qbar/4). This does not construct a trajectory saturating the integrated bound. In the candidate, q<a at every finite field point, so equality with the envelope qbar=a should not be represented as a selected finite-field state. No optimality for qbar>0 is established or claimed.

## Candidate applicability and calibration limits

For the supplied action, b=(alpha/F,0,0) and K_uu=J/F^2 give q=a/J. The exact identity 1-3a=(1-3k)^2/4>0 gives J>1 and q<a<1/3 for fixed 0<k<1/3. All kinetic diagonal entries are positive on the finite chart. All potential additions are nonnegative, so the candidate satisfies the theorem's V>=0 premise without needing its stronger Hv-dependent floor. The proof selects neither a state nor a numerical vacuum scale.

The physical clock bound still contains Q/C0. Defining positive G_cal and gamma0=G_cal/[C0/(8piQ)] gives Q/C0=gamma0/(8piG_cal), exactly as in Eq. 12. This is an algebraic conversion, not a measured identification of bare and laboratory gravity.

The further ceiling gamma0<=(1+eta)(1+q0)<4(1+eta)/3 is an additional same-background principal-response and error hypothesis. Substitution, followed by sqrt(4-3qbar)>sqrt(3), gives both strict inequalities in Eq. 13. This check verifies those conditional manipulations; it does not establish the required local-source hierarchy, errors, environment matching or an actual calibrated value.

For a distinct calibration environment the action algebra gives

    (1+k)-C(1+q(C))
      =4(1+k)(C-1)^2/[4-3(1+k)C]>=0.

Its denominator is positive on 0<C<4a/(1+k), because 12a<4. This supports the stated principal ceiling (1+eta)(1+k)/C0 when the same fixed action and calibration hypothesis apply. The unmeasured C0 remains. It cannot be replaced by the same-background ceiling merely to obtain a numerical age statement.

## Matter-charge scope and explicit challenges

The reused finite-mass result gives D_final/D_earlier<=R, with R=(11/4)^(1/3) for the same isolated fixed-entropy ideal photon/pair bath. Inverting that positive inequality gives D_earlier>=D0/R. It does not require a temperature ordering. The species, common temperature, fixed physical masses, zero chemical potentials, reversible equilibrium and isolation assumptions remain in force. No finite-mass quadrature or thermodynamic proof was rerun here.

A fixed R must control every earlier event in the interval. A different component, additional species, separate temperatures, entropy transfer or a past-dependent unbounded R needs another argument. Present radiation density alone does not prove the charge comparison across an arbitrary real thermal history.

Three concrete challenges distinguish the theorem from stronger unsupported statements:

1. **Positive spatial curvature.** With curved Friedmann, the left side of Eq. 9 equals its proposed square/energy right side minus (4-3qbar)kappa. The omitted term matters. A directly verified constant-origin candidate control with Q=Hv=1, A=1, a_E^2=3+2cosh(2t_E), Kc=6 and conserved radiation charge D=15 satisfies the curved constraint, Raychaudhuri and radiation equations. It has H=3/11 at t_E=log(2)/2 and unbounded past proper time. It lies outside flatness and is not excluded by this theorem.
2. **Incorrect root orientation.** The local flat positive-energy state q=1/2,H=-1,L=11/10,w=121/50,rho_B/Q=29/50,V=rho_o=0 has H_J>0 but 2H+L=-9/10. Its c=sqrt(3/2) is below 2 yet above 1. The squared identity still holds; the positive-root inference fails. This is an outside-domain local state, not an asserted full history. It does not claim that every boundary point qbar>=1/3 must fail.
3. **No uniform charge floor.** General constant-coupling flat de Sitter with H=1,Q=1,V=0 and a selected vacuum-like fluid rho_B=3,p_B=-3 has positive energy and unbounded past proper time, while D/D0=exp(4t)->0. It violates every finite-R past floor. This deliberately is not a radiation or photon/pair bath and supplies no matter-repair proposal.

## Independent complete controls without an A cap

A distinct general-class model has Q=K=1,V=0, constant coupling norm qbar, radiation charge D=3 and a_E0=A0=1. For conserved scalar momentum P!=0,

    v=P/a_E^3,
    H=sqrt(P^2+3a_E^2)/(sqrt(3) a_E^3),
    phi(a)-phi(1)=sign(P)sqrt(3)
      log[a(sqrt(P^2+3)+|P|)/(sqrt(P^2+3a^2)+|P|)],
    A=exp[sqrt(qbar)(phi(a)-phi(1))].

The independent checker verifies the free scalar equation, flat constraint, Raychaudhuri equation and scalar primitive. Traceless radiation does not source the scalar. For P<0, A grows without a global past cap as a_E approaches zero, while Phi tends to zero with positive power 2-sqrt(3qbar). Thus this is a useful complete control of the no-cap argument, rather than an arbitrary pair of envelopes.

These are general-action controls, not exact members of the supplied positive-Hv candidate or selected cosmologies. Physical time was integrated independently in a_E and -log(a_E), with maximum difference 5.78e-15 and no integration warning.

| qbar | P | Physical elapsed time | Joint upper bound | Preliminary upper bound |
| --- | --- | --- | --- | --- |
| 1/12 | -sqrt(1/5) | 0.4886246178 | 0.5163977795 | 0.6666666667 |
| 1/4 | -1 | 0.4590343338 | 0.5547001962 | 0.8818539704 |
| 1/5 | 3/5 | 0.3686472505 | 0.5423261445 | 0.8160578439 |

The no-vacuum qbar=0 pure-radiation control saturates the limiting normalization. A constant-scalar radiation-plus-positive-vacuum example has strictly smaller elapsed time than its direct no-vacuum comparator. Its constant A along a trajectory does not imply the candidate's field-space coupling norm is zero. Numerical solution controls supplement the exact proof and do not establish uniformity or optimality by sampling.

## Actual commands, damaged controls and evidence

The baseline script check_clock_bound_v1.py has SHA-256 7f2ae932d365157bd3bcdf6ec039309a11cc241c7d26d7d1eb24fd635b922d39. It actually ran from 2026-10-14T12:13:07.779857Z to 12:13:09.108487Z, completed 186/0 and exited 0. Python 3.12.8, SymPy 1.14.0 and SciPy 1.17.0 were used. Exact argv, cwd, UTC intervals, script hashes, child exits and stdout/stderr hashes are recorded for every execution and consolidated in COMMANDS_v1.json.

| Actual one-edit damaged script | Pass / fail | Child exit |
| --- | --- | --- |
| Reverse the L sign in the joint square | 175 / 11 | 1 |
| Change 4-3qbar to 4+3qbar | 173 / 13 | 1 |
| Omit conversion from Einstein to physical time | 185 / 1 | 1 |
| Change Phi=A a_E^2 to A a_E | 185 / 1 | 1 |
| Put C0^2 in the endpoint density denominator | 184 / 2 | 1 |
| Reverse the past-A envelope | 152 / 34 | 1 |
| Invert the calibration ratio gamma | 184 / 2 | 1 |

The wrong joint coefficient fails both the exact identity and two complete toy-history duration controls. For example, its false bound 0.4850712501 is below the actual 0.4886246178 duration in the first toy history. All seven damaged scripts, exact diffs, outputs and intended failed identities are retained. No unexpected checker, quadrature, tool or metadata failure occurred in this unit. No failure from the reused finite-mass unit is omitted from its immutable dependency receipt.

Final evidence validation is 198/0 metadata checks. It verifies eight live/snapshot bindings, every recorded child/output identity, all seven damaged failures and the original dependency's 92 artifacts/five source pairs. These checks are not a new execution of either science result.

## Bounded disposition

The original reviewer confirms that the final author source and protocol remain byte-identical to their independently checked v2 snapshots. No amendment is required within this scope. The conclusion is a bound on the supremum of regular past physical duration under the stipulated flat positive-energy and matter/coupling hypotheses. It is not an age of the observed universe, a proof of a selected initial state, a calibration measurement, a theorem of spacetime inextendibility or a general exclusion of curved histories.

MANIFEST_v1.json binds every artifact except itself and RECEIPT_v1.json; the receipt binds the manifest, report, sources, actual commands, explicit dependency reuse and limited conclusion. All new output is confined to this independent_v1 directory. Prior seals and author sources remain untouched. No Git, runtime, settings, PR, audit or authority operation was performed. No further writes follow the final seal verification.
