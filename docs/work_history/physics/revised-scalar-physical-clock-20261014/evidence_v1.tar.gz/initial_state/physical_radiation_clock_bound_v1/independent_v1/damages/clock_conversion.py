"""Independent clock inequalities and general-class solution controls."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys,math,warnings
import sympy as s
import scipy
from scipy.integrate import quad
SQUARE_L_SIGN = 1
JOINT_Q_SIGN = -1
CLOCK_A_POWER = 0
PHI_POWER = 2
ENDPOINT_C_POWER = 1
PAST_A_SIGN = -1
CALIBRATION_GAMMA_POWER = 1
rows=[];evidence={};warning_rows=[]
def check(n,b,d=None):rows.append({'name':n,'passed':bool(b),'detail':d})
def zero(n,e):
 z=s.simplify(e);check(n,z==0,str(z))
def near(n,a,b,tol=2e-10):
 gap=abs(a-b);check(n,math.isfinite(a) and math.isfinite(b) and gap<=tol*max(1,abs(a),abs(b)),{'actual':a,'expected':b,'absolute_gap':gap,'tolerance':tol})
q,Q,H,L,w,V,o,rho,kappa=s.symbols('q Q H L w V o rho kappa',positive=True)
B=4+JOINT_Q_SIGN*3*q
square=(3*q*H+SQUARE_L_SIGN*2*L)**2/(3*q)+B*(w-L**2/q)/3+B*(V+o)/(3*Q)
left=(2*H+L)**2-B*rho/(3*Q)
flat_rho=Q*(3*H**2-w)-V-o
zero('joint_Friedmann_square',left.subs(rho,flat_rho)-square)
zero('curvature_term_required',left.subs(rho,flat_rho+3*Q*kappa)-square+B*kappa)
# The physical clock must be applied before cancelling A.
A,a=s.symbols('A a',positive=True)
phiE_dot=A*a**PHI_POWER*(L+PHI_POWER*H)
phiJ_dot=phiE_dot/A**CLOCK_A_POWER
zero('physical_Phi_clock_derivative',phiJ_dot-a**2*(2*H+L))
D0,R,rhoJ,A0,a0=s.symbols('D0 R rhoJ A0 a0',positive=True)
rhoE0=A0**4*rhoJ
Phi0=A0*a0**2;Dactual=rhoE0*a0**4
endpoint=Phi0/s.sqrt(Dactual)
claimed=1/s.sqrt((A0**2)**ENDPOINT_C_POWER*rhoJ)
zero('endpoint_C_normalization',endpoint-claimed)
zero('charge_to_uniform_Phi_speed',(a**2*s.sqrt(B*(D0/(R*a**4))/(3*Q)))**2-B*D0/(3*Q*R))
zero('finite_interval_clock_normalization',(Phi0*s.sqrt(3*Q*R/(B*Dactual)))**2-3*Q*R/(B*(A0**2)**ENDPOINT_C_POWER*rhoJ))
# Preliminary integral and signs, with actual rational domain controls.
x,c,xi=s.symbols('x c xi',positive=True)
prelim=(1-xi**(2+PAST_A_SIGN*c))/(2+PAST_A_SIGN*c)
zero('preliminary_integral_denominator',prelim-(1-xi**(2-c))/(2-c))
zero('preliminary_antiderivative',s.diff(x**(2-c)/(2-c),x)-x**(1-c))
zero('joint_improves_separate_squared',4-c*c-(2-c)**2-2*c*(2-c))
for cc in [s.Rational(1,6),s.Rational(1,2),s.Rational(4,5),s.Rational(99,100)]:
 check('positive_orientation_margin_'+str(cc),1-cc>0 and 2-cc>0)
 check('joint_denominator_larger_'+str(cc),s.sqrt(4-cc*cc)>2-cc)
 for xx in [s.Rational(1,100),s.Rational(1,4),s.Rational(3,4)]:
  actual_A=xx**(-cc);claimed_A=xx**(PAST_A_SIGN*cc)
  check('past_A_upper_envelope_'+str((cc,xx)),actual_A<=claimed_A)
  val=prelim.subs({xi:xx,c:cc})
  correct=(1-xx**(2-cc))/(2-cc)
  zero('finite_interval_integral_'+str((cc,xx)),val-correct)
  check('finite_preliminary_bound_strict_'+str((cc,xx)),0<val<1/(2-cc))
zero('subcritical_boundary_joint_limit',s.limit(s.sqrt(4-3*q),q,s.Rational(1,3),dir='-')-s.sqrt(3))
# The optimal instantaneous state verifies the cost of conformal motion.
instant=[]
for qq in [s.Rational(1,48),s.Rational(1,12),s.Rational(1,5),s.Rational(8,25)]:
 hh=s.Integer(1);ll=-3*qq/2;ww=ll*ll/qq;rr=3-ww
 zero('instantaneous_square_equality_'+str(qq),(left-square).subs({q:qq,Q:1,H:hh,L:ll,w:ww,V:0,o:0,rho:rr}))
 zero('instantaneous_nonnegative_remainder_zero_'+str(qq),square.subs({q:qq,Q:1,H:hh,L:ll,w:ww,V:0,o:0}))
 check('instantaneous_positive_bath_and_physical_rate_'+str(qq),rr>0 and hh+ll>0)
 instant.append({'qbar':str(qq),'H':str(hh),'L':str(ll),'w':str(ww),'rho_over_Q':str(rr),'scope':'instantaneous algebraic equality data, not integrated saturation'})
evidence['instantaneous_states']=instant
# A real outside-domain local state disproves an automatic positive square root.
qbad=s.Rational(1,2);Hbad=-1;Lbad=s.Rational(11,10);wbad=Lbad**2/qbad;rbad=3-wbad
zero('supercritical_local_constraint',3*Hbad**2-wbad-rbad)
check('supercritical_physical_expansion',Hbad+Lbad>0)
check('supercritical_Phi_derivative_negative',2*Hbad+Lbad<0)
check('c_less_than_two_is_insufficient',1<s.sqrt(3*qbad)<2)
zero('supercritical_square_still_holds',(left-square).subs({q:qbad,Q:1,H:Hbad,L:Lbad,w:wbad,V:0,o:0,rho:rbad}))
evidence['orientation_counterprobe']={'q':str(qbad),'H':Hbad,'L':str(Lbad),'w':str(wbad),'rho_over_Q':str(rbad),'twoH_plus_L':str(2*Hbad+Lbad),'scope':'outside qbar<1/3; local flat positive-energy state only'}
# Candidate action positivity and q envelope are independent of its potential scale.
k,E,u,X,Y,nu=s.symbols('k E u X Y nu',positive=True)
aa=(1-k)*(1+3*k)/4;alpha=s.sqrt(aa);ss=(1+k)/(k*(1-3*k));beta=1-3*aa
F=1+ss*E;J=1+beta*ss*E
zero('candidate_beta_identity',beta-(1-3*k)**2/4)
zero('candidate_coupling_norm',(alpha/F)**2/(J/F**2)-aa/J)
zero('candidate_coupling_gap',aa-aa/J-aa*beta*ss*E/J)
C=(1+ss)*E/F;Cenv=s.symbols('Cenv',positive=True)
qC=(4*aa-(1+k)*Cenv)/(4-3*(1+k)*Cenv)
zero('candidate_C_chart_identity',qC.subs(Cenv,C)-aa/J)
zero('environment_principal_maximum',(1+k)-Cenv*(1+qC)-4*(1+k)*(Cenv-1)**2/(4-3*(1+k)*Cenv))
for kk in [s.Rational(1,13),s.Rational(2,11),s.Rational(3,10)]:
 ab=aa.subs(k,kk);cm=4*ab/(1+kk)
 check('candidate_parameter_envelope_'+str(kk),s.Rational(1,4)<ab<s.Rational(1,3))
 for ee in [s.Rational(1,7),s.Rational(5,3),s.Integer(8)]:
  qb=s.simplify((aa/J).subs({k:kk,E:ee}))
  check('candidate_q_strictly_inside_envelope_'+str((kk,ee)),0<qb<ab)
 for ce in [cm/5,s.Integer(1),cm*s.Rational(9,10)]:
  gap=s.simplify(((1+k)-Cenv*(1+qC)).subs({k:kk,Cenv:ce}))
  check('environment_ceiling_'+str((kk,ce)),gap>=0)
# Origin is stationary for the complete supplied scalar potential.
Eu=s.exp(2*alpha*u);Fu=1+ss*Eu
U=s.Rational(3,2)+3*ss*(Eu-1)**2/(2*Fu**2)+(k/2)*X**2*s.exp(-(1-k)*u/alpha)+(k/3)*Y**2*s.exp(-(1+k)*u/alpha)+nu*(1+ss)*u**2/(2*Fu**2)
zero('candidate_origin_potential',U.subs({u:0,X:0,Y:0})-s.Rational(3,2))
for field in [u,X,Y]:zero('candidate_origin_gradient_'+str(field),s.diff(U,field).subs({u:0,X:0,Y:0}))
zero('candidate_origin_conformal_factor',C.subs(E,1)-1)
# Calibration is conditional algebra, not a measured input.
gamma,Gcal,C0,eta=s.symbols('gamma Gcal C0 eta',positive=True)
QoverC=gamma**CALIBRATION_GAMMA_POWER/(8*s.pi*Gcal)
zero('calibration_substitution',QoverC-gamma/(8*s.pi*Gcal))
zero('calibrated_joint_bound_squared',3*R*QoverC/(B*rhoJ)-3*R*gamma/(8*s.pi*Gcal*B*rhoJ))
q0=s.symbols('q0',positive=True)
for qq in [s.Rational(1,20),s.Rational(2,9),s.Rational(8,25)]:
 check('same_background_strict_gamma_ceiling_'+str(qq),1+qq<s.Rational(4,3))
 check('strict_calibrated_denominator_'+str(qq),s.sqrt(4-3*qq)>s.sqrt(3))
zero('distinct_environment_retains_C0',3*R*(1+eta)*(1+k)/(8*s.pi*Gcal*C0*B*rhoJ)-3*R*((1+eta)*(1+k)/C0)/(8*s.pi*Gcal*B*rhoJ))
# Exact qbar=0 radiation normalization, and a positive-vacuum comparison.
t=s.symbols('t',positive=True)
aR=s.sqrt(2*t);HR=1/(2*t);rhoR=3/(4*t*t)
zero('pure_radiation_constraint',3*HR**2-rhoR)
zero('pure_radiation_clock',s.diff(aR**2,t)-s.sqrt(4*3/3))
zero('qbar_zero_bound_saturation',s.Rational(1,2)-s.sqrt(3/3)/2)
zero('finite_radiation_interval_deficit',s.Rational(1,2)-t-(1-aR**2)/2)
av=s.sqrt(s.sinh(2*t));Hv=s.coth(2*t);rhov=3/s.sinh(2*t)**2
zero('vacuum_radiation_constraint',(3*Hv**2-3-rhov).rewrite(s.exp))
zero('vacuum_radiation_Raychaudhuri',(s.diff(Hv,t)+2*rhov/3).rewrite(s.exp))
tf=s.asinh(2)/2
zero('vacuum_example_final_density',(rhov.subs(t,tf)-s.Rational(3,4)).rewrite(s.exp))
check('vacuum_example_age_strict',s.N(tf,60)<1)
# A complete curved candidate control, not a flat history.
tr=s.symbols('tr',real=True);Yc=3+2*s.cosh(2*tr);Hc=s.diff(Yc,tr)/(2*Yc);rc=15/Yc**2;kapc=6/Yc
zero('closed_history_constraint',(3*(Hc**2+kapc)-3-rc).rewrite(s.exp))
zero('closed_history_Raychaudhuri',(s.diff(Hc,tr)-kapc+2*rc/3).rewrite(s.exp))
zero('closed_history_radiation',(s.diff(rc,tr)+4*Hc*rc).rewrite(s.exp))
zero('closed_history_positive_final_H',(Hc.subs(tr,s.log(2)/2)-s.Rational(3,11)).rewrite(s.exp))
check('closed_history_unbounded_past_clock',s.integrate(1,(tr,-s.oo,s.log(2)/2))==s.oo)
check('closed_history_positive_radius',s.cosh(2*tr).is_positive)
evidence['curvature_counterprobe']={'a_E_squared':'3+2cosh(2t_E)','Q':1,'Hv':1,'Kc':6,'radiation_charge':15,'A':1,'H_final':'3/11 at t_E=log(2)/2','past_physical_duration':'unbounded','scope':'exact curved constant-origin candidate solution; outside flatness'}
# Without a uniform charge floor the abstract positive-bath theorem has no age bound.
ads=s.exp(tr);Hds=s.Integer(1);rds=s.Integer(3);pds=-rds
zero('no_charge_floor_flat_constraint',3*Hds**2-rds)
zero('no_charge_floor_conservation',s.diff(rds,tr)+3*Hds*(rds+pds))
zero('no_charge_floor_limit',s.limit(rds*ads**4/3,tr,-s.oo))
check('no_charge_floor_infinite_past',s.integrate(1,(tr,-s.oo,0))==s.oo)
evidence['charge_counterprobe']={'a_E':'exp(t_E)','A':1,'H':1,'Q':1,'rho_B':3,'p_B':-3,'D_over_D0':'exp(4t_E)','scope':'general constant-coupling vacuum-like bath, not radiation or candidate thermal history; violates every finite R floor'}
# Exact general-class free-scalar plus radiation solution.
P=s.symbols('P',positive=True)
Ha=s.sqrt(P**2+3*a*a)/(s.sqrt(3)*a**3)
vpos=P/a**3
zero('toy_flat_constraint',3*Ha**2-vpos**2-3/a**4)
zero('toy_Raychaudhuri',a*Ha*s.diff(Ha,a)+vpos**2+2/a**4)
zero('toy_scalar_conservation',a*Ha*s.diff(vpos,a)+3*Ha*vpos)
ratio=a*(s.sqrt(P**2+3)+P)/(s.sqrt(P**2+3*a*a)+P)
phi=s.sqrt(3)*s.log(ratio)
zero('toy_scalar_primitive',s.diff(phi,a)*a*Ha-vpos)
zero('toy_final_phi_normalization',phi.subs(a,1))
zero('toy_past_ratio_linear_limit',s.limit(ratio/a,a,0,dir='+')-(s.sqrt(P*P+3)+P)/(2*P))
# Two distinct coordinates integrate the same physical proper time.
cases=[(s.Rational(1,12),-s.sqrt(s.Rational(1,5))),(s.Rational(1,4),s.Integer(-1)),(s.Rational(1,5),s.Rational(3,5))]
toy=[]
for qr,pr in cases:
 qq=float(qr);pp=float(pr);mag=abs(pp);sign=1 if pp>0 else -1;cc=math.sqrt(3*qq)
 const=math.log(math.sqrt(mag*mag+3)+mag)
 def logA(loga):
  av=math.exp(loga) if loga>-745 else 0.
  return sign*cc*(loga+const-math.log(math.sqrt(mag*mag+3*av*av)+mag))
 def ta(av):
  if av==0:return 0.
  la=math.log(av)
  return math.exp(0.5*math.log(3)+logA(la)+2*la-0.5*math.log(mag*mag+3*av*av))
 def tu(uu):
  la=-uu;av=math.exp(la) if la>-745 else 0.
  return math.exp(0.5*math.log(3)+logA(la)+3*la-0.5*math.log(mag*mag+3*av*av))
 with warnings.catch_warnings(record=True) as caught:
  warnings.simplefilter('always')
  duration,err_a=quad(ta,0,1,epsabs=2e-12,epsrel=2e-12,limit=300)
  alternate,err_u=quad(tu,0,math.inf,epsabs=2e-12,epsrel=2e-12,limit=300)
 for warn in caught:warning_rows.append({'qbar':str(qr),'P':str(pr),'warning':str(warn.message)})
 Bnum=4+JOINT_Q_SIGN*3*qq;bound=1/math.sqrt(Bnum);weak=1/(2-cc)
 near('toy_dual_clock_integral_'+str((qr,pr)),duration,alternate)
 check('toy_joint_duration_bound_'+str((qr,pr)),0<duration<bound)
 check('toy_joint_stronger_than_weak_'+str((qr,pr)),bound<weak)
 points=[]
 for av in [0.01,0.2,0.8,1.0]:
  Aval=math.exp(logA(math.log(av)));hval=math.sqrt(mag*mag+3*av*av)/(math.sqrt(3)*av**3)
  lval=math.sqrt(qq)*pp/av**3
  phi_dot=av**2*(2*hval+lval)
  check('toy_joint_Phi_speed_'+str((qr,pr,av)),phi_dot>=math.sqrt(Bnum)-2e-12)
  check('toy_positive_physical_expansion_'+str((qr,pr,av)),hval+lval>0)
  check('toy_past_A_envelope_'+str((qr,pr,av)),Aval<=av**(PAST_A_SIGN*cc)*(1+2e-12))
  points.append({'a_E':av,'A':Aval,'H_E':hval,'L':lval,'dPhi_dtJ':phi_dot})
 limit_power=2-sign*(-cc) if False else 2+sign*cc
 check('toy_Phi_zero_radius_exponent_'+str((qr,pr)),limit_power>0)
 if pp<0:check('toy_A_has_no_global_past_cap_'+str((qr,pr)),logA(-100)>20)
 toy.append({'qbar':str(qr),'P':str(pr),'duration_a_coordinate':duration,'duration_log_coordinate':alternate,'quad_error_a':err_a,'quad_error_log':err_u,'joint_bound':bound,'weak_bound':weak,'past_Phi_power':limit_power,'logA_at_log_a_minus100':logA(-100),'points':points,'scope':'complete constant-coupling general-class control; not supplied positive-Hv candidate'})
check('toy_integrations_no_warnings',not warning_rows,warning_rows)
evidence['toy_histories']=toy
result={'created_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'pass':sum(z['passed'] for z in rows),'fail':sum(not z['passed'] for z in rows),'checks':rows,'evidence':evidence,'scope':'new focused clock controls; finite-mass180/0 reused without rerun','producer_code_or_results_accessed':False,'versions':{'python':sys.version,'sympy':s.__version__,'scipy':scipy.__version__}}
out=Path(sys.argv[1]);assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pass':result['pass'],'fail':result['fail'],'failed_checks':[z for z in rows if not z['passed']],'toy_integrals':[{k:z[k] for k in ['qbar','P','duration_a_coordinate','duration_log_coordinate','joint_bound','weak_bound','logA_at_log_a_minus100']} for z in toy],'warnings':warning_rows},indent=2))
sys.exit(1 if result['fail'] else 0)
