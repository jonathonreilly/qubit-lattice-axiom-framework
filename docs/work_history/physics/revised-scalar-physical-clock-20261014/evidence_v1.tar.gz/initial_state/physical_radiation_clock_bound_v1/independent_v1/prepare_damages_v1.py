from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,difflib
here=Path(__file__).resolve().parent;source=here/'check_clock_bound_v1.py';text=source.read_text()
changes=[('joint_square_sign','SQUARE_L_SIGN = 1','SQUARE_L_SIGN = -1','joint_Friedmann_square'),('joint_coefficient','JOINT_Q_SIGN = -1','JOINT_Q_SIGN = 1','joint_Friedmann_square'),('clock_conversion','CLOCK_A_POWER = 1','CLOCK_A_POWER = 0','physical_Phi_clock_derivative'),('phi_exponent','PHI_POWER = 2','PHI_POWER = 1','physical_Phi_clock_derivative'),('endpoint_C_power','ENDPOINT_C_POWER = 1','ENDPOINT_C_POWER = 2','endpoint_C_normalization'),('past_A_orientation','PAST_A_SIGN = -1','PAST_A_SIGN = 1','preliminary_integral_denominator'),('calibration_inverse','CALIBRATION_GAMMA_POWER = 1','CALIBRATION_GAMMA_POWER = -1','calibration_substitution')]
folder=here/'damages';assert not folder.exists();folder.mkdir();rows=[]
for name,old,new,required in changes:
 assert text.count(old)==1
 changed=text.replace(old,new);script=folder/(name+'.py');script.write_text(changed)
 diff=folder/(name+'.diff');diff.write_text(''.join(difflib.unified_diff(text.splitlines(True),changed.splitlines(True),fromfile='check_clock_bound_v1.py',tofile=str(script.relative_to(here)))))
 rows.append({'name':name,'script':str(script.relative_to(here)),'sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'diff':str(diff.relative_to(here)),'old':old,'new':new,'required_failed_check':required,'expected_exit':1})
result={'created_utc':datetime.now(timezone.utc).isoformat(),'baseline_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'baseline_result_sha256':hashlib.sha256((here/'independent_clock_results_v1.json').read_bytes()).hexdigest(),'before_damaged_execution':True,'damages':rows}
with (here/'DAMAGE_PLAN_v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
