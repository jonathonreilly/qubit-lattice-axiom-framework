from pathlib import Path
from datetime import datetime,timezone
import subprocess,sys,json,hashlib
here=Path(__file__).resolve().parent;name=sys.argv[1];script=(here/sys.argv[2]).resolve()
assert script.is_relative_to(here)
args=[sys.executable,'-B',str(script),*sys.argv[3:]]
record=here/(name+'.json');outs={k:here/(name+'.'+k+'.txt') for k in ['stdout','stderr']}
assert not record.exists() and all(not p.exists() for p in outs.values())
start=datetime.now(timezone.utc).isoformat();timed=False
try:
 p=subprocess.run(args,cwd=here,text=True,capture_output=True,timeout=180);out,err,code=p.stdout,p.stderr,p.returncode
except subprocess.TimeoutExpired as e:
 timed=True;code=124;out=e.stdout or '';err=e.stderr or ''
 if isinstance(out,bytes):out=out.decode(errors='replace')
 if isinstance(err,bytes):err=err.decode(errors='replace')
end=datetime.now(timezone.utc).isoformat()
for key,value in [('stdout',out),('stderr',err)]:outs[key].write_text(value)
r={'command':args,'cwd':str(here),'started_utc':start,'finished_utc':end,'exit_code':code,'timeout_seconds':180,'timed_out':timed,'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest()}
for k,p in outs.items():r[k]={'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
record.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));print(out);print(err)
