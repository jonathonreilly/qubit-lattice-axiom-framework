"""Final identity verification and immutable serialization, without science reruns."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
here=Path(__file__).resolve().parent
root=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((here/n).read_text())
def bind(p):return {'path':str(p.relative_to(here)),'bytes':p.stat().st_size,'sha256':sha(p)}
def write(n,o):
 with (here/n).open('x') as f:json.dump(o,f,indent=2);f.write('\n')
def verify_pair(pair,base=here):
 live=root/pair['original_path'];snap=base/pair['snapshot_path']
 assert live.read_bytes()==snap.read_bytes()
 assert sha(live)==pair['sha256'] and live.stat().st_size==pair['bytes']
for n in ['COMMANDS_v1.json','FINAL_SOURCE_CONFIRMATION_v1.json','SEAL_VALIDATION_v1.json','MANIFEST_v1.json','RECEIPT_v1.json']:
 assert not (here/n).exists(),n
assert (here/'REPORT_v1.md').is_file()
validation=read('EVIDENCE_VALIDATION_v1.json');assert (validation['pass'],validation['fail'])==(198,0)
pairs=read('SOURCE_MANIFEST_v1.json')['sources'];assert len(pairs)==8
assert validation['source_pairs']==pairs
for pair in pairs:verify_pair(pair)
assert pairs[0]['sha256']=='512fcbb9c7bdf1a61f47c16386b6f030ca233bb15297ba227afe7ed1134df7d3'
assert pairs[1]['sha256']=='8a0795b00de10e68fcd56e36c0bca7c0ac6907009fe289972facec89bf44f1a3'
for item in read('HAND_PROOF_FREEZE_v1.json')['files']:
 p=here/item['path'];assert sha(p)==item['sha256'] and p.stat().st_size==item['bytes']
dep=read('DEPENDENCY_BINDING_v1.json');old=root/dep['dependency_root']
assert (dep['pass'],dep['fail'])==(97,0)
assert sha(old/'RECEIPT_v1.json')==dep['receipt_sha256']=='af527b7be8f1c0e00d30b4118e24b6436332e3e08de03d7ad5e7ffded6b82098'
assert sha(old/'MANIFEST_v1.json')==dep['manifest_sha256']=='e7a805ff48e89d68c6e09079eee59af5d97bb73b3c1a7b317ea087131ac53459'
oldmanifest=json.loads((old/'MANIFEST_v1.json').read_text())
assert len(oldmanifest['artifacts'])==92 and len(oldmanifest['source_pairs'])==5
for item in oldmanifest['artifacts']:
 p=old/item['path'];assert sha(p)==item['sha256'] and p.stat().st_size==item['bytes']
for pair in oldmanifest['source_pairs']:verify_pair(pair,old)
commands=[]
for path in sorted(here.glob('*_run_v*.json')):
 r=json.loads(path.read_text());expected=1 if path.name.startswith('damage_') else 0
 assert r['exit_code']==expected and not r['timed_out']
 assert Path(r['cwd'])==here and sha(Path(r['command'][2]))==r['script_sha256']
 for key in ['stdout','stderr']:
  info=r[key];p=here/info['path'];assert sha(p)==info['sha256'] and p.stat().st_size==info['bytes']
 commands.append({'record':path.name,'record_sha256':sha(path),**r})
assert len(commands)==10
science=read('independent_clock_results_v1.json');assert (science['pass'],science['fail'])==(186,0)
assert science['script_sha256']==sha(here/'check_clock_bound_v1.py')
assert not science['producer_code_or_results_accessed']
assert len(validation['actual_damages'])==7
for item in validation['actual_damages']:
 result=read(item['result']);command=read(item['command_record'])
 assert item['exit_code']==command['exit_code']==1
 assert item['fail']>0 and (result['pass'],result['fail'])==(item['pass'],item['fail'])
 assert result['script_sha256']==sha(here/item['script'])==item['sha256']
 assert item['required_failed_check'] in [x['name'] for x in result['checks'] if not x['passed']]
assert not validation['unexpected_failures']
for p in here.rglob('*'):assert not p.is_symlink(),str(p)
now=datetime.now(timezone.utc).isoformat()
seal_command={'command':[sys.executable,'-B',str(Path(__file__).resolve())],'cwd':str(here),'script_sha256':sha(Path(__file__)),'scope':'identity checks plus evidence serialization; no science rerun'}
write('COMMANDS_v1.json',{'created_utc':now,'child_runs':commands,'seal_command':seal_command,'unexpected_failures':[]})
confirmation={'created_utc':now,'checker':'/root/local_response_check','direct_scientific_author':'/root','source_pairs':pairs,'author_sources_unchanged':True,'source_corrections_requested':[],'original_reviewer_confirmation':'The final live source and protocol v2 are byte-identical to the independently checked snapshots. The exact joint square, physical-clock integration and conditional scope require no source correction.','dependency_reuse':{'receipt_sha256':dep['receipt_sha256'],'manifest_sha256':dep['manifest_sha256'],'original_pass':180,'original_fail':0,'new_run':False,'role':'same total isolated fixed-entropy bath charge bound only'},'producer_code_results_accessed':False,'formal_audit_or_authority_change':False}
write('FINAL_SOURCE_CONFIRMATION_v1.json',confirmation)
write('SEAL_VALIDATION_v1.json',{'created_utc':now,'scope':'metadata only','live_source_pairs_verified':len(pairs),'dependency_artifacts_verified':92,'dependency_source_pairs_verified':5,'child_run_records_verified':len(commands),'damaged_copies_rejected':7,'unexpected_failures':[],'seal_command':seal_command})
excluded={'MANIFEST_v1.json','RECEIPT_v1.json'}
artifacts=[bind(p) for p in sorted(here.rglob('*')) if p.is_file() and str(p.relative_to(here)) not in excluded]
manifest={'created_utc':now,'unit':str(here.relative_to(root)),'artifact_count':len(artifacts),'artifacts':artifacts,'source_pairs':pairs,'excluded_seal_files':sorted(excluded),'immutable_after_seal':True}
write('MANIFEST_v1.json',manifest)
receipt={'created_utc':now,'type':'focused blind mathematical check; not formal audit','checker':'/root/local_response_check','direct_scientific_author':'/root','unit':str(here.relative_to(root)),'report':bind(here/'REPORT_v1.md'),'manifest':bind(here/'MANIFEST_v1.json'),'artifact_count':len(artifacts),'live_source_pair_count':len(pairs),'source_pairs':pairs,
 'new_science':{'pass':186,'fail':0,'exit_code':0,'script':bind(here/'check_clock_bound_v1.py'),'result':bind(here/'independent_clock_results_v1.json'),'command':bind(here/'independent_clock_run_v1.json'),'role':'exact identities, independent physical-time integrals and explicit outside-domain controls'},
 'reused_finite_mass_dependency':{'receipt':pairs[5],'manifest':pairs[6],'corrected_source':pairs[4],'report':pairs[3],'original_pass':180,'original_fail':0,'new_run':False,'role':'uniform same-bath finite charge comparison','original_artifacts_verified':92,'original_source_pairs_verified':5,'original177_quality_defect_remains_preserved':True},
 'actual_damaged_copies':validation['actual_damages'],'unexpected_failures':[],
 'metadata':{'initial_dependency_identity':{'pass':97,'fail':0},'final_evidence_validation':{'pass':198,'fail':0},'new_science':False,'validation':bind(here/'EVIDENCE_VALIDATION_v1.json'),'seal_validation':bind(here/'SEAL_VALIDATION_v1.json')},
 'original_reviewer_final_source_confirmation':bind(here/'FINAL_SOURCE_CONFIRMATION_v1.json'),'commands':bind(here/'COMMANDS_v1.json'),'seal_command':seal_command,
 'bounded_conclusion':'Under the stated flat positive-energy, fixed subcritical coupling and uniform matter-charge hypotheses, the physical proper-time supremum is bounded by sqrt[3QR/(C0 rho_J0)]/sqrt(4-3qmax). The derivation does not use a separate global A cap or vacuum-scale calibration. No author-source correction was required.',
 'limitations':['The fixed R must apply to every earlier event of the same selected bath; real thermal history and entropy production are not supplied by current radiation alone.','Positive-curvature histories are outside the proof, and positive final physical expansion alone does not justify the root at supercritical coupling.','The endpoint Q/C0 remains until an independently justified calibration relation is supplied; no measured age is inferred.','Same-background principal-response/error ceilings and distinct-environment bounds are conditional imports, not measured environment matching.','Instantaneous square equality does not establish integrated optimality for qmax>0.','General constant-coupling toy histories are independent controls, not candidate positive-Hv cosmologies or selected initial states.','No singularity classification, inextendibility, quantum origin or formal audit result is inferred.'],
 'writes_confined_to_unit':True,'producer_code_results_accessed':False,'git_runtime_settings_or_authority_changed':False,'immutable_after_seal':True}
write('RECEIPT_v1.json',receipt)
# Read-only verification; no writes follow this point.
for item in artifacts:
 p=here/item['path'];assert sha(p)==item['sha256'] and p.stat().st_size==item['bytes']
assert {str(p.relative_to(here)) for p in here.rglob('*') if p.is_file()}=={x['path'] for x in artifacts}|excluded
assert sha(here/'MANIFEST_v1.json')==receipt['manifest']['sha256']
for pair in pairs:verify_pair(pair)
print(json.dumps({'sealed_utc':now,'artifact_count':len(artifacts),'live_source_pairs':len(pairs),'postseal_identity_verification':'passed','new_science':'186/0','damaged_copies_rejected':7,'finite_mass_reuse':'180/0, not rerun','report':bind(here/'REPORT_v1.md'),'manifest':bind(here/'MANIFEST_v1.json'),'receipt':bind(here/'RECEIPT_v1.json')},indent=2))
