# Independent finite-mass equilibrium and bounce-bound check

The conditional finite-mass result is supported. The continuous ideal photon/pair thermodynamics gives a bounded charge ratio with R=(11/4)^(1/3). The action's strict Einstein-bounce inequality then gives

    d_J F_bare,total > [3/(2R)] exp(2N),
    3/(2R)=1.0706487832554121>1.

Thus the stated total-bath target cannot be reached when the final Einstein radius is at least the bounce radius, subject to the explicit equilibrium, isolation, positivity and calibration premises.

One source qualification was needed: the divided entropy escape formula requires a positive target product. The author preserved v1 and supplied v2 with that domain and the impossible nonpositive-target case made explicit. This same checker read the complete corrected source and confirmed only the two requested prose changes; all displayed equations are unchanged. No further mathematical correction was identified.

The corrected independent computation completed **180/0** and seven actual altered-code controls were rejected. The original 177/0 execution remains preserved, with a disclosed checker-quality defect in four vacuous guard rows; those rows are not treated as evidence. The corrected run replaces them with actual substitutions and product calculations. Separate source correspondence was **56/0 metadata checks**, followed by **134/0 evidence checks**. These counts are not added together as science results. No author checker, output, grid, other new-route computation or earlier independent science runner was read or executed.

## Frozen sources and ordering

| Source | SHA-256 |
| --- | --- |
| Original DERIVATION_v1.md | 0675d2e7134c09921c474d3e6887ae95f9638e38b560b8856a21e9e02fe8105f |
| PROTOCOL_v1.json | d7ae9e14d1c5c1f8497c51dc258e60a2a65fd1653a68b53eaa19645339b96b87 |
| Supplied complete-action confinement note | 39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000 |
| Corrected DERIVATION_v2.md | 356b3cdbc71d862223da2e6197f09eab816807afcf40bd17a3ec3335e8da6e23 |
| TARGET_DOMAIN_REPAIR_v2.json | 7877488fcacbcbd913f5c2b1bf8a09f5fea3f38c6103df9c9e527117a9f40bb8 |

The first three sources were copied before the hand proof or computations. HAND_PROOF_v1.md and CONTROL_PROTOCOL_v1.json were then frozen before checker implementation. INDEPENDENT_SCIENCE_FREEZE_v1.json binds the completed independent runs and actual damaged copies before the later source correspondence. Full original/snapshot paths, byte counts and roles are recorded in the source manifests; the final receipt contains all five live/snapshot pairs. The old slow-past unit is neither modified nor a dependency of this new result.

The source's primary review reference was also inspected at [PDG 2025 Big-Bang Cosmology, Eqs. 22.35–22.42 and 22.45](https://pdg.lbl.gov/2025/reviews/rpp2025-rev-bbang-cosmology.pdf). Those equations support the stated equilibrium stress, entropy and statistical weights and distinguish the interaction-rate condition. They do not establish equilibrium for this candidate trajectory. PDG_ACCESS_v1.json records the successful text access; no local PDF binary or byte hash is claimed. The new identities below were independently derived from the supplied distributions and action.

## Continuous thermodynamics and entropy

For four fermion spin states, the phase-space coefficient is 4/(2pi^2)=2/pi^2. Direct subtraction of the pressure moment gives

    rho_F-3p_F=(2m^2/pi^2) integral p^2 f/E dp>0.

The two photons add positive pressure and zero trace. Hence at every finite m,T>0 the total bath has 0<p<rho/3. The fixed-physical-momentum derivative d_T f=E f(1-f)/T^2 proves the stated positive heat capacity. The momentum derivative d_p f=-p f(1-f)/(ET), together with integration by parts of p^3 E f, proves p_T=(rho+p)/T. Its endpoint term vanishes at both zero and infinity. Therefore s_T=rho_T/T.

Physical isolation gives rho_T dot_J T=-3H_J(rho+p), so dot_J(s a_J^3)=0. The conserved entropy value remains an unselected integration constant. The proof does not hold a variable Einstein mass m_E=A m fixed while differentiating the physical temperature. A physical constant mass and fixed species definitions are essential to these identities.

With S=s a_J^3, the exact charge is D=S^(4/3)G(T), where G=rho/s^(4/3). Differentiation gives

    d ln G/dT=rho_T(3p-rho)/[3rho(rho+p)]<0.

The hot limiting weights are 2+(7/8)4=11/2; the cold bath has two photons. The exact Bose and Fermi integrals are pi^4/15 and 7pi^4/120. At a massless endpoint, G=(3/4)^(4/3)(pi^2 g/30)^(-1/3), giving G_cold/G_hot=R=(11/4)^(1/3). Strict monotonicity and the two asymptotic limits prove the uniform range. Finite endpoint ratios lie strictly within (1/R,R); using the closed interval is conservative. No stepwise effective-degree approximation or temperature ordering is required.

## Action normalization, component identity and clocks

The complete action has -Q K_AB partial phi^A partial phi^B, with no additional 1/2. Its scalar density and pressure are Qw_phi+V and Qw_phi-V. The full metric is positive on its supplied finite chart because its parameters give positive F,J,D and diagonal coefficients. Einstein variation consequently yields

    dot_E H_E=kappa-w_phi-(rho_B,E+p_B,E+rho_o+p_o)/(2Q).

At a strict Einstein bounce, nonnegative scalar kinetic energy and other-matter enthalpy imply kappa_b>rho_B,b(1+w_B,b)/(2Q)>0. Thus positive curvature is derived and f_B,b<2/[3(1+w_B,b)]<=2/3. The potential's detailed height does not enter this particular inequality, although the full constraint and equations still matter for existence of a history.

The source's rho_J is a physical thermal density T^4 r; in the canonical note's density-unit convention it corresponds to rho_unit times that note's normalized density. No normalized density is substituted into an unnormalized thermal or Einstein equation.

Frame conversion gives rho_E=A^4 rho_J, p_E=A^4 p_J, a_J=A a_E and dt_J=A dt_E. Therefore D=rho_E a_E^4=rho_J a_J^4 and the bath equation-of-state ratio is frame invariant. The physical rate is H_J=Z/A, with Z=H_E+dot_E ln A. The bare physical coefficient is Q/C in the R_J/2 convention, yielding d_J=kappa/Z^2 and F_bare=3Q Z^2/rho_B,E. Positive-curvature d_J equals -Omega_K in the usual signed convention.

The endpoint requires Z_f!=0. A cancelled expression for d_J F does not make the two readouts well-defined at Z_f=0; the independent substitution actually gives divergent d and zero F. No physical expansion sign is needed for the stated squared endpoint diagnostic. An Einstein bounce is not generally a Jordan bounce if the conformal factor rolls.

For r_a=a_E,f/a_E,b=exp N, fixed curvature and the same bath give kappa_f/kappa_b=r_a^-2 and rho_f/rho_b=zeta r_a^-4. Thus

    d_J,f F_bare,B,f=r_a^2/(f_B,b zeta)
      >3(1+w_B,b)r_a^2/(2R)>=3r_a^2/(2R).

The strict inequality survives the weak zeta<=R bound. The claimed >1 conclusion uses N>=0; a negative N can make the coarse lower bound smaller than one. Full monotone Einstein expansion between endpoints is unnecessary, but endpoint radius ordering cannot be discarded.

A photon-only substitution is materially different. In the limiting isolated pair-annihilation comparison, D_gamma,cold/D_gamma,hot=(11/4)^(4/3), approximately 3.85280408, whereas the total-bath ratio is R, approximately 1.40101967. Their ratio is 11/4. This is why the theorem cannot combine a total-bath bounce fraction with a photon-only charge or endpoint diagnostic. The measured local-gravity normalization is a separate unresolved conversion.

## Larger baths and entropy budgets

For a finite ideal collection with fixed masses, zero chemical potentials, a common temperature and some massless species, each massive trace is nonnegative and the heat capacity is positive. The same proof yields R=(g_hot/g_cold)^(1/3). No finite cold-end ratio follows if the massless content is removed. These statements assume the ideal particle definitions throughout; interactions, chemical potentials, changing masses or separate temperature sectors need their own equations.

R<=3/2 suffices for the coarse obstruction at N>=0, including the equality boundary because the bounce step is strict. For R>3/2 this estimate is insufficient; it neither constructs a repair nor proves one impossible. The stronger factor 1+w_B,b may still matter in a particular state.

Relaxing isolation while retaining the same endpoint equilibrium definitions gives zeta<=sigma^(4/3)R, where sigma=S_f/S_b>0. For a positive proposed target product P=epsilon(1+delta), a necessary condition is

    sigma>[3 exp(2N)/(2R P)]^(3/4).

Equality cannot reach a product <=P because the bounce inequality is strict. V1 left the divided expression's domain implicit. V2 now explicitly states epsilon>0,delta>=0 for the target, P>0 for this formula, and impossibility of a nonpositive target product. The separate source_correspondence_v2 report and receipt confirm that correction. Specifying an entropy ratio remains a budget rather than a production mechanism or sufficient history.

## New independent numerical controls

The finite-mass controls use x=m/T=0.007,0.11,0.6,1.3,2.9,6.7,14,24. Adaptive momentum quadrature on [0,infinity) is compared with independent 256- and 512-node Gauss-Legendre rapidity integration at x=0.11,1.3,6.7,24. The rapidity integral ends at Ehat=x+80. Its omitted energy-moment tails are bounded by explicit integrals of Ehat^3 exp(-Ehat) and Ehat^4 exp(-Ehat). Adaptive error estimates are not treated as rigorous intervals; the hand proof, not the finite grid, establishes the uniform range.

The largest stored cross-coordinate moment difference was 9.06e-14. The largest absolute difference between the direct thermodynamic G derivative and a five-point log-temperature derivative was 1.06e-12. Both were below the preregistered tolerances, and no quadrature warning occurred.

| m/T | Total p/rho | G |
| --- | --- | --- |
| 0.007 | 0.3333318290 | 0.5592022856 |
| 0.6 | 0.3240507575 | 0.5677398748 |
| 2.9 | 0.2739702297 | 0.6750313083 |
| 6.7 | 0.3155556133 | 0.7749651408 |
| 24 | 0.3333333194 | 0.7834516297 |

The limiting values are G_hot=0.5592010237293866 and G_cold=0.7834516311162488. Additional endpoint controls use both temperature orderings and unequal admissible conformal factors; they verify frame-invariant D and the same charge range without claiming a trajectory.

A local nonempty-domain example uses Q=Hv=m=1, k=1/5, nu=9/7, fields and velocities zero, and T=1/1.3. It gives rho_B=0.5814501433, p_B=0.1759482486, V=3 and kappa=1.1938167144 from the exact action constraint. Raychaudhuri gives dot_E H_E=0.8151175185>0 and f_B=0.1623504782. The finite trace generally accelerates the scalar even though its instantaneous velocity vanishes. This is regular local constraint/bounce data, not a stationary finite-mass cosmology or a complete equilibrated history.

## Executions, damages and retained defects

The corrected checker SHA-256 is dda428fa8a15b0a733438042da4992bbb762e69b555848dc5a9a9bafc50cad17. It ran at 2026-10-14T11:53:03.441255Z through 11:53:03.970426Z and completed 180/0, exit 0, using Python 3.12.8, SymPy 1.14.0, SciPy 1.17.0 and NumPy 2.4.1. Every child invocation records its exact argv, cwd, UTC interval, code hash, exit status and stdout/stderr hashes. The wrapper's own success is not substituted for the child's exit.

| Actual damaged script | Pass / fail | Exit | Intended failed identity |
| --- | --- | --- | --- |
| Reverse trace sign | 159 / 21 | 1 | stress_trace_integrand |
| Replace entropy power 4/3 by 1 | 150 / 30 | 1 | G_temperature_identity |
| Use A^2 instead of A^4 density conversion | 179 / 1 | 1 | conformal_charge_invariance |
| Reverse endpoint radius exponent | 178 / 2 | 1 | endpoint_radius_charge_identity |
| Change Raychaudhuri denominator 2 to 3 | 178 / 2 | 1 | action_Raychaudhuri_normalization |
| Mix photon and total-bath components | 179 / 1 | 1 | same_total_component_diagnostic |
| Halve the adopted fermion degeneracy | 176 / 4 | 1 | adopted_hot_species_weight |

All scripts, exact one-edit diffs, outputs and failed-check identities are retained. Changing degeneracy is a source-model mismatch, not a claim that a different species model is mathematically inconsistent.

The initial checker actually completed 177/0, but self-review found three hardcoded strictness rows and one literal-zero domain guard. CHECKER_QUALITY_REPAIR_v2.json preserves this real validation-quality defect. V2 replaces them by actual Z=0 substitution and strict-fraction calculations, adding three exact product identities. The original source, script, result and diff remain intact; no tolerance or physical case was changed. The vacuous rows are not counted as independent support, and 177/0 is not added to 180/0.

A later tool invocation also failed before process creation because its working directory contained science-loops instead of science/physics-loops. TOOL_FAILURES_v1.json preserves the exact attempted command, wrong directory, error and correction. No command ran and no file was created by that failed attempt. The same verification script then ran in the authorized directory and completed 134/0 metadata checks. No failure was discarded or relabeled as a success.

## Bounded conclusion and seal

The supported result replaces exact total-radiation charge conservation with a derived finite-mass charge range for the specified reversible isolated equilibrium bath. It preserves a restricted Einstein-bounce obstruction under a stated total-bath bare target and endpoint radius condition. It does not derive the particle theory, equilibrium rates, entropy abundance, calibrated gravity, target epoch, a full bouncing thermal history, perturbation stability, observed fit or quantum origin.

The original reviewer confirms the final v2 source correction is adequate and its equations are unchanged. All five source pairs and all command/output identities are bound by the final manifest and receipt; the separate v2 correspondence is included without rerunning science. All persistent outputs are confined to this independent_v1 folder. The earlier seals and author sources remain untouched. No Git, runtime, settings, PR, formal audit or authority change was made. This unit is frozen after the final hash verification.
