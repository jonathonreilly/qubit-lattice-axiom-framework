from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,sys
here=Path(__file__).resolve().parent
root=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
checks=[]
def check(n,b):checks.append({'name':n,'passed':bool(b)})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((here/n).read_text())
pairs=read('SOURCE_MANIFEST_v1.json')['sources']
for i,pair in enumerate(pairs):
 live=root/pair['original_path'];snap=here/pair['snapshot_path']
 check('source_live_'+str(i),sha(live)==pair['sha256'])
 check('source_snapshot_'+str(i),sha(snap)==pair['sha256'])
 check('source_bytes_'+str(i),live.read_bytes()==snap.read_bytes() and live.stat().st_size==pair['bytes'])
hand=read('HAND_PROOF_FREEZE_v1.json')
for item in hand['files']:
 p=here/item['path'];check('frozen_'+item['path'],sha(p)==item['sha256'] and p.stat().st_size==item['bytes'])
dep=read('DEPENDENCY_BINDING_v1.json');old=root/dep['dependency_root']
check('dependency_receipt_unchanged',sha(old/'RECEIPT_v1.json')==dep['receipt_sha256'])
check('dependency_manifest_unchanged',sha(old/'MANIFEST_v1.json')==dep['manifest_sha256'])
oldmanifest=json.loads((old/'MANIFEST_v1.json').read_text())
for item in oldmanifest['artifacts']:
 p=old/item['path'];check('dependency_artifact_'+item['path'],sha(p)==item['sha256'] and p.stat().st_size==item['bytes'])
for pair in oldmanifest['source_pairs']:
 live=root/pair['original_path'];snap=old/pair['snapshot_path'];check('dependency_source_'+pair['original_path'],live.read_bytes()==snap.read_bytes() and sha(live)==pair['sha256'])
check('dependency_not_new_run',dep['original_science']=={'pass':180,'fail':0,'new_run':False})
commands=[]
for p in sorted(here.glob('*_run_v*.json')):
 r=json.loads(p.read_text());expected=1 if p.name.startswith('damage_') else 0
 check(p.name+'_exit',r['exit_code']==expected and not r['timed_out'])
 check(p.name+'_script',sha(Path(r['command'][2]))==r['script_sha256'])
 check(p.name+'_cwd',Path(r['cwd'])==here)
 for key in ['stdout','stderr']:
  item=r[key];f=here/item['path'];check(p.name+'_'+key,sha(f)==item['sha256'] and f.stat().st_size==item['bytes'])
 commands.append({'record':p.name,**r})
result=read('independent_clock_results_v1.json');run=read('independent_clock_run_v1.json')
check('new_science_actual186_0',(result['pass'],result['fail'],run['exit_code'])==(186,0,0))
check('new_science_script_bound',result['script_sha256']==sha(here/'check_clock_bound_v1.py'))
check('hand_proof_preceded_run',hand['created_utc']<run['started_utc'])
check('producer_not_accessed',not result['producer_code_or_results_accessed'])
plan=read('DAMAGE_PLAN_v1.json');damages=[]
for item in plan['damages']:
 name=item['name'];rp='damages/'+name+'_results_v1.json';cp='damage_'+name+'_run_v1.json';r=read(rp);c=read(cp)
 failures=[x['name'] for x in r['checks'] if not x['passed']]
 check(name+'_script_bound',sha(here/item['script'])==item['sha256']==r['script_sha256'])
 check(name+'_actual_counts',r['pass']+r['fail']==186 and r['fail']==len(failures))
 check(name+'_intended_failure',item['required_failed_check'] in failures and c['exit_code']==1)
 damages.append({**item,'result':rp,'command_record':cp,'pass':r['pass'],'fail':r['fail'],'exit_code':c['exit_code'],'failed_checks':failures})
coeff=next(x for x in damages if x['name']=='joint_coefficient')
check('wrong_joint_coefficient_fails_actual_histories',sum(n.startswith('toy_joint_duration_bound_') for n in coeff['failed_checks'])==2)
check('no_symlinks',not any(p.is_symlink() for p in here.rglob('*')))
summary={'maximum_two_coordinate_duration_gap':max(abs(x['duration_a_coordinate']-x['duration_log_coordinate']) for x in result['evidence']['toy_histories']),'toy_histories':result['evidence']['toy_histories']}
o={'created_utc':datetime.now(timezone.utc).isoformat(),'scope':'source, output and dependency metadata only; no science rerun','pass':sum(x['passed'] for x in checks),'fail':sum(not x['passed'] for x in checks),'checks':checks,'source_pairs':pairs,'commands':commands,'actual_damages':damages,'stored_numerical_summary':summary,'reused_dependency':{'receipt_sha256':dep['receipt_sha256'],'manifest_sha256':dep['manifest_sha256'],'artifacts_verified':len(oldmanifest['artifacts']),'source_pairs_verified':len(oldmanifest['source_pairs']),'original_science':dep['original_science']},'unexpected_failures':[],'author_source_corrections_required':False,'producer_code_results_accessed':False,'script_sha256':sha(Path(__file__))}
out=here/'EVIDENCE_VALIDATION_v1.json';assert not out.exists();out.write_text(json.dumps(o,indent=2)+'\n')
print(json.dumps({'pass':o['pass'],'fail':o['fail'],'failed_checks':[x for x in checks if not x['passed']],'live_source_pairs':len(pairs),'run_records':len(commands),'damages':[{k:x[k] for k in ['name','pass','fail','exit_code','required_failed_check']} for x in damages],'maximum_duration_difference':summary['maximum_two_coordinate_duration_gap']},indent=2))
sys.exit(1 if o['fail'] else 0)
