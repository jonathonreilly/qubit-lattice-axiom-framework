# Observed photon density and the conditional clock normalization

The published aggregate CMB temperature is 2.72548 +/- 0.00057 K (Fixsen, Table2 and conclusion). CODATA2022 recommends G=6.67430(15)e-11 m^3 kg^-1 s^-2, with the parentheses denoting standard uncertainty. These values are read as calibration/development inputs; none were fitted to the scalar model and none constitutes an independent test of it.

Using the Planck blackbody law and exact SI definitions,

 u_gamma = pi^2 (k_B T)^4/(15 hbar^3 c^3),
 rho_gamma,mass = u_gamma/c^2,
 tau_ref = 1/sqrt(6 pi G_cal rho_gamma,mass).

This gives u_gamma=4.1746783808e-14 J/m^3, rho_gamma,mass=4.6449561344e-31 kg/m^3, and tau_ref=1310.846386 Gyr (Julian-year convention). The universal same-background bound in the preceding physical-clock theorem would be tau_ref sqrt[R(1+eta)] if all its premises hold for the selected interval and bath. The formula uses mass density in SI; inserting energy density directly would lose a factor c in the time.

The number is a normalization diagnostic, not a measured cosmic age or a universal upper age. The present CMB temperature does not establish a uniform past charge bound, spatial flatness through that interval, or equality of laboratory and cosmological response environments. In particular G's quoted measurement error is not eta: eta bounds the theory-to-experiment response approximation and remains unjustified. No present-day photon calibration selects the supplied scalar action, potential or vacuum scale.

The input +/-uncertainty rectangle gives tau_ref in [1310.283540,1311.409589] Gyr. This is deterministic sensitivity to those published input ranges, not a simultaneous confidence interval and not a fitted cosmological constraint. The weak numerical ceiling illustrates why the mathematical elimination of Hv and a global A cap does not by itself produce a useful measured early-history test.

Primary sources, accessed2026-10-14:
- Fixsen: https://arxiv.org/pdf/0911.1955 (Table2 p5, conclusion p6).
- NIST: https://physics.nist.gov/cuu/Constants/Table/allascii.txt (2022 table; G,c,h,k_B).

Saved inputs, source bytes/hashes, code, full outputs and dimensional controls accompany this note. The original clock proof and its independent seal are unchanged. Twelve direct checks cover SI dimensions, two blackbody routes, scaling, rectangle orientation and q-envelope samples; they are numerical/formula validation, not an empirical acceptance count.
