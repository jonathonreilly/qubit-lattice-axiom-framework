from pathlib import Path
import json,sys,hashlib
import mpmath as mp
mp.mp.dps=50
root=Path(__file__).resolve().parent
inp=json.loads((root/'INPUT_PROTOCOL_v1.json').read_text())
c=mp.mpf(str(inp['c_m_s']));h=mp.mpf(str(inp['h_J_s']));kb=mp.mpf(str(inp['kB_J_K']));hb=h/(2*mp.pi)
T=mp.mpf(str(inp['T_CMB_K']['value']));G=mp.mpf(str(inp['G_SI']['value']))
uT=mp.mpf(str(inp['T_CMB_K']['reported_uncertainty']));uG=mp.mpf(str(inp['G_SI']['standard_uncertainty']))
year=mp.mpf('365.25')*86400;gyr=year*10**9

def calc(temp,gravity):
 energy=mp.pi**2*(kb*temp)**4/(15*hb**3*c**3)
 mass=energy/c**2
 tau=1/mp.sqrt(6*mp.pi*gravity*mass)
 return dict(T=temp,G=gravity,energy_density_J_m3=energy,mass_density_kg_m3=mass,tau_reference_s=tau,tau_reference_Gyr=tau/gyr)
center=calc(T,G);corners=[calc(tt,gg) for tt in [T-uT,T+uT] for gg in [G-uG,G+uG]]
checks=[]
def ck(n,v):checks.append(dict(name=n,passed=bool(v)))
sb=2*mp.pi**5*kb**4/(15*h**3*c**2)
ck('blackbody_stefan_boltzmann_route',abs(4*sb*T**4/c/center['energy_density_J_m3']-1)<mp.mpf('1e-45'))
ck('SI_mass_energy_conversion',abs(center['mass_density_kg_m3']*c**2/center['energy_density_J_m3']-1)<mp.mpf('1e-45'))
ck('time_temperature_scaling',abs(calc(2*T,G)['tau_reference_s']*4/center['tau_reference_s']-1)<mp.mpf('1e-45'))
ck('time_gravity_scaling',abs(calc(T,4*G)['tau_reference_s']*2/center['tau_reference_s']-1)<mp.mpf('1e-45'))
ck('monotone_rectangle_upper',max(r['tau_reference_s'] for r in corners)==corners[0]['tau_reference_s'])
ck('monotone_rectangle_lower',min(r['tau_reference_s'] for r in corners)==corners[-1]['tau_reference_s'])
# Exponents in (mass,length,time,temperature) for explicitly dimensional inputs.
import sympy as S
L=S.Matrix([0,1,0,0]);Ti=S.Matrix([0,0,1,0]);M=S.Matrix([1,0,0,0]);Th=S.Matrix([0,0,0,1])
dc=L-Ti;dh=M+2*L-Ti;dk=M+2*L-2*Ti-Th;dG=3*L-M-2*Ti
energy_dim=4*(dk+Th)-3*dh-3*dc
mass_dim=energy_dim-2*dc
time_dim=-(dG+mass_dim)/2
ck('energy_density_dimensions',energy_dim==M-L-2*Ti)
ck('mass_density_dimensions',mass_dim==M-3*L)
ck('clock_dimensions',time_dim==Ti)
for q in [mp.mpf('.25'),mp.mpf('.30'),mp.mpf('0.333333333333')]:
 exact=mp.sqrt(3*(1+q)/(8*mp.pi*G*center['mass_density_kg_m3']*(4-3*q)))
 ck('q_envelope_'+str(q),exact<center['tau_reference_s'])
def clean(v):
 if isinstance(v,dict):return {k:clean(x) for k,x in v.items()}
 if isinstance(v,list):return [clean(x) for x in v]
 if isinstance(v,mp.mpf):return mp.nstr(v,35)
 return v
res=clean(dict(passed=sum(x['passed'] for x in checks),failed=sum(not x['passed'] for x in checks),checks=checks,central=center,reported_uncertainty_rectangle=corners,
 scope='Observed-input conditional normalization only: multiply tau_reference by sqrt(R*(1+eta)). Not a measured cosmic-age ceiling without all theorem and same-background calibration assumptions. Input uncertainty rectangle is not simultaneous confidence.',
 input_sha256=hashlib.sha256((root/'INPUT_PROTOCOL_v1.json').read_bytes()).hexdigest(),code_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))
out=Path(sys.argv[1]);assert not out.exists();out.write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2));sys.exit(bool(res['failed']))
