# Independent SI derivation, frozen before implementation

This check uses only the author calculation/protocol and saved primary inputs.
No producer script or result was read. The author's printed proposed answers
were visible in the calculation note; they are comparison targets, not inputs
to the independent formula implementation. The previous clock theorem is reused
through its sealed report and receipt, with no new proof or run of that theorem.

Two photon polarizations give the frequency-space number of modes per volume
as 8*pi*nu^2/c^3. Multiplying by mean Planck energy
h*nu/(exp(h*nu/(k_B*T))-1) and integrating over frequency yields

    u = 8*pi*(k_B*T)^4/(h^3*c^3) * I,
    I = integral_0^infinity x^3/(exp(x)-1) dx
      = sum_n>=1 integral_0^infinity x^3 exp(-n*x) dx
      = 6*zeta(4) = pi^4/15.

All summands are nonnegative; exchange of sum and integral is justified by
monotone convergence. Thus u=8*pi^5*(k_B*T)^4/(15*h^3*c^3), exactly the
displayed hbar expression after hbar=h/(2*pi). The isotropic outgoing flux is
c*u/4, so sigma=2*pi^5*k_B^4/(15*h^3*c^2) and u=4*sigma*T^4/c.
The blackbody premise is explicit; using a measured spectral temperature alone
does not reprove a perfectly Planckian spectrum or a particular thermal history.

Use exact SI decimal definitions c=299792458 m/s, h=6.62607015e-34 J*s,
k_B=1.380649e-23 J/K. The NIST table writes h in J/Hz, equivalent to J*s.
The mass density is rho_m=u/c^2. Dimensions (kg,m,s,K) are

    u:       (1,-1,-2,0),
    rho_m:   (1,-3, 0,0),
    G*rho_m: (0, 0,-2,0),
    tau_ref: (0, 0, 1,0).

Inserting u instead of rho_m makes the inverse square root have units s^2/m;
its numerical value in this SI expression is tau_ref/c. It is not a time with
another harmless unit convention. The missing factor is physically consequential.

The inherited universal conditional coefficient, written in SI, is

    tau_ref = 1/sqrt(6*pi*G_cal*rho_m)
            = sqrt[5*h^3*c^5/(16*pi^6*G_cal*(k_B*T)^4)].

The second expression is derived independently by substituting the integrated
Planck formula. It uses an exact rational input times powers of pi and a square
root; high-precision evaluation does not make the measured T or G exact facts.
One Julian Gyr is exactly 10^9*365.25*86400=31557600000000000 seconds by the
chosen conversion convention.

For positive T and G, tau_ref is proportional to T^-2 G^-1/2. Its derivatives
are -2*tau_ref/T and -tau_ref/(2*G), both negative. Hence over the stipulated
rectangle the minimum is at T+sigma_T,G+sigma_G and the maximum is at
T-sigma_T,G-sigma_G. All four corners will be computed independently.
The rectangle is a deterministic input-sensitivity domain. The two displayed
uncertainties do not establish a simultaneous coverage probability, a covariance
matrix, or a confidence interval for the derived scale.

Fixsen physical PDF page 5, Table 2, visibly labels the uncertainty column mK;
the mean row reads 2.72548 and .57. Page 6's conclusion writes
2.72548 +/- 0.00057 K. The surrounding text describes an aggregate of estimates,
with 97 percent of the weight from FIRAS, not a single newly independent FIRAS
measurement. The saved NIST 2022 table gives G=6.67430e-11 and uncertainty
0.00015e-11=1.5e-15 in m^3 kg^-1 s^-2; c, h and k_B are marked exact.

The laboratory uncertainty in G quantifies the published input precision.
The theorem's eta is a separate upper bound on theoretical local-response
approximation and environment matching; the former supplies no value of the
latter. Even a perfectly calculated tau_ref supplies neither the required
uniform past charge ratio R, nor flatness on the interval, nor the relation
between laboratory and cosmological gravitational responses. This is a
conditional normalization reference, not a measured cosmic age bound.

No consequential source correction is apparent from the hand derivation and
primary transcription. This conclusion will be tested numerically, dimensionally
and by executing an actually altered missing-c copy of the checker.
