# Independent observed-normalization check

The supplied calculation and input protocol are correct within their stated
scope. The saved primary sources support the transcribed temperature, constants
and units; the independent SI calculation reproduces every displayed numerical
value. No author-source amendment is required. The resulting reference scale
is **1310.84638597313669 Gyr**, with deterministic input-rectangle range
**[1310.28353997877761, 1311.40958879319771] Gyr**. This is not a measured age
bound, and the laboratory uncertainty in G does not determine eta.

New controls completed **39/0: 26 formula controls and 13 transcription
controls**. The actually executed missing-c-squared damaged copy completed
**29/10 and exited 1**, with all required failures. Separate provenance
validation completed **38/0 metadata checks**. The previous clock theorem's
186/0 and metadata 198/0 are reused, never rerun or added to this unit's counts.
No producer script or result file was read or run. The author's proposed
answers were visible in CALCULATION_v1.md before computation, as disclosed in
the frozen control protocol; they serve only as rounded comparison targets.

## Primary transcription and source identity

| Frozen input | SHA-256 |
| --- | --- |
| CALCULATION_v1.md | fcf3a05ab25c402bbcdfa45917d3037b1c4b56bad7301e21c8529f5ed448905e |
| INPUT_PROTOCOL_v1.json | a0c9db1f70dba3db9e614f6b10b773b7ec47f6c16ba2e1f15a25235491ee79f3 |
| Saved Fixsen_0911.1955.pdf | 36cbaee69b8106ca45d007f46a2e002f9f593b67c310f6d808007a5c3d998f85 |
| Saved NIST_2022_allascii.txt | 77fb90e66c40db3e6eb16630bc9c88e4c7c8beddbe5e71be406f2f26e3f67e67 |
| Reused clock REPORT_v1.md | e612b8d37dc3fa4dad9c1e393f4dfe177802857db33d21a1caf09d3613bba110 |
| Reused clock RECEIPT_v1.json | 30bd74f31d8386b32c3567a8f310a47f44ed7f7eb8a65f8a2b3bb7cbcec9ff4c |

SOURCE_BINDINGS_v1.json records all six live/snapshot path pairs and byte
counts. Complete physical PDF pages 5 and 6 were extracted and visually
inspected. Table 2 labels its uncertainty column mK and gives the mean as
2.72548 K with 0.57 mK uncertainty. The conclusion gives 2.72548 +/- 0.00057 K.
This is the aggregate estimate described by the paper, dominated by FIRAS
weighting; it is not the separate 2.7260 +/- 0.0013 K entry marked This Work.
The checked source is the saved published estimate, not a claim to identify
the newest cosmological fit. Primary location: [Fixsen, Table 2 and conclusion](https://arxiv.org/pdf/0911.1955).

The saved [NIST 2022 CODATA table](https://physics.nist.gov/cuu/Constants/Table/allascii.txt)
gives G=6.67430e-11 and uncertainty 0.00015e-11=1.5e-15 in m^3 kg^-1 s^-2.
It marks c=299792458 m/s, h=6.62607015e-34 J/Hz, and k_B=1.380649e-23 J/K
exact. J/Hz is J*s. The reported relative standard uncertainty of G is
2.2474266964e-5, a laboratory-input precision, not a cosmological response
error budget. The Julian-year conversion is an explicitly selected convention,
365.25*86400 seconds, not an inferred year length or fit parameter.

## Independent calculation and dimensions

The hand calculation preceded code execution. Counting two photon polarizations
gives the spectral mode density 8*pi*nu^2/c^3. Integrating the mean Planck energy
and using integral x^3/(exp(x)-1) dx=6*zeta(4)=pi^4/15 yields

    u = 8*pi^5*(k_B*T)^4/(15*h^3*c^3),
    rho_m = u/c^2,
    tau_ref = sqrt[5*h^3*c^5/(16*pi^6*G*(k_B*T)^4)].

This independent h-form agrees exactly with the supplied hbar-form. A direct
dimensionless quadrature also agrees with the Planck integral, and the derived
Stefan-Boltzmann coefficient agrees with the NIST table's displayed truncated
value. SI definitions and input decimals are represented as exact rationals;
irrational constants and final numerical expressions are evaluated at 80 digits.
That arithmetic precision does not promote measured T and G to exact facts.

| Quantity | Independent result |
| --- | --- |
| Photon energy density | 4.17467838080037544e-14 J/m^3 |
| Photon mass density | 4.64495613440336677e-31 kg/m^3 |
| Reference time | 4.13671659099858585e19 s |
| Reference time | 1310.84638597313669 Julian Gyr |

The dimensions of u, rho_m and tau_ref are respectively kg*m^-1*s^-2,
kg*m^-3 and s. Inserting u directly into the mass-density formula instead
produces units s^2/m, with numerical value tau_ref/c. It is not a valid elapsed
time. The author wording about losing a factor c is correct in that numerical
sense; the damaged output's nominal time and density field labels must not be
mistaken for valid units.

The Planck spectrum is a physical modeling premise of this conversion. This
check verifies its normalization at the supplied spectral temperature; it does
not remeasure the spectrum, its distortions, or a past thermal history.

## Uncertainty rectangle and calibration limits

For positive T,G, logarithmic derivatives are d ln tau/d ln T=-2 and
d ln tau/d ln G=-1/2. Thus the lower extreme uses both upper inputs and the
upper extreme both lower inputs. All four independent corners are retained:

| Temperature sign | G sign | tau_ref (Gyr) |
| --- | --- | --- |
| - | - | 1311.40958879319771 |
| - | + | 1311.38011615518384 |
| + | - | 1310.31298797176880 |
| + | + | 1310.28353997877761 |

Signs mean the quoted central value plus or minus its supplied uncertainty.
The rectangle remains a deterministic sensitivity calculation. Neither the
paper nor these four corners supplies a simultaneous confidence level for T
and G, their covariance, or a confidence interval for this derived scale.

The reused clock proof supplies the conditional universal coefficient
tau_ref*sqrt[R*(1+eta)] only after its complete positive-energy, flatness,
coupling, uniform selected-bath charge and gravitational-calibration hypotheses
are applied. No value of R or eta is inferred here. In particular, the
experimental error of G is not a bound on theoretical response corrections,
finite-scale errors or differences between laboratory and cosmological scalar
environments. Even zero experimental uncertainty would not supply those
premises. Present CMB temperature also does not establish the past charge floor
or interval flatness. No measured cosmic age, early-history exclusion, scalar
model test, vacuum-scale calibration or fitted likelihood follows.

## Executions, failures and final disposition

The frozen checker check_normalization_v1.py has SHA-256
8932a6cea16d972143afade6487bdabd95f3b418695adfda2c6008061b92b8f3.
Its baseline was executed with

    /usr/local/bin/python3 -B check_normalization_v1.py --output BASELINE_RESULTS_v1.json

An actual one-edit copy changed MASS_C_POWER from 2 to 0, then ran with

    /usr/local/bin/python3 -B damages/missing_c_squared_v1.py --output DAMAGE_MISSING_C_RESULTS_v1.json

The damaged script SHA-256 is
697dc6e65b60f7293846477812147724d9d0f2db28f9dc0a5bb8436a6a24379a.
Its ten failures include both SI dimensions, mass conversion, independent time
normalization, all displayed time comparisons and the explicit factor-c witness.
The actual code, exact diff, output, nonzero exit and named failures are retained.
There were no unexpected checker, extraction, tool or metadata failures in this
unit. Output truncation in two tool displays did not truncate the saved files;
the remaining reused report was read separately. Preparatory read-only access
before the directory existed is disclosed in COMMANDS_v1.json; every independent
computation and extraction has exact argv, cwd, UTC interval, script hash, output
hashes and exit code.

The original clock report/receipt binding was checked without rehashing or
rerunning its entire proof unit; no claim of a new full clock validation is made.
The final reviewer confirms all six source pairs remain byte-identical to their
snapshots. No source correction or substituted empirical interpretation is
needed. MANIFEST_v1.json binds this unit's artifacts except itself and its final
receipt; RECEIPT_v1.json binds the manifest, report, source pairs, run records,
dependency reuse and limitations. All new writes are confined to this unit.
Prior seals and producer sources are untouched; no Git, network, runtime,
settings, PR, audit, authority or other-chat operation was performed.
