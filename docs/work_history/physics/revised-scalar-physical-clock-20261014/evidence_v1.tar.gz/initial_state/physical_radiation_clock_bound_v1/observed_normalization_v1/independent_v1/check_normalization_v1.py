from pathlib import Path
import argparse
import json
import platform
import re

import mpmath as mp
import sympy as sp

HERE = Path.cwd()
MASS_C_POWER = 2
mp.mp.dps = 80
parser = argparse.ArgumentParser()
parser.add_argument('--output', required=True)
args = parser.parse_args()
checks = []

def check(name, condition, observed, expected, category='formula'):
    checks.append({'name': name, 'category': category, 'ok': bool(condition),
                   'observed': str(observed), 'expected': str(expected)})

def exact(name, expression, category='formula'):
    reduced = sp.simplify(expression)
    check(name, reduced == 0, reduced, '0 exactly', category)

def close(name, left, right, atol=None, rtol=mp.mpf('1e-65'), category='formula'):
    error = abs(left - right)
    tolerance = atol if atol is not None else rtol * abs(right)
    check(name, error <= tolerance, mp.nstr(error, 25),
          'absolute error <= ' + mp.nstr(tolerance, 25), category)

def numeric(expr):
    return mp.mpf(str(sp.N(expr, 85)))

table = (HERE / 'sources/NIST_2022_allascii.txt').read_text().splitlines()
def nist_row(name):
    matches = []
    for line in table:
        fields = re.split(r' {2,}', line.strip())
        if fields and fields[0] == name:
            matches.append(fields)
    if len(matches) != 1:
        raise ValueError(f'expected one NIST row for {name}, found {matches}')
    return matches[0]

row_G = nist_row('Newtonian constant of gravitation')
row_c = nist_row('speed of light in vacuum')
row_h = nist_row('Planck constant')
row_k = nist_row('Boltzmann constant')
row_sigma = nist_row('Stefan-Boltzmann constant')
parse_rational = lambda s: sp.Rational(s.replace(' ', ''))
G = parse_rational(row_G[1])
dG = parse_rational(row_G[2])
c = parse_rational(row_c[1])
h = parse_rational(row_h[1])
kB = parse_rational(row_k[1])
T = sp.Rational('2.72548')
dT = sp.Rational('0.57') / 1000
gyr_seconds = sp.Rational(10**9) * sp.Rational('365.25') * 86400
protocol = json.loads((HERE / 'sources/input_protocol_v1.json').read_text(),
                      parse_float=str)
pdf_text = (HERE / 'Fixsen_extracted_all_pages_v1.txt').read_text()
check('Fixsen_table_mean_mK', re.search(r'Mean\s+2\.72548\s+\.57', pdf_text),
      'searched extracted Table 2 mean row', '2.72548 K; .57 mK', 'transcription')
conclusion = pdf_text.split('5. SUMMARY AND CONCLUSIONS', 1)[1]
conclusion_compact = re.sub(r'\s+', '', conclusion)
check('Fixsen_conclusion_K', '2.72548±0.00057K' in conclusion_compact,
      'searched whitespace-normalized conclusion', '2.72548±0.00057K', 'transcription')
for name, actual, supplied in [
    ('temperature', T, protocol['T_CMB_K']['value']),
    ('temperature_uncertainty_mK_to_K', dT, protocol['T_CMB_K']['reported_uncertainty']),
    ('G', G, protocol['G_SI']['value']),
    ('G_uncertainty', dG, protocol['G_SI']['standard_uncertainty']),
    ('c', c, protocol['c_m_s']), ('h', h, protocol['h_J_s']),
    ('kB', kB, protocol['kB_J_K'])]:
    exact('protocol_' + name, actual - sp.Rational(str(supplied)), 'transcription')
check('exact_SI_constants', all(row[2] == '(exact)' for row in (row_c, row_h, row_k)),
      [row[2] for row in (row_c, row_h, row_k)], 'three exact markers', 'transcription')
check('NIST_2022_header', '2022 CODATA adjustment' in '\n'.join(table[:12]),
      table[2].strip(), '2022 CODATA adjustment', 'transcription')
check('NIST_SI_units', [row_G[3], row_c[3], row_h[3], row_k[3]] ==
      ['m^3 kg^-1 s^-2', 'm s^-1', 'J Hz^-1', 'J K^-1'],
      [row_G[3], row_c[3], row_h[3], row_k[3]],
      'G in SI; c in m/s; h in J/Hz=J*s; kB in J/K', 'transcription')

# Derive from frequency-mode count and Planck integral, independently of hbar.
I_quad = mp.quad(lambda x: x**3 / mp.expm1(x) if x else mp.mpf(0),
                 [0, 1, 5, mp.inf])
close('Planck_integral', I_quad, mp.pi**4 / 15, atol=mp.mpf('1e-60'))
exact('Planck_integral_zeta', 6 * sp.zeta(4) - sp.pi**4 / 15)
Ts, Gs, hs, cs, ks = sp.symbols('T G h c k_B', positive=True)
u_symbol = 8 * sp.pi**5 * (ks*Ts)**4 / (15*hs**3*cs**3)
u_hbar = sp.pi**2 * (ks*Ts)**4 / (15*(hs/(2*sp.pi))**3*cs**3)
exact('h_and_hbar_blackbody_equivalence', u_symbol-u_hbar)
sigma_symbol = 2*sp.pi**5*ks**4/(15*hs**3*cs**2)
exact('Stefan_flux_equivalence', u_symbol-4*sigma_symbol*Ts**4/cs)
rho_symbol = u_symbol / cs**MASS_C_POWER
tau_symbol = 1/sp.sqrt(6*sp.pi*Gs*rho_symbol)
tau_simplified = sp.sqrt(5*hs**3*cs**5/(16*sp.pi**6*Gs*(ks*Ts)**4))
exact('tau_independent_simplification', tau_symbol-tau_simplified)
exact('temperature_log_sensitivity', sp.diff(tau_symbol, Ts)*Ts/tau_symbol+2)
exact('G_log_sensitivity', sp.diff(tau_symbol, Gs)*Gs/tau_symbol+sp.Rational(1,2))
exact('double_temperature_quarters_tau', tau_symbol.subs(Ts,2*Ts)/tau_symbol-sp.Rational(1,4))
exact('quadruple_G_halves_tau', tau_symbol.subs(Gs,4*Gs)/tau_symbol-sp.Rational(1,2))

# Independent SI exponent arithmetic, ordered kg,m,s,K.
d_kB = sp.Matrix([1,2,-2,-1]); d_T = sp.Matrix([0,0,0,1])
d_h = sp.Matrix([1,2,-1,0]); d_c = sp.Matrix([0,1,-1,0])
d_G = sp.Matrix([-1,3,-2,0])
d_u = 4*(d_kB+d_T)-3*d_h-3*d_c
d_rho = d_u-MASS_C_POWER*d_c
d_tau = -(d_G+d_rho)/2
check('energy_density_SI_dimension', d_u == sp.Matrix([1,-1,-2,0]), list(d_u),
      '[1,-1,-2,0]')
check('mass_density_SI_dimension', d_rho == sp.Matrix([1,-3,0,0]), list(d_rho),
      '[1,-3,0,0]')
check('clock_SI_dimension', d_tau == sp.Matrix([0,0,1,0]), list(d_tau),
      '[0,0,1,0]')
exact('Julian_Gyr_seconds', gyr_seconds-sp.Integer(31557600000000000))

sub = {Ts:T, Gs:G, hs:h, cs:c, ks:kB}
u = numeric(u_symbol.subs(sub)); rho = numeric(rho_symbol.subs(sub))
tau_seconds = numeric(tau_symbol.subs(sub))
tau_gyr = tau_seconds/numeric(gyr_seconds)
direct_hbar = mp.pi**2*(numeric(kB)*numeric(T))**4 / (
    15*(numeric(h)/(2*mp.pi))**3*numeric(c)**3)
close('independent_hbar_numeric', u, direct_hbar)
close('rho_mass_conversion', rho*numeric(c)**2, u)
close('independent_tau_numeric', tau_seconds, numeric(tau_simplified.subs(sub)))
sigma_exact = numeric(sigma_symbol.subs(sub))
sigma_prefix = mp.mpf(row_sigma[1].replace(' ', '').replace('...', ''))
check('NIST_Stefan_Boltzmann_prefix', sigma_prefix <= sigma_exact < sigma_prefix+mp.mpf('1e-17'),
      mp.nstr(sigma_exact, 45), 'displayed truncated prefix plus <1e-17', 'transcription')
close('printed_energy_density', u, mp.mpf('4.1746783808e-14'), atol=mp.mpf('5e-25'))
close('printed_mass_density', rho, mp.mpf('4.6449561344e-31'), atol=mp.mpf('5e-42'))
close('printed_tau_Gyr', tau_gyr, mp.mpf('1310.846386'), atol=mp.mpf('0.0000005'))

corners = []
for tsign in (-1, 1):
    for gsign in (-1, 1):
        Ti=T+tsign*dT; Gi=G+gsign*dG
        value=numeric(tau_symbol.subs({**sub,Ts:Ti,Gs:Gi}))/numeric(gyr_seconds)
        corners.append({'T_sign':tsign,'G_sign':gsign,
                        'T_K':str(Ti),'G_SI':str(Gi),'tau_Gyr':mp.nstr(value,55)})
minimum = min(corners, key=lambda row:mp.mpf(row['tau_Gyr']))
maximum = max(corners, key=lambda row:mp.mpf(row['tau_Gyr']))
check('positive_rectangle_domain', T-dT>0 and G-dG>0,
      [str(T-dT),str(G-dG)], 'both positive')
check('rectangle_minimum_orientation', (minimum['T_sign'],minimum['G_sign']) == (1,1),
      [minimum['T_sign'],minimum['G_sign']], '[1,1]')
check('rectangle_maximum_orientation', (maximum['T_sign'],maximum['G_sign']) == (-1,-1),
      [maximum['T_sign'],maximum['G_sign']], '[-1,-1]')
close('printed_rectangle_lower',mp.mpf(minimum['tau_Gyr']),mp.mpf('1310.283540'),atol=mp.mpf('0.0000005'))
close('printed_rectangle_upper',mp.mpf(maximum['tau_Gyr']),mp.mpf('1311.409589'),atol=mp.mpf('0.0000005'))
check('central_inside_rectangle', mp.mpf(minimum['tau_Gyr'])<tau_gyr<mp.mpf(maximum['tau_Gyr']),
      mp.nstr(tau_gyr,25),'strictly between extremes')
wrong_energy_tau = 1/mp.sqrt(6*mp.pi*numeric(G)*u)
close('missing_c_factor_witness', tau_seconds/wrong_energy_tau,numeric(c))
lab_fraction = numeric(dG/G)

categories={name:{'pass':sum(r['ok'] for r in checks if r['category']==name),
                  'fail':sum(not r['ok'] for r in checks if r['category']==name)}
            for name in sorted({r['category'] for r in checks})}
result={'pass':sum(r['ok'] for r in checks),'fail':sum(not r['ok'] for r in checks),
        'categories':categories,'checks':checks,
        'exact_SI_inputs':{n:str(v) for n,v in [('T',T),('dT',dT),('G',G),('dG',dG),('c',c),('h',h),('kB',kB)]},
        'values':{'u_J_m3':mp.nstr(u,60),'rho_kg_m3':mp.nstr(rho,60),
                  'tau_seconds':mp.nstr(tau_seconds,60),'tau_Gyr':mp.nstr(tau_gyr,60),
                  'sigma_W_m2_K4':mp.nstr(sigma_exact,60),
                  'laboratory_G_relative_standard_uncertainty':mp.nstr(lab_fraction,45),
                  'wrong_energy_input_inverse_root_SI_numeric':mp.nstr(wrong_energy_tau,45),
                  'wrong_energy_input_units':'s^2/m; not a time',
                  'eta':'unidentified; no value inferred from laboratory uncertainty'},
        'corners':corners,
        'scope':'Deterministic normalization and source transcription, not measured age or empirical validation; original clock theorem not rerun.',
        'versions':{'python':platform.python_version(),'sympy':sp.__version__,'mpmath':mp.__version__}}
output=HERE/args.output
if output.exists():
    raise RuntimeError('refusing to overwrite existing output')
output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:result[key] for key in ('pass','fail','categories','values','corners')},indent=2))
for row in checks:
    if not row['ok']:
        print('FAILED',row['name'],row['observed'],'EXPECTED',row['expected'])
raise SystemExit(0 if result['fail']==0 else 1)
