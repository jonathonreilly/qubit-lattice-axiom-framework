from pathlib import Path
import json
import pypdf
import fitz

HERE = Path(__file__).resolve().parent
pdf = HERE / 'sources/Fixsen_0911.1955.pdf'
reader = pypdf.PdfReader(str(pdf))
texts = [page.extract_text() for page in reader.pages]
full = '\n\n'.join(f'PHYSICAL PDF PAGE {i + 1}\n{text}'
                   for i, text in enumerate(texts))
(HERE / 'Fixsen_extracted_all_pages_v1.txt').write_text(full)
doc = fitz.open(str(pdf))
rendered = []
for page_number in (5, 6):
    path = HERE / f'Fixsen_page_{page_number}_v1.png'
    doc[page_number - 1].get_pixmap(matrix=fitz.Matrix(1.5, 1.5)).save(str(path))
    rendered.append(path.name)
    print(f'PHYSICAL PDF PAGE {page_number}\n{texts[page_number - 1]}')
table_lines = (HERE / 'sources/NIST_2022_allascii.txt').read_text().splitlines()
keys = ('Newtonian constant of gravitation ', 'speed of light in vacuum ',
        'Planck constant ', 'Boltzmann constant ')
selected = [{'line_number': i + 1, 'text': line}
            for i, line in enumerate(table_lines)
            if any(line.startswith(key) for key in keys)]
(HERE / 'NIST_selected_rows_v1.json').write_text(
    json.dumps({'header': table_lines[:12], 'rows': selected}, indent=2) + '\n')
print('NIST HEADER AND SELECTED ROWS')
print(json.dumps({'header': table_lines[:12], 'rows': selected}, indent=2))
(HERE / 'PDF_EXTRACTION_v1.json').write_text(json.dumps({
    'pages': len(reader.pages), 'text_extractor': 'pypdf',
    'pypdf_version': pypdf.__version__, 'renderer': 'PyMuPDF',
    'renderer_version': fitz.VersionBind, 'rendered_pages': rendered,
    'render_scale': 1.5, 'visual_inspection': 'separately required'
}, indent=2) + '\n')
