from pathlib import Path
import datetime
import hashlib
import json
import shlex
import subprocess
import sys

HERE = Path(__file__).resolve().parent
label = sys.argv[1]
argv = sys.argv[2:]
if not argv:
    raise SystemExit('expected a label and child command')
record_path = HERE / f'{label}_run_v1.json'
if record_path.exists():
    raise SystemExit('refusing to overwrite an existing run')
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
proc = subprocess.run(argv, cwd=HERE, capture_output=True)
ended = datetime.datetime.now(datetime.timezone.utc).isoformat()
stdout_path = HERE / f'{label}_stdout_v1.txt'
stderr_path = HERE / f'{label}_stderr_v1.txt'
stdout_path.write_bytes(proc.stdout)
stderr_path.write_bytes(proc.stderr)
def binding(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(HERE)), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}
scripts = []
for arg in argv:
    path = Path(arg)
    if not path.is_absolute():
        path = HERE / path
    if path.is_file() and path.suffix == '.py':
        scripts.append(binding(path))
record = {'argv': argv, 'command': shlex.join(argv), 'cwd': str(HERE),
          'started_at': started, 'ended_at': ended,
          'child_exit_code': proc.returncode, 'scripts': scripts,
          'stdout': binding(stdout_path), 'stderr': binding(stderr_path)}
record_path.write_text(json.dumps(record, indent=2) + '\n')
sys.stdout.buffer.write(proc.stdout)
sys.stderr.buffer.write(proc.stderr)
print(json.dumps({'record': record_path.name, 'child_exit_code': proc.returncode}))
raise SystemExit(proc.returncode)
