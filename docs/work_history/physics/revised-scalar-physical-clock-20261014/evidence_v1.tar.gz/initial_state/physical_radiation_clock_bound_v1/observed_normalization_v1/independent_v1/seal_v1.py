from pathlib import Path
import datetime
import hashlib
import json
import sys

HERE=Path(__file__).resolve().parent
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def read(name): return json.loads((HERE/name).read_text())
def bind(name):
    path=HERE/name
    return {'path':name,'bytes':path.stat().st_size,'sha256':sha(path)}
def write(name,value):
    path=HERE/name
    if path.exists(): raise RuntimeError('refusing overwrite of '+name)
    path.write_text(json.dumps(value,indent=2)+'\n')

for name in ['FINAL_SOURCE_CONFIRMATION_v1.json','FAILURES_v1.json',
             'SEAL_VALIDATION_v1.json','MANIFEST_v1.json','RECEIPT_v1.json']:
    if (HERE/name).exists(): raise RuntimeError('seal output already exists: '+name)
checks=[]
def check(name,condition,details):
    checks.append({'name':name,'ok':bool(condition),'details':details})
sources=read('SOURCE_BINDINGS_v1.json')['source_pairs']
for row in sources:
    check('final_source_'+row['snapshot_path'],
          sha(Path(row['original_path']))==row['sha256']==sha(HERE/row['snapshot_path'])
          and Path(row['original_path']).stat().st_size==row['bytes']==(HERE/row['snapshot_path']).stat().st_size,
          row)
for label,expected in [('extraction',0),('baseline',0),('damage_missing_c',1),('validation',0)]:
    record=read(label+'_run_v1.json')
    check(label+'_exit',record['child_exit_code']==expected,record['child_exit_code'])
    for row in record['scripts']+[record['stdout'],record['stderr']]:
        check(label+'_hash_'+row['path'],sha(HERE/row['path'])==row['sha256'] and (HERE/row['path']).stat().st_size==row['bytes'],row)
base=read('BASELINE_RESULTS_v1.json');damage=read('DAMAGE_MISSING_C_RESULTS_v1.json')
validation=read('EVIDENCE_VALIDATION_v1.json')
check('baseline_count',base['pass']==39 and base['fail']==0,base['categories'])
check('damage_count',damage['pass']==29 and damage['fail']==10,damage['categories'])
check('metadata_count',validation['pass']==38 and validation['fail']==0,
      {'pass':validation['pass'],'fail':validation['fail']})
check('all_existing_artifacts_regular',not any(p.is_symlink() for p in HERE.rglob('*')),'no symbolic links')
if not all(row['ok'] for row in checks):
    write('SEAL_FAILURE_v1.json',{'checks':checks})
    raise RuntimeError('seal identity check failed; preserved SEAL_FAILURE_v1.json')

now=datetime.datetime.now(datetime.timezone.utc).isoformat()
write('FINAL_SOURCE_CONFIRMATION_v1.json',{
    'created_utc':now,'reviewer':'/root/local_response_check',
    'source_pairs':sources,'all_match':True,'source_corrections_required':False,
    'conclusion':'Exact published-input transcription and SI normalization confirmed; deterministic rectangle only, no measured age or eta identification.',
    'scope':'Original reviewer final unchanged-source confirmation; no formal audit or authority/status promotion'})
failed=[row for row in damage['checks'] if not row['ok']]
write('FAILURES_v1.json',{
    'unexpected_failures':[],
    'intentional_damage':{'actual_script':bind('damages/missing_c_squared_v1.py'),
                          'actual_child_exit':1,'pass':29,'fail':10,'failed_checks':failed,
                          'output':bind('DAMAGE_MISSING_C_RESULTS_v1.json'),
                          'diff':bind('damages/missing_c_squared_v1.diff')},
    'display_truncation':'Two long tool outputs were shortened in display; complete saved output retained and relevant remaining report text read separately. No computation failed as a result.',
    'earlier_units':'Only the bound original clock report/receipt reused; historical failures remain in their immutable original evidence and are neither deleted nor relabeled here.'})
write('SEAL_VALIDATION_v1.json',{'pass':sum(r['ok'] for r in checks),
      'fail':sum(not r['ok'] for r in checks),'checks':checks,
      'scope':'Final byte-identity and recorded-exit verification, not a new science run'})
artifacts=[]
for path in sorted(HERE.rglob('*')):
    if path.is_file() and path.name not in ['MANIFEST_v1.json','RECEIPT_v1.json']:
        artifacts.append(bind(str(path.relative_to(HERE))))
write('MANIFEST_v1.json',{'created_utc':now,'unit':str(HERE),
      'artifact_count':len(artifacts),'artifacts':artifacts,
      'excludes':['MANIFEST_v1.json','RECEIPT_v1.json'],
      'scope':'Immutable content manifest; receipt binds this manifest'})
receipt={
    'created_utc':now,'type':'focused_independent_observed_normalization_check',
    'checker':'/root/local_response_check','direct_scientific_author':'/root',
    'unit':str(HERE),'report':bind('REPORT_v1.md'),'manifest':bind('MANIFEST_v1.json'),
    'artifact_count':len(artifacts),'live_source_pair_count':len(sources),'source_pairs':sources,
    'new_checks':{'pass':39,'fail':0,'formula':{'pass':26,'fail':0},
                  'transcription':{'pass':13,'fail':0},
                  'result':bind('BASELINE_RESULTS_v1.json'),
                  'command_record':bind('baseline_run_v1.json')},
    'values':base['values'],'corners':base['corners'],
    'actual_damaged_copy':{'pass':29,'fail':10,'exit_code':1,
                           'script':bind('damages/missing_c_squared_v1.py'),
                           'results':bind('DAMAGE_MISSING_C_RESULTS_v1.json'),
                           'command_record':bind('damage_missing_c_run_v1.json'),
                           'failed_check_names':[row['name'] for row in failed]},
    'unexpected_failures':[],'failure_ledger':bind('FAILURES_v1.json'),
    'metadata':{'validation_pass':38,'validation_fail':0,
                'validation':bind('EVIDENCE_VALIDATION_v1.json'),
                'seal_pass':len(checks),'seal_fail':0,
                'seal_validation':bind('SEAL_VALIDATION_v1.json'),
                'science_rerun':False},
    'reused_dependency':{'report':bind('sources/clock_REPORT_v1.md'),
                         'receipt':bind('sources/clock_RECEIPT_v1.json'),
                         'original_new_science_count':'186/0',
                         'original_metadata_count':'198/0',
                         'full_original_unit_rehashed':False,'rerun':False,
                         'added_to_current_counts':False,
                         'role':'Conditional coefficient and limitation provenance only'},
    'original_reviewer_confirmation':bind('FINAL_SOURCE_CONFIRMATION_v1.json'),
    'commands':bind('COMMANDS_v1.json'),
    'seal_command':{'argv':[sys.executable,'-B',str(Path(__file__).resolve())],
                    'cwd':str(HERE),'script_sha256':sha(Path(__file__).resolve()),
                    'scope':'Final identity checks and serialization; no science rerun'},
    'bounded_conclusion':'The primary-input transcription, SI blackbody normalization, tau_ref=1310.84638597313669 Julian Gyr and stipulated uncertainty rectangle are correct. No source amendment is required.',
    'limitations':['This is a deterministic reference scale, not a measured cosmic age or age bound.',
                   'Laboratory G measurement uncertainty does not identify the theorem response-error ceiling eta.',
                   'R, flatness, bath history, coupling conditions and laboratory/cosmological environment matching are not supplied by present CMB temperature.',
                   'The uncertainty rectangle has no asserted simultaneous confidence coverage or covariance model.',
                   'The Planck-spectrum normalization is checked conditionally, not empirically remeasured.',
                   'No original clock theorem rerun, new fit, latest-estimate claim or formal audit was performed.'],
    'writes_confined_to_unit':True,'producer_code_results_accessed':False,
    'git_network_runtime_settings_or_authority_changed':False,'immutable_after_seal':True}
write('RECEIPT_v1.json',receipt)
for row in artifacts:
    if sha(HERE/row['path'])!=row['sha256']:
        raise RuntimeError('post-seal artifact changed: '+row['path'])
if sha(HERE/'MANIFEST_v1.json')!=receipt['manifest']['sha256']:
    raise RuntimeError('manifest changed during seal')
print(json.dumps({'created_utc':now,'artifact_count':len(artifacts),'source_pairs':len(sources),
      'report':bind('REPORT_v1.md'),'manifest':bind('MANIFEST_v1.json'),
      'receipt':bind('RECEIPT_v1.json'),'metadata_final_pass':len(checks),
      'postseal_identity':'all listed artifacts and receipt-bound manifest verified; no further writes'},indent=2))
