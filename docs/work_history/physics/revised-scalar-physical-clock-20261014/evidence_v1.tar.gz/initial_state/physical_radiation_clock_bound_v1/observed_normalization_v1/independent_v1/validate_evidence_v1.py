from pathlib import Path
import hashlib
import json

HERE=Path(__file__).resolve().parent
checks=[]
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def check(name,condition,details):
    checks.append({'name':name,'ok':bool(condition),'details':details})
def read(name): return json.loads((HERE/name).read_text())

sources=read('SOURCE_BINDINGS_v1.json')['source_pairs']
for row in sources:
    for kind,path in [('live',Path(row['original_path'])),('snapshot',HERE/row['snapshot_path'])]:
        check(f'{kind}_{row["snapshot_path"]}',
              path.is_file() and sha(path)==row['sha256'] and path.stat().st_size==row['bytes'],
              str(path))
for label,expected_exit in [('extraction',0),('baseline',0),('damage_missing_c',1)]:
    record=read(label+'_run_v1.json')
    check(label+'_exit',record['child_exit_code']==expected_exit,record['child_exit_code'])
    for bound in record['scripts']+[record['stdout'],record['stderr']]:
        path=HERE/bound['path']
        check(label+'_binding_'+bound['path'],sha(path)==bound['sha256'] and path.stat().st_size==bound['bytes'],bound)
baseline=read('BASELINE_RESULTS_v1.json')
check('baseline_39_0',baseline['pass']==39 and baseline['fail']==0 and all(row['ok'] for row in baseline['checks']),baseline['categories'])
check('formula_and_source_counts',baseline['categories']=={'formula':{'pass':26,'fail':0},'transcription':{'pass':13,'fail':0}},baseline['categories'])
mutation=read('MUTATION_PROTOCOL_v1.json')
damage=read('DAMAGE_MISSING_C_RESULTS_v1.json')
failed=[row['name'] for row in damage['checks'] if not row['ok']]
check('actual_damage_29_10',damage['pass']==29 and damage['fail']==10,failed)
check('required_damage_failures',set(mutation['required_failure_checks'])<=set(failed),failed)
base=HERE/mutation['original']; changed=HERE/mutation['damaged']
check('baseline_script_binding',sha(base)==mutation['original_sha256'],sha(base))
check('actual_damaged_script_binding',sha(changed)==mutation['damaged_sha256'],sha(changed))
check('damage_exact_single_edit',base.read_text().count(mutation['old'])==1 and changed.read_text()==base.read_text().replace(mutation['old'],mutation['new']),mutation)
for row in read('PRE_EXECUTION_FREEZE_v1.json')['artifacts']:
    path=HERE/row['path']
    check('pre_execution_'+row['path'],sha(path)==row['sha256'] and path.stat().st_size==row['bytes'],row)
clock=read('sources/clock_RECEIPT_v1.json')
report=HERE/'sources/clock_REPORT_v1.md'
check('reused_clock_receipt_report_binding',sha(report)==clock['report']['sha256'] and report.stat().st_size==clock['report']['bytes'],clock['report'])
visual=read('VISUAL_SOURCE_CONFIRMATION_v1.json')
check('visual_source_pdf_binding',sha(HERE/'sources/Fixsen_0911.1955.pdf')==visual['pdf_sha256'],visual['pdf_sha256'])
check('two_visual_pages_retained',all((HERE/name).is_file() and (HERE/name).stat().st_size>10000 for name in visual['images']),visual['images'])
check('no_symlinks_in_unit',not any(p.is_symlink() for p in HERE.rglob('*')),'all independent unit artifacts checked')
out={'pass':sum(row['ok'] for row in checks),'fail':sum(not row['ok'] for row in checks),
     'checks':checks,'scope':'Source, provenance and expected negative-control identity validation only; no formula or original clock rerun'}
target=HERE/'EVIDENCE_VALIDATION_v1.json'
if target.exists(): raise RuntimeError('refusing overwrite')
target.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
raise SystemExit(0 if not out['fail'] else 1)
