# Staged physical-clock canonical correspondence

The frozen staged note and runner correspond to the two previously checked source units. No substantive correction is required. The staged note SHA-256 is `be76862bcb1477db57553642cd1a29738acb76db3101be24daf01ca275ab9d29`; the staged runner SHA-256 is `b224dd7fe83fee401345446090a8ae04ec2ad032d01e3bc7b49af9c19de20631`.

This is a source and saved-execution correspondence check by `/root/scalar_energy_check`, with direct scientific authorship retained by `/root`. It is neither a new blind mathematical derivation nor a formal audit. No producer checker was executed. The saved staged **69/0** is the parent's actual execution, divided into **57 clock** and **12 published-input normalization** rows. New work here consists of **145/0 reused-seal identity checks** and **146/0 static correspondence checks**. These metadata counts are separate from all science counts.

The conclusion applies only to the staged bytes and their frozen inputs. It does not certify live canonical installation, a runner cache, a Git commit, an archive, a review unit, or a delivery. Those identities require a later check. Intended destination paths in ORIGINAL_DISPOSITIONS_v1.json are plans, not assertions that copying has occurred.

## Frozen and reused evidence

SOURCE_BINDINGS_v1.json binds 75 original/snapshot pairs, including both staged files, the lineage and saved staging records, original proof versions and protocols, both original scripts and executions, all five original clock damaged implementations and their actual records, published-input bytes, both independent reports/receipts/manifests, and the three declared canonical input notes. All copies are byte preserving.

| Reused source or review | SHA-256 |
| --- | --- |
| Clock DERIVATION_v2.md | `512fcbb9c7bdf1a61f47c16386b6f030ca233bb15297ba227afe7ed1134df7d3` |
| Observed CALCULATION_v1.md | `fcf3a05ab25c402bbcdfa45917d3037b1c4b56bad7301e21c8529f5ed448905e` |
| Clock independent REPORT_v1.md | `e612b8d37dc3fa4dad9c1e393f4dfe177802857db33d21a1caf09d3613bba110` |
| Clock independent RECEIPT_v1.json | `30bd74f31d8386b32c3567a8f310a47f44ed7f7eb8a65f8a2b3bb7cbcec9ff4c` |
| Observed independent REPORT_v1.md | `2c7b2af261b2597efbb58535147ed7f26fadca27a47ee654ba7664f4617a6626` |
| Observed independent RECEIPT_v1.json | `a4f7cccaddfc05402d2c06b2f554083b95128d8c8b35167d272ff925c9dd545d` |

Both independent reports were read completely. The clock seal's 76 artifacts and eight live/snapshot pairs, and the observed seal's 45 artifacts and six pairs, all pass current hash/size and exact inventory validation. Report and manifest hashes also agree with their receipts. Thus the reused original 186/0 clock check with seven actual damages and the original 39/0 observed check with its actual missing-c-squared damage remain exactly identifiable. They were not rerun or added to a new science total.

The clock seal's finite-mass dependency and its disclosed original checker-quality history remain part of that immutable seal. This unit rehashes the two immediate independent units and their declared source pairs; it does not claim to rerun or recursively validate every artifact of every older campaign. The saved Fixsen PDF and NIST text are reused source bytes. There was no new acquisition, visual reinspection, latest-estimate claim, or new empirical evaluation here.

## Exact note correspondence and claim boundaries

Section I is the entire checked clock DERIVATION_v2 body after removing its first title, trimming exterior blank lines, and demoting second-level headings to third-level headings. Section II is the entire CALCULATION_v1 body under the corresponding title removal. Independent section extraction yields equality in both cases; the retained comparison diffs are empty. The newly written introduction, input links, section wrappers, and computational-scope ending were read in full.

The main source remains a conditional statement about a connected regular spatially flat history with positive selected bath density, nonnegative other energy, Q>0, and one uniform coupling bound q<=qmax<1/3. The charge comparison D(t)>=D0/R must hold at every earlier event. Positive final physical expansion, the coupling-speed inequality and continuity supply the Einstein/physical expansion signs. This is not an assertion that the integrability condition c<2 alone supplies those signs.

The completed square and positive-root argument lead to d(A a_E^2)/dt_J>=sqrt[(4-3qmax)D0/(3QR)]. Consequently the finite regular interval is strictly below its limiting endpoint bound, whereas the past-duration supremum obeys a non-strict upper bound. The canonical body preserves both distinctions. It also keeps the separate qmax=0 treatment, the distinction between instantaneous square equality and an integrated saturating solution, and the candidate's positive-Hv limitation on the pure-radiation normalization control. A finite chart endpoint is not classified as inextendible. Positive-curvature histories remain outside the flat proof.

The physical density conversion is rho_E,0=C0^2 rho_J,0, with rho_J,0 a physical bath density in this unit. The endpoint coefficient is therefore sqrt[3QR/(C0 rho_J,0)]/sqrt(4-3qmax). No separately supplied global A cap or measured vacuum scale is used. This removal does not select an action, scalar state or matter history.

The declared complete-action note is byte-identical to the action used in the clock independent seal: SHA-256 `39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000`. It supplies q=a/J<a<1/3 on the stated finite-field domain. The relevant local-calibration section of the physical-past note was inspected: it explicitly conditions the principal response and nonnegative-mass extension on their source/background regimes, and treats G_cal<=(1+eta)G_pr as an additional positive calibration/error premise. The staged note retains this condition. A different calibration background leaves C0; it is not silently replaced by the same-background expression.

The relevant finite-mass section of the declared thermal note was also inspected. Its R=(11/4)^(1/3) range is for the same isolated equilibrium photon/pair bath at fixed entropy, with supplied species, masses, statistics and zero chemical potentials. The clock note applies that range as one conditional realization of its charge premise. It does not infer a uniform photon-only charge floor through an arbitrary real thermal history from today's temperature. Other claims in the declared input notes are not newly endorsed by this linkage check.

The observed normalization keeps the Planck blackbody premise, rho_mass=u/c^2 in SI, and the Julian-year convention. It retains the conditional nature of tau_ref sqrt[R(1+eta)], distinguishes the reported uncertainty in laboratory G from eta, and labels the rectangular input sensitivity as neither a simultaneous confidence interval nor a fit. The wrapper adds no measurement or age conclusion. The displayed reference and rectangle endpoints are ordinary rounded numerical summaries, not a separate rigorous interval certificate.

## Runner-body and input correspondence

Both original scientific bodies are exactly equal to the corresponding de-indented staged function bodies, including their final newline. The only surrounding operations are imports, isolation into functions, the observed input literal and precision setting, return dictionaries, and main aggregation/optional output. No function, row, residual, local-state condition or numerical value was omitted from those bodies.

The body hashes in CANONICAL_LINEAGE_v1.json use the body with its terminal newline removed. That convention is now explicit in BODY_CORRESPONDENCE_v1.json. The raw extracted bodies, including newline, instead have hashes `3c97d7128e93107ac59380309cc6cd636a622218e9896e503a86fd42935866fb` for clock and `5db5ea25f71633a23285956bbab8849b0d9ae265ac3502f531cfe239bc5412fc` for normalization. Each raw original equals its raw de-indented staged counterpart. This is a hash-boundary convention, not a scientific or byte-correspondence failure.

The embedded Python input literal is semantically and type-preservingly identical to the original INPUT_PROTOCOL_v1.json, whose hash is `a0c9db1f70dba3db9e614f6b10b773b7ec47f6c16ba2e1f15a25235491ee79f3`. The lineage phrase “verbatim as Python data” means identical parsed data; the Python literal is not asserted to retain JSON indentation or quote bytes. The original 50-digit mpmath setting and string conversions remain intact.

The main wrapper executes both function calls, removes only their checks lists into the aggregate, retains all other returned substantive outputs, prefixes row names, and computes pass/fail counts from the actual row booleans. It exits nonzero on any failure and refuses to overwrite an existing optional output file. Its four declared inputs are the intended final physical-clock note plus the complete action, physical-past calibration note and thermal note. The three extant dependencies were frozen and verified. The future self-input path and relative note links are interpreted in their intended docs/scripts placement; no live-input cache freshness is asserted while staging remains outside that layout.

## Actual saved execution and row substance

The saved staging command records the exact staged runner path, --output path, working directory, timestamp and runner digest. Its completion record gives exit 0. The full saved stdout parses to the same JSON object as STAGED_RESULTS_v1.json; stderr is empty. The result's self-hash equals both the saved command hash and the frozen runner hash. Every original row, including residual/detail fields, survives prefixing in its original order. All 69 names are unique and both unit/aggregate counts are derived correctly.

The 57 clock rows comprise 16 symbolic/normalization/domain identities, 28 rational parameter/local-constraint checks at four k values, nine radiation-plus-vacuum solution/duration and hyperbolic-gap controls, two explicitly nonconserved de Sitter charge controls, and two explicitly outside-domain large-coupling sign controls. The finite parameter rows do not prove the all-domain theorem; its proof is the written argument already independently checked. In particular a local constraint point and a kinematic sign witness are not mislabeled as complete candidate histories.

The 12 observed rows comprise the independent blackbody route, SI mass-energy conversion, two scaling identities, two uncertainty-rectangle orientation checks, three SI dimension checks, and three specified q-envelope samples. Their empirical status is formula/numerical development, not 12 observed tests of the action.

All four candidate-envelope records, the observed central values and all four uncertainty corners agree exactly with the original JSON values. For example, the stored reference is 1310.8463859731366932641284297618419 Julian Gyr; its long string is computational output from adopted finite-precision inputs, not reported experimental precision. The corresponding stored mass density is 4.644956134403366771447101471178197e-31 kg/m^3. ROW_INVENTORY_v1.json preserves every actual row and the full substantive payload.

The five original author damages named by the canonical note were checked against their one-edit source changes, actual script hashes, saved result self-hashes, execution hashes, nonzero exits and named failed witnesses. Their counts remain 56/1, 56/1, 53/4, 55/2 and 56/1, respectively. This is recovery of actual historical evidence, not five new staged damaged-runner executions. The separately reused seven clock-independent damages and observed missing-c-squared damage remain in their own seals. Three new in-memory metadata perturbations test rejection of an altered input constant, a dropped actual row and an altered substantive value; they are not science-damage executions.

## Failure record and final disposition

No new checker execution failed: preparation/reuse validation was 145/0 and static correspondence was 146/0. Initial exploratory comparison of the lineage digest against a body including its terminal newline did not match; testing the explicit newline-trim convention resolved both values without any file change. That diagnostic and its exact alternative hashes are preserved in FAILURE_LEDGER_v1.json. Tool output truncation during source inventory/review was addressed by narrower subsequent reads; a truncated display was never treated as a full read. No source or execution failure is erased or relabeled.

The two staged source files are retained unchanged. Original sources, execution records and independent seals retain their original dispositions, with local immutable recovery snapshots in this unit. Later copying to docs/scripts, fresh live-cache execution and delivery identity require separate binding to those actual bytes. This report does not authorize or record those actions.

MANIFEST_v1.json binds this unit's artifacts, excluding itself and RECEIPT_v1.json; the receipt binds the manifest, full report, source map, exact command records, reused seals and limited conclusion. All writes in this task are inside physical_clock_canonical_correspondence_v1. No parent source, prior receipt, Git, PR, runtime, lock, settings, audit or authority state was changed.
