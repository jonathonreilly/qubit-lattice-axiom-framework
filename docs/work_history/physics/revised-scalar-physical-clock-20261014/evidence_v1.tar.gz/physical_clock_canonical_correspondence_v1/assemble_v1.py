from pathlib import Path
import datetime as dt
import hashlib
import json

UNIT=Path(__file__).resolve().parent
def write(name,value):
    path=UNIT/name
    assert not path.exists(),path
    path.write_text(json.dumps(value,indent=2)+'\n')
def ref(name):
    data=(UNIT/name).read_bytes()
    return dict(path=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

bindings=json.loads((UNIT/'SOURCE_BINDINGS_v1.json').read_text())['sources']
primary=[]
dependencies=[]
for row in bindings:
    recovery=dict(path=row['snapshot_path'],sha256=row['sha256'],bytes=row['bytes'])
    if row['role']=='reviewed_staged_source':
        destination=('docs/' if row['original_path'].endswith('.md') else 'scripts/')+Path(row['original_path']).name
        primary.append(dict(original_path=row['original_path'],original_sha256=row['sha256'],
                            disposition='retained',recovery=recovery,final_path=destination,
                            final_sha256=row['sha256'],final_identity_verified=False,
                            final_path_status='intended byte-preserving destination only; no delivery check',
                            explanation='The original staged file is unchanged. Its same-byte final placement must be verified separately after copying.'))
    else:
        dependencies.append(dict(original_path=row['original_path'],original_sha256=row['sha256'],
                                 disposition='retained dependency or historical evidence',recovery=recovery,
                                 final_path=row['original_path'],final_sha256=row['sha256'],
                                 meaning='Existing original remains unchanged; not a new canonical delivery path.'))
write('ORIGINAL_DISPOSITIONS_v1.json',dict(
    scope='Staged-source dispositions only. Intended docs/scripts destinations are not asserted to exist or be delivered.',
    original_dispositions=primary,dependency_dispositions=dependencies,
    source_count=len(bindings),new_delivery_verified=False))

write('FAILURE_LEDGER_v1.json',dict(
    checker_execution_failures=[],source_corrections_required=[],
    resolved_diagnostics=[dict(
        kind='Body digest boundary convention',
        observation='Exploratory raw start/stop slices including the final newline did not equal the lineage body digests. No assertion, science run or source failed.',
        clock_raw_sha256='3c97d7128e93107ac59380309cc6cd636a622218e9896e503a86fd42935866fb',
        clock_newline_trimmed_sha256='d456aff13988d2a553f7e01fcbf6e87ae55a764cb15a8d53caac20bf5f81e297',
        observed_raw_sha256='5db5ea25f71633a23285956bbab8849b0d9ae265ac3502f531cfe239bc5412fc',
        observed_newline_trimmed_sha256='f52a57f75147cf00d464599d0eff425e7357e7878b5e90954016c35c3d3cc8f3',
        resolution='Both raw bodies exactly equal the de-indented staged bodies; both .rstrip(newline) digests equal the lineage. Explicitly checked in check_correspondence_v1.py.',
        files_changed=False),dict(
        kind='Read display truncation',
        observation='Two broad text-read calls truncated displayed source/receipt output. The source files themselves were unchanged.',
        resolution='Repeated narrower reads supplied the complete observed original script, complete clock report, compact full receipt fields and relevant imports; both manifests were parsed in full and every listed artifact and source pair rehashed.',
        result_claim_limit='Metadata verification does not assert fresh mathematical review of every historical artifact.')],
    historical_failure_records=dict(
        original_five_damages=ref('HISTORICAL_DAMAGE_BINDING_v1.json'),
        reused_clock_receipt=ref('sources/reused_clock/RECEIPT_v1.json'),
        reused_observed_receipt=ref('sources/reused_observed/RECEIPT_v1.json')),
    new_metadata_perturbations='Three in-memory altered-data witnesses only; no damaged science checker execution.',
    all_original_sources_and_failed_runs_preserved=True))

write('READ_SCOPE_v1.json',dict(
    at=dt.datetime.now(dt.timezone.utc).isoformat(),
    full_text_reads=['staged canonical note','staged canonical runner','CANONICAL_LINEAGE_v1.json',
      'clock DERIVATION_v2.md','observed CALCULATION_v1.md','both original producer scripts',
      'observed INPUT_PROTOCOL_v1.json','both independent REPORT_v1.md files',
      'original five-damage plan and summary','saved staging command/run'],
    parsed_in_full=['all source and dependency manifests/receipts needed for exact validation',
      'saved staged JSON/stdout','both original primary JSON outputs','all five original damaged-copy results and execution records'],
    imported_sections_read=['physical-past note local source calibration section (original lines 278-379)',
      'thermal-bounce note finite-mass bath/charge section (original lines 190-330)'],
    whole_action_reused_by_exact_identity='39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000',
    primary_published_sources='Saved PDF and NIST bytes copied and hashed; prior independent transcription/visual check reused, not repeated.',
    forbidden_actions_not_taken=['producer science execution','new empirical access','parent source changes','prior seal writes',
      'Git operations','PR operations','runtime or lock changes','formal audit or authority operation']))

write('COMMANDS_v1.json',dict(
    scope='Exact recorded new source/metadata subprocess executions. Read-only exploratory shell reads are separately characterized in READ_SCOPE/FAILURE_LEDGER.',
    commands=[json.loads((UNIT/name).read_text()) for name in ['preparation_COMMAND_v1.json','correspondence_COMMAND_v1.json']],
    current_assembly_command=dict(argv=['/usr/local/bin/python3','-B',str(UNIT/'assemble_v1.py')],cwd=str(UNIT)),
    producer_run_count=0))
print(json.dumps(dict(primary_dispositions=len(primary),retained_dependencies=len(dependencies),source_pairs=len(bindings))))
