"""Read-only source/log correspondence. Does not import or run a science checker."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import textwrap

UNIT=Path(__file__).resolve().parent
ROOT=UNIT.parent.parents[3]
SRC=UNIT/'sources'
checks=[]
def sha(data): return hashlib.sha256(data).hexdigest()
def read(rel): return (SRC/rel).read_text()
def js(rel): return json.loads(read(rel))
def ck(name, value, **detail): checks.append(dict(name=name,passed=bool(value),**detail))
def emit(name, value):
    path=UNIT/name
    assert not path.exists(), path
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2)+'\n')
def text_out(name,value):
    path=UNIT/name
    assert not path.exists(),path
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(value)

bindings=json.loads((UNIT/'SOURCE_BINDINGS_v1.json').read_text())
for ref in bindings['sources']:
    live=(ROOT/ref['original_path']).read_bytes()
    frozen=(UNIT/ref['snapshot_path']).read_bytes()
    ck('frozen_source::'+ref['snapshot_path'],live==frozen and sha(live)==ref['sha256'] and len(live)==ref['bytes'])

note_name='EXPONENTIAL_SCALAR_PHYSICAL_CLOCK_BOUNDED_THEOREM_NOTE_2026-10-14.md'
runner_name='exponential_scalar_physical_clock_check.py'
note=read('staged/'+note_name)
runner=read('staged/'+runner_name)
lineage=js('packaging/CANONICAL_LINEAGE_v1.json')
ck('staged_note_expected_identity',sha(note.encode())==lineage['note_sha256']=='be76862bcb1477db57553642cd1a29738acb76db3101be24daf01ca275ab9d29')
ck('staged_runner_expected_identity',sha(runner.encode())==lineage['runner_sha256']=='b224dd7fe83fee401345446090a8ae04ec2ad032d01e3bc7b49af9c19de20631')

body_evidence=[]
for group, name, title, following, ref in [
    ('original_clock','DERIVATION_v2.md','## I. Physical-clock derivation',
     '## II. Published-input normalization and its limit',lineage['proof_sources'][0]),
    ('original_observed','CALCULATION_v1.md','## II. Published-input normalization and its limit',
     '## Computational and empirical scope',lineage['proof_sources'][1])]:
    original=read(group+'/'+name)
    expected=original.split('\n',1)[1].strip().replace('\n## ','\n### ')
    actual=note.split(title,1)[1].split(following,1)[0].strip()
    ck('note_body::'+name,actual==expected)
    ck('proof_source_lineage_hash::'+name,sha(original.encode())==ref['sha256'])
    diff=''.join(difflib.unified_diff(expected.splitlines(True),actual.splitlines(True),fromfile=name,tofile=note_name))
    text_out('comparisons/'+name+'.diff',diff)
    body_evidence.append(dict(source=name,transformation='Remove initial title and exterior blank lines; demote level-two headings to level three.',
                              expected_body_sha256=sha(expected.encode()),actual_body_sha256=sha(actual.encode()),equal=actual==expected))

tree=ast.parse(runner)
functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
code_evidence=[]
for ref, function_name, group, return_expression in [
    (lineage['runner_bodies'][0],'check_clock','original_clock',"{'checks':rows,'candidate_envelopes':examples}"),
    (lineage['runner_bodies'][1],'check_observed_normalization','original_observed',"{'checks':checks,'central':clean(center),'reported_uncertainty_rectangle':clean(corners)}")]:
    original=read(group+'/'+Path(ref['path']).name)
    raw=original[original.index(ref['start']):original.index(ref['stop'])]
    function=functions[function_name]
    interior=''.join(runner.splitlines(keepends=True)[function.lineno:function.end_lineno-1])
    interior=textwrap.dedent(interior)
    actual=interior[interior.index(ref['start']):]
    ck('scientific_body_exact_after_deindent::'+function_name,actual==raw)
    ck('original_code_lineage_hash::'+function_name,sha(original.encode())==ref['sha256'])
    ck('body_lineage_hash_with_terminal_newline_trim::'+function_name,sha(raw.rstrip('\n').encode())==ref['body_sha256'])
    ck('return_wrapper::'+function_name,ast.dump(function.body[-1])==ast.dump(ast.parse('return '+return_expression).body[0]))
    text_out('comparisons/'+function_name+'_source_body.txt',raw)
    text_out('comparisons/'+function_name+'_staged_body.txt',actual)
    text_out('comparisons/'+function_name+'.diff',''.join(difflib.unified_diff(raw.splitlines(True),actual.splitlines(True))))
    code_evidence.append(dict(function=function_name,raw_source_sha256=sha(raw.encode()),deindented_staged_sha256=sha(actual.encode()),
                              lineage_hash=ref['body_sha256'],lineage_convention='rstrip terminal newline before hashing',raw_equal=raw==actual))

observed_function=functions['check_observed_normalization']
input_nodes=[n for n in observed_function.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='inp' for t in n.targets)]
ck('single_embedded_input_literal',len(input_nodes)==1)
literal=ast.literal_eval(input_nodes[0].value)
input_json=js('original_observed/INPUT_PROTOCOL_v1.json')
ck('embedded_input_semantic_identity',literal==input_json)
ck('embedded_input_types_and_roundtripping',json.dumps(literal,sort_keys=True)==json.dumps(input_json,sort_keys=True))
ck('original_observed_precision_preserved',ast.dump(observed_function.body[0])==ast.dump(ast.parse('mp.mp.dps=50').body[0]))
ck('required_symbolic_and_numeric_imports',all(s in runner for s in ['import sympy as S','import mpmath as mp']))

assignments={n.targets[0].id:n.value for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name)}
declared=ast.literal_eval(assignments['AUDIT_INPUT_PATHS'])
expected_inputs=['docs/'+note_name,
    'docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md',
    'docs/EXPONENTIAL_SCALAR_PHYSICAL_PAST_BOUNDED_THEOREM_NOTE_2026-10-14.md',
    'docs/EXPONENTIAL_SCALAR_THERMAL_BOUNCE_BOUNDED_THEOREM_NOTE_2026-10-14.md']
ck('declared_input_list',declared==expected_inputs)
ck('declared_timeout',ast.literal_eval(assignments['AUDIT_TIMEOUT_SEC'])==120)
for path in expected_inputs[1:]:
    ck('declared_input_frozen::'+path, (ROOT/path).read_bytes()==(SRC/'declared_inputs'/Path(path).name).read_bytes())
main=next(n for n in tree.body if isinstance(n,ast.If) and isinstance(n.test,ast.Compare))
main_text=''.join(runner.splitlines(keepends=True)[main.lineno-1:main.end_lineno])
ck('wrapper_count_computes_from_actual_rows',"'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks)" in main_text)
ck('wrapper_keeps_both_units',"[('clock',check_clock),('observed_normalization',check_observed_normalization)]" in main_text)
ck('wrapper_keeps_outputs',"result=fn();rows=result.pop('checks');outputs[name]=result" in main_text)
ck('wrapper_prefixes_without_filter',"checks.extend([{**row,'name':name+'::'+row['name']} for row in rows])" in main_text)
ck('wrapper_fails_on_any_failed_row',"raise SystemExit(bool(result['failed']))" in main_text)
ck('optional_file_prevents_overwrite',"assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\\n')" in main_text)
text_out('comparisons/inspected_main_wrapper.py.txt',main_text)

staged=js('packaging/STAGED_RESULTS_v1.json')
staged_stdout=js('packaging/STAGED_stdout_v1.txt')
run=js('packaging/STAGED_RUN_v1.json')
command=js('packaging/STAGED_COMMAND_v1.json')
ck('saved_stdout_equals_full_result',staged_stdout==staged)
ck('saved_stderr_empty',read('packaging/STAGED_stderr_v1.txt')=='')
ck('saved_staged_exit_zero',run['exit_code']==0)
ck('saved_execution_source_binding',staged['checker_sha256']==sha(runner.encode())==command['runner_sha256'])
ck('saved_command_paths',Path(command['command'][1]).name==runner_name and command['command'][-2:] == ['--output',str(ROOT/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013/physical_clock_packaging/STAGED_RESULTS_v1.json')])
ck('saved_command_cwd',command['cwd']==str(ROOT))

all_expected=[]
row_inventory=[]
for group,label,count,payload_keys in [('original_clock','clock',57,['candidate_envelopes']),
                                       ('original_observed','observed_normalization',12,['central','reported_uncertainty_rectangle'])]:
    original=js(group+'/RESULTS_v1.json')
    rows=original['checks']
    ck('original_counts::'+label,original['passed']==sum(r['passed'] for r in rows)==count and original['failed']==sum(not r['passed'] for r in rows)==0)
    ck('staged_unit_counts::'+label,staged['units'][label]=={'passed':count,'failed':0})
    expected=[{**row,'name':label+'::'+row['name']} for row in rows]
    selected=[r for r in staged['checks'] if r['name'].startswith(label+'::')]
    ck('all_rows_and_residuals_preserved::'+label,selected==expected)
    ck('substantive_outputs_preserved::'+label,staged['substantive_outputs'][label]=={k:original[k] for k in payload_keys})
    all_expected.extend(expected)
    row_inventory.extend(dict(unit=label,original_name=r['name'],staged_name=label+'::'+r['name'],original_row=r) for r in rows)
    source_name='check_physical_clock_v1.py' if label=='clock' else 'calculate_observed_clock_v1.py'
    field='checker_sha256' if label=='clock' else 'code_sha256'
    ck('original_result_code_binding::'+label,original[field]==sha((SRC/group/source_name).read_bytes()))
ck('all69_exact_and_ordered',staged['checks']==all_expected and len(all_expected)==69)
ck('aggregate69_0_derived',staged['passed']==sum(r['passed'] for r in staged['checks'])==69 and staged['failed']==sum(not r['passed'] for r in staged['checks'])==0)
ck('unique_actual_row_names',len({r['name'] for r in staged['checks']})==69)
ck('observed_saved_input_binding',js('original_observed/RESULTS_v1.json')['input_sha256']==sha((SRC/'original_observed/INPUT_PROTOCOL_v1.json').read_bytes()))
ck('original_observed_stdout_identity',js('original_observed/stdout_v1.txt')==js('original_observed/RESULTS_v1.json'))
clock_output=js('original_clock/RESULTS_v1.json')
ck('original_clock_stdout_summary_identity',js('original_clock/stdout_v1.txt')=={k:v for k,v in clock_output.items() if k!='checks'})

damage_evidence=[]
plans=js('original_clock/DAMAGE_PLAN_v1.json')
summaries=js('original_clock/DAMAGE_SUMMARY_v1.json')
original_script=read('original_clock/check_physical_clock_v1.py')
ck('five_original_actual_damages',len(plans)==len(summaries)==5)
for plan,summary in zip(plans,summaries):
    name=plan['name'];prefix='original_clock/damages/'+name
    script=read(prefix+'.py');result=js(prefix+'_results.json');execution=js(prefix+'_run.json')
    failed=[r['name'] for r in result['checks'] if not r['passed']]
    ck('actual_damage_edit::'+name,original_script.count(plan['original'])==1 and script==original_script.replace(plan['original'],plan['changed'],1))
    ck('actual_damage_source_binding::'+name,sha(script.encode())==plan['sha256']==result['checker_sha256']==execution['script_sha256'])
    ck('actual_damage_failed_witnesses::'+name,failed==summary['failed_checks'] and len(failed)==result['failed']==summary['failed']>0 and execution['exit_code']==1)
    damage_evidence.append(dict(name=name,passed=result['passed'],failed=result['failed'],failed_checks=failed,exit_code=execution['exit_code'],new_execution=False))

# In-memory correspondence perturbations exercise linkage checks, not physics.
damaged_input=dict(literal);damaged_input['c_m_s']=299792459
ck('metadata_damage_reject_changed_input',damaged_input!=input_json)
damaged_rows=all_expected[:-1]
ck('metadata_damage_reject_dropped_actual_row',damaged_rows!=staged['checks'])
damaged_output=json.loads(json.dumps(staged['substantive_outputs']))
damaged_output['observed_normalization']['central']['tau_reference_Gyr']='1'
ck('metadata_damage_reject_changed_substantive_value',damaged_output!=staged['substantive_outputs'])

emit('BODY_CORRESPONDENCE_v1.json',dict(note_sections=body_evidence,runner_bodies=code_evidence,input_semantic_identity=literal==input_json,
     note='Lineage body digests trim the final newline; the original and de-indented staged raw bodies are themselves exactly equal.'))
emit('ROW_INVENTORY_v1.json',dict(row_count=len(row_inventory),rows=row_inventory,substantive_outputs=staged['substantive_outputs']))
emit('HISTORICAL_DAMAGE_BINDING_v1.json',dict(scope='Five actual original author damages reused by identity; no new damage execution.',damages=damage_evidence))
result=dict(scope='New independent static correspondence and saved-log checks; not a science rerun.',passed=sum(x['passed'] for x in checks),
            failed=sum(not x['passed'] for x in checks),checks=checks)
emit('CORRESPONDENCE_RESULTS_v1.json',result)
print(json.dumps(dict(passed=result['passed'],failed=result['failed'],failures=[x for x in checks if not x['passed']]),indent=2))
raise SystemExit(bool(result['failed']))
