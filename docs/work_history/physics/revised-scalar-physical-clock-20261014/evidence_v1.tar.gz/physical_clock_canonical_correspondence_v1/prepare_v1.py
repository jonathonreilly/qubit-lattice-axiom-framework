from pathlib import Path
import datetime as dt
import hashlib
import json

UNIT = Path(__file__).resolve().parent
PACK = UNIT.parent
ROOT = PACK.parents[3]
CLOCK = PACK / 'initial_state/physical_radiation_clock_bound_v1'
OBS = CLOCK / 'observed_normalization_v1'
PKG = PACK / 'physical_clock_packaging'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write_json(path, value):
    assert not path.exists(), path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')

sources = []
def snapshot(path, group, role):
    dest = UNIT / 'sources' / group / path.name
    assert path.is_file() and not path.is_symlink()
    assert not dest.exists(), dest
    dest.parent.mkdir(parents=True, exist_ok=True)
    data = path.read_bytes()
    dest.write_bytes(data)
    sources.append(dict(original_path=str(path.relative_to(ROOT)),
                        snapshot_path=str(dest.relative_to(UNIT)),
                        bytes=len(data), sha256=digest(data), role=role))

for name in ['CANONICAL_LINEAGE_v1.json', 'STAGED_COMMAND_v1.json',
             'STAGED_RESULTS_v1.json', 'STAGED_RUN_v1.json',
             'STAGED_stderr_v1.txt', 'STAGED_stdout_v1.txt']:
    snapshot(PKG / name, 'packaging', 'saved_staging_record_not_new_execution')
for name in ['EXPONENTIAL_SCALAR_PHYSICAL_CLOCK_BOUNDED_THEOREM_NOTE_2026-10-14.md',
             'exponential_scalar_physical_clock_check.py']:
    snapshot(PKG / 'staged' / name, 'staged', 'reviewed_staged_source')
for name in ['DERIVATION_v1.md', 'DERIVATION_v2.md', 'DERIVATION_v1_v2.diff',
             'PROTOCOL_v1.json', 'PROTOCOL_v2.json', 'check_physical_clock_v1.py',
             'COMMAND_v1.json', 'RUN_v1.json', 'RESULTS_v1.json', 'stdout_v1.txt',
             'stderr_v1.txt', 'DAMAGE_PLAN_v1.json', 'DAMAGE_SUMMARY_v1.json']:
    snapshot(CLOCK / name, 'original_clock', 'original_clock_source_or_actual_record')
for path in sorted((CLOCK / 'damages').iterdir()):
    snapshot(path, 'original_clock/damages', 'actual_historical_damage_no_new_run')
for name in ['CALCULATION_v1.md', 'INPUT_PROTOCOL_v1.json', 'SOURCE_ACCESS_v1.json',
             'calculate_observed_clock_v1.py', 'COMMAND_v1.json', 'RUN_v1.json',
             'RESULTS_v1.json', 'stdout_v1.txt', 'stderr_v1.txt']:
    snapshot(OBS / name, 'original_observed', 'original_observed_source_or_actual_record')
for path in sorted((OBS / 'sources').iterdir()):
    snapshot(path, 'original_observed/published_sources', 'reused_published_bytes_not_new_acquisition')
for source_dir, group in [(CLOCK/'independent_v1', 'reused_clock'),
                          (OBS/'independent_v1', 'reused_observed')]:
    for name in ['REPORT_v1.md', 'RECEIPT_v1.json', 'MANIFEST_v1.json',
                 'FINAL_SOURCE_CONFIRMATION_v1.json', 'EVIDENCE_VALIDATION_v1.json']:
        snapshot(source_dir/name, group, 'immutable_independent_provenance')
for name in ['EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md',
             'EXPONENTIAL_SCALAR_PHYSICAL_PAST_BOUNDED_THEOREM_NOTE_2026-10-14.md',
             'EXPONENTIAL_SCALAR_THERMAL_BOUNCE_BOUNDED_THEOREM_NOTE_2026-10-14.md']:
    snapshot(ROOT/'docs'/name, 'declared_inputs', 'declared_dependency_bytes_and_relevant_imports_only')

write_json(UNIT/'SOURCE_BINDINGS_v1.json', dict(
    at=dt.datetime.now(dt.timezone.utc).isoformat(), source_pair_count=len(sources),
    scope='Byte-preserving source freeze for staged correspondence; not a live cache or delivery check.',
    sources=sources))

checks = []
units = []
def ck(name, value, **detail):
    checks.append(dict(name=name, passed=bool(value), **detail))

for folder, label, expected_receipt in [
    (CLOCK/'independent_v1', 'clock', '30bd74f31d8386b32c3567a8f310a47f44ed7f7eb8a65f8a2b3bb7cbcec9ff4c'),
    (OBS/'independent_v1', 'observed', 'a4f7cccaddfc05402d2c06b2f554083b95128d8c8b35167d272ff925c9dd545d')]:
    receipt = json.loads((folder/'RECEIPT_v1.json').read_text())
    manifest = json.loads((folder/'MANIFEST_v1.json').read_text())
    ck(label+'::receipt_identity', digest((folder/'RECEIPT_v1.json').read_bytes()) == expected_receipt)
    for kind in ['manifest', 'report']:
        ref = receipt[kind]
        data = (folder/ref['path']).read_bytes()
        ck(label+'::'+kind+'_receipt_binding', len(data)==ref['bytes'] and digest(data)==ref['sha256'])
    for ref in manifest['artifacts']:
        rel = Path(ref['path'])
        assert not rel.is_absolute() and '..' not in rel.parts
        path = folder/rel
        data = path.read_bytes()
        ck(label+'::artifact::'+str(rel), not path.is_symlink() and len(data)==ref['bytes'] and digest(data)==ref['sha256'])
    ck(label+'::artifact_count', len(manifest['artifacts']) == manifest['artifact_count'] == receipt['artifact_count'])
    allowed = {r['path'] for r in manifest['artifacts']} | {'MANIFEST_v1.json','RECEIPT_v1.json'}
    actual = {str(f.relative_to(folder)) for f in folder.rglob('*') if f.is_file()}
    ck(label+'::exact_inventory', actual==allowed, additional=sorted(actual-allowed), missing=sorted(allowed-actual))
    for ref in receipt['source_pairs']:
        original = Path(ref['original_path'])
        if not original.is_absolute(): original=ROOT/original
        data = original.read_bytes()
        frozen = (folder/ref['snapshot_path']).read_bytes()
        ck(label+'::source_pair::'+ref['snapshot_path'], data==frozen and len(data)==ref['bytes'] and digest(data)==ref['sha256'])
    units.append(dict(label=label, unit=str(folder.relative_to(ROOT)),
                      receipt_sha256=expected_receipt, artifacts=len(manifest['artifacts']),
                      source_pairs=len(receipt['source_pairs']), science_rerun=False))

result=dict(scope='Identity validation of two reused independent seals; no scientific execution.',
            passed=sum(x['passed'] for x in checks), failed=sum(not x['passed'] for x in checks),
            units=units, checks=checks)
write_json(UNIT/'REUSED_SEALS_VALIDATION_v1.json', result)
print(json.dumps(dict(source_pairs=len(sources), passed=result['passed'], failed=result['failed'], units=units),indent=2))
raise SystemExit(bool(result['failed']))
