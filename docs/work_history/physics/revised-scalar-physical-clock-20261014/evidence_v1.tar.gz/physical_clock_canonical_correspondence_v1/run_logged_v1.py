from pathlib import Path
import datetime as dt
import hashlib
import json
import subprocess
import sys

unit=Path(__file__).resolve().parent
name=sys.argv[1]
script=unit/sys.argv[2]
assert script.parent==unit and script.is_file()
record=unit/(name+'_COMMAND_v1.json')
assert not record.exists()
argv=[sys.executable, '-B', str(script), *sys.argv[3:]]
start=dt.datetime.now(dt.timezone.utc).isoformat()
proc=subprocess.run(argv,cwd=unit,capture_output=True,timeout=60)
end=dt.datetime.now(dt.timezone.utc).isoformat()
streams={}
for label,data in [('stdout',proc.stdout),('stderr',proc.stderr)]:
    path=unit/(name+'_'+label+'_v1.txt')
    assert not path.exists()
    path.write_bytes(data)
    streams[label]=dict(path=path.name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
payload=dict(argv=argv,cwd=str(unit),started_at=start,finished_at=end,
             script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),
             exit_code=proc.returncode,streams=streams,
             scope='New independent source/metadata correspondence only; no producer science rerun.')
record.write_text(json.dumps(payload,indent=2)+'\n')
print(proc.stdout.decode(),end='')
if proc.stderr: print(proc.stderr.decode(),file=sys.stderr,end='')
print(json.dumps(dict(record=record.name,exit_code=proc.returncode)))
raise SystemExit(proc.returncode)
