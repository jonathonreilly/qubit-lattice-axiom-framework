from pathlib import Path
import datetime as dt
import hashlib
import json
import sys

UNIT=Path(__file__).resolve().parent
ROOT=UNIT.parent.parents[3]
def digest(data):return hashlib.sha256(data).hexdigest()
def ref(name):
    path=UNIT/name
    data=path.read_bytes()
    return dict(path=name,bytes=len(data),sha256=digest(data))
def write(name,obj):
    path=UNIT/name
    assert not path.exists(),path
    path.write_text(json.dumps(obj,indent=2)+'\n')
def load(name):return json.loads((UNIT/name).read_text())

assert not (UNIT/'MANIFEST_v1.json').exists()
assert not (UNIT/'RECEIPT_v1.json').exists()
rows=[]
def ck(name,value):rows.append(dict(name=name,passed=bool(value)))
bindings=load('SOURCE_BINDINGS_v1.json')
for r in bindings['sources']:
    live=(ROOT/r['original_path']).read_bytes()
    frozen=(UNIT/r['snapshot_path']).read_bytes()
    ck('current_source::'+r['snapshot_path'],live==frozen and digest(live)==r['sha256'] and len(live)==r['bytes'])
for name in ['preparation_COMMAND_v1.json','correspondence_COMMAND_v1.json']:
    rec=load(name)
    ck('exit::'+name,rec['exit_code']==0)
    ck('script::'+name,digest(Path(rec['argv'][2]).read_bytes())==rec['script_sha256'])
    for kind,r in rec['streams'].items():
        data=(UNIT/r['path']).read_bytes()
        ck('stream::'+name+'::'+kind,len(data)==r['bytes'] and digest(data)==r['sha256'])
for name,count in [('REUSED_SEALS_VALIDATION_v1.json',145),('CORRESPONDENCE_RESULTS_v1.json',146)]:
    result=load(name)
    ck('actual_metadata_counts::'+name,result['passed']==sum(r['passed'] for r in result['checks'])==count and result['failed']==sum(not r['passed'] for r in result['checks'])==0)
for label in ['clock','observed']:
    receipt=load('sources/reused_'+label+'/RECEIPT_v1.json')
    live=ROOT/receipt['unit']
    manifest=json.loads((live/'MANIFEST_v1.json').read_text())
    for r in manifest['artifacts']:
        data=(live/r['path']).read_bytes()
        ck('reused_final_identity::'+label+'::'+r['path'],len(data)==r['bytes'] and digest(data)==r['sha256'])
    for r in receipt['source_pairs']:
        original=Path(r['original_path'])
        if not original.is_absolute():original=ROOT/original
        data=original.read_bytes()
        frozen=(live/r['snapshot_path']).read_bytes()
        ck('reused_final_pair::'+label+'::'+r['snapshot_path'],data==frozen and len(data)==r['bytes'] and digest(data)==r['sha256'])
validation=dict(scope='Final metadata identity checks only; no scientific execution.',passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),checks=rows)
write('SEAL_VALIDATION_v1.json',validation)
assert validation['failed']==0

now=dt.datetime.now(dt.timezone.utc).isoformat()
artifacts=[]
for path in sorted(UNIT.rglob('*')):
    if path.is_file():
        assert not path.is_symlink()
        artifacts.append(ref(str(path.relative_to(UNIT))))
manifest=dict(created_utc=now,scope='Immutable staged-correspondence evidence, not delivery or scientific audit.',
              artifact_count=len(artifacts),artifacts=artifacts,excludes=['MANIFEST_v1.json','RECEIPT_v1.json'])
write('MANIFEST_v1.json',manifest)

dispositions=load('ORIGINAL_DISPOSITIONS_v1.json')
receipt=dict(
    created_utc=now,type='focused_staged_canonical_correspondence',checker='/root/scalar_energy_check',
    direct_scientific_author='/root',unit=str(UNIT.relative_to(ROOT)),
    report=ref('REPORT_v1.md'),manifest=ref('MANIFEST_v1.json'),artifact_count=len(artifacts),
    source_pair_count=len(bindings['sources']),source_bindings=ref('SOURCE_BINDINGS_v1.json'),
    source_pairs=bindings['sources'],
    reviewed_staged_note=ref('sources/staged/EXPONENTIAL_SCALAR_PHYSICAL_CLOCK_BOUNDED_THEOREM_NOTE_2026-10-14.md'),
    reviewed_staged_runner=ref('sources/staged/exponential_scalar_physical_clock_check.py'),
    saved_parent_execution=dict(passed=69,failed=0,clock=57,observed_normalization=12,
      results=ref('sources/packaging/STAGED_RESULTS_v1.json'),command=ref('sources/packaging/STAGED_COMMAND_v1.json'),
      run=ref('sources/packaging/STAGED_RUN_v1.json'),stdout=ref('sources/packaging/STAGED_stdout_v1.txt'),
      stderr=ref('sources/packaging/STAGED_stderr_v1.txt'),new_run=False),
    reused_independent_evidence=[dict(unit='clock',original_science='186/0',actual_historical_damages=7,
      verified_artifacts=76,verified_source_pairs=8,report=ref('sources/reused_clock/REPORT_v1.md'),
      receipt=ref('sources/reused_clock/RECEIPT_v1.json'),manifest=ref('sources/reused_clock/MANIFEST_v1.json'),rerun=False),
      dict(unit='observed_normalization',original_science='39/0',actual_historical_damages=1,
      verified_artifacts=45,verified_source_pairs=6,report=ref('sources/reused_observed/REPORT_v1.md'),
      receipt=ref('sources/reused_observed/RECEIPT_v1.json'),manifest=ref('sources/reused_observed/MANIFEST_v1.json'),rerun=False)],
    new_metadata=dict(initial_reused_seals='145/0',static_correspondence='146/0',
      final_seal_identity=f"{validation['passed']}/{validation['failed']}",science=False,
      reused_seals=ref('REUSED_SEALS_VALIDATION_v1.json'),correspondence=ref('CORRESPONDENCE_RESULTS_v1.json'),
      final_validation=ref('SEAL_VALIDATION_v1.json')),
    body_correspondence=ref('BODY_CORRESPONDENCE_v1.json'),actual_row_inventory=ref('ROW_INVENTORY_v1.json'),
    historical_original_damages=ref('HISTORICAL_DAMAGE_BINDING_v1.json'),failure_ledger=ref('FAILURE_LEDGER_v1.json'),
    read_scope=ref('READ_SCOPE_v1.json'),commands=ref('COMMANDS_v1.json'),
    original_dispositions=dispositions['original_dispositions'],all_dispositions=ref('ORIGINAL_DISPOSITIONS_v1.json'),
    seal_command=dict(argv=[sys.executable,'-B',str(Path(__file__).resolve())],cwd=str(UNIT),
      script_sha256=digest(Path(__file__).read_bytes()),scope='Final read-only identity checks and new evidence serialization.'),
    source_corrections_required=[],
    conclusion='The staged note, runner and saved 69/0 execution correspond to the checked clock and observed-normalization sources. Both scientific bodies and all rows/substantive outputs are preserved. No substantive correction is required.',
    limitations=[
      'Staged bytes only; intended docs/scripts paths are not verified delivered paths.',
      'No live runner cache, commit, archive or review-unit identity checked.',
      'No producer science execution, independent mathematics rerun or new empirical acquisition.',
      'Reused science counts and actual historical damages remain separate from new metadata counts.',
      'Flatness, positivity, subcritical uniform coupling, uniform same-bath charge and calibration regimes remain premises.',
      'Published inputs give a conditional reference scale, not a measured age, confidence bound, selected state or empirical action test.',
      'No formal audit verdict, landing authority or broader endorsement of input-note science.'],
    writes_confined_to_unit=True,producer_executed=False,prior_seals_modified=False,
    git_pr_runtime_lock_audit_or_authority_changed=False,immutable_after_seal=True)
write('RECEIPT_v1.json',receipt)

# Read-only verification after the final receipt write.
assert load('MANIFEST_v1.json')==manifest
for r in artifacts:
    data=(UNIT/r['path']).read_bytes()
    assert digest(data)==r['sha256'] and len(data)==r['bytes']
assert {str(p.relative_to(UNIT)) for p in UNIT.rglob('*') if p.is_file()}=={r['path'] for r in artifacts}|{'MANIFEST_v1.json','RECEIPT_v1.json'}
print(json.dumps(dict(artifact_count=len(artifacts),source_pairs=len(bindings['sources']),
      final_validation=f"{validation['passed']}/{validation['failed']}",
      report=ref('REPORT_v1.md'),manifest=ref('MANIFEST_v1.json'),receipt=ref('RECEIPT_v1.json')),indent=2))
