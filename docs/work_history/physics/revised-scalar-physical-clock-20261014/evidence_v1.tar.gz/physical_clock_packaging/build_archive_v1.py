from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,datetime
wt=Path.cwd();pk=wt/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013';pack=pk/'physical_clock_packaging';dest=wt/'docs/work_history/physics/revised-scalar-physical-clock-20261014'
clock='initial_state/physical_radiation_clock_bound_v1'
roots=[clock,'physical_clock_canonical_correspondence_v1','physical_clock_packaging']
seal_units=[clock+'/independent_v1',clock+'/observed_normalization_v1/independent_v1','physical_clock_canonical_correspondence_v1']
assert (pack/'CACHE_RUN_v1.json').is_file(), 'fresh live cache must precede archive'
for rel in seal_units:
 for name in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json']:assert (pk/rel/name).is_file(),(rel,name)
assert not dest.exists();dest.mkdir(parents=True)
items=[]
for root in roots:
 for f in sorted((pk/root).rglob('*')):
  if f.is_dir():continue
  assert f.is_file() and not f.is_symlink(),f
  if '__pycache__' in f.parts or f.suffix=='.pyc' or f.name=='ARCHIVE_BUILD_v1.json':continue
  items.append((f.relative_to(pk).as_posix(),f.read_bytes()))
assert len(set(n for n,b in items))==len(items)
rows=[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in items]
manifest={'schema':'campaign-recovery-manifest-v1','source_roots':roots,'artifact_count':len(rows),'payloads':rows,'scope':'Conditional physical-clock theorem, uniform bath-charge requirement and published CMB/G normalization; original derivations, actual checks, failures and scoped independent evidence. No finite-body or density-environment follow-on.','exclusions':['Python bytecode/cache and later archive-own-hash build record.'],'counts_are_not_new_science':True};mb=(json.dumps(manifest,indent=2)+'\n').encode();archive=dest/'evidence_v1.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for n,b in items+[('RECOVERY_MANIFEST_v1.json',mb)]:
    assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
    t=tarfile.TarInfo(n);t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)+1
 for row in rows:
  t=tar.getmember(row['path']);assert t.isfile();b=tar.extractfile(t).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
sha=hashlib.sha256(archive.read_bytes()).hexdigest();msha=hashlib.sha256(mb).hexdigest();record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive.relative_to(wt)),'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'payloads':len(rows),'total_members':len(members),'manifest_sha256':msha,'all_payloads_verified':True};(pack/'ARCHIVE_BUILD_v1.json').write_text(json.dumps(record,indent=2)+'\n')
refs=[]
for rel in seal_units:
 for name in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json']:
  refs.append(rel+'/'+name+' SHA256 '+hashlib.sha256((pk/rel/name).read_bytes()).hexdigest())
readme="""Recovery evidence for the revised scalar physical-clock milestone

Live claim: docs/EXPONENTIAL_SCALAR_PHYSICAL_CLOCK_BOUNDED_THEOREM_NOTE_2026-10-14.md
Scientific author: /root. Conditional support; no formal audit or main merge.

Archive SHA256: {sha}
Archive bytes: {size}
Payloads: {count} plus RECOVERY_MANIFEST_v1.json
Internal manifest SHA256: {msha}

A joint Friedmann/coupling square controls the derivative of A*a_E^2 in physical
time. Under flatness, nonnegative other energy, a uniform coupling envelope and
a positive past bath-charge floor, it gives a finite past-interval bound without
an independently assumed global conformal-factor cap or vacuum-scale value.
It does not classify a chart endpoint as inextendible or choose a state/history.

A stipulated same-background weak-gravity calibration makes a reference scale
computable from a physical bath density. The published T=2.72548 K aggregate and
CODATA2022 G give tau_ref=1310.846385973 Gyr from blackbody mass density. This is
a weak conditional normalization, not a measured cosmic age or a verified bound
for the real thermal history. The uncertainty rectangle is input sensitivity,
not a confidence interval; statistical G error does not supply response eta.

The canonical runner has69/0 controls:57 conditional clock controls and12
published-input normalization checks. Scientific counts remain separate from
independent proofs, actual altered implementations and identity checks.
The staged correspondence preserves both source bodies, all69 rows/residuals,
all candidate envelopes and all four input corners; live copying/cache binding
is recorded separately. Original source revisions and actual failure/repair
records are preserved without treating reused outputs as fresh executions.

The saved Fixsen PDF and NIST text are exposed calibration/development sources.
Their exact bytes and transcription records are retained. No scalar likelihood,
held-out empirical test, selected action/state, calibrated Hv or nonlinear body
solution is introduced. The finite-mass bath supplies one conditional charge
range only; present photon observations do not prove an arbitrary past floor.

Only safe regular relative archive members should be extracted. Verify all
manifest sizes/hashes. The later archive-own-hash build record is intentionally
outside this archive. Postcommit delivery and exact UNIT/cache checks are separate.

Independent source and staged-correspondence identities:
{refs}
""".format(sha=sha,size=archive.stat().st_size,count=len(rows),msha=msha,refs='\n'.join(refs))
(dest/'README.txt').write_text(readme);print(json.dumps(record))
