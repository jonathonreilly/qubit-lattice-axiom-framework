# Physical turning points and a later near-flat radiation-law event

Direct candidate theorem by /root, extending the separately checked-domain
Einstein-bounce comparison. This closes a possible frame loophole only under
explicit additional interval premises; it is not a measured exclusion of the
scalar theory. The physical radiation diagnostic uses bare Q/C, and the
observational calibration of that coefficient remains open.

Use dimensionful Einstein time t, H=H_E, v=dot(phi), b=d ln A, q=|b|_K^2,
A=sqrt(C)>0, Z=H+b.v, H_J=Z/A and kappa=Kc/a_E^2. The supplied action gives

    3Q(H^2+kappa)=Q|v|_K^2+V+rho_r+rho_m,
    V=2Q H_v^2 U>=3Q H_v^2>0,
    Hdot=kappa-|v|_K^2-[rho_m+p_m+(4/3)rho_r]/(2Q).

Assume all fields/metrics remain regular on a closed finite time interval
[t_b,t_f], Q>0, rho_r>0, rho_m>=0 and rho_m+p_m>=0. The candidate's positive
scalar metric and full action give

    q=a_k/J<a_k<1/3,
    a_k=(1-k)(1+3k)/4,
    J=1+(1-3a_k)s exp(2sqrt(a_k)u)>1.

Radiation is separately conserved throughout: rho_r a_E^4=constant. The
initial event is only a physical stationary point Z_b=0; it need not be an
Einstein bounce or even a strict physical minimum. The later event has Z_f>0
and d_f=kappa_f/Z_f^2<=1. We will derive Kc>0 rather than adopt it separately.

## 1. A physical stationary event requires positive curvature

At Z_b=0, H_b=-b.v_b and H_b^2<=(q_b)|v_b|_K^2. Therefore

    3Q kappa_b
      =Q[|v_b|_K^2-3(b.v_b)^2]+V_b+rho_r,b+rho_m,b
      >=Q(1-3q_b)|v_b|_K^2+V_b+rho_r,b+rho_m,b
      >rho_r,b.                                     (1)

Thus kappa_b>0 and Kc>0, and f_b=rho_r,b/(3Q kappa_b)<1.
This does not require Hdot_J,b>0. Positivity of V makes the final inequality
strict even if v_b=0. The coupling-norm condition and density assumptions are
substantive; they are supplied-action consequences/interval premises, not a
general theorem about arbitrary scalar-tensor theories.

## 2. The later near-flat physical expansion has H_f>0

If H_f<=0, put t=-H_f/Z_f>=0. Since Z_f>0,

    b.v_f=Z_f-H_f=Z_f(1+t).

Cauchy-Schwarz and the positive-energy constraint give

    Z_f^2(1+t)^2 <= q_f |v_f|_K^2
                       < 3q_f(H_f^2+kappa_f).

Consequently

    d_f > (1+t)^2/(3q_f)-t^2
         =1/(3q_f)+2t/(3q_f)+(1/(3q_f)-1)t^2 > 1.     (2)

This contradicts d_f<=1. Hence H_f>0. The proof covers H_f=0 as well;
the intermediate strict inequality uses V+rho_r+rho_m>0. No equality at a
zero field-space norm q is needed; the candidate has q>0 at regular points.

## 3. Chronological split removes the radius ambiguity

If H has no zero in [t_b,t_f], continuity and H_f>0 imply H>0 throughout.
Thus a_E,f>a_E,b (for distinct events). Conservation and curvature scaling give

    f_f := rho_r,f/(3Q kappa_f)=f_b(a_E,b/a_E,f)^2<1.

If H has a zero, let t_* be its last zero before t_f. It exists because the
zero set is closed in the compact interval and H_f>0 gives a zero-free final
neighborhood. On (t_*,t_f] H>0, so a_E,f>a_E,*. Differentiability and positivity
to the right imply Hdot_*>0 or Hdot_*=0. The Raychaudhuri equation and
nonradiation enthalpy>=0 then give

    kappa_* >= 2rho_r,*/(3Q),
    f_* <= 1/2,
    f_f=f_*(a_E,*/a_E,f)^2 < 1/2.                    (3)

A tangential zero, a degenerate crossing or a zero at t_b is allowed. We do
not divide by H or presume a strict Einstein bounce. The interval equations
and nonradiation enthalpy assumption are crucial in this second case.
Both cases yield f_f<1.

## 4. Physical consequence and remaining empirical boundary

At the final event use the actual physical spatial curvature and radiation
density but retain the bare physical Ricci coefficient Q/C:

    d_J=Kc/(a_J^2 H_J^2)=kappa/Z^2,
    F_r,J=H_J^2/[C rho_r,J/(3Q)]=3QZ^2/rho_r.

Their product is 1/f_f, so the necessary conclusion is

    d_J F_r,J > 1.                                  (4)

In the case with an intermediate Einstein zero it is >2. Therefore an earlier
regular physical turning point cannot precede a later physical expanding event
that simultaneously has d_J<=epsilon<=1 and F_r,J<=1+delta with

    epsilon(1+delta)<=1, delta>=0.                    (5)

This is a conditional obstruction to a near-flat GR-like radiation law using
the bare coupling, not a numerical CMB/BBN fit or local measured-gravity result.
Present near-flatness and positive CMB temperature alone do not imply (5),
because radiation does not dominate the present expansion. No observed bound
is silently transferred from LambdaCDM. Physical effective scalar density is
not equated with Einstein scalar energy.

The theorem does not derive a singular origin, choose a state, prove global
completeness, or exclude quantum/inhomogeneous alternatives. Radiation charge
production or exchange, a changed action/coupling norm, or violations of the
positive density/enthalpy premises can evade its domain. Naming such a route
is not deriving an energy-transfer mechanism or a new viable theory.
