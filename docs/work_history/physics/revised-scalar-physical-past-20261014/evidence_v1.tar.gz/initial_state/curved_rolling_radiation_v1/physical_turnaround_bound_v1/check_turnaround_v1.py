from pathlib import Path
import sys,json,hashlib
import sympy as S
out=Path(sys.argv[1]);assert not out.exists();rows=[]
def ck(n,b,d=None):rows.append({'name':n,'passed':bool(b),'detail':d})
def zero(n,e):v=S.factor(S.simplify(e));ck(n,v==0,str(v))
k,E=S.symbols('k E',positive=True);a=(1-k)*(1+3*k)/4;s=(1+k)/(k*(1-3*k));F=1+s*E;J=1+(1-3*a)*s*E
K=J/F**2;b=S.sqrt(a)/F
zero('action_coupling_norm',b*b/K-a/J)
zero('action_strict_norm_domain',1-3*a-(1-3*k)**2/4)
zero('action_J_gap',J-1-(1-3*a)*s*E)
Q,V,rho=S.symbols('Q V rho',positive=True);v2,rm,sigma=S.symbols('v2 rm sigma',nonnegative=True);q=S.symbols('q',positive=True)
# sigma=q|v|²-(b.v)² is a nonnegative Cauchy gap for an actual velocity.
H2=q*v2-sigma;kap=(Q*v2+V+rho+rm)/(3*Q)-H2
zero('stationary_curvature_gap',3*Q*kap-rho-(Q*(1-3*q)*v2+3*Q*sigma+V+rm))
c=S.symbols('c',positive=True);qq=1/(3*(1+c));gap=S.factor((Q*(1-3*q)*v2+3*Q*sigma+V+rm).subs(q,qq));ck('stationary_strict_gap',gap.is_positive,str(gap))
x=S.symbols('x',nonnegative=True)
endpoint_lower=(1+x)**2/(3*qq)-x**2
zero('endpoint_positive_polynomial',endpoint_lower-1-(c+2*(1+c)*x+c*x*x))
ck('endpoint_incompatible_near_flat',S.expand(endpoint_lower-1).is_positive,str(S.expand(endpoint_lower-1)))
# Dimensionful physical transformations and the positive-radiation product.
AA,ZZ,kapf=S.symbols('A Z kapf',positive=True);C=AA**2;HJ2=ZZ**2/C;rhoJ=rho/C**2;dJ=kapf/ZZ**2;Frad=HJ2/(C*rhoJ/(3*Q));zero('physical_product',dJ*Frad-3*Q*kapf/rho)
lam=S.symbols('lambda',positive=True);fb=S.symbols('fb',positive=True);rhob,kapb=S.symbols('rhob kapb',positive=True)
zero('radiation_curvature_transport',(rhob/lam**4)/(3*Q*(kapb/lam**2))-rhob/(3*Q*kapb*lam**2))
eta,ell=S.symbols('eta ell',positive=True);fb_nozero=1/(1+eta);l=1+ell
ck('no_zero_case_product_strict',(l*l/fb_nozero-1).is_positive,str(S.expand(l*l/fb_nozero-1)))
eta0=S.symbols('eta0',nonnegative=True);fb_lastzero=1/(2+eta0)
ck('last_zero_case_product_stronger',(l*l/fb_lastzero-2).is_positive,str(S.expand(l*l/fb_lastzero-2)))
enthalpy,hd=S.symbols('enthalpy hd',nonnegative=True);kap0=hd+(enthalpy+S.Rational(4,3)*rho)/(2*Q)
zero('last_zero_nonnegative_raychaudhuri',3*Q*kap0-2*rho-3*Q*hd-S.Rational(3,2)*enthalpy)
ck('last_zero_nonstrict_gap',(3*Q*hd+S.Rational(3,2)*enthalpy).is_nonnegative)
# Standalone witnesses of lost algebraic premises, not complete cosmologies.
# q=1/2 permits flat stationary data with positive V and radiation.
flat_sub={Q:1,v2:1,V:S.Rational(1,10),rho:S.Rational(2,5),rm:0,q:S.Rational(1,2),sigma:0}
zero('excluded_large_q_flat_witness',kap.subs(flat_sub))
# Positive physical expansion can coincide with Einstein contraction if curvature is large.
v0=S.Rational(3);b0=S.Rational(1,3);H0=-S.Rational(1,2);Z0=H0+b0*v0;kapx=(v0*v0+1+1)/3-H0*H0
ck('large_curvature_counterwitness_E_contraction',H0<0 and Z0>0)
zero('large_curvature_counterwitness_d',kapx/Z0**2-S.Rational(41,3))
ck('large_curvature_counterwitness_outside_endpoint',kapx/Z0**2>1)
# Strict and degenerate final zeros: chronology controls alone, not physical trajectories.
t=S.symbols('t',real=True)
chronology=[('cross',(t-1)**2*(t-2)),('degenerate_cross',(t-1)**2*(t-2)**3),('touch',(t-1)**2*(t-2)**2)]
for name,H in chronology:
 roots=S.solve(H,t);last=max(roots);zero(name+'_last_zero',last-2);ck(name+'_right_derivative_nonnegative',S.diff(H,t).subs(t,last)>=0);ck(name+'_positive_final_H',H.subs(t,3)>0);ck(name+'_positive_final_log_radius',S.integrate(H,(t,last,3))>0)
H=t+S.Rational(1,2);ck('zero_free_chronology',H.subs(t,0)>0 and S.diff(H,t)>0);ck('zero_free_positive_radius',S.integrate(H,(t,0,3))>0)
# The exact closed constant-scalar solution is a physical example within the domain.
for tau in [S.Rational(1,2),S.Rational(1),S.Rational(2)]:
 X=(3+S.sqrt(5)*S.cosh(2*tau))/2;HH=S.sqrt(5)*S.sinh(2*tau)/(2*X);rho0=3/X**2;kapv=3/X;dv=kapv/HH**2;fv=3*HH**2/rho0
 zero('closed_example_product_'+str(tau),dv*fv-3*X)
 ck('closed_example_obstruction_'+str(tau),3*X>2)
# Threshold implication is purely algebraic; no epsilon or delta is an observed tolerance.
eps,delta=S.symbols('eps delta',positive=True)
for ev,dv in [(S.Rational(1,100),S.Rational(1,10)),(S.Rational(1,2),1),(S.Rational(1,4),2)]:ck('illustrative_threshold_'+str((ev,dv)),ev*(1+dv)<=1)
result={'scope':'Direct exact controls for candidate physical-turnaround theorem; general chronology proof is in DERIVATION_v1.md.','passed':sum(r['passed'] for r in rows),'failed':sum(not r['passed'] for r in rows),'checks':rows,'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'limits':['No observed calibration, likelihood or physical singularity theorem.','Polynomial chronological controls are not cosmological solutions.','Large-q and large-curvature points are algebraic domain witnesses, not global history constructions.','No parent grid used or rerun.']};out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':result['passed'],'failed':result['failed']}))
for r in rows:
 if not r['passed']:print('FAILED',r)
raise SystemExit(1 if result['failed'] else 0)
