# A necessary gravity-calibration bridge for a prior physical turning point

Direct derivation by /root. The physical-turnaround result uses the bare
squared-Planck coefficient Q/C. This block connects that diagnostic to the
previously derived leading weak-source gravitational coefficient, and makes
its environment dependence explicit. It does not assert that any laboratory
or primordial-element measurement satisfies the local approximation.

## Supplied action and the local coefficient

Use the full supplied action, Q=Q0(1+k), 0<k<1/3, nu>0 and finite fields.
Write a=(1-k)(1+3k)/4, s=(1+k)/(k(1-3k)), E=exp(2 sqrt(a) u),
F=1+sE, J=1+(1-3a)sE and C=(1+s)E/F. The matter covector is
b=(sqrt(a)/F,0,0) and its field-metric squared norm is q=a/J<1/3.
For a weak nonrelativistic source in a locally frozen background, when the
spatial principal operator dominates mass, mixing and time variation, the
scalar Green function and physical mass/radius conversion give

    G_pr(phi)=C(phi)(1+q(phi))/(8 pi Q).
    G_bare(phi)=C(phi)/(8 pi Q).                       (1)

These are coefficients in the source response, not a fit to a measured
finite-body force or a choice of a screening factor. This normalization
was independently checked in the earlier local and rolling response blocks.

A separately conditional extension includes a constant positive field metric
and a self-adjoint nonnegative mass-squared operator. Whiten the field metric
and diagonalize the operator. With orthonormal eigenvectors e_i and masses
m_i>=0, put w_i=(e_i dot K^(-1/2)b)^2, so sum_i w_i=q. The static point-source
force at Einstein radius r then has coefficient

    G_force(r)=G_bare [1+sum_i w_i (1+m_i r) exp(-m_i r)]. (2)

The physical radius is sqrt(C)r at the frozen background. Since
0<=(1+z)exp(-z)<=1 for z>=0, G_bare<=G_force<=G_pr. This does not certify a
positive operator at every field point, a static global solution around
an arbitrary background, finite-body sensitivities, environmental matching,
or a controlled cosmological remainder. Negative eigenvalues or additional
source/boundary modes are outside (2), not suppressed by declaration.

## Same background: enhancement cannot be chosen arbitrarily

Let the cosmic event have C_c, and set
F_cal=H_J^2/[(8 pi G_cal/3)rho_r,J]. Its relation to the bare diagnostic is

    F_cal=F_bare / gamma, gamma=G_cal/G_bare,c.          (3)

If the calibration has the same local background, equation (1) or the domain
of (2) gives gamma<=1+q<4/3. The physical-turnaround theorem says

    d_J F_bare > m, m=1,

or m=2 in its last-Einstein-zero case; the later event also has Z>0,d_J<=1.
Hence

    d_J F_cal > 3m/4.                                 (4)

A near-flat radiation-law target d_J<=epsilon<=1, F_cal<=1+delta is
incompatible with this class if epsilon(1+delta)<=3m/4. The inequality
is a consequence of the supplied action and matched local background,
not a universal scalar-tensor or empirical exclusion.

To expose approximation error, a separately supplied bound
G_cal<=(1+eta)G_pr, eta>=0, weakens (4) to

    d_J F_cal > 3m/[4(1+eta)].                         (5)

No numerical eta is derived here. The eta=0 equations are exact for the
leading coefficient and the frozen nonnegative-mass model, not exact for
an actual finite-distance experiment unless its errors have been controlled.

## Different backgrounds: an absolute leading ceiling

Let the calibration background be any finite (u_l,x_l,y_l), even at another
epoch, with the same action constants and physical matter units. Define
chi=s(C_l-1) and B=4k^2(1-3k)/(1+k)^2. Exact action algebra yields

    C_l(1+q_l)/(1+k)=1-B chi^2/(1-3k chi)<=1,           (6)
    -s<chi<1, 1-3k chi>0.

The maximum is attained at u_l=0, regardless of x_l,y_l in this principal
coefficient. Thus G_pr,l<=1/(8 pi Q0); increasing an arbitrary calibration
field cannot make this coefficient unbounded. The local experiment's
admissibility and any environment solution remain open.

If G_cal<=(1+eta)G_pr,l, equations (3) and (6) give

    gamma <= (1+eta)(1+k)/C_c,
    d_J F_cal > m C_c/[(1+eta)(1+k)].                  (7)

A target d_J<=epsilon<=1, F_cal<=1+delta therefore necessarily requires

    C_c < Ccrit=(1+eta)(1+k)epsilon(1+delta)/m.         (8)

This is necessary, not sufficient. It neither constructs an environment nor
establishes a history joining its calibration point to the cosmological
point. When Ccrit>=1 it gives no positive small-C energy floor of the type
below. Radiation at the current epoch is not presumed to dominate expansion.

## Energy cost of the remaining distinct-background route

For 0<C<1, invert the actual supplied coupling, without choosing a selector:

    E=C/(1+s-sC), u=log[C/(1+s-sC)]/(2 sqrt(a)).

At fixed u, x=y=0 minimizes U over x,y. The resulting potential is

    U0(C)=3/2+(3/2)s(1-C)^2
          +nu(1+s-sC)^2 log^2[C/(1+s-sC)]/[8a(1+s)]. (9)

It decreases strictly as C grows from zero to one. To check the total
potential, put t=2sqrt(a)u<0. The sign of U_u is the sign of

    12a(exp(t)-1)+nu t(1-t)+nu t/[s exp(t)],

whose three terms are negative for every t<0. Thus no upper bound on nu
is required on this negative-u branch. The map C(u) is increasing.
Consequently, if 0<Ccrit<1, the target in (8) implies

    U(phi_c)>U0(Ccrit),
    rho_phi,E/(2Q H_v^2)>=U(phi_c)>U0(Ccrit).           (10)

For the campaign energy e=|dphi/d(H_v t_E)|_K^2/2+U-3/2,
e>U0(Ccrit)-3/2. Kinetic and transverse potential energy only increase
this floor. As Ccrit tends to zero with k,nu fixed, the last term diverges
like nu(1+s)log^2(Ccrit)/[8a]. This is a conditional necessary energy cost;
a large early-universe scalar density is not automatically inconsistent.
No observational amplitude or measured dimensional age is inferred.

## What was derived and what survives

The scalar enhancement and the global leading calibration ceiling follow
from the supplied action. Conditional on the previous turning-point theorem,
they turn the unknown environment into a necessary inequality and energy
cost rather than an arbitrarily assigned conversion factor. The action,
k,nu,Q0,H_v, radiation/thermal state, local response applicability, bounded
error eta and an actual environment/history solution remain inputs or gaps.

A speed-up parameter is not a primordial abundance likelihood. An actual
comparison needs temperatures, species thresholds, interaction/entropy
history, nuclear rates, measured abundances and their correlations, and
the relevant cosmological curvature inference. No synthetic target values
here count as independent observations. No charge-production mechanism,
initial-state selector, singularity theorem or completed TOE is claimed.
