from pathlib import Path
import sys,json,hashlib,itertools
import sympy as S
out=Path(sys.argv[1]);assert not out.exists();rows=[]
def ck(n,b,d=None):rows.append(dict(name=n,passed=bool(b),detail=d))
def eq(n,x):y=S.factor(S.simplify(x));ck(n,y==0,str(y))
k,E,nu,Q=S.symbols('k E nu Q',positive=True)
a=(1-k)*(1+3*k)/4;s=(1+k)/(k*(1-3*k));F=1+s*E;J=1+(1-3*a)*s*E;C=(1+s)*E/F;q=a/J
chi=S.symbols('chi',real=True);Ec=(1+chi/s)/(1-chi);B=4*k*k*(1-3*k)/(1+k)**2
R=C*(1+q)/(1+k)
eq('global_calibration_ceiling_identity',R.subs(E,Ec)-(1-B*chi*chi/(1-3*k*chi)))
eq('chi_coupling_identity',q.subs(E,Ec)-k*(1-chi)/(1-3*k*chi))
eq('maximum_at_origin',R.subs(E,1)-1)
eq('positive_denominator_split',1-3*k*chi-((1-3*k)+3*k*(1-chi)))
eq('finite_field_coupling_norm_gap',1-3*a-(1-3*k)**2/4)
eq('coupling_monotone',S.diff(C,E)-(1+s)/(1+s*E)**2)
# Independent Euler normalization of a constant-metric quadratic gradient.
f1,f2,f3,b1,b2,b3=S.symbols('f1 f2 f3 b1 b2 b3',real=True)
K=S.diag(4,9,16);grad=S.Matrix([f1,f2,f3]);bb=S.Matrix([b1,b2,b3]);L=-Q*(grad.T*K*grad)[0]
for i in range(3):eq('gradient_Euler_coefficient_'+str(i),S.diff(L,grad[i])+2*Q*(K*grad)[i])
Gstar=1/(8*S.pi*Q);eq('scalar_Poisson_normalization',4*S.pi*Gstar-1/(2*Q))
# Stable frozen mass operator: orthogonal eigenbasis with positive spectral weights.
O=S.Matrix([[S.Rational(3,5),-S.Rational(4,5),0],[S.Rational(4,5),S.Rational(3,5),0],[0,0,1]])
eq('eigenbasis_orthogonality',sum((O.T*O-S.eye(3))[i,j]**2 for i in range(3) for j in range(3)))
bvec=S.Matrix([S.Rational(1,3),S.Rational(1,5),S.Rational(1,7)]);white=S.diag(S.Rational(1,2),S.Rational(1,3),S.Rational(1,4))*bvec
w=[(O[:,i].dot(white))**2 for i in range(3)];eq('spectral_weight_sum',sum(w)-(bvec.T*K.inv()*bvec)[0]);ck('weights_nonnegative',all(x>=0 for x in w))
r,m=S.symbols('r m',positive=True)
force=(1+m*r)*S.exp(-m*r)
eq('force_from_Green_potential',-r*r*S.diff(S.exp(-m*r)/r,r)-force)
eq('force_kernel_derivative',S.diff(force,r)+m*m*r*S.exp(-m*r))
eq('force_massless_limit',S.limit(force,m,0)-1)
eq('force_infinite_range_limit',S.limit(force,r,S.oo))
for radius in [S.Rational(1,10),S.Rational(1),S.Rational(10)]:
 correction=sum(ww*(1+mm*radius)*S.exp(-mm*radius) for ww,mm in zip(w,[0,1,3]));ck('spectral_force_ceiling_'+str(radius),0<=float(correction)<=float(sum(w)))
# Calibration inversion and conditional event threshold: all denominators positive.
Gc,Gb,H2,rho,gamma=S.symbols('Gcal Gbare H2 rho gamma',positive=True)
Fcal=H2/(8*S.pi*Gb*rho/3);Fbare=H2/(8*S.pi*Gb*rho/3)
eq('calibration_divides_radiation_diagnostic',(Fcal/Fbare).subs(Gc,gamma*Gb)-1/gamma)
et,eps,de,mm,cc=S.symbols('eta epsilon delta m cc',positive=True)
upper=(1+et)*(1+k)/cc;crit=(1+et)*(1+k)*eps*(1+de)/mm
eq('necessary_coupling_threshold',((mm/upper)-eps*(1+de)).subs(cc,crit))
# An upper ceiling alone admits an invalid negative calibration; positivity must be separate.
ck('negative_calibration_does_not_define_positive_diagnostic',Fcal.subs({Gc:-1,H2:1,rho:1})<0)
# Reconstruct the actual potential at fixed C, then check its total derivative sign form.
c,aa,ss,t=S.symbols('c aa ss t',positive=True);D=1+ss-ss*c;Einv=c/D;u=S.log(Einv)/(2*S.sqrt(aa));Finv=1+ss*Einv
U_original=S.Rational(3,2)+S.Rational(3,2)*ss*(Einv-1)**2/Finv**2+nu*(1+ss)*u*u/(2*Finv**2)
Ufloor=S.Rational(3,2)+S.Rational(3,2)*ss*(1-c)**2+nu*D**2*S.log(c/D)**2/(8*aa*(1+ss))
eq('potential_coupling_inverse',((1+ss)*Einv/(1+ss*Einv))-c)
eq('potential_energy_floor_identity',U_original-Ufloor)
FF=1+ss*S.exp(t);Ut=S.Rational(3,2)+S.Rational(3,2)*ss*(S.exp(t)-1)**2/FF**2+nu*(1+ss)*t*t/(8*aa*FF**2)
G=12*aa*(S.exp(t)-1)+nu*t*(1-t)+nu*t/(ss*S.exp(t));pref=ss*S.exp(t)*(1+ss)/(4*aa*FF**3)
eq('total_potential_derivative_sign_factor',S.diff(Ut,t)-pref*G)
z=S.symbols('z',positive=True)
for i,term in enumerate([12*aa*(S.exp(t)-1),nu*t*(1-t),nu*t/(ss*S.exp(t))]):
 # At i=0 use f(0)=0 and f'(z)>0 for f=1-exp(-z); symbolic assumptions alone returned None.
 positive_gap=1-S.exp(-z)
 calculus=(positive_gap.subs(z,0)==0 and S.simplify(S.diff(positive_gap,z)-S.exp(-z))==0 and S.exp(-z).is_positive is True)
 sign_ok=calculus if i==0 else term.subs(t,-z).is_negative is True
 ck('negative_u_derivative_term_'+str(i),sign_ok,str(term.subs(t,-z)))
eq('zero_coupling_log_squared_floor',S.limit(Ufloor/S.log(c)**2,c,0,dir='+')-nu*(1+ss)/(8*aa))
# Exposed synthetic targets, not fitted values or histories.
examples=[]
for kval,nval,ep,mval in itertools.product([S.Rational(1,20),S.Rational(1,10),S.Rational(1,4)],[S.Rational(1,10),S.Rational(1),S.Rational(10)],[S.Rational(1,100),S.Rational(1,10)],[1,2]):
 av=a.subs(k,kval);sv=s.subs(k,kval);cv=(1+kval)*ep*S.Rational(11,10)/mval
 val=Ufloor.subs({c:cv,aa:av,ss:sv,nu:nval});val_half=Ufloor.subs({c:cv/2,aa:av,ss:sv,nu:nval});v=float(val.evalf(30));vh=float(val_half.evalf(30));ck('synthetic_floor_'+str((kval,nval,ep,mval)),0<cv<1 and vh>v>1.5)
 examples.append(dict(k=str(kval),nu=str(nval),epsilon=str(ep),delta='1/10',eta=0,m=mval,Ccrit=str(cv),U_floor=v,U_at_half_Ccrit=vh))
rout=dict(passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,synthetic_examples=examples,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),scope='Exact action/readout and energy-floor controls plus exposed synthetic targets; no observational fit, thermal history, environment solution or empirical exclusion.')
out.write_text(json.dumps(rout,indent=2)+'\n');print(json.dumps({x:rout[x] for x in ['passed','failed']}));
for x in rows:
 if not x['passed']:print('FAILED',x)
raise SystemExit(1 if rout['failed'] else 0)
