# Independent handwritten derivation, frozen before control code

Author of this check: /root/scalar_energy_check. Parent /root remains scientific author. This file was written before any executable mathematical control. No producer checker, results, grids or prior independent code was read or imported.

## Action normalization and physical force

Write A=sqrt(C), b_A=partial_A log A. Vary the supplied action with signature (-+++):

2 Q K_AB (Box phi^B + Gamma^B_CD partial phi^C partial phi^D) - 2 Q Hv^2 U_A + b_A T_E = 0.

Thus the scalar equation is Box phi^A+Gamma...=Hv^2 grad^A U - b^A T_E/(2Q). For a weak prescribed nonrelativistic source T_E=-rho_E, with constant background and the stated dominant spatial principal operator, Delta delta phi^A=b^A rho_E/(2Q). Since Delta(1/r)=-4 pi delta_3, a point mass produces delta phi^A=-b^A M_E/(8 pi Q r_E). The Einstein lapse potential in the negative-potential convention is Psi_E=-M_E/(8 pi Q r_E); multiplication by A^2 gives Psi_J=Psi_E+delta log A=-(1+q)M_E/(8 pi Q r_E), q=b_A K^{AB}b_B. The scalar sign is attractive here, not a sign chosen to match an observation.

At frozen A, the point-particle action -M_J integral ds_J=-A M_J integral ds_E gives M_E=A M_J. A physical ruler gives r_J=A r_E. Hence M_E/r_E=C M_J/r_J, and G_pr=C(1+q)/(8 pi Q), G_bare=C/(8 pi Q). These relations assume the prescribed point-source rest mass and the same physical matter units; finite-body charge/sensitivity is not derived. Trace-free sources do not have this scalar forcing.

Directly, b=(sqrt(a)/F,0,0), K_uu=J/F^2, hence q=a/J. The identities 1-3a=(1-3k)^2/4>0 and E,s>0 give J>1 and 0<q<a<1/3 for every finite field and 0<k<1/3. The principal norm is independent of transverse x,y even when the full background is not a vacuum.

## Positive spectral weights and the force, not just the potential

Whiten a constant positive metric by psi=K^(1/2) delta phi and beta=K^(-1/2)b. A K-self-adjoint nonnegative squared-mass operator becomes a symmetric nonnegative matrix in these variables. Choose a real orthonormal eigenbasis e_i and m_i>=0. The forced solution decaying to the stipulated background is

psi=-M_E/(8 pi Q r_E) sum_i e_i (e_i dot beta) exp(-m_i r_E).

Contracting with beta gives weights w_i=(e_i dot beta)^2>=0; completeness gives sum w_i=beta^T beta=q. Differentiating exp(-m r)/r gives -(1+m r)exp(-m r)/r^2. Therefore the physical force coefficient is G_bare[1+sum w_i f(m_i r_E)], f(z)=(1+z)e^(-z). Here r_J=A r_E and the physical inverse range is m_i/A. Since f(0)=1, f'=-z e^(-z)<=0 and lim f=0, 0<=f<=1 on z>=0. This proves G_bare<=G_force<=G_pr. It says nothing about negative eigenvalues, free homogeneous/boundary modes, background gradients, mixing not included in the operator, or nonlinear source response.

## Same-background and absolute ceilings

For cosmic bare coefficient G_bare,c=C_c/(8 pi Q), let gamma=G_cal/G_bare,c. The diagnostic identity F_cal=F_bare/gamma is purely algebraic but its inequality uses gamma>0. Under the accepted turning-point premises, d_J>0, F_bare>0 and d_J F_bare>m, with m=1, or m=2 in the last-Einstein-zero case. For same-background leading or positive-mass calibration, 0<gamma<=1+q<4/3. Dividing yields d_J F_cal>3m/4. With an explicitly positive G_cal obeying G_cal<=(1+eta)G_pr, eta>=0, the corresponding bound is >3m/[4(1+eta)]. A finite-distance error ceiling is an additional premise, not derived here.

For arbitrary finite calibration u_l, start from E rather than assume a chi formula. C=(1+s)E/(1+sE), so chi=s(C-1)=s(E-1)/(1+sE), -s<chi<1. Its inverse is E=(1+chi/s)/(1-chi). Substitution into q=a/J yields q=k(1-chi)/(1-3k chi). Also 1-3k chi>1-3k>0. Now C=1+chi/s and direct common-denominator reduction gives

C(1+q)/(1+k)=1-[4 k^2(1-3k)/(1+k)^2] chi^2/(1-3k chi).

The left-hand side is positive and the subtracted term nonnegative. Equality holds exactly at chi=0, equivalently E=1 and u=0; x,y are immaterial for this principal coefficient. Thus G_pr,l<=G0=1/(8 pi Q0), without a choice of calibration field. This does not ensure that an arbitrary point admits a controlled local experiment.

The positive calibration upper bound gives gamma<=(1+eta)(1+k)/C_c. Therefore

d_J F_cal>m C_c/[(1+eta)(1+k)].

If also 0<epsilon<=1, delta>=0, d_J<=epsilon and F_cal<=1+delta, positivity allows multiplication: d_J F_cal<=epsilon(1+delta). Combining strict lower with upper yields C_c<Ccrit=(1+eta)(1+k)epsilon(1+delta)/m. The direction is strict less-than. This is only a necessary condition; no constructed environment/history follows.

## Negative-u energy floor

For 0<C<1 define L=1+s-sC>0. E=C/L and u=log(C/L)/(2sqrt(a)); F=(1+s)/L. Transverse terms in the supplied U are nonnegative for finite u, k>0. Thus x=y=0 minimizes U at fixed u and

U0(C)=3/2+(3/2)s(1-C)^2+nu L^2 log^2(C/L)/[8a(1+s)].

The relation dC/du=2sqrt(a)(1+s)E/F^2>0 preserves order. On x=y=0 set t=2sqrt(a)u. Direct differentiation gives

dU0/dt = (1+s)s exp(t)/(4a F^3) * [12a(exp(t)-1)+nu t(1-t)+nu t/(s exp(t))].

For t<0 and nu>0 all three bracket terms are strictly negative; the factor is positive. Therefore U0 strictly decreases with C throughout 0<C<1, without an upper bound on nu. The full transverse terms add nonnegative energy and also have negative u derivatives, but the sign-factor identity is the line x=y=0 calculation.

If 0<Ccrit<1 and C_c<Ccrit, then U(phi_c)>=U0(C_c)>U0(Ccrit). The action gives rho_phi,E=Q |dphi/dt_E|_K^2+2 Q Hv^2 U. Thus rho_phi,E/(2QHv^2)=|dphi/d(Hv t_E)|_K^2/2+U, and e>U0(Ccrit)-3/2. This is an Einstein-frame scalar energy statement, not a physical inferred density.

As C approaches zero at fixed k,nu, L->1+s and log(C/L)/log C->1, so the diverging term is asymptotic to nu(1+s)log^2 C/(8a). If Ccrit>=1 this negative-u ordering does not give a positive excess floor: the vacuum C=1 is then available (strictly available when Ccrit>1). No positive-u monotonicity for arbitrary nu follows.

## Initial finding and adversarial domains

V1 leaves G_cal>0 implicit in the separately supplied upper-error bound. That upper bound alone permits negative G_cal; then F_cal is negative, a positive upper target can hold, and neither division nor the necessary Ccrit conclusion is valid. At abstract d=1/10, F_bare=20, gamma=-1, m=1, eta=0 and C_c=1, the turning-point product is 2>1 while F_cal=-20 satisfies the target epsilon=1/10, delta=0, contradicting the unqualified positive lower bound and C_c<Ccrit. This is an omitted applicability premise, not a counterexample to the positive-response formulas. Parent has preserved v1 and supplied v2 explicitly adopting G_cal>0, gamma>0, 0<epsilon<=1, delta>=0, eta>=0. The correction will be bound separately.

For a negative squared mass, a real Helmholtz response cos(mu r)/r can instead give cos z+z sin z>1 near z>0, defeating the positive-spectrum force cap. Homogeneous waves or boundary modes also evade the prescribed forced solution. These are excluded domains, not defects in the conditional cap. For Ccrit>1, applying U0(Ccrit) as a positive excess floor can falsely exclude the vacuum. For t>0 at large nu the derivative bracket can become negative; restricting the monotonicity argument to t<0 is essential.

No empirical calibration, abundance likelihood, measured gravity completion, selection principle, singularity/global-extension theorem or whole-history existence is checked. The physical-turnaround theorem is reused solely under the exact regular finite-interval, conserved positive radiation, positive density/enthalpy and later Z>0,d<=1 assumptions stated in its source.
