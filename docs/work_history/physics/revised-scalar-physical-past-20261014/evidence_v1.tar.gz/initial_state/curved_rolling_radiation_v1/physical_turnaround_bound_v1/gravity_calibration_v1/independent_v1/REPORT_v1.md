# Focused independent gravity-calibration check

Scientific author: /root. Independent checker: /root/scalar_energy_check.
This is a source-bound mathematical check, not a formal audit, source authorship transfer, landing decision, or empirical acceptance.

## Conclusion and correction

Equations (1)–(10) are supported under the final v2 stated domains and the explicitly reused physical-turnaround assumptions. The action fixes the force normalization and spectral sum; the arbitrary finite-background principal coefficient has maximum G0=1/(8 pi Q0); the necessary threshold has the strict direction C_c<Ccrit; and the negative-u potential gives the stated Einstein scalar energy floor for 0<Ccrit<1. No additional material source correction was found.

V1 omitted an explicit positive-calibration premise from its general externally supplied upper-error-ceiling route. Equations (1) and (2) already produce positive coefficients in their own domains. An inequality G_cal<=(1+eta)G_pr by itself does not: zero or negative G_cal invalidates division or reverses the order. The exact witness d=1/10, F_bare=20, gamma=-1, m=1, C_c=1, k=2/11, eta=0, epsilon=1/10, delta=0 has d F_bare=2>1 and F_cal=-20<=1, but C_c=1 exceeds Ccrit=13/110. This is a witness to a missing algebraic applicability condition, not a proposed physical negative-gravity experiment or an action-history construction.

V2 adds G_cal>0, gamma>0, 0<epsilon<=1, delta>=0, eta>=0 in one paragraph before equation (3). I read v2 fully and verified byte-for-byte that this is the only change, that every indented equation is unchanged, and that the supplied diff and correction hashes match. Positivity is explicitly adopted for the general error-ceiling route; it was not newly derived from that ceiling. V1 and the finding remain preserved.

## Independent derivation and exact checked scope

The complete supplied action is frozen in source 07. The handwritten derivation was saved before mathematical control code, with SHA d9a40c46df5b2831437e962060d4dc4d3e3ef77cee69aa5a1cf289c13770dd1f. No parent checker, results, grids or prior independent code was accessed.

Varying the action gives 2Q K_AB times the covariant scalar wave operator, minus 2Q Hv² U_A, plus b_A T_E. In the frozen weak dust principal limit, Delta delta_phi^A=b^A rho_E/(2Q). The distributional identity Delta(1/r)=-4 pi delta_3 therefore fixes the point-source scalar amplitude to -b^A M_E/(8 pi Q r_E). The physical lapse adds b.delta_phi to the Einstein potential. The point-particle action gives M_E=A M_J, and a physical ruler gives r_J=A r_E. Thus M_E/r_E=C M_J/r_J, giving C(1+q)/(8 pi Q), rather than a freely adjustable scalar factor. The same variation makes the scalar trace forcing vanish for a trace-free source.

The actual metric gives q=(sqrt(a)/F)^2/(J/F²)=a/J. Since 1-3a=(1-3k)²/4>0 and 1/3-a=(1-3k)²/12>0, finite E>0 implies 0<q<a<1/3. Neither transverse field enters this principal norm. This is not a stability proof for the full background.

For the separately conditional massive model, whiten the constant positive field metric. Self-adjointness and nonnegativity must hold in that positive inner product, so the whitened squared-mass matrix is symmetric nonnegative. With beta=K^(-1/2)b and a complete real orthonormal eigenbasis, w_i=(e_i.beta)²>=0 and sum w_i=beta²=q. Differentiation of the Yukawa potential, not just its amplitude, yields f(z)=(1+z)exp(-z). Its derivative is -z exp(-z); hence 0<=f<=1 for z>=0. The physical radius is A r_E and the physical inverse range is m_i/A. This gives G_bare<=G_force<=G_pr for the prescribed forced point-source solution.

With positive gamma, the diagnostic ratio is exactly F_cal=F_bare/gamma. The preceding source supplies the strict product d_J F_bare>m under its interval hypotheses. At the same background gamma<4/3, or gamma<4(1+eta)/3 under the positive bounded-error route. The strict product gives equations (4)–(5). The explicit margin at the maximal gamma is

    (m+Delta)/[(1+eta)(1+q)] - 3m/[4(1+eta)]
      = [m(1-3q)+4Delta]/[4(1+eta)(1+q)] > 0,

for Delta>0 and 0<q<1/3.

For the distinct-background comparison I began with the original E functions and derived chi=s(E-1)/(1+sE), its inverse, and q=k(1-chi)/(1-3k chi). The domain is -s<chi<1 and 1-3k chi>0. Direct substitution gives

    G_pr/G0=C(1+q)/(1+k)
      =1-[4k²(1-3k)/(1+k)²] chi²/(1-3k chi).

The left side is positive; the subtracted term is nonnegative and vanishes exactly at u=0. This proves the exact global ceiling for this leading coefficient at every finite background, independent of x,y. It does not prove that a local experiment is admissible at every such background.

Dividing the positive calibration ceiling by the cosmic bare coefficient yields gamma<=(1+eta)(1+k)/C_c. Combining the strict product with d_J F_cal<=epsilon(1+delta) gives C_c<Ccrit, where Ccrit=(1+eta)(1+k)epsilon(1+delta)/m. The strict direction and the m=1 versus m=2 factor were checked symbolically and at exact rational boundaries. Satisfying this inequality is not sufficient to supply a physical trajectory or environment.

At fixed u the transverse potential terms are nonnegative, so x=y=0 minimizes U. With L=1+s-sC, the exact inverse E=C/L and F=(1+s)/L give equation (9), including its coefficient nu L²/[8a(1+s)]. Differentiating the original potential in t=2sqrt(a)u, before converting to C, gives the positive prefactor (1+s)s exp(t)/(4a F³) times

    12a(exp(t)-1)+nu t(1-t)+nu t/[s exp(t)].

Every term is negative for t<0 and nu>0; dC/du>0. No upper bound on nu is needed on this branch. The prefactor identity is the x=y=0 line calculation; the remaining transverse energies are nonnegative and cannot weaken the floor. For 0<C_c<Ccrit<1, U(phi_c)>=U0(C_c)>U0(Ccrit). The action stress tensor gives rho_phi,E/(2QHv²)=|dphi/d(Hv t_E)|_K²/2+U, so the strict e floor follows with the stated normalization. The asymptotic ratio of the log term to nu(1+s)log²(C)/(8a) tends to one at fixed k,nu.

## Actual executions and adversarial evidence

The independent baseline executed once: **75 passed, 0 failed**, exit 0. A separate narrow correspondence/exact-domain supplement executed once: **12 passed, 0 failed**, exit 0. These are distinct saved executions, not a relabeled parent run or a repaired baseline. Both have complete commands, scripts, stdout, stderr and JSON results. Python 3.12.8 and SymPy 1.14.0 were used. No unexpected runtime failure or verifier repair occurred.

Finite rational controls use k=1/11, 2/11, 3/13 with E=1/25, 2/7, 1, 9/4, 17, derived directly from the original E expressions. The spectral control uses K=diag(4,9,25), b=(2/5,3/7,1/2), a 3-4-5 rational eigenbasis rotation and masses (0,2,4). No producer grid or outputs selected these points. Two numerical potential diagnostics use k=2/11, nu=5/7 or 100, and C=1/10 versus 39/220. Their sign observations accompany the general analytic derivative proof; decimal values are not claimed as interval certificates.

Eight actual single-expression damaged copies of my implementation were executed. Every one exited 1 with the intended mathematical witness; the scripts, exact diffs, full results and commands remain under mutations/. These establish that the independent controls discriminate the listed errors, not exhaustive test completeness.

| Actual damage | Passed/failed assertions | Intended witness |
|---|---:|---|
| double_scalar_force | 63/12 | `action.principal_force_binding` |
| drop_force_derivative_term | 73/2 | `spectrum.actual_force_derivative` |
| reverse_ceiling_square | 74/1 | `ceiling.exact_action_binding` |
| invert_mcase_dependence | 71/4 | `calibration.critical_C_binding` |
| double_log_energy | 74/1 | `potential.C_expression_from_action` |
| wrong_negative_branch_derivative | 72/3 | `potential.actual_negative_branch_derivative` |
| double_normalized_kinetic | 73/2 | `energy.action_stress_normalization` |
| drop_calibration_positivity | 73/2 | `calibration.rejects_negative_Gcal` |

The additional domain witnesses matter to the scope:

- If a squared mass is negative, a real static Helmholtz response cos(mu r)/r can give force factor cos z+z sin z>1. At z=1/4, alternating Taylor bounds give an exact lower bound 1583/1536>1. Such a spectrum is excluded by equation (2), not screened by it. Extra source/boundary or homogeneous modes also are not covered.
- At k=2/11 and Ccrit=148/143>1, the vacuum C=1 satisfies C<Ccrit yet has U=3/2. The quadratic part alone makes U0(Ccrit)-3/2>=15/572>0. Thus extending the small-C floor above one would be false; the source correctly does not do so.
- At k=2/11, nu=100, t=2, the derivative bracket is negative. The exact exp(2) bounds 109/15<exp(2)<1663/225 imply 7<exp(2)<8 and an upper bound -1887817/11011<0 for that bracket. Negative-u monotonicity must not be silently extended to all positive u at arbitrary nu.
- Dropping G_cal positivity in an actual altered domain predicate admitted both zero and negative calibration coefficients and failed its intended checks. The original source-gap witness is retained separately from that damaged-code execution.

## Reused assumptions and physical limitations

I read the preceding physical-turnaround source only to identify the exact theorem premises. Its proof and trajectories were not rerun or newly certified. The imported implication requires a regular closed finite interval; positive Q and positive scalar metric; positive separately conserved Einstein radiation rho_r a_E^4; nonnegative additional density and nonnegative enthalpy; the supplied positive potential; an earlier physical stationary event Z_b=0; and a later Z_f>0,d_f<=1. It supplies positive curvature and the strict product with m=1, or m=2 for its last-Einstein-zero case. Any failure of those hypotheses removes this calibration implication's theorem input. It is not a blanket statement about all past histories.

Equation (1) remains a leading weak, nonrelativistic, locally frozen spatial-principal response. Background variation, masses, mixing, source support and boundary conditions must be controlled. Equation (2) separately assumes the constant positive metric and nonnegative self-adjoint mass operator with the stated forced solution. Neither formula establishes a global static solution, positive mass operator at arbitrary fields, finite-body charge, environmental matching, or a controlled cosmological remainder. The same physical matter units and action constants are essential when comparing different calibration points. Eta is externally supplied and is not numerically bounded here.

The leading ceiling is exact algebra within that approximation. It is not an exact cap on every finite-distance measured force. The energy floor is Einstein-frame scalar energy, not a physical inferred matter density or an observational exclusion. Large early scalar energy is not ruled out by this result. The inequality neither chooses a state nor supplies an environment/history connecting the two events. No thermal/nuclear inputs, abundance likelihood, measured dimensional scale, empirical calibration, initial-state selector, global-completeness result, singularity theorem or completed gravity model is established.

## Sources, recovery and final files

Seven immutable source snapshots are in sources/. Full original paths are in SOURCE_MANIFEST_v1.json. The final source is DERIVATION_v2.md, SHA 22f51459c09d50b17fa38967595cbf3c8d7608e6020c4720f9251648faa42bb8; v1 is preserved with its original hash. No parent source or previous seal was changed.

| Snapshot | SHA-256 |
|---|---|
| sources/01_DERIVATION_v1.md | `18d9a7c8f98ed3fbe4f7d730f8fc90e9b8a47a425c4517c1ce1e757e1b8a4a07` |
| sources/02_DERIVATION_v2.md | `22f51459c09d50b17fa38967595cbf3c8d7608e6020c4720f9251648faa42bb8` |
| sources/03_PROTOCOL_v1.json | `5bf15ce344d834358691d662b6405323f8c1fffa2b23d54101816c347ad66e83` |
| sources/04_CALIBRATION_DOMAIN_v2.json | `35ef23cf8495ef0301aba6bb5da7076cc4790298b84c1d5086c8cdcaf6cb9b09` |
| sources/05_CALIBRATION_DOMAIN_v2.diff | `495f871efcdc4591fc076048d1ecdfbb5f2f088219fda04febf45397ff0f41c9` |
| sources/06_DERIVATION_v1.md | `4fbff5f606381a003802eebf8ee723c80627dc8977a567f177820bc5f3b216ad` |
| sources/07_EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md | `b4080f1e5c63109f66a4a8b15c2e4888c5331384654ddcbca5c9c0eb97a3cd68` |

The final files are REPORT_v1.md, MANIFEST_v1.json and RECEIPT_v1.json. The manifest binds every artifact except itself and the receipt; the receipt binds the manifest, report, sources, command/result evidence, original finding and correction correspondence. Original source v1 and every actual execution are preserved. Writes were confined to this new independent_v1 directory. No producer code/results, empirical data, prior independent code, Git/PR mutation, runtime/lock state or formal audit authority was used or changed.
