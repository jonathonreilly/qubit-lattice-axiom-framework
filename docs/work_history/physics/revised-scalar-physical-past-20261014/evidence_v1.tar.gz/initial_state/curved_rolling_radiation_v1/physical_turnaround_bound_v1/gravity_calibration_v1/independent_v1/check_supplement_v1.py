#!/usr/bin/env python3
from pathlib import Path
import argparse,difflib,hashlib,json,sys
import sympy as S
p=Path(__file__).resolve().parent
R=S.Rational
checks=[]
def ck(name,ok,evidence):
 checks.append({'name':name,'passed':bool(ok),'evidence':evidence});print(('PASS ' if ok else 'FAIL ')+name)
def eq(name,left,right):
 res=S.factor(S.together(left-right));ck(name,res==0,{'left':str(left),'right':str(right),'residual':str(res)})
meta=json.loads((p/'SOURCE_MANIFEST_v1.json').read_text());w=Path(meta['worktree'])
bindings=[]
for row in meta['sources']:
 live=(w/row['original_path']).read_bytes();snap=(p/row['snapshot_path']).read_bytes()
 bindings.append(live==snap and len(live)==row['bytes'] and hashlib.sha256(live).hexdigest()==row['sha256'])
ck('sources.all_seven_live_snapshot_pairs',all(bindings),{'pairs':len(bindings),'matches':bindings})
v1=(p/'sources/01_DERIVATION_v1.md').read_text();v2=(p/'sources/02_DERIVATION_v2.md').read_text()
old='Let the cosmic event have C_c, and set\n'
new='Let the cosmic event have C_c. Throughout this comparison require G_cal>0\nand hence gamma>0; use target/error parameters 0<epsilon<=1, delta>=0 and\neta>=0. Positivity follows from (1) and (2) in their stated domains, but\nmust be added explicitly when only a calibration error ceiling is supplied.\nSet\n'
ck('correspondence.only_explicit_domain_paragraph',v1.count(old)==1 and v1.replace(old,new)==v2,{'old':old,'new':new})
ck('correspondence.all_indented_equations_unchanged',[l for l in v1.splitlines() if l.startswith('    ')]==[l for l in v2.splitlines() if l.startswith('    ')],{'equation_lines_v1':sum(l.startswith('    ') for l in v1.splitlines())})
computed=''.join(difflib.unified_diff(v1.splitlines(True),v2.splitlines(True),fromfile='DERIVATION_v1.md',tofile='DERIVATION_v2.md'))
supplied=(p/'sources/05_CALIBRATION_DOMAIN_v2.diff').read_text()
ck('correspondence.exact_supplied_diff',computed==supplied,{'computed_sha256':hashlib.sha256(computed.encode()).hexdigest(),'supplied_sha256':hashlib.sha256(supplied.encode()).hexdigest()})
correction=json.loads((p/'sources/04_CALIBRATION_DOMAIN_v2.json').read_text())
ck('correspondence.correction_record_hashes',correction['original_sha256']==hashlib.sha256(v1.encode()).hexdigest() and correction['new_sha256']==hashlib.sha256(v2.encode()).hexdigest(),correction)
# Exact sign margin for the strict cap, independent of a numerical q sample.
q,eta,m,Delta,k,Cc=S.symbols('q eta m Delta k Cc',positive=True)
eq('inequality.same_background_strict_margin',(m+Delta)/((1+eta)*(1+q))-3*m/(4*(1+eta)),(m*(1-3*q)+4*Delta)/(4*(1+eta)*(1+q)))
eq('inequality.distinct_background_strict_margin',(m+Delta)*Cc/((1+eta)*(1+k))-m*Cc/((1+eta)*(1+k)),Delta*Cc/((1+eta)*(1+k)))
# Rational bounds for e^2 via a positive Taylor series and a geometric tail.
N=5
partial=sum(S.Integer(2)**j/S.factorial(j) for j in range(N+1))
nextterm=S.Integer(2)**(N+1)/S.factorial(N+1)
upper=partial+nextterm/(1-R(2,N+2))
ck('domain.exponential_two_rational_bracket',7<partial<upper<8,{'partial':str(partial),'upper':str(upper),'tail_ratio_upper':'2/7','proof':'For n>=6, successive terms of exp(2) have ratio at most 2/7. The omitted positive tail is at most its first term/(1-2/7).'})
kv=R(2,11);av=(1-kv)*(1+3*kv)/4;sv=(1+kv)/(kv*(1-3*kv))
gupper=12*av*(8-1)-200+200/(sv*7)
ck('domain.positive_u_large_nu_exact_negative_bound',gupper<0,{'t':2,'nu':100,'k':str(kv),'G_upper':str(gupper),'proof':'Use 7<exp(2)<8 separately in the two positive terms of G; this upper bound is already negative.'})
z=R(1,4)
force_lower=1-z**2/2+z*(z-z**3/6)
ck('domain.tachyonic_force_exact_excess',force_lower>1,{'z':str(z),'force_lower':str(force_lower),'excess_lower':str(force_lower-1),'proof':'On 0<z<1 the alternating Taylor lower bounds cos(z)>=1-z^2/2 and sin(z)>=z-z^3/6 apply.'})
crit=1+1/(2*sv); floor_gap=R(3,2)*sv*(1-crit)**2
ck('domain.Ccrit_above_one_exact_false_floor',1<crit<(1+sv)/sv and floor_gap>0,{'Ccrit':str(crit),'positive_quadratic_gap':str(floor_gap),'vacuum_U':'3/2','proof':'U0(Ccrit)>3/2 from this positive term alone, while Cvac=1<Ccrit and Uvac=3/2. The claimed floor cannot be extended to Ccrit>1.'})
Ccrit=(1+kv)*R(1,10)
ck('domain.negative_Gcal_exact_counterwitness',R(1,10)*20>1 and -20<=1 and -1<=1 and 1>Ccrit,{'Gcal':-1,'Gpr':1,'gamma':-1,'Fbare':20,'Fcal':-20,'d':'1/10','m':1,'C_c':1,'Ccrit':str(Ccrit),'meaning':'Upper ceiling alone and a positive target do not imply the necessary coupling bound. V2 excludes this algebraic witness by adopted Gcal>0; no physical trajectory is asserted.'})
passed=sum(c['passed'] for c in checks);failed=len(checks)-passed
parser=argparse.ArgumentParser();parser.add_argument('--result',required=True);ns=parser.parse_args()
Path(ns.result).write_text(json.dumps({'scope':'narrow source correspondence plus exact domain witnesses; no science rerun','counts':{'passed':passed,'failed':failed,'total':len(checks)},'checks':checks,'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,'sympy':S.__version__},indent=2)+'\n')
print(f'TOTAL: PASS={passed} FAIL={failed}')
raise SystemExit(bool(failed))
