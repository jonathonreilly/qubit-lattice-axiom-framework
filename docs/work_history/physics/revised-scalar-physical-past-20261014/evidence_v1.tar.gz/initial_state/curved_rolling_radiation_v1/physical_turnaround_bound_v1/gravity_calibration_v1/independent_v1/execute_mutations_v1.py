#!/usr/bin/env python3
from pathlib import Path
import datetime,difflib,hashlib,json,os,subprocess,sys,time
p=Path(__file__).resolve().parent
src=(p/'check_independent_v1.py').read_text()
specs=[
 ('double_scalar_force','return C*(1+q)/(8*S.pi*Q)','return C*(1+2*q)/(8*S.pi*Q)','action.principal_force_binding'),
 ('drop_force_derivative_term','return (1+z)*S.exp(-z)','return S.exp(-z)','spectrum.actual_force_derivative'),
 ('reverse_ceiling_square','return 1-B*chi**2/(1-3*k*chi)','return 1+B*chi**2/(1-3*k*chi)','ceiling.exact_action_binding'),
 ('invert_mcase_dependence','return (1+eta)*(1+k)*epsilon*(1+delta)/m','return (1+eta)*(1+k)*epsilon*(1+delta)*m','calibration.critical_C_binding'),
 ('double_log_energy','log(C/L)**2/(8*a*(1+s))','log(C/L)**2/(4*a*(1+s))','potential.C_expression_from_action'),
 ('wrong_negative_branch_derivative','nu*t*(1-t)','nu*t*(1+t)','potential.actual_negative_branch_derivative'),
 ('double_normalized_kinetic','return vsq/2+U','return vsq+U','energy.action_stress_normalization'),
 ('drop_calibration_positivity','return Gcal > 0 and Gcal <= (1+eta)*Gpr and eta >= 0','return Gcal <= (1+eta)*Gpr and eta >= 0','calibration.rejects_negative_Gcal')
]
protocol={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_checker_sha256':hashlib.sha256(src.encode()).hexdigest(),'principle':'Actual single expression changes to independent implementation; expected mathematical witnesses fixed before execution. No producer source touched.','cases':[{'name':n,'old':o,'new':v,'intended_witness':w} for n,o,v,w in specs]}
(p/'mutations'/'PROTOCOL_v1.json').write_text(json.dumps(protocol,indent=2)+'\n')
records=[]; env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
for name,old,new,witness in specs:
 assert src.count(old)==1,(name,src.count(old))
 d=p/'mutations'/name; assert not d.exists();d.mkdir()
 changed=src.replace(old,new); code=d/'check_damaged.py';code.write_text(changed)
 (d/'SOURCE.diff').write_text(''.join(difflib.unified_diff(src.splitlines(True),changed.splitlines(True),fromfile='check_independent_v1.py',tofile=name+'/check_damaged.py')))
 argv=[sys.executable,'-B',str(code),'--result',str(d/'RESULTS_v1.json')]
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();tic=time.monotonic()
 r=subprocess.run(argv,cwd=p,env=env,capture_output=True,timeout=90)
 (d/'stdout.txt').write_bytes(r.stdout);(d/'stderr.txt').write_bytes(r.stderr)
 rr=json.loads((d/'RESULTS_v1.json').read_text()) if (d/'RESULTS_v1.json').exists() else None
 failed=[c['name'] for c in rr['checks'] if not c['passed']] if rr else []
 row={'name':name,'argv':argv,'cwd':str(p),'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-tic,'exit_code':r.returncode,'script_sha256':hashlib.sha256(code.read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'counts':rr['counts'] if rr else None,'intended_witness':witness,'failed_witnesses':failed,'detected':r.returncode==1 and witness in failed,'runtime_error':rr is None}
 (d/'COMMAND_v1.json').write_text(json.dumps(row,indent=2)+'\n');records.append(row)
 print(json.dumps({'name':name,'counts':row['counts'],'exit_code':r.returncode,'detected':row['detected'],'failed_witnesses':failed}))
(p/'mutations'/'RESULTS_v1.json').write_text(json.dumps({'actual_executions':len(records),'detected':sum(r['detected'] for r in records),'undetected':sum(not r['detected'] for r in records),'cases':records},indent=2)+'\n')
raise SystemExit(any(not r['detected'] for r in records))
