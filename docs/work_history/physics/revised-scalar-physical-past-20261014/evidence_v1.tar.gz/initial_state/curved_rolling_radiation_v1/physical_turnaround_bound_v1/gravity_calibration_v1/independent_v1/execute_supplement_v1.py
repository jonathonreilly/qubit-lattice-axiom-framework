#!/usr/bin/env python3
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
p=Path(__file__).resolve().parent;d=p/'runs'/'supplement_v1';assert not d.exists();d.mkdir()
argv=[sys.executable,'-B',str(p/'check_supplement_v1.py'),'--result',str(d/'RESULTS_v1.json')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat();tic=time.monotonic();env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
r=subprocess.run(argv,cwd=p,env=env,capture_output=True,timeout=90)
(d/'stdout.txt').write_bytes(r.stdout);(d/'stderr.txt').write_bytes(r.stderr)
(d/'COMMAND_v1.json').write_text(json.dumps({'argv':argv,'cwd':str(p),'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-tic,'exit_code':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'checker_sha256':hashlib.sha256((p/'check_supplement_v1.py').read_bytes()).hexdigest()},indent=2)+'\n')
print(r.stdout.decode());print(r.stderr.decode());raise SystemExit(r.returncode)
