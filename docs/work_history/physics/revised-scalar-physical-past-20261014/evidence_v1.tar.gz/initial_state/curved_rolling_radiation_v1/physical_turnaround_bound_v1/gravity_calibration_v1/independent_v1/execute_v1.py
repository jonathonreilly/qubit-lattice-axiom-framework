#!/usr/bin/env python3
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
p=Path(__file__).resolve().parent
run=p/'runs'/'baseline_v1'
assert not run.exists()
run.mkdir()
argv=[sys.executable,'-B',str(p/'check_independent_v1.py'),'--result',str(run/'RESULTS_v1.json')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); tic=time.monotonic()
env=dict(os.environ); env['PYTHONDONTWRITEBYTECODE']='1'
r=subprocess.run(argv,cwd=p,env=env,capture_output=True,timeout=90)
(run/'stdout.txt').write_bytes(r.stdout); (run/'stderr.txt').write_bytes(r.stderr)
record={'argv':argv,'cwd':str(p),'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-tic,'exit_code':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'checker_sha256':hashlib.sha256((p/'check_independent_v1.py').read_bytes()).hexdigest(),'producer_execution':False}
(run/'COMMAND_v1.json').write_text(json.dumps(record,indent=2)+'\n')
print(r.stdout.decode()); print(r.stderr.decode()); print(json.dumps(record,indent=2))
