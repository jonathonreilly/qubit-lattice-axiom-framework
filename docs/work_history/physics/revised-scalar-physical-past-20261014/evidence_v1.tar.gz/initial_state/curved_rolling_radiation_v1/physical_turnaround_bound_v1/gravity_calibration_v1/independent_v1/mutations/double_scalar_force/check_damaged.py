#!/usr/bin/env python3
"""Independent action-derived gravity calibration checks. No producer imports."""
import argparse, json, sys, hashlib, platform
from pathlib import Path
import sympy as S

R=S.Rational
records=[]
def eq(name,lhs,rhs):
    residual=S.factor(S.together(lhs-rhs))
    if residual != 0:
        residual=S.simplify(residual)
    ok=residual == 0
    records.append({'name':name,'passed':bool(ok),'lhs':str(lhs),'rhs':str(rhs),'residual':str(residual)})
    print(('PASS ' if ok else 'FAIL ')+name+(' residual='+str(residual) if not ok else ''))
    return ok

def check(name,condition,evidence):
    ok=bool(condition)
    records.append({'name':name,'passed':ok,'evidence':evidence})
    print(('PASS ' if ok else 'FAIL ')+name)
    return ok

# Deliberately separate evaluated candidate expressions from the independent
# action/derivative paths. Actual damaged copies modify these definitions only.
def principal_model(C,q,Q):
    return C*(1+2*q)/(8*S.pi*Q)
def force_profile(z):
    return (1+z)*S.exp(-z)
def ceiling_model(k,chi):
    B=4*k**2*(1-3*k)/(1+k)**2
    return 1-B*chi**2/(1-3*k*chi)
def critical_C(k,m,eta,epsilon,delta):
    return (1+eta)*(1+k)*epsilon*(1+delta)/m
def potential_C(C,a,s,nu):
    L=1+s-s*C
    return R(3,2)+R(3,2)*s*(1-C)**2+nu*L**2*S.log(C/L)**2/(8*a*(1+s))
def derivative_bracket(t,a,s,nu):
    return 12*a*(S.exp(t)-1)+nu*t*(1-t)+nu*t/(s*S.exp(t))
def normalized_energy(vsq,U):
    return vsq/2+U
def calibration_admitted(Gcal,Gpr,eta):
    return Gcal > 0 and Gcal <= (1+eta)*Gpr and eta >= 0

k,E=S.symbols('k E',positive=True)
a=(1-k)*(1+3*k)/4
s=(1+k)/(k*(1-3*k))
F=1+s*E
J=1+(1-3*a)*s*E
C=(1+s)*E/F
Ku=J/F**2
b=S.sqrt(a)/F
q=b**2/Ku
chi=s*(C-1)
Q,Hv=S.symbols('Q Hv',positive=True)

# Scalar variation and the point-source/frame normalization.
x=S.symbols('r')
ph=S.Function('ph')(x)
Kc,bc,T,rho=S.symbols('Kc bc T rho',positive=True)
L=-Q*Kc*S.diff(ph,x)**2
EL=S.diff(L,ph)-S.diff(S.diff(L,S.diff(ph,x)),x)+bc*T
source=S.solve(EL,S.diff(ph,x,2))[0].subs(T,-rho)
eq('action.scalar_source_coefficient',source,bc*rho/(2*Q*Kc))
pressure=S.symbols('pressure')
trace=-rho+3*pressure
eq('action.trace_free_source',(-bc*trace/(2*Q*Kc)).subs(pressure,rho/3),0)
amp=S.symbols('amp')
source_monopole=S.solve(S.Eq(-4*S.pi*amp,bc/(2*Q*Kc)),amp)[0]
eq('action.green_flux_normalization',source_monopole,-bc/(8*S.pi*Q*Kc))
A,MJ,RJ,qsym=S.symbols('A MJ RJ qsym',positive=True)
ME=A*MJ
RE=RJ/A
psiE=-ME/(8*S.pi*Q*RE)
dlogA=-qsym*ME/(8*S.pi*Q*RE)
force_from_action=-S.diff(psiE+dlogA,RJ)*RJ**2/MJ
# Force vector is inward; positive coefficient is minus the radial acceleration.
Gfromaction=-force_from_action
eq('action.frame_mass_radius_factor',-psiE*RJ/MJ,A**2/(8*S.pi*Q))
eq('action.principal_force_binding',principal_model(A**2,qsym,Q),Gfromaction)
eq('action.b_from_log_A',S.diff(S.log(C),E)*S.sqrt(a)*E,b)
eq('action.metric_coupling_norm',q,a/J)
eq('domain.one_minus_3a',1-3*a,(1-3*k)**2/4)
eq('domain.one_third_minus_a',R(1,3)-a,(1-3*k)**2/12)
eq('domain.a_minus_q',a-q,a*(1-3*a)*s*E/J)
eq('domain.chi_lower',chi+s,s*E*(1+s)/F)
eq('domain.chi_upper',1-chi,(1+s)/F)
eq('domain.C_upper',(1+s)/s-C,(1+s)/(s*F))
eq('domain.denominator_margin',(1-3*k*chi)-(1-3*k),3*k*(1-chi))
eq('action.chi_inverse',E,(1+chi/s)/(1-chi))
eq('action.q_from_chi',q,k*(1-chi)/(1-3*k*chi))
RG=principal_model(C,q,Q)*(8*S.pi*Q)/(1+k)
eq('ceiling.exact_action_binding',RG,ceiling_model(k,chi))
eq('ceiling.vacuum_saturation',RG.subs(E,1),1)
eq('ceiling.small_E_limit',S.limit(RG,E,0,dir='+'),0)
eq('ceiling.large_E_limit',S.limit(RG,E,S.oo),(1+s)/(s*(1+k)))

# Whitened spectral control: exact rational metric and non-axis eigenvectors.
Kmat=S.diag(4,9,25)
bvec=S.Matrix([R(2,5),R(3,7),R(1,2)])
rootinv=S.diag(R(1,2),R(1,3),R(1,5))
beta=rootinv*bvec
O=S.Matrix([[R(3,5),-R(4,5),0],[R(4,5),R(3,5),0],[0,0,1]])
weights=[(O[:,i].dot(beta))**2 for i in range(3)]
q_spec=(bvec.T*Kmat.inv()*bvec)[0]
eq('spectrum.orthonormality',(O.T*O-S.eye(3)).norm()**2,0)
eq('spectrum.weight_sum',sum(weights),q_spec)
check('spectrum.weights_positive',all(w>0 for w in weights),{'weights':[str(w) for w in weights],'q':str(q_spec),'K_diagonal':[4,9,25]})
M2=O*S.diag(0,4,16)*O.T
eq('spectrum.mass_operator_reconstruction',(M2*O-O*S.diag(0,4,16)).norm()**2,0)
r,m,z=S.symbols('r m z',positive=True)
force_by_differentiation=-r**2*S.diff(S.exp(-m*r)/r,r)
eq('spectrum.actual_force_derivative',force_profile(m*r),force_by_differentiation)
eq('spectrum.profile_derivative',S.diff(force_profile(z),z),-z*S.exp(-z))
eq('spectrum.profile_at_zero',force_profile(0),1)
eq('spectrum.profile_at_infinity',S.limit(force_profile(z),z,S.oo),0)
force_sum=sum(w*force_profile(mm*r) for w,mm in zip(weights,[0,2,4]))
eq('spectrum.massless_short_distance',S.limit(force_sum,r,0,dir='+'),q_spec)
eq('spectrum.massive_long_distance',S.limit(force_sum,r,S.oo),weights[0])

# Exact rational finite-field controls built from E directly, no grids imported.
rational_points=[]
for kv in [R(1,11),R(2,11),R(3,13)]:
    for ev in [R(1,25),R(2,7),S.Integer(1),R(9,4),S.Integer(17)]:
        cv=S.factor(C.subs({k:kv,E:ev})); qv=S.factor(q.subs({k:kv,E:ev}))
        ch=S.factor(chi.subs({k:kv,E:ev})); rg=S.factor(RG.subs({k:kv,E:ev}))
        sv=s.subs(k,kv); av=a.subs(k,kv)
        ok=0<cv<(1+sv)/sv and -sv<ch<1 and 0<qv<av<R(1,3) and 0<rg<=1 and ((rg==1)==(ev==1))
        row={'k':str(kv),'E':str(ev),'C':str(cv),'q':str(qv),'chi':str(ch),'Gpr_over_G0':str(rg)}
        rational_points.append(row)
        check('rational.domain_and_ceiling.k='+str(kv)+'.E='+str(ev),ok,row)

# Calibration identities and exact strict-threshold reasoning/corners.
Hj,rhoJ,gb,gcal=S.symbols('Hj rhoJ gb gcal',positive=True)
fbare=3*Hj**2/(8*S.pi*gb*rhoJ)
fcal=3*Hj**2/(8*S.pi*gcal*rhoJ)
eq('calibration.diagnostic_ratio',fcal,fbare/(gcal/gb))
et,ep,de,ms,cc=S.symbols('eta epsilon delta mcase Cc',positive=True)
lower=ms*cc/((1+et)*(1+k))
root=S.solve(S.Eq(lower,ep*(1+de)),cc)[0]
eq('calibration.critical_C_binding',critical_C(k,ms,et,ep,de),root)
eq('calibration.strict_order_factor',ep*(1+de)-lower,ms*(critical_C(k,ms,et,ep,de)-cc)/((1+et)*(1+k)))
for mm in [S.Integer(1),S.Integer(2)]:
    for eta in [S.Integer(0),R(1,5)]:
        kval=R(2,11); eps=R(1,10); delta=R(1,4)
        crit=critical_C(kval,mm,eta,eps,delta)
        at_boundary=mm*crit/((1+eta)*(1+kval))
        eq(f'calibration.target_boundary.m={mm}.eta={eta}',at_boundary,eps*(1+delta))
        check(f'calibration.strict_target_side.m={mm}.eta={eta}',mm*(crit+R(1,100))/((1+eta)*(1+kval))>eps*(1+delta),{'Ccrit':str(crit),'C_above':str(crit+R(1,100))})
# Concrete feasible inequality tuple; not a trajectory or sufficient construction.
kv=R(2,11); mv=S.Integer(1); eta=R(1,5); eps=R(1,10); delta=R(1,4)
ccv=R(1,10); gamma=(1+eta)*(1+kv)/ccv; product_bare=R(6,5)
d=eps; fcal_val=product_bare/gamma/d
check('calibration.necessary_not_reverse',ccv<critical_C(kv,mv,eta,eps,delta) and fcal_val<=1+delta and product_bare>mv,{'C_c':str(ccv),'Ccrit':str(critical_C(kv,mv,eta,eps,delta)),'gamma':str(gamma),'d':str(d),'Fcal':str(fcal_val),'product_bare':str(product_bare),'scope':'abstract logical tuple, not a constructed action history'})
check('calibration.accepts_positive_ceiling',calibration_admitted(R(6,5),1,R(1,5)),{'Gcal':'6/5','Gpr':'1','eta':'1/5'})
check('calibration.rejects_negative_Gcal',not calibration_admitted(-1,1,0),{'Gcal':-1,'Gpr':1,'eta':0})
check('calibration.rejects_zero_Gcal',not calibration_admitted(0,1,0),{'Gcal':0,'Gpr':1,'eta':0})

# The potential is differentiated in t and transformed independently to C.
t=S.symbols('t',real=True)
asym,ss,nu=S.symbols('a s nu',positive=True)
Et=S.exp(t); Ft=1+ss*Et
Ut=R(3,2)+R(3,2)*ss*(Et-1)**2/Ft**2+nu*(1+ss)*t**2/(8*asym*Ft**2)
pref=(1+ss)*ss*Et/(4*asym*Ft**3)
eq('potential.actual_negative_branch_derivative',S.diff(Ut,t),pref*derivative_bracket(t,asym,ss,nu))
cv=S.symbols('Cvalue',positive=True)
Lc=1+ss-ss*cv
Ufromaction=S.cancel(Ut.subs(t,S.log(cv/Lc)))
eq('potential.C_expression_from_action',potential_C(cv,asym,ss,nu),Ufromaction)
eq('potential.coupling_inversion',(1+ss)*(cv/Lc)/(1+ss*(cv/Lc)),cv)
eq('potential.clock_coupling_derivative',S.diff((1+ss)*Et/Ft,t), (1+ss)*Et/Ft**2)
eq('potential.vacuum_minimum',potential_C(1,asym,ss,nu),R(3,2))
# Decompose the entire derivative into manifestly positive factors times negative t terms.
h=S.symbols('h',positive=True)
gneg=derivative_bracket(-h,asym,ss,nu)
eq('potential.negative_t_decomposition',gneg,-12*asym*(1-S.exp(-h))-nu*h*(1+h)-nu*h*S.exp(h)/ss)
vsq,Us=S.symbols('vsq Us',nonnegative=True)
rho_scalar=Q*Hv**2*vsq+2*Q*Hv**2*Us
eq('energy.action_stress_normalization',normalized_energy(vsq,Us),rho_scalar/(2*Q*Hv**2))
eq('energy.excess_variable',normalized_energy(vsq,Us)-R(3,2),vsq/2+Us-R(3,2))
# Asymptotic constant: C=exp(-h), h->infinity; avoid numerical extrapolation.
last=nu*Lc**2*S.log(cv/Lc)**2/(8*asym*(1+ss))
ratio=last/(nu*(1+ss)*S.log(cv)**2/(8*asym))
eq('potential.small_C_asymptotic',S.limit(ratio,cv,0,dir='+'),1)
# Evaluate fixed C values at distinct exact parameters; this is a diagnostic,
# while the derivative decomposition above supplies the general sign proof.
potential_diagnostics=[]
for nv in [R(5,7),S.Integer(100)]:
    av=a.subs(k,R(2,11)); sv=s.subs(k,R(2,11))
    c1=R(1,10); c2=R(39,220)
    u1=potential_C(c1,av,sv,nv); u2=potential_C(c2,av,sv,nv)
    t1=S.log(c1/(1+sv-sv*c1)); g=derivative_bracket(t1,av,sv,nv)
    row={'k':'2/11','nu':str(nv),'C1':str(c1),'C2':str(c2),'U0_C1':str(S.N(u1,40)),'U0_C2':str(S.N(u2,40)),'derivative_bracket_C1':str(S.N(g,40))}
    potential_diagnostics.append(row)
    check('potential.numeric_negative_branch.nu='+str(nv),S.N(u1-u2,60)>0 and S.N(u2-R(3,2),60)>0 and S.N(g,60)<0,row)

# Explicit domain attacks, each preserving its distinction from an in-domain counterexample.
neg_witness={'d':'1/10','Fbare':'20','gamma':'-1','Fcal':'-20','m':'1','C_c':'1','k':'2/11','eta':'0','epsilon':'1/10','delta':'0','Gcal_ceiling_satisfied':True}
check('domain_witness.v1_negative_calibration_gap',R(1,10)*20>1 and -20<=1 and 1>critical_C(R(2,11),1,0,R(1,10),0) and -1<=1,neg_witness)
zsmall=R(1,4)
tachyon_force=S.cos(zsmall)+zsmall*S.sin(zsmall)
# cos z+z sin z has derivative z cos z>0 on (0,pi/2), so this
# positive excess is a proof consequence; decimal evaluation is ancillary.
check('domain_witness.tachyonic_cap_failure',S.N(tachyon_force,60)>1,{'z':'1/4','force_multiplier':str(tachyon_force),'value':str(S.N(tachyon_force,40)),'proof':'d/dz[cos z+z sin z]=z cos z>0 on (0,pi/2); value at 0 is 1; static Helmholtz domain is excluded'})
sv=s.subs(k,R(2,11)); av=a.subs(k,R(2,11)); highc=1+1/(2*sv)
false_floor=potential_C(highc,av,sv,R(5,7))
check('domain_witness.Ccrit_above_one_false_floor',1<highc<(1+sv)/sv and S.N(false_floor,60)>R(3,2),{'Ccrit':str(highc),'vacuum_C':1,'vacuum_U':'3/2','false_floor':str(S.N(false_floor,40)),'scope':'shows why extending the negative-u floor to Ccrit>1 is invalid'})
gpositive=derivative_bracket(S.Integer(2),av,sv,S.Integer(100))
check('domain_witness.positive_u_large_nu_not_monotone',S.N(gpositive,60)<0,{'t':2,'k':'2/11','nu':100,'G':str(gpositive),'value':str(S.N(gpositive,40))})

args=argparse.ArgumentParser(); args.add_argument('--result',required=True); ns=args.parse_args()
passed=sum(r['passed'] for r in records); failed=len(records)-passed
out={'scope':'independent action identities, rational controls and domain witnesses; no producer execution','python':sys.version,'platform':platform.platform(),'sympy':S.__version__,'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'passed':passed,'failed':failed,'total':len(records)},'checks':records,'rational_points':rational_points,'potential_diagnostics':potential_diagnostics,'negative_calibration_witness':neg_witness}
Path(ns.result).write_text(json.dumps(out,indent=2)+'\n')
print(f'TOTAL: PASS={passed} FAIL={failed}')
raise SystemExit(bool(failed))
