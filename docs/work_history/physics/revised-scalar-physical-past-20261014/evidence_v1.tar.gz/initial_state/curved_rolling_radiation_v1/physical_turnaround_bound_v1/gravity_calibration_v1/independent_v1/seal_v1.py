#!/usr/bin/env python3
from pathlib import Path
import datetime,hashlib,json
p=Path(__file__).resolve().parent
assert not (p/'MANIFEST_v1.json').exists() and not (p/'RECEIPT_v1.json').exists()
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(rel):
 b=(p/rel).read_bytes();return {'path':rel,'bytes':len(b),'sha256':sha(b)}
source=json.loads((p/'SOURCE_MANIFEST_v1.json').read_text());w=Path(source['worktree'])
verified=[]
for r in source['sources']:
 live=w/r['original_path'];snap=p/r['snapshot_path'];b=live.read_bytes()
 assert not live.is_symlink() and not snap.is_symlink()
 assert b==snap.read_bytes() and len(b)==r['bytes'] and sha(b)==r['sha256'],r
 verified.append(dict(r,live_snapshot_identical=True))
base=json.loads((p/'runs/baseline_v1/RESULTS_v1.json').read_text())
supp=json.loads((p/'runs/supplement_v1/RESULTS_v1.json').read_text())
mut=json.loads((p/'mutations/RESULTS_v1.json').read_text())
assert base['counts']=={'passed':75,'failed':0,'total':75}
assert supp['counts']=={'passed':12,'failed':0,'total':12}
assert mut['actual_executions']==8 and mut['detected']==8 and mut['undetected']==0
assert base['checker_sha256']==sha((p/'check_independent_v1.py').read_bytes())
assert supp['checker_sha256']==sha((p/'check_supplement_v1.py').read_bytes())
for row in mut['cases']:
 assert row['exit_code']==1 and row['intended_witness'] in row['failed_witnesses']
 assert row['script_sha256']==sha((p/'mutations'/row['name']/'check_damaged.py').read_bytes())
 assert row['stdout_sha256']==sha((p/'mutations'/row['name']/'stdout.txt').read_bytes())
 assert row['stderr_sha256']==sha((p/'mutations'/row['name']/'stderr.txt').read_bytes())
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
(p/'FINAL_SOURCE_IDENTITY_v1.json').write_text(json.dumps({'created_utc':now,'source_pairs':len(verified),'all_current_live_snapshot_hash_size_pairs_match':True,'pairs':verified,'final_derivation_sha256':verified[1]['sha256'],'old_derivation_preserved':True,'hand_derivation_sha256':sha((p/'HAND_DERIVATION_v1.md').read_bytes()),'all_current_script_and_saved_result_hash_bindings_match':True,'writes_outside_new_independent_folder':False},indent=2)+'\n')
artifacts=[]
for f in sorted(p.rglob('*')):
 if f.is_dir():continue
 assert f.is_file() and not f.is_symlink(),str(f)
 rel=str(f.relative_to(p))
 assert rel not in ['MANIFEST_v1.json','RECEIPT_v1.json']
 artifacts.append(ref(rel))
manifest={'schema':'focused-independent-mathematical-check-manifest-v1','created_utc':now,'artifact_root':str(p),'artifact_count':len(artifacts),'excludes':['MANIFEST_v1.json','RECEIPT_v1.json'],'artifacts':artifacts}
(p/'MANIFEST_v1.json').write_text(json.dumps(manifest,indent=2)+'\n')
receipt={'schema':'focused-independent-mathematical-check-receipt-v1','created_utc':now,'unit':'gravity_calibration_v1/independent_v1','scientific_author':'/root','independent_checker':'/root/scalar_energy_check','formal_audit':False,'formal_grade_assigned':False,'landing_authority':False,'final_source':'DERIVATION_v2.md','final_source_sha256':verified[1]['sha256'],'original_source_sha256':verified[0]['sha256'],'source_bindings':source['sources'],'source_pair_count':len(source['sources']),'manifest':ref('MANIFEST_v1.json'),'report':ref('REPORT_v1.md'),'hand_derivation':ref('HAND_DERIVATION_v1.md'),'protocol':ref('PROTOCOL_INDEPENDENT_v1.json'),'findings':ref('FINDINGS_v1.json'),'failure_ledger':ref('FAILURES_v1.json'),'source_dispositions':ref('SOURCE_DISPOSITIONS_v1.json'),'final_source_identity':ref('FINAL_SOURCE_IDENTITY_v1.json'),'access_and_scope':ref('ACCESS_AND_SCOPE_v1.json'),'command_index':ref('COMMAND_INDEX_v1.json'),'baseline':{'checker':ref('check_independent_v1.py'),'command':ref('runs/baseline_v1/COMMAND_v1.json'),'stdout':ref('runs/baseline_v1/stdout.txt'),'stderr':ref('runs/baseline_v1/stderr.txt'),'results':ref('runs/baseline_v1/RESULTS_v1.json'),'counts':base['counts'],'actual_executions':1,'exit_code':0},'narrow_supplement':{'checker':ref('check_supplement_v1.py'),'command':ref('runs/supplement_v1/COMMAND_v1.json'),'stdout':ref('runs/supplement_v1/stdout.txt'),'stderr':ref('runs/supplement_v1/stderr.txt'),'results':ref('runs/supplement_v1/RESULTS_v1.json'),'counts':supp['counts'],'actual_executions':1,'exit_code':0,'scope':'v1-v2 exact correspondence and exact domain/strict-inequality witnesses'},'actual_damaged_controls':{'protocol':ref('mutations/PROTOCOL_v1.json'),'results':ref('mutations/RESULTS_v1.json'),'actual_executions':8,'detected':8,'undetected':0,'all_exit_codes':1,'cases':[{'name':r['name'],'counts':r['counts'],'intended_witness':r['intended_witness'],'command':ref('mutations/'+r['name']+'/COMMAND_v1.json'),'source':ref('mutations/'+r['name']+'/check_damaged.py'),'diff':ref('mutations/'+r['name']+'/SOURCE.diff')} for r in mut['cases']]},'source_correction':{'finding':'missing explicit positive G_cal in v1 general upper-error route','same_session_confirmation':True,'equations_changed':False,'only_change':'Explicit positive calibration and target/error parameter domains before equation (3).','qualification':'For a separately supplied ceiling, positivity is adopted as an applicability condition; not derived from the ceiling alone.','original_counterwitness_preserved':True},'checked_scope':['Independent variation of complete supplied action, force/trace/mass/radius normalization','Positive metric and nonnegative self-adjoint spectral weights and static force profile','Same-background 4/3 cap and exact arbitrary finite-background G_pr<=G0','Positive-calibration necessary Ccrit inequality and strict direction','Negative-u total potential minimum, monotonicity, Einstein scalar-energy floor and asymptotic','Exact narrow v2 correction correspondence'],'reused_assumption_only':{'source':source['sources'][5],'scope':'Physical-turnaround theorem hypotheses and strict product d_J F_bare>m only; its mathematics/trajectories not rerun or newly certified.'},'limits':['Leading weak-source or separately conditional frozen stable massive readout only.','No finite-distance remainder bound, source sensitivity or environment/history solution established.','No measured calibration, empirical exclusion, state selector or global history theorem.','No producer code/results, grids or previous independent code accessed.','Finite controls supplement the handwritten quantified proofs; counts are not a theorem or audit.'],'mutations':{'writes_confined_to_new_independent_folder':True,'parent_sources_or_previous_seals_changed':False,'git_PR_runtime_lock_or_audit_state_changed':False,'subagents_spawned':False}}
(p/'RECEIPT_v1.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'artifact_count':len(artifacts),'source_pair_count':len(verified),'total_files':len(artifacts)+2,'sealed':{n:ref(n) for n in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json']}},indent=2))
