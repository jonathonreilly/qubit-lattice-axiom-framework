from pathlib import Path
import datetime,hashlib,json
p=Path(__file__).resolve().parent
meta=json.loads((p/'SOURCE_MANIFEST_v1.json').read_text())
baseline=json.loads((p/'runs/baseline_v1/RESULTS_v1.json').read_text())
supplement=json.loads((p/'runs/supplement_v1/RESULTS_v1.json').read_text())
mut=json.loads((p/'mutations/RESULTS_v1.json').read_text())
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
finding={'id':'positive_calibration_domain','kind':'omitted explicit applicability premise in v1 upper-error-ceiling route','found_before_executable_controls':True,'original_sha256':meta['sources'][0]['sha256'],'final_sha256':meta['sources'][1]['sha256'],'statement':'An upper ceiling alone does not ensure positive G_cal or gamma; division and target ordering require it. The source-response models themselves already supply positive coefficients.','witness':baseline['negative_calibration_witness'],'author_correction':'V2 explicitly adopts G_cal>0, gamma>0, 0<epsilon<=1, delta>=0, eta>=0 before equation (3).','correction_scope':'One prose paragraph only, no equation change; independent exact diff and unchanged equation-line checks passed. Positivity under an externally supplied upper bound is an applicability condition, not a derived consequence of the bound.','disposition':'resolved in v2; v1 preserved with the missing explicit premise recorded','unresolved_material_source_error':False}
(p/'FINDINGS_v1.json').write_text(json.dumps({'created_utc':now,'findings':[finding],'other_material_source_errors_found':[]},indent=2)+'\n')
(p/'FAILURES_v1.json').write_text(json.dumps({'created_utc':now,'original_source_premise_gap':'positive_calibration_domain; see FINDINGS_v1.json','baseline_execution':{'path':'runs/baseline_v1/COMMAND_v1.json','counts':baseline['counts'],'exit_code':0},'supplement_execution':{'path':'runs/supplement_v1/COMMAND_v1.json','counts':supplement['counts'],'exit_code':0},'unexpected_execution_failures':[],'verifier_repairs':[],'expected_damaged_executions':[{'name':x['name'],'exit_code':x['exit_code'],'counts':x['counts'],'failed_witnesses':x['failed_witnesses'],'command_path':'mutations/'+x['name']+'/COMMAND_v1.json'} for x in mut['cases']],'all_original_scripts_logs_results_preserved':True,'parent_execution_claims':'No parent checker/results read, imported or executed; no parent run is represented as independent evidence.'},indent=2)+'\n')
cmdpaths=['runs/baseline_v1/COMMAND_v1.json','runs/supplement_v1/COMMAND_v1.json']+['mutations/'+x['name']+'/COMMAND_v1.json' for x in mut['cases']]
commands=[]
for rel in cmdpaths:
 b=(p/rel).read_bytes();d=json.loads(b);commands.append({'path':rel,'sha256':hashlib.sha256(b).hexdigest(),'argv':d['argv'],'exit_code':d['exit_code']})
(p/'COMMAND_INDEX_v1.json').write_text(json.dumps({'created_utc':now,'exact_mathematical_execution_records':commands,'execution_count':len(commands),'baseline_and_supplement':2,'actual_damaged_copies':8,'producer_executions':0,'parent_source_mutations':0,'git_mutations':0,'empirical_data_acquisition':0,'all_mathematical_stdout_stderr_saved':True},indent=2)+'\n')
(p/'SOURCE_DISPOSITIONS_v1.json').write_text(json.dumps({'created_utc':now,'dispositions':[dict(x,disposition=('preserved original; explicit positive-calibration premise gap recorded' if i==0 else 'final corrected derivation fully checked in same session' if i==1 else 'frozen supplied protocol' if i==2 else 'narrow correction correspondence checked' if i in [3,4] else 'read only for exact prior-theorem hypotheses; theorem not rerun or newly certified' if i==5 else 'complete supplied action and local response context read; action normalization independently reconstructed; unrelated claims not re-reviewed')) for i,x in enumerate(meta['sources'])]},indent=2)+'\n')
(p/'ACCESS_AND_SCOPE_v1.json').write_text(json.dumps({'created_utc':now,'scientific_reads':[x['original_path'] for x in meta['sources']],'extra_scientific_context_read':'The previously supplied future-confinement note was displayed during source discovery; the complete action in the frozen local-response note is sufficient and is the binding action input for this check. No theorem from the extra display is used.','procedure_reads':['worktree AGENTS.md','git show origin/ai/execution:AGENTS.md (read only, exit 0)','docs/ai_methodology/SCIENCE_WORKFLOW.md','/Users/jonBridger/.codex/skills/review-loop/SKILL.md'],'skill_use':'Focused source binding, independent calculation and full-failure preservation only; no branch/PR review workflow, formal audit or landing authority invoked. Explicit task scope controls.','blind_boundary':{'producer_checkers_or_results_read':False,'grids_read':False,'prior_independent_code_read':False,'new_empirical_sources_accessed':False},'writes':'Only this new independent_v1 folder','model':'Inherited session configuration; no model override or subagent delegation','original_author':'/root'},indent=2)+'\n')
source_table='\n'.join('| '+x['snapshot_path']+' | `'+x['sha256']+'` |' for x in meta['sources'])
mutation_table='\n'.join('| '+x['name']+' | '+str(x['counts']['passed'])+'/'+str(x['counts']['failed'])+' | `'+x['intended_witness']+'` |' for x in mut['cases'])
report=r'''# Focused independent gravity-calibration check

Scientific author: /root. Independent checker: /root/scalar_energy_check.
This is a source-bound mathematical check, not a formal audit, source authorship transfer, landing decision, or empirical acceptance.

## Conclusion and correction

Equations (1)–(10) are supported under the final v2 stated domains and the explicitly reused physical-turnaround assumptions. The action fixes the force normalization and spectral sum; the arbitrary finite-background principal coefficient has maximum G0=1/(8 pi Q0); the necessary threshold has the strict direction C_c<Ccrit; and the negative-u potential gives the stated Einstein scalar energy floor for 0<Ccrit<1. No additional material source correction was found.

V1 omitted an explicit positive-calibration premise from its general externally supplied upper-error-ceiling route. Equations (1) and (2) already produce positive coefficients in their own domains. An inequality G_cal<=(1+eta)G_pr by itself does not: zero or negative G_cal invalidates division or reverses the order. The exact witness d=1/10, F_bare=20, gamma=-1, m=1, C_c=1, k=2/11, eta=0, epsilon=1/10, delta=0 has d F_bare=2>1 and F_cal=-20<=1, but C_c=1 exceeds Ccrit=13/110. This is a witness to a missing algebraic applicability condition, not a proposed physical negative-gravity experiment or an action-history construction.

V2 adds G_cal>0, gamma>0, 0<epsilon<=1, delta>=0, eta>=0 in one paragraph before equation (3). I read v2 fully and verified byte-for-byte that this is the only change, that every indented equation is unchanged, and that the supplied diff and correction hashes match. Positivity is explicitly adopted for the general error-ceiling route; it was not newly derived from that ceiling. V1 and the finding remain preserved.

## Independent derivation and exact checked scope

The complete supplied action is frozen in source 07. The handwritten derivation was saved before mathematical control code, with SHA d9a40c46df5b2831437e962060d4dc4d3e3ef77cee69aa5a1cf289c13770dd1f. No parent checker, results, grids or prior independent code was accessed.

Varying the action gives 2Q K_AB times the covariant scalar wave operator, minus 2Q Hv² U_A, plus b_A T_E. In the frozen weak dust principal limit, Delta delta_phi^A=b^A rho_E/(2Q). The distributional identity Delta(1/r)=-4 pi delta_3 therefore fixes the point-source scalar amplitude to -b^A M_E/(8 pi Q r_E). The physical lapse adds b.delta_phi to the Einstein potential. The point-particle action gives M_E=A M_J, and a physical ruler gives r_J=A r_E. Thus M_E/r_E=C M_J/r_J, giving C(1+q)/(8 pi Q), rather than a freely adjustable scalar factor. The same variation makes the scalar trace forcing vanish for a trace-free source.

The actual metric gives q=(sqrt(a)/F)^2/(J/F²)=a/J. Since 1-3a=(1-3k)²/4>0 and 1/3-a=(1-3k)²/12>0, finite E>0 implies 0<q<a<1/3. Neither transverse field enters this principal norm. This is not a stability proof for the full background.

For the separately conditional massive model, whiten the constant positive field metric. Self-adjointness and nonnegativity must hold in that positive inner product, so the whitened squared-mass matrix is symmetric nonnegative. With beta=K^(-1/2)b and a complete real orthonormal eigenbasis, w_i=(e_i.beta)²>=0 and sum w_i=beta²=q. Differentiation of the Yukawa potential, not just its amplitude, yields f(z)=(1+z)exp(-z). Its derivative is -z exp(-z); hence 0<=f<=1 for z>=0. The physical radius is A r_E and the physical inverse range is m_i/A. This gives G_bare<=G_force<=G_pr for the prescribed forced point-source solution.

With positive gamma, the diagnostic ratio is exactly F_cal=F_bare/gamma. The preceding source supplies the strict product d_J F_bare>m under its interval hypotheses. At the same background gamma<4/3, or gamma<4(1+eta)/3 under the positive bounded-error route. The strict product gives equations (4)–(5). The explicit margin at the maximal gamma is

    (m+Delta)/[(1+eta)(1+q)] - 3m/[4(1+eta)]
      = [m(1-3q)+4Delta]/[4(1+eta)(1+q)] > 0,

for Delta>0 and 0<q<1/3.

For the distinct-background comparison I began with the original E functions and derived chi=s(E-1)/(1+sE), its inverse, and q=k(1-chi)/(1-3k chi). The domain is -s<chi<1 and 1-3k chi>0. Direct substitution gives

    G_pr/G0=C(1+q)/(1+k)
      =1-[4k²(1-3k)/(1+k)²] chi²/(1-3k chi).

The left side is positive; the subtracted term is nonnegative and vanishes exactly at u=0. This proves the exact global ceiling for this leading coefficient at every finite background, independent of x,y. It does not prove that a local experiment is admissible at every such background.

Dividing the positive calibration ceiling by the cosmic bare coefficient yields gamma<=(1+eta)(1+k)/C_c. Combining the strict product with d_J F_cal<=epsilon(1+delta) gives C_c<Ccrit, where Ccrit=(1+eta)(1+k)epsilon(1+delta)/m. The strict direction and the m=1 versus m=2 factor were checked symbolically and at exact rational boundaries. Satisfying this inequality is not sufficient to supply a physical trajectory or environment.

At fixed u the transverse potential terms are nonnegative, so x=y=0 minimizes U. With L=1+s-sC, the exact inverse E=C/L and F=(1+s)/L give equation (9), including its coefficient nu L²/[8a(1+s)]. Differentiating the original potential in t=2sqrt(a)u, before converting to C, gives the positive prefactor (1+s)s exp(t)/(4a F³) times

    12a(exp(t)-1)+nu t(1-t)+nu t/[s exp(t)].

Every term is negative for t<0 and nu>0; dC/du>0. No upper bound on nu is needed on this branch. The prefactor identity is the x=y=0 line calculation; the remaining transverse energies are nonnegative and cannot weaken the floor. For 0<C_c<Ccrit<1, U(phi_c)>=U0(C_c)>U0(Ccrit). The action stress tensor gives rho_phi,E/(2QHv²)=|dphi/d(Hv t_E)|_K²/2+U, so the strict e floor follows with the stated normalization. The asymptotic ratio of the log term to nu(1+s)log²(C)/(8a) tends to one at fixed k,nu.

## Actual executions and adversarial evidence

The independent baseline executed once: **75 passed, 0 failed**, exit 0. A separate narrow correspondence/exact-domain supplement executed once: **12 passed, 0 failed**, exit 0. These are distinct saved executions, not a relabeled parent run or a repaired baseline. Both have complete commands, scripts, stdout, stderr and JSON results. Python 3.12.8 and SymPy 1.14.0 were used. No unexpected runtime failure or verifier repair occurred.

Finite rational controls use k=1/11, 2/11, 3/13 with E=1/25, 2/7, 1, 9/4, 17, derived directly from the original E expressions. The spectral control uses K=diag(4,9,25), b=(2/5,3/7,1/2), a 3-4-5 rational eigenbasis rotation and masses (0,2,4). No producer grid or outputs selected these points. Two numerical potential diagnostics use k=2/11, nu=5/7 or 100, and C=1/10 versus 39/220. Their sign observations accompany the general analytic derivative proof; decimal values are not claimed as interval certificates.

Eight actual single-expression damaged copies of my implementation were executed. Every one exited 1 with the intended mathematical witness; the scripts, exact diffs, full results and commands remain under mutations/. These establish that the independent controls discriminate the listed errors, not exhaustive test completeness.

| Actual damage | Passed/failed assertions | Intended witness |
|---|---:|---|
'''+mutation_table+r'''

The additional domain witnesses matter to the scope:

- If a squared mass is negative, a real static Helmholtz response cos(mu r)/r can give force factor cos z+z sin z>1. At z=1/4, alternating Taylor bounds give an exact lower bound 1583/1536>1. Such a spectrum is excluded by equation (2), not screened by it. Extra source/boundary or homogeneous modes also are not covered.
- At k=2/11 and Ccrit=148/143>1, the vacuum C=1 satisfies C<Ccrit yet has U=3/2. The quadratic part alone makes U0(Ccrit)-3/2>=15/572>0. Thus extending the small-C floor above one would be false; the source correctly does not do so.
- At k=2/11, nu=100, t=2, the derivative bracket is negative. The exact exp(2) bounds 109/15<exp(2)<1663/225 imply 7<exp(2)<8 and an upper bound -1887817/11011<0 for that bracket. Negative-u monotonicity must not be silently extended to all positive u at arbitrary nu.
- Dropping G_cal positivity in an actual altered domain predicate admitted both zero and negative calibration coefficients and failed its intended checks. The original source-gap witness is retained separately from that damaged-code execution.

## Reused assumptions and physical limitations

I read the preceding physical-turnaround source only to identify the exact theorem premises. Its proof and trajectories were not rerun or newly certified. The imported implication requires a regular closed finite interval; positive Q and positive scalar metric; positive separately conserved Einstein radiation rho_r a_E^4; nonnegative additional density and nonnegative enthalpy; the supplied positive potential; an earlier physical stationary event Z_b=0; and a later Z_f>0,d_f<=1. It supplies positive curvature and the strict product with m=1, or m=2 for its last-Einstein-zero case. Any failure of those hypotheses removes this calibration implication's theorem input. It is not a blanket statement about all past histories.

Equation (1) remains a leading weak, nonrelativistic, locally frozen spatial-principal response. Background variation, masses, mixing, source support and boundary conditions must be controlled. Equation (2) separately assumes the constant positive metric and nonnegative self-adjoint mass operator with the stated forced solution. Neither formula establishes a global static solution, positive mass operator at arbitrary fields, finite-body charge, environmental matching, or a controlled cosmological remainder. The same physical matter units and action constants are essential when comparing different calibration points. Eta is externally supplied and is not numerically bounded here.

The leading ceiling is exact algebra within that approximation. It is not an exact cap on every finite-distance measured force. The energy floor is Einstein-frame scalar energy, not a physical inferred matter density or an observational exclusion. Large early scalar energy is not ruled out by this result. The inequality neither chooses a state nor supplies an environment/history connecting the two events. No thermal/nuclear inputs, abundance likelihood, measured dimensional scale, empirical calibration, initial-state selector, global-completeness result, singularity theorem or completed gravity model is established.

## Sources, recovery and final files

Seven immutable source snapshots are in sources/. Full original paths are in SOURCE_MANIFEST_v1.json. The final source is DERIVATION_v2.md, SHA 22f51459c09d50b17fa38967595cbf3c8d7608e6020c4720f9251648faa42bb8; v1 is preserved with its original hash. No parent source or previous seal was changed.

| Snapshot | SHA-256 |
|---|---|
'''+source_table+r'''

The final files are REPORT_v1.md, MANIFEST_v1.json and RECEIPT_v1.json. The manifest binds every artifact except itself and the receipt; the receipt binds the manifest, report, sources, command/result evidence, original finding and correction correspondence. Original source v1 and every actual execution are preserved. Writes were confined to this new independent_v1 directory. No producer code/results, empirical data, prior independent code, Git/PR mutation, runtime/lock state or formal audit authority was used or changed.
'''
(p/'REPORT_v1.md').write_text(report)
print(json.dumps({'report_bytes':len(report.encode()),'report_sha256':hashlib.sha256(report.encode()).hexdigest(),'finding':'resolved explicit positivity premise in v2','baseline':baseline['counts'],'supplement':supplement['counts'],'mutations_detected':mut['detected']},indent=2))
