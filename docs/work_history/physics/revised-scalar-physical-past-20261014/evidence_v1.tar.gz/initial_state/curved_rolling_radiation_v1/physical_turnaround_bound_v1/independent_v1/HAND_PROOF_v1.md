# Blind proof challenge, before executable checks

Only the frozen derivation, protocol and complete supplied action are inputs.
The action uses -Q K_AB partial phi^A partial phi^B, without a 1/2.
Writing w=K_AB v^A v^B, L=b_A v^A and V=2Q Hv^2 U, metric variation gives
rho_phi=Qw+V and p_phi=Qw-V. Thus

    3Q(H^2+kappa)=Qw+V+rho_r+rho_m,
    Hdot=kappa-w-(rho_m+p_m)/(2Q)-2rho_r/(3Q).

These equations are full-field relations; no invariant-plane restriction is
needed. The supplied diagonal metric and b_u=alpha/F, b_x=b_y=0 give
q=b K^{-1} b=a/J. Since 1-3a=(1-3k)^2/4>0 and s,E>0, J>1 and
0<q<a<1/3 for each fixed 0<k<1/3 and finite scalar chart point. U>=3/2
because every added potential term is nonnegative for nu>0. These facts
belong to the candidate action, not arbitrary scalar-tensor theories.

At the earlier physical stationary event H=-L. Cauchy-Schwarz in the
positive K inner product gives L^2<=qw. If e=qw-L^2>=0,

    3Q kappa-rho_r=V+rho_m+Q(1-3q)w+3Qe>0.

Hence Kc>0, kappa>0 throughout the regular interval, and
0<f_b=rho_r,b/(3Qkappa_b)<1. The strict term V alone suffices when w=0.
No sign of Hdot_J at the initial event is required. Positive regular scale
factors and A>0 keep the two proper-time orders the same.

For the later event take Z>0 and suppose H<=0. Put t=-H/Z>=0. Then
L=Z(1+t). Combining Cauchy-Schwarz with the constraint yields

    (1+t)^2 <= q w/Z^2 < 3q(t^2+d),  d=kappa/Z^2.

The strict inequality uses V+rho_r+rho_m>0. If d<=1, write
q=B/[3(1+B)] with B>0 and d=1-h, h>=0. The necessary difference is

    3q(t^2+d)-(1+t)^2
      =-[1+t^2+2t(1+B)+Bh]/(1+B)<0,

a contradiction. Thus H_f>0. A zero coupling norm is not needed in the
candidate; more generally q=0 would already contradict Z>0 and H<=0.
The near-flat condition is essential to this inference: regular local
action data can have H<0 but Z>0 when d>1.

Chronology is the critical topological step. H is C^1 on a compact interval,
H_f>0, and H has a zero-free positive neighborhood of t_f. If its zero set
is empty, continuity gives H>0 throughout, hence a_f>a_b. Otherwise the
closed nonempty zero set has a greatest member t_*<t_f. On (t_*,t_f],
continuity and absence of another zero force H>0. Therefore a_f>a_*.
The right difference quotients H(t_*+h)/h are positive, so their existing
limit Hdot_* is >=0. Strict positivity is not justified or needed.

This remains valid for an endpoint zero, tangency, degenerate crossing or
infinitely many earlier zeros accumulating at t_*. Compactness and a final
zero-free neighborhood, not isolation or analyticity of every zero, do the
work. Picking the first zero is invalid: the polynomial
H(t)=(t-1)(t-2)(t-4), ending at t_f=41/10, is positive at the end but has
negative portions after its first zero, and integral_1^{41/10} H dt<0.
This is a pure chronology probe, not a claimed action solution.

At the actual last zero the Raychaudhuri equation and nonradiation
enthalpy e_m=rho_m+p_m>=0 give

    kappa_*=w_*+e_m,*/(2Q)+2rho_r,*/(3Q)+Hdot_*,
    3Qkappa_*-2rho_r,*=3Q(w_*+Hdot_*)+3e_m,*/2>=0.

Thus f_*<=1/2. The inequality deliberately allows equality at the zero;
strictness of the final bound instead follows from a_f>a_*. Separate
radiation conservation gives f(t)=D/[3QKc a_E(t)^2], so in the zero-free
case f_f=f_b(a_b/a_f)^2<1; in the last-zero case
f_f=f_*(a_*/a_f)^2<1/2. Physical expansion between the two events is
not assumed: only the sign of H on the final Einstein interval is used.

The physical curvature is Kc/a_J^2, not an Einstein curvature readout with
an unchanged scale factor. With a_J=A a_E, H_J=Z/A, and
rho_r,E=A^4 rho_r,J=C^2 rho_r,J,

    d_J=kappa/Z^2,
    F_r,J=H_J^2/[C rho_r,J/(3Q)]=3QZ^2/rho_r,E,
    d_J F_r,J=3Qkappa/rho_r,E=1/f_f.

The positive d_J is the magnitude of the conventional negative curvature
density parameter for Kc>0. The coefficient Q/C means the squared-Planck
coefficient of R_J/2; it is not automatically a measured local G. Since
d_J,F_r,J>0, d_J<=epsilon<=1 and F_r,J<=1+delta with delta>=0 imply a
product <=epsilon(1+delta). If this upper bound is <=1 it contradicts
the strictly >1 theorem, including the equality threshold. The stronger
>2 result belongs only to the Einstein-zero case.

Potential/density positivity, the field-space norm bound, the regular
finite interval, separate radiation conservation and nonnegative other
enthalpy are real assumptions. In particular a physical stationary event
alone is not a global completeness theorem; present near-flatness plus a
nonzero radiation density supplies no bound F_r,J<=1+delta. No empirical
exclusion, singular origin, measured-G calibration, state selector or
thermal-history calibration follows.

The protocol's phrase “regular closed homogeneous” could already assume
positive spatial curvature. For a clean record of deriving rather than
assuming Kc>0 it should say “regular homogeneous FLRW on a closed finite
time interval.” This is a protocol wording qualification, not a break in
the source proof. It has been reported to the author.

Planned controls: direct stress/normalization and q identities; exact slack
forms for both strict inequalities; rational feasible/infeasible states;
endpoint/tangent/degenerate/multiple-zero chronology; an accumulating-zero
smooth example with its explicit flatness proof; exact radiation scaling;
full conformal readout normalization; a genuine constant-origin closed
radiation solution satisfying the theorem with final d=3/4,F=16; and
actually executed one-equation damaged copies. No producer code, results
or profiles will be accessed.
