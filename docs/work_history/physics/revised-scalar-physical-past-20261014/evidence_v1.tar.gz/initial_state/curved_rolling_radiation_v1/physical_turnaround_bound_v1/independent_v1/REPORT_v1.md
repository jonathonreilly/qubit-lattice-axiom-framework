# Focused blind proof challenge

The conditional conclusion **d_J F_r,J>1** follows from the stated action
and interval assumptions. The chronology argument survives tangencies,
degenerate crossings, a zero at the initial endpoint, and infinitely many
earlier zeros accumulating at the last zero. The stronger **>2** conclusion
is valid in the branch with an Einstein-frame zero. No mathematical repair
to DERIVATION_v1.md was identified in this scope.

The independent run completed **158/0** exact and example controls. Six
actual one-edit damaged checker copies were rejected by the intended
identities. No producer code, grid, profile or result was read or run.
There was no parameter fit, formal audit or authority/status change.

The sole requested wording amendment concerned PROTOCOL_v1.json: “regular
closed homogeneous” could assume positive spatial curvature before the proof
derived it. The author preserved that protocol and supplied v2, specifying
a closed finite time interval instead. The same original checker confirms
that narrow amendment in `source_correspondence_v2/REPORT_v2.md` and its
receipt; the original science run is reused without relabeling or rerunning.

## Frozen source identities

The first three sources were copied before the independent computation.
The later protocol is separately captured. Paths beginning with
physical_turnaround_bound_v1 below are under the campaign's
initial_state/curved_rolling_radiation_v1 directory.

| Source | SHA-256 |
| --- | --- |
| physical_turnaround_bound_v1/DERIVATION_v1.md | 4fbff5f606381a003802eebf8ee723c80627dc8977a567f177820bc5f3b216ad |
| physical_turnaround_bound_v1/PROTOCOL_v1.json | 71a4e6fdf4730b90cac62afa6a4070d73153b38bdcfa73a19a45ccb7df0f59af |
| docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md | 39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000 |
| physical_turnaround_bound_v1/PROTOCOL_v2.json | fb3e40c7bb3cd0b1eb28afc3203f622ba0ff65eeebe951c9c8bd18956aa01b8c |

The canonical note contributes the complete supplied action, not its
separate spatially flat future-confinement theorem. No earlier scientific
check is counted as a new result in this unit. HAND_PROOF_v1.md and
CONTROL_PROTOCOL_v1.json precede execution and contain the blind derivation
and selected controls.

## Action normalization and strict inequalities

Write w=|v|_K^2 and L=b.v. Direct homogeneous lapse/metric variations give
rho_phi=Qw+V and p_phi=Qw-V because the action has no 1/2 before K.
Consequently the Friedmann and Raychaudhuri equations in the source have
the stated coefficients. In particular the radiation term in Hdot is
-2rho_r/(3Q), while the scalar kinetic term is -w.

Using the full three-field metric, b=(alpha/F,0,0) gives q=a/J. The exact
identities 1-3a=(1-3k)^2/4 and 1/3-a=(1-3k)^2/12 prove 0<q<a<1/3 for
fixed 0<k<1/3 at finite regular field values. All extra terms in U are
nonnegative, so V>=3QHv^2>0. Neither statement needs the x=y=0 subspace.
There is no claimed uniform quantitative margin as parameters approach
excluded boundaries.

At the earlier physical stationary event H=-L, introduce the nonnegative
Cauchy slack e=qw-L^2. The exact constraint becomes

    3Qkappa-rho_r=V+rho_m+Q(1-3q)w+3Qe>0.

This proves positive curvature and 0<f_b<1 without assuming a physical
minimum, an Einstein bounce, or nonzero scalar velocity. Potential
positivity makes the inequality strict even at w=0.

At the final event suppose H<=0, let t=-H/Z>=0, and use Z>0. Then
L/Z=1+t. The positive-energy constraint and Cauchy inequality require
(1+t)^2<3q(t^2+d). For q=B/[3(1+B)], B>0, and d=1-h, h>=0, their
difference is exactly

    3q(t^2+d)-(1+t)^2
      =-[1+t^2+2t(1+B)+Bh]/(1+B)<0.

The contradiction proves H_f>0, including exclusion of H_f=0. The
near-flat condition is essential to that sign inference. As a check,
regular constraint-satisfying local action data at the scalar origin can
have Q=1, Hv^2=1/3, k=1/4, b.u_dot=2, w=16, H=-1, Z=1, rho_r=1,
V=1, kappa=5 and d=5. These are an outside-domain local-state probe,
not a history with an asserted earlier stationary event.

## Chronology, tangencies and strict final growth

Regularity supplies H in C^1 on the finite closed interval and positive
scale factors. H_f>0 supplies a zero-free positive final neighborhood.
If there are no zeros, continuity makes H positive throughout and a_f>a_b.
Otherwise the nonempty zero set is closed and compact; its largest member
t_* exists and is strictly earlier than t_f. Absence of further zeros and
continuity force H>0 on (t_*,t_f], so a_f>a_*.

Right difference quotients H(t_*+h)/h are positive. Their existing limit
only has to be nonnegative. Thus Hdot_*>=0 is justified; Hdot_*>0 would
be an unnecessary and invalid strengthening. With nonnegative other
enthalpy e_m=rho_m+p_m, Raychaudhuri yields

    3Qkappa_*-2rho_r,*=3Q(w_*+Hdot_*)+3e_m,*/2>=0.

Hence f_*<=1/2. Equality at this point causes no gap: the strictly positive
integral of H after t_* gives strict final radius growth. Separate
radiation conservation makes f proportional to a_E^-2. The two branches
therefore give f_f<1 and f_f<1/2, respectively.

The check includes endpoint, quadratic tangent, cubic degenerate and
multiple-zero examples. A first-zero substitute is genuinely unsafe:
for H=(t-1)(t-2)(t-4), ending at 41/10, the integral after the first zero
is -266197/120000, whereas after the last zero it is 3803/120000>0.
The first-zero damaged copy consequently fails the radius-ordering check.

Infinitely many earlier zeros are also harmless. The piecewise function
exp(-1/t^2)sin(1/t) for t<0, zero at0, and exp(-1/t^2) for t>0 has zeros
at -1/(n pi) accumulating at0 and a positive right branch. Bounds
exp(-1/t^2)/|t|^m ->0 for m=1,2,3 prove its needed C^1 flatness and
zero derivative. These chronology functions test the mathematical lemma;
they are not represented as solutions of the candidate field equations.

An algebraic negative-enthalpy probe with Q=1,w=0,rho_r=2,e_m=-1,
Hdot=1/6 gives kappa=1 and f=2/3. It deliberately violates a premise and
shows why the half-bound step cannot omit that premise. It is not a
counterexample to the stated theorem or a claimed complete cosmology.

## Physical readouts and empirical boundary

The frame transformations a_J=A a_E, H_J=Z/A and rho_r,E=C^2rho_r,J
give exactly

    d_J=kappa/Z^2,
    F_r,J=3QZ^2/rho_r,E,
    d_J F_r,J=3Qkappa/rho_r,E=1/f_f.

The positive d_J uses the actual physical curvature. In the conventional
Omega_K=-Kc/(a_J^2H_J^2) sign convention it equals -Omega_K for this
positive-curvature result. No sign flip or Einstein-radius substitution
is allowed when interpreting it.

The physical gravitational action contains (Q/(2C))R_J, equivalently
squared-Planck coefficient Q/C in the R/2 convention. Its bare radiation
term is C rho_r,J/(3Q). This is the coefficient used in F_r,J; a measured
Cavendish G has not been derived or substituted. The theorem concerns a
curvature/radiation expansion-law product, not a Jordan effective scalar
energy decomposition.

Because both factors are positive, d_J<=epsilon<=1 and F_r,J<=1+delta
with delta>=0 and epsilon(1+delta)<=1 contradict the strict >1 conclusion,
including the equality threshold. This is conditional on an exact earlier
finite stationary event and the conserved-radiation/regularity/positivity
premises. Asymptotic stationarity only at infinite past time, approximate
stationarity inferred from noisy data, radiation production, or violations
of the stated density/enthalpy conditions are not covered by this proof.
No approximation tolerance for those changes is supplied.

Present near-flatness and nonzero CMB temperature alone do not provide
F_r,J near1. No observed radiation-law history, empirical likelihood,
initial-state selection, global singularity, geodesic completeness,
stability or quantum exclusion follows. The result does not construct
an alternative mechanism when a premise is dropped.

## Controls, actual failures and evidence

The baseline script is check_proof_v1.py, SHA-256
0a6bc593551fc3371ee839f704917d28b0de093099f22cf1e1959d9f2d5546b7.
It completed 158/0 using Python 3.12.8 and SymPy 1.14.0. Exact command,
cwd, UTC times, code hash, exit0 and output hashes are in
independent_proof_run_v1.json. The finite rational control families support
the symbolic identities; they do not replace the handwritten inequalities
or compactness argument.

One exact full-action solution verifies that the event premises are not
empty. At u=x=y=0, Q=Hv=1, Kc=4/3 and rho_r,b=1,

    a_E(t)^2=[2+cosh(2t)]/3

satisfies the full constraint, Raychaudhuri, radiation conservation and
stationary scalar equations. At t_f=acosh(7)/2 it has a_E^2=3,
H^2=16/27,kappa=4/9,rho_r=1/9, d_J=3/4, F_r,J=16 and product12>2.
The chosen k=2/9,nu=4/3 and units are exposed synthetic inputs. This
example satisfies the theorem but does not resemble an F_r,J near1
radiation-law event, and is not an observational fit.

| Actually executed altered copy | Pass / fail | Child exit |
| --- | --- | --- |
| Wrong stationary kinetic subtraction coefficient | 144 / 14 | 1 |
| Omit +1 in L/Z=1+t | 134 / 24 | 1 |
| Choose first Einstein zero | 155 / 3 | 1 |
| Reject zero derivative at a degenerate last zero | 155 / 3 | 1 |
| Reverse the radiation/curvature radius ratio | 136 / 22 | 1 |
| Use rho_r,J=rho_r,E/C | 153 / 5 | 1 |

Every actual damaged file, its result and exact execution record is kept.
There were no unexpected checker, solver or metadata failures in this
unit. The later source/command validation is **94/0 metadata checks**,
not another science run. It confirms all four live/snapshot bindings and
the exact one-edit nature and intended failures of all six damaged files.
The recorder's own successful exit does not conceal the recorded child
exit1 for each damage.

The final narrow protocol confirmation preserves v1, source hashes and
original results. Its statement about timing before the parent's checker
is author-reported; no parent execution or output was inspected to verify
that statement. No source, prior seal, Git state, runtime, settings or
authority was modified. All new files are confined to this independent
unit. This report is bounded independent support for the stated proof,
not a formal audit verdict.
