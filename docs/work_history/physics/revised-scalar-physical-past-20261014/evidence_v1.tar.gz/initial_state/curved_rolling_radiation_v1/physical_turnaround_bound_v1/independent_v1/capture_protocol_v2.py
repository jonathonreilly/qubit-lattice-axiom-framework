"""Capture only the later protocol clarification, without producer access."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,difflib
here=Path(__file__).resolve().parent
root=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
folder=here/'source_correspondence_v2';folder.mkdir(exist_ok=False)
live=here.parent/'PROTOCOL_v2.json';raw=live.read_bytes()
snap=folder/'PROTOCOL_v2.json';snap.write_bytes(raw)
source={'original_path':live.relative_to(root).as_posix(),'snapshot_path':snap.relative_to(here).as_posix(),
        'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
record={'created_utc':datetime.now(timezone.utc).isoformat(),'sources':[source],
        'scope':'narrow later protocol correspondence; original158/0 run retained without rerun'}
(folder/'SOURCE_MANIFEST_v2.json').write_text(json.dumps(record,indent=2)+'\n')
old=(here/'sources/PROTOCOL_v1.json').read_text();new=raw.decode()
diff=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),
 fromfile='frozen_PROTOCOL_v1.json',tofile='frozen_PROTOCOL_v2.json'))
(folder/'INDEPENDENT_v1_v2.diff').write_text(diff)
print(json.dumps(record,indent=2));print(new);print(diff)
