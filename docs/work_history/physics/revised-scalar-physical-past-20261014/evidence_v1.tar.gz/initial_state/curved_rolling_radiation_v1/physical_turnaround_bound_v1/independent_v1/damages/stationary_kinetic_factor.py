"""Independent proof controls. No producer code, profile or result imports."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
import sympy as s

STATIONARY_KINETIC_SUBTRACTION = 1
FINAL_DOT_OFFSET = 1
SELECT_LAST_ZERO = True
ALLOW_ZERO_DERIVATIVE = True
RADIUS_EXPONENT = -2
PHYSICAL_RADIATION_C_POWER = 2

rows=[];evidence={}
def check(name,condition,detail=None):
 rows.append({'name':name,'passed':bool(condition),'detail':detail})
def zero(name,expression):
 result=s.simplify(expression)
 check(name,result==0,str(result))

# Direct homogeneous variations establish normalization independently.
t=s.symbols('t',real=True)
r=s.Function('r')(t); n=s.Function('n')(t)
Q,hv,kc,w,U=s.symbols('Q hv kc w U',positive=True)
Ls=Q*r**3*(w/n-2*hv**2*n*U)
rhoph=-s.diff(Ls,n).subs(n,1)/r**3
pph=s.diff(Ls,r).subs(n,1)/(3*r**2)
zero('action_scalar_density',rhoph-(Q*w+2*Q*hv**2*U))
zero('action_scalar_pressure',pph-(Q*w-2*Q*hv**2*U))
zero('action_scalar_enthalpy',rhoph+pph-2*Q*w)
Lg=-3*Q*r*s.diff(r,t)**2/n+3*Q*kc*n*r
zero('action_lapse_Einstein_coefficient',s.diff(Lg,n).subs(n,1)/r**3
     -3*Q*((s.diff(r,t)/r)**2+kc/r**2))
Elg=(s.diff(s.diff(Lg,s.diff(r,t)),t)-s.diff(Lg,r)).subs({n:1,s.diff(n,t):0})
zero('action_spatial_Einstein_coefficient',Elg/(-3*r**2)
     -Q*(2*s.diff(r,t,2)/r+(s.diff(r,t)/r)**2+kc/r**2))
rho,rm,pm,V,H,kap=s.symbols('rho rm pm V H kap',real=True)
rtot=Q*w+V+rho+rm;ptot=Q*w-V+rho/3+pm
hd=kap-(rtot+ptot)/(2*Q)
zero('Raychaudhuri_normalization',hd-(kap-w-(rm+pm)/(2*Q)-2*rho/(3*Q)))

# q is computed with the supplied full three-field metric, not a memorized
# canonical-scalar coupling convention.
k,u,x,y,nu=s.symbols('k u x y nu',real=True)
a=(1-k)*(1+3*k)/4; alpha=s.sqrt(a)
ss=(1+k)/(k*(1-3*k)); E=s.exp(2*alpha*u);F=1+ss*E
J=1+(1-3*a)*ss*E; Df=1+2*(1+k)*(x*x+y*y)/3
K=s.diag(J/F**2,(1+ss)*4*k/(9*F*Df),(1+ss)*k/(3*F*Df))
bb=s.Matrix([alpha/F,0,0])
qmetric=(bb.T*K.inv()*bb)[0]
zero('full_metric_coupling_norm',qmetric-a/J)
zero('strict_a_margin',s.Rational(1,3)-a-(1-3*k)**2/12)
zero('strict_J_coefficient',1-3*a-(1-3*k)**2/4)
zero('origin_coupling_q_equals_k',(a/J).subs(u,0)-k)
Ufull=s.Rational(3,2)+3*ss*(E-1)**2/(2*F**2)+k*x*x*s.exp(-(1-k)*u/alpha)/2
Ufull+=k*y*y*s.exp(-(1+k)*u/alpha)/3+nu*(1+ss)*u*u/(2*F**2)
zero('origin_potential',Ufull.subs({u:0,x:0,y:0})-s.Rational(3,2))
for field in [u,x,y]:
 zero('origin_force_'+str(field),s.diff(Ufull,field).subs({u:0,x:0,y:0}))

# Stationarity plus the constraint: keep Cauchy slack explicit.
q,L,slack=s.symbols('q L slack',nonnegative=True)
curv=(Q*(w-STATIONARY_KINETIC_SUBTRACTION*L**2)+V+rho+rm)/(3*Q)
constraint=3*Q*(H**2+kap)-Q*w-V-rho-rm
zero('stationary_curvature_from_constraint',constraint.subs({H:-L,kap:curv}))
margin=3*Q*curv-rho
zero('stationary_Cauchy_slack_identity',margin.subs(L**2,q*w-slack)
     -(V+rm+Q*(1-3*q)*w+3*Q*slack))
B=s.symbols('B',positive=True)
qp=B/(3*(1+B))
Vp,rmp,wp,sp=s.symbols('Vp rmp wp sp',nonnegative=True)
strict_margin=s.symbols('Vstrict',positive=True)+rmp+Q*wp/(1+B)+3*Q*sp
check('stationary_strictness_certificate',strict_margin.is_positive)
state_margins=[]
for qq in [s.Rational(1,7),s.Rational(1,4),s.Rational(8,25)]:
 for ww in [s.Integer(0),s.Rational(1,2),s.Integer(5)]:
  for theta in [s.Integer(0),s.Rational(1,2),s.Integer(1)]:
   vals={Q:1,V:s.Rational(3,2),rho:s.Rational(7,3),rm:s.Rational(2,5),w:ww,L:s.sqrt(qq*ww)*theta}
   cv=s.simplify(curv.subs(vals));mr=s.simplify(margin.subs(vals))
   exact_constraint=s.simplify(constraint.subs({H:-L,kap:curv}).subs(vals))
   state_margins.append({'q':str(qq),'w':str(ww),'theta':str(theta),'kappa':str(cv),'margin':str(mr)})
   check('stationary_rational_'+str((qq,ww,theta)),exact_constraint==0 and mr>0)
evidence['stationary_rational_states']=state_margins

# Final sign lemma. The strict positive energy forces a negative expression
# to be positive if H<=0 and d<=1.
T,hh=s.symbols('T hh',nonnegative=True);Z=s.symbols('Z',positive=True)
lf=Z*(T+FINAL_DOT_OFFSET)
zero('final_dot_kinematics',-T*Z+lf-Z)
d=1-hh
contradiction=3*qp*(T*T+d)-(T+FINAL_DOT_OFFSET)**2
expected=-(1+T*T+2*T*(1+B)+B*hh)/(1+B)
zero('final_sign_strict_certificate_identity',contradiction-expected)
check('final_sign_strict_certificate_negative',(-expected).is_positive)
threshold=(T+FINAL_DOT_OFFSET)**2/(3*q)-T*T
zero('source_d_threshold_expansion',threshold-(1/(3*q)+2*T/(3*q)+(1/(3*q)-1)*T*T))
for qq in [s.Rational(1,7),s.Rational(1,4),s.Rational(8,25)]:
 for tt in [s.Integer(0),s.Rational(1,3),s.Integer(2)]:
  for dd in [s.Rational(1,4),s.Rational(9,10),s.Integer(1)]:
   energy_upper=s.simplify(3*(tt*tt+dd)-(tt+FINAL_DOT_OFFSET)**2/qq)
   check('final_nonpositive_H_infeasible_'+str((qq,tt,dd)),energy_upper<0,str(energy_upper))

# A real local supplied-action state outside d<=1 shows why Z>0 alone
# cannot establish H>0. It is not a history or an earlier-stationary solution.
q0=s.simplify((a/J).subs({u:0,k:s.Rational(1,4)}))
w0=4/q0; H0=-s.Integer(1);Z0=s.Integer(1);rho0=s.Integer(1);V0=s.Integer(1)
kap0=(w0+rho0+V0)/3-H0*H0
check('outside_domain_local_action_state',q0==s.Rational(1,4) and kap0==5 and H0<0 and Z0>0)
zero('outside_domain_local_constraint',3*(H0*H0+kap0)-w0-rho0-V0)
check('outside_domain_has_large_curvature',kap0/Z0**2>1)
evidence['outside_nearflat_domain_state']={'Q':'1','Hv_squared':'1/3','k':'1/4','u':'0','x':'0','y':'0',
 'u_dot':'2/b_u','H':'-1','Z':'1','w':'16','rho_r':'1','V':'1','kappa':'5','d':'5',
 'scope':'regular constraint-satisfying local data; no specified earlier physical stationary event'}

# Chronology probes. These functions are not asserted to be action histories.
cases=[('endpoint',t,[s.Integer(0)],s.Integer(1)),
 ('tangency',(t-1)**2,[s.Integer(1)],s.Integer(2)),
 ('degenerate_crossing',(t-1)**3,[s.Integer(1)],s.Integer(2)),
 ('multiple_zeros',(t-1)*(t-2)*(t-4),[s.Integer(1),s.Integer(2),s.Integer(4)],s.Rational(41,10))]
chrono=[]
for name,expr,zeros,tf in cases:
 selected=max(zeros) if SELECT_LAST_ZERO else min(zeros)
 deriv=s.diff(expr,t).subs(t,selected)
 allowed=deriv>=0 if ALLOW_ZERO_DERIVATIVE else deriv>0
 check('chronology_final_positive_'+name,expr.subs(t,tf)>0)
 check('chronology_selected_is_last_'+name,selected==max(zeros))
 check('chronology_right_derivative_allowed_'+name,allowed,str(deriv))
 cuts=[selected]+[z for z in zeros if selected<z<tf]+[tf]
 mids=[(left+right)/2 for left,right in zip(cuts[:-1],cuts[1:])]
 check('chronology_final_interval_positive_'+name,all(expr.subs(t,m)>0 for m in mids))
 integral=s.integrate(expr,(t,selected,tf))
 check('chronology_final_radius_grows_'+name,integral>0,str(integral))
 chrono.append({'name':name,'selected_zero':str(selected),'Hdot_at_zero':str(deriv),
                'log_radius_ratio':str(integral),'full_action_solution_claim':False})
poly=(t-1)*(t-2)*(t-4)
first_integral=s.integrate(poly,(t,1,s.Rational(41,10)))
check('first_zero_counterexample_radius_shrinks',first_integral<0,str(first_integral))
check('no_zero_sign_and_radius',all((1+t).subs(t,z)>0 for z in [0,s.Rational(1,2),1])
      and s.integrate(1+t,(t,0,1))>0)
# Accumulating zeros: exp(-1/t^2) sin(1/t) for t<0, zero at0,
# and exp(-1/t^2)>0 for t>0. These explicit bounds prove C^1 flatness.
xx=s.symbols('xx',positive=True)
for power in [1,2,3]:
 zero('accumulating_zero_flat_bound_'+str(power),s.limit(s.exp(-1/xx**2)/xx**power,xx,0,dir='+'))
for integer in [1,2,7,23]:
 zero('accumulating_exact_zero_'+str(integer),s.sin(1/(-1/(integer*s.pi))))
flat_derivative=s.Integer(0)
check('accumulating_last_zero_derivative_allowed',
      flat_derivative>=0 if ALLOW_ZERO_DERIVATIVE else flat_derivative>0)
check('accumulating_positive_right_branch',s.exp(-1/xx**2).is_positive)
evidence['chronology_probes']=chrono
evidence['first_zero_counterexample_integral']=str(first_integral)

# At the last zero, enthalpy and a nonnegative derivative give f<=1/2.
enthalpy,hdot=s.symbols('enthalpy hdot',nonnegative=True)
curvzero=w+enthalpy/(2*Q)+2*rho/(3*Q)+hdot
zero('last_zero_raychaudhuri_balance',curvzero-w-enthalpy/(2*Q)-2*rho/(3*Q)-hdot)
zero('last_zero_f_half_margin',3*Q*curvzero-2*rho-(3*Q*(w+hdot)+3*enthalpy/2))
check('last_zero_f_half_sign',(3*Q*(w+hdot)+3*enthalpy/2).is_nonnegative)
# Without nonnegative enthalpy the half-bound step really can fail.
violating={Q:1,w:0,rho:2,enthalpy:-1,hdot:s.Rational(1,6)}
negative_enthalpy_kappa=s.simplify(curvzero.subs(violating))
check('negative_enthalpy_really_breaks_half_bound',negative_enthalpy_kappa==1 and s.Rational(2,3)>s.Rational(1,2))
evidence['negative_enthalpy_step_probe']={'Q':'1','w':'0','rho_r':'2','enthalpy':'-1',
 'Hdot':'1/6','kappa':'1','f':'2/3','scope':'violates an explicit premise; algebraic Raychaudhuri-step probe only'}

# Radiation charge and curvature scaling; the direction of the radius ratio
# is essential even when endpoint identities happen to look plausible.
ab,af,Kc,charge,fb,g=s.symbols('ab af Kc charge fb g',positive=True)
f_at=lambda aa:charge/(3*Q*Kc*aa**2)
candidate_scale=f_at(ab)*(af/ab)**RADIUS_EXPONENT
zero('radiation_curvature_scaling',candidate_scale-f_at(af))
zero('radiation_curvature_growth_factor',candidate_scale.subs(af,g*ab)/f_at(ab)-g**(-2))
for ff in [s.Rational(1,5),s.Rational(1,2),s.Rational(9,10)]:
 for gg in [s.Rational(5,4),s.Integer(2),s.Integer(3)]:
  final=ff*gg**RADIUS_EXPONENT
  check('radiation_fraction_decreases_'+str((ff,gg)),0<final<ff,str(final))
  check('final_product_exceeds_one_'+str((ff,gg)),1/final>1,str(1/final))
  if ff<=s.Rational(1,2):check('Einstein_zero_product_exceeds_two_'+str((ff,gg)),1/final>2,str(1/final))

# Physical curvature and bare-coupling radiation readout.
C,ae,rr=s.symbols('C ae rr',positive=True)
aj=s.sqrt(C)*ae;HJ=Z/s.sqrt(C);rj=rr/C**PHYSICAL_RADIATION_C_POWER
dj=Kc/(aj**2*HJ**2);fr=HJ**2/(C*rj/(3*Q))
zero('physical_curvature_ratio',dj-Kc/(ae**2*Z**2))
zero('physical_radiation_readout',fr-3*Q*Z**2/rr)
zero('physical_product',dj*fr-3*Q*Kc/(ae**2*rr))
zero('radiation_charge_frame_invariance',rj*aj**4-rr*ae**4)
zero('physical_Ricci_prefactor',(Q/2)*C**(-2)*C-Q/(2*C))
for cc in [s.Rational(1,3),s.Integer(2)]:
 check('nontrivial_C_product_'+str(cc),s.simplify((dj*fr-3*Q*Kc/(ae**2*rr)).subs(C,cc))==0)
for eps,delta in [(s.Rational(1,100),s.Integer(1)),(s.Rational(1,2),s.Integer(1)),(s.Integer(1),s.Integer(0))]:
 check('nearflat_upper_threshold_'+str((eps,delta)),eps*(1+delta)<=1)

# Exact nonvacuous full-action example: fields are at the stationary origin;
# radiation is trace-free, and both frames coincide. This is synthetic.
X=(2+s.cosh(2*t))/3
Hex=s.diff(X,t)/(2*X);kapex=4/(3*X);rex=1/X**2
def hyperzero(name,expr):zero(name,expr.rewrite(s.exp))
hyperzero('exact_closed_solution_constraint',3*(Hex**2+kapex)-3-rex)
hyperzero('exact_closed_solution_Raychaudhuri',s.diff(Hex,t)-kapex+2*rex/3)
hyperzero('exact_closed_solution_radiation',s.diff(rex,t)+4*Hex*rex)
zero('exact_closed_solution_stationary_event',Hex.subs(t,0))
zero('exact_closed_solution_bounce_acceleration',s.diff(Hex,t).subs(t,0)-s.Rational(2,3))
tf=s.acosh(7)/2
xf=s.simplify(X.subs(t,tf));hf2=s.simplify((Hex**2).subs(t,tf))
kf=s.simplify(kapex.subs(t,tf));rf=s.simplify(rex.subs(t,tf))
df=s.simplify(kf/hf2);ff=s.simplify(3*hf2/rf)
zero('exact_closed_solution_final_radius',xf-3)
zero('exact_closed_solution_final_d',df-s.Rational(3,4))
zero('exact_closed_solution_final_F',ff-16)
check('exact_closed_solution_strong_bound',df<=1 and df*ff==12 and df*ff>2)
evidence['exact_full_action_example']={'k':'2/9','nu':'4/3','Q':'1','Hv':'1','fields':'u=x=y=0',
 't_final':'acosh(7)/2','a_final_squared':str(xf),'H_final_squared':str(hf2),
 'kappa_final':str(kf),'rho_r_final':str(rf),'d_J':str(df),'F_r,J':str(ff),'product':str(df*ff),
 'no_empirical_calibration':True}

result={'created_utc':datetime.now(timezone.utc).isoformat(),
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'pass':sum(z['passed'] for z in rows),'fail':sum(not z['passed'] for z in rows),
 'checks':rows,'evidence':evidence,'versions':{'python':sys.version,'sympy':s.__version__},
 'scope':'blind exact proof controls; arbitrary chronology probes explicitly distinguished from full-action solutions',
 'producer_access':False}
out=Path(sys.argv[1]);assert not out.exists()
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pass':result['pass'],'fail':result['fail'],
 'failed_checks':[z for z in rows if not z['passed']],
 'chronology':chrono,'first_zero_integral':str(first_integral),
 'exact_full_action_example':evidence['exact_full_action_example']},indent=2))
sys.exit(1 if result['fail'] else 0)
