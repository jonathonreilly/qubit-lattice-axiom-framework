"""Create one-edit damaged copies with required detection controls frozen first."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
here=Path(__file__).resolve().parent
original=here/'check_proof_v1.py';raw=original.read_text()
folder=here/'damages';folder.mkdir(exist_ok=False)
cases=[
 ('stationary_kinetic_factor','STATIONARY_KINETIC_SUBTRACTION = 3','STATIONARY_KINETIC_SUBTRACTION = 1','stationary_curvature_from_constraint'),
 ('lost_final_dot_offset','FINAL_DOT_OFFSET = 1','FINAL_DOT_OFFSET = 0','final_dot_kinematics'),
 ('first_instead_of_last_zero','SELECT_LAST_ZERO = True','SELECT_LAST_ZERO = False','chronology_final_radius_grows_multiple_zeros'),
 ('reject_degenerate_zero','ALLOW_ZERO_DERIVATIVE = True','ALLOW_ZERO_DERIVATIVE = False','chronology_right_derivative_allowed_tangency'),
 ('reversed_radius_ratio','RADIUS_EXPONENT = -2','RADIUS_EXPONENT = 2','radiation_curvature_scaling'),
 ('wrong_physical_density','PHYSICAL_RADIATION_C_POWER = 2','PHYSICAL_RADIATION_C_POWER = 1','physical_product')]
rows=[]
for name,old,new,required in cases:
 assert raw.count(old+'\n')==1
 path=folder/(name+'.py');path.write_text(raw.replace(old+'\n',new+'\n'))
 rows.append({'name':name,'path':path.relative_to(here).as_posix(),
  'original_line':old,'damaged_line':new,'required_failed_check':required,
  'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,'expected_child_exit':1})
result={'created_utc':datetime.now(timezone.utc).isoformat(),
 'original_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'cases':rows,
 'execution_not_yet_claimed':True}
(here/'DAMAGE_PLAN_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
