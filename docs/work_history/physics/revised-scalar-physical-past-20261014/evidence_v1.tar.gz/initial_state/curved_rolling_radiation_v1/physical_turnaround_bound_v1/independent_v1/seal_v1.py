"""Seal source, exact-command and complete artifact identities; then verify."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
here=Path(__file__).resolve().parent
root=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
now=datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bind(p):return {'path':p.relative_to(here).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)}
def create(p,obj):
 assert not p.exists(),str(p)
 p.write_text(json.dumps(obj,indent=2)+'\n')
assert not (here/'MANIFEST_v1.json').exists()
assert not (here/'RECEIPT_v1.json').exists()
val=json.loads((here/'EVIDENCE_VALIDATION_v1.json').read_text())
assert val['pass']==94 and val['fail']==0
result=json.loads((here/'independent_proof_results_v1.json').read_text())
assert result['pass']==158 and result['fail']==0
for row in val['source_pairs']:
 assert sha(root/row['original_path'])==row['sha256']==sha(here/row['snapshot_path'])
commands=[]
for p in sorted(here.glob('*run*.json')):
 record=json.loads(p.read_text())
 if 'command' not in record:continue
 assert sha(Path(record['command'][2]))==record['script_sha256']
 for kind in ['stdout','stderr']:
  path=here/record[kind]['path']
  assert sha(path)==record[kind]['sha256'] and path.stat().st_size==record[kind]['bytes']
 assert record['exit_code']==(1 if p.name.startswith('damage_') else 0)
 assert not record['timed_out']
 commands.append({'record':bind(p),**record})
sealcmd={'argv':[sys.executable,'-B','seal_v1.py'],'cwd':str(here),'script_sha256':sha(Path(__file__))}
create(here/'COMMANDS_v1.json',{'created_utc':now,'recorded_child_commands':commands,
 'scope':'all science, damage and metadata script executions; ordinary reads/copies remain in tool history',
 'wrapper_behavior':'wrapper preserves actual child exit; damaged child exit1 is authoritative',
 'seal_command':sealcmd})
sub=here/'source_correspondence_v2'
create(sub/'RECEIPT_v2.json',{'created_utc':now,'type':'affected_protocol_correspondence',
 'original_reviewer':'/root/local_response_check',
 'original_reviewer_confirmation':'Same blind checker confirms closed finite interval wording, unchanged remaining premises and original derivation; positive curvature is derived.',
 'report':bind(sub/'REPORT_v2.md'),
 'source_pairs':val['source_pairs'],
 'reused_independent_science':{'pass':158,'fail':0,'result':bind(here/'independent_proof_results_v1.json'),
  'command':bind(here/'independent_proof_run_v1.json'),'new_science_run':False},
 'metadata':bind(here/'EVIDENCE_VALIDATION_v1.json'),
 'limitation':'Parent checker execution timing is author-reported and not independently inspected; no parent code/profile/results access.'})
inventory=[]
for p in sorted(here.rglob('*')):
 assert not p.is_symlink(),str(p)
 if p.is_file():inventory.append(bind(p))
create(here/'MANIFEST_v1.json',{'created_utc':now,'unit':here.relative_to(root).as_posix(),
 'artifact_count':len(inventory),'artifacts':inventory,'source_pairs':val['source_pairs'],
 'excluded_seal_files':['MANIFEST_v1.json','RECEIPT_v1.json'],'immutable_after_seal':True})
receipt={'created_utc':now,'type':'focused_blind_mathematical_check',
 'checker':'/root/local_response_check','direct_scientific_author':'/root','unit':str(here),
 'report':bind(here/'REPORT_v1.md'),'manifest':bind(here/'MANIFEST_v1.json'),
 'artifact_count':len(inventory),'live_source_pair_count':len(val['source_pairs']),
 'source_pairs':val['source_pairs'],
 'science':{'pass':158,'fail':0,'result':bind(here/'independent_proof_results_v1.json'),
  'command':bind(here/'independent_proof_run_v1.json'),'producer_access':False,'observational_fit':False},
 'actual_damaged_copies':val['actual_damages'],'unexpected_failures':[],
 'metadata':{'pass':94,'fail':0,'result':bind(here/'EVIDENCE_VALIDATION_v1.json')},
 'original_reviewer_final_protocol_confirmation':bind(sub/'RECEIPT_v2.json'),
 'commands':bind(here/'COMMANDS_v1.json'),'seal_command':sealcmd,
 'bounded_conclusion':'The stated conditional d_J F_r,J>1 proof holds, with >2 in the Einstein-zero branch; last-zero reasoning includes tangencies, degenerate and accumulating zeros. Protocolv2 removes ambiguous spatial-closure wording. No source proof equation correction identified.',
 'limitations':['Supplied classical action, finite regular interval and exact finite stationary event remain premises.',
  'Separate radiation conservation and density/enthalpy positivity are substantive.',
  'Bare Q/C is not identified with measured local gravity.',
  'No empirical exclusion, thermal calibration, global singularity/completeness, state selection or stability claim.',
  'Abstract chronology probes are not asserted to be full-action solutions.',
  'No parent code/results, prior-seal modification, Git/runtime/source/authority mutation or formal audit.'],
 'immutable_after_seal':True}
create(here/'RECEIPT_v1.json',receipt)
for row in inventory:
 p=here/row['path'];assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes']
actual={p.relative_to(here).as_posix() for p in here.rglob('*') if p.is_file()}
assert actual=={r['path'] for r in inventory}|{'MANIFEST_v1.json','RECEIPT_v1.json'}
assert sha(here/'MANIFEST_v1.json')==receipt['manifest']['sha256']
for row in val['source_pairs']:
 assert sha(root/row['original_path'])==row['sha256']==sha(here/row['snapshot_path'])
print(json.dumps({'sealed':True,'artifact_count':len(inventory),'source_pairs':len(val['source_pairs']),
 'report':bind(here/'REPORT_v1.md'),'manifest':bind(here/'MANIFEST_v1.json'),
 'receipt':bind(here/'RECEIPT_v1.json'),'protocol_receipt':bind(sub/'RECEIPT_v2.json'),
 'post_seal_inventory_verified':True,'finished_utc':datetime.now(timezone.utc).isoformat()},indent=2))
