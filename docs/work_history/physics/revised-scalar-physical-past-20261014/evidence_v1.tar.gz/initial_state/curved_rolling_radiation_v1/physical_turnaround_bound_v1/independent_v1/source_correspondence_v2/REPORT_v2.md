# Original-checker protocol confirmation

The same checker, /root/local_response_check, read the later PROTOCOL_v2.json
and independently compared it with the frozen v1. Its first premise now
specifies a regular homogeneous classical action on a closed finite time
interval. Positive spatial curvature remains derived from the earlier
physical stationary event; it is not silently assumed by “closed.”

All remaining premises, target, limits, motivation and supplied-action hash
are unchanged. The other differences are the version timestamp and the
explicit supersedes/qualification fields. The source derivation remains
byte-identical, SHA-256
4fbff5f606381a003802eebf8ee723c80627dc8977a567f177820bc5f3b216ad.
The final protocol SHA-256 is
fb3e40c7bb3cd0b1eb28afc3203f622ba0ff65eeebe951c9c8bd18956aa01b8c.

The original blind hand proof never assumed spatial closure. Its original
158/0 controls are reused with their original identities and no science
rerun. The six actual damaged-copy results remain separate evidence.
EVIDENCE_VALIDATION_v1.json confirms this affected-source correspondence and
execution metadata with 94/0 checks, not additional science results.

The author's statement that v2 preceded the parent's checker is retained
as author-reported timing; parent code and execution evidence were excluded
from the blind task. This confirmation concerns the mathematical premise
and byte correspondence only. No status promotion or formal audit follows.
