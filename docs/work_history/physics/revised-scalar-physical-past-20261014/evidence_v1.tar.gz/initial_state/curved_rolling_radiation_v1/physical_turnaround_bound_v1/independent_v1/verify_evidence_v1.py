"""Validate source, protocol correspondence and actual execution provenance."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
here=Path(__file__).resolve().parent
root=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
rows=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(name,ok,detail=None):rows.append({'name':name,'passed':bool(ok),'detail':detail})
pairs=[]
for name in ['SOURCE_MANIFEST_v1.json','source_correspondence_v2/SOURCE_MANIFEST_v2.json']:
 for r in json.loads((here/name).read_text())['sources']:
  check('live_source_'+r['original_path'],sha(root/r['original_path'])==r['sha256'])
  check('snapshot_'+r['snapshot_path'],sha(here/r['snapshot_path'])==r['sha256']
        and (here/r['snapshot_path']).stat().st_size==r['bytes'])
  pairs.append(r)
old=json.loads((here/'sources/PROTOCOL_v1.json').read_text())
new=json.loads((here/'source_correspondence_v2/PROTOCOL_v2.json').read_text())
check('protocol_expected_final_hash',sha(here/'source_correspondence_v2/PROTOCOL_v2.json')=='fb3e40c7bb3cd0b1eb28afc3203f622ba0ff65eeebe951c9c8bd18956aa01b8c')
check('protocol_exact_first_premise',new['premises'][0]=='regular homogeneous classical candidate action on a closed finite time interval, fixed Q')
check('protocol_remaining_premises_identical',new['premises'][1:]==old['premises'][1:])
for key in set(old)-{'at','premises'}:
 check('protocol_unchanged_'+key,new[key]==old[key])
check('protocol_only_declared_added_keys',set(new)-set(old)=={'supersedes','qualification'})
check('protocol_preserves_original',new['supersedes']=='PROTOCOL_v1.json')
check('protocol_curvature_derived','positive spatial curvature is a derived conclusion, not an initial premise' in new['qualification'])
check('protocol_full_action_binding',new['source_action_sha256']==sha(here/'sources/FULL_ACTION_CANONICAL_NOTE.md'))
check('derivation_original_hash',sha(here/'sources/DERIVATION_v1.md')=='4fbff5f606381a003802eebf8ee723c80627dc8977a567f177820bc5f3b216ad')
original=here/'check_proof_v1.py'
result=json.loads((here/'independent_proof_results_v1.json').read_text())
check('baseline_actual158_0',result['pass']==158 and result['fail']==0)
check('baseline_code_binding',result['script_sha256']==sha(original))
plan=json.loads((here/'DAMAGE_PLAN_v1.json').read_text())
check('damage_original_code_binding',plan['original_sha256']==sha(original))
damages=[]
for r in plan['cases']:
 p=here/r['path'];name=r['name']
 check('damage_exact_one_edit_'+name,p.read_text()==original.read_text().replace(r['original_line']+'\n',r['damaged_line']+'\n'))
 check('damage_script_hash_'+name,sha(p)==r['sha256'])
 res=json.loads((here/'damages'/(name+'_results_v1.json')).read_text())
 run=json.loads((here/('damage_'+name+'_run_v1.json')).read_text())
 failed=[q['name'] for q in res['checks'] if not q['passed']]
 check('damage_actual_intended_rejection_'+name,run['exit_code']==1 and res['fail']>0 and r['required_failed_check'] in failed)
 check('damage_result_binding_'+name,res['script_sha256']==sha(p))
 damages.append({'name':name,'pass':res['pass'],'fail':res['fail'],'exit_code':run['exit_code'],
  'required_failed_check':r['required_failed_check'],'failed_checks':failed,
  'script':r['path'],'result':'damages/'+name+'_results_v1.json','command_record':'damage_'+name+'_run_v1.json'})
commands=[]
for p in sorted(here.glob('*run*.json')):
 rec=json.loads(p.read_text())
 if 'command' not in rec:continue
 target=Path(rec['command'][2])
 check('command_script_'+p.name,target.is_relative_to(here) and sha(target)==rec['script_sha256'])
 for kind in ['stdout','stderr']:
  output=here/rec[kind]['path']
  check('command_'+kind+'_'+p.name,sha(output)==rec[kind]['sha256'] and output.stat().st_size==rec[kind]['bytes'])
 check('command_exit_'+p.name,rec['exit_code']==(1 if p.name.startswith('damage_') else 0))
 check('command_no_timeout_'+p.name,not rec['timed_out'])
 commands.append({'record':p.name,**rec})
out={'created_utc':datetime.now(timezone.utc).isoformat(),
 'scope':'metadata and narrow protocol confirmation, not a science rerun',
 'pass':sum(r['passed'] for r in rows),'fail':sum(not r['passed'] for r in rows),'checks':rows,
 'source_pairs':pairs,'commands':commands,'actual_damages':damages,
 'unexpected_failures':[],'producer_code_profiles_results_accessed':False,
 'author_parent_execution_order_claim':'not independently verified; parent execution excluded from blind scope'}
target=here/'EVIDENCE_VALIDATION_v1.json';assert not target.exists()
target.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'pass':out['pass'],'fail':out['fail'],'source_pairs':len(pairs),
 'damages':[{k:r[k] for k in ['name','pass','fail','exit_code']} for r in damages],
 'failed_metadata':[r for r in rows if not r['passed']]},indent=2))
sys.exit(1 if out['fail'] else 0)
