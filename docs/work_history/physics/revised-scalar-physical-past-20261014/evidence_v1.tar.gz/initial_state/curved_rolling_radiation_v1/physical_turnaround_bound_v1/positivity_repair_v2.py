from pathlib import Path
import json,sys,sympy as S
ell,eta=S.symbols("ell eta",positive=True);eta0=S.symbols("eta0",nonnegative=True)
l=1+ell
checks=[]
for name,e in [("no_zero_case_product_strict",l*l*(1+eta)-1),("last_zero_case_product_stronger",l*l*(2+eta0)-2)]:
 expanded=S.expand(e);checks.append({"name":name,"original_query":str(e.is_positive),"exact_expansion":str(expanded),"positive":expanded.is_positive is True})
r={"passed":sum(x["positive"] for x in checks),"failed":sum(not x["positive"] for x in checks),"checks":checks,"scope":"Affected-only exact positivity check. Original38/2 retained: two unevaluated SymPy predicates, not counterexamples. Remaining38 checks reused; no full rerun."}
out=Path(sys.argv[1]);assert not out.exists();out.write_text(json.dumps(r,indent=2)+"\n");print(json.dumps(r));raise SystemExit(1 if r["failed"] else 0)
