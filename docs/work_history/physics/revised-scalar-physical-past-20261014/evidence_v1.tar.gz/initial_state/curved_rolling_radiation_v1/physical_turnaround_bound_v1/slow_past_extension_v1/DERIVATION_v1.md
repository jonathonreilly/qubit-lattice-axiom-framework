# From a slow physical expansion to a bounded-past obstruction

Direct candidate extension by /root. The earlier physical-turnaround proof
requires an exact finite event Z=0. Here that condition is replaced by an
explicit inequality. The supplied action itself bounds the coupling norm
uniformly at fixed k, so a physical Hubble rate tending to zero also enters
the forbidden class. No new initial-state selector is introduced.

Use the complete action and definitions from physical_turnaround_bound_v1:
H=H_E, w=|dot(phi)|_K^2, L=b.dot(phi), q=|b|_K^2<1/3, Z=H+L,
C=A^2, H_J=Z/A, kappa=Kc/a_E^2, V=2Q H_v^2 U>=3Q H_v^2>0.
Positive radiation is separately conserved and other density/enthalpy is
nonnegative. All connecting finite time intervals must be regular. Parameters
0<k<1/3,nu>0,Q>0,H_v>0 are fixed; no uniform endpoint-parameter limit is used.

## Exact local completion and a sufficient slow-event condition

Decompose v into its component along b^sharp and its K-orthogonal complement.
Since q>0, w=L^2/q+w_perp with w_perp>=0. The constraint gives

    3Q kappa-rho_r = V+rho_m+Q[w-3(Z-L)^2],
    w-3(Z-L)^2
      =w_perp+(1-3q)/q [L+3qZ/(1-3q)]^2
        -3Z^2/(1-3q).                               (1)

Thus an earlier event obeying

    Z_b^2 < (1-3q_b)(V_b+rho_m,b)/(3Q)                (2)

necessarily has 3Q kappa_b>rho_r,b>0. It has positive curvature and
f_b=rho_r,b/(3Q kappa_b)<1, exactly the intermediate conclusion needed
by the physical-turnaround chronology proof. No actual zero, minimum,
Einstein bounce, or sign of H_J at this earlier event is required.

If a later event has Z_f>0 and d_f=kappa_f/Z_f^2<=1, the original endpoint
argument still proves H_E,f>0. The same no-zero/last-zero split therefore
gives f_f<1 and

    d_f F_bare,f > 1,                                (3)

with >2 in the last-Einstein-zero branch. All original conservation,
positivity and regularity premises remain essential. Condition (2) is
sufficient, not necessary, and is not an observational error bar on H.

## An exact action-wide physical slow-rate threshold

Let a=(1-k)(1+3k)/4, beta=1-3a=(1-3k)^2/4>0 and
Cmax=(1+s)/s, s=(1+k)/(k(1-3k)). At any finite field point, 0<C<Cmax and

    q=a(1-C/Cmax)/(1-3a C/Cmax),
    (1-3q)/C=beta/[C(1-3a C/Cmax)].                  (4)

Completing this scalar quadratic gives

    Cmax/(12a)-C(1-3a C/Cmax)
       =(3a/Cmax)[C-Cmax/(6a)]^2 >=0.

The denominator is positive on the action domain. Therefore

    (1-3q)/C >= 12a beta/Cmax,
    h_* = H_v sqrt(12a beta/Cmax) > 0.               (5)

The coupling-only minimum occurs at C=Cmax/(6a), inside the allowed interval
because a>1/4. This does not minimize the full potential-dependent threshold
in (2), or select that field value. It is an exact conservative uniform bound.

Since Z^2=C H_J^2 and V>=3Q H_v^2, any finite earlier event with

    |H_J| < h_*                                      (6)

satisfies (2). A sequence of physical Hubble rates tending to zero along
an arbitrarily remote past therefore contains a sufficient finite event;
there is no need to include the infinite endpoint in a compactness argument.
This also works when C tends toward a boundary, provided every finite
connecting segment is regular and the parameters stay fixed.

## A bounded-past duration corollary

Suppose a later event satisfies the exact symbolic target

    H_J,f>0, d_f<=1, d_f F_bare,f<=1.                (7)

Then no earlier finite event in a connected regular interval satisfying the
same matter/action premises can obey (6), because it would contradict (7).
Hence |H_J|>=h_* throughout that earlier interval. Continuity and H_J,f>0
force the positive sign, including near the final event; otherwise a zero
or an open neighborhood of small magnitude would occur. Thus

    H_J >= h_*,
    a_J(t_J)<=a_J,f exp[-h_*(t_J,f-t_J)].             (8)

For any additionally required lower physical radius a_J>=a_min>0,

    t_J,f-t_J <= log(a_J,f/a_min)/h_*.               (9)

An unbounded past proper-time interval with a positive lower physical scale
factor is therefore impossible under (7) and these hypotheses. If instead
one postulates an upper bound rho_r,J<=rho_max>=rho_r,J,f, separate physical
radiation conservation rho_r,J a_J^4=constant gives the equivalent duration

    t_J,f-t_J <= log(rho_max/rho_r,J,f)/(4h_*).        (10)

The density/radius cutoffs are explicit additional conditions, not derived
fundamental scales. If the physical past duration is unbounded with no such
cutoff, (8) forces a_J to zero and rho_r,J to infinity in that limit. This
is not a proof of divergent physical curvature, finite-time singularity,
spacetime inextendibility or geodesic incompleteness: C may vary strongly,
and no Einstein energy is silently equated with Jordan effective energy.

The bare target (7) must be distinguished from a measured local-gravity
radiation law. The separate gravity_calibration_v1 analysis supplies only
conditional conversion inequalities, not a data likelihood. Present CMB
radiation and present near-flatness alone are not (7). Neither changing a
potential within the stated positive lower bound nor choosing a special
radiation charge repairs the obstruction; production/exchange, a changed
action, positivity failures or a different empirical target leave its domain.
