from pathlib import Path
import sys,json,hashlib,itertools
import sympy as S
out=Path(sys.argv[1]);assert not out.exists();rows=[]
def ck(n,b,d=None):rows.append(dict(name=n,passed=bool(b),detail=d))
def eq(n,e):v=S.factor(S.simplify(e));ck(n,v==0,str(v))
q,Q,C,Cmax,a,Hv,rho,V=S.symbols('q Q C Cmax a Hv rho V',positive=True)
L,Z=S.symbols('L Z',real=True);wp,rm=S.symbols('wp rm',nonnegative=True)
w=L*L/q+wp;H=Z-L
completed=wp+(1-3*q)/q*(L+3*q*Z/(1-3*q))**2-3*Z*Z/(1-3*q)
eq('kinetic_square_completion',w-3*H*H-completed)
kap=(Q*w+V+rho+rm)/(3*Q)-H*H
eq('slow_event_curvature_gap',3*Q*kap-rho-(V+rm+Q*completed))
# Exact minimum over the velocity component; orthogonal motion increases the gap.
Lmin=-3*q*Z/(1-3*q)
eq('stationary_velocity_minimum',S.diff(completed,L).subs(L,Lmin))
eq('velocity_minimum_value',completed.subs(L,Lmin)-(wp-3*Z*Z/(1-3*q)))
qq,slack=S.symbols('qq slack',positive=True);qpos=1/(3*(1+qq))
ck('positive_completed_square_coefficient',S.factor(((1-3*q)/q).subs(q,qpos)).is_positive)
VV=3*Q*Z*Z/(1-3*q)+slack
eq('strict_slow_gap_exact_certificate',VV+rm+Q*completed-(slack+rm+Q*wp+Q*(1-3*q)/q*(L+3*q*Z/(1-3*q))**2))
ck('strict_slow_gap_positive_remainder',(slack+rm+Q*wp).is_positive is True)
# Derive q(C) from the actual field-dependent action, not a free q selector.
k,E=S.symbols('k E',positive=True);aa=(1-k)*(1+3*k)/4;ss=(1+k)/(k*(1-3*k));FF=1+ss*E;JJ=1+(1-3*aa)*ss*E;CC=(1+ss)*E/FF;CM=(1+ss)/ss
qqC=a*(1-C/Cmax)/(1-3*a*C/Cmax);eq('action_norm_as_coupling',qqC.subs({a:aa,C:CC,Cmax:CM})-aa/JJ)
ratio=(1-3*a)/(C*(1-3*a*C/Cmax))
eq('norm_to_physical_clock_ratio',(1-3*qqC)/C-ratio)
cap=Cmax/(12*a)
eq('quadratic_completion_for_denominator',cap-C*(1-3*a*C/Cmax)-3*a/Cmax*(C-Cmax/(6*a))**2)
Cstar=Cmax/(6*a)
eq('ratio_minimum_point_derivative',S.diff(ratio,C).subs(C,Cstar))
eq('ratio_at_minimum',ratio.subs(C,Cstar)-12*a*(1-3*a)/Cmax)
eq('positive_margin_k',1-3*aa-(1-3*k)**2/4)
z=S.symbols('z',positive=True);ap=S.Rational(1,4)+z/(12*(1+z))
ck('minimizer_inside_Cmax',S.factor(6*ap-1).is_positive)
ck('positive_uniform_margin',S.factor(1-3*ap).is_positive)
# Full expression equality proving nonnegative excess; positivity in stated domain.
eq('ratio_minus_uniform_floor',ratio-12*a*(1-3*a)/Cmax-((1-3*a)*(Cmax-6*a*C)**2/(Cmax*C*(Cmax-3*a*C))))
hj=S.symbols('HJ',real=True);hstar2=Hv*Hv*12*a*(1-3*a)/Cmax
eq("threshold_is_exact_coupling_minimum",hstar2/Hv**2-ratio.subs(C,Cstar))
# Sufficient trigger from V>=3QHv² and C: compare squared quantities exactly.
rr,ee=S.symbols('rr ee',positive=True)
trigger_margin=(1-3*q)*Hv*Hv-C*hj*hj
# Let ratio=hstar²/Hv²+rr and HJ²=hstar²-ee, yielding positive C(Hv²rr+ee).
eq('strict_trigger_margin',trigger_margin.subs(q,(1-C*(hstar2/Hv**2+rr))/3).subs(hj*hj,hstar2-ee)-C*(Hv*Hv*rr+ee))
# Proper-time integral and conservation signs, using exact kinematic controls.
h,T,af,amin,rhof,rhomax=S.symbols('h T af amin rhof rhomax',positive=True)
at=af*S.exp(-h*T);rho_t=rhof*S.exp(3*h*T)
eq('proper_time_radius_derivative',-S.diff(S.log(at),T)-h)
eq('physical_radiation_charge',rho_t*at**4-rhof*af**4)
eq('radius_duration_boundary',at.subs(T,S.log(af/amin)/h)-amin)
eq('density_duration_boundary',rho_t.subs(T,S.log(rhomax/rhof)/(4*h))-rhomax)
# A positive excess H increases growth and preserves the one-sided bounds.
beta=S.symbols('beta',positive=True);at_excess=af*S.exp(-h*T-beta*(1-S.exp(-T)))
eq('excess_rate_derivative',-S.diff(S.log(at_excess),T)-(h+beta*S.exp(-T)))
eq('excess_zero_at_origin',(1-S.exp(-T)).subs(T,0))
ck('excess_gap_derivative_positive',S.diff(1-S.exp(-T),T).is_positive)
# Exact critical emergent history: slow past exists but fails future target.
t=S.symbols('t',real=True);X=1+S.exp(2*t);HH=S.exp(2*t)/X;kapx=2/X;rhox=3/X**2
for name,expr in [('critical_constraint',3*(HH**2+kapx)-(3+rhox)),('critical_raychaudhuri',S.diff(HH,t)-(kapx-S.Rational(2,3)*rhox)),('critical_radiation',S.diff(rhox,t)+4*HH*rhox)]:eq(name,expr)
eq('critical_physical_rate_past_zero',S.limit(HH,t,-S.oo))
eq('critical_past_radius_positive',S.limit(X,t,-S.oo)-1)
product=kapx/HH**2*3*HH**2/rhox;eq('critical_target_failure_product',product-2*X)
# No fitted parameters: fixed rational controls across supplied k and coupling intervals.
for kval,cfrac in itertools.product([S.Rational(1,100),S.Rational(1,10),S.Rational(1,4),S.Rational(3,10)],[S.Rational(1,100),S.Rational(1,4),S.Rational(1,2),S.Rational(3,4),S.Rational(99,100)]):
 av=aa.subs(k,kval);cm=CM.subs(k,kval);cv=cm*cfrac;rat=ratio.subs({a:av,Cmax:cm,C:cv});low=12*av*(1-3*av)/cm
 ck('uniform_bound_'+str((kval,cfrac)),rat>=low>0)
# Every premature large-magnitude stationary replacement violates a needed inequality.
qv=S.Rational(1,4);Zv=S.Rational(1);Lv=Lmin.subs({q:qv,Z:Zv});wv=Lv*Lv/qv;kapv=(wv+1+1)/3-(Zv-Lv)**2
ck('outside_slow_condition_curvature_can_be_negative',kapv<0)
res=dict(passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),limits=['Exact controls supplement the written general chronology/comparison proof.','Critical emergent example is a full constant-scalar action history but does not satisfy the target.','Kinematic integral controls are not claimed full field solutions.','No observed age, fitted thermal state, local G calibration or curvature-singularity conclusion.']);out.write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:res[k] for k in ['passed','failed']}))
for x in rows:
 if not x['passed']:print('FAILED',x)
raise SystemExit(1 if res['failed'] else 0)
