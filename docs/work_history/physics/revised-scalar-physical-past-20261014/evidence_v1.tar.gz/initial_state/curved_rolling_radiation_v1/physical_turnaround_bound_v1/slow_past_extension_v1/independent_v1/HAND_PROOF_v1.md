# Blind extension proof, frozen before computation

The supplied action and new derivation/protocol are frozen in sources.
The reused turnaround check is explicitly bound to receipt
dd6bf7b35b4f3a037ab1f9f1e3aa85f97c5e081adf0467fb4fcbc16d21a272c0
and manifest56ecb251c7c5b00f46c4c93b2e0fe64fdb85c78ea042d4b15ba8719b596bb8ac.
Its original158/0 is not a new run. DEPENDENCY_BINDING_v1.json verified its
64 artifacts and four source pairs without executing its science code.

Let bsharp=K^{-1}b, q=b.bsharp>0 and L=b.v. Projecting
v_parallel=(L/q)bsharp gives |v_parallel|_K^2=L^2/q and an orthogonal
v_perp with w_perp>=0. Hence w=L^2/q+w_perp. Since H=Z-L,

    w-3H^2=w_perp+(1-3q)L^2/q+6ZL-3Z^2
      =w_perp+(1-3q)/q [L+3qZ/(1-3q)]^2-3Z^2/(1-3q).

The sign in the square is positive. Minimization over the parallel velocity
has L=-3qZ/(1-3q), not the opposite sign. The constraint therefore implies

    3Qkappa-rho_r >= V+rho_m-3QZ^2/(1-3q).

The stated strict slow-event inequality makes this positive. It supplies
positive curvature and 0<f_b<1 without requiring Z_b=0, a minimum, or a
specified sign of H_J,b. Saturating the velocity square and the slow-event
threshold only gives equality of this lower bound; no strict local bound
should be attributed to that equality test. The condition remains sufficient,
not a classification of every initial event.

The reused turnaround theorem cannot be invoked verbatim with its Z_b=0
hypothesis removed. Its explicitly proved endpoint and chronology lemmas
are what transfer: the new local result supplies exactly Kc>0 and f_b<1;
at the later Z_f>0,d_f<=1 event the endpoint lemma gives H_E,f>0; then
the same zero-free or last-zero argument gives f_f<1 (or <1/2 in the
last-zero case). The unchanged conformal readout identity gives
d_f F_bare,f=1/f_f>1. No original science count is repeated.

For the uniform threshold, set r=C/Cmax=sE/(1+sE). The supplied metric
and b give

    q=a(1-r)/(1-3ar),
    1-3q=(1-3a)/(1-3ar),
    B(C):=(1-3q)/C=beta/[C(1-3a C/Cmax)].

The denominator is positive for0<C<Cmax, a<1/3. It is a concave quadratic
with maximum Cmax/(12a) at Copt=Cmax/(6a), strictly inside the domain
because a>1/4. Its exact square-completion remainder is the source's
(3a/Cmax)(C-Copt)^2. Thus B(C)>=12a beta/Cmax. The minimizing field
value exists at finite E=1/[s(6a-1)] for each fixed admissible k.

An independent parameter simplification gives

    Cmax=4a/(1+k),
    h_*^2/Hv^2=3(1+k)(1-3k)^2/4,
    h_*/Hv=(1-3k)sqrt[3(1+k)]/2>0.

This is a coupling-only minimum. U generally exceeds its vacuum minimum at
Copt, so it does not minimize the full V-dependent slow-event threshold or
select a realized state. At fixed k, B(C)->infinity as C->0 and
B(C)->1/Cmax as C->Cmax. Neither field boundary removes the uniform
positive lower bound at finite points. The parameter limit k->1/3 is
different: h_* tends to0. No common positive h_* is supplied over that
excluded parameter limit.

Because Z^2=C H_J^2, |H_J|<h_* implies

    Z^2 < C h_*^2 <= (1-3q)Hv^2
                         <= (1-3q)(V+rho_m)/(3Q).

The first strict inequality keeps the final condition strict even if one
of the other inequalities is saturated. This also works at finite states
arbitrarily close to either conformal boundary. For fixed h_*>0, any
sequence H_J(t_n)->0 eventually has |H_J(t_n)|<h_* at a finite event.
Only that event's regular connecting segment to the target is used, never
compactness at an infinite endpoint. A sequence in which k itself tends
to1/3 is not covered: e.g. k_n=(1-1/n)/3 and H_J,n=2Hv/n both tend to
the excluded limit while H_J,n remains above its changing h_*(k_n).

Under the future bare target the transferred endpoint/chronology result
forbids every earlier event with |H_J|<h_*. Thus every earlier finite
event in the connected interval has |H_J|>=h_*. The interval must contain
an actual nonempty left neighborhood of t_f, as a past duration claim
requires. Continuity then also implies H_J,f>=h_*: otherwise a nearby
earlier event is slow. If any earlier value were negative, the intermediate
value theorem between it and the positive final value would produce a
forbidden zero. Therefore H_J>=h_* throughout. Merely checking endpoint
magnitudes is insufficient, and a discontinuous sign jump would violate
the regularity premise. No assumption of monotone H_J is needed.

Using the physical proper time, not Einstein time,

    ln(a_J,f/a_J(t))=integral_t^tf H_J ds >=h_*(tf-t).

This proves the radius upper bound. Adding a_J>=a_min>0 gives the stated
finite duration. Separate physical radiation conservation follows from
rho_E=C^2rho_J and a_J^4=C^2 a_E^4, hence rho_J a_J^4 is constant.
An upper density cutoff therefore gives a_min/a_f=(rho_f/rho_max)^(1/4)
and the same duration with denominator4h_*. Ratios of scale factors are
unchanged by a fixed comoving spatial normalization. An absolute radius
cutoff must use a fixed normalization (or a specified physical distance);
no such numerical cutoff is derived here.

If the physical past duration is unbounded, the exponential upper bound
forces a_J->0 and radiation conservation forces rho_J->infinity. This
alone proves neither physical-curvature divergence nor finite-time
singularity, inextendibility, or geodesic incompleteness. Unbounded
Einstein time is not automatically unbounded physical time when C varies.
The source correctly phrases the duration in physical proper time.

The later bare target is an exact supplied condition. It has not been
shown observationally, and Q/C is not a measured-G identification. Hv and
the cutoff values remain supplied scales. No other new-route calculation,
gravity-calibration file or producer result is used by this check.

Planned independent controls: exact projection/completion, admissible-model
rational states, equality/strict-threshold probes, exact q(C) inversion and
quadratic remainder, boundary/parameter-limit controls, finite-event
sequences, continuity counterprobes, radius/density identities, and a
synthetic exact flat radiation-plus-vacuum solution satisfying the future
target and duration assumptions. Actual damaged copies will test square
sign, conformal factor, uniform coefficient, endpoint-only sign inference,
past exponential orientation and radiation dilution power.
