# Focused blind check of the slow-past extension

The stated conditional extension is mathematically supported. The new kinetic completion supplies the same positive-curvature and radiation-fraction intermediate result needed by the already checked endpoint and last-Einstein-zero lemmas. The coupling bound is uniform over every finite field point at fixed admissible parameters. Its contrapositive gives the stated positive physical Hubble lower bound and the conditional radius/density duration bounds. No repair to the author's DERIVATION_v1.md or PROTOCOL_v1.json was identified.

The new corrected independent run completed **153 pass / 0 fail**. The initial independent run completed **149 pass / 2 fail** because SymPy left two exact endpoint identities unreduced; that failed run, script and outputs remain intact. Six actual damaged copies of the corrected checker each exited 1 with the intended failed identity. The earlier turnaround result, **158/0**, is explicitly reused through its immutable receipt and was not rerun or added to the new count.

This is a focused mathematical check of a supplied classical action and conditional target. It is not a formal audit, an empirical exclusion, an observed initial-state selection or a global spacetime singularity result. No producer checker, output, profile, grid or other new-route calculation was read or run.

## Source and dependency identities

All three current inputs and four reused dependency files were frozen before the independent calculation. SOURCE_MANIFEST_v1.json gives full repository-relative original paths, snapshot paths, byte counts and roles.

| Input | SHA-256 |
| --- | --- |
| slow_past_extension_v1/DERIVATION_v1.md | 03d231669de0bf27724e653447f2b75b7ad5ef4386b41874059976dd8119c107 |
| slow_past_extension_v1/PROTOCOL_v1.json | 19948459bf0f35951103a289d54337407046dd82a6956421d2ffce9c5f550781 |
| Supplied full-action confinement note | 39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000 |
| Reused turnaround REPORT_v1.md | 5bdd6275fb335cff17280eac4616be755b9a379b1ef60b7ff50b135b40768916 |
| Reused turnaround HAND_PROOF_v1.md | da83f49409f2ed9edb08e70795ef87fb381f09f57ff101af9f34404890cd971e |
| Reused turnaround RECEIPT_v1.json | dd6bf7b35b4f3a037ab1f9f1e3aa85f97c5e081adf0467fb4fcbc16d21a272c0 |
| Reused turnaround MANIFEST_v1.json | 56ecb251c7c5b00f46c4c93b2e0fe64fdb85c78ea042d4b15ba8719b596bb8ac |

The canonical note supplies its complete action, not its separate flat future-confinement theorem. The original turnaround receipt binds 64 artifacts and four live/snapshot source pairs. Both the initial dependency check and final evidence validation rehashed those originals. This unit's HAND_PROOF_v1.md and CONTROL_PROTOCOL_v1.json were written before execution. The prior proof and its narrow protocol correction are retained through the original seal; no previous evidence was edited.

## Independent completion and sufficient event

For the action with no factor 1/2 before K, homogeneous scalar energy density is Qw+V, where w=|v|_K^2. Let b=d ln A, q=|b|_K^2, L=b.v, and Z=H_E+L. The positive-definite full three-field metric permits the orthogonal projection

    v_parallel=(L/q)b^sharp,
    w=L^2/q+w_perp,       w_perp>=0.

At finite field values q>0, so no division by a vanishing coupling occurs. Direct expansion then gives

    w-3(Z-L)^2
      =w_perp+(1-3q)/q [L+3qZ/(1-3q)]^2
        -3Z^2/(1-3q).

The plus sign inside the square is necessary; the minimizing parallel velocity has L=-3qZ/(1-3q). The constraint becomes

    3Q kappa-rho_r >= V+rho_m-3QZ^2/(1-3q).

Thus the strict slow-event inequality in the source gives 3Q kappa_b>rho_r,b>0, proving Kc>0 and 0<f_b<1 without requiring a stationary event, a minimum, or a sign choice for H_J,b.

Exact full-metric controls use k=1/11,2/9,3/10, E=1/5,2,7, nonzero x,y and velocities with both parallel and transverse components. They check projection orthogonality, positive transverse energy and the square identity. Separate local origin states at k=1/5, Q=Hv=1, V=3, rho_r=1 and rho_m=0 saturate the velocity square. For theta=Z^2/[(1-3q)V/(3Q)], the constraint margin is exactly 3(1-theta). Controls theta=0,1/4,9/10,1,11/10 distinguish strict sufficiency, threshold equality and a failure above the threshold. They are local constraint data, not asserted complete histories.

The old exact-turnaround theorem is not invoked verbatim after dropping its Z_b=0 hypothesis. Its previously proved endpoint and chronology lemmas are reused with the new intermediate conclusion. The final Z_f>0,d_f<=1 event gives H_E,f>0. If H_E has no zero on the connecting finite interval, it is positive throughout and the Einstein radius grows. Otherwise the compact zero set has a last zero, including tangencies and degenerate zeros; its right derivative is nonnegative and H_E is positive afterward. The old proof then gives f_f<1, with f_f<1/2 in the last-zero branch. Radiation conservation and the unchanged conformal readout yield d_f F_bare,f=1/f_f>1, or >2 in that latter branch. The old 158/0 is dependency evidence, not a new execution.

## Uniform coupling threshold and boundary challenges

From the supplied metric and b=(alpha/F,0,0), q=a/J. Substituting C=(1+s)E/(1+sE) gives

    q=a(1-C/Cmax)/(1-3aC/Cmax),
    (1-3q)/C=beta/[C(1-3aC/Cmax)],
    beta=1-3a=(1-3k)^2/4>0.

For fixed 0<k<1/3, 1/4<a<1/3. The denominator is positive on 0<C<Cmax and has maximum Cmax/(12a) at Copt=Cmax/(6a). The exact quadratic remainder in the source is correct. Consequently

    (1-3q)/C >= 12a beta/Cmax,
    h_*^2/Hv^2 = 12a beta/Cmax
                =3(1+k)(1-3k)^2/4.

The independent parameter simplification also gives Cmax=4a/(1+k), Copt=2/[3(1+k)] and h_*/Hv=(1-3k)sqrt[3(1+k)]/2. The minimizing coupling state has finite E=1/[s(6a-1)]. This minimizes the coupling factor alone, not the full potential-dependent slow-event threshold, and does not select a realized field state.

At fixed k, (1-3q)/C tends to infinity as C tends to 0 and to 1/Cmax as C tends to Cmax. Neither field boundary defeats the uniform bound. Since Z^2=C H_J^2 and V+rho_m>=3QHv^2,

    |H_J|<h_* => Z^2<C h_*^2
                     <=(1-3q)Hv^2
                     <=(1-3q)(V+rho_m)/(3Q).

The first inequality supplies strictness even if a later inequality saturates. Exact finite-state controls approach both C boundaries while H_J/Hv=1/n for n=100,1000 and the three independent k values above.

A fixed-parameter sequence H_J(t_n)->0 must eventually contain a finite slow event. Only that event's regular finite connecting interval is needed; no compactness or regular field value at an infinite endpoint is inferred. The fixed-parameter premise is essential. As an explicit outside-premise probe, k_n=(1-1/n)/3 and H_J,n/Hv=2/n both approach their respective limits, while h_*^2/Hv^2=(n-1/4)/n^3 and H_J,n remains above its changing threshold. This is an across-model sequence, not a trajectory. The excluded limit k->1/3 loses the positive uniform constant; k->0 instead gives h_*^2/Hv^2->3/4.

## Contrapositive, physical clock and duration

Under the later bare target H_J,f>0, d_f<=1 and d_f F_bare,f<=1, every earlier finite event in the connected regular interval must satisfy |H_J|>=h_*. A nonempty left neighborhood of the final event is implicit in a past-duration statement. If H_J,f<h_*, continuity would supply a slow earlier event. If any earlier H_J were negative, continuity to the positive final value would supply a forbidden zero. Therefore H_J>=h_* throughout, including the final event. No monotonicity of H_J is needed.

Endpoint magnitudes alone cannot establish this sign conclusion: H_J=h_*(1+2t) on [-1,0] has endpoint magnitudes h_* but an interior zero. This exact counterprobe rejects the endpoint-only damaged checker. A discontinuous sign jump violates the regularity premise; a negative constant violates the final positive-rate premise.

Using physical proper time, d ln a_J/dt_J=H_J gives

    ln[a_J,f/a_J(t)]>=h_*(t_J,f-t_J),
    a_J(t)<=a_J,f exp[-h_*(t_J,f-t_J)].

Adding a positive lower scale factor gives the stated logarithmic duration upper bound. Physical radiation conservation follows consistently from rho_r,E=C^2 rho_r,J and a_J^4=C^2 a_E^4, so rho_r,J a_J^4 is constant. A finite upper radiation density therefore gives the same bound with denominator 4h_*. A fixed comoving normalization cancels from the radius ratio; a numerical absolute radius cutoff needs a specified normalization or physical distance. The cutoffs and Hv remain supplied scales.

For unbounded physical past duration without a cutoff, the bound forces a_J->0 and rho_r,J->infinity. It does not prove divergent physical curvature, a finite-time singularity, inextendibility or geodesic incompleteness. Unbounded Einstein time is not automatically unbounded physical time when C varies.

As a new nonempty-domain control, the constant-origin full-action solution with Q=Hv=1 and Kc=0 is

    a_J(t)=sqrt(sinh(2t)),
    H_J(t)=coth(2t),
    rho_r,J(t)=3 csch(2t)^2,       t>0.

The checker verifies its constraint, Raychaudhuri, clock and radiation equations. At k=1/5, nu=9/7 and t_f=asinh(1)/2, it has a_f=1, rho_f=3, H_f^2=2, d_f=0 and F_bare,f=2, satisfying the target. Choosing t_min=asinh(1/4)/2 gives a_min=1/2 and rho_max=48. Here h_*^2=18/125, the actual duration is approximately 0.31695356273614 and the radius/density upper bound is approximately 1.82660320357784. Analytically H_J>1>h_*; the numerical illustration does not establish the general theorem. All values are exposed synthetic choices, with no measured calibration.

## Executions, negative controls and preserved failures

Python 3.12.8 and SymPy 1.14.0 were used. Exact command arrays, working directory, UTC intervals, script hashes, exit codes and stdout/stderr hashes are in each *_run_v*.json and the sealed COMMANDS_v1.json. The child command for the successful new run was Python -B check_extension_v2.py independent_extension_results_v2.json, using the absolute paths recorded there. It ran at 2026-10-14T11:32:17.612034Z through 11:32:18.394289Z and exited 0.

The original check_extension_v1.py (SHA f5a31e11e41638a7d026a4692cf479123eb6c61158f92222c2263fd72038a1d3) actually ran 149/2 and exited 1. The failed exact residuals were -1+sqrt(sinh(log(1+sqrt(2)))) and -6+3/tanh(log(1+sqrt(2)))^2. The corrected v2 rewrites only those endpoint expressions through exponentials to make cancellation explicit. It also computes the final Hubble rate and bare radiation factor directly, adding two controls. The parameter cases and tolerances were unchanged. CHECKER_REPAIR_v2.json, CHECKER_v1_v2.diff, both scripts and both complete outputs preserve this history. Corrected script SHA: 8dbeadebdc246243b0c0adf0e558bb1c890246504fbaf4c111aa9ef70fc85ed8.

| Actually executed damaged copy | Pass / fail | Exit | Required failed check |
| --- | --- | --- | --- |
| Reverse the square-completion sign | 131 / 22 | 1 | exact_kinetic_square |
| Omit physical threshold division by C | 137 / 16 | 1 | physical_threshold_conformal_conversion |
| Replace uniform coefficient 12 by 16 | 144 / 9 | 1 | coupling_minimum_value |
| Infer sign from endpoint magnitudes alone | 152 / 1 | 1 | endpoint_only_sign_inference_rejected |
| Reverse the past exponential sign | 148 / 5 | 1 | past_exponential_has_positive_physical_H |
| Substitute dust's dilution power 3 | 147 / 6 | 1 | physical_radiation_dilution |

All six damaged scripts, results and exact command records are retained. No damaged result is counted as a passing science run. The initial dependency identity check was 71/0; the final source, command, damage and dependency validation was **148/0 metadata checks**, not science. It confirmed all seven current live/snapshot bindings, the original dependency's 64 artifacts and four source pairs, and the recorded expected exits.

There was also a real process mistake: an accidental apply_patch call created a zero-byte scratch file at campaign-root/physical_turnaround_placeholder, outside this unit's authorized output directory. Its empty bytes were verified and that exact file was immediately removed; the parent was notified. PROCESS_FAILURES_v1.json preserves the erroneous patch, path, empty-file hash, diagnosis and repair. No parent source or prior seal was altered. Persistent output artifacts are confined to this unit, but the transient write is explicitly not represented as compliant. Final metadata and sealing checks confirm the misplaced path remains absent.

A later read-only preseal diagnostic printer also exited 1 when it called len() on the integer source_pairs count in DEPENDENCY_BINDING_v1.json. PRESEAL_READ_FAILURE_v1.json preserves the exact command, traceback and successful type-aware inspection. This was a metadata display failure, not a science or source-binding failure; it changed no input or prior evidence.

## Bounded disposition and seal

The same independent checker confirms the final author source and protocol are byte-identical to their frozen originals. No author correction, changed premise or new source version is needed for the checked result. The explicit fixed parameters, positive potential floor, regular connected finite intervals, separately conserved positive radiation, nonnegative other density/enthalpy, physical clock and supplied bare future target remain necessary scope conditions.

The result is a conditional obstruction to a slow physical past or an arbitrarily long past with an additionally bounded radius/density. The bare Q/C coefficient has not been identified with measured local gravity. No observation establishes the future target here; present CMB radiation and near-flatness alone do not do so. There is no new initial-state selection, likelihood, stability result, quantum conclusion or general singularity theorem. The author's separately mentioned gravity-calibration route is not used as evidence in this check.

MANIFEST_v1.json binds every persistent artifact except itself and the receipt; RECEIPT_v1.json binds that manifest and this report, all source/dependency identities, actual commands, failures, controls and limited conclusion. The unit is frozen after sealing; prior independent units remain immutable. No authority/status, Git, runtime, PR or audit operation was performed.
