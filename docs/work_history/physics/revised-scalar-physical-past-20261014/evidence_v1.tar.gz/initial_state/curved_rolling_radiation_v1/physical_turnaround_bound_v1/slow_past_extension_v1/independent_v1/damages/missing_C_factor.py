"""Blind new extension controls; reused turnaround science is not imported/run."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
import sympy as s
COMPLETION_SIGN = 1
PHYSICAL_C_POWER = 0
UNIFORM_FACTOR = 12
CHECK_INTERIOR_ZERO = True
PAST_EXPONENT_SIGN = -1
RADIATION_POWER = 4
rows=[];evidence={}
def check(name,ok,detail=None):rows.append({'name':name,'passed':bool(ok),'detail':detail})
def zero(name,expr):
 out=s.simplify(expr);check(name,out==0,str(out))
q,L,Z,wp=s.symbols('q L Z wp',real=True)
w=L**2/q+wp
completed=wp+(1-3*q)/q*(L+COMPLETION_SIGN*3*q*Z/(1-3*q))**2-3*Z**2/(1-3*q)
zero('exact_kinetic_square',w-3*(Z-L)**2-completed)
minimizer=-COMPLETION_SIGN*3*q*Z/(1-3*q)
zero('parallel_velocity_minimizer',s.diff(w-3*(Z-L)**2,L).subs(L,minimizer))
zero('minimum_value',((w-3*(Z-L)**2).subs({L:minimizer,wp:0}))+3*Z**2/(1-3*q))
Q,V,rm,rho,kap=s.symbols('Q V rm rho kap',positive=True)
constraint_curv=(Q*w+V+rm+rho-3*Q*(Z-L)**2)/(3*Q)
zero('constraint_completion',3*Q*constraint_curv-rho-(V+rm+Q*completed))
# Full-model rational geometry controls; the field value is u=log(E)/(2sqrt(a)).
geometry=[]
for kk in [s.Rational(1,11),s.Rational(2,9),s.Rational(3,10)]:
 aa=(1-kk)*(1+3*kk)/4;alpha=s.sqrt(aa);ss=(1+kk)/(kk*(1-3*kk))
 for ee in [s.Rational(1,5),s.Integer(2),s.Integer(7)]:
  ff=1+ss*ee;jj=1+(1-3*aa)*ss*ee;dd=1+2*(1+kk)*(s.Rational(1,3)**2+s.Rational(-2,5)**2)/3
  metric=s.diag(jj/ff**2,(1+ss)*4*kk/(9*ff*dd),(1+ss)*kk/(3*ff*dd))
  cov=s.Matrix([alpha/ff,0,0]);vel=s.Matrix([2/(3*alpha),s.Rational(1,4),s.Rational(-2,7)])
  sharp=metric.inv()*cov;qq=(cov.T*sharp)[0];ll=(cov.T*vel)[0];ww=(vel.T*metric*vel)[0]
  perp=vel-(ll/qq)*sharp;pp=(perp.T*metric*perp)[0]
  zero('projection_orthogonal_'+str((kk,ee)),(cov.T*perp)[0])
  zero('projection_energy_'+str((kk,ee)),ww-ll*ll/qq-pp)
  check('projection_positive_'+str((kk,ee)),0<qq<s.Rational(1,3) and pp>=0)
  for zz in [-2,0,s.Rational(3,5)]:
   zero('model_square_'+str((kk,ee,zz)),(w-3*(Z-L)**2-completed).subs({q:qq,L:ll,Z:zz,wp:pp}))
  geometry.append({'k':str(kk),'E':str(ee),'q':str(qq),'w_perp':str(pp)})
evidence['full_metric_states']=geometry
# Strict local condition: a real origin state with parallel minimizing velocity.
local=[]
for theta in [0,s.Rational(1,4),s.Rational(9,10),1,s.Rational(11,10)]:
 qq=s.Rational(1,5);zz=s.sqrt(s.Rational(2,5)*theta);ll=-3*qq*zz/(1-3*qq)
 ww=ll*ll/qq;hh=zz-ll;cc=(ww+3+1-3*hh*hh)/3
 margin=s.simplify(3*cc-1)
 zero('local_margin_'+str(theta),margin-3*(1-theta))
 if theta<1:check('strict_slow_condition_implies_margin_'+str(theta),margin>0)
 elif theta==1:check('equality_is_not_strict_local_margin',margin==0)
 else:check('above_threshold_can_break_local_margin',margin<0)
 local.append({'theta':str(theta),'Z':str(zz),'L':str(ll),'H':str(hh),'w':str(ww),'kappa':str(cc),'margin':str(margin)})
evidence['local_origin_threshold_states']=local
# Rational coupling inversion and exact global minimum.
k,E,C=s.symbols('k E C',positive=True)
a=(1-k)*(1+3*k)/4;beta=(1-3*k)**2/4;ss=(1+k)/(k*(1-3*k))
cm=(1+ss)/ss;cf=(1+ss)*E/(1+ss*E);qE=a/(1+beta*ss*E)
qC=a*(1-C/cm)/(1-3*a*C/cm)
zero('coupling_chart_identity',qC.subs(C,cf)-qE)
zero('one_minus_three_q',1-3*qC-beta/(1-3*a*C/cm))
zero('Cmax_parameter_simplification',cm-4*a/(1+k))
zero('C_inverse_E',cf.subs(E,C/(ss*(cm-C)))-C)
opt=cm/(6*a);den=C*(1-3*a*C/cm)
zero('quadratic_denominator_completion',cm/(12*a)-den-(3*a/cm)*(C-opt)**2)
B=(1-3*qC)/C**PHYSICAL_C_POWER
uniform=UNIFORM_FACTOR*a*beta/cm
zero('physical_threshold_conformal_conversion',C*B-(1-3*qC))
zero('global_square_gap',B-uniform-36*a*a*beta*(C-opt)**2/(cm*cm*den))
zero('coupling_minimum_stationary',s.diff(B,C).subs(C,opt))
zero('coupling_minimum_value',B.subs(C,opt)-uniform)
zero('independent_hstar_parameter_form',uniform-3*(1+k)*(1-3*k)**2/4)
zero('optimum_parameter_form',opt-2/(3*(1+k)))
zero('optimum_finite_E',cf.subs(E,1/(ss*(6*a-1)))-opt)
zero('k_endpoint_threshold_loss',s.limit(uniform,k,s.Rational(1,3),dir='-'))
zero('small_k_threshold_limit',s.limit(uniform,k,0,dir='+')-s.Rational(3,4))
for kk in [s.Rational(1,11),s.Rational(2,9),s.Rational(3,10)]:
 cmb=s.simplify(cm.subs(k,kk));op=s.simplify(opt.subs(k,kk));floor=s.simplify(uniform.subs(k,kk))
 check('interior_minimum_'+str(kk),0<op<cmb and floor>0)
 for cc in [cmb/100,op,cmb*s.Rational(99,100)]:
  value=s.simplify(B.subs({k:kk,C:cc}))
  check('global_lower_bound_'+str((kk,cc)),value>=floor,str(value-floor))
 check('C_to_zero_limit_'+str(kk),s.limit(B.subs(k,kk),C,0,dir='+')==s.oo)
 zero('C_to_Cmax_limit_'+str(kk),s.limit(B.subs(k,kk),C,cmb,dir='-')-1/cmb)
 for n in [100,1000]:
  for side,cc in [('lower',cmb/n),('upper',cmb*(1-s.Rational(1,n)))]:
   qq=s.simplify(qC.subs({k:kk,C:cc}));ee=s.simplify((C/(ss*(cm-C))).subs({k:kk,C:cc}))
   check('boundary_sequence_finite_chart_'+str((kk,n,side)),0<cc<cmb and ee>0 and 0<qq<s.Rational(1,3))
   check('boundary_sequence_sufficient_event_'+str((kk,n,side)),s.Rational(1,n*n)<floor and cc/s.Integer(n*n)<1-3*qq)
# Across-model sequence deliberately violates the fixed-k premise.
n=s.symbols('n',positive=True)
kn=(1-1/n)/3;hn2=s.simplify(uniform.subs(k,kn));HJn2=4/n**2
zero('varying_k_threshold_formula',hn2-(4*n-1)/(4*n**3))
zero('varying_k_excluded_sequence_limit',s.limit(HJn2,n,s.oo))
check('varying_k_sequence_stays_above_changing_threshold',s.simplify(HJn2-hn2).is_positive)
evidence['parameter_limit_probe']={'k_n':'(1-1/n)/3 for n>=2','HJ_n/Hv':'2/n','hstar_squared/Hv_squared':str(hn2),'scope':'across-model sequence, not a fixed-parameter trajectory'}
# No numerical sampling substitutes for continuity: this exact linear path
# has a known interior root, despite both endpoint magnitudes equaling h.
t=s.symbols('t',real=True);h=s.symbols('h',positive=True)
linear=h*(1+2*t)
points=[s.Integer(-1),s.Integer(0)]
if CHECK_INTERIOR_ZERO:points+=s.solve(linear,t)
accepted=all(abs(linear.subs(t,p))>=h for p in points)
check('endpoint_only_sign_inference_rejected',not accepted)
zero('continuous_sign_switch_has_forbidden_zero',linear.subs(t,s.Rational(-1,2)))
check('discontinuous_jump_violates_continuity',-h!=h)
check('negative_constant_violates_positive_final',not (-h>0))
check('small_positive_final_has_slow_left_neighborhood',h/2<h)
# Physical proper-time integration and conserved radiation cutoff.
T,af,rhof,rhomax=s.symbols('T af rhof rhomax',positive=True)
a_upper=af*s.exp(PAST_EXPONENT_SIGN*h*T)
zero('past_exponential_has_positive_physical_H',-s.diff(s.log(a_upper),T)-h)
zero('past_radius_upper_orientation',s.log(af/a_upper)-h*T)
rho_past=rhof*(af/a_upper)**RADIATION_POWER
zero('physical_radiation_dilution',-s.diff(s.log(rho_past),T)+4*h)
amin=af*(rhof/rhomax)**s.Rational(1,4)
radius_duration=s.expand_log(s.log(af/amin)/h,force=True)
density_duration=s.expand_log(s.log(rhomax/rhof)/(RADIATION_POWER*h),force=True)
zero('radius_density_duration_equivalence',radius_duration-density_duration)
# The no-cutoff limits concern physical time T, not the Einstein clock.
zero('infinite_physical_past_radius_limit',s.limit(a_upper,T,s.oo))
check('infinite_physical_past_density_limit',s.limit(rho_past,T,s.oo)==s.oo)
# Full-action exact flat radiation+vacuum example with positive future target.
tp=s.symbols('tp',positive=True)
scale=s.sqrt(s.sinh(2*tp));H=s.coth(2*tp);radiation=3/scale**RADIATION_POWER
zero('flat_solution_clock',s.diff(s.log(scale),tp)-H)
zero('flat_solution_constraint',(3*H**2-3-radiation).rewrite(s.exp))
zero('flat_solution_Raychaudhuri',(s.diff(H,tp)+2*radiation/3).rewrite(s.exp))
zero('flat_solution_radiation',(s.diff(radiation,tp)+4*H*radiation).rewrite(s.exp))
check('flat_solution_positive_H_and_radiation',H.is_positive and radiation.is_positive)
tf=s.asinh(1)/2;tm=s.asinh(s.Rational(1,4))/2
zero('flat_example_final_scale',(scale.subs(tp,tf)-1).rewrite(s.exp))
zero('flat_example_minimum_scale',scale.subs(tp,tm)-s.Rational(1,2))
zero('flat_example_final_density',(radiation.subs(tp,tf)-3).rewrite(s.exp))
zero('flat_example_upper_density',radiation.subs(tp,tm)-48)
hfloor2=s.simplify(uniform.subs(k,s.Rational(1,5)))
zero('flat_example_hstar_squared',hfloor2-s.Rational(18,125))
check('flat_example_H_above_uniform_floor',0<hfloor2<1)
Hfinal=s.simplify(H.subs(tp,tf).rewrite(s.exp))
rhofinal=s.simplify(radiation.subs(tp,tf).rewrite(s.exp))
dfinal=s.Integer(0)/(Hfinal**2)
Ffinal=s.simplify(3*Hfinal**2/rhofinal)
zero('flat_example_actual_final_H_squared',Hfinal**2-2)
zero('flat_example_actual_final_bare_F',Ffinal-2)
check('flat_example_future_target',Hfinal>0 and dfinal<=1 and dfinal*Ffinal<=1)
actual=tf-tm;bound=s.log(16)/(RADIATION_POWER*s.sqrt(hfloor2))
check('flat_example_duration_bound',s.N(bound-actual,70)>0,str(s.N(bound-actual,50)))
evidence['exact_flat_example']={'k':'1/5','nu':'9/7','Q':'1','Hv':'1','fields':'u=x=y=0','Kc':'0',
 'd_final':'0','F_bare_final':'2','product_final':'0','hstar_squared':str(hfloor2),
 't_final':'asinh(1)/2','t_min':'asinh(1/4)/2','actual_duration':str(s.N(actual,50)),
 'radius_or_density_bound':str(s.N(bound,50)),
 'scope':'synthetic exact solution and cutoff controls; no observed scale or parameter calibration'}
result={'created_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'pass':sum(z['passed'] for z in rows),'fail':sum(not z['passed'] for z in rows),'checks':rows,'evidence':evidence,
 'scope':'new extension controls only; prior158/0 turnaround result reused without rerun',
 'producer_access':False,'versions':{'python':sys.version,'sympy':s.__version__}}
out=Path(sys.argv[1]);assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pass':result['pass'],'fail':result['fail'],'failed_checks':[z for z in rows if not z['passed']],
 'parameter_limit_probe':evidence['parameter_limit_probe'],'exact_flat_example':evidence['exact_flat_example']},indent=2))
sys.exit(1 if result['fail'] else 0)
