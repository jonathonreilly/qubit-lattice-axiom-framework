from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
here=Path(__file__).resolve().parent
original=here/'check_extension_v2.py';raw=original.read_text()
folder=here/'damages';folder.mkdir(exist_ok=False)
specs=[
 ('square_sign','COMPLETION_SIGN = 1','COMPLETION_SIGN = -1','exact_kinetic_square'),
 ('missing_C_factor','PHYSICAL_C_POWER = 1','PHYSICAL_C_POWER = 0','physical_threshold_conformal_conversion'),
 ('overstated_uniform_constant','UNIFORM_FACTOR = 12','UNIFORM_FACTOR = 16','coupling_minimum_value'),
 ('endpoint_only_sign','CHECK_INTERIOR_ZERO = True','CHECK_INTERIOR_ZERO = False','endpoint_only_sign_inference_rejected'),
 ('reversed_past_exponential','PAST_EXPONENT_SIGN = -1','PAST_EXPONENT_SIGN = 1','past_exponential_has_positive_physical_H'),
 ('dust_density_power','RADIATION_POWER = 4','RADIATION_POWER = 3','physical_radiation_dilution')]
rows=[]
for name,old,new,required in specs:
 assert raw.count(old+'\n')==1
 p=folder/(name+'.py');p.write_text(raw.replace(old+'\n',new+'\n'))
 rows.append({'name':name,'path':p.relative_to(here).as_posix(),'original_line':old,'damaged_line':new,
 'required_failed_check':required,'expected_child_exit':1,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
out={'created_utc':datetime.now(timezone.utc).isoformat(),'original_script':original.name,
 'original_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'cases':rows,'execution_not_yet_claimed':True}
(here/'DAMAGE_PLAN_v1.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
