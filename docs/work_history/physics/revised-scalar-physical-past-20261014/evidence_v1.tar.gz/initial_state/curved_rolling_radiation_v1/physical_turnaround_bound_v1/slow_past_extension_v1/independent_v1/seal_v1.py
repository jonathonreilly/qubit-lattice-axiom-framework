"""Freeze this focused unit; identity checks only, no science execution."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, sys
here = Path(__file__).resolve().parent
root = Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(name):
    return json.loads((here / name).read_text())

def write(name, obj):
    with (here / name).open('x') as f:
        json.dump(obj, f, indent=2)
        f.write('\n')

def bind(path):
    return {'path': str(path.relative_to(here)), 'bytes': path.stat().st_size, 'sha256': sha(path)}

def verify_pair(pair, snapshot_root):
    original = root / pair['original_path']
    snapshot = snapshot_root / pair['snapshot_path']
    assert original.is_file() and snapshot.is_file()
    assert original.read_bytes() == snapshot.read_bytes()
    assert sha(original) == pair['sha256']
    assert original.stat().st_size == pair['bytes']

for name in ['COMMANDS_v1.json', 'FINAL_SOURCE_CONFIRMATION_v1.json', 'SEAL_VALIDATION_v1.json', 'MANIFEST_v1.json', 'RECEIPT_v1.json']:
    assert not (here / name).exists(), name
assert (here / 'REPORT_v1.md').is_file()
sources = read('SOURCE_MANIFEST_v1.json')['sources']
assert len(sources) == 7
for pair in sources:
    verify_pair(pair, here)
assert sources[0]['sha256'] == '03d231669de0bf27724e653447f2b75b7ad5ef4386b41874059976dd8119c107'
assert sources[1]['sha256'] == '19948459bf0f35951103a289d54337407046dd82a6956421d2ffce9c5f550781'
validation = read('EVIDENCE_VALIDATION_v1.json')
assert (validation['pass'], validation['fail']) == (148, 0)
assert validation['source_pairs'] == sources
assert not validation['producer_code_results_or_other_route_accessed']
old_root = here.parent.parent / 'independent_v1'
old_manifest = json.loads((old_root / 'MANIFEST_v1.json').read_text())
old_receipt = json.loads((old_root / 'RECEIPT_v1.json').read_text())
assert sha(old_root / 'RECEIPT_v1.json') == 'dd6bf7b35b4f3a037ab1f9f1e3aa85f97c5e081adf0467fb4fcbc16d21a272c0'
assert sha(old_root / 'MANIFEST_v1.json') == '56ecb251c7c5b00f46c4c93b2e0fe64fdb85c78ea042d4b15ba8719b596bb8ac'
assert len(old_manifest['artifacts']) == 64
assert len(old_manifest['source_pairs']) == 4
for item in old_manifest['artifacts']:
    path = old_root / item['path']
    assert path.is_file() and not path.is_symlink()
    assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
for pair in old_manifest['source_pairs']:
    verify_pair(pair, old_root)

commands = []
for path in sorted(here.glob('*_run_v*.json')):
    record = json.loads(path.read_text())
    expected = 1 if path.name.startswith('damage_') or path.name == 'independent_extension_run_v1.json' else 0
    assert record['exit_code'] == expected
    assert not record['timed_out']
    assert Path(record['cwd']).resolve() == here
    script = Path(record['command'][2])
    assert script.is_file() and sha(script) == record['script_sha256']
    for key in ['stdout', 'stderr']:
        item = record[key]
        p = here / item['path']
        assert p.stat().st_size == item['bytes'] and sha(p) == item['sha256']
    commands.append({'record': path.name, 'record_sha256': sha(path), **record})
assert len(commands) == 10
first = read('independent_extension_results_v1.json')
corrected = read('independent_extension_results_v2.json')
assert (first['pass'], first['fail']) == (149, 2)
assert (corrected['pass'], corrected['fail']) == (153, 0)
assert not first['producer_access'] and not corrected['producer_access']
assert first['script_sha256'] == sha(here / 'check_extension_v1.py')
assert corrected['script_sha256'] == sha(here / 'check_extension_v2.py')
assert len(validation['actual_damages']) == 6
for item in validation['actual_damages']:
    result = read(item['result'])
    command = read(item['command_record'])
    assert (result['pass'], result['fail']) == (item['pass'], item['fail'])
    assert result['fail'] > 0 and command['exit_code'] == 1
    assert result['script_sha256'] == sha(here / item['script'])
    failed_names = [row['name'] for row in result['checks'] if not row['passed']]
    assert item['required_failed_check'] in failed_names
    assert item['failed_checks'] == failed_names
process = read('PROCESS_FAILURES_v1.json')
assert not (root / process['path']).exists()
read_failure = read('PRESEAL_READ_FAILURE_v1.json')
assert read_failure['exit_code'] == 1 and not read_failure['files_changed_by_failed_command']
for p in here.rglob('*'):
    assert not p.is_symlink(), str(p)

now = datetime.now(timezone.utc).isoformat()
seal_command = {'command': [sys.executable, '-B', str(Path(__file__).resolve())], 'cwd': str(here), 'script_sha256': sha(Path(__file__)), 'scope': 'hash and identity verification plus immutable evidence serialization; no science rerun'}
write('COMMANDS_v1.json', {'created_utc': now, 'recorded_child_runs': commands, 'read_only_inspection_failure': bind(here / 'PRESEAL_READ_FAILURE_v1.json'), 'process_failure': bind(here / 'PROCESS_FAILURES_v1.json'), 'seal_command': seal_command})
confirmation = {
    'created_utc': now,
    'checker': '/root/local_response_check',
    'direct_scientific_author': '/root',
    'source_pairs': sources,
    'author_source_changed_during_check': False,
    'source_corrections_requested': [],
    'original_checker_confirmation': 'The final live derivation and protocol are byte-identical to the independently read frozen v1 inputs. The conditional proof and stated scope require no amendment in this check.',
    'reused_turnaround_receipt': {'path': str((old_root / 'RECEIPT_v1.json').relative_to(root)), 'sha256': sha(old_root / 'RECEIPT_v1.json'), 'original_pass': 158, 'original_fail': 0, 'new_run': False},
    'producer_code_results_and_other_routes_accessed': False,
    'formal_audit_or_authority_change': False
}
write('FINAL_SOURCE_CONFIRMATION_v1.json', confirmation)
write('SEAL_VALIDATION_v1.json', {
    'created_utc': now,
    'scope': 'metadata only; no science execution',
    'live_snapshot_source_pairs_verified': len(sources),
    'original_dependency_artifacts_verified': len(old_manifest['artifacts']),
    'original_dependency_source_pairs_verified': len(old_manifest['source_pairs']),
    'child_run_records_verified': len(commands),
    'actual_damage_records_verified': len(validation['actual_damages']),
    'misplaced_empty_scratch_path_absent': True,
    'unrecorded_identity_failures': [],
    'preserved_failures': ['CHECKER_REPAIR_v2.json', 'PROCESS_FAILURES_v1.json', 'PRESEAL_READ_FAILURE_v1.json'],
    'seal_command': seal_command
})
excluded = ['MANIFEST_v1.json', 'RECEIPT_v1.json']
artifacts = [bind(p) for p in sorted(here.rglob('*')) if p.is_file() and str(p.relative_to(here)) not in excluded]
manifest = {
    'created_utc': now, 'unit': str(here.relative_to(root)),
    'artifact_count': len(artifacts), 'artifacts': artifacts,
    'source_pairs': sources, 'excluded_seal_files': excluded,
    'immutable_after_seal': True
}
write('MANIFEST_v1.json', manifest)
receipt = {
    'created_utc': now,
    'type': 'focused independent blind mathematical check; not formal audit',
    'checker': '/root/local_response_check', 'direct_scientific_author': '/root',
    'unit': str(here.relative_to(root)),
    'report': bind(here / 'REPORT_v1.md'), 'manifest': bind(here / 'MANIFEST_v1.json'),
    'artifact_count': len(artifacts), 'live_source_pair_count': len(sources), 'source_pairs': sources,
    'new_science': {
        'preserved_initial_run': {'pass': 149, 'fail': 2, 'exit_code': 1, 'script': bind(here / 'check_extension_v1.py'), 'result': bind(here / 'independent_extension_results_v1.json'), 'command': bind(here / 'independent_extension_run_v1.json')},
        'corrected_run': {'pass': 153, 'fail': 0, 'exit_code': 0, 'script': bind(here / 'check_extension_v2.py'), 'result': bind(here / 'independent_extension_results_v2.json'), 'command': bind(here / 'independent_extension_run_v2.json')},
        'repair': bind(here / 'CHECKER_REPAIR_v2.json'),
        'no_relabeling_of_old_results': True
    },
    'reused_turnaround_dependency': {'receipt': sources[5], 'manifest': sources[6], 'original_pass': 158, 'original_fail': 0, 'new_run': False, 'artifact_count_verified': 64, 'source_pair_count_verified': 4, 'use': 'endpoint and last-zero chronology lemmas, not an unchanged invocation of the old exact-turnaround hypothesis'},
    'actual_damaged_copies': validation['actual_damages'],
    'preserved_failures': [bind(here / x) for x in ['CHECKER_REPAIR_v2.json', 'PROCESS_FAILURES_v1.json', 'PRESEAL_READ_FAILURE_v1.json']],
    'metadata': {'initial_dependency_identity_pass': 71, 'initial_dependency_identity_fail': 0, 'evidence_validation_pass': 148, 'evidence_validation_fail': 0, 'validation': bind(here / 'EVIDENCE_VALIDATION_v1.json'), 'seal_validation': bind(here / 'SEAL_VALIDATION_v1.json'), 'not_science_counts': True},
    'original_reviewer_final_source_confirmation': bind(here / 'FINAL_SOURCE_CONFIRMATION_v1.json'),
    'commands': bind(here / 'COMMANDS_v1.json'), 'seal_command': seal_command,
    'bounded_conclusion': 'The fixed-parameter kinetic completion and coupling bound imply the stated sufficient slow-event obstruction, positive physical-rate lower bound under the supplied bare future target, and duration limits with explicit radius/density cutoffs. No author-source correction was needed.',
    'limitations': ['Candidate supplied action and fixed parameters; no initial-state selection.', 'Regular connected finite intervals, positive conserved radiation and nonnegative other density/enthalpy remain premises.', 'Bare Q/C gravity and future target are not measured calibrations or an empirical likelihood.', 'A fixed positive h_star is not uniform as k approaches the excluded 1/3 parameter boundary.', 'Infinite physical past implications do not prove physical curvature divergence, finite-time singularity, inextendibility or geodesic incompleteness.', 'Prior158/0 is reused, not rerun or added to153/0.', 'One transient out-of-scope empty scratch write was repaired and disclosed; persistent artifacts stay in this unit.'],
    'producer_code_results_or_other_route_accessed': False,
    'git_runtime_settings_authority_or_formal_audit_changes': False,
    'immutable_after_seal': True
}
write('RECEIPT_v1.json', receipt)
# Read-only post-seal verification. No artifact is written after this point.
for item in artifacts:
    p = here / item['path']
    assert p.stat().st_size == item['bytes'] and sha(p) == item['sha256']
actual = {str(p.relative_to(here)) for p in here.rglob('*') if p.is_file()}
assert actual == {item['path'] for item in artifacts} | set(excluded)
assert sha(here / 'MANIFEST_v1.json') == receipt['manifest']['sha256']
assert sha(here / 'REPORT_v1.md') == receipt['report']['sha256']
for pair in sources:
    verify_pair(pair, here)
assert not (root / process['path']).exists()
print(json.dumps({'sealed_utc': now, 'artifact_count': len(artifacts), 'live_source_pairs': len(sources), 'postseal_verification': 'passed', 'new_science': '153/0, prior149/2 preserved', 'damaged_copies_rejected': 6, 'old_science': '158/0 reused, not rerun', 'report': bind(here / 'REPORT_v1.md'), 'manifest': bind(here / 'MANIFEST_v1.json'), 'receipt': bind(here / 'RECEIPT_v1.json')}, indent=2))
