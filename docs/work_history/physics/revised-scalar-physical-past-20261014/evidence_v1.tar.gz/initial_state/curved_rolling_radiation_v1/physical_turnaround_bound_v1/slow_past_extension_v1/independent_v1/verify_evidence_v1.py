from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
here=Path(__file__).resolve().parent
root=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
rows=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(name,ok):rows.append({'name':name,'passed':bool(ok)})
pairs=json.loads((here/'SOURCE_MANIFEST_v1.json').read_text())['sources']
for r in pairs:
 check('live:'+r['original_path'],sha(root/r['original_path'])==r['sha256'])
 check('snapshot:'+r['snapshot_path'],sha(here/r['snapshot_path'])==r['sha256'] and (here/r['snapshot_path']).stat().st_size==r['bytes'])
check('expected_author_source',sha(here/'sources/DERIVATION_v1.md')=='03d231669de0bf27724e653447f2b75b7ad5ef4386b41874059976dd8119c107')
old=here.parent.parent/'independent_v1'
depreceipt=json.loads((old/'RECEIPT_v1.json').read_text());depmanifest=json.loads((old/'MANIFEST_v1.json').read_text())
check('dependency_receipt_seal',sha(old/'RECEIPT_v1.json')=='dd6bf7b35b4f3a037ab1f9f1e3aa85f97c5e081adf0467fb4fcbc16d21a272c0')
check('dependency_manifest_seal',sha(old/'MANIFEST_v1.json')=='56ecb251c7c5b00f46c4c93b2e0fe64fdb85c78ea042d4b15ba8719b596bb8ac')
for r in depmanifest['artifacts']:
 check('reused_artifact:'+r['path'],sha(old/r['path'])==r['sha256'] and (old/r['path']).stat().st_size==r['bytes'])
for r in depreceipt['source_pairs']:
 check('reused_source:'+r['original_path'],sha(root/r['original_path'])==r['sha256']==sha(old/r['snapshot_path']))
check('dependency_reuse_not_rerun',depreceipt['science']['pass']==158 and depreceipt['science']['fail']==0)
v1=json.loads((here/'independent_extension_results_v1.json').read_text());v2=json.loads((here/'independent_extension_results_v2.json').read_text())
check('original_failed_run_preserved',v1['pass']==149 and v1['fail']==2 and {r['name'] for r in v1['checks'] if not r['passed']}=={'flat_example_final_scale','flat_example_final_density'})
check('corrected_actual_run',v2['pass']==153 and v2['fail']==0)
for version,result in [('v1',v1),('v2',v2)]:check('science_code_binding_'+version,result['script_sha256']==sha(here/('check_extension_'+version+'.py')))
repair=json.loads((here/'CHECKER_REPAIR_v2.json').read_text())
check('repair_old_hash',repair['original_sha256']==sha(here/'check_extension_v1.py'))
check('repair_new_hash',repair['corrected_sha256']==sha(here/'check_extension_v2.py'))
process=json.loads((here/'PROCESS_FAILURES_v1.json').read_text())
check('transient_scope_mistake_repaired',process['bytes']==0 and process['path_absent_after_repair'] and not (root/process['path']).exists())
original=here/'check_extension_v2.py';plan=json.loads((here/'DAMAGE_PLAN_v1.json').read_text())
check('damage_base_binding',plan['original_sha256']==sha(original))
damages=[]
for r in plan['cases']:
 p=here/r['path'];name=r['name'];outpath=here/'damages'/(name+'_results_v1.json')
 res=json.loads(outpath.read_text());run=json.loads((here/('damage_'+name+'_run_v1.json')).read_text())
 failed=[x['name'] for x in res['checks'] if not x['passed']]
 check('damage_exact_edit_'+name,p.read_text()==original.read_text().replace(r['original_line']+'\n',r['damaged_line']+'\n'))
 check('damage_code_hash_'+name,sha(p)==r['sha256']==res['script_sha256'])
 check('damage_intended_failure_'+name,run['exit_code']==1 and res['fail']>0 and r['required_failed_check'] in failed)
 damages.append({'name':name,'pass':res['pass'],'fail':res['fail'],'exit_code':run['exit_code'],'script':r['path'],
  'result':outpath.relative_to(here).as_posix(),'command_record':'damage_'+name+'_run_v1.json','required_failed_check':r['required_failed_check'],'failed_checks':failed})
commands=[]
for p in sorted(here.glob('*run*.json')):
 rec=json.loads(p.read_text())
 if 'command' not in rec:continue
 script=Path(rec['command'][2]);check('command_code_'+p.name,script.is_relative_to(here) and sha(script)==rec['script_sha256'])
 for typ in ['stdout','stderr']:
  op=here/rec[typ]['path'];check('command_'+typ+'_'+p.name,sha(op)==rec[typ]['sha256'] and op.stat().st_size==rec[typ]['bytes'])
 expected=1 if p.name.startswith('damage_') or p.name=='independent_extension_run_v1.json' else 0
 check('command_exit_'+p.name,rec['exit_code']==expected and not rec['timed_out'])
 commands.append({'record':p.name,**rec})
out={'created_utc':datetime.now(timezone.utc).isoformat(),'scope':'metadata and dependency identity verification; no science rerun',
 'pass':sum(r['passed'] for r in rows),'fail':sum(not r['passed'] for r in rows),'checks':rows,'source_pairs':pairs,
 'reused_dependency':{'receipt_sha256':sha(old/'RECEIPT_v1.json'),'manifest_sha256':sha(old/'MANIFEST_v1.json'),
  'artifact_count':len(depmanifest['artifacts']),'source_pair_count':len(depreceipt['source_pairs']),'original_science':{'pass':158,'fail':0,'new_run':False}},
 'new_science':{'initial':{'pass':149,'fail':2,'exit_code':1},'corrected':{'pass':153,'fail':0,'exit_code':0}},
 'actual_damages':damages,'commands':commands,'preserved_failures':['CHECKER_REPAIR_v2.json','PROCESS_FAILURES_v1.json'],
 'producer_code_results_or_other_route_accessed':False}
p=here/'EVIDENCE_VALIDATION_v1.json';assert not p.exists();p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'pass':out['pass'],'fail':out['fail'],'source_pairs':len(pairs),
 'damages':[{k:r[k] for k in ['name','pass','fail','exit_code']} for r in damages],
 'failed_metadata':[r for r in rows if not r['passed']]},indent=2))
sys.exit(1 if out['fail'] else 0)
