# Focused canonical correspondence review

The canonical note and runner correspond to the three checked source routes. No additional mathematical correction is required within this focused scope. All three complete proof bodies are preserved after heading nesting. The complete executable bodies, including comments, match after wrapper indentation and the two disclosed turnaround positivity expansions. The new wrapper changes output organization, not the field equations, parameter ranges or theorem premises.

Scientific authorship remains with /root. This is an independent source-correspondence and interaction check, not a formal audit, retained-grade decision, empirical acceptance or campaign-wide validation. No producer scientific code or reused independent scientific checker was executed here.

## Exact canonical scope

The checked canonical note is docs/EXPONENTIAL_SCALAR_PHYSICAL_PAST_BOUNDED_THEOREM_NOTE_2026-10-14.md, SHA-256 117ac20d3408a8e69519d8c87246e05fc389ee7268240e5f2c8c316a78bc897e. The complete runner is scripts/exponential_scalar_physical_past_check.py, SHA-256 8695e05f06a05db0e7ac3cb6006e33015b40f4361278db142013beb5c742fc5c. Both remain unchanged at final source confirmation.

The three source proof identities are:

| Route | Source version | SHA-256 |
|---|---|---|
| Physical stationary event | physical_turnaround_bound_v1/DERIVATION_v1.md | 4fbff5f606381a003802eebf8ee723c80627dc8977a567f177820bc5f3b216ad |
| Gravity calibration | gravity_calibration_v1/DERIVATION_v2.md | 22f51459c09d50b17fa38967595cbf3c8d7608e6020c4720f9251648faa42bb8 |
| Slow physical past | slow_past_extension_v1/DERIVATION_v1.md | 03d231669de0bf27724e653447f2b75b7ad5ef4386b41874059976dd8119c107 |

All are under the campaign initial_state/curved_rolling_radiation_v1/physical_turnaround_bound_v1 directory. The complete canonical action at SHA 39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000 supplies the action, positive kinetic domain and stress/frame normalization. Its separate spatially flat future-confinement theorem is not silently imported as a proof of the present result. The local-response and curvature notes were read for the actual supplied normalization and example scope; their complete bytes are included among the four cache inputs. The new canonical note does not claim to derive that action, its three fields, k, nu, Q0, Hv, matter/thermal state or initial data.

The complete canonical text and source proofs were read. The original checkers were fully parsed, their complete bodies compared both as AST and as text, and their wrappers, version diffs, run records and output rows inspected. Reused independent reports and hand derivations were read fully. Their code and commands are recovered and hash-verified, but are not represented as newly line-by-line reaudited or rerun. The cache utility was inspected for the relevant identity, fingerprint, execution and envelope semantics only; this is not a review of its unrelated code or authority machinery.

## Code, row and execution correspondence

The canonical turnaround function matches check_turnaround_v1.py, SHA 3fd4679d7304b5efbf16a1c311e6a39e5e3732d2370b62333d24b43a563f054f, after exactly the two declared S.expand substitutions before is_positive. The calibration function matches check_calibration_v2.py, SHA 7482368aaff66ea1ccd1420cb17818f05a00fa3c6c4ce56684e8b61893dc4c3d, without body changes. The slow-past function matches check_slow_past_v2.py, SHA a02241f0d31e753124647ac4ac00536336790258cf71571ed15a5235389b4434, without body changes. Each function has isolated local rows and returns them; the main entrypoint prefixes names and sums the actual Boolean outcomes.

All 158 cached check objects match the corrected source objects, including their detail strings: 40 turnaround, 66 calibration and 52 slow-past. Names are unique. The raw execution JSON and cache stdout JSON are identical. The cache's source hash, declared 120-second timeout, recorded successful exit and four-input fingerprint match. The independently reconstructed fingerprint is 65763b4a7634a545eb3ad6f846849b08e12b1135f928fe419f05bf6acebac1bb. This is identity verification of a disclosed parent execution, not another independent scientific pass count. The raw record has empty stderr and its stdout parses as the complete JSON result.

One deliberate output difference is retained explicitly: the source calibration result also serializes 36 synthetic example records. The canonical wrapper calculates the same example loop and retains its assertions, but does not serialize that separate table. Both original RESULTS_v1.json and RESULTS_v2.json tables are preserved byte-for-byte in this review's snapshots; the 36 records are exactly equal between those source versions. Thus the canonical cache should not be described as containing the complete original example table. This does not change the theorem or the 66 assertions and requires no source repair for the stated canonical purpose.

The initial producer outcomes remain recoverable:

| Producer route | Preserved original outcome | Disclosed repair and canonical correspondence |
|---|---:|---|
| Turnaround | 38 passed / 2 failed | Unexpanded positivity predicates were undecided; separate exact expansion returned 2/0. Only these two Booleans differ in the canonical 40 rows. |
| Calibration | 65 / 1 | The negative-u exponential sign query was undecided. A zero-value plus strictly positive derivative certificate changes exactly that row to pass; the 36 example values are unchanged. |
| Slow-past | 49 / 1 | The undecided completed-square sign query is replaced by an exact square/slack identity and positive remainder check; a separate threshold/minimum identity is added. All 49 common rows remain exactly equal. |

The four actual altered calibration sources and four actual altered slow-past sources, their exact one-expression diffs, source hashes, recorded exit 1 and failed result rows were inspected and preserved. These are reused producer sensitivity evidence, not eight new executions by this reviewer. The canonical note accurately discloses the original failures, repairs and reused status of its execution.

## Mathematical and physical interactions

The supplied action has -Q K_AB partial(phi^A)partial(phi^B), so homogeneous rho_phi=Q|dot(phi)|_K^2+V and rho_phi+p_phi=2Q|dot(phi)|_K^2. The bound q=a/J<1/3 is a consequence of that finite-field metric at fixed 0<k<1/3. With Hv>0 and nu>0 the full potential has V>=3QHv^2>0, independently of x,y. The source and canonical note use the same normalization throughout.

The physical stationary-event proof obtains positive curvature rather than assuming it. Its final expanding near-flat event has H_E>0. The finite-interval last-zero lemma permits a degenerate derivative and needs only Hdot>=0 at that zero; strict final Einstein-radius growth supplies the strict >2 branch. It does not replace the last zero by the first, divide by H at a zero, or identify an H-normalized radiation fraction with an energy fraction at a turning point. The protocol's earlier ambiguous spatial-closure wording is preserved and its v2 correction is bound by the original independent receipt.

The physical transformations are a_J=A a_E, H_J=Z/A and rho_r,E=C^2 rho_r,J. Consequently d_J=kappa/Z^2 and F_bare=3QZ^2/rho_r,E. Their product is 3Qkappa/rho_r,E. The bare coefficient is Q/C in the R_J/2 convention; it is not automatically a measured local gravitational constant.

The slow-past result reuses the endpoint and chronology lemmas only after its new square completion supplies the required earlier positive-curvature and f_b<1 conclusion. It does not invoke the exact-stationary-event theorem verbatim while dropping its hypothesis. The sign inside the square, the division by C in the physical-clock threshold, and the factor 12 in h_*^2 are consistent. The coupling-only minimum is interior because 1/4<a<1/3. At fixed parameters h_*>0 uniformly over finite fields, including arbitrarily close approaches to the conformal boundaries; there is no common positive bound as k approaches the excluded 1/3 endpoint. The final bare target and continuity force positive H_J throughout the connected past interval. The duration is measured in physical proper time and additionally requires a positive radius lower bound or a radiation-density upper bound. Hv and those cutoffs are supplied scales. Neither an absolute age nor geodesic incompleteness follows.

The local coefficient G_pr=C(1+q)/(8 pi Q) is restricted to the stated weak, nonrelativistic, locally frozen principal response. Its massive extension additionally requires the stipulated nonnegative self-adjoint squared-mass operator and forced solution. The note does not claim that arbitrary rolling backgrounds or finite bodies satisfy those assumptions. The positive spectral weights and the differentiated Yukawa force factor belong to this conditional model.

In the calibration section gamma means G_cal/G_bare,c, not a PPN parameter. The final source explicitly requires G_cal>0, hence gamma>0. This was a genuine v1 domain omission in the route using only an externally supplied upper-error ceiling: such a ceiling alone also permits zero or negative coefficients. The v2 qualification is copied completely. With positivity, division gives the stated strict product bounds and C_c<Ccrit. At a different finite background the absolute principal ceiling is exact action algebra, not an exact ceiling on every experiment. The energy floor applies only for 0<Ccrit<1 and is Einstein scalar energy. It neither constructs an environment nor rules out large early scalar energy. The negative-u monotonicity is valid for every nu>0; an unrestricted positive-u extension is not asserted.

The new note contains no observational data read, likelihood, empirical fit or independent-test claim. The runner imports only its stated symbolic/standard-library tools and constructs exposed rational examples. Epsilon, delta, eta, the local approximation and the future radiation-law target remain supplied conditions. Present near-flatness and positive CMB radiation alone do not establish that target. The Coc citation is development context and is not an imported numerical calibration or a new primary-paper read by this reviewer.

The metadata says proposed_retained while explicitly stating actual current surface status conditional-support. The note disclaims a formal audit verdict, empirical exclusion and completed unification. This correspondence check assigns no effective grade and inspects or changes no audit authority. It also makes no claim about unexamined repository changes outside the pinned source set.

## Independent evidence reused and newly produced

The full final reports, hand derivations, code, command records, outputs, failures and seals of all three focused independent reviews are captured. Their exact receipt hashes are:

| Reused focused review | Final receipt SHA-256 |
|---|---|
| Physical turnaround | dd6bf7b35b4f3a037ab1f9f1e3aa85f97c5e081adf0467fb4fcbc16d21a272c0 |
| Gravity calibration | c469038e0f353d01f0c311108900b6ebfc2972ab73bafa5f442ebe2edbe2065f |
| Slow physical past | 85024e185781b0ddce1d00f8a1c7821396abc3d36f4d7b5d3cfd00c61dedb78b |

The physical-turnaround review's 158/0 and six actual damaged-copy failures remain its own evidence. Calibration's 75/0 plus 12/0 narrow supplement and eight damaged-copy failures remain its own evidence. Slow-past's corrected 153/0 and six damaged-copy failures remain its own evidence; its initial 149/2 symbolic-reduction failure is preserved rather than hidden. That review also preserves a transient empty-file write outside its allowed directory, its removal, and a later diagnostic TypeError. These are not represented as compliant or successful original operations. No author proof equation changed in that slow review. Reused counts are not added together as new science here.

This review executed its own standard-library correspondence checker once: 95 passed / 0 failed. Those include 48 exact-rational assertions across 12 independently selected finite states, checking the action domain, calibration ceiling, slow threshold and completed-square curvature margin without importing producer helpers. The remaining assertions check source, cache and complete result correspondence. A separate complete-body text comparison, including comments, found all three bodies identical after their declared transformations. A separate review-seal verifier then passed 266/0 artifact and source-binding checks. Those are metadata checks, not new scientific results. No newly executed checker failed in this correspondence unit. The initial rg no-match exit is recorded as an inspection outcome, not a scientific failure.

All 327 captured original paths and exact recovery copies are listed in SOURCE_DISPOSITIONS_v1.json. The first capture contains 169 files; the calibration and slow review captures add 85 and 73 files respectively. No primary PDF is included. The recovery scope includes all proof/checker/version/command/result files needed to reproduce the stated correspondence and reused evidence. Original raw bytes and every reported failure remain unchanged.

## Final binding

The final files for this unit are exactly CORRESPONDENCE_REVIEW_v1.md, FINAL_MANIFEST_v1.json and FINAL_RECEIPT_v1.json. The manifest binds the complete persistent review tree except itself and the final receipt. The receipt binds this exact report, that manifest, the three input captures, both actual reviewer executions, complete text comparison, source dispositions and the three reused final review receipts. It does not point to a prior report version. No scientific rerun or source modification is needed to reproduce the byte checks.

All new persistent files in this unit are confined to physical_past_canonical_correspondence_v1. No parent source, earlier seal, Git state, external runtime/lock, PR, model, audit authority or external chat was modified. Coordination was only with the parent agent. The disposition is support for the exact canonical correspondence and stated conditional mathematics; state selection, local environmental matching, measured calibration, thermal likelihoods and unrestricted past-history conclusions remain outside it.
