"""Read-only canonical/source correspondence; never import or run producer code."""
from pathlib import Path
from fractions import Fraction as F
import ast
import hashlib
import json
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT = Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
PACK = '.claude/science/physics-loops/revised-scalar-derivation-24h-20261013'
BASE = PACK + '/initial_state/curved_rolling_radiation_v1/physical_turnaround_bound_v1'
rows = []

def data(rel):
    return (HERE / 'source_snapshot' / rel).read_bytes()

def text(rel):
    return data(rel).decode()

def obj(rel):
    return json.loads(data(rel))

def digest(b):
    return hashlib.sha256(b).hexdigest()

def ck(name, value, detail=None):
    rows.append(dict(name=name, passed=bool(value), detail=detail))

def astlist(nodes):
    return [ast.dump(n, include_attributes=False) for n in nodes]

note_rel = 'docs/EXPONENTIAL_SCALAR_PHYSICAL_PAST_BOUNDED_THEOREM_NOTE_2026-10-14.md'
runner_rel = 'scripts/exponential_scalar_physical_past_check.py'
note = text(note_rel)
runner = text(runner_rel)
lineage = obj(PACK + '/physical_past_packaging/CANONICAL_LINEAGE_v1.json')
ck('lineage.note_hash', digest(data(note_rel)) == lineage['note_sha256'])
ck('lineage.runner_hash', digest(data(runner_rel)) == lineage['runner_sha256'])

parts = [
    ('turnaround', '## I. Finite physical stationary event', '## II. Quantitative slow past and bounded duration', 'DERIVATION_v1.md'),
    ('slow_past', '## II. Quantitative slow past and bounded duration', '## III. Local calibration and environment energy requirement', 'slow_past_extension_v1/DERIVATION_v1.md'),
    ('calibration', '## III. Local calibration and environment energy requirement', '## Computation, provenance and surviving inputs', 'gravity_calibration_v1/DERIVATION_v2.md'),
]
note_correspondence = []
for unit, start, end, source in parts:
    original = text(BASE + '/' + source)
    expected = '\n'.join(original.splitlines()[1:]).strip()
    expected = re.sub(r'^## ', '### ', expected, flags=re.M)
    actual = note.split(start, 1)[1].split(end, 1)[0].strip()
    ck('note.complete_body.' + unit, actual == expected)
    note_correspondence.append(dict(unit=unit, original_sha256=digest(original.encode()), canonical_body_sha256=digest(actual.encode()), expected_body_sha256=digest(expected.encode())))

tree = ast.parse(runner)
functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
block_correspondence = []
for item in lineage['mathematics_lineage']:
    original = text(item['source'])
    ck('lineage.source_hash.' + item['unit'], digest(original.encode()) == item['sha256'])
    fragment = original.split(item['start_marker'], 1)[1].split(item['end_marker'], 1)[0]
    fragment = item['start_marker'] + fragment
    before_ast = astlist(ast.parse(fragment).body)
    for old, new in item['body_changes']:
        ck('lineage.unique_patch.' + item['unit'] + '.' + old, fragment.count(old) == 1)
        fragment = fragment.replace(old, new, 1)
    expected_ast = astlist(ast.parse(fragment).body)
    fn = functions['check_' + item['unit']]
    ck('wrapper.local_rows.' + item['unit'], ast.dump(fn.body[0], include_attributes=False) == ast.dump(ast.parse('rows=[]').body[0], include_attributes=False))
    ck('wrapper.returns_rows.' + item['unit'], ast.dump(fn.body[-1], include_attributes=False) == ast.dump(ast.parse('return rows').body[0], include_attributes=False))
    actual_ast = astlist(fn.body[1:-1])
    ck('code.complete_ast.' + item['unit'], actual_ast == expected_ast)
    block_correspondence.append(dict(unit=item['unit'], ast_statements=len(actual_ast), original_body_identical_before_declared_changes=(before_ast == actual_ast), final_body_identical=(expected_ast == actual_ast), declared_changes=item['body_changes']))

declared = next(ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'AUDIT_INPUT_PATHS' for t in n.targets))
fp = hashlib.sha256(b'runner-cache-input-fingerprint-v1\0')
for rel in declared:
    rb = rel.encode(); bb = data(rel)
    fp.update(len(rb).to_bytes(8, 'big')); fp.update(rb)
    fp.update(len(bb).to_bytes(8, 'big')); fp.update(bb)
cache = text('logs/runner-cache/exponential_scalar_physical_past_check.txt')
header, tail = cache.split('----- stdout -----\n', 1)
stdout, stderr = tail.split('----- stderr -----\n', 1)
heads = dict(line.split(': ', 1) for line in header.splitlines() if ': ' in line)
ck('cache.runner_hash', heads['runner_sha256'] == digest(data(runner_rel)))
ck('cache.input_fingerprint', heads['input_fingerprint_sha256'] == fp.hexdigest())
ck('cache.success_envelope', heads['exit_code'] == '0' and heads['status'] == 'ok' and heads['timeout_sec'] == '120')
canonical = json.loads(stdout)
execution = obj(PACK + '/physical_past_packaging/CACHE_RUN_v1.json')['execution']
ck('cache.raw_json_identity', canonical == json.loads(execution['stdout']))
ck('cache.empty_stderr', not stderr.strip() and not execution['stderr'])
ck('cache.result_source_identity', canonical['checker_sha256'] == digest(data(runner_rel)))
ck('cache.actual_census', len(canonical['checks']) == canonical['passed'] + canonical['failed'] == 158 and canonical['failed'] == 0)
ck('cache.unique_names', len({r['name'] for r in canonical['checks']}) == len(canonical['checks']))

expected_units = {'turnaround': ('RESULTS_v1.json', 40), 'calibration': ('gravity_calibration_v1/RESULTS_v2.json', 66), 'slow_past': ('slow_past_extension_v1/RESULTS_v2.json', 52)}
changes = []
for unit, (rel, count) in expected_units.items():
    original = obj(BASE + '/' + rel)
    actual = [{**r, 'name': r['name'].split('::', 1)[1]} for r in canonical['checks'] if r['name'].startswith(unit + '::')]
    expected = [dict(r) for r in original['checks']]
    if unit == 'turnaround':
        repair = obj(BASE + '/POSITIVITY_RESULTS_v2.json')
        repaired_names = {r['name'] for r in repair['checks'] if r['positive']}
        for r in expected:
            if r['name'] in repaired_names:
                changes.append(dict(unit=unit, name=r['name'], before=r['passed'], after=True))
                r['passed'] = True
    ck('rows.all_fields_equal.' + unit, actual == expected)
    ck('rows.unit_count.' + unit, len(actual) == count and canonical['units'][unit] == dict(passed=count, failed=0))

cal1 = obj(BASE + '/gravity_calibration_v1/RESULTS_v1.json')
cal2 = obj(BASE + '/gravity_calibration_v1/RESULTS_v2.json')
ck('repair.calibration_examples_unchanged', cal1['synthetic_examples'] == cal2['synthetic_examples'] and len(cal2['synthetic_examples']) == 36)
caldiff = [(a, b) for a, b in zip(cal1['checks'], cal2['checks']) if a != b]
ck('repair.calibration_only_expected_row', len(caldiff) == 1 and caldiff[0][0]['name'] == 'negative_u_derivative_term_0' and caldiff[0][0]['passed'] is False and caldiff[0][1]['passed'] is True)
slow1 = obj(BASE + '/slow_past_extension_v1/RESULTS_v1.json')
slow2 = obj(BASE + '/slow_past_extension_v1/RESULTS_v2.json')
s1 = {r['name']: r for r in slow1['checks']}; s2 = {r['name']: r for r in slow2['checks']}
ck('repair.slow_old_49_rows_unchanged', all(s1[n] == s2[n] for n in s1.keys() & s2.keys()) and len(s1.keys() & s2.keys()) == 49)
ck('repair.slow_exact_add_remove', s1.keys() - s2.keys() == {'strict_slow_gap_after_completion'} and s2.keys() - s1.keys() == {'strict_slow_gap_exact_certificate', 'strict_slow_gap_positive_remainder', 'threshold_is_exact_coupling_minimum'})

producer_mutations = []
for sub, source in [('gravity_calibration_v1', 'check_calibration_v2.py'), ('slow_past_extension_v1', 'check_slow_past_v2.py')]:
    rel_dir = BASE + '/' + sub + '/damages_v1'
    for path in sorted((HERE / 'source_snapshot' / rel_dir).glob('*_RESULTS.json')):
        result = json.loads(path.read_bytes()); stem = path.name[:-len('_RESULTS.json')]
        script = path.parent / (stem + '.py')
        run = obj(BASE + '/' + sub + '/' + stem + '_RUN.json')
        ck('preserved_mutant.' + sub + '.' + stem, result['checker_sha256'] == digest(script.read_bytes()) and result['failed'] > 0 and run['exit_code'] == 1)
        producer_mutations.append(dict(unit=sub, name=stem, passed=result['passed'], failed=result['failed'], intended_failures=[r['name'] for r in result['checks'] if not r['passed']], source_sha256=digest(script.read_bytes())))

# Distinct exact-rational cross-block checks, not a replay of producer helpers.
exact_rows = []
for k in [F(1,17), F(2,9), F(3,10)]:
    a = (1-k)*(1+3*k)/4; s = (1+k)/(k*(1-3*k)); cm = (1+s)/s
    for e in [F(1,20), F(1), F(7,3), F(100)]:
        c = (1+s)*e/(1+s*e); q = a/(1+(1-3*a)*s*e); chi = s*(c-1)
        norm = c*(1+q)/(1+k); b = 4*k*k*(1-3*k)/(1+k)**2
        floor = 12*a*(1-3*a)/cm
        ck('rational.action_domain.' + str((k,e)), 0<q<a<F(1,3) and 0<c<cm and -s<chi<1)
        ck('rational.global_ceiling.' + str((k,e)), norm == 1-b*chi*chi/(1-3*k*chi) and 0<norm<=1)
        ck('rational.slow_threshold.' + str((k,e)), (1-3*q)/c >= floor > 0)
        Q=F(5,7); Z=F(9,10); L=F(-1,3); wp=F(2,9); rm=F(1,5); rho=F(11,8)
        velocity=L*L/q+wp; V=3*Q*Z*Z/(1-3*q)+1
        kap=(Q*velocity+V+rho+rm)/(3*Q)-(Z-L)**2
        square=wp+(1-3*q)/q*(L+3*q*Z/(1-3*q))**2-3*Z*Z/(1-3*q)
        ck('rational.positive_slow_gap.' + str((k,e)), velocity-3*(Z-L)**2 == square and 3*Q*kap-rho>0)
        exact_rows.append({key:str(value) for key,value in dict(k=k,E=e,C=c,q=q,chi=chi,calibration=norm,threshold_squared_over_Hv_squared=floor,curvature_gap=3*Q*kap-rho).items()})

inputs = json.loads((HERE/'INPUT_FREEZE_v1.json').read_text())['inputs']
ck('source_snapshot.identity', all(digest(Path(x['snapshot']).read_bytes()) == x['sha256'] for x in inputs))
ck('live_original.identity', all(digest(Path(x['original_path']).read_bytes()) == x['sha256'] for x in inputs))
result = dict(scope='Canonical source/row/lineage correspondence plus explicitly limited rational cross-block controls; no producer execution or audit.', passed=sum(r['passed'] for r in rows), failed=sum(not r['passed'] for r in rows), checks=rows, note_correspondence=note_correspondence, code_correspondence=block_correspondence, parent_scientific_result_reuse=dict(units=canonical['units'], counts_are_not_independent_reexecution=True, exact_changed_turnaround_rows=changes, original_36_calibration_example_rows_preserved=True, canonical_omits_separate_synthetic_examples_table=True), preserved_parent_mutations=producer_mutations, distinct_exact_rational_rows=exact_rows, input_fingerprint=fp.hexdigest(), checker_sha256=digest(Path(__file__).read_bytes()))
out=Path(sys.argv[1]);assert not out.exists()
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['passed','failed']}))
for r in rows:
    if not r['passed']:print(json.dumps(r))
raise SystemExit(1 if result['failed'] else 0)
