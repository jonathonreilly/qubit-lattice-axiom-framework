"""One-shot final byte seal; only writes new files in this review directory."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def pin(p):
    return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))

def write_new(name, data):
    p=HERE/name
    with p.open('x') as f:
        f.write(json.dumps(data,indent=2)+'\n')
    return p

captures=['INPUT_FREEZE_v1.json','CALIBRATION_REVIEW_CAPTURE_v1.json','SLOW_REVIEW_CAPTURE_v1.json']
all_inputs={}
for name in captures:
    capture=json.loads((HERE/name).read_bytes())
    for row in capture['inputs']:
        old=all_inputs.get(row['original_path'])
        assert old is None or old['sha256']==row['sha256']
        assert sha(Path(row['original_path']))==row['sha256']==sha(Path(row['snapshot'])),row['original_path']
        all_inputs[row['original_path']]=row
assert len(all_inputs)==327

result=json.loads((HERE/'CORRESPONDENCE_RESULTS_v1.json').read_bytes())
bindings=json.loads((HERE/'REUSED_REVIEW_BINDINGS_v1.json').read_bytes())
textcheck=json.loads((HERE/'TEXT_CORRESPONDENCE_v1.json').read_bytes())
assert result['passed']==95 and result['failed']==0
assert bindings['passed']==266 and bindings['failed']==0
assert all(r['identical_text_after_indentation_and_declared_changes'] for r in textcheck['rows'])
for name in ['CHECK_EXECUTION_v1.json','BINDING_EXECUTION_v1.json']:
    execution=json.loads((HERE/name).read_bytes())
    assert execution['exit_code']==0 and execution['checker_unchanged']

dispositions=[]
for original,row in sorted(all_inputs.items()):
    if '/independent_v1/' in original:
        role='Preserved exact completed prior focused-review evidence; report/derivation read and sealed artifact/source bindings checked; scientific code not rerun or relabeled as new evidence.'
    elif original.endswith('exponential_scalar_physical_past_check.py'):
        role='Complete canonical runner read; all mathematical bodies checked as text and AST; full saved row and cache identity verified without producer execution.'
    elif original.endswith('EXPONENTIAL_SCALAR_PHYSICAL_PAST_BOUNDED_THEOREM_NOTE_2026-10-14.md'):
        role='Complete canonical note read; all three proof sections matched and interactions/domains checked.'
    elif '/docs/' in original:
        role='Supplied conditional dependency preserved; action/readout/context roles inspected. Separate results not globally recertified.'
    elif original.endswith('runner_cache.py'):
        role='Full utility bytes preserved; relevant fingerprint, identity and envelope functions inspected only; no cache API or audit invocation.'
    else:
        role='Original producer proof/protocol/code/correction/command/result or lineage evidence preserved; relevant full source, changes and result rows consumed for correspondence, not rerun.'
    dispositions.append(dict(original_path=original,original_sha256=row['sha256'],disposition=role,recovery=row['snapshot'],final_path=original,final_sha256=sha(Path(original))))
write_new('SOURCE_DISPOSITIONS_v1.json',dict(created_at_utc=datetime.now(timezone.utc).isoformat(),count=len(dispositions),sources=dispositions,all_final_bytes_match=True,excluded_primary_pdf='Coc et al. PDF is not copied or claimed independently read; no primary numerical observation enters this correspondence.'))

write_new('FAILURES_AND_QUALIFICATIONS_v1.json',dict(
    newly_executed_checker_failures=[],
    inspection_no_match=dict(tool_chunk_id='f96251',exit_code=1,meaning='rg found no matching extra guidance files in scoped directories; not a mathematical or source failure.'),
    preserved_producer_failures=[dict(route='turnaround',passed=38,failed=2,repair='Separate exact expansion 2/0; canonical substitutes only the two predicates.'),dict(route='calibration',passed=65,failed=1,repair='Exact calculus certificate; v2 66/0.'),dict(route='slow_past',passed=49,failed=1,repair='Square/slack and threshold/minimum certificates; v2 52/0.')],
    preserved_prior_independent_failures=dict(slow_past_original=dict(passed=149,failed=2,corrected_passed=153,corrected_failed=0),slow_past_process='Transient empty placeholder outside the prior reviewer scope was removed; original PROCESS_FAILURES_v1.json preserved. This prior operation is not represented as compliant.',slow_past_read_diagnostic='TypeError on len(integer) preserved with corrected type-aware read; no source change.'),
    prior_domain_corrections=['Turnaround protocol v2 clarifies closed finite time interval; spatial curvature is derived.','Calibration source v2 explicitly requires positive G_cal/gamma under an externally supplied upper error ceiling.'],
    output_scope='Canonical cache contains all 158 check objects but not the separate 36-row synthetic calibration table; exact original tables are recovered.',
    source_recovery_scope='327 distinct input paths; all byte-identical at final verification. Reused independent controls are not new execution.'))

write_new('COMMAND_INDEX_v1.json',dict(
    scope='Commands and reusable code necessary for the new checks; original producer and reused review command records are inside source_snapshot.',
    actual_new_executions=[dict(command='CHECK_COMMAND_v1.json',execution='CHECK_EXECUTION_v1.json',source='check_correspondence_v1.py',stdout='CHECK_STDOUT_v1.txt',stderr='CHECK_STDERR_v1.txt',result='CORRESPONDENCE_RESULTS_v1.json'),dict(command='BINDING_COMMAND_v1.json',execution='BINDING_EXECUTION_v1.json',source='verify_reused_review_bindings_v1.py',stdout='BINDING_STDOUT_v1.txt',stderr='BINDING_STDERR_v1.txt',result='REUSED_REVIEW_BINDINGS_v1.json')],
    text_comparison=dict(tool_chunk_id='aa4a82',source_archive='text_correspondence_executed_stdin_v1.py',result='TEXT_CORRESPONDENCE_v1.json',execution_form='python3 stdin',producer_execution=False,source_archive_written_after_execution=True),
    capture_commands=[dict(tool_chunk_id='296e97',record='INPUT_FREEZE_v1.json'),dict(tool_chunk_id='5ba91f',record='CALIBRATION_REVIEW_CAPTURE_v1.json'),dict(tool_chunk_id='48d97b',record='SLOW_REVIEW_CAPTURE_v1.json')],
    full_reads=['7005f0','38ee9f','ef8154','add068','205439','ba3b47','0b64a6','1a0378','48d97b','30b222'],
    relevant_cache_utility_reads=['e609d4','14eeb8'],
    producer_damage_diff_read='dc13cf',
    seal_command='SEAL_COMMAND_v1.json'))

report=HERE/'CORRESPONDENCE_REVIEW_v1.md'
assert report.is_file() and report.read_bytes().endswith(b'\n') and not report.read_bytes().endswith(b'\n\n')
excluded={'FINAL_MANIFEST_v1.json','FINAL_RECEIPT_v1.json'}
artifacts=[]
for p in sorted(HERE.rglob('*')):
    if p.is_file() and p.relative_to(HERE).as_posix() not in excluded:
        artifacts.append(dict(path=p.relative_to(HERE).as_posix(),bytes=p.stat().st_size,sha256=sha(p)))
manifest=write_new('FINAL_MANIFEST_v1.json',dict(created_at_utc=datetime.now(timezone.utc).isoformat(),artifact_root=str(HERE),artifact_count=len(artifacts),artifacts=artifacts,excluded_seal_files=sorted(excluded),source_count=len(all_inputs),report=pin(report),scope='Focused canonical correspondence and exact recovery; no audit authority.'))
receipt=write_new('FINAL_RECEIPT_v1.json',dict(created_at_utc=datetime.now(timezone.utc).isoformat(),unit=str(HERE),scientific_author='/root',focused_checker='/root/direct_field_check',report=pin(report),manifest=pin(manifest),source_dispositions=pin(HERE/'SOURCE_DISPOSITIONS_v1.json'),artifact_count=len(artifacts),captured_original_count=len(all_inputs),captures=[pin(HERE/n) for n in captures],new_checks=dict(correspondence=dict(passed=95,failed=0,result=pin(HERE/'CORRESPONDENCE_RESULTS_v1.json')),complete_text_bodies=dict(equal=3,total=3,result=pin(HERE/'TEXT_CORRESPONDENCE_v1.json')),reused_binding_metadata=dict(passed=266,failed=0,result=pin(HERE/'REUSED_REVIEW_BINDINGS_v1.json'))),reused_independent_reviews=bindings['reused_reviews'],preserved_failures=pin(HERE/'FAILURES_AND_QUALIFICATIONS_v1.json'),command_index=pin(HERE/'COMMAND_INDEX_v1.json'),no_producer_or_prior_science_rerun=True,formal_audit=False,formal_grade_assigned=False,landing_authority=False,conclusion='The pinned canonical note/code and saved outcomes correspond to the corrected original three routes within their explicit conditional domains; no new material source correction identified.',limits=['No observed target or empirical fit/acceptance.','No derivation of action, scales, state or thermal history.','Local calibration remains a specified approximation with positive coefficient and separately supplied error bound.','No generic singularity, geodesic or unbounded-history exclusion outside the stated hypotheses.'],final_filenames=['CORRESPONDENCE_REVIEW_v1.md','FINAL_MANIFEST_v1.json','FINAL_RECEIPT_v1.json']))
for item in artifacts:
    assert sha(HERE/item['path'])==item['sha256'],item['path']
for field in ['report','manifest','source_dispositions','preserved_failures','command_index']:
    item=json.loads(receipt.read_bytes())[field]
    assert sha(Path(item['path']))==item['sha256'],field
print(json.dumps(dict(report=pin(report),manifest=pin(manifest),receipt=pin(receipt),artifacts=len(artifacts),sources=len(all_inputs)),indent=2))
