from pathlib import Path
from datetime import datetime,timezone
import ast,json,hashlib,textwrap,difflib
p=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go/.claude/science/physics-loops/revised-scalar-derivation-24h-20261013/physical_past_canonical_correspondence_v1')
s=p/'source_snapshot';lineage=json.loads((s/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013/physical_past_packaging/CANONICAL_LINEAGE_v1.json').read_text());runner=(s/lineage['runner']).read_text();lines=runner.splitlines(True);tree=ast.parse(runner);rows=[]
for item in lineage['mathematics_lineage']:
 original=(s/item['source']).read_text();fragment=item['start_marker']+original.split(item['start_marker'],1)[1].split(item['end_marker'],1)[0]
 for before,after in item['body_changes']:fragment=fragment.replace(before,after,1)
 fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='check_'+item['unit'])
 actual=textwrap.dedent(''.join(lines[fn.body[1].lineno-1:fn.body[-1].lineno-1])).strip();expected=fragment.strip()
 rows.append({'unit':item['unit'],'identical_text_after_indentation_and_declared_changes':actual==expected,'diff':''.join(difflib.unified_diff(expected.splitlines(True),actual.splitlines(True),fromfile='declared_original',tofile='canonical')),'actual_body_sha256':hashlib.sha256(actual.encode()).hexdigest(),'expected_body_sha256':hashlib.sha256(expected.encode()).hexdigest()})
record={'created_at_utc':datetime.now(timezone.utc).isoformat(),'scope':'Complete body text, including comments, not only AST; surrounding function indentation and strip of outer blank lines are the sole additional normalization. No producer execution.','command':'Python stdlib ast locates function body line spans; textwrap.dedent removes wrapper indentation; compare against original start/end markers plus declared substitutions.','rows':rows}
out=p/'TEXT_CORRESPONDENCE_v1.json'
with out.open('x') as f:f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
