"""Verify captured independent review seals without executing their science."""
from pathlib import Path
import hashlib
import json
import sys

HERE=Path(__file__).resolve().parent
ROOT=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
BASE=Path('.claude/science/physics-loops/revised-scalar-derivation-24h-20261013/initial_state/curved_rolling_radiation_v1/physical_turnaround_bound_v1')
SNAP=HERE/'source_snapshot'
records=[]
checks=[]

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def ck(name, value, detail=None):
    checks.append(dict(name=name,passed=bool(value),detail=detail))

def paired_path(relative):
    rel=Path(relative)
    if rel.is_absolute():
        rel=rel.relative_to(ROOT)
    return ROOT/rel,SNAP/rel

for suffix in ['independent_v1','gravity_calibration_v1/independent_v1','slow_past_extension_v1/independent_v1']:
    rel=BASE/suffix
    live,base=paired_path(rel)
    manifest=json.loads((base/'MANIFEST_v1.json').read_bytes())
    receipt=json.loads((base/'RECEIPT_v1.json').read_bytes())
    ck(suffix+'.receipt_live_identity',sha(live/'RECEIPT_v1.json')==sha(base/'RECEIPT_v1.json'))
    for name in ['report','manifest']:
        pin=receipt[name]
        ck(suffix+'.'+name+'_binding',sha(base/pin['path'])==pin['sha256'] and (base/pin['path']).stat().st_size==pin['bytes'])
    artifacts=manifest['artifacts']
    ck(suffix+'.artifact_census',len(artifacts)==manifest['artifact_count'])
    for pin in artifacts:
        saved=base/pin['path'];actual=live/pin['path']
        ck(suffix+'.artifact.'+pin['path'],sha(saved)==pin['sha256']==sha(actual) and saved.stat().st_size==pin['bytes'])
    pairs=receipt.get('source_pairs',receipt.get('source_bindings',[]))
    for pin in pairs:
        actual,saved=paired_path(pin['original_path'])
        recovery=base/pin['snapshot_path']
        ck(suffix+'.source.'+pin['original_path'],sha(actual)==pin['sha256']==sha(recovery))
        if saved.is_file():
            ck(suffix+'.source_double_recovery.'+pin['original_path'],sha(saved)==pin['sha256'])
    records.append(dict(unit=suffix,report=receipt['report'],manifest=receipt['manifest'],receipt_sha256=sha(base/'RECEIPT_v1.json'),artifact_count=len(artifacts),source_pair_count=len(pairs),reuse='Prior independent work, exact-byte preservation and correspondence only; not independently rerun here.'))

result=dict(scope='Independent review identity/coverage verification only; no science execution or authority operation.',passed=sum(r['passed'] for r in checks),failed=sum(not r['passed'] for r in checks),checks=checks,reused_reviews=records,checker_sha256=sha(Path(__file__)))
out=Path(sys.argv[1]);assert not out.exists()
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['passed','failed']}))
for r in checks:
    if not r['passed']:print(json.dumps(r))
raise SystemExit(1 if result['failed'] else 0)
