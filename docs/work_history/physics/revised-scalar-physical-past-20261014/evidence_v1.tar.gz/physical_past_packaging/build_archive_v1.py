from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,datetime
wt=Path.cwd();pk=wt/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013';pack=pk/'physical_past_packaging';dest=wt/'docs/work_history/physics/revised-scalar-physical-past-20261014';dest.mkdir(parents=True,exist_ok=False)
pt='initial_state/curved_rolling_radiation_v1/physical_turnaround_bound_v1'
roots=[pt,'physical_past_canonical_correspondence_v1','physical_past_packaging'];items=[]
# Every input unit must have a final immutable receipt before recovery packaging.
for rel in [pt+'/independent_v1/RECEIPT_v1.json',pt+'/gravity_calibration_v1/independent_v1/RECEIPT_v1.json',pt+'/slow_past_extension_v1/independent_v1/RECEIPT_v1.json','physical_past_canonical_correspondence_v1/RECEIPT_v1.json']:
 assert (pk/rel).is_file(),rel
for root in roots:
 for f in sorted((pk/root).rglob('*')):
  if f.is_dir():continue
  assert f.is_file() and not f.is_symlink(),str(f)
  if '__pycache__' in f.parts or f.suffix=='.pyc' or f.name=='ARCHIVE_BUILD_v1.json':continue
  items.append((f.relative_to(pk).as_posix(),f.read_bytes()))
assert len(set(n for n,b in items))==len(items)
rows=[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in items]
manifest={'schema':'campaign-recovery-manifest-v1','source_roots':roots,'artifact_count':len(rows),'payloads':rows,'scope':'Physical stationary/slow-past conditional theorem, gravity-calibration necessity, exact source/code/results and independent correspondence. No later thermal-trace research or rolling grid included.','exclusions':['Python bytecode/cache; subsequent ARCHIVE_BUILD record of this archive own hash.'],'counts_are_not_new_science':True}
mb=(json.dumps(manifest,indent=2)+'\n').encode();archive=dest/'evidence_v1.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for n,b in items+[('RECOVERY_MANIFEST_v1.json',mb)]:
    assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
    t=tarfile.TarInfo(n);t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)+1
 for row in rows:
  t=tar.getmember(row['path']);assert t.isfile();b=tar.extractfile(t).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
sha=hashlib.sha256(archive.read_bytes()).hexdigest();msha=hashlib.sha256(mb).hexdigest();record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive.relative_to(wt)),'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'payloads':len(rows),'total_members':len(members),'manifest_sha256':msha,'all_payloads_verified':True};(pack/'ARCHIVE_BUILD_v1.json').write_text(json.dumps(record,indent=2)+'\n')
refs=[]
for rel in [pt+'/independent_v1',pt+'/gravity_calibration_v1/independent_v1',pt+'/slow_past_extension_v1/independent_v1','physical_past_canonical_correspondence_v1']:
 for name in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json']:
  f=pk/rel/name;refs.append(rel+'/'+name+' SHA256 '+hashlib.sha256(f.read_bytes()).hexdigest())
readme="""Recovery evidence for the revised scalar physical-past milestone

Live claim: docs/EXPONENTIAL_SCALAR_PHYSICAL_PAST_BOUNDED_THEOREM_NOTE_2026-10-14.md
Scientific author: /root. Conditional support, no formal audit verdict or merge.

Archive SHA256: {sha}
Archive bytes: {size}
Payloads: {count} plus RECOVERY_MANIFEST_v1.json
Internal manifest SHA256: {msha}

The written proofs cover an exact physical stationary event and a sufficient
slow physical expansion event. A stated later bare radiation-law/curvature
target implies a positive lower physical Hubble rate, with a finite duration
if a positive lower radius or upper radiation density is additionally required.
Gravity calibration is conditional on the explicit weak-source response regime,
positive calibration and any separately supplied approximation-error bound.
It does not establish a finite-distance experiment or environment solution.
Action, state, matter, scales and empirical likelihood remain unselected.

The standalone canonical runner158/0 contains40 turning-point,66 calibration
and52 slow-past controls. It reuses and reruns the producer mathematics, with
two exact expansion fixes for undecided SymPy predicates. Original failures
38/2 plus separate2/0,65/1 before66/0, and49/1 before52/0 are retained.
Four actual damaged calibration copies and four slow-past copies are retained.
The general inequalities and chronology proofs are not inferred from counts.

Each focused independent unit preserves its own handwritten proof, sources,
code, results, actual damaged copies, full commands and streams. Source/protocol
qualifications and declared process failures remain in their respective seals.
The independent calibration finding was explicit positivity of G_cal in the
external-error-ceiling route; original and corrected source versions remain.
Counts and source-correspondence scopes are in the complete reports below;
this archive does not reclassify reused checks as new independent calculations.

The saved Coc et al. source is exposed development material for gravity/BBN
readout context, not new empirical evidence or an imported likelihood. No
primordial-abundance fit or measured radius/density cutoff was performed.
Later thermal/charge-transfer research and rolling-grid results are outside
this milestone, including any unreviewed extension of these proof domains.

Recover only validated regular relative members into an empty directory and
verify each manifest size/hash. Every payload was verified at build time.
ARCHIVE_BUILD_v1.json is intentionally outside the archive whose hash it records.
A separate post-commit mapping binds the exact five Git paths and recovery bytes.

Independent and canonical correspondence source identities:
{refs}
""".format(sha=sha,size=archive.stat().st_size,count=len(rows),msha=msha,refs='\n'.join(refs))
(dest/'README.txt').write_text(readme);print(json.dumps(record))
