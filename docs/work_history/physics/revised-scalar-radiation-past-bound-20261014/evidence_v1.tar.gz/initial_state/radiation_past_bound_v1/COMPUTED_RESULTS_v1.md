# Positive-radiation comparison: checked result

The direct exact/quadrature controls pass58/0. They check the supplied-action
origin, kinetic/conformal identities, radiation conservation, comparison
antiderivative, exact action-compatible saturation and constant-curvature
vacuum exception. Twelve positive-extra-density comparison integrals in four
specified scale settings support the stated inequality; they are comparison
functions, not computed rolling scalar histories or independent observations.
The sharper positive-vacuum bound is below the radiation-only coarse bound.

The independently constructed proof/checker passes72/0 exact controls; all
four actual changed-formula copies reject. Its full report was personally
read and49 artifacts plus4 live/snapshot source pairs verified. It identifies
no source correction. The exact Einstein comparison is sharp because a
radiation-only phi=0 solution saturates it. Physical sqrt(Cmax) conversion is
generally loose. Ricci scalar12Hv² stays finite in the saturation solution
while Kretschmann diverges. Finite duration alone does not classify an earlier
finite-aE chart endpoint. Unknown C0 and radiation/scale choices preclude a
uniform calibrated age. Hv->0 at fixed Q,rho0 approaches the finite coarse
bound; rho0->0 instead makes the bound diverge.

No numerical CMB temperature was used in these computations. Its primary
abstract was accessed only to motivate positive radiation, which does not
prove its separate conservation or this action throughout the past. No scalar
initial state, unique potential, particle spectrum or scale hierarchy selected.
Canonical source packaging is separate from this sealed derivation evidence.
