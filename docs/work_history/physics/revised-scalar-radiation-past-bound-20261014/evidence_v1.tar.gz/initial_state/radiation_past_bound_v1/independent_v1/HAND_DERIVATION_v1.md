# Independent positive-radiation past-duration derivation before code

Scientific author /root. Focused checker /root/scalar_energy_check. This derivation uses the four specified source texts, including the full canonical action, and no producer executable or outputs. No initial scalar point is assumed in the inequality. The CMB access metadata is read only as the author's exposed positive-radiation motivation; no abstract, catalogue, temperature-derived density, numerical calibration or empirical test is independently obtained.

Write a_k=(1-k)(1+3k)/4 to distinguish the coupling constant from the Einstein scale factor a_E. Let A=sqrt(C), b=d ln A, and let dot mean dimensionful Einstein proper-time derivative unless a J derivative is explicit. All densities below are dimensionful. Canonical rho_J must be multiplied by rho_unit to supply the rho_r,J in this block.

1. The action is

    S=Q integral sqrt(-g) [R/2-K_AB partial(phi^A).partial(phi^B)-2Hv^2 U]
      + S_m[A^2 g,matter], Q=Q0(1+k).

Metric variation gives

    T_phi,mu nu=2Q K_AB partial_mu phi^A partial_nu phi^B
      -Q g_mu nu [K_AB partial(phi^A).partial(phi^B)+2Hv^2 U],
    rho_phi=Q K_AB dot(phi^A)dot(phi^B)+2Q Hv^2 U,
    p_phi=Q K_AB dot(phi^A)dot(phi^B)-2Q Hv^2 U.

The missing conventional 1/2 in the kinetic term is consequential: the scalar kinetic energy is Q times the norm squared, not Q/2. The flat Hamiltonian equation is

    3Q H_E^2=Q |dot(phi)|_K^2+2Q Hv^2 U+rho_E,total.

Varying the lapse in the homogeneous action gives the same result. Matter conformal variation is delta S_m/sqrt(-g)=b_A T_E delta phi^A. The scalar equation therefore is

    D_t dot(phi)^A+3H_E dot(phi)^A+Hv^2 K^AB U_,B
      = -(rho_E-3p_E) K^AB b_B/(2Q).

This confirms both the radiation trace decoupling and the potential derivative normalization. It is unnecessary to solve this scalar equation to obtain the duration inequality.

2. On the stated finite field chart, E>0, F=1+sE>0, Dfield=1+2(1+k)(x^2+y^2)/3>0. Since

    1-3a_k=(1-3k)^2/4>0,

J=1+(1-3a_k)sE>1. Every diagonal K entry is positive. All terms in U-3/2 are nonnegative for 0<k<1/3, nu>0, and the positive exponential factors. U>=3/2 follows without restricting nu to the separate future-convergence range.

For A=sqrt((1+s)E/F), b_u=sqrt(a_k)/F and b_x=b_y=0. Hence

    |b|_K^2=a_k/J<a_k<1/3,
    0<C<Cmax=(1+s)/s.

The constraint, U>0 and nonnegative other densities imply |dot(phi)|_K^2<3H_E^2. On the expanding sheet H_E>=Hv>0. Its sign cannot change in a regular solution. With eta=1-sqrt(3a_k)>0,

    H_J=(H_E+b_A dot(phi)^A)/A
       >= eta H_E/A >= eta H_E/sqrt(Cmax)>0.

The inequalities can be made strict on a finite chart, but the weak form suffices. This proves orientation and excludes a homogeneous physical bounce within the premises. It is not a k-uniform estimate: with epsilon=1-3k, eta=1-sqrt(1-epsilon^2/4)~epsilon^2/8. No lower bound on A is needed for the upper proper-duration bound.

3. Stress transformation gives T_E,mu nu=A^2 T_J,mu nu. With the normalized comoving velocities, rho_r,E=A^4 rho_r,J and p_r,E=A^4 p_r,J. The separately conserved isotropic massless component obeys

    d rho_r,J/dt_J+4H_J rho_r,J=0.

Since dt_J=A dt_E and a_J=A a_E, this implies both

    rho_r,J a_J^4=constant,
    rho_r,E a_E^4=constant.

Equivalently, differentiating A^4 rho_J cancels the 4 d ln A/dt_E contribution against A H_J=H_E+d ln A/dt_E. Other equations of state do not give this cancellation; a component exchanging energy does not obey it. At the homogeneous level massless collisionless particles with an exactly isotropic distribution also have this stress/conservation law. Isotropy, vanishing trace and separate conservation, rather than a claim about a general collisionless perturbation closure, are the required inputs.

4. Fix a regular event with a0>0, rho0=rho_r,E0>0 and Q,Hv>0. Define D_rad=a0^2 sqrt(rho0/(3Q)). Then

    H_E^2 >= Hv^2+D_rad^2/a_E^4.

For X=a_E^2>0 on the expanding branch,

    dot X=2X H_E >= 2sqrt(Hv^2 X^2+D_rad^2).

The function

    T(X)=asinh(Hv X/D_rad)/(2Hv)

has derivative 1/[2sqrt(Hv^2 X^2+D_rad^2)]. Therefore dT/dt_E>=1. Integrating forward from any earlier regular event to t0 yields

    t0-t <= T(X0)-T(X(t)) < T(X0)
         = asinh(Hv sqrt(3Q/rho0))/(2Hv)=Tstar.

The first inequality points in this direction because the actual X flow is at least as fast as the comparison flow. The second is strict for each regular earlier event because X(t)>0. The supremum of durations is at most Tstar, not necessarily attained. Scale normalization a_E->c a_E sends D_rad->c^2 D_rad and X->c^2 X; it cancels from Tstar. asinh z<=z for z>=0 gives Tstar<=sqrt(3Q/rho0)/2.

For any such pair of events,

    t_J0-t_J=integral_t^t0 A dt_E <=sqrt(Cmax)(t0-t)
             <sqrt(Cmax)Tstar.

The supremum obeys the non-strict physical bound. t_J here is the proper time along homogeneous comoving physical observers. This alone is not a classification of every timelike/null geodesic or a maximal spacetime extension. A conformal factor tending to zero only shortens this integral; it cannot defeat the stated upper bound.

5. Equality in the Einstein comparison is achieved by phi=0, dot(phi)=0, no matter except the positive radiation component. The potential has U=3/2 and U_,A=0 there, C=1, and radiation has zero trace. This is an exact solution of the full scalar and Einstein equations, not only of the Hamiltonian constraint. With tau=t_E-t_B>0,

    X=(D_rad/Hv)sinh(2Hv tau), H_E=Hv coth(2Hv tau),
    rho_r,E=3Q D_rad^2/X^2, dot H_E=-2D_rad^2/X^2.

Radiation conservation, the Friedmann constraint and the Raychaudhuri equation -2Q dot H_E=rho_r,E+p_r,E all hold. At the reference event tau0=Tstar. Since C=1, t_J=t_E for this solution. Its physical duration does not saturate the generally larger bound sqrt(Cmax)Tstar.

The independent exact parameters will be k=1/7, nu=5/4, Q0=49/32 so Q=7/4, Hv=3/5, a0=5/3, rho0=84/25. Then s=14, Cmax=15/14, D_rad=20/9 and Hv sqrt(3Q/rho0)=3/4, giving Tstar=(5/6)log 2. At tau1=(5/6)log(3/2), X1=125/81 and H1=39/25. These rational/hyperbolic identities permit a distinct exact control without numerical trajectory integration.

6. For a smooth flat physical FLRW metric,

    Kretschmann=12[(dH_J/dt_J+H_J^2)^2+H_J^4]>=12H_J^4.

If a regular branch tends backward to a_E=0, conserved positive radiation makes rho_r,E and H_E diverge. The fixed-k physical clock inequality then makes H_J diverge, so this physical curvature invariant diverges. The conclusion is conditional on a_E reaching zero on that branch. It does not follow for every earlier chart endpoint from the finite interval bound alone.

For the exact saturation solution, Kretschmann=24[Hv^4+D_rad^4/X^4] diverges while the Ricci scalar is 12Hv^2, a finite constant. Thus substituting a Ricci-scalar divergence test would be wrong. A truncation at the regular tau1>0 event has finite curvature and positive X; its finite past interval is not a singular or maximal endpoint. This is a logical test of what the duration comparison alone proves, not a construction of a genuine finite-field-chart boundary solution.

No extension maintaining all the same premises can provide an arbitrarily long regular expanding homogeneous past through the chosen event, because the same inequality would apply to it. The comparison does not forbid a finite earlier regular extension, changes of chart, or an extension that leaves the assumptions. It also does not prove that every allowed scalar history reaches a_E=0.

7. With rho0=0 the derivation divides by D_rad=0 and is inapplicable. The exact origin vacuum solution a_E=exp(Hv t_E), C=1 has Ricci scalar 12Hv^2, Kretschmann 24Hv^4 and t_E extending to -infinity for the comoving flat-patch clock. It does not imply past completeness of all geodesics. As rho0->0+ at fixed Hv,Q, Tstar diverges logarithmically, consistently with this vacuum limit. As Hv->0+ at fixed rho0,Q, Tstar tends to sqrt(3Q/rho0)/2; that is a limiting control, not an expansion of the stated Hv>0 theorem.

No source correction has been identified in this derivation before code. The inequalities and endpoint qualifications appear consistent. The executable will test the exact statements and altered formulas without reading producer material.
