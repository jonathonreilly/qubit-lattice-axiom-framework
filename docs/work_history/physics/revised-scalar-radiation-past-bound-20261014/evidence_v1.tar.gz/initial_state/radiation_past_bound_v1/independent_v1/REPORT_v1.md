# Independent positive-radiation past-duration check

The stated comparison bound follows from the supplied action and the declared homogeneous premises. I found no source equation or endpoint-qualification error requiring a correction. In dimensionful Einstein proper time, a regular expanding spatially flat branch containing a positive separately conserved radiation component obeys

    sup(t0-t) <= Tstar,
    Tstar=asinh[Hv sqrt(3Q/rho_r,E0)]/(2Hv),

and the corresponding comoving physical proper duration is at most sqrt(Cmax) Tstar. Each pair of regular events satisfies the strict final bound; the supremum need not be attained. These are conditional duration statements. The source correctly distinguishes them from a proof that every allowed history reaches a_E=0 or that every earlier chart boundary is a curvature singularity.

The independently reconstructed action normalization, radiation conversion, comparison integral, physical clock, exact saturating solution and vacuum limit passed 72 exact controls. Four actual altered-formula copies were executed separately and all failed their intended witnesses. No unexpected mathematical execution failure or repair occurred. The control count is not a count of independent theorems; the complete handwritten proof and its assumptions remain necessary.

Scientific authorship remains with /root. This is a focused independent check, not a formal audit or an empirical acceptance. All writes are confined to this new independent_v1 directory. No parent implementation or results, previous orbit arrays, git/PR/runtime/lock state, parent source, or earlier evidence was changed or used as an oracle.

## Exact sources and independence

The complete three requested radiation-block documents and the full canonical action note were read before the checker was constructed. Their snapshots and live identities are bound in SOURCE_MANIFEST_v1.json.

| Source | SHA-256 |
| --- | --- |
| RP/DERIVATION_v1.md | eabdd21138c7b0c1113715c8e607494e94f3b39300e457beb7dfbd884cfa16e1 |
| RP/PROTOCOL_v1.json | feaba9a776ea4681c1803b6ad7f78c4be046c08d6fa3c3fdbca0cfb72fe0ffa3 |
| RP/SOURCE_ACCESS_v1.json | 1eaa39decbc29b4c05503603856116b7fa10ca4b494bb8e333725711fde9fbc2 |
| Canonical future-confinement note containing the full action | 39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000 |

Here RP is the campaign's initial_state/radiation_past_bound_v1 directory. The canonical source status and earlier future theorem are not regraded by this check. Its complete action is the physical input; the new past comparison is reconstructed directly below.

HAND_DERIVATION_v1.md and the independent PROTOCOL_v1.json were saved before check_independent_v1.py. The independent closed-form parameters were chosen separately from any producer computation. No producer checker or output was read, imported, or run. The parent's source-access metadata records an exposed CMB abstract; that abstract and its quoted temperature were not independently fetched or validated in this check. No observed temperature, density, numerical cosmological parameter, or likelihood appears in the mathematical controls.

## Action normalization and the global bounds used

Let a_k=(1-k)(1+3k)/4 and distinguish this coupling constant from the scale factor a_E. The canonical action is

    S=Q integral sqrt(-g) [R/2-K_AB partial(phi^A).partial(phi^B)-2Hv^2 U]
      +S_m[A^2 g,matter],
    Q=Q0(1+k), A=sqrt(C).

There is no 1/2 in front of K. Direct metric variation gives

    rho_phi=Q |dot(phi)|_K^2+2Q Hv^2 U,
    p_phi=Q |dot(phi)|_K^2-2Q Hv^2 U.

The homogeneous lapse action, after the usual gravitational boundary term is removed, is

    L=-3Q a_E dot(a_E)^2/N
      +Q a_E^3 |dot(phi)|_K^2/N-2Q Hv^2 a_E^3 N U+L_m.

Using partial L_m/partial N=-a_E^3 rho_E and varying N recovers

    3Q H_E^2=Q |dot(phi)|_K^2+2Q Hv^2 U+rho_E,total.

The executable compares this lapse derivative directly with the implemented constraint. A changed kinetic coefficient 1/2 leaves the nonzero residual Q |dot(phi)|_K^2/2.

On the complete finite chart, E=exp(2sqrt(a_k)u)>0, F=1+sE>0 and the transverse denominator 1+2(1+k)(x^2+y^2)/3 is positive. Since

    1-3a_k=(1-3k)^2/4>0,
    1/3-a_k=(1-3k)^2/12>0,

J=1+(1-3a_k)sE>1 and every diagonal metric entry is positive. Every term in U-3/2 is nonnegative for the stated 0<k<1/3 and nu>0. Therefore U>=3/2. This does not require the extra nu<=6a_k restriction used in the separate future-convergence theorem.

Differentiating the actual C gives b=d ln A with b_u=sqrt(a_k)/F, b_x=b_y=0. Thus

    |b|_K^2=a_k/J<a_k<1/3,
    0<C<Cmax=(1+s)/s,
    Cmax-C=(1+s)/(sF)>0.

With nonnegative total matter density the constraint implies |dot(phi)|_K^2<3H_E^2 and H_E^2>=Hv^2. For a regular expanding branch, H_E cannot cross zero. Define eta_k=1-sqrt(3a_k)>0. Cauchy-Schwarz and differentiation of a_J=A a_E with dt_J=A dt_E yield

    H_J=(H_E+b_A dot(phi)^A)/A
       >=eta_k H_E/A
       >=eta_k H_E/sqrt(Cmax)>0.

This is a consequence within the stated chart, not an extra assumption of a physical bounce-free history. It excludes such a homogeneous bounce while the premises hold. For epsilon=1-3k, eta_k=1-sqrt(1-epsilon^2/4) behaves as epsilon^2/8, so no uniform positive margin survives as k approaches 1/3.

The upper physical-duration bound only needs the upper bound on A. No positive lower bound on A or past compactness of the scalar trajectory is being smuggled into it.

## Radiation density, conservation and units

All densities in this independent past-duration calculation are dimensionful. In the canonical future note, rho_J denotes density divided by the supplied rho_unit. Multiplication by rho_unit is therefore required before interpreting that canonical symbol as the present block's dimensionful rho_r,J. The past source itself explicitly calls its densities physical/dimensionful, so there is no source correction here.

Conformal stress transformation gives T_E,mu nu=A^2 T_J,mu nu. Normalizing the comoving time vectors then gives

    rho_r,E=A^4 rho_r,J, p_r,E=A^4 p_r,J.

The component is assumed isotropic and separately conserved, with p_r,J=rho_r,J/3. Its physical conservation law is

    d rho_r,J/dt_J+4H_J rho_r,J=0.

Together with a_J=A a_E, this proves

    rho_r,J a_J^4=constant,
    rho_r,E a_E^4=constant.

Equivalently, differentiating A^4 rho_r,J in Einstein time produces a 4 dot(A)/A term that cancels against A H_J=H_E+dot(A)/A. The checker retains a variable A and dot(A), so the cancellation is tested away from constant C. Changing A^4 to A^2 fails this conservation identity, the invariant product and the stress conversion.

Radiation has zero trace, so it does not directly force the scalar through the conformal coupling. The action's scalar equation has the normalization

    D_t dot(phi)^A+3H_E dot(phi)^A+Hv^2 K^AB U_,B
      =-(rho_E-3p_E)K^AB b_B/(2Q).

This confirms the trace statement without presupposing the scalar is fixed in the general comparison. At the homogeneous background level, an isotropic collisionless massless distribution can have this stress and conservation law; no closure for its inhomogeneous angular perturbations is asserted. Interactions preserving the total component energy do not change its background law. Energy transfer into or out of that component, nonzero mass/trace, or anisotropy would require another derivation.

Detecting positive radiation at one observed epoch does not establish separate conservation, isotropy or the classical model throughout an arbitrarily long past. Those remain hypotheses.

## Comparison direction and clocks

At a chosen regular event set a0=a_E(t0)>0 and rho0=rho_r,E(t0)>0. Define

    D_rad=a0^2 sqrt[rho0/(3Q)], X=a_E^2.

Radiation conservation and the lower scalar vacuum energy give

    H_E^2>=Hv^2+D_rad^2/a_E^4,
    dot X=2X H_E>=2sqrt(Hv^2 X^2+D_rad^2).

For

    T(X)=asinh(Hv X/D_rad)/(2Hv),

the derivative is 1/[2sqrt(Hv^2 X^2+D_rad^2)], so dT/dt_E>=1. Integrating forward from an earlier regular event t to the fixed event t0 yields

    t0-t<=T(X0)-T(X(t))<T(X0)=Tstar.

The inequality direction is important: the actual expanding scale factor runs at least as fast as the comparison solution, hence it takes no more elapsed time to reach the same reference scale. The second inequality is strict for each regular t because X(t)>0. Only the supremum is bounded non-strictly.

Substituting D_rad cancels a0 and gives exactly

    Tstar=asinh[Hv sqrt(3Q/rho0)]/(2Hv).

Rescaling a_E by a positive constant rescales X and D_rad equally. This is a scale-factor normalization invariance, not a calibration of Q or Hv. Since asinh z<=z for z>=0,

    Tstar<=sqrt(3Q/rho0)/2.

The duration along homogeneous comoving physical observers obeys

    t_J0-t_J=integral_t^t0 A dt_E
             <=sqrt(Cmax)(t0-t)<sqrt(Cmax)Tstar.

Thus its supremum satisfies the source's non-strict physical bound. The result concerns these proper-time clocks on the stated branch; it does not classify arbitrary null or noncomoving timelike geodesics.

Since rho0=C0^2 rho_r,J0, a fixed finite chart event with positive physical radiation gives rho0>0 and a finite bound. But there is no uniform numerical age bound over an uncalibrated family in which C0 approaches zero, Q changes, or rho0 approaches zero. The source appropriately leaves Q, Hv and C0 supplied. No inferred observational age has been obtained.

## Exact saturation and distinct rational controls

At phi=0 the full potential has U=3/2 and all three gradients vanish; C=1. For zero scalar velocity and radiation only, its trace is zero and the full scalar equations remain satisfied. The exact solution is

    X=(D_rad/Hv)sinh[2Hv(t_E-t_B)],
    H_E=Hv coth[2Hv(t_E-t_B)],
    rho_r,E=3Q D_rad^2/X^2.

The checker verifies the scale-factor kinematics, Friedmann constraint, radiation conservation and Raychaudhuri equation. In particular,

    dot H_E=-2D_rad^2/X^2,
    -2Q dot H_E=rho_r,E+p_r,E.

This establishes an exact action-compatible saturation solution, rather than merely a chosen comparison curve satisfying one equation. Its origin scalar point is used only to show sharpness of the Einstein comparison; it was not assumed in deriving the bound for other histories.

The independent exact parameters are

    k=1/7, nu=5/4, Q0=49/32, Q=7/4,
    Hv=3/5, a0=5/3, rho0=84/25.

They give s=14, Cmax=15/14, D_rad=20/9 and Hv sqrt(3Q/rho0)=3/4. Consequently

    Tstar=(5/6)log 2
          =0.5776226504666210911810267678818138067296...

in the supplied time units. At the earlier regular elapsed time tau1=(5/6)log(3/2), the exact values are X1=125/81 and H1=39/25. The difference to the reference time is (5/6)log(4/3), and the comparison identity is saturated on this interval as well. These are exact synthetic checks, not a measured time.

Because this solution has A=1, it saturates the Einstein duration while the general physical bound is larger by sqrt(15/14). The latter is not claimed sharp. Adding three times as much additional positive radiation, retaining the selected component rho0, gives the smaller exact duration (5/6)asinh(3/8). This tests the direction and the allowed nonnegative extra-density slack.

A separate finite origin initial state with scalar norm squared 1/4 and the same positive radiation has H_E^2=13/12 and g0=|b|_K^2=1/7. Taking scalar velocity opposite the coupling gradient gives H_J=H_E-1/(2sqrt(7))>0 and still lies above eta_k H_E. Thus the clock control is not confined to zero scalar velocity.

## Endpoint and vacuum challenges

For a smooth spatially flat physical FLRW metric,

    Kretschmann=12[(dH_J/dt_J+H_J^2)^2+H_J^4]>=12H_J^4.

If a particular regular branch continues toward a_E=0, positive conserved radiation forces rho_r,E and H_E to diverge. At fixed allowed k, the lower physical clock inequality then forces H_J to diverge, and the physical Kretschmann invariant diverges. The source's conditional curvature statement is valid.

For the exact C=1 radiation solution,

    Kretschmann=24[Hv^4+D_rad^4/X^4],
    Ricci scalar=12Hv^2.

The Ricci scalar stays finite while Kretschmann diverges. This explicitly checks that a scalar-curvature test based only on R would miss this endpoint. The source uses the correct stronger invariant.

Finite duration itself does not diagnose an earlier endpoint. Truncating this exact branch at the regular tau1 above leaves X1>0 and finite Kretschmann 41525784/390625. Such a truncation is an extendible interval boundary, not a singular or maximal endpoint. This is a logical control of the inference, not a claimed example of a genuine action-generated field-chart boundary. The check has not constructed or classified all finite-a_E chart endpoints.

A nonflat Milne metric also provides a geometric check of why spatial flatness matters to the H_J-only lower bound: its spatial-curvature term cancels H^2 in the corresponding Riemann invariant. That excluded metric is not offered as a solution of this positive-Hv scalar model. Likewise, formal cancellation of a positive radiation density by a negative component would destroy the comparison; it violates the explicitly required nonnegative other densities.

An extension that keeps all the stated premises and remains a regular expanding homogeneous branch through the same fixed event still obeys the same inequality, so it cannot create an arbitrarily long past proper duration. The result does not forbid a finite earlier extension or a change of chart, and does not constrain extensions leaving the stated sector. It is not a general global-spacetime or all-geodesic theorem.

When rho0=0, D_rad=0 and the positive-radiation comparison is inapplicable. The exact origin vacuum a_E=exp(Hv t_E), C=1 has constant Kretschmann 24Hv^4 and unbounded comoving past proper time in its flat patch. This is a valid excluded-premise counterexample to an overbroad claim about every history. It does not imply past completeness of every geodesic or establish a global extension.

The limit rho0->0+ of Tstar diverges logarithmically, consistently with this separate vacuum solution. At fixed Q,rho0, the limit Hv->0+ gives sqrt(3Q/rho0)/2. The latter is a limiting algebraic control; it does not change the theorem's supplied Hv>0 domain.

## Actual computations and failure preservation

One independent baseline run completed 72 passed / 0 failed, exit zero, using Python 3.12.8 and Sympy 1.14.0. The independent checker hash is 3860c9dff3f0cdfb3d7abd392c6776edc0d74d008030f6938bee7c3e3bbf8e1f. The baseline results hash is 56cdacef1c36a4dd77fe9e803367f611189313fdf8995dea37de2ce4c11f3aa5.

The independent protocol specified four formula changes before they were executed. Each changed source, its exact diff, argv, stdout, stderr, result and execution record is retained separately:

| Actual changed formula | Result | Required witness |
| --- | --- | --- |
| Kinetic density Q times norm squared changed to Q/2 | 71 passed / 1 failed, exit 1 | Lapse constraint residual Q KV/2 |
| Radiation conversion A^4 changed to A^2 | 68 passed / 4 failed, exit 1 | Einstein conservation residual -2 A dot(A) rho_J |
| Comparison denominator 2Hv changed to Hv | 65 passed / 7 failed, exit 1 | Exact saturation-time residual log(r)/(2Hv) |
| Physical clock numerator H_E+b.dot(phi) changed to H_E-b.dot(phi) | 71 passed / 1 failed, exit 1 | Scale-factor differentiation residual -2B/A |

Doubling T would still produce a looser upper bound, but it is not the stated comparison antiderivative or sharp Einstein saturation time. The relevant failed controls test those precise claims, rather than pretending that every larger number ceases to be an upper bound. Similarly, the wrong clock sign is rejected against direct kinematics, even though an absolute-value Cauchy bound by itself would not distinguish the signs.

These damaged runs test this independent implementation. They are not tests of the unread parent code. There were no unexpected baseline mathematical failures, exceptions, timed-out runs, omitted repairs or replaced outputs. FAILURES_v1.json preserves every actual expected failure and records the absence of unexpected ones. Simple bookkeeping identities in the count do not replace the sign-domain and integration proof.

## Final scope

The new result removes the need to impose a bounded earlier scalar trajectory or select a radiation fixed point in order to bound regular past duration. It still depends on the supplied action and parameter domain, positive kinetic metric and potential floor, spatial flatness, homogeneous classical evolution in the regular field chart, the expanding sheet, nonnegative other matter densities, and positive separately conserved isotropic radiation throughout the interval.

The exact saturation example shows the Einstein comparison cannot generally be tightened using only these hypotheses. It does not select the actual scalar history, establish a finite regular origin, derive the dimensional scales, or fit an observed universe. The conditional curvature conclusion requires a_E->0; a finite duration alone leaves other earlier chart endpoints unclassified. No source correction is requested within this checked scope.
