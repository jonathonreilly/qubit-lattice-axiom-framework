#!/usr/bin/env python3
"""Independent exact radiation/action/clock controls, with no producer imports."""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import sys
import time
import sympy as s

KINETIC_DENSITY_COEFFICIENT = s.Integer(1)
RADIATION_CONFORMAL_POWER = 4
COMPARISON_TIME_DENOMINATOR = 1
PHYSICAL_CLOCK_COUPLING_SIGN = 1

parser = argparse.ArgumentParser()
parser.add_argument("--output-dir", required=True)
args = parser.parse_args()
out = Path(args.output_dir)
out.mkdir(parents=True, exist_ok=True)
started = time.monotonic()
checks = []
details = {}
rat = s.Rational

def serial(obj):
    if isinstance(obj, dict):
        return {key: serial(value) for key, value in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [serial(value) for value in obj]
    if isinstance(obj, (str, int, bool, float)) or obj is None:
        return obj
    return str(obj)

def record(name, passed, witness=None):
    entry = {"name": name, "passed": bool(passed)}
    if witness is not None:
        entry["witness"] = serial(witness)
    checks.append(entry)
    print(("PASS " if passed else "FAIL ") + name, flush=True)

def zero(name, expression):
    seq = list(expression) if isinstance(expression, s.MatrixBase) else [expression]
    residuals = [s.factor(s.simplify(value)) for value in seq]
    record(name, all(value == 0 for value in residuals), residuals)

# The homogeneous lapse action follows directly from the complete supplied action.
Q,Hv,aa,adot,N,KV,U,rho = s.symbols("Q Hv aa adot N KV U rho", positive=True)
mini = -3*Q*aa*adot**2/N + Q*aa**3*KV/N - 2*Q*Hv**2*aa**3*N*U
from_lapse = s.diff(mini,N).subs(N,1)/aa**3-rho
implemented_constraint = 3*Q*(adot/aa)**2-Q*KINETIC_DENSITY_COEFFICIENT*KV-2*Q*Hv**2*U-rho
zero("action.lapse_constraint_normalization", implemented_constraint-from_lapse)
rho_phi = Q*KV+2*Q*Hv**2*U
p_phi = Q*KV-2*Q*Hv**2*U
zero("action.scalar_enthalpy",rho_phi+p_phi-2*Q*KV)
zero("action.constant_vacuum_density",rho_phi.subs({KV:0,U:rat(3,2)})-3*Q*Hv**2)
Q0,k,nu = s.symbols("Q0 k nu", positive=True)
zero("action.Q_parameter_binding",Q0*(1+k)-Q0-Q0*k)

# Full actual metric, conformal factor and potential; no producer functions.
u,x,y = s.symbols("u x y",real=True)
ak=(1-k)*(1+3*k)/4
alpha=s.sqrt(ak)
ss=(1+k)/(k*(1-3*k))
E=s.exp(2*alpha*u)
F=1+ss*E
J=1+(1-3*ak)*ss*E
Dfield=1+2*(1+k)*(x*x+y*y)/3
Kdiag=s.Matrix([J/F**2,(1+ss)*4*k/(9*F*Dfield),(1+ss)*k/(3*F*Dfield)])
C=(1+ss)*E/F
Uactual=rat(3,2)+3*ss*(E-1)**2/(2*F**2)+(k/2)*x*x*s.exp(-(1-k)*u/alpha)+(k/3)*y*y*s.exp(-(1+k)*u/alpha)+nu*(1+ss)*u*u/(2*F**2)
origin={u:0,x:0,y:0}
zero("action.potential_origin",Uactual.subs(origin)-rat(3,2))
zero("action.potential_all_origin_gradients",s.Matrix([s.diff(Uactual,q).subs(origin) for q in [u,x,y]]))
zero("action.conformal_origin",C.subs(origin)-1)
zero("action.transverse_metric_origin",s.Matrix([Kdiag[1].subs(origin)-4*k/9,Kdiag[2].subs(origin)-k/3]))
zero("action.origin_scalar_trace_source",s.Symbol("b_up")*(rho-3*rho/3)/(2*Q))
zero("metric.positive_domain_identity",1-3*ak-(1-3*k)**2/4)
zero("metric.a_below_one_third_identity",rat(1,3)-ak-(1-3*k)**2/12)
zero("metric.positive_J_excess",J-1-(1-3*k)**2*ss*E/4)
bu=s.diff(s.log(C)/2,u)
zero("coupling.actual_log_gradient",bu-alpha/F)
zero("coupling.actual_metric_norm",bu**2/Kdiag[0]-ak/J)
Cmax=(1+ss)/ss
zero("coupling.global_C_gap",Cmax-C-(1+ss)/(ss*F))
zero("coupling.Cmax_above_one",Cmax-1-1/ss)
eps=s.symbols("epsilon",positive=True)
eta_eps=1-s.sqrt(1-eps*eps/4)
zero("clock.margin_endpoint_rate",s.limit(eta_eps/eps**2,eps,0,dir="+")-rat(1,8))

# Direct differentiation of a_J=A a_E and dt_J=A dt_E.
A,Adot,H,B = s.symbols("A Adot H B",positive=True)
from_scale_factor=(Adot*aa+A*adot)/(A*A*aa)
HJimplemented=(H+PHYSICAL_CLOCK_COUPLING_SIGN*B)/A
zero("clock.from_physical_scale_factor",HJimplemented-from_scale_factor.subs({adot:H*aa,Adot:B*A}))

# Radiation transformation: general A(t), separately conserved physical component.
rhoJ=s.symbols("rhoJ",positive=True)
rhoE=A**RADIATION_CONFORMAL_POWER*rhoJ
HJderived=(H+Adot/A)/A
rhoJdot_E=-4*A*HJderived*rhoJ
rhoEdot=s.diff(rhoE,A)*Adot+s.diff(rhoE,rhoJ)*rhoJdot_E
zero("radiation.Einstein_conservation",rhoEdot+4*H*rhoE)
zero("radiation.invariant_scale_product",rhoE*aa**4-rhoJ*(A*aa)**4)
# Coordinate covariant T_E,00=A^2 T_J,00 and T_J,00=A^2 rho_J.
zero("radiation.stress_conversion",rhoE-A**2*(A**2*rhoJ))
record("radiation.trace_free_equation_of_state",s.simplify(rhoE-3*(rhoE/3))==0)
source=s.symbols("source",real=True)
zero("radiation.energy_transfer_spoils_invariant",
     ((rhoEdot+A**RADIATION_CONFORMAL_POWER*source)+4*H*rhoE)-A**RADIATION_CONFORMAL_POWER*source)

# Comparison function, integration orientation and normalization independence.
X,D,a0,rho0,scale=s.symbols("X D a0 rho0 scale",positive=True)
Tfun=s.asinh(Hv*X/D)/(COMPARISON_TIME_DENOMINATOR*Hv)
zero("comparison.integral_derivative",s.diff(Tfun,X)-1/(2*s.sqrt(Hv**2*X**2+D**2)))
speed_compare=2*s.sqrt(Hv**2*X**2+D**2)
zero("comparison.flow_derivative",s.diff(Tfun,X)*speed_compare-1)
surplus=s.symbols("surplus",nonnegative=True)
zero("comparison.nonnegative_speed_surplus",
     s.diff(Tfun,X)*(speed_compare+surplus)-(1+surplus/(2*s.sqrt(Hv**2*X**2+D**2))))
Drad=a0**2*s.sqrt(rho0/(3*Q))
Tstar=Tfun.subs({X:a0**2,D:Drad})
Tsource=s.asinh(Hv*s.sqrt(3*Q/rho0))/(2*Hv)
zero("comparison.reference_density_formula",Tstar-Tsource)
zero("comparison.scale_normalization",Tfun.subs({X:scale**2*X,D:scale**2*D},simultaneous=True)-Tfun)
z=s.symbols("z",positive=True)
weak_gap=z-s.asinh(z)
zero("comparison.weaker_bound_derivative",s.diff(weak_gap,z)-(1-1/s.sqrt(1+z*z)))
zero("comparison.weaker_bound_initial_value",weak_gap.subs(z,0))
Hgap=s.asinh(z)-z/s.sqrt(1+z*z)
zero("comparison.Hv_monotonicity_identity",s.diff(Hgap,z)-z*z/(1+z*z)**rat(3,2))
record("comparison.density_derivative_negative",s.diff(Tsource,rho0).is_negative,
       s.diff(Tsource,rho0))
record("comparison.Q_derivative_positive",s.diff(Tsource,Q).is_positive,
       s.diff(Tsource,Q))
zero("comparison.Hv_zero_limit",s.limit(Tsource,Hv,0,dir="+")-s.sqrt(3*Q/rho0)/2)
record("comparison.radiation_zero_limit_unbounded",s.limit(Tsource,rho0,0,dir="+")==s.oo)

# Exact saturation solution, constructed directly from the Einstein/radiation equations.
tau=s.symbols("tau",positive=True)
Xsat=D/Hv*s.sinh(2*Hv*tau)
Hsat=Hv*s.coth(2*Hv*tau)
rhosat=3*Q*D*D/Xsat**2
zero("saturation.scale_factor_kinematics",s.diff(Xsat,tau)-2*Xsat*Hsat)
zero("saturation.Friedmann",3*Q*Hsat**2-3*Q*Hv**2-rhosat)
zero("saturation.radiation_conservation",s.diff(rhosat,tau)+4*Hsat*rhosat)
zero("saturation.Raychaudhuri",-2*Q*s.diff(Hsat,tau)-rat(4,3)*rhosat)
zero("saturation.Hdot",-s.diff(Hsat,tau)-2*D*D/Xsat**2)

# Use r=exp(2Hv tau)>1 to establish the inverse branch without a CAS assumption gap.
rr=s.symbols("rr",positive=True)
zz=(rr-1/rr)/2
positive_root=(rr+1/rr)/2
zero("comparison.inverse_positive_sqrt",positive_root**2-(1+zz**2))
zero("comparison.inverse_log_argument",zz+positive_root-rr)
Tsat_log=s.log(zz+positive_root)/(COMPARISON_TIME_DENOMINATOR*Hv)
zero("comparison.saturating_elapsed_time",Tsat_log-s.log(rr)/(2*Hv))

# Distinct exact rational parameters: asinh(3/4)=log 2.
choices={k:rat(1,7),nu:rat(5,4),Q0:rat(49,32),Q:rat(7,4),Hv:rat(3,5),a0:rat(5,3),rho0:rat(84,25),D:rat(20,9)}
zero("exact_parameters.Q_from_Q0", (Q0*(1+k)-Q).subs(choices))
zero("exact_parameters.s",ss.subs(choices)-14)
zero("exact_parameters.Cmax",Cmax.subs(choices)-rat(15,14))
zero("exact_parameters.D",Drad.subs(choices)-rat(20,9))
zero("exact_parameters.asinh_argument",(Hv*s.sqrt(3*Q/rho0)).subs(choices)-rat(3,4))
zero("exact_parameters.Tstar",Tsource.subs(choices).rewrite(s.log)-rat(5,6)*s.log(2))
zero("exact_parameters.actual_comparison_value",Tstar.subs(choices).rewrite(s.log)-rat(5,6)*s.log(2))
tau1=rat(5,6)*s.log(rat(3,2))
X1=s.simplify(Xsat.subs(choices).subs(tau,tau1).rewrite(s.exp))
H1=s.simplify(Hsat.subs(choices).subs(tau,tau1).rewrite(s.exp))
zero("exact_parameters.earlier_X",X1-rat(125,81))
zero("exact_parameters.earlier_H",H1-rat(39,25))
elapsed=rat(5,6)*s.log(2)-tau1
T_at_X1=Tfun.subs(choices).subs(X,X1).rewrite(s.log)
zero("exact_parameters.interval_saturates",Tstar.subs(choices).rewrite(s.log)-T_at_X1-elapsed)
record("exact_parameters.regular_interval_shorter_than_Tstar",elapsed>0 and tau1>0,
       {"elapsed":elapsed,"Tstar":Tsource.subs(choices),"earlier_X":X1,"earlier_H":H1})
record("physical_duration.origin_bound_is_loose",Cmax.subs(choices)>1)

# An actual constraint-compatible finite origin state with nonzero scalar velocity.
kv0=rat(1,4)
Hstate=s.sqrt((kv0+2*choices[Hv]**2*rat(3,2)+choices[rho0]/choices[Q])/3)
g0=s.factor((ak/J).subs(origin).subs(choices))
HJstate=Hstate-s.sqrt(g0*kv0)
eta=1-s.sqrt(3*ak)
gapstate=HJstate-eta.subs(choices)*Hstate
zero("clock.origin_coupling_norm",g0-rat(1,7))
zero("clock.constrained_H",Hstate**2-rat(13,12))
record("clock.nonzero_velocity_state_positive",HJstate>0,{"HJ":HJstate})
record("clock.nonzero_velocity_state_bound",gapstate>0,{"gap":gapstate})

# More nonnegative radiation makes the elapsed time strictly smaller.
Textra=s.asinh(Hv*s.sqrt(3*Q/(4*rho0)))/(2*Hv)
zero("comparison.extra_positive_radiation_formula",
     Textra.subs(choices)-rat(5,6)*s.asinh(rat(3,8)))
record("comparison.extra_positive_radiation_strict",
       (s.asinh(rat(3,4))-s.asinh(rat(3,8))).is_positive)

# Physical curvature on the exact C=1 radiation solution.
Kretsch=12*((s.diff(Hsat,tau)+Hsat**2)**2+Hsat**4)
Ricci=6*(s.diff(Hsat,tau)+2*Hsat**2)
zero("curvature.exact_Kretschmann",Kretsch-24*(Hv**4+D**4/Xsat**4))
zero("curvature.Ricci_stays_finite",Ricci-12*Hv**2)
record("curvature.radiation_endpoint_diverges",s.limit(Kretsch,tau,0,dir="+")==s.oo)
K1=s.simplify(Kretsch.subs(choices).subs(tau,tau1).rewrite(s.exp))
record("endpoint.finite_regular_cutoff_curvature",K1.is_finite and K1>0,
       {"K_at_cutoff":K1,"X_at_cutoff":X1,"maximal_endpoint_claim":False})
Hdot_symbol=s.symbols("Hdot",real=True)
zero("curvature.flat_lower_bound_remainder",
     12*((Hdot_symbol+H**2)**2+H**4)-12*H**4-12*(Hdot_symbol+H**2)**2)
# A check of why the spatial-flatness premise matters: Milne's excluded case.
Kmilne=12*((s.diff(1/tau,tau)+1/tau**2)**2+(1/tau**2-1/tau**2)**2)
zero("scope.nonflat_Milne_no_Honly_curvature_bound",Kmilne)

# Independent vacuum limit; no division by radiation density is applied here.
avac=s.exp(Hv*tau)
Hvac=s.diff(avac,tau)/avac
zero("vacuum.Friedmann",3*Q*Hvac**2-3*Q*Hv**2)
zero("vacuum.Kretschmann",12*((s.diff(Hvac,tau)+Hvac**2)**2+Hvac**4)-24*Hv**4)
zero("vacuum.Ricci",6*(s.diff(Hvac,tau)+2*Hvac**2)-12*Hv**2)
negative_time=s.symbols("negative_time",real=True)
record("vacuum.flat_scale_tends_zero_at_infinite_time",s.limit(s.exp(Hv*negative_time),negative_time,-s.oo)==0)
zero("scope.negative_other_density_cancellation",rho+(-rho))

details["exact_parameters"]={str(key):str(value) for key,value in choices.items()}
details["exact_times"]={
    "Tstar":str(rat(5,6)*s.log(2)),
    "Tstar_decimal":str((rat(5,6)*s.log(2)).evalf(40)),
    "earlier_tau":str(tau1),
    "elapsed":str(elapsed),
    "physical_upper_bound":str(s.sqrt(rat(15,14))*rat(5,6)*s.log(2)),
    "C_at_saturation":1,
    "curvature_at_regular_cutoff":str(K1)
}
result={
    "schema":"independent-radiation-past-duration-exact-results-v1",
    "scientific_author":"/root","checker":"/root/scalar_energy_check",
    "code_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "producer_code_or_results_accessed":False,
    "formula_constants":{
        "kinetic_density_coefficient":str(KINETIC_DENSITY_COEFFICIENT),
        "radiation_conformal_power":RADIATION_CONFORMAL_POWER,
        "comparison_time_denominator":COMPARISON_TIME_DENOMINATOR,
        "physical_clock_coupling_sign":PHYSICAL_CLOCK_COUPLING_SIGN
    },
    "versions":{"python":sys.version,"sympy":s.__version__,"platform":platform.platform()},
    "counts":{"passed":sum(row["passed"] for row in checks),"failed":sum(not row["passed"] for row in checks),"total":len(checks)},
    "checks":checks,"details":details,"elapsed_seconds":time.monotonic()-started,
    "scope_limits":[
        "No empirical calibration or CMB-temperature use.",
        "No unknown scalar initial point is supplied to the duration inequality.",
        "The exact saturation solution is an unselected example.",
        "Finite duration alone does not classify an earlier chart endpoint.",
        "No all-geodesic or global extension theorem is proved.",
        "No producer implementation or outputs were accessed."
    ]
}
(out/"RESULTS_v1.json").write_text(json.dumps(serial(result),indent=2)+"\n")
print(json.dumps(result["counts"]),flush=True)
sys.exit(0 if result["counts"]["failed"]==0 else 1)
