#!/usr/bin/env python3
"""Snapshot only the four requested sources; no producer implementation access."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[6]
RP = ".claude/science/physics-loops/revised-scalar-derivation-24h-20261013/initial_state/radiation_past_bound_v1"
paths = [
    (RP + "/PROTOCOL_v1.json", "PROTOCOL_v1.json", None),
    (RP + "/DERIVATION_v1.md", "DERIVATION_v1.md", "eabdd21138c7b0c1113715c8e607494e94f3b39300e457beb7dfbd884cfa16e1"),
    (RP + "/SOURCE_ACCESS_v1.json", "SOURCE_ACCESS_v1.json", None),
    ("docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md", "FULL_ACTION_CANONICAL_NOTE.md", "39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000")
]
def sha(b):
    return hashlib.sha256(b).hexdigest()
folder = ROOT / "sources"
folder.mkdir(exist_ok=False)
rows = []
for rel, name, expected in paths:
    data = (REPO / rel).read_bytes()
    digest = sha(data)
    assert expected is None or digest == expected
    snap = folder / name
    snap.write_bytes(data)
    rows.append({"original_path": rel, "snapshot_path": str(snap.relative_to(ROOT)),
                 "bytes": len(data), "sha256": digest})
record = {
    "at_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
    "command": [sys.executable, str(Path(__file__).resolve())],
    "cwd": str(Path.cwd()),
    "sources": rows,
    "all_four_sources_read_in_full": True,
    "producer_code_or_results_accessed": False,
    "primary_CMB_abstract_independently_accessed": False,
    "observational_role": "Only the author's exposed positivity motivation and access metadata were read. No temperature or observed density is used or independently validated."
}
(ROOT / "SOURCE_MANIFEST_v1.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
