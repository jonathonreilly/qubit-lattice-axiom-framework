#!/usr/bin/env python3
"""Record every actual execution, including any unexpected or intended failures."""
from pathlib import Path
import argparse
import datetime as dt
import difflib
import hashlib
import json
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
CODE=ROOT/"check_independent_v1.py"
parser=argparse.ArgumentParser()
parser.add_argument("phase",choices=["baseline","damages"])
args=parser.parse_args()

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def execute(code,out):
    out.mkdir(parents=True,exist_ok=False)
    argv=[sys.executable,str(code),"--output-dir",str(out)]
    rec={"argv":argv,"cwd":str(ROOT),"code_sha256":sha(code),"started_utc":dt.datetime.now(dt.timezone.utc).isoformat()}
    (out/"COMMAND.json").write_text(json.dumps(rec,indent=2)+"\n")
    start=time.monotonic()
    try:
        proc=subprocess.run(argv,cwd=ROOT,capture_output=True,text=True,timeout=90)
        stdout,stderr,returncode=proc.stdout,proc.stderr,proc.returncode
    except subprocess.TimeoutExpired as exc:
        stdout=exc.stdout or ""
        stderr=exc.stderr or ""
        if isinstance(stdout,bytes):stdout=stdout.decode(errors="replace")
        if isinstance(stderr,bytes):stderr=stderr.decode(errors="replace")
        stderr+="\nIndependent driver: execution timed out at 90 seconds.\n"
        returncode=124
    (out/"stdout.txt").write_text(stdout)
    (out/"stderr.txt").write_text(stderr)
    rec.update(returncode=returncode,elapsed_seconds=time.monotonic()-start,completed_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
               stdout_sha256=sha(out/"stdout.txt"),stderr_sha256=sha(out/"stderr.txt"))
    if (out/"RESULTS_v1.json").exists():
        result=json.loads((out/"RESULTS_v1.json").read_text())
        rec.update(results_sha256=sha(out/"RESULTS_v1.json"),counts=result["counts"],
                   failed_checks=[row["name"] for row in result["checks"] if not row["passed"]])
    (out/"EXECUTION.json").write_text(json.dumps(rec,indent=2)+"\n")
    print(json.dumps(rec,indent=2),flush=True)
    return rec

if args.phase=="baseline":
    rec=execute(CODE,ROOT/"baseline_v1")
    sys.exit(rec["returncode"])

base=json.loads((ROOT/"baseline_v1/EXECUTION.json").read_text())
assert base["returncode"]==0,"Preserve and resolve unexpected baseline failure before damages."
changes=[
    ("half_scalar_kinetic_density","KINETIC_DENSITY_COEFFICIENT = s.Integer(1)","KINETIC_DENSITY_COEFFICIENT = s.Rational(1,2)","action.lapse_constraint_normalization"),
    ("wrong_conformal_density_power","RADIATION_CONFORMAL_POWER = 4","RADIATION_CONFORMAL_POWER = 2","radiation.Einstein_conservation"),
    ("doubled_comparison_time","COMPARISON_TIME_DENOMINATOR = 2","COMPARISON_TIME_DENOMINATOR = 1","comparison.saturating_elapsed_time"),
    ("physical_clock_wrong_sign","PHYSICAL_CLOCK_COUPLING_SIGN = 1","PHYSICAL_CLOCK_COUPLING_SIGN = -1","clock.from_physical_scale_factor")
]
folder=ROOT/"damages_v1"
folder.mkdir(exist_ok=False)
protocol={"saved_before_execution":True,"baseline_code_sha256":sha(CODE),
          "controls":[{"name":n,"replace":old,"with":new,"required_failure":req} for n,old,new,req in changes],
          "producer_access":False}
(folder/"PROTOCOL.json").write_text(json.dumps(protocol,indent=2)+"\n")
source=CODE.read_text()
records=[]
for name,old,new,required in changes:
    assert source.count(old)==1
    changed=source.replace(old,new)
    path=folder/(name+".py")
    path.write_text(changed)
    (folder/(name+".diff")).write_text("".join(difflib.unified_diff(source.splitlines(keepends=True),changed.splitlines(keepends=True),fromfile=CODE.name,tofile=path.name)))
    rec=execute(path,folder/name)
    rec.update(name=name,required_failure=required,detected=rec["returncode"]==1 and required in rec.get("failed_checks",[]))
    records.append(rec)
summary={"all_detected":all(row["detected"] for row in records),"controls":records,
         "protocol_sha256":sha(folder/"PROTOCOL.json"),"baseline_sha256":sha(CODE)}
(folder/"SUMMARY.json").write_text(json.dumps(summary,indent=2)+"\n")
sys.exit(0 if summary["all_detected"] else 1)
