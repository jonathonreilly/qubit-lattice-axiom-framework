#!/usr/bin/env python3
"""Seal the completed independent radiation-duration evidence, without a rerun."""
from pathlib import Path
import datetime as dt
import hashlib
import json

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[6]
for name in ["FAILURES_v1.json","COMMAND_INDEX_v1.json","MANIFEST_v1.json","RECEIPT_v1.json"]:
    assert not (ROOT/name).exists(),name

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def bind(rel):
    path=ROOT/rel
    return {"path":rel,"bytes":path.stat().st_size,"sha256":sha(path)}

def write(name,obj):
    path=ROOT/name
    assert not path.exists()
    path.write_text(json.dumps(obj,indent=2)+"\n")

sources=json.loads((ROOT/"SOURCE_MANIFEST_v1.json").read_text())["sources"]
for row in sources:
    live=REPO/row["original_path"]
    snapshot=ROOT/row["snapshot_path"]
    assert sha(live)==row["sha256"]==sha(snapshot)
    assert live.stat().st_size==row["bytes"]==snapshot.stat().st_size

base=json.loads((ROOT/"baseline_v1/EXECUTION.json").read_text())
assert base["returncode"]==0 and base["counts"]=={"passed":72,"failed":0,"total":72}
assert base["code_sha256"]==sha(ROOT/"check_independent_v1.py")
for key,file in [("results_sha256","RESULTS_v1.json"),("stdout_sha256","stdout.txt"),("stderr_sha256","stderr.txt")]:
    assert base[key]==sha(ROOT/"baseline_v1"/file)
summary=json.loads((ROOT/"damages_v1/SUMMARY.json").read_text())
assert summary["all_detected"] and len(summary["controls"])==4
failures=[]
for row in summary["controls"]:
    folder=ROOT/"damages_v1"/row["name"]
    assert row["code_sha256"]==sha(ROOT/"damages_v1"/(row["name"]+".py"))
    for key,file in [("results_sha256","RESULTS_v1.json"),("stdout_sha256","stdout.txt"),("stderr_sha256","stderr.txt")]:
        assert row[key]==sha(folder/file)
    result=json.loads((folder/"RESULTS_v1.json").read_text())
    failed=[check for check in result["checks"] if not check["passed"]]
    assert row["returncode"]==1 and row["detected"]
    assert row["required_failure"] in [check["name"] for check in failed]
    failures.append({"name":row["name"],"counts":row["counts"],"exit_code":row["returncode"],
                     "required_failure":row["required_failure"],"actual_failed_checks":failed,
                     "code_sha256":row["code_sha256"],"results_sha256":row["results_sha256"]})
write("FAILURES_v1.json",{
    "unexpected_baseline_mathematical_failures":[],
    "exceptions_timeouts_or_tooling_failures":[],
    "source_errors_identified":[],
    "source_corrections_requested":False,
    "baseline_counts":base["counts"],
    "actual_expected_formula_damage_failures":failures,
    "interpretation":{
        "doubled_time":"Still a looser upper bound, but it fails the stated antiderivative and exact saturation normalization.",
        "wrong_clock_sign":"Fails direct scale-factor differentiation; a bound using the absolute coupling alone would not detect that sign."
    },
    "repairs_or_reruns":[],
    "failures_hidden_or_overwritten":False
})
write("COMMAND_INDEX_v1.json",{
    "source_snapshot_command":"SOURCE_MANIFEST_v1.json",
    "baseline_command":"baseline_v1/COMMAND.json",
    "baseline_execution":"baseline_v1/EXECUTION.json",
    "baseline_stdout":"baseline_v1/stdout.txt",
    "baseline_stderr":"baseline_v1/stderr.txt",
    "damage_protocol":"damages_v1/PROTOCOL.json",
    "damage_executions":[
        {"name":row["name"],"command":"damages_v1/"+row["name"]+"/COMMAND.json",
         "execution":"damages_v1/"+row["name"]+"/EXECUTION.json",
         "stdout":"damages_v1/"+row["name"]+"/stdout.txt",
         "stderr":"damages_v1/"+row["name"]+"/stderr.txt"}
        for row in summary["controls"]
    ],
    "primary_observation_network_access":False,
    "producer_code_or_results_accessed":False
})

now=dt.datetime.now(dt.timezone.utc).isoformat()
files=sorted(path for path in ROOT.rglob("*") if path.is_file())
assert not any(path.is_symlink() for path in ROOT.rglob("*"))
assert not any(path.suffix in {".pyc",".npz"} for path in files)
artifacts=[bind(str(path.relative_to(ROOT))) for path in files]
write("MANIFEST_v1.json",{
    "schema":"independent-review-artifact-manifest-v1",
    "created_utc":now,"artifact_root":str(ROOT),"artifact_count":len(artifacts),
    "excludes":["MANIFEST_v1.json","RECEIPT_v1.json"],"artifacts":artifacts
})
write("RECEIPT_v1.json",{
    "schema":"focused-independent-mathematical-check-receipt-v1",
    "created_utc":now,
    "unit":"initial_state/radiation_past_bound_v1/independent_v1",
    "scientific_author":"/root","independent_checker":"/root/scalar_energy_check",
    "formal_audit":False,"formal_grade_or_authority_state_changed":False,
    "scope":[
        "Action/lapse normalization, positive metric/potential, global conformal and coupling bounds",
        "Dimensionful radiation conformal conversion and separate conservation",
        "Comparison antiderivative, integration direction, scale normalization and proper clocks",
        "Full-action exact origin radiation saturation and separate vacuum limit",
        "Conditional physical curvature conclusion and endpoint/global-extension limitations",
        "Distinct exact synthetic controls and four actual damaged-formula executions"
    ],
    "source_bindings":sources,
    "manifest":bind("MANIFEST_v1.json"),
    "report":bind("REPORT_v1.md"),
    "hand_derivation":bind("HAND_DERIVATION_v1.md"),
    "protocol":bind("PROTOCOL_v1.json"),
    "independent_code":bind("check_independent_v1.py"),
    "execution_driver":bind("run_controls_v1.py"),
    "baseline_execution":bind("baseline_v1/EXECUTION.json"),
    "baseline_results":bind("baseline_v1/RESULTS_v1.json"),
    "baseline_counts":base["counts"],
    "damage_summary":bind("damages_v1/SUMMARY.json"),
    "actual_damage_counts":[{"name":row["name"],"counts":row["counts"],"exit_code":row["returncode"],"detected":row["detected"]} for row in summary["controls"]],
    "failure_ledger":bind("FAILURES_v1.json"),
    "command_index":bind("COMMAND_INDEX_v1.json"),
    "source_finding":{"errors_identified":[],"correction_required":False,"source_v1_preserved":True},
    "independence":{
        "hand_derivation_and_protocol_saved_before_checker_execution":True,
        "distinct_exact_parameters_and_controls":True,
        "producer_code_or_results_read_imported_or_run":False,
        "prior_trajectories_or_receipts_changed":False,
        "CMB_abstract_or_empirical_data_independently_obtained":False,
        "all_writes_confined_to_this_new_independent_directory":True,
        "parent_source_git_PR_runtime_lock_audit_state_changed":False
    },
    "claim_boundaries":[
        "The supplied action and classical homogeneous flat expanding premises remain conditional.",
        "Radiation positivity and separate conservation must hold throughout the interval, not merely at an observed epoch.",
        "The duration is for the Einstein and physical homogeneous comoving proper clocks.",
        "No initial scalar point is assumed for the general bound; the origin solution is only a saturation example.",
        "Finite regular interval duration alone does not classify an earlier chart endpoint.",
        "Physical curvature divergence follows conditionally when the branch reaches a_E=0.",
        "No universal global-extension or all-geodesic theorem is established.",
        "No uniform numerical age bound over unknown C0, radiation normalization or supplied scales.",
        "No CMB temperature calibration, empirical acceptance, state selection or authorship transfer."
    ]
})
for row in artifacts:
    p=ROOT/row["path"]
    assert sha(p)==row["sha256"] and p.stat().st_size==row["bytes"]
assert len([p for p in ROOT.rglob("*") if p.is_file()])==len(artifacts)+2
print(json.dumps({
    "artifact_count_excluding_manifest_receipt":len(artifacts),
    "total_regular_files":len(artifacts)+2,
    "source_pairs":len(sources),
    "report_sha256":sha(ROOT/"REPORT_v1.md"),
    "manifest_sha256":sha(ROOT/"MANIFEST_v1.json"),
    "receipt_sha256":sha(ROOT/"RECEIPT_v1.json"),
    "all_bound_artifacts_verified":True
},indent=2))
