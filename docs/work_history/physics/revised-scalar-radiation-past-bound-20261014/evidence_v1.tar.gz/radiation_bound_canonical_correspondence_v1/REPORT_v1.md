# Radiation past-bound canonical correspondence

The frozen canonical note, runner and cache correspond to the independently checked source. No mathematical correction or unbound consequential implementation path was found. This unit is ready to be included in a recovery archive; the final committed five-path delivery mapping remains a separate task. Scientific authorship stays with `/root`. This is source/evidence correspondence by `/root/local_response_check`, with no formal audit, scientific grade or authority-state change.

## Sources and review boundary

All 95 selected source/evidence files were copied before review and remain byte-identical to their live originals. `SOURCE_MANIFEST_v1.json` records every original path, snapshot path, byte count and SHA-256. The complete canonical note and runner, the complete supplied action note, original derivation, original independent hand derivation/report, and packaging records were read. Producer access is permitted for this correspondence; it is not being presented as a new blind derivation.

| Bound source | SHA-256 |
|---|---|
| Canonical radiation note | `c6751e952b5d645f6505ad160c8da8f08b0e01cdf36a3aecc08ac117741dcc08` |
| Canonical primary runner | `bdfdd7b7089bbb1c3d0fee106909f8ebd04846a1e5318e0a575ce38fd755ad8e` |
| Canonical cache | `ecdebea968fc77f584e6f767cc4613be35ec6e7a8179b52e09a3a08822dfe552` |
| Complete future-confinement action note | `39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000` |
| Original radiation derivation | `eabdd21138c7b0c1113715c8e607494e94f3b39300e457beb7dfbd884cfa16e1` |
| Original producer runner | `bb5186b75e3a9897d8bd979f60d311a2bb11395675c8a358af7f380b4715e500` |
| Original independent receipt | `907872850d04723730764d5fe7a587a2d2a1e340e7484c3097864600ea979e47` |
| Original independent report | `2057644c7ea35bb6386bc24928ec8392a7021294faa88f3dd73dfb37101efd02` |
| Original independent manifest | `2906cbed6d2ca1e679837832d1f4e59d7d1377ddc55d9a1d53860a64be47bbbf` |

The original independent unit belongs to `/root/scalar_energy_check`. Its 49 manifest artifacts and four live/snapshot source pairs were verified, including its actual failed damaged-code runs. Its 72/0 result is reused with that original identity. It was not produced or rerun by this correspondence checker.

## Mathematical and physical correspondence

The original proof body is identical apart from presentation of the primary-source link. Canonical additions supply metadata, verification scope, and qualifications already supported by the independent proof. The exact source diff is preserved in `DISCOVERY_TO_CANONICAL_NOTE_v1.diff`.

1. **Action and positive domain.** The supplied action has kinetic term `-Q K_AB partial(phi^A).partial(phi^B)`, so the homogeneous kinetic density is `Q |phi_dot|_K^2`, without an extra factor of one-half. Its constraint is `3Q H_E^2=Q|phi_dot|_K^2+2Q Hv^2 U+rho_E,total`. The original independent lapse calculation checks this consequential normalization. For `0<k<1/3`, `nu>0`, `Q,Hv>0`, and the finite field chart, every diagonal kinetic entry is positive and every term in `U-3/2` is nonnegative. This use of the action does not import the narrower `nu<=6a_k` condition belonging to the separate future-convergence argument.

2. **Physical clock.** `b_u=sqrt(a_k)/F`, `|b|_K^2=a_k/J<a_k<1/3`, and `C<Cmax=(1+s)/s`. The constraint and Cauchy-Schwarz give `H_J=(H_E+b.phi_dot)/A >= eta_k H_E/A >= eta_k H_E/sqrt(Cmax)>0`, where `eta_k=1-sqrt(3a_k)`. This covers negative as well as positive `b.phi_dot`; the primary symbolic conservation check declares its auxiliary `c` positive, but the proof does not rely on that declaration. The independent unit contains an oppositely directed scalar-velocity check. The expanding Einstein sheet cannot cross zero because `H_E^2>=Hv^2`. No lower bound on `A` is needed to bound the physical duration from above.

3. **Radiation and dimensions.** The conformal stress conversion is `rho_r,E=A^4 rho_r,J`. Separate physical conservation with isotropic massless stress gives `rho_r,J a_J^4=constant`, hence `rho_r,E a_E^4=constant` even with rolling `A`. The radiation trace vanishes in the scalar equation. These are dimensionful densities: the older canonical normalized `rho_J` must first be multiplied by `rho_unit`, as the independent report explicitly notes. This background statement assumes isotropy and separate conservation; it does not impose a perfect-fluid closure on general collisionless perturbations.

4. **Duration comparison.** For `D=a0^2 sqrt(rho0/(3Q))>0` and `X=a_E^2`, positivity gives `X_dot>=2 sqrt(Hv^2 X^2+D^2)`. The increasing comparison function `T(X)=asinh(Hv X/D)/(2Hv)` obeys `dT/dt_E>=1`. Thus each earlier regular event satisfies `t0-t <=T(X0)-T(X(t))<Tstar`; the supremum is at most `Tstar=asinh(Hv sqrt(3Q/rho0))/(2Hv)`. The scale-factor normalization cancels. Integrating `dt_J=A dt_E` gives the bound `sqrt(Cmax) Tstar` for comoving physical proper time. A specified scalar point or bounded past scalar trajectory is unnecessary. Nonnegative other densities, flat homogeneous classical evolution, the supplied action/domain and conserved positive radiation remain premises.

5. **Sharp example and endpoint.** The origin scalar state with only radiation satisfies the full action equations: the potential gradient and radiation trace source vanish. `X=(D/Hv)sinh(2Hv(t_E-t_B))` saturates the Einstein comparison, and its Raychaudhuri equation also holds. This is an unselected example, not a classification of all solutions. Its physical clock is `A=1`, so it generally does not saturate the larger physical bound. If an allowed regular branch reaches `a_E->0`, conserved radiation and the clock inequality force `H_J->infinity`; the flat FLRW Kretschmann invariant is at least `12H_J^4`. A finite duration alone does not establish curvature divergence at an earlier finite-`a_E` chart endpoint. In the exact radiation example the Ricci scalar stays `12Hv^2`, while the Kretschmann invariant diverges. The canonical added distinction is correct.

6. **Limits and observational scope.** Strictly positive radiation is essential. The separate exact zero-radiation origin vacuum has unbounded comoving past proper time in its flat patch and finite curvature, without implying completeness of all geodesics. At fixed `Hv,Q`, the comparison bound diverges as `rho0->0+`; at fixed positive physical density, `C0->0` likewise sends `rho0=C0^2 rho_r,J0` toward zero. At fixed `Q,rho0`, however, `Hv->0+` has the finite coarse limit `sqrt(3Q/rho0)/2`; unknown `Hv` alone is not a divergence argument. The nonuniformity/uncalibrated-age wording is read with this explicit distinction. The fixed-`k` clock margin also vanishes as `k->1/3`, so no uniform positive clock margin is claimed. None of these bounds chooses an initial state, establishes the earliest-universe premises from the CMB, supplies a measured age, or proves a general spacetime-extension or all-geodesics theorem.

## Implementation and evidence

The parsed calculation body and its literal text, from `rows=[]` through the end, are unchanged from the original producer runner. The only runner changes are the optional temporary output wrapper, a `tempfile` import, and literal timeout/input declarations. The import closure is standard library plus SymPy and SciPy; there is no unbound local science helper. The action and theorem note are both declared cache inputs. `DISCOVERY_TO_CANONICAL_RUNNER_v1.diff` preserves the entire change.

The fresh cache records the author's actual run at 09:52:51–09:52:52 UTC on 2026-10-14, exit 0, with 58 passing and zero failing controls. Its runner SHA and independently reconstructed input fingerprint match the frozen/live sources. The fingerprint is `febdeeb110cb84580c1583df6f5e0b2c84cd6c33914ea0399de90524deefc724`. Its full result equals both the packaging primary result and the original discovery result. The 12 positive-extra-density quadratures are comparison functions, not demonstrated scalar trajectories. Sampled monotonic values labeled as limit controls are supporting checks; the analytical arguments establish the actual limits.

The original independent altered copies remain 71/1, 68/4, 65/7 and 71/1, each with exit 1 and the intended failed identities. The author's canonical altered copies remain 56/2, 54/4 and 57/1, each exit 1. Exact one-location source changes, code hashes, commands, outputs and failed-check lists were checked. None was rerun or relabeled as new independent science. All seven failed executions remain in the source snapshots.

New work in this unit comprises 60/0 initial binding checks, 132/0 source/evidence correspondence checks, and 154/0 final identity checks. These counts overlap by design and are metadata/integrity controls, not additional physics tests. The three execution records preserve exact command, working directory, code hash, time, exit status, stdout and stderr. No science runner was executed by this unit. No unexpected failure or source correction occurred.

One new attribution check opened [Fixsen's primary arXiv abstract](https://arxiv.org/abs/0911.1955): the quoted `2.72548 +/- 0.00057 K` is correctly the combined estimate. It is distinct from the abstract's individual recalibration value. No density was inferred or model calibrated. `PRIMARY_ABSTRACT_ATTRIBUTION_v1.json` records the factual comparison; it is an access receipt rather than a preserved remote-page byte hash. `SCOPE_CLARIFICATION_v2.json` preserves the narrow departure from the checker's initial no-network planning flag. No parent restriction was bypassed, no PDF or observational data pipeline was used, and no new agent was launched.

## Disposition

`CLAIM_DISPOSITIONS_v1.json` records the retained conditional claims and exclusions. Source and equation corrections are not requested; there is consequently no corrected-author-source confirmation to fabricate. All earlier seals remain unchanged. The recovery archive, final commit identities, exact five-path delta and delivery mapping have not yet been inspected by this unit and must be bound separately after they exist. No Git, PR, runtime, lock, authority state or parent source was changed.
