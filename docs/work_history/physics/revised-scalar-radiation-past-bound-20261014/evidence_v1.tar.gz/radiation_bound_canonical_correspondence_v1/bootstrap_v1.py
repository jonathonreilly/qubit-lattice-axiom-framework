from pathlib import Path
import datetime,hashlib,json,shutil,sys
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[4];PACK=HERE.parent
scope=json.loads((HERE/'SCOPE_v1.json').read_text());unit=PACK/'initial_state/radiation_past_bound_v1/independent_v1'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(name,v):(HERE/name).write_text(json.dumps(v,indent=2)+'\n')
receipt=json.loads((unit/'RECEIPT_v1.json').read_text());manifest=json.loads((unit/'MANIFEST_v1.json').read_text());checks=[]
def check(name,ok,**kw):checks.append({'name':name,'passed':bool(ok),**kw})
check('expected_receipt',h(unit/'RECEIPT_v1.json')==scope['expected_independent_receipt'])
for rel,expected in scope['expected_source_hashes'].items():check('expected_source.'+rel,h(ROOT/rel)==expected,actual_sha256=h(ROOT/rel))
for item in manifest['artifacts']:
 p=unit/item['path'];check('old_artifact.'+item['path'],h(p)==item['sha256'] and p.stat().st_size==item['bytes'])
for name in ['manifest','report']:
 item=receipt[name];p=unit/item['path'];check('receipt_'+name,h(p)==item['sha256'] and p.stat().st_size==item['bytes'])
for i,item in enumerate(receipt['source_bindings']):
 live=ROOT/item['original_path'];snap=unit/item['snapshot_path'];check('old_source_pair.'+str(i),h(live)==h(snap)==item['sha256'] and live.stat().st_size==snap.stat().st_size==item['bytes'])
selected={ROOT/r for r in scope['expected_source_hashes']}
for directory in [PACK/'initial_state/radiation_past_bound_v1',PACK/'radiation_bound_packaging']:
 for p in directory.rglob('*'):
  assert not p.is_symlink(),str(p)
  if p.is_file():selected.add(p)
selected.add(ROOT/'scripts/runner_cache.py')
for item in receipt['source_bindings']:selected.add(ROOT/item['original_path'])
sources=[]
for p in sorted(selected):
 rel=p.relative_to(ROOT);dest=HERE/'sources'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);sources.append({'original_path':str(rel),'snapshot_path':str(dest.relative_to(HERE)),'bytes':p.stat().st_size,'sha256':h(p)})
put('SOURCE_MANIFEST_v1.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':sources,'source_count':len(sources),'all_snapshotted_before_review':True})
put('REUSED_EVIDENCE_BINDING_v1.json',{'unit':str(unit.relative_to(ROOT)),'receipt_sha256':h(unit/'RECEIPT_v1.json'),'report_sha256':h(unit/'REPORT_v1.md'),'manifest_sha256':h(unit/'MANIFEST_v1.json'),'original_artifacts':len(manifest['artifacts']),'original_source_pairs':len(receipt['source_bindings']),'checks':checks,'counts':{'passed':sum(r['passed'] for r in checks),'failed':sum(not r['passed'] for r in checks)},'science_rerun':False})
print(json.dumps({'source_count':len(sources),'original_artifacts':len(manifest['artifacts']),'original_source_pairs':len(receipt['source_bindings']),'failed':[r for r in checks if not r['passed']]},indent=2));sys.exit(any(not r['passed'] for r in checks))
