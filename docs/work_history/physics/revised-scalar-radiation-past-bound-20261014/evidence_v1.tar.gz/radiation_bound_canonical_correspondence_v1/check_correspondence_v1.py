"""Metadata/source-only correspondence. Never import or execute science code."""
from pathlib import Path
from datetime import datetime, timezone
import ast, difflib, hashlib, json, sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
PK = Path('.claude/science/physics-loops/revised-scalar-derivation-24h-20261013')
SRC = HERE / 'sources'
RP = PK / 'initial_state/radiation_past_bound_v1'
OLD = RP / 'independent_v1'
PACK = PK / 'radiation_bound_packaging'
NOTE = 'docs/EXPONENTIAL_SCALAR_RADIATION_PAST_BOUND_BOUNDED_THEOREM_NOTE_2026-10-14.md'
ACTION = 'docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md'
RUNNER = 'scripts/exponential_scalar_radiation_past_bound_check.py'
CACHE = 'logs/runner-cache/exponential_scalar_radiation_past_bound_check.txt'
rows = []
def check(name, condition, evidence=None):
    rows.append({'name': name, 'passed': bool(condition), 'evidence': evidence})
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def data(rel): return json.loads((SRC / rel).read_text())
def save(name, obj):
    path = HERE / name
    assert not path.exists(), str(path)
    path.write_text(json.dumps(obj, indent=2) + '\n')

# All original bytes, including archived failures, remain recoverable and live.
sm = json.loads((HERE/'SOURCE_MANIFEST_v1.json').read_text())
for row in sm['sources']:
    live, snap = ROOT/row['original_path'], HERE/row['snapshot_path']
    check('source_identity.'+row['original_path'],
          live.is_file() and snap.is_file() and not live.is_symlink() and not snap.is_symlink()
          and sha(live) == sha(snap) == row['sha256']
          and live.stat().st_size == snap.stat().st_size == row['bytes'])
check('snapshot_count', sm['source_count'] == len(sm['sources']) == 95)
reuse = json.loads((HERE/'REUSED_EVIDENCE_BINDING_v1.json').read_text())
check('original_seal_binding', reuse['counts'] == {'passed':60, 'failed':0}
      and reuse['original_artifacts']==49 and reuse['original_source_pairs']==4)

# Text proof is unchanged after the explicitly identified URL-presentation edit.
old_note = (SRC/RP/'DERIVATION_v1.md').read_text()
new_note = (SRC/NOTE).read_text()
begin = '## Observation and premise boundary'
end = '## Verification and remaining physical work'
raw_link = 'https://arxiv.org/abs/0911.1955 (v2; DOI10.1088/0004-637X/707/2/916).'
new_link = '[Fixsen2009, v2](https://arxiv.org/abs/0911.1955) (DOI10.1088/0004-637X/707/2/916).'
old_body = old_note[old_note.index(begin):].strip()
new_body = new_note[new_note.index(begin):new_note.index(end)].strip()
check('note.only_link_presentation_in_original_proof', old_body.count(raw_link)==1
      and old_body.replace(raw_link,new_link)==new_body)
(HERE/'DISCOVERY_TO_CANONICAL_NOTE_v1.diff').write_text(''.join(difflib.unified_diff(
    old_note.splitlines(True),new_note.splitlines(True),fromfile=str(RP/'DERIVATION_v1.md'),tofile=NOTE)))
check('note.linked_complete_action', Path(ACTION).name in new_note)
check('note.additional_scope_guards', all(q in new_note for q in [
    'comparison functions, not full scalar', 'finite Ricci scalar12Hv^2',
    'Kretschmann invariant diverges', 'not a general geodesic-incompleteness theorem',
    'No formal audit or effective', 'No state selection']))

# Compare parsed statements starting with rows=[], excluding only output setup.
old_code = (SRC/RP/'check_past_bound_v1.py').read_text()
new_code = (SRC/RUNNER).read_text()
ot, nt = ast.parse(old_code), ast.parse(new_code)
def main_body(tree):
    fn = next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
    start = next(i for i,n in enumerate(fn.body) if isinstance(n,ast.Assign)
                 and any(isinstance(t,ast.Name) and t.id=='rows' for t in n.targets))
    return fn.body[:start], fn.body[start:]
old_wrap, old_math = main_body(ot); new_wrap, new_math = main_body(nt)
check('runner.unchanged_calculation_ast', ast.dump(ast.Module(body=old_math,type_ignores=[]),include_attributes=False)
      == ast.dump(ast.Module(body=new_math,type_ignores=[]),include_attributes=False))
check('runner.unchanged_calculation_text', old_code[old_code.index(' rows=[]'):]
      == new_code[new_code.index(' rows=[]'):])
check('runner.optional_output_wrapper', "ap.add_argument('--output')" in new_code
      and 'tempfile.TemporaryDirectory' in new_code and 'exist_ok=False' in new_code)
imports=[]
for node in nt.body:
    if isinstance(node,ast.Import): imports.extend(a.name for a in node.names)
    if isinstance(node,ast.ImportFrom): imports.append(node.module)
check('runner.import_closure', imports==['argparse','json','math','pathlib','tempfile','sympy','scipy.integrate'], imports)
decl={n.targets[0].id:ast.literal_eval(n.value) for n in nt.body if isinstance(n,ast.Assign)
      and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
check('runner.cache_declarations', decl=={'AUDIT_TIMEOUT_SEC':120,'AUDIT_INPUT_PATHS':[NOTE,ACTION]},decl)
check('runner.no_empirical_temperature_input', '2.72548' not in new_code and '0.00057' not in new_code)
(HERE/'DISCOVERY_TO_CANONICAL_RUNNER_v1.diff').write_text(''.join(difflib.unified_diff(
    old_code.splitlines(True),new_code.splitlines(True),fromfile=str(RP/'check_past_bound_v1.py'),tofile=RUNNER)))
sr=data(PACK/'SOURCE_REUSE_v1.json')
check('reuse.authored_source_identities', sr['source_note_sha256']==sha(SRC/RP/'DERIVATION_v1.md')
      and sr['canonical_note_sha256']==sha(SRC/NOTE)
      and sr['source_runner_sha256']==sha(SRC/RP/'check_past_bound_v1.py')
      and sr['canonical_runner_sha256']==sha(SRC/RUNNER) and sr['equation_change'] is False)

# Original independent execution and altered-code controls: receipts, not reruns.
old_receipt=data(OLD/'RECEIPT_v1.json')
baseline=data(OLD/'baseline_v1/RESULTS_v1.json')
bexec=data(OLD/'baseline_v1/EXECUTION.json')
check('independent.original_checker_identity', baseline['checker']=='/root/scalar_energy_check'
      and baseline['producer_code_or_results_accessed'] is False)
check('independent.baseline_72_0', baseline['counts']=={'passed':72,'failed':0,'total':72}
      and len(baseline['checks'])==72 and all(x['passed'] for x in baseline['checks'])
      and old_receipt['baseline_counts']==baseline['counts'])
check('independent.baseline_command_result_bindings', bexec['returncode']==0
      and bexec['code_sha256']==sha(SRC/OLD/'check_independent_v1.py')
      and bexec['results_sha256']==sha(SRC/OLD/'baseline_v1/RESULTS_v1.json')
      and bexec['stdout_sha256']==sha(SRC/OLD/'baseline_v1/stdout.txt')
      and bexec['stderr_sha256']==sha(SRC/OLD/'baseline_v1/stderr.txt'))
damage_protocol=data(OLD/'damages_v1/PROTOCOL.json')
damage_summary=data(OLD/'damages_v1/SUMMARY.json')
ind_damage_rows=[]
old_ind_code=(SRC/OLD/'check_independent_v1.py').read_text()
for control in damage_protocol['controls']:
    name=control['name']; folder=OLD/'damages_v1'/name
    rec=next(x for x in damage_summary['controls'] if x['name']==name)
    exe=data(folder/'EXECUTION.json'); result=data(folder/'RESULTS_v1.json')
    code=SRC/OLD/'damages_v1'/(name+'.py')
    failed=[x['name'] for x in result['checks'] if not x['passed']]
    check('independent.damage_code.'+name, old_ind_code.count(control['replace'])==1
          and old_ind_code.replace(control['replace'],control['with'])==code.read_text()
          and sha(code)==rec['code_sha256']==exe['code_sha256'])
    check('independent.damage_execution.'+name, rec['returncode']==exe['returncode']==1
          and result['counts']==rec['counts']==exe['counts']
          and len(result['checks'])==72 and failed==rec['failed_checks']==exe['failed_checks']
          and control['required_failure'] in failed
          and sha(SRC/folder/'RESULTS_v1.json')==rec['results_sha256']==exe['results_sha256']
          and sha(SRC/folder/'stdout.txt')==rec['stdout_sha256']==exe['stdout_sha256']
          and sha(SRC/folder/'stderr.txt')==rec['stderr_sha256']==exe['stderr_sha256'])
    ind_damage_rows.append({'name':name,'counts':result['counts'],'exit_code':exe['returncode'],
                            'failed_checks':failed,'reexecuted_in_this_unit':False})
check('independent.four_actual_damages', len(ind_damage_rows)==4 and damage_summary['all_detected'])

# Fresh cache is tied to literal source inputs, not merely a count or wall clock.
primary=data(PACK/'PRIMARY_RESULTS_v1.json')
check('primary.counts_58_0', primary['passed']==58 and primary['failed']==0
      and len(primary['checks'])==58 and all(x['ok'] for x in primary['checks']))
check('primary.comparison_only_scope', len(primary['comparison_samples'])==12
      and 'comparison-function quadrature' in primary['scope'] and 'No full rolling orbit' in primary['scope'])
check('primary.stdout_matches_recorded_result', json.loads((SRC/PACK/'PRIMARY_v1.stdout').read_text())==primary
      and (SRC/PACK/'PRIMARY_v1.stderr').read_bytes()==b'')
cache=(SRC/CACHE).read_text()
prefix,rest=cache.split('----- stdout -----\n',1)
stdout,stderr=rest.split('----- stderr -----\n',1)
header=dict(line.split(': ',1) for line in prefix.splitlines() if ': ' in line)
fingerprint=hashlib.sha256(b'runner-cache-input-fingerprint-v1\0')
for rel in decl['AUDIT_INPUT_PATHS']:
    rb=rel.encode();body=(SRC/rel).read_bytes()
    fingerprint.update(len(rb).to_bytes(8,'big'));fingerprint.update(rb)
    fingerprint.update(len(body).to_bytes(8,'big'));fingerprint.update(body)
check('cache.header_and_fingerprint', header['runner']==RUNNER
      and header['runner_sha256']==sha(SRC/RUNNER)
      and header['input_fingerprint_sha256']==fingerprint.hexdigest()
      and header['timeout_sec']=='120' and header['exit_code']=='0' and header['status']=='ok',header)
check('cache.primary_result_identity', json.loads(stdout)==primary and not stderr.strip())
cmd=data(PACK/'CACHE_COMMAND_v1.json');run=data(PACK/'CACHE_RUN_v1.json')
check('cache.recorded_actual_execution', cmd['operation']=='runner_cache.execute_and_write_cache'
      and cmd['runner']==run['execution']['runner']==RUNNER
      and cmd['runner_sha256']==sha(SRC/RUNNER)
      and cmd['runtime_inputs']==[{'path':r,'sha256':sha(SRC/r)} for r in [NOTE,ACTION]]
      and run['cache_sha256']==sha(SRC/CACHE) and run['execution']['exit_code']==0
      and run['execution']['status']=='ok' and run['freshness']=='fresh'
      and run['counts']=={'passed':58,'failed':0}
      and cmd['at']==run['started'] and run['finished']>run['started'])

# Actual damaged copies from the canonical author run; no new damage execution.
parent_damages=data(PACK/'DAMAGES_SUMMARY_v1.json')
parent_damage_rows=[]
expected={'wrong_radiation_power':(56,2),'wrong_comparison_denominator':(54,4),'wrong_potential_floor':(57,1)}
for rec in parent_damages:
    name=rec['name'];folder=PACK/'damages_v1'/name
    exe=data(folder/'RUN.json');cmd=data(folder/'COMMAND.json')
    result=data(folder/'results/RESULTS.json');code=SRC/folder/'changed.py'
    old,new=rec['replacement'];failed=[r['name'] for r in result['checks'] if not r['ok']]
    check('parent.damage_exact_code.'+name, new_code.count(old)==1 and new_code.replace(old,new)==code.read_text()
          and sha(code)==rec['changed_sha256']==exe['changed_sha256']==cmd['changed_sha256']
          and rec['source_sha256']==sha(SRC/RUNNER))
    check('parent.damage_actual_result.'+name, rec['exit_code']==exe['exit_code']==1
          and (rec['passed'],rec['failed'])==expected[name]
          and (result['passed'],result['failed'])==expected[name]
          and len(result['checks'])==58 and len(failed)==expected[name][1]
          and json.loads((SRC/folder/'stdout').read_text())==result
          and sha(SRC/folder/'stdout')==rec['stdout_sha256']==exe['stdout_sha256']
          and sha(SRC/folder/'stderr')==rec['stderr_sha256']==exe['stderr_sha256']
          and (SRC/folder/'stderr').read_bytes()==b''
          and rec['argv']==exe['argv']==cmd['argv']
          and rec['argv'][1]==str(folder/'changed.py') and rec['argv'][-1]==str(folder/'results'))
    parent_damage_rows.append({'name':name,'passed':result['passed'],'failed':result['failed'],
                              'exit_code':exe['exit_code'],'failed_checks':failed,'reexecuted_in_this_unit':False})
check('parent.three_actual_damages',len(parent_damage_rows)==3)

save('CORRESPONDENCE_RESULTS_v1.json',{
    'created_utc':datetime.now(timezone.utc).isoformat(),
    'scope':'Source/evidence correspondence only; no independent or producer science runner reexecution.',
    'script_sha256':sha(Path(__file__)), 'checks':rows,
    'counts':{'passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),'total':len(rows)},
    'reused_independent_baseline':baseline['counts'], 'reused_independent_damages':ind_damage_rows,
    'reused_primary_baseline':{'passed':primary['passed'],'failed':primary['failed']},
    'reused_parent_damages':parent_damage_rows,
    'cache_input_fingerprint_sha256':fingerprint.hexdigest(),
    'science_runner_executions_in_this_unit':0, 'source_edits':0})
print(json.dumps({'passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),
                  'failed_checks':[x['name'] for x in rows if not x['passed']],'science_executions':0},indent=2))
sys.exit(any(not x['passed'] for x in rows))
