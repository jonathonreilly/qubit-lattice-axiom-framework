"""Final source freshness and execution-link checks only; no science run."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
H=Path(__file__).resolve().parent;R=H.parents[4];S=H/'sources'
P=Path('.claude/science/physics-loops/revised-scalar-derivation-24h-20261013')
RP=P/'initial_state/radiation_past_bound_v1';PK=P/'radiation_bound_packaging'
rows=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(n,b,e=None):rows.append({'name':n,'passed':bool(b),'evidence':e})
def data(p):return json.loads(p.read_text())
for x in data(H/'SOURCE_MANIFEST_v1.json')['sources']:
    l=R/x['original_path'];s=H/x['snapshot_path']
    check('final_source.'+x['original_path'],l.read_bytes()==s.read_bytes()
          and sha(l)==x['sha256'] and l.stat().st_size==x['bytes'])
for tag in ['bootstrap_execution_v1','correspondence_execution_v1']:
    e=data(H/(tag+'.json'))
    check('execution_code.'+tag,sha(Path(e['command'][2]))==e['script_sha256']
          and e['exit_code']==0 and not e['timed_out'])
    for stream in ['stdout','stderr']:
        v=e[stream];p=H/v['path']
        check('execution_stream.'+tag+'.'+stream,sha(p)==v['sha256'] and p.stat().st_size==v['bytes'])
orig=data(S/RP/'baseline_v1/RESULTS.json');primary=data(S/PK/'PRIMARY_RESULTS_v1.json')
check('original_primary_exact_results_reused',orig==primary)
old_run=data(S/RP/'RUN_v1.json');old_cmd=data(S/RP/'COMMAND_v1.json')
check('original_run_is_successful_58_0',orig['passed']==58 and orig['failed']==0
      and old_run['exit_code']==0 and old_run['argv']==old_cmd['argv'])
check('original_stdout_matches_json',json.loads((S/RP/'RUN_v1.stdout').read_text())==orig
      and not (S/RP/'RUN_v1.stderr').read_bytes())
check('new_correspondence_is_132_0',data(H/'CORRESPONDENCE_RESULTS_v1.json')['counts']=={'passed':132,'failed':0,'total':132})
old_manifest=data(S/RP/'independent_v1/MANIFEST_v1.json')
for item in old_manifest['artifacts']:
    p=S/RP/'independent_v1'/item['path']
    check('original_seal_artifact.'+item['path'],sha(p)==item['sha256'] and p.stat().st_size==item['bytes'])
result={'created_utc':datetime.now(timezone.utc).isoformat(),'scope':'Final identity/freshness only',
        'checks':rows,'counts':{'passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),'total':len(rows)},
        'science_executions':0,'prior_evidence_reused_without_change':True}
out=H/'FINAL_BINDING_RESULTS_v1.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'counts':result['counts'],'failed_checks':[r for r in rows if not r['passed']]},indent=2))
sys.exit(any(not x['passed'] for x in rows))
