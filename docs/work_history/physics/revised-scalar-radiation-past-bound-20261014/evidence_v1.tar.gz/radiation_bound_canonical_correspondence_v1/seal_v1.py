"""Seal this focused unit after final immutable source and execution checks."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys

H=Path(__file__).resolve().parent;R=H.parents[4]
start=datetime.now(timezone.utc).isoformat()
assert not (H/'MANIFEST_v1.json').exists()
assert not (H/'RECEIPT_v1.json').exists()
assert not (H/'SEAL_EXECUTION_v1.json').exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((H/n).read_text())
def write(n,x):(H/n).write_text(json.dumps(x,indent=2)+'\n')
def binding(n):
    p=H/n;return {'path':n,'bytes':p.stat().st_size,'sha256':sha(p)}
sources=read('SOURCE_MANIFEST_v1.json')['sources']
for row in sources:
    live=R/row['original_path'];snap=H/row['snapshot_path']
    assert not live.is_symlink() and not snap.is_symlink()
    assert sha(live)==sha(snap)==row['sha256']
    assert live.stat().st_size==snap.stat().st_size==row['bytes']
for tag in ['bootstrap_execution_v1','correspondence_execution_v1','final_binding_execution_v1']:
    row=read(tag+'.json')
    assert row['exit_code']==0 and not row['timed_out']
    assert sha(Path(row['command'][2]))==row['script_sha256']
    for kind in ['stdout','stderr']:
        item=row[kind];p=H/item['path']
        assert sha(p)==item['sha256'] and p.stat().st_size==item['bytes']
assert read('CORRESPONDENCE_RESULTS_v1.json')['counts']=={'passed':132,'failed':0,'total':132}
assert read('FINAL_BINDING_RESULTS_v1.json')['counts']=={'passed':154,'failed':0,'total':154}
assert read('REUSED_EVIDENCE_BINDING_v1.json')['counts']=={'passed':60,'failed':0}
finish=datetime.now(timezone.utc).isoformat()
write('SEAL_EXECUTION_v1.json',{'started_utc':start,'finished_pre_manifest_utc':finish,
    'command':[sys.executable,'-B',str(Path(__file__).resolve())],'cwd':str(H),
    'script_sha256':sha(Path(__file__)),'verified_live_source_pairs':len(sources),
    'verified_prior_execution_records':3,'science_executions':0,
    'operation':'Verify source/command bindings, then hash all payload artifacts; receipt binds manifest. No writes follow successful sealing.'})
artifacts=[]
for p in sorted(H.rglob('*')):
    assert not p.is_symlink(),str(p)
    if p.is_file():artifacts.append(binding(str(p.relative_to(H))))
write('MANIFEST_v1.json',{'schema':'focused-canonical-correspondence-artifact-manifest-v1',
    'created_utc':finish,'unit':str(H.relative_to(R)),'artifact_count':len(artifacts),
    'excludes':['MANIFEST_v1.json','RECEIPT_v1.json'],'artifacts':artifacts})
reuse=read('REUSED_EVIDENCE_BINDING_v1.json')
receipt={'schema':'focused-radiation-bound-canonical-correspondence-receipt-v1',
    'created_utc':datetime.now(timezone.utc).isoformat(),
    'unit':str(H.relative_to(R)),'scientific_author':'/root','checker':'/root/local_response_check',
    'formal_audit':False,'formal_grade_or_authority_state_changed':False,
    'scope':'Final whole-source/evidence correspondence; prior independent proof and actual damage runs reused with original identity. No science rerun.',
    'report':binding('REPORT_v1.md'),'manifest':binding('MANIFEST_v1.json'),
    'artifact_count':len(artifacts),'source_count':len(sources),'source_bindings':sources,
    'new_metadata_counts':{'initial_binding':{'passed':60,'failed':0},
                           'correspondence':{'passed':132,'failed':0},
                           'final_binding':{'passed':154,'failed':0}},
    'counts_qualification':'These are overlapping source/identity controls, not new physics controls.',
    'evidence_results':[binding('REUSED_EVIDENCE_BINDING_v1.json'),binding('CORRESPONDENCE_RESULTS_v1.json'),binding('FINAL_BINDING_RESULTS_v1.json')],
    'original_independent_unit':{'checker':'/root/scalar_energy_check','path':reuse['unit'],
        'receipt_sha256':reuse['receipt_sha256'],'report_sha256':reuse['report_sha256'],
        'manifest_sha256':reuse['manifest_sha256'],'artifacts':49,'source_pairs':4,
        'counts':{'passed':72,'failed':0},'actual_damaged_copies':4,'reexecuted_here':False},
    'canonical_author_evidence':{'counts':{'passed':58,'failed':0},'actual_damaged_copies':3,
        'cache_sha256':'ecdebea968fc77f584e6f767cc4613be35ec6e7a8179b52e09a3a08822dfe552',
        'input_fingerprint_sha256':'febdeeb110cb84580c1583df6f5e0b2c84cd6c33914ea0399de90524deefc724',
        'fresh_against_current_note_and_full_action':True,'reexecuted_here':False},
    'claim_dispositions':binding('CLAIM_DISPOSITIONS_v1.json'),
    'failures_and_corrections':binding('FAILURES_AND_CORRECTIONS_v1.json'),
    'commands':binding('COMMAND_INDEX_v1.json'),'seal_execution':binding('SEAL_EXECUTION_v1.json'),
    'primary_attribution_access':binding('PRIMARY_ABSTRACT_ATTRIBUTION_v1.json'),
    'scope_clarification':binding('SCOPE_CLARIFICATION_v2.json'),
    'reviewer_confirmation':{'all_frozen_sources_current':True,'consequential_calculation_paths_unchanged':True,
        'whole_note_action_and_scope_read':True,'substantive_corrections_requested':[],
        'corrected_source_confirmation':'Not applicable: no author-source correction required.'},
    'science_runner_executions_here':0,'parent_source_changes':0,'git_or_pr_mutations':0,
    'new_agents':0,'prior_seals_modified':False,
    'readiness':'Correspondence complete for inclusion in recovery archive. Final archive/commit/five-path delivery mapping is separate and pending.'}
write('RECEIPT_v1.json',receipt)
for item in artifacts:
    p=H/item['path'];assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
assert sha(H/'MANIFEST_v1.json')==receipt['manifest']['sha256']
assert sha(H/'REPORT_v1.md')==receipt['report']['sha256']
print(json.dumps({'unit':str(H),'artifact_count':len(artifacts),'source_count':len(sources),
                  'report_sha256':sha(H/'REPORT_v1.md'),
                  'manifest_sha256':sha(H/'MANIFEST_v1.json'),
                  'receipt_sha256':sha(H/'RECEIPT_v1.json'),'sealed':True},indent=2))
