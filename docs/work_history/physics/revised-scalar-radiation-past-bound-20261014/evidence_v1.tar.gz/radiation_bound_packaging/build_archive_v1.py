"""Milestone8 recovery archive; fail rather than overwrite."""
from pathlib import Path
import datetime,gzip,hashlib,io,json,tarfile
pk=Path('.claude/science/physics-loops/revised-scalar-derivation-24h-20261013')
out=Path('docs/work_history/physics/revised-scalar-radiation-past-bound-20261014/evidence_v1.tar.gz')
assert not out.exists()
assert (pk/'radiation_bound_canonical_correspondence_v1/RECEIPT_v1.json').exists()
folders=[pk/'initial_state/radiation_past_bound_v1',pk/'radiation_bound_packaging',pk/'radiation_bound_canonical_correspondence_v1']
files=sorted(set(f for d in folders for f in d.rglob('*') if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc'))
payload={};rows=[]
for f in files:
 assert not f.is_symlink()
 rel=f.relative_to(pk).as_posix();assert not Path(rel).is_absolute() and '..' not in Path(rel).parts
 b=f.read_bytes();payload[rel]=b;rows.append({'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={'schema':'campaign-recovery-manifest-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'campaign':'revised-scalar-derivation-24h-20261013','milestone':8,'scope':'Positive conserved radiation bounds regular past duration within the supplied flat homogeneous action. No selected past scalar state or empirical calibration.','payload_count':len(rows),'files':rows}
payload['RECOVERY_MANIFEST_v1.json']=(json.dumps(manifest,indent=2)+'\n').encode();out.parent.mkdir(parents=True,exist_ok=True)
with out.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for name,b in sorted(payload.items()):
  info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b))
with tarfile.open(out,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(payload) and len(set(m.name for m in members))==len(members)
 for m in members:
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  assert tar.extractfile(m).read()==payload[m.name]
r={'at':manifest['created_utc'],'archive':str(out),'archive_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'archive_bytes':out.stat().st_size,'manifest_sha256':hashlib.sha256(payload['RECOVERY_MANIFEST_v1.json']).hexdigest(),'payload_count':len(rows),'member_count':len(payload),'safe_relative_regular_members':True,'all_bytes_verified':True}
(pk/'radiation_bound_packaging/ARCHIVE_BUILD_v1.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
