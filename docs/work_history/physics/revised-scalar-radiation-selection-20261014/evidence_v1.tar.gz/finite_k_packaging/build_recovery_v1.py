#!/usr/bin/env python3
"""Package immutable radiation milestone evidence; exclude other research routes."""
from pathlib import Path
import datetime,hashlib,io,json,tarfile

repo=Path.cwd()
pack=repo/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013'
rt=Path('/Users/jonBridger/.codex/campaigns/revised-scalar-derivation-24h-20261013')
correspondence=pack/'initial_state/independent_finite_k_v1/canonical_correspondence_v1'
assert (correspondence/'RECEIPT_v1.json').is_file(), 'Wait for the sealed correspondence receipt.'
dest=repo/'docs/work_history/physics/revised-scalar-radiation-selection-20261014'
dest.mkdir(exist_ok=False)
readme=(pack/'finite_k_packaging/README_DRAFT_v1.txt').read_text()
(dest/'README.txt').write_text(readme)
explicit=[
 'initial_state/FINITE_K_RADIATION_DERIVATION_v1.md',
 'initial_state/FINITE_K_RADIATION_DERIVATION_v2.md',
 'initial_state/FINITE_K_RADIATION_CORRECTION_v2.md',
 'initial_state/FINITE_K_RADIATION_PROTOCOL_v1.json',
 'initial_state/FINITE_K_LINEARIZATION_v1.json',
 'initial_state/check_finite_k_radiation_v1.py',
 'initial_state/CROSS_DOMAIN_RELAXATION_BOUND_v1.md',
 'initial_state/check_relaxation_bound_v1.py',
 'initial_state/PARENT_RELAXATION_V1_VERIFICATION.json',
 'initial_state/RADIATION_DERIVATION_v1.md',
 'initial_state/RADIATION_DERIVATION_v2.md',
 'inherited/cosmology/direct_exponential_completion/DERIVATION_v1.md',
]
directories=[
 'initial_state/finite_k_radiation_evidence_v1',
 'initial_state/relaxation_bound_v1',
 'initial_state/independent_finite_k_v1',
 'initial_state/independent_relaxation_bound_v1',
 'initial_state/transverse_radiation',
 'finite_k_packaging',
]
files={pack/f for f in explicit}
for folder in directories:
 files.update(f for f in (pack/folder).rglob('*') if f.is_file()
              and '__pycache__' not in f.parts and f.suffix!='.pyc'
              and 'delivery_mapping_v1' not in f.parts and f.name!='.DS_Store')
assert all(f.is_file() and not f.is_symlink() for f in files)
entries=[];payloads={}
for f in sorted(files):
 rel=str(f.relative_to(pack));data=f.read_bytes();payloads[rel]=data
 entries.append({'path':rel,'source_path':str(f.relative_to(repo)),
                 'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'built_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope':'Radiation invariant-plane theorem, slow-rate bound, transverse saddle and their full evidence history; unrelated routes excluded.',
          'artifact_count':len(entries),'artifacts':entries,
          'excluded_routes':['initial_state/alternative_radiation','clock_profile','clock_inverse','scale_selection']}
mb=(json.dumps(manifest,indent=2)+'\n').encode()
archive=dest/'evidence_v1.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
 for rel,data in list(payloads.items())+[('ARCHIVE_MANIFEST.json',mb)]:
  info=tarfile.TarInfo(rel);info.size=len(data);info.mode=0o644;info.mtime=0
  tf.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tf:
 members=tf.getmembers();assert len(members)==len(entries)+1
 for member in members:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  expected=mb if member.name=='ARCHIVE_MANIFEST.json' else payloads[member.name]
  assert tf.extractfile(member).read()==expected
for row in entries:
 data=(repo/row['source_path']).read_bytes()
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
record={'built_at':manifest['built_at'],'archive_path':str(archive.relative_to(repo)),
        'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
        'archive_bytes':archive.stat().st_size,'artifact_count':len(entries),
        'manifest_sha256':hashlib.sha256(mb).hexdigest(),'all_member_and_live_bytes_verified':True}
(rt/'RADIATION_ARCHIVE_v1.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
