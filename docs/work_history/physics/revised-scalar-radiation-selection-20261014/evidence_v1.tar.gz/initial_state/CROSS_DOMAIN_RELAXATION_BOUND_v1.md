# A coupling bound forces slow linear radiation relaxation

Direct author /root, October 14, 2026. Conditional cross-domain consequence of
the already checked finite-k radiation reduction and local vacuum coupling.
The factorization below was personally derived algebraically, then confirmed
with SymPy before this file was saved. No observational likelihood is fitted.
Focused independent verification of this extension remains pending.

Take all hypotheses of FINITE_K_RADIATION_DERIVATION_v2.md: the supplied action,
fixed 0<k<1/3, ideal trace-free large-positive-y radiation at bounded u,z,
x=x'=0, and perturbations in the local neighborhood of its ideal fixed point.
Time N is the Einstein e-fold variable. The real slow eigenvalue lambda_s lies
in (-1/2,0), and its exact characteristic polynomial is

    P(lambda)=(lambda^2+lambda)^2+S(lambda^2+lambda)+P0,
    D=(1+k)(1-3k)^2,
    n=-3k^3+10k^2+k+4,
    S=4n/D, P0=16k/[(1+k)(1-3k)].

The checked factorization is P(lambda)=(lambda^2+lambda+r_s)
(lambda^2+lambda+r_l), with 0<r_s<1/6 and r_l>16-1/6.
Direct substitution now yields the exact identity

    P(-k)=-k^2 L(k)/D,
    L(k)=35+43k-66k^2+14k^3+15k^4-9k^5.

On 0<k<1/3,

    L(k)>35-66/9-9/243=746/27>0.

Thus P(-k)<0. The large-root factor at lambda=-k is positive, because
k^2-k>=-1/4 and r_l>16-1/6. Therefore r_s<k-k^2. The function t-t^2
is strictly increasing on 0<t<1/2. Since t=-lambda_s is the small positive
solution of t-t^2=r_s and k<1/3, it follows that

    0<-lambda_s<k,     tau_relax=1/(-lambda_s)>1/k.       (1)

This is an all-k inequality within the open candidate range, not a truncated
small-k expansion. For a nonzero component along the linear slow eigenmode,
its amplitude ratio over a prescribed DeltaN>0 is exp(lambda_s DeltaN).
Consequently, if an APPLICABLE independent physical constraint establishes
0<k<=b<1/3, then

    exp(lambda_s DeltaN)>exp(-b DeltaN),
    tau_relax>1/b.                                      (2)

The local vacuum bridge yields alpha_m^2=k only in the stipulated vacuum and
when its actual experimental range/source/readout assumptions are applicable.
A constraint on another environment's coupling g is not automatically a bound
on k. No Cassini timing model, cosmic-to-local matching, fixed initial amplitude
or nonlinear/global relaxation bound is supplied by this argument.

For orientation only, insert the already exposed development proxy b=1/79999
used earlier in the campaign, and DeltaN=24. Equation (2) then gives relaxation
longer than79999 Einstein e-folds and slow-mode amplitude retention above
exp(-24/79999). This is not a new extraction or confidence interval from an
experiment. The exact conditional formula (2), with a bound established by an
appropriate forward model, is the scientific result.

A preassigned DeltaN is not a derived cosmic duration, and a pure slow-mode
calculation is not a thermal-history integration. Initial data can have zero
slow-mode projection. Actual massive/thermal traces, transitions, finite-y
corrections, nonlinear excursions and other possible attractors can change the
history. The result rules out claiming rapid linear erasure from this specific
ideal attractor under weak k; it does not rule out every initial-state mechanism.
The initial state remains an open input of the current candidate.
