# Scope clarification in v2

The independent checker identified that the noncommuting-limits statement is established at the linearized slow-mode level. Version2 says this explicitly and excludes an inferred common nonlinear basin. No equation, rate, parent script or frozen result changes. Version1 remains preserved.
