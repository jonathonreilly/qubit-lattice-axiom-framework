# Finite-coupling radiation attraction and its slow direction

Direct author /root. This is a reduction of the same supplied exponential
action, not a new physical axiom or a derivation of the observed initial
state. The previously checked zero-coupling radiation limit has a neutral
family. This calculation asks whether finite coupling lifts that freedom
fast enough to justify supplying the ideal state.

## Deriving the finite-k reduced equations

Take fixed 0<k<1/3, ideal trace-free radiation, x=x'=0 and the large positive
y regime, at bounded u and z=log(y/y_b). Let y_b^2=Rstar rho_r and
rho_r proportional to exp(-4N_J). Hold k fixed in this limit: it is not the
weak-limit-first construction of RADIATION_DERIVATION_v2.md. Terms from the
constant and nu potential divided by radiation density vanish in this
reduction. It does not hold across the actual thermal/mass transitions or
late vacuum domination. Primes below mean d/dN, N=log a_E.

With ell=log y, p=u', q=ell', the remaining field metric and potential are

    A(u)=J/F^2, B(u)=(1+s)k/[2(1+k)F],
    W(u,z)=U_rad/y_b^2=(k/3) exp(2z-lambda_y u),
    C=(1+s)E/F, alpha_B=alpha/F,
    T=A p^2+B q^2,
    Hbar=H_E^2/(Hv^2 y_b^2)=2(C^2+W)/(3-T),
    h=H_E'/H_E=-4C^2/(3 Hbar)-T.

Here E=exp(2 alpha u), F=1+sE, J=1+(1-3a)sE and
lambda_y=4 alpha s/(1+s). A and B are metric coefficients, unrelated to
the conformal square root A used in the separate local-response notes.
The lowered field equations and radiation conservation give

    u'=p,
    z'=q+2+2 alpha_B p,
    p'=-(3+h)p-(A_u/(2A))p^2+(B_u/(2A))q^2
        +lambda_y W/(A Hbar),
    q'=-(3+h)q-(B_u/B)pq-2W/(B Hbar).                 (1)

In particular, the 2 alpha_B p term in z' must not be omitted: y_b scales
with the physical scale factor, not the Einstein scale factor. The
potential derivative in p' holds physical y fixed before expressing its
ratio to y_b^2. Equation (1) is smooth in the open positive chart T<3.

The ideal fixed point is (u,z,p,q)=(0,0,0,-2). There C=1,
B=k/[2(1+k)], T=2k/(1+k)<3, Hbar=2(1+k)/3 and h=-2.
The earlier constant-u scaling calculation proves uniqueness within that
restricted class. This note analyzes local attraction, not a global basin.

## Exact spectrum and a local nonlinear consequence

Differentiating all of (1), including Hbar, h, and z', gives the characteristic
polynomial

    P_lambda=(lambda^2+lambda)^2+S(lambda^2+lambda)+P,
    D=(1+k)(1-3k)^2,
    n=-3k^3+10k^2+k+4,
    S=4n/D, P=16k/[(1+k)(1-3k)].                     (2)

This polynomial is an exact consequence of the reduced flow, not a fit to
numerical eigenvalues. Write

    r_small=2P/[S+sqrt(S^2-4P)],
    r_large=(S+sqrt(S^2-4P))/2.

For 0<k<1/3, n>4, D>0, and n-4D=k(21-2k-39k^2)>16k>0, so S>16.
Also P/S=4k(1-3k)/n<1/12. These inequalities imply
S^2-4P>0, 0<r_small<1/6<1/4, and r_large>16-1/6>1/4.
The four eigenvalues are therefore

    (-1+sqrt(1-4 r_small))/2,
    (-1-sqrt(1-4 r_small))/2,
    (-1+i sqrt(4 r_large-1))/2,
    (-1-i sqrt(4 r_large-1))/2.                       (3)

Their real parts are strictly negative for every finite k in this open
range. Since (1) is smooth near the fixed point, it is locally
asymptotically stable for each fixed k. To make the nonlinear inference
explicit: if M is its Jacobian, the integral
P_L=integral_0^infinity exp(M^T t) exp(M t) dt is positive definite and
M^T P_L+P_L M=-I. Writing (1) in displaced coordinates as w'=Mw+O(|w|^2)
gives d(w^T P_L w)/dN=-|w|^2+O(|w|^3)<0 in a sufficiently small
neighborhood. No uniform neighborhood as k->0, finite capture time or
global attraction has been established.

## A slowly selected state is not an observed initial-state derivation

The eigenvalue closest to zero has the expansion

    lambda_slow=-k+(35/16)k^2+(869/128)k^3+O(k^4).     (4)

The analytic root exists near k=0 because the zero eigenvalue of (2) at
k=0 is simple. Thus the radiation-only linear relaxation time in Einstein
e-folds diverges as 1/k. The other real eigenvalue tends to -1 and the
oscillating pair tends to (-1+-3i sqrt(7))/2, in agreement with the
independently checked weak-limit family. Already at the linearized slow-mode level,
the long-time and weak-coupling limits do not commute. The local nonlinear
stability argument does not establish a common basin for exchanging
limits of nonlinear solutions.

Compute the exact rate at the already used candidate values k=1e-6,1e-5,
.001,.01,.1,.3,.32. An illustrative24 Einstein e-fold evolution of the
linear slow eigenmode is exp(24 lambda_slow), not a simulation of the
actual thermal history. At weak k this interval is much shorter than
the relaxation time. It cannot justify erasing the initial-state freedom.
The actual27 thermal-history probes already exhibit surviving memory;
they are contextual computations, not an independent test of (1).

Check the action-to-flow reduction and spectrum independently. The full
observed state, an allowed basin, parameter k, the matter content and the
action remain open inputs. Finite-k local asymptotic stability retires
neither the initial-state assumption nor the cosmological-to-local bridge.
