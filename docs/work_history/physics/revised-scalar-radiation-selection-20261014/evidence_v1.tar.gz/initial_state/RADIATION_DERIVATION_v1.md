# Initial-state selection in the revised scalar candidate

Author: /root, personally in the campaign chat. Status: open derivation under
the inherited action. This is not a framework derivation of that action.

## Radiation scaling limit

Start from the inherited normalized weak-coupling equations, then take an
ideal radiation dominated scaling regime. Set the dust field x=0, let
y_b^2=R0 rho_r with y_b proportional to exp(-2N), and take y_b large while
u and z=log(y/y_b) remain finite. The vacuum/nu terms divided by B vanish,
D/(2y^2/3) tends to1, B/(2y_b^2/3) tends to1, h tends to-2, and the
matter trace is zero. These are asymptotic assumptions to check separately
from the actual finite thermal history; they are not identities through
electron annihilation, neutrino mass transitions or vacuum domination.

In (u,ell=log y) coordinates the surviving target metric is

    g_rad=exp(-u)[du^2/4+dell^2/2],
    W/B -> exp(-2u+2z)/2.

Put p=u', q=ell', z'=q+2, with prime d/dN. Direct differentiation of
this metric and of W at fixed physical field y gives

    u'=p,
    z'=q+2,
    p'=-p+p^2/2-q^2+4 exp(2z-u),
    q'=-q+p q-2 exp(2z-u).

The fixed histories are the one-parameter family
(u,z,p,q)=(c,c/2,0,-2), not just the previously chosen c=0 history.
The Jacobian, in the order (u,z,p,q), is independent of c:

    M=[[0,0,1,0],[0,0,0,1],[-4,8,-1,4],[2,-4,-2,-1]].

Its characteristic polynomial is lambda(lambda+1)(lambda^2+lambda+16).
Thus there is one neutral tangent direction and three linearly damped
transverse directions. This by itself is a linear statement, not a nonlinear
basin proof. In w=2z-u coordinates the remaining three-dimensional system
is autonomous and has a strictly Hurwitz linearization at (w,p,q)=(0,0,-2).
A local nonlinear stability proof with an explicit neighborhood is the next
mathematical step. It would select a family; it would not determine c.

The inherited physical first expansion coefficient C_exp vanishes along
every member of this radiation scaling family: W/B=exp(-c)/2,
sigma/B=3/2, Tbar=2exp(-c), p=0. Substitution gives
(1-5exp(-c)/3)+2exp(-c)/3-1+exp(-c)=0.
Early expansion agreement therefore does not select c at this order.
This does not imply exact finite-k degeneracy or agreement at later epochs.

## Finite coupling lifts the exact scaling degeneracy

In the radiation dominated, large-y reduction of the finite-k action define
c_y(u)=(1+s)k/[2(1+k)F]. A constant-u, y proportional to exp(-2N)
scaling state satisfies Hhat^2=U_y/c_y from the y equation. The u equation
then requires 2 c_y'(u)+lambda_y c_y(u)=0. Since
c_y'/c_y=-2alpha sE/F and lambda_y=4alpha s/(1+s), this is E=1,
so u=0 for each fixed 0<k<1/3. This algebra determines the unique
constant-u scaling state in this restricted class; it does not prove its
attraction rate or control interchange of long-time and weak-coupling limits.
Compute the rates and compare with finite cosmological duration before
calling the initial-state assumption retired.

## Full thermal discriminator

Keep the complete inherited thermal gas, calibration and potential. Vary
each initial scaled coordinate and explore the radiation neutral direction;
integrate the entire history without retuning parameters. Preserve failures.
These are model-development counterfactuals. No probability measure, basin
fraction, empirical likelihood or independent observational test is defined
by this deterministic sample. A late-time local attractor can coexist with
substantial present-day memory.
