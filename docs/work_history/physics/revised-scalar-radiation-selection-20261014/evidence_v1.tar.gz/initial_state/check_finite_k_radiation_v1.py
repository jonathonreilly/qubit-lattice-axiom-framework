#!/usr/bin/env python3
"""Direct-author finite-k radiation reduction; no fitted spectrum."""
from pathlib import Path
import argparse, datetime, hashlib, json
import mpmath as mp
import sympy as sp

CHECKS=[]


def check(name, ok, **extra):
    CHECKS.append(dict(name=name,passed=bool(ok),**extra))


def exact(name, value):
    v=sp.factor(sp.cancel(value))
    check(name,v==0,residual=str(v))


def main(protocol_path,out):
    out.mkdir(exist_ok=False)
    protocol=json.loads(protocol_path.read_text())
    bindings=[dict(path=r['path'],passed=hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()==r['sha256']) for r in protocol['inputs']]
    if not all(r['passed'] for r in bindings):raise RuntimeError('Frozen source mismatch')
    k=sp.symbols('k',positive=True)
    u,z,p,q=sp.symbols('u z p q',real=True)
    a=(1-k)*(1+3*k)/4;al=sp.sqrt(a);s=(1+k)/(k*(1-3*k))
    E=sp.exp(2*al*u);F=1+s*E;J=1+(1-3*a)*s*E
    A=J/F**2;B=(1+s)*k/(2*(1+k)*F);C=(1+s)*E/F;ab=al/F;ly=4*al*s/(1+s)
    W=k*sp.exp(2*z-ly*u)/3;T=A*p*p+B*q*q;HB=2*(C*C+W)/(3-T);h=-4*C*C/(3*HB)-T
    flow=sp.Matrix([p,q+2+2*ab*p,
                    -(3+h)*p-sp.diff(A,u)*p*p/(2*A)+sp.diff(B,u)*q*q/(2*A)+ly*W/(A*HB),
                    -(3+h)*q-sp.diff(B,u)*p*q/B-2*W/(B*HB)])
    fp={u:0,z:0,p:0,q:-2}
    for i,r in enumerate(flow.subs(fp)):exact('fixed_point.'+str(i),r)
    exact('fixed_H',HB.subs(fp)-2*(1+k)/3)
    exact('fixed_h',h.subs(fp)+2)
    M=flow.jacobian([u,z,p,q]).subs(fp).applyfunc(lambda v:sp.factor(sp.simplify(v)))
    lam=sp.symbols('lambda');cp=sp.factor(M.charpoly(lam).as_expr())
    D=(1+k)*(1-3*k)**2;n=-3*k**3+10*k*k+k+4;S=4*n/D;P=16*k/((1+k)*(1-3*k))
    target=(lam*lam+lam)**2+S*(lam*lam+lam)+P
    exact('characteristic_polynomial',cp-target)
    exact('S_lower_bound_numerator',n-4*D-k*(21-2*k-39*k*k))
    exact('ratio_P_over_S',P/S-4*k*(1-3*k)/n)
    exact('k_quadratic_bound',sp.Rational(1,12)-k*(1-3*k)-3*(k-sp.Rational(1,6))**2)
    approx=-k+sp.Rational(35,16)*k*k+sp.Rational(869,128)*k**3
    exact('slow_root_series_through_cubic',sp.series(target.subs(lam,approx),k,0,4).removeO())
    exact('weak_limit_polynomial',sp.limit(target,k,0)-lam*(lam+1)*(lam*lam+lam+16))
    # Removing the physical-clock coupling changes the actual matrix and spectrum.
    bad=M.copy();bad[1,2]=0
    defect=sp.factor(bad.charpoly(lam).as_expr()-target)
    check('negative_control.omitted_clock_term',sp.cancel(defect)!=0,residual=str(defect))
    check('negative_control.wrong_series_coefficient',sp.series(target.subs(lam,-k+sp.Rational(9,4)*k*k),k,0,3).removeO()!=0)
    mp.mp.dps=80;rows=[]
    matrix_fn=sp.lambdify(k,M,'mpmath')
    for ks in protocol['k_values']:
        kk=mp.mpf(ks);sn=4*(-3*kk**3+10*kk**2+kk+4)/((1+kk)*(1-3*kk)**2);pn=16*kk/((1+kk)*(1-3*kk))
        rs=2*pn/(sn+mp.sqrt(sn*sn-4*pn));rl=(sn+mp.sqrt(sn*sn-4*pn))/2
        slow=-2*rs/(1+mp.sqrt(1-4*rs))
        analytic=[slow,-1-slow,mp.mpc(-mp.mpf('.5'),mp.sqrt(4*rl-1)/2),mp.mpc(-mp.mpf('.5'),-mp.sqrt(4*rl-1)/2)]
        eig,_=mp.eig(matrix_fn(kk))
        maxerr=max(min(abs(x-y) for y in eig) for x in analytic)
        check('numeric.k'+ks+'.matrix_spectrum',maxerr<mp.mpf('1e-60'),max_error=mp.nstr(maxerr,12))
        check('numeric.k'+ks+'.Hurwitz',all(mp.re(v)<0 for v in eig))
        check('numeric.k'+ks+'.bounds',sn>16 and pn/sn<mp.mpf(1)/12 and 0<rs<mp.mpf(1)/6 and rl>16-mp.mpf(1)/6)
        rows.append(dict(k=ks,slow_eigenvalue=mp.nstr(slow,40),linear_relaxation_e_folds=mp.nstr(-1/slow,40),
                         slow_mode_retained_after_24_Einstein_e_folds=mp.nstr(mp.exp(24*slow),40),spectrum=[[mp.nstr(mp.re(v),30),mp.nstr(mp.im(v),30)] for v in analytic]))
    result=dict(scope='Exact finite-k reduced radiation flow; local stability only, no full-history or initial-state selection claim.',
                matrix=str(M),characteristic_polynomial=str(cp),checks=CHECKS,rates=rows,source_bindings=bindings,
                unchanged_sources=all(hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()==r['sha256'] for r in protocol['inputs']),
                counts=dict(passed=sum(r['passed'] for r in CHECKS),failed=sum(not r['passed'] for r in CHECKS)),completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (out/'RESULTS.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'counts':result['counts'],'rates':rows},indent=2),flush=True)
    return int(result['counts']['failed']>0 or not result['unchanged_sources'])


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--protocol',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    args=p.parse_args();raise SystemExit(main(args.protocol,args.out))
