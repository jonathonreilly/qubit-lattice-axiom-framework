#!/usr/local/bin/python3
from pathlib import Path
import sympy as s
import mpmath as mp
import json,hashlib
p=Path(__file__).resolve().parent;o=p/'relaxation_bound_v1';assert not o.exists();o.mkdir();rows=[]
def ck(n,ok,**details):rows.append(dict(name=n,passed=bool(ok),**details))
k=s.symbols('k');D=(1+k)*(1-3*k)**2;n=-3*k**3+10*k**2+k+4;S=4*n/D;P=16*k/((1+k)*(1-3*k));L=35+43*k-66*k*k+14*k**3+15*k**4-9*k**5
ck('factorization_exact',s.factor((k*k-k)**2+S*(k*k-k)+P+k*k*L/D)==0)
ck('positive_bracket_bound',s.Rational(35)-s.Rational(66,9)-s.Rational(9,243)==s.Rational(746,27)>0)
ck('large_factor_lower_bound',s.Rational(16)-s.Rational(1,6)-s.Rational(1,4)>0)
# t-t² strictly increases on the relevant interval and k remains in it.
ck('monotone_comparison_domain',s.Rational(1,3)<s.Rational(1,2))
mp.mp.dps=80;data=[]
for text in ['0.000001','0.00001','0.001','0.01','0.1','0.3','0.32','0.333333333333']:
 kv=mp.mpf(text);dv=(1+kv)*(1-3*kv)**2;nv=-3*kv**3+10*kv**2+kv+4;sv=4*nv/dv;pv=16*kv/((1+kv)*(1-3*kv));rs=2*pv/(sv+mp.sqrt(sv**2-4*pv));rate=2*rs/(1+mp.sqrt(1-4*rs));ret=mp.exp(-24*rate)
 ck('exact_rate_bound_'+text,0<rate<kv,rate=mp.nstr(rate,60),rate_over_k=mp.nstr(rate/kv,60));ck('retention_'+text,ret>mp.exp(-24*kv));data.append(dict(k=text,rate=mp.nstr(rate,60),relaxation=mp.nstr(1/rate,60),retention24=mp.nstr(ret,60)))
b=mp.mpf(1)/79999;proxy=dict(role='Previously exposed development proxy; no reconstructed likelihood',b=mp.nstr(b,60),minimum_relaxation='79999 (strict inequality)',minimum_retention24=mp.nstr(mp.exp(-24*b),60))
res=dict(scope='Exact linear ideal-radiation conditional bound only',source_sha256=hashlib.sha256((p/'CROSS_DOMAIN_RELAXATION_BOUND_v1.md').read_bytes()).hexdigest(),script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),passed=sum(x['passed'] for x in rows),failed=sum(not x['passed'] for x in rows),checks=rows,examples=data,proxy=proxy)
(o/'RESULTS.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps(res,indent=2));raise SystemExit(res['failed']!=0)
