# Actual execution and failure record

Two independent mathematics scripts were run once each in this evidence
folder. Each output path was guarded against replacement before computation.

1. `python3 derive_spectrum_v1.py > results/spectrum_run01.stdout.txt 2> results/spectrum_run01.stderr.txt`
   completed with exit code 0. All ten compound checks were true. The stderr
   file is empty; the full result and stdout are preserved.
2. `python3 check_large_y_limit_v1.py > results/large_y_run01.stdout.txt 2> results/large_y_run01.stderr.txt`
   completed with exit code 0. All eight case-level collections of checks
   were true. The stderr file is empty; the full result and stdout are
   preserved.

No runtime exception or failed mathematical check occurred in these two
runs. No source retry or replacement result was needed. The three damage
controls in the first run deliberately introduce a wrong clock or force;
their nonzero symbolic defects are expected evidence that these errors are
detected, not suppressed execution failures.

The later source correspondence check also completed with exit code 0 and
confirmed that v2 differs from v1 only in the stated linear-versus-nonlinear
limits qualification. No producer runner was read or executed in this check.
