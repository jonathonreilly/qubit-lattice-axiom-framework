# Independent finite-k radiation derivation

Checker `/root/scalar_energy_check`; parent `/root` remains the scientific
author. Start with the exact supplied canonical action, not a producer
function. No `check_finite_k_radiation_v1.py` source has been read or imported
in constructing this derivation or its controls. This is a classical internal
reduction and a local dynamical result, not a derivation of an observed state.

## 1. Full action, invariant plane, and the large-y limit

The action has scalar Lagrangian `-K_AB dphi^A dphi^B-2Hv^2 U`, with Q>0.
Its dimensionless homogeneous equations, derived by direct variation, are

    D_theta v^i+3H v^i+K^{ij}U_j = -K^{ij}d_j log(sqrt(C)) tau,
    3H^2=K(v,v)+2U+2sigma,
    H'/H=-K(p,p)-(sigma+pi)/H^2,

where theta=Hv t_E, H=H_E/Hv, prime is d/dN, and p=dphi/dN. The positive
normalization is sigma=C^2 Rstar rho_J. All physical parameters, including
nu, remain fixed while taking the radiation limit.

For exact trace-free radiation, pi=sigma/3 and tau=0. The full action is even
in x and has diagonal field metric. At x=0 all derivatives in the x direction
of the other coefficients vanish, and U_x=0. Thus x=x'=0 is invariant. This
does not show attraction to this plane from generic transverse x states.

On the y>0 branch put ell=log y, p=u', q=ell'. The exact two-coordinate metric
is `diag(A,B_full)`, where

    A=J/F^2,
    d=2(1+k)/3,
    B_full=K_yy y^2
          = [(1+s)k/(2(1+k)F)] * d y^2/(1+d y^2).

Write `B=(1+s)k/[2(1+k)F]`. Then B_full->B as y->infinity, its u derivative
tends to B_u, and

    (partial_ell B_full)/(2B_full)=1/(1+d y^2)->0.

The surviving connection coefficients are

    Gamma^u_uu=A_u/(2A), Gamma^u_ell,ell=-B_u/(2A),
    2 Gamma^ell_u,ell=B_u/B.

Let y_b^2=Rstar rho_r>0 and z=ell-log y_b. At fixed bounded u,z and fixed
positive k, y_b->infinity is equivalent to y->infinity. The potential is

    U=V0(u)+(k/3)y^2 exp(-lambda_y u),
    V0=3/2+3s(E-1)^2/(2F^2)+nu(1+s)u^2/(2F^2).

Consequently U/y_b^2 tends to

    W=(k/3) exp(2z-lambda_y u),

and the V0 gradient divided by y_b^2 vanishes too. At fixed physical y (or
fixed ell), the action derivative satisfies

    U_u/y_b^2 -> -lambda_y W,
    U_ell/y_b^2 -> 2W.

These are derivatives of the physical potential before replacing y by
y_b exp(z). Differentiating U at fixed z and fixed N would also differentiate
the physical radiation scale y_b(u,N), giving an erroneous extra term if
inserted directly into the original scalar equation. A coordinate-transformed
action would require transforming every kinetic and fluid term as well.

On fixed compact phase regions inside the positive chart, the dropped metric,
connection, potential, and force corrections are O(y_b^-2), also after a fixed
number of field derivatives. Fixed nu and bounded u,z are essential. This is
a controlled coefficient/flow limit on such compact regions, not a theorem
that arbitrary full histories stay in this regime for arbitrarily long N.

## 2. Physical clock and reduced flow

Conformal coupling gives

    N_J=N+(1/2)log C + constant,
    N_J'=1+alpha_B p,   alpha_B=alpha/F.

Radiation conservation therefore gives

    (log y_b)'=-2N_J'=-2-2alpha_B p,
    z'=q+2+2alpha_B p.

Omitting the last term changes the finite-k vector field and its spectrum.
Equivalently sigma=C^2 y_b^2 redshifts exactly as exp(-4N), but y_b itself
redshifts with N_J, which is why z must retain the clock correction.

With T=A p^2+B q^2 and Hbar=H_E^2/(Hv^2 y_b^2), the Einstein constraint and
Raychaudhuri equation give

    Hbar=2(C^2+W)/(3-T),
    h=H_E'/H_E=-T-4C^2/(3Hbar).

Substitution into the action equations yields independently

    u'=p,
    z'=q+2+2alpha_B p,
    p'=-(3+h)p-A_u p^2/(2A)+B_u q^2/(2A)+lambda_y W/(A Hbar),
    q'=-(3+h)q-(B_u/B)pq-2W/(B Hbar).

Thus the candidate's full reduced system, force signs, factors, and derivative
convention agree with the action. Positivity of A,B,C and W makes it smooth
near any finite phase point with T<3. No matter-trace force survives.

## 3. Fixed point and an independent rational Jacobian

At u=z=p=0,q=-2,

    B0=k/[2(1+k)], W0=k/3, C0=1,
    A0=k(1-3k)^2/(16a), alpha_B0=k(1-3k)/(4alpha),
    T0=2k/(1+k), Hbar0=2(1+k)/3, h0=-2.

Since B_u0=-(lambda_y/2)B0 and W0/Hbar0=B0, the last two forces cancel
exactly. This establishes the fixed point directly. It does not require the
earlier constant-u uniqueness result, and that prior result is not a premise
of this local check.

To remove square roots from the matrix, use coordinates
`(t,z,r,q)=(2alpha u,z,2alpha p,q)`. This is an invertible constant change of
variables for each admissible k, so it preserves eigenvalues. Put
`d_k=(1-3k)^2(k+3)`. Manual differentiation gives

    M = [[0, 0, 1, 0],
         [0, 0, k(1-3k)/(4a), 1],
         [4(3k^3+29k^2-9k-3)/d_k, 96a/d_k, -1,
              48a(1+k)/d_k],
         [(1+2k-7k^2)/(2a(1+k)), -4/(1+k), -(1+k)/(2a), -1]].

The symbolic checker separately differentiates the flow obtained from the
transformed action metric `A/(4a)`, then compares all entries with this
manual result. It does not input the claimed spectrum when constructing M.

For orientation, the intermediate derivatives in the original u coordinates
are, with L=lambda_y and beta=alpha_B0,

    B_u0/B0=-L/2,
    (Hbar_u/Hbar)0=(12beta-2Lk)/(3+k),
    (Hbar_z/Hbar)0=2k/(3+k),
    (Hbar_q/Hbar)0=-2k/(3+k), Hbar_p0=0,
    h_u0=k[L(k-1)-8beta]/[(1+k)(3+k)],
    h_z0=4k/[(1+k)(3+k)], h_q0=2k/(3+k), h_p0=0.

They make the differentiations of the Friedmann and damping terms explicit.

## 4. Characteristic polynomial and all-k Hurwitz proof

Direct determinant expansion of lambda I-M gives, with X=lambda^2+lambda,

    det(lambda I-M)=X^2+S X+P,
    S=4n/D, P=16k/[(1+k)(1-3k)],
    D=(1+k)(1-3k)^2,
    n=4+k+10k^2-3k^3.

This agrees exactly with the supplied characteristic polynomial. The matrix
calculation includes the physical-clock term in row 2. An actual omission
changes the determinant by

    -24 k lambda(lambda-1)/[(k+3)(3k-1)],

which is not identically zero on the admissible parameter range.

The sign claims need no sampling. First,

    n-4=k(1+10k-3k^2)>0,
    n-4D=k[16+(1-3k)(13k+5)]>16k>0.

Hence S>16. Moreover

    P/S=4k(1-3k)/n < k(1-3k)
       = 1/12-3(k-1/6)^2 <= 1/12.

In particular S^2-4P>0 because `4(P/S)/S<1/48`. Define

    r_small=2P/[S+sqrt(S^2-4P)],
    r_large=[S+sqrt(S^2-4P)]/2.

Then both are positive, their sum is S, and

    r_small<2P/S<1/6<1/4,
    r_large=S-r_small>16-1/6>1/4.

The factorization is `(X+r_small)(X+r_large)`. It has two negative real
eigenvalues `[-1 +/- sqrt(1-4r_small)]/2` and a conjugate pair with real part
-1/2. The less negative real eigenvalue lies in (-1/2,0) and is the unique
slowest spectral rate. Every fixed `0<k<1/3` is therefore Hurwitz. Neither
endpoint is included, and no uniform lower decay rate on the open k interval
is obtained. No unproved Routh-Hurwitz assertion is required.

## 5. Local nonlinear inference and its scope

For each fixed admissible k, the point is strictly inside T<3 and the vector
field is smooth. With the above Hurwitz M, define

    P_L=int_0^infinity exp(M^T t) exp(M t) dt.

Exponential matrix decay makes the integral finite; its quadratic form is
strictly positive because the integrand at t=0 is the identity. Differentiating
the integrand and integrating gives `M^T P_L+P_L M=-I`. The nonlinear
remainder is R(w)=O(|w|^2), so

    d(w^T P_L w)/dN=-|w|^2+2w^T P_L R(w)
                  <= -|w|^2/2

in a sufficiently small neighborhood. A small sublevel set stays inside the
positive chart and proves local asymptotic (indeed local exponential)
stability of the reduced system. All constants and the neighborhood may
depend on k. This says nothing about attraction to x=0, a full basin, finite
capture, thermal transitions, or nonlinear comparison at a common initial
state as k tends to zero.

## 6. Slow-root expansion and the limit-order qualification

At k=0, the polynomial is `X(X+16)`, with eigenvalues 0, -1 and
`(-1 +/- 3i sqrt(7))/2`. Its lambda derivative at the zero root is 16, so
the analytic implicit-function theorem gives one analytic slow root near
k=0. Coefficient matching in the determinant, without fitting numerical
rates, yields

    S=16+84k+412k^2+O(k^3),
    P=16k+32k^2+112k^3+O(k^4),
    r_small=k-(51/16)k^2-(309/128)k^3+O(k^4),
    lambda_slow=-r_small-r_small^2-2r_small^3+O(r_small^4)
               =-k+(35/16)k^2+(869/128)k^3+O(k^4).

The rate vanishes linearly with k, so the linear radiation-only relaxation
time `-1/lambda_slow` diverges as 1/k. A cancellation-safe evaluation uses
`lambda_slow=-2r_small/[1+sqrt(1-4r_small)]`. The independent checker also
computes eigenvalues directly from the derived matrix and compares them.

At the linear slow-mode level,

    lim_{k->0+} lim_{N->infinity} exp(lambda_slow(k) N)=0,
    lim_{N->infinity} lim_{k->0+} exp(lambda_slow(k) N)=1.

This rigorously demonstrates noncommutation for that mode factor. The local
Lyapunov proof alone does not establish a common k-independent nonlinear
basin, so an unqualified nonlinear solution-limit claim would overreach. The
parent has narrowed this sentence in a preserved v2; the final report will
bind its exact changed bytes. No actual thermal-history limit is claimed.

As an independent consistency check, the k->0 coefficient limit in original
u coordinates is

    u'=p, z'=q+2,
    p'=-p+p^2/2-q^2+4exp(2z-u),
    q'=-q+pq-2exp(2z-u).

It has the neutral family `(u,z,p,q)=(c,c/2,0,-2)`. This follows directly from
the action limit here; it is not imported from a previously checked weak-limit
runner. The finite-k local result does not derive the physical realization
of one member or justify discarding initial-state memory over a short era.
