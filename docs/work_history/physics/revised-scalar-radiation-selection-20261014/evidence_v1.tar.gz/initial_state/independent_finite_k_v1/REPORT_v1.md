# Independent finite-k radiation check

Checker: `/root/scalar_energy_check`. Parent `/root` remains the scientific
author. Completed 2026-10-13. This is a focused internal mathematical check,
not a formal audit or a claim about an observed cosmological history.

No unresolved mathematical correction was found in the checked reduced
equations, fixed point, spectrum, all-k stability argument, or cubic slow-root
expansion. One scope clarification was requested and is now present in the
preserved v2: the noncommuting-limits statement applies to the linear slow-mode
factor. The local nonlinear proof does not supply a common basin as k tends
to zero. The exact v1-to-v2 diff contains only that wording replacement.

## Inputs, independence, and correspondence

The derivation starts from the full canonical action in
`docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md`,
whose snapshot SHA-256 is
`39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000`.
The candidate v1 snapshot is
`f27969fd9d8dbd3cb63eb1c3bc0a9de846a9a08747979fd4afb7bebc40624e60`.
The v2 snapshot is
`88d7f4300dfb710818ac7c0da070b9710ee2f993f2dbb7392367347d3b54b664`.
The correction note and exact diff are preserved alongside these sources.

The producer `check_finite_k_radiation_v1.py` was neither read nor imported.
Neither producer outputs nor the reported producer check count are used as
independent evidence. The handwritten derivation and two executable controls
were constructed independently. They use only Python, SymPy and mpmath.
No generic uniqueness result, earlier weak-limit computation, thermal-history
trajectory, or observed-state input is a premise of this calculation.

`SOURCE_MANIFEST_v1.json` binds the initial inputs;
`SOURCE_MANIFEST_v2.json` and `V1_V2_CORRESPONDENCE.diff` bind the later scope
clarification. They confirm that the candidate equations and rates are
unchanged. The final receipt also checks that each original source still
matches its frozen snapshot when the receipt is built.

## Derivation and mathematical findings

`HAND_DERIVATION_v1.md` gives the complete ordinary derivation and proof.

1. At fixed `0<k<1/3`, fixed finite nu, exact trace-free radiation, and on the
   invariant plane `x=x'=0`, the full action's metric in `(u,ell=log y)` is
   `diag(A,B_full)` with
   `B_full=B*d*y^2/(1+d*y^2)`, `d=2(1+k)/3`.
   For bounded u,z and `y_b->infinity`, it tends to `diag(A,B)`; the finite
   potential and its gradient divided by `y_b^2` vanish. The coefficient and
   force errors are `O(y_b^-2)` on fixed compact subsets of the positive chart.
   This is a limit of the equations under specified hypotheses.
2. The physical clock is essential:
   `N_J'=1+alpha_B*p` implies `z'=q+2+2*alpha_B*p`.
   The potential is differentiated at fixed physical y before substituting
   `y=y_b*exp(z)`. These operations give the candidate force terms and their
   signs and factors exactly. Radiation has zero trace force.
3. The ideal point `(u,z,p,q)=(0,0,0,-2)` is a genuine interior fixed point.
   Independently differentiating the complete constrained flow, including
   Hbar, h and the physical clock, reproduces the handwritten Jacobian in
   `(2*alpha*u,z,2*alpha*p,q)` and the exact characteristic polynomial
   `(lambda^2+lambda)^2+S*(lambda^2+lambda)+P`.
4. The all-k proof is algebraic, not inferred from a sample. The identities
   `n-4D=k[16+(1-3k)(13k+5)]` and
   `P/S<k(1-3k)<=1/12` give `S>16`, a positive discriminant,
   `0<r_small<1/6<1/4`, and `r_large>16-1/6>1/4`.
   Thus all four eigenvalues have negative real part for every fixed k in
   the open interval, with a unique slow real eigenvalue.
5. Smoothness and the explicit positive Lyapunov integral establish local
   nonlinear asymptotic stability for each fixed k. A sufficiently small
   sublevel set stays in the positive chart. The neighborhood and constants
   may depend on k. The same calculation also yields local exponential
   stability of this reduced system, without a uniform rate in k.
6. Exact series coefficient matching gives
   `lambda_slow=-k+(35/16)*k^2+(869/128)*k^3+O(k^4)`.
   The analytic root follows from the simple zero root at k=0. Independently
   taking the weak coefficient limit recovers the neutral family
   `(u,z,p,q)=(c,c/2,0,-2)`. No earlier weak-limit result is needed.

The unqualified v1 phrase about limits and state selection was too broad if
read as a nonlinear solution statement. For the linear factor, the iterated
limits of `exp(lambda_slow(k)*N)` are respectively 0 and 1. V2 now states
exactly that level of conclusion and excludes an inferred common nonlinear
basin. No mathematical equation required correction.

## Executed controls and actual outcomes

`derive_spectrum_v1.py` ran once and exited 0. Its ten compound checks all
returned true. The actual evidence includes four zero fixed-point residuals,
16 zero manual-versus-symbolic Jacobian residuals, the zero characteristic
polynomial difference, exact cubic coefficients, five zero sign-identity
residuals, and independent 80-digit matrix eigenvalues at seven k values.
Direct matrix eigenvalues agree with cancellation-safe closed-form slow
rates to absolute error at most `6.72e-79` in those cases.

Three deliberate symbolic damage controls produce nonzero defects:

- Removing the physical-clock derivative changes the characteristic
  polynomial by `-24*k*lambda*(lambda-1)/[(k+3)*(3k-1)]`.
- Differentiating the potential at fixed z and N, then inserting it as the
  original scalar force, produces fixed-point t-acceleration defect
  `4*k*(k-1)*(3k+1)/[(k+1)*(3k-1)]`.
- Halving the ell potential gradient produces fixed-point q-acceleration
  defect 1.

These are explicit analytic damage probes; they are not executions of a
modified producer script or additional independent science results.

`check_large_y_limit_v1.py` ran once and exited 0. It differentiates the full
action at fixed physical ell, solves the lowered-momentum equations for the
accelerations, and compares with the separately implemented reduced flow.
There are eight off-orbit cases: k=`1e-5,.01,.1,.32`, each with fixed nu=1 or
100 and one of two supplied bounded phase points. Each case is evaluated at
`y_b=100,10000,1000000`, for 24 full-action comparisons. Every sampled full
and reduced point has `T<3`; the physical-clock terms agree exactly. A factor
100 increase in y_b reduces the maximum flow error by factors between about
9997.24 and 9999.99994. All prescribed checks return true; all actual errors
and phase coordinates are preserved. These are local equation comparisons,
not trajectories or full-history tests.

The two runs had no runtime or check failures. Both stderr files are empty.
The complete stdout, JSON outputs, input scripts and their hashes remain
preserved. `FAILURE_LOG_v1.md` distinguishes the deliberate damage probes
from actual failures; no failed attempt was discarded or replaced.

Representative independently computed rates are:

| k | lambda_slow | relaxation e-folds | exp(24 lambda_slow) |
|---|---:|---:|---:|
| 1e-5 | -0.000009999781243210968 | 100002.187615746 | 0.9997600340465992 |
| .01 | -0.009774495076117808 | 102.307074914112 | 0.7908967253880971 |
| .1 | -0.07204887404963626 | 13.8794674197278 | 0.1774310888655910 |
| .32 | -0.009857563759086530 | 101.444943643222 | 0.7893215261223604 |

All seven specified rates and their full spectra are in the machine-readable
spectrum result. The 24-e-fold quantity is the amplitude factor of the
linearized slow eigenmode in Einstein e-fold time.

## Boundaries retained

This establishes a conditional local result for the fixed-k, large-y,
trace-free radiation reduction. It does not show generic attraction to the
invariant x=0 plane, a global basin, finite capture, uniform nonlinear
control as k tends to zero, or attraction of the full action for arbitrarily
long N while it remains in the radiation approximation. The full trajectory
can leave the large-y regime as radiation dilutes. The endpoints k=0 and
k=1/3 are not included in the Hurwitz claim.

The supplied action, parameter k, radiation idealization, state within a
local neighborhood, matter content, thermal transitions, and actual observed
initial state are not derived by this calculation. Earlier restricted-class
uniqueness and contextual thermal-history probes have not been rechecked
here and are unnecessary to the local result. No full-history observational
test or cosmological-to-local bridge is established.

All new files are confined to `initial_state/independent_finite_k_v1/`.
The prior 41-artifact energy receipt, canonical packaging receipt and delivery
mapping receipts were not edited. Parent source, git/PR/runtime/audit state
were not changed. This report issues no formal audit verdict.
