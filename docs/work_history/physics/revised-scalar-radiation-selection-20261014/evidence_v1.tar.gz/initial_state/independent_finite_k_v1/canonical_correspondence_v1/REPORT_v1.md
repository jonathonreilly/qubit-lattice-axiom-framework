# Canonical radiation note: source and delivery correspondence

Checker: `/root/scalar_energy_check`. Scientific author: `/root`.
This is a focused correspondence check, not a formal audit, a new science
authorship block, or an authority/status decision.

The final canonical note corresponds to the previously checked finite-k
radiation and all-k relaxation results, and its added transverse section
corresponds to the separately sealed independent transverse check. No source
equation correction remains from this review. One regression-coverage gap in
an intermediate runner was identified here and repaired by the author. The
final runner's 117 successful conditions and nine actually executed damaged
copies are bound to the final source and cache bytes.

## Final identities and reused mathematics

| Item | SHA-256 |
| --- | --- |
| Canonical radiation note | `222e6adb8899fda6e2b1642b11dee83f2af669dece1c8917f35928f449a2f4f3` |
| Final runner, version 6 | `99c7919099d267f5bae1f66d1663d74b644305a870d82d3ab295d1eafbc84cb4` |
| Final runner cache | `a24428be35fb589d8159bc11f60b20ce57d6da8e4329a574e1fedf4e86695c3b` |
| Complete supplied action note | `39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000` |
| Original finite-k independent receipt | `0c07e8051bef08ec85c5cedc916bec70a07ce5d8c2939caf5f8c7c28c6401694` |
| Original relaxation independent receipt | `0caee9cb3e59fd6a32095df2ceb5d13b6d3cb64dd487045e532783f192c80d02` |
| Separate transverse independent receipt | `c3e1eae38953f9d84e0f1d83e73c7e1534601d39e1424f095971ff849b44071b` |

The canonical paths are
`docs/EXPONENTIAL_SCALAR_RADIATION_SELECTION_BOUNDED_THEOREM_NOTE_2026-10-14.md`,
`scripts/exponential_scalar_radiation_selection_check.py`, and
`logs/runner-cache/exponential_scalar_radiation_selection_check.txt`.
All source manifests retain exact repository-relative paths and snapshot hashes.
Initial note hash `af45e8a725fc8e00f088bb41c0baab8af30cd44c795044388b58412f55264cb8`
and all six runner versions remain recoverable in this record. Historical
snapshots are explicitly superseded versions, not assertions that their old
hashes still describe the live canonical paths.

The original 20 finite-k artifacts and 20 relaxation artifacts were verified
against their sealed records. Their proof derivations and controls are reused,
not rerun. The nested correspondence folder is not presented as part of the
old 20-artifact inventory. The separately authored transverse check contributes
18 hash-verified artifacts and three matching live/source pairs. Its complete
report, handwritten derivation, source and execution accounting were read.
No producer scientific runner was executed or imported by this checker in
this correspondence task. Reading the primary source was explicitly allowed
for packaging, after the original independent mathematics had been sealed.

## Correspondence of the action and bounded claims

The self-contained action retains the original kinetic normalization without
an extra one-half, all three metric components, conformal matter metric,
potential terms, positive parameters and both lambda definitions. The density
normalization is consistent: physical unscaled Jordan density multiplied by
`1/(2 Q Hv^2)` gives the same `y_b^2` as the earlier scaled density multiplied
by `rho_unit/(2 Q Hv^2)`. This is a declared calibration convention, not a
selection of the model's scale.

The newly explicit action-to-flow paragraph agrees with the original
independent derivation. The exact ell coefficient is
`B*d*y^2/(1+d*y^2)`, with `d=2(1+k)/3`; its fixed-k large-y limit is B.
Potential gradients are taken at fixed physical field coordinates before
substituting `y=y_b exp(z)`. Exact radiation has vanishing scalar trace force.
The Einstein constraint, Raychaudhuri equation, metric connection terms and
Jordan conservation law give the displayed flow, including `2 alpha_B p`
in z'. The x=0 restriction is invariant, with both x and x' initially zero.
It was never established by the old four-dimensional attraction proof.

The quartic, its all-k sign proof, cubic slow-root expansion and Lyapunov
argument retain their checked hypotheses. For each fixed `0<k<1/3`, the
four-dimensional reduced point is locally asymptotically stable. This supplies
no common nonlinear neighborhood as k tends to zero. The noncommuting-limits
statement concerns the linear slow factor. The exact inequality
`0 < -lambda_s < k` and its conditional `k<=b` consequence apply to a nonzero
linear slow component over a prescribed Einstein e-fold interval. They are
not a lower bound on every state norm or a nonlinear/full-history estimate.
The `b=1/79999` insertion remains an exposed proxy. A non-vacuum coupling
limit is not automatically a k limit; the finite-chart example is algebraic,
not an on-shell environmental solution or an experimental forward model.

The canonical transverse section preserves the separately checked action
pullback, mixed inverse-metric force, physical x equation, normal ratio block
and scope. Its additional connection/force explanation is also explicitly
derived in the peer's handwritten check. The peer normal matrix and the final
primary output agree exactly after algebraic normalization. This comparison
does not duplicate the peer's science. The normal exponents are `+1/2,-3/2`
for v=x/y, while x has `-3/2,-7/2`; these differ by the y clock exponent.
The energy ratio, local five-dimensional stable manifold, invariant-plane
subset, and distinction between stable tangent cancellation and a nonlinear
manifold are carried over correctly. The full six-variable *limiting*
autonomous point is a saddle. Neither this statement nor the pointwise
finite-y controls establish an arbitrary future saddle of the full action.

The final note consistently leaves fixed k, supplied action and matter,
trace-free radiation, large positive y, the bounded local chart, initial
amplitude and observational bridge as premises. It does not claim generic
attraction, a global basin, a measure on initial data, actual thermal history,
empirical exclusion, or selection of the observed state. No alternative
radiation source or next-route work was read or included.

## Completed execution evidence and the repaired coverage issue

The original primary timed out operationally: its recorded SIGTERM exit is
-15 after 189.502394 seconds, beyond the declared 120-second budget. A separate
35-second instrumented diagnostic stopped at expanded `flow.lowered_u`.
Those sources, empty unfinished stdout, full stderr and metadata are preserved.

Version 2 factored the lowered equations over symbolic coefficients and ran
in 2.36 seconds, but actually exited 1 with 84 passing conditions and one
failed characteristic-polynomial residual. This check independently reduced
that stored residual to zero using positive-square-root identities valid on
`0<k<1/3`. It did not apply unrestricted radical identities. Version 3 used
the already checked lambda_y identity before forming the flow and completed
85/0 in 1.366257 seconds. Its matrix is exactly similar to the sealed original
independent matrix under `diag(2 alpha,1,2 alpha,1)`. Its polynomial and all
seven printed rates/spectra agree with the original independent outputs at
their printed precision. No eigenvalue or trajectory calculation was rerun.

Version 4 added the transverse calculation and completed 113/0. Inspection
here found that the factored lowered-equation checks used generic pg/qg but
did not execute a binding to the actual nonlinear RHS. The formulas still
matched by inspection; the missing regression sensitivity was real. The
author's `REVIEW_CORRECTION_v5.json` supersedes the earlier statement that no
test target had weakened. Version 5 added both actual-flow bindings and
completed 115/0. A real `+p**3` RHS damage then failed only the new u binding,
as required for an error invisible to the fixed point and its Jacobian.

Version 6 additionally binds the transverse kernel to `K_xx/K_yy=4/3` and
`U_xx(u=x=0)=k`. These two additions and two whitespace lines are the complete
v5-to-v6 change. The final cache records exit 0, 117/0 and 1.64060998 seconds
within the unchanged 120-second budget. Its runner hash is exact. Rebuilding
the declared-input byte fingerprint independently, without importing the
repository cache helper, gives
`b18f504aeed1284f82b26f206261790927264c78f7c572956f65723dd54bdf89`,
which matches the cache and binds the final note bytes. Cache stdout equals
the completed build record; stderr is empty. All original 85 condition records,
matrix, polynomial, rates and exposed-proxy values are unchanged.

All nine final damaged copies were compared byte-for-byte with the exact
prescribed edits to final v6. Their recorded source hashes, completed stdout,
empty stderr, exit 1, check names and recomputed failure counts agree:

| Actual damage | Failed conditions |
| --- | ---: |
| Halved full y metric | 3 |
| Omitted physical-clock term | 9 |
| Halved reduced potential in both definitions | 15 |
| Wrong cubic slow coefficient | 1 |
| Wrong constant in the all-k sign polynomial | 2 |
| Omitted transverse inverse-metric mixing | 6 |
| Added nonlinear u drift | 1 |
| Wrong full x metric coefficient | 1 |
| Wrong full x potential curvature | 1 |

The last three fail their intended direct bindings. These are actual damaged
runner executions, distinct from built-in analytic damage probes. Finite
controls and symbolic identity checks supplement the reused derivations;
they are not exhaustive mutation coverage or empirical validation.

## Independent record, failures and exact checked scope

This packaging check produced 21 successful completed-lineage conditions,
45 successful v5 delivery conditions, and 61 successful final-v6 delivery and
peer-receipt conditions. These counts describe packaging checks, not newly
independent proofs or additional empirical tests. The initial frozen-input
check also verified its three compound metadata obligations. No history,
observational data or primary science runner was rerun.

The first correspondence-reader attempt genuinely failed because serialized
symbol `lambda` is a Python keyword in the SymPy parser. Its original code,
full stderr and empty stdout are preserved. The new reader changes only that
token to a non-keyword parser identifier bound to the same mathematical
symbol; all formulas and tolerances are unchanged. A read-only peer-report
lookup also initially used `.md` instead of the actual `.txt`; the failure
and resolution are recorded. Neither was a hidden passing run.

The peer's separate original run actually had 144 successes and one failed
structural-equality negative-control assertion. Its narrow replacement run
had three successes. The report, receipt, code and outputs explicitly reuse
the 144 successes and do not claim a new clean 145-condition execution. The
original failure, repaired assertion and all certificate artifacts are
preserved in the copied peer evidence, not silently merged into a fresh run.

The report/receipt/manifest bind the source versions, real failures, complete
final cache and damaged copies. The receipt's verification mode only reads
and hashes evidence. Original receipts remain unchanged. This checker wrote
only inside this new correspondence folder and made no Git, branch, PR,
runtime, lock, author-source, audit or authority changes. Scientific authorship
and any later integration or delivery decision remain with `/root`.
