#!/usr/bin/env python3
"""Read frozen, completed records only; do not import or execute producer code."""
from pathlib import Path
import ast
import datetime as dt
import hashlib
import json
import sys
import mpmath as mp
import sympy as sp

HERE = Path(__file__).resolve().parent
records = HERE / "parent_completed_v1_v3"
checks = []


def ck(name, ok, **details):
    checks.append(dict(name=name, passed=bool(ok), **details))


def get(name):
    return json.loads((records / name).read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


execs = [get(f"PRIMARY_EXECUTION_v{i}.json") for i in (1, 2, 3)]
for i, rec in enumerate(execs, 1):
    ck(f"v{i}.execution_source_hash", sha(records / f"PRIMARY_SOURCE_v{i}.py") == rec["script_sha256"])
durations = [(dt.datetime.fromisoformat(r["completed_at"]) -
              dt.datetime.fromisoformat(r["started_at"])).total_seconds()
             for r in execs]
ck("v1.failed_after_declared_timeout", execs[0]["exit_code"] == -15 and durations[0] > 120,
   elapsed_seconds=durations[0], declared_timeout_seconds=120)
ck("v1.no_completed_json", (records / "PRIMARY_v1.stdout.json").read_bytes() == b"")
diagnostic = (records / "PRIMARY_DIAGNOSTIC_v1.stderr.txt").read_text()
ck("diagnostic.stopped_in_expanded_lowered_u", diagnostic.endswith("START flow.lowered_u\n") and
   get("PRIMARY_DIAGNOSTIC_v1.json")["exit"] == "timeout35")

v2 = get("PRIMARY_v2.stdout.json")
v3 = get("PRIMARY_v3.stdout.json")
failed2 = [r for r in v2["checks"] if not r["passed"]]
ck("v2.actual_failure_preserved", execs[1]["exit_code"] == 1 and
   v2["counts"] == {"passed": 84, "failed": 1} and
   [r["name"] for r in failed2] == ["spectrum.characteristic_polynomial"])
ck("v3.actual_pass_preserved", execs[2]["exit_code"] == 0 and
   v3["counts"] == {"passed": 85, "failed": 0} and all(r["passed"] for r in v3["checks"]))
ck("v3.completed_inside_declared_budget", durations[2] < 120, elapsed_seconds=durations[2])
ck("v2_v3.check_names_unchanged", [r["name"] for r in v2["checks"]] ==
   [r["name"] for r in v3["checks"]])

k = sp.Symbol("k", positive=True)
lam = sp.Symbol("lambda")
loc = {"k": k, "lambda": lam, "Matrix": sp.Matrix}
residual2 = sp.sympify(failed2[0]["residual"], locals=loc)
# These two substitutions use positive real square roots on 0<k<1/3.
# No force=True power rewrite or equality outside that domain is assumed.
radical_replacements = {
    sp.sqrt(-3*k*k+2*k+1): sp.sqrt(1-k)*sp.sqrt(1+3*k),
    sp.sqrt(-9*k**3+3*k*k+5*k+1): (1+3*k)*sp.sqrt(1-k),
}
normalized = sp.factor(sp.cancel(residual2.xreplace(radical_replacements)))
ck("v2.failed_residual_zero_on_stated_positive_domain", normalized == 0,
   normalized_residual=str(normalized),
   branch_hypothesis="0<k<1/3: both 1-k and 1+3k are positive")

independent = json.loads((HERE / "source_snapshot/PRIOR_FINITE_K_SPECTRUM_v1.json").read_text())
M = sp.sympify(v3["matrix"], locals=loc)
Mi = sp.Matrix([[sp.sympify(v, locals=loc) for v in row] for row in independent["jacobian"]])
two_alpha = sp.sqrt(1-k)*sp.sqrt(1+3*k)
scaling = sp.diag(two_alpha, 1, two_alpha, 1)
matrix_residual = (scaling*M*scaling.inv()-Mi).applyfunc(lambda x: sp.factor(sp.cancel(x)))
ck("v3.matrix_matches_sealed_independent_coordinates", matrix_residual == sp.zeros(4),
   transformation="M_ind = diag(2alpha,1,2alpha,1) M_primary diag(2alpha,1,2alpha,1)^(-1)",
   residual=str(matrix_residual))
cp = sp.sympify(v3["characteristic_polynomial"], locals=loc)
cpi = sp.sympify(independent["characteristic_polynomial"], locals=loc)
cpres = sp.factor(sp.cancel(cp-cpi))
ck("v3.polynomial_matches_sealed_independent_output", cpres == 0, residual=str(cpres))

mp.mp.dps = 90
old_rates = {mp.mpf(r["k"]): r for r in independent["rates"]}
comparisons = []
for row in v3["rates"]:
    prior = old_rates[mp.mpf(row["k"])]
    errors = {}
    for key, old_key in [
        ("slow_eigenvalue", "lambda_slow_stable_closed_form"),
        ("linear_relaxation_e_folds", "Einstein_efold_relaxation_time"),
        ("slow_mode_retained_after_24_Einstein_e_folds", "linear_amplitude_after_24_efolds"),
    ]:
        new, old = mp.mpf(row[key]), mp.mpf(prior[old_key])
        errors[key] = abs((new-old)/old)
    eigen_new = [mp.mpc(*p) for p in row["spectrum"]]
    eigen_old = [mp.mpc(p["real"], p["imag"]) for p in prior["eigenvalues"]]
    eigen_error = max(min(abs((a-b)/b) for b in eigen_old) for a in eigen_new)
    ck("v3.cached_numbers_match_independent_k_"+row["k"],
       max(errors.values()) < mp.mpf("1e-38") and eigen_error < mp.mpf("1e-28"))
    comparisons.append(dict(k=row["k"], relative_errors={key:mp.nstr(v,16) for key,v in errors.items()},
                            max_spectrum_relative_error=mp.nstr(eigen_error,16)))

tree = ast.parse((records / "PRIMARY_SOURCE_v3.py").read_text())
generic_lowered = []
for node in ast.walk(tree):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "exact" and node.args:
        if isinstance(node.args[0], ast.Constant) and node.args[0].value in ("flow.lowered_u", "flow.lowered_ell"):
            names = sorted({n.id for n in ast.walk(node.args[1]) if isinstance(n, ast.Name)})
            generic_lowered.append(dict(name=node.args[0].value, referenced_names=names,
                                        references_actual_flow="flow" in names))
ck("v3.generic_lowered_checks_are_unbound", len(generic_lowered) == 2 and
   all(not r["references_actual_flow"] for r in generic_lowered))

result = dict(
    scope="Delivery correspondence of frozen completed v1-v3 records; no producer import/execution and no science rerun.",
    script_sha256=sha(Path(__file__)), checks=checks, comparisons=comparisons,
    findings=["The factored v2/v3 generic lowered identities no longer reference actual flow[2]/flow[3]. Formulas match by source inspection; direct coefficient-substitution bindings were requested to restore regression sensitivity."],
    generic_lowered_check_dependencies=generic_lowered,
    counts=dict(passed=sum(r["passed"] for r in checks), failed=sum(not r["passed"] for r in checks)),
)
out = HERE / "results/completed_lineage_run01.json"
with out.open("x") as f:
    json.dump(result, f, indent=2)
    f.write("\n")
print(json.dumps(result, indent=2))
sys.exit(bool(result["counts"]["failed"]))
