#!/usr/bin/env python3
"""Inspect immutable completed delivery records, never execute producer code."""
from pathlib import Path
import ast
import datetime as dt
import difflib
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
FINAL = HERE / "parent_final"
MUT = FINAL / "mutations_v2"
checks = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ck(name, ok, **extra):
    checks.append(dict(name=name, passed=bool(ok), **extra))


def read_json(path):
    return json.loads(path.read_text())


runner = (HERE / "source_snapshot/CANONICAL_RUNNER_v5.py").read_bytes()
runner_text = runner.decode()
note = (HERE / "source_snapshot/CANONICAL_NOTE_v2.md").read_bytes()
note_path = "docs/EXPONENTIAL_SCALAR_RADIATION_SELECTION_BOUNDED_THEOREM_NOTE_2026-10-14.md"
runner_path = "scripts/exponential_scalar_radiation_selection_check.py"
cache = (FINAL / "CACHE_v5.txt").read_text()
header_text, rest = cache.split("----- stdout -----\n", 1)
stdout, stderr = rest.split("----- stderr -----\n", 1)
header = dict(line.split(": ", 1) for line in header_text.splitlines() if ": " in line)
payload = json.loads(stdout)
build = read_json(FINAL / "CACHE_BUILD_v2.json")
build_result = build["result"]

declared = {}
tree = ast.parse(runner_text)
for node in tree.body:
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id in ("AUDIT_TIMEOUT_SEC", "AUDIT_INPUT_PATHS"):
                declared[target.id] = ast.literal_eval(node.value)
ck("metadata.input_and_timeout_declarations", declared == {
    "AUDIT_TIMEOUT_SEC": 120, "AUDIT_INPUT_PATHS": (note_path,)})
# Reconstruct the documented v1 byte fingerprint directly. No runner_cache import.
digest = hashlib.sha256(b"runner-cache-input-fingerprint-v1\0")
path_bytes = note_path.encode()
digest.update(len(path_bytes).to_bytes(8, "big"))
digest.update(path_bytes)
digest.update(len(note).to_bytes(8, "big"))
digest.update(note)
ck("cache.binds_exact_note_bytes", header["input_fingerprint_sha256"] == digest.hexdigest(),
   fingerprint=digest.hexdigest(), note_sha256=sha(note))
ck("cache.binds_exact_runner_bytes", header["runner_sha256"] == sha(runner), runner_sha256=sha(runner))
ck("cache.runner_path", header["runner"] == runner_path == build_result["runner"])
ck("cache.success_status_and_runtime", header["status"] == build_result["status"] == "ok" and
   int(header["exit_code"]) == build_result["exit_code"] == 0 and
   int(header["timeout_sec"]) == build_result["timeout_sec"] == 120 and
   build_result["elapsed_sec"] < 120 and
   abs(float(header["elapsed_sec"])-build_result["elapsed_sec"]) < 0.005,
   elapsed_sec=build_result["elapsed_sec"])
ck("cache.output_matches_completed_build", payload == json.loads(build_result["stdout"]) and
   stdout.strip() == build_result["stdout"].strip() and not stderr.strip() and build_result["stderr"] == "")
names = [r["name"] for r in payload["checks"]]
ck("cache.recomputed_check_count", payload["counts"] == {"passed": 115, "failed": 0} and
   len(names) == len(set(names)) == 115 and all(r["passed"] for r in payload["checks"]))
ck("cache.transverse_nested_records_match_global", payload["transverse"]["checks"] ==
   [r for r in payload["checks"] if r["name"].startswith("transverse.")])

v3 = read_json(HERE / "parent_completed_v1_v3/PRIMARY_v3.stdout.json")
ck("v5.reuses_exact_v3_matrix_polynomial_rates_proxy", all(
    payload[key] == v3[key] for key in ("matrix", "characteristic_polynomial", "rates", "exposed_proxy")))
v3map = {r["name"]: r for r in v3["checks"]}
ck("v5.original_85_check_records_unchanged", all(
    r == v3map[r["name"]] for r in payload["checks"] if r["name"] in v3map) and
   len(set(names) & set(v3map)) == 85)
v4 = read_json(FINAL / "PRIMARY_v4.stdout.json")
v4execution = read_json(FINAL / "PRIMARY_EXECUTION_v4.json")
ck("v4.preserved_completed_intermediate", v4["counts"] == {"passed": 113, "failed": 0} and
   v4execution["exit_code"] == 0 and
   sha((FINAL / "PRIMARY_SOURCE_v4.py").read_bytes()) == v4execution["script_sha256"])
binding_names = {"flow.actual_u_matches_lowered_solution", "flow.actual_ell_matches_lowered_solution"}
ck("v5.adds_only_two_binding_records_to_v4", [r for r in payload["checks"] if r["name"] not in binding_names] ==
   v4["checks"] and set(names)-{r["name"] for r in v4["checks"]} == binding_names)
ck("v5.frozen_source_matches_parent_completed_source", runner == (FINAL / "PRIMARY_SOURCE_v5.py").read_bytes())

bindings_found = []
for n in ast.walk(tree):
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "exact" and n.args:
        if isinstance(n.args[0], ast.Constant) and n.args[0].value in binding_names:
            refs = {sub.id for sub in ast.walk(n.args[1]) if isinstance(sub, ast.Name)}
            bindings_found.append({"name":n.args[0].value, "names":sorted(refs)})
ck("v5.bindings_reference_actual_flow_and_coefficient_map", len(bindings_found) == 2 and all(
    {"flow", "coefficient_bindings"} <= set(r["names"]) for r in bindings_found))

protocol = read_json(MUT / "PROTOCOL_v2.json")
summary = read_json(MUT / "RESULTS_v2.json")
ck("mutations.bind_exact_v5_source", protocol["source_sha256"] == sha(runner))
ck("mutations.seven_cases_and_records", len(protocol["cases"]) == len(summary["mutations"]) == 7 and
   summary["all_detected"] is True)
summaries = {r["name"]:r for r in summary["mutations"]}
details = []
for case in protocol["cases"]:
    name = case["name"]
    damaged = (MUT / (name+".py")).read_bytes()
    execution = read_json(MUT / (name+".execution.json"))
    output = read_json(MUT / (name+".stdout.json"))
    err = (MUT / (name+".stderr.txt")).read_text()
    failures = [r for r in output["checks"] if not r["passed"]]
    replacement_count = runner_text.count(case["original"])
    ck(name+".exact_prescribed_damage", replacement_count > 0 and
       damaged == runner_text.replace(case["original"],case["damaged"]).encode() and damaged != runner,
       replacement_count=replacement_count)
    ck(name+".execution_hash_and_summary", execution == summaries[name] and
       execution["script_sha256"] == sha(damaged))
    counts = {"passed":sum(r["passed"] for r in output["checks"]),
              "failed":sum(not r["passed"] for r in output["checks"])}
    ck(name+".actual_completed_failed_checks", execution["exit_code"] == 1 and
       counts == execution["counts"] == output["counts"] and counts["failed"] > 0 and
       [r["name"] for r in failures] == execution["failed_checks"] and
       [r["name"] for r in output["checks"]] == names and err == "")
    start, end = (dt.datetime.fromisoformat(execution[k]) for k in ("started_at","completed_at"))
    ck(name+".completed_inside_timeout", 0 < (end-start).total_seconds() < 120 and
       dt.datetime.fromisoformat(protocol["frozen_at"]) <= start)
    details.append(dict(name=name, script_sha256=sha(damaged), counts=counts,
                        failures=failures, stderr_empty=not err,
                        diff="".join(difflib.unified_diff(runner_text.splitlines(True),
                                                         damaged.decode().splitlines(True),
                                                         fromfile="primary-v5",tofile=name))))

drift = next(r for r in details if r["name"] == "nonlinear_u_drift")
ck("finding.closed_by_nonlinear_only_damage", [r["name"] for r in drift["failures"]] ==
   ["flow.actual_u_matches_lowered_solution"] and drift["failures"][0]["residual"] == "p**3")

result = dict(scope="New packaging/source-cache and actual-damage correspondence only; prior mathematics reused; transverse science receipt checked separately.",
              script_sha256=sha(Path(__file__).read_bytes()),checks=checks,cache_header=header,
              bindings=bindings_found,mutation_details=details,
              counts=dict(passed=sum(r["passed"] for r in checks),failed=sum(not r["passed"] for r in checks)))
with (HERE / "results/final_delivery_run01.json").open("x") as f:
    json.dump(result,f,indent=2)
    f.write("\n")
print(json.dumps(result,indent=2))
sys.exit(bool(result["counts"]["failed"]))
