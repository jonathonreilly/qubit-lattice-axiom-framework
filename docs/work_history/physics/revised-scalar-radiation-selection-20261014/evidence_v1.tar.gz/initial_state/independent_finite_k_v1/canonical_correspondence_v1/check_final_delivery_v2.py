#!/usr/bin/env python3
"""Inspect immutable completed delivery records, never execute producer code."""
from pathlib import Path
import ast
import datetime as dt
import difflib
import hashlib
import json
import sys
import sympy as sp

HERE = Path(__file__).resolve().parent
FINAL = HERE / "parent_final_v6"
MUT = FINAL / "mutations_v3"
checks = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ck(name, ok, **extra):
    checks.append(dict(name=name, passed=bool(ok), **extra))


def read_json(path):
    return json.loads(path.read_text())


runner = (HERE / "source_snapshot/CANONICAL_RUNNER_v6.py").read_bytes()
runner_text = runner.decode()
note = (HERE / "source_snapshot/CANONICAL_NOTE_v2.md").read_bytes()
note_path = "docs/EXPONENTIAL_SCALAR_RADIATION_SELECTION_BOUNDED_THEOREM_NOTE_2026-10-14.md"
runner_path = "scripts/exponential_scalar_radiation_selection_check.py"
cache = (FINAL / "CACHE_v6.txt").read_text()
header_text, rest = cache.split("----- stdout -----\n", 1)
stdout, stderr = rest.split("----- stderr -----\n", 1)
header = dict(line.split(": ", 1) for line in header_text.splitlines() if ": " in line)
payload = json.loads(stdout)
build = read_json(FINAL / "CACHE_BUILD_v3.json")
build_result = build["result"]

declared = {}
tree = ast.parse(runner_text)
for node in tree.body:
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id in ("AUDIT_TIMEOUT_SEC", "AUDIT_INPUT_PATHS"):
                declared[target.id] = ast.literal_eval(node.value)
ck("metadata.input_and_timeout_declarations", declared == {
    "AUDIT_TIMEOUT_SEC": 120, "AUDIT_INPUT_PATHS": (note_path,)})
# Reconstruct the documented v1 byte fingerprint directly. No runner_cache import.
digest = hashlib.sha256(b"runner-cache-input-fingerprint-v1\0")
path_bytes = note_path.encode()
digest.update(len(path_bytes).to_bytes(8, "big"))
digest.update(path_bytes)
digest.update(len(note).to_bytes(8, "big"))
digest.update(note)
ck("cache.binds_exact_note_bytes", header["input_fingerprint_sha256"] == digest.hexdigest(),
   fingerprint=digest.hexdigest(), note_sha256=sha(note))
ck("cache.binds_exact_runner_bytes", header["runner_sha256"] == sha(runner), runner_sha256=sha(runner))
ck("cache.runner_path", header["runner"] == runner_path == build_result["runner"])
ck("cache.success_status_and_runtime", header["status"] == build_result["status"] == "ok" and
   int(header["exit_code"]) == build_result["exit_code"] == 0 and
   int(header["timeout_sec"]) == build_result["timeout_sec"] == 120 and
   build_result["elapsed_sec"] < 120 and
   abs(float(header["elapsed_sec"])-build_result["elapsed_sec"]) < 0.005,
   elapsed_sec=build_result["elapsed_sec"])
ck("cache.output_matches_completed_build", payload == json.loads(build_result["stdout"]) and
   stdout.strip() == build_result["stdout"].strip() and not stderr.strip() and build_result["stderr"] == "")
names = [r["name"] for r in payload["checks"]]
ck("cache.recomputed_check_count", payload["counts"] == {"passed": 117, "failed": 0} and
   len(names) == len(set(names)) == 117 and all(r["passed"] for r in payload["checks"]))
ck("cache.transverse_nested_records_match_global", payload["transverse"]["checks"] ==
   [r for r in payload["checks"] if r["name"].startswith("transverse.")])

v3 = read_json(HERE / "parent_completed_v1_v3/PRIMARY_v3.stdout.json")
ck("v6.reuses_exact_v3_matrix_polynomial_rates_proxy", all(
    payload[key] == v3[key] for key in ("matrix", "characteristic_polynomial", "rates", "exposed_proxy")))
v3map = {r["name"]: r for r in v3["checks"]}
ck("v6.original_85_check_records_unchanged", all(
    r == v3map[r["name"]] for r in payload["checks"] if r["name"] in v3map) and
   len(set(names) & set(v3map)) == 85)
previous_cache = (HERE / "parent_final/CACHE_v5.txt").read_text()
previous_stdout = previous_cache.split("----- stdout -----\n", 1)[1].split("----- stderr -----\n", 1)[0]
v5 = json.loads(previous_stdout)
action_binding_names = {"action.transverse_metric_ratio", "action.transverse_potential_curvature"}
ck("v5.preserved_completed_intermediate", v5["counts"] == {"passed": 115, "failed": 0})
ck("v6.adds_only_two_action_binding_records_to_v5", [r for r in payload["checks"] if r["name"] not in action_binding_names] ==
   v5["checks"] and set(names)-{r["name"] for r in v5["checks"]} == action_binding_names)
ck("v6.frozen_source_matches_parent_completed_source", runner == (FINAL / "PRIMARY_SOURCE_v6.py").read_bytes())
binding_names = {"flow.actual_u_matches_lowered_solution", "flow.actual_ell_matches_lowered_solution"}

bindings_found = []
for n in ast.walk(tree):
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "exact" and n.args:
        if isinstance(n.args[0], ast.Constant) and n.args[0].value in binding_names:
            refs = {sub.id for sub in ast.walk(n.args[1]) if isinstance(sub, ast.Name)}
            bindings_found.append({"name":n.args[0].value, "names":sorted(refs)})
ck("v6.bindings_reference_actual_flow_and_coefficient_map", len(bindings_found) == 2 and all(
    {"flow", "coefficient_bindings"} <= set(r["names"]) for r in bindings_found))

protocol = read_json(MUT / "PROTOCOL_v3.json")
summary = read_json(MUT / "RESULTS_v3.json")
ck("mutations.bind_exact_v6_source", protocol["source_sha256"] == sha(runner))
ck("mutations.nine_cases_and_records", len(protocol["cases"]) == len(summary["mutations"]) == 9 and
   summary["all_detected"] is True)
summaries = {r["name"]:r for r in summary["mutations"]}
details = []
for case in protocol["cases"]:
    name = case["name"]
    damaged = (MUT / (name+".py")).read_bytes()
    execution = read_json(MUT / (name+".execution.json"))
    output = read_json(MUT / (name+".stdout.json"))
    err = (MUT / (name+".stderr.txt")).read_text()
    failures = [r for r in output["checks"] if not r["passed"]]
    replacement_count = runner_text.count(case["original"])
    ck(name+".exact_prescribed_damage", replacement_count > 0 and
       damaged == runner_text.replace(case["original"],case["damaged"]).encode() and damaged != runner,
       replacement_count=replacement_count)
    ck(name+".execution_hash_and_summary", execution == summaries[name] and
       execution["script_sha256"] == sha(damaged))
    counts = {"passed":sum(r["passed"] for r in output["checks"]),
              "failed":sum(not r["passed"] for r in output["checks"])}
    ck(name+".actual_completed_failed_checks", execution["exit_code"] == 1 and
       counts == execution["counts"] == output["counts"] and counts["failed"] > 0 and
       [r["name"] for r in failures] == execution["failed_checks"] and
       [r["name"] for r in output["checks"]] == names and err == "")
    start, end = (dt.datetime.fromisoformat(execution[k]) for k in ("started_at","completed_at"))
    ck(name+".completed_inside_timeout", 0 < (end-start).total_seconds() < 120 and
       dt.datetime.fromisoformat(protocol["frozen_at"]) <= start)
    details.append(dict(name=name, script_sha256=sha(damaged), counts=counts,
                        failures=failures, stderr_empty=not err,
                        diff="".join(difflib.unified_diff(runner_text.splitlines(True),
                                                         damaged.decode().splitlines(True),
                                                         fromfile="primary-v6",tofile=name))))

drift = next(r for r in details if r["name"] == "nonlinear_u_drift")
ck("finding.closed_by_nonlinear_only_damage", [r["name"] for r in drift["failures"]] ==
   ["flow.actual_u_matches_lowered_solution"] and drift["failures"][0]["residual"] == "p**3")

peer = HERE / "peer_transverse_v1"
peer_manifest = read_json(peer / "MANIFEST_v1.json")
peer_receipt = read_json(peer / "RECEIPT_v1.json")
peer_rows = []
for row in peer_manifest["artifacts"]:
    data = (peer / row["path"]).read_bytes()
    peer_rows.append(dict(path=row["path"],valid=len(data)==row["bytes"] and sha(data)==row["sha256"]))
ck("peer.all_18_sealed_artifacts_match", len(peer_rows) == peer_manifest["artifact_count"] == 18 and
   all(r["valid"] for r in peer_rows))
ck("peer.receipt_and_report_identity", sha((peer / "RECEIPT_v1.json").read_bytes()) ==
   "c3e1eae38953f9d84e0f1d83e73c7e1534601d39e1424f095971ff849b44071b" and
   sha((peer / "REPORT_v1.txt").read_bytes()) ==
   "8ce609a9d8541e4e5eae12482a1b8e7d04b45c11a35e2d6e99f467f3b6870cf7")
peer_pairs = []
for row in peer_receipt["source_files"]:
    live, frozen = Path(row["source_path"]).read_bytes(), (peer / row["snapshot_path"]).read_bytes()
    peer_pairs.append(dict(source_path=row["source_path"],valid=live==frozen and sha(frozen)==row["sha256"]))
ck("peer.three_live_source_pairs_match", len(peer_pairs)==3 and all(r["valid"] for r in peer_pairs))
peer_run1 = read_json(peer / "RUN_01.stdout.json")
peer_run2 = read_json(peer / "RUN_02_REPAIR.stdout.json")
peer_bad = [r for r in peer_run1["checks"] if not r["pass"]]
ck("peer.original_failure_preserved_without_clean_rerun_claim", peer_run1["counts"] == {"passed":144,"failed":1}
   and sum(r["pass"] for r in peer_run1["checks"]) == 144
   and [r["name"] for r in peer_bad] == ["damage_omit_transformed_connection"]
   and read_json(peer / "RUN_01.json")["exit_code"] == 1
   and peer_run2["full_science_rerun"] is False)
ck("peer.separate_narrow_repair_accounted", peer_run2["counts"] == {"passed":3,"failed":0}
   and len(peer_run2["checks"]) == 3 and all(r["pass"] for r in peer_run2["checks"])
   and read_json(peer / "RUN_02_REPAIR.json")["exit_code"] == 0)
for run in peer_receipt["actual_runs"]:
    metadata = read_json(peer / run["metadata"]["path"])
    ck("peer.execution_hashes_"+run["metadata"]["path"],
       metadata["script_sha256"] == sha((peer/run["script"]["path"]).read_bytes()) and
       metadata["stdout_sha256"] == sha((peer/run["stdout"]["path"]).read_bytes()) and
       metadata["stderr_sha256"] == sha((peer/run["stderr"]["path"]).read_bytes()))
# Compare completed outputs only; do not derive or execute the peer normal flow.
loc = {"Matrix":sp.Matrix,"k":sp.Symbol("k",positive=True)}
primary_normal = sp.sympify(payload["transverse"]["normal_jacobian"],locals=loc)
peer_normal = sp.sympify(peer_run1["normal_block"],locals=loc)
normal_residual = (primary_normal-peer_normal).applyfunc(lambda x:sp.factor(sp.cancel(x)))
ck("peer.primary_normal_block_matches_independent_result",normal_residual==sp.zeros(2),residual=str(normal_residual))

result = dict(scope="New packaging/source-cache and actual-damage correspondence only; prior mathematics reused; transverse science receipt checked separately.",
              script_sha256=sha(Path(__file__).read_bytes()),checks=checks,cache_header=header,
              bindings=bindings_found,mutation_details=details,
              peer_artifacts=peer_rows,peer_source_pairs=peer_pairs,peer_original_failed_control=peer_bad,
              counts=dict(passed=sum(r["passed"] for r in checks),failed=sum(not r["passed"] for r in checks)))
with (HERE / "results/final_delivery_run02.json").open("x") as f:
    json.dump(result,f,indent=2)
    f.write("\n")
print(json.dumps(result,indent=2))
sys.exit(bool(result["counts"]["failed"]))
