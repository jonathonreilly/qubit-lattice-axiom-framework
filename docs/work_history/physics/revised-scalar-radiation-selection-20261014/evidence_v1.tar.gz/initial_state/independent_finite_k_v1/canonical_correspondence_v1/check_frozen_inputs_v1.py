#!/usr/bin/env python3
"""Read-only version/inventory and source-diff checks, without executing science."""
from pathlib import Path
import ast
import datetime
import difflib
import hashlib
import json


ROOT=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
OUT=Path(__file__).resolve().parent
BASE=ROOT/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013/initial_state'


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    target=OUT/'results/frozen_inputs_run01.json'
    if target.exists():raise RuntimeError('Preserve existing result')
    source_manifest=json.loads((OUT/'SOURCE_MANIFEST_INITIAL_v1.json').read_text())
    snapshots=[]
    for row in source_manifest['sources']:
        p=OUT/row['snapshot_path']
        snapshots.append({'path':row['snapshot_path'],'expected':row['sha256'],'actual':sha(p),'matches':sha(p)==row['sha256'] and p.stat().st_size==row['bytes']})
    prior=[]
    for directory,receipt_name in [('independent_finite_k_v1','PRIOR_FINITE_K_RECEIPT_v1.json'),('independent_relaxation_bound_v1','PRIOR_RELAXATION_RECEIPT_v1.json')]:
        frozen=OUT/'source_snapshot'/receipt_name
        receipt=json.loads(frozen.read_text());live=BASE/directory/'RECEIPT_v1.json'
        assert sha(live)==sha(frozen)
        if 'artifacts' in receipt:
            entries=receipt['artifacts']
        else:
            manifest_path=BASE/directory/receipt['manifest_path']
            assert sha(manifest_path)==receipt['manifest_sha256']
            entries=json.loads(manifest_path.read_text())['artifacts']
        errors=[]
        for entry in entries:
            path=BASE/directory/entry['path']
            if path.stat().st_size!=entry['bytes'] or sha(path)!=entry['sha256']:errors.append(entry['path'])
        prior.append({'directory':directory,'receipt_sha256':sha(live),'artifacts_checked':len(entries),'errors':errors,
                      'scope':'Original enumerated artifacts only. New nested packaging evidence is deliberately not an original artifact.'})
    canonical=(OUT/'source_snapshot/CANONICAL_NOTE_v1.md').read_text()
    old_finite=(OUT/'source_snapshot/FINITE_K_CHECKED_SOURCE_v2.md').read_text()
    old_relax=(OUT/'source_snapshot/RELAXATION_CHECKED_SOURCE_v1.md').read_text()
    marker='## Deriving the finite-k reduced equations'
    old_block=old_finite[old_finite.index(marker):]
    new_block=canonical[canonical.index(marker):canonical.index('## All-coupling rate bound and conditional observation link')]
    finite_diff=''.join(difflib.unified_diff(old_block.splitlines(keepends=True),new_block.splitlines(keepends=True),fromfile='checked_finite_k_v2_sections',tofile='canonical_initial_finite_k_sections'))
    relax_block=canonical[canonical.index('Take the hypotheses of the finite-k radiation reduction above:'):canonical.index('## Executed evidence and surviving assumptions')]
    relax_diff=''.join(difflib.unified_diff(old_relax.splitlines(keepends=True),relax_block.splitlines(keepends=True),fromfile='checked_relaxation_source_v1',tofile='canonical_initial_relaxation_section'))
    (OUT/'FINITE_K_TO_CANONICAL_INITIAL.diff').write_text(finite_diff)
    (OUT/'RELAXATION_TO_CANONICAL_INITIAL.diff').write_text(relax_diff)
    runner=OUT/'source_snapshot/CANONICAL_RUNNER_v1.py'
    tree=ast.parse(runner.read_text())
    declarations={}
    for node in tree.body:
        if isinstance(node,ast.Assign):
            for item in node.targets:
                if isinstance(item,ast.Name) and item.id in ('AUDIT_TIMEOUT_SEC','AUDIT_INPUT_PATHS'):
                    declarations[item.id]=ast.literal_eval(node.value)
    literal_checks=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id in ('check','exact') and node.args and isinstance(node.args[0],ast.Constant) and isinstance(node.args[0].value,str):
            literal_checks.append({'function':node.func.id,'label':node.args[0].value,'line':node.lineno})
    result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script_sha256':sha(Path(__file__)),
            'frozen_source_checks':snapshots,'prior_receipt_inventory_checks':prior,
            'runner_snapshot_sha256':sha(runner),'runner_syntax':'AST parsed; not executed or imported',
            'runner_declarations':declarations,'literal_check_sites':literal_checks,
            'source_diffs':{'finite':sha(OUT/'FINITE_K_TO_CANONICAL_INITIAL.diff'),'relaxation':sha(OUT/'RELAXATION_TO_CANONICAL_INITIAL.diff')},
            'new_science_rerun':False,'primary_output_inspected':False,
            'final_seal':'held pending parent integration decision and completed primary/cache/mutations',
            'checks':{'snapshots_match':all(x['matches'] for x in snapshots),'original_enumerated_artifacts_unchanged':all(not x['errors'] for x in prior),
                      'canonical_runner_declares_note_input':declarations['AUDIT_INPUT_PATHS']==('docs/EXPONENTIAL_SCALAR_RADIATION_SELECTION_BOUNDED_THEOREM_NOTE_2026-10-14.md',)}}
    result['failures']=[k for k,v in result['checks'].items() if not v]
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if result['failures']:raise SystemExit(1)


if __name__=='__main__':main()
