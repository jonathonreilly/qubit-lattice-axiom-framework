#!/usr/bin/env python3
"""Repair only the one failed representation assertion; do not rerun science."""
from pathlib import Path
import hashlib
import json
import sys
import sympy as s

OUT=Path(__file__).resolve().parent
old_raw=(OUT/"RUN_01.stdout.json").read_bytes()
old=json.loads(old_raw)
old_run=json.loads((OUT/"RUN_01.json").read_text())
failed=[row for row in old["checks"] if not row["pass"]]
lam=s.symbols("lambda")
damaged=lam**2+lam+s.Rational(1,4)
factored=s.factor(damaged)
claimed=(lam+s.Rational(1,2))**2
checks=[
    {"name":"original_execution_binding","category":"binding","pass":
        hashlib.sha256(old_raw).hexdigest()==old_run["stdout_sha256"]
        and old_run["exit_code"]==1 and old["counts"]=={"passed":144,"failed":1}
        and len(failed)==1 and failed[0]["name"]=="damage_omit_transformed_connection"},
    {"name":"diagnose_structural_not_algebraic_mismatch","category":"diagnosis","pass":
        factored!=claimed and s.cancel(factored-claimed)==0,
        "factored":str(factored),"claimed":str(claimed),"difference":str(s.cancel(factored-claimed))},
    {"name":"damage_omit_transformed_connection_replacement","category":"replacement","pass":
        damaged.subs(lam,s.Rational(1,2))!=0
        and s.cancel(factored-claimed)==0
        and damaged.subs(lam,s.Rational(-1,2))==0
        and s.diff(damaged,lam).subs(lam,s.Rational(-1,2))==0,
        "correct_growing_root_residual":str(damaged.subs(lam,s.Rational(1,2))),
        "damaged_polynomial":str(damaged),"damaged_roots":"-1/2 repeated twice"},
]
output={"scope":"One replacement negative control, one diagnosis and one original-run binding; 144 original successes reused without rerun.",
        "checks":checks,"counts":{"passed":sum(bool(row["pass"]) for row in checks),"failed":sum(not row["pass"] for row in checks)},
        "original_failed_control":failed,"producer_code_or_results_read":False,"full_science_rerun":False}
print(json.dumps(output,indent=2))
sys.exit(any(not row["pass"] for row in checks))
