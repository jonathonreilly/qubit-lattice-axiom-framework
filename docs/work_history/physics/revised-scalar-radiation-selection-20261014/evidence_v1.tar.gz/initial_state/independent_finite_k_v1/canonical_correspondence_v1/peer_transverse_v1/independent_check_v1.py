#!/usr/bin/env python3
"""Independent action/geometry normal-mode check. No producer imports."""
from pathlib import Path
from fractions import Fraction as Q
import hashlib
import json
import sys
import sympy as s

OUT=Path(__file__).resolve().parent
checks=[]
certificates=[]

def check(name, condition, category, evidence=None):
    checks.append({"name":name,"pass":bool(condition),"category":category,"evidence":evidence})

def exact(name, expression, category="symbolic"):
    reduced=s.factor(s.cancel(expression))
    check(name,reduced==0,category,str(reduced))

def q(value):
    value=s.Rational(value)
    return Q(int(value.p),int(value.q))

def sym(value):
    value=Q(value)
    return s.Rational(value.numerator,value.denominator)

def show(value):
    value=Q(value)
    return {"exact":str(value),"decimal":format(float(value),".16g")}

def horner(poly,left,right):
    lo=hi=Q(0)
    for value in poly.all_coeffs():
        products=[lo*left,lo*right,hi*left,hi*right]
        lo=min(products)+q(value);hi=max(products)+q(value)
    return lo,hi

def rational_interval(expression,variable,left,right):
    numerator,denominator=s.fraction(s.cancel(expression))
    numerator=s.Poly(numerator,variable,domain=s.QQ)
    denominator=s.Poly(denominator,variable,domain=s.QQ)
    subdivisions=32
    intervals=[]
    for index in range(subdivisions):
        a=left+(right-left)*Q(index,subdivisions)
        b=left+(right-left)*Q(index+1,subdivisions)
        nl,nu=horner(numerator,a,b);dl,du=horner(denominator,a,b)
        if dl<=0<=du:
            raise ArithmeticError("Exact interval denominator was not separated from zero")
        vals=[nn/dd for nn in [nl,nu] for dd in [dl,du]]
        intervals.append((min(vals),max(vals)))
    return min(z[0] for z in intervals),max(z[1] for z in intervals)

source_rows=json.loads((OUT/"SOURCE_MANIFEST_v1.json").read_text())["source_files"]
for i,row in enumerate(source_rows):
    raw=Path(row["source_path"]).read_bytes()
    check("source_identity_"+str(i),raw==(OUT/row["snapshot_path"]).read_bytes()
          and hashlib.sha256(raw).hexdigest()==row["sha256"] and len(raw)==row["bytes"],"binding")

# Pull back the ORIGINAL metric before taking the limit. Coordinate order u,ell,v.
k,ss,F,A,B,Au,Bu=s.symbols("k ss F A B Au Bu",positive=True)
y,v=s.symbols("y v",real=True)
d=2*(1+k)/3
D=1+d*y*y*(1+v*v)
old=s.diag(A,(1+ss)*4*k/(9*F*D),(1+ss)*k/(3*F*D))
transform=s.Matrix([[1,0,0],[0,v*y,y],[0,y,0]])
pulled=transform.T*old*transform
M=s.Matrix([[0,0,0],[0,(1+s.Rational(4,3)*v*v)/(1+v*v),s.Rational(4,3)*v/(1+v*v)],
            [0,s.Rational(4,3)*v/(1+v*v),s.Rational(4,3)/(1+v*v)]])
G=s.diag(A,0,0)+B*M
B_definition=(1+ss)*k/(2*(1+k)*F)
for i in range(3):
    for j in range(i,3):
        exact("metric_pullback_limit_"+str(i)+str(j),s.limit(pulled[i,j],y,s.oo)-G[i,j].subs(B,B_definition))
exact("metric_determinant",G.det()-A*4*B*B/(3*(1+v*v)**2))
inverse=s.simplify(G.inv())
target_inverse=s.Matrix([[1/A,0,0],[0,(1+v*v)/B,-v*(1+v*v)/B],
                         [0,-v*(1+v*v)/B,(v*v+s.Rational(3,4))*(1+v*v)/B]])
check("inverse_metric_full_matrix",s.simplify(inverse-target_inverse)==s.zeros(3),"symbolic")
partials=[G.diff(A)*Au+G.diff(B)*Bu,s.zeros(3),G.diff(v)]
Gamma=[[[s.factor(sum(inverse[i,l]*(partials[j][l,h]+partials[h][l,j]-partials[l][j,h])
                      for l in range(3))/2) for h in range(3)] for j in range(3)] for i in range(3)]
exact("normal_connection_ll",Gamma[2][1][1]+v*(4*v*v+3)/(12*(1+v*v)))
exact("normal_connection_lv",Gamma[2][1][2]+v*v/(3*(1+v*v)))
exact("normal_connection_vv",Gamma[2][2][2]+7*v/(3*(1+v*v)))
exact("normal_connection_ul_zero",Gamma[2][0][1])
exact("normal_connection_uv",Gamma[2][0][2]-Bu/(2*B))

# Physical potential gradients are supplied independently in u,ell,v coordinates.
p,qq,w,C,ab,rx,ry,lx,ly=s.symbols("p q w C alpha_B rx ry lambda_x lambda_y",real=True)
X=rx*v*v/2;W=X+ry
gradient=s.Matrix([-lx*X-ly*ry,2*W,rx*v])
velocity=s.Matrix([p,qq,w])
T=s.factor((velocity.T*G*velocity)[0])
Hbar=s.factor(2*(C*C+W)/(3-T))
h=-T-4*C*C/(3*Hbar)
raised=inverse*gradient
acceleration=s.Matrix([- (3+h)*velocity[i]
    -sum(Gamma[i][j][l]*velocity[j]*velocity[l] for j in range(3) for l in range(3))
    -raised[i]/Hbar for i in range(3)])
flow=s.Matrix([p,qq+2+2*ab*p,acceleration[0],acceleration[1],w,acceleration[2]])
reflection={v:-v,w:-w}
for i in range(6):
    parity=1 if i<4 else -1
    exact("reflection_flow_"+str(i),flow[i].subs(reflection,simultaneous=True)-parity*flow[i])
for i in [4,5]:
    exact("normal_invariant_plane_"+str(i),flow[i].subs({v:0,w:0}))
for i in range(4):
    for normal in [v,w]:
        exact("even_normal_Jacobian_"+str(i)+"_"+str(normal),s.diff(flow[i],normal).subs({v:0,w:0}))
exact("squared_radiation_clock_term",flow[1]-(qq+2+2*ab*p))

B0=k/(2*(1+k));base={p:0,qq:-2,w:0,v:0,C:1,rx:k,ry:k/3,B:B0,Bu:-ly*B0/2}
for i in range(6):
    exact("radiation_point_flow_"+str(i),flow[i].subs(base))
exact("radiation_Hbar",Hbar.subs(base)-2*(1+k)/3)
exact("radiation_h",h.subs(base)+2)
for expr,label in [(T,"T"),(W,"W"),(Hbar,"Hbar"),(h,"h")]:
    for normal in [v,w]:
        exact(label+"_zero_linear_normal_change_"+str(normal),s.diff(expr,normal).subs(base))
normal_matrix=s.simplify(s.Matrix([flow[4],flow[5]]).jacobian([v,w]).subs(base))
check("normal_block_exact_all_k",normal_matrix==s.Matrix([[0,1],[s.Rational(3,4),-1]]),"symbolic",str(normal_matrix))
lam=s.symbols("lambda")
char=s.factor(normal_matrix.charpoly(lam).as_expr())
exact("normal_polynomial",char-(lam*lam+lam-s.Rational(3,4)))
for root in [s.Rational(1,2),s.Rational(-3,2)]:
    exact("normal_root_"+str(root),char.subs(lam,root))
exact("normal_potential_mixed_contribution",raised[2].subs({rx:k,ry:k/3})-k*v*(1+v*v)/(12*B))

# Independent original-coordinate linear equation and exponent conversion.
H0=2*(1+k)/3;Kxx_times_y2=2*k/(3*(1+k))
friction=3-2-2*(-2)
mass=s.Rational(3,4)*(-2)**2+k/(Kxx_times_y2*H0)
exact("original_x_friction",friction-5)
exact("original_x_mass",mass-s.Rational(21,4))
exponent=s.symbols("r")
xpoly=exponent**2+friction*exponent+mass
exact("original_x_polynomial_factor",xpoly-(exponent+s.Rational(3,2))*(exponent+s.Rational(7,2)))
exact("ratio_exponent_shift",xpoly.subs(exponent,lam-2)-char)

# A second route retains the complete action at finite y, at u=z=p=0 and q=-2.
delta=s.symbols("delta",nonnegative=True) # delta=1/y^2
dn=delta+d*(1+v*v)
kx=4*k/(9*dn);ky=k/(3*dn)
xp=w-2*v;yp=s.Integer(-2)
t_full=kx*xp*xp+ky*yp*yp
potential_scaled=s.Rational(3,2)*delta+k*v*v/2+k/3
hb_full=2*(1+potential_scaled)/(3-t_full)
h_full=-t_full-4/(3*hb_full)
gx=(-d*v*xp*xp-2*d*xp*yp+s.Rational(3,4)*d*v*yp*yp)/dn
gy=(s.Rational(4,3)*d*xp*xp-2*d*v*xp*yp-d*yp*yp)/dn
xacc=-(3+h_full)*xp-gx-k*v/(kx*hb_full)
yacc=-(3+h_full)*yp-gy-(2*k/3)/(ky*hb_full)
full_vacc=s.cancel(xacc-v*yacc-2*yp*w)
limit_vacc=s.factor(flow[5].subs({p:0,qq:-2,C:1,rx:k,ry:k/3,B:B0}))
exact("full_action_finite_y_limit_matches_transformed_flow",full_vacc.subs(delta,0)-limit_vacc)
exact("full_action_limit_original_metric_T",t_full.subs(delta,0)-T.subs({p:0,qq:-2,B:B0}))

ks=[s.Rational(1,23),s.Rational(2,11),s.Rational(7,25),s.Rational(4,13)]
slopes=[s.Rational(2,3),s.Rational(-5,4)]
amplitudes=[Q(1,20),Q(1,40),Q(1,80),Q(-1,20),Q(-1,40),Q(-1,80)]
eps=s.symbols("epsilon",real=True)
for kk in ks:
    for slope in slopes:
        nonlinear=s.cancel(limit_vacc.subs({k:kk,v:eps,w:slope*eps}))
        remainder=s.cancel(nonlinear-(s.Rational(3,4)-slope)*eps)
        cubic=s.cancel(remainder/eps**3)
        lo,hi=rational_interval(cubic,eps,Q(-1,20),Q(1,20))
        bound=max(abs(lo),abs(hi))
        t_path=t_full.subs({delta:0,k:kk,v:eps,w:slope*eps})
        tl,tu=rational_interval(t_path,eps,Q(-1,20),Q(1,20))
        check("normal_compact_positive_chart_"+str(kk)+"_"+str(slope),0<=tl and tu<3,"rational_certificate")
        values=[]
        for amplitude in amplitudes:
            actual=q(remainder.subs(eps,sym(amplitude)))
            check("normal_cubic_remainder_"+str(kk)+"_"+str(slope)+"_"+str(amplitude),
                  abs(actual)<=bound*abs(amplitude)**3,"rational_certificate")
            values.append({"v":str(amplitude),"w_over_v":str(slope),"exact_remainder":show(actual)})
        certificates.append({"kind":"normal_cubic_remainder","k":str(kk),"slope":str(slope),
            "interval":["-1/20","1/20"],"remainder_over_v_cubed":str(cubic),
            "rational_interval":[str(lo),str(hi)],"T_interval":[str(tl),str(tu)],"bound":show(bound),"values":values})

points=[(s.Rational(1,10),s.Rational(1,13)),(s.Rational(-2,15),s.Rational(3,17)),
        (s.Rational(3,20),s.Rational(-1,11)),(s.Rational(-1,7),s.Rational(-2,19))]
for kk,(vv,ww) in zip(ks,points):
    expr=s.cancel(full_vacc.subs({k:kk,v:vv,w:ww}))
    limit=q(expr.subs(delta,0))
    derivative=s.diff(expr,delta)
    dl,du=rational_interval(derivative,delta,Q(0),Q(1,25))
    bound=max(abs(dl),abs(du))
    tl,tu=rational_interval(t_full.subs({k:kk,v:vv,w:ww}),delta,Q(0),Q(1,25))
    check("finite_y_compact_positive_chart_"+str(kk),0<=tl and tu<3,"rational_certificate")
    values=[]
    for yy in [5,11,23,47]:
        actual=q(expr.subs(delta,s.Rational(1,yy*yy)))
        error=actual-limit
        check("finite_y_action_remainder_"+str(kk)+"_"+str(yy),abs(error)<=bound/Q(yy*yy),"rational_certificate")
        values.append({"y":yy,"v_acceleration":show(actual),"limiting_acceleration":show(limit),"error":show(error),"rigorous_error_bound":show(bound/Q(yy*yy))})
    certificates.append({"kind":"finite_y_action_acceleration","k":str(kk),"v":str(vv),"w":str(ww),
        "delta_interval":["0","1/25"],"v_acceleration_rational":str(expr),
        "derivative_interval":[str(dl),str(du)],"T_interval":[str(tl),str(tu)],"bound_constant":show(bound),"values":values})

# Actual damaged equations and scope controls, evaluated independently.
bad_x_poly=exponent**2+exponent+s.Rational(21,4)
check("damage_omit_original_mixed_connection",s.factor(bad_x_poly.subs(exponent,lam-2)-char)!=0
      and bad_x_poly.subs(exponent,s.Rational(-3,2))!=0,"negative_control",str(s.factor(bad_x_poly.subs(exponent,lam-2))))
bad_no_mixed_potential=lam*lam+lam+s.Rational(5,4)
check("damage_omit_mixed_raised_potential",bad_no_mixed_potential.subs(lam,s.Rational(1,2))!=0
      and s.discriminant(bad_no_mixed_potential,lam)<0,"negative_control",str(bad_no_mixed_potential))
bad_no_connection=lam*lam+lam+s.Rational(1,4)
check("damage_omit_transformed_connection",bad_no_connection.subs(lam,s.Rational(1,2))!=0
      and s.factor(bad_no_connection)==(lam+s.Rational(1,2))**2,"negative_control",str(bad_no_connection))
check("inverse_ratio_is_not_smooth_at_radiation_plane",s.limit(abs(-1/v**2),v,0,dir="+")==s.oo,
      "negative_control","d(y/x)/dv=-1/v^2 diverges; y/x is not a finite local chart at v=0.")
duration=2*s.log(3)
absolute_x_factor=s.simplify(s.exp(-s.Rational(3,2)*duration))
relative_energy_factor=s.simplify(s.exp(duration))
check("absolute_decay_does_not_imply_relative_attraction",absolute_x_factor==s.Rational(1,27)
      and relative_energy_factor==9,"scope_control",{"DeltaN":str(duration),"x_factor":str(absolute_x_factor),"potential_ratio_factor":str(relative_energy_factor)})
for kk in ks:
    vv=s.Rational(1,20);ww=-s.Rational(3,2)*vv
    residual=s.factor(limit_vacc.subs({k:kk,v:vv,w:ww})+s.Rational(3,2)*ww)
    check("stable_tangent_line_is_not_nonlinear_solution_"+str(kk),residual!=0,"scope_control",str(residual))

categories=sorted({row["category"] for row in checks})
counts={name:{"passed":sum(row["pass"] for row in checks if row["category"]==name),
              "failed":sum(not row["pass"] for row in checks if row["category"]==name)} for name in categories}
certificate_bytes=(json.dumps(certificates,indent=2)+"\n").encode()
with (OUT/"CONTROL_CERTIFICATES_v1.json").open("xb") as stream:stream.write(certificate_bytes)
result={"scope":"New independent transverse action/geometry check; no producer code/results or invariant-plane spectrum rerun.",
    "checks":checks,"counts":{"passed":sum(row["pass"] for row in checks),"failed":sum(not row["pass"] for row in checks)},
    "counts_by_category":counts,"normal_block":str(normal_matrix),"normal_polynomial":str(char),
    "normal_flow_at_even_point":str(limit_vacc),"finite_y_full_action_flow":str(full_vacc),
    "certificate_sha256":hashlib.sha256(certificate_bytes).hexdigest(),"certificate_bytes":len(certificate_bytes),
    "certificate_count":len(certificates),"interval_subdivisions":32,
    "hand_derivation_sha256":hashlib.sha256((OUT/"HAND_DERIVATION_v1.txt").read_bytes()).hexdigest(),
    "protocol_sha256":hashlib.sha256((OUT/"PROTOCOL_v1.json").read_bytes()).hexdigest(),
    "producer_code_or_results_read":False}
print(json.dumps(result,indent=2))
sys.exit(any(not row["pass"] for row in checks))
