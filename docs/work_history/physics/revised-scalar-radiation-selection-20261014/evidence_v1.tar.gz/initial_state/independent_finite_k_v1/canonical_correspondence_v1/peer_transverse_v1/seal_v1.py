#!/usr/bin/env python3
"""Seal a focused transverse check, preserving the failed original execution."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys
import sympy

BASE=Path(__file__).resolve().parent

def binding(path):
    raw=path.read_bytes()
    return {"path":str(path.relative_to(BASE)),"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()}

def write_new(path,value):
    with path.open("x") as stream:
        stream.write(json.dumps(value,indent=2)+"\n")

sources=json.loads((BASE/"SOURCE_MANIFEST_v1.json").read_text())["source_files"]
for row in sources:
    live=Path(row["source_path"]).read_bytes()
    saved=(BASE/row["snapshot_path"]).read_bytes()
    assert live==saved and hashlib.sha256(live).hexdigest()==row["sha256"] and len(live)==row["bytes"]
original=json.loads((BASE/"RUN_01.stdout.json").read_text())
repair=json.loads((BASE/"RUN_02_REPAIR.stdout.json").read_text())
assert original["counts"]=={"passed":144,"failed":1}
assert repair["counts"]=={"passed":3,"failed":0}
failed=[row for row in original["checks"] if not row["pass"]]
assert len(failed)==1 and failed[0]["name"]=="damage_omit_transformed_connection"
assert binding(BASE/"CONTROL_CERTIFICATES_v1.json")["sha256"]==original["certificate_sha256"]
assert binding(BASE/"HAND_DERIVATION_v1.txt")["sha256"]==original["hand_derivation_sha256"]
assert binding(BASE/"PROTOCOL_v1.json")["sha256"]==original["protocol_sha256"]
runs=[]
for prefix,script,exit_code in [("RUN_01","independent_check_v1.py",1),("RUN_02_REPAIR","check_damage_repair_v2.py",0)]:
    metadata=json.loads((BASE/(prefix+".json")).read_text())
    assert metadata["exit_code"]==exit_code
    assert binding(BASE/script)["sha256"]==metadata["script_sha256"]
    for suffix,key in [(".stdout.json","stdout_sha256"),(".stderr.txt","stderr_sha256")]:
        assert binding(BASE/(prefix+suffix))["sha256"]==metadata[key]
    runs.append({"metadata":binding(BASE/(prefix+".json")),"script":binding(BASE/script),
                 "stdout":binding(BASE/(prefix+".stdout.json")),"stderr":binding(BASE/(prefix+".stderr.txt")),
                 "actual_exit_code":exit_code})
now=datetime.now(timezone.utc).isoformat()
receipt={
    "kind":"focused_independent_mathematical_receipt",
    "sealed_utc":now,
    "checker":"/root/local_response_check",
    "direct_author":"/root",
    "source_files":sources,
    "report":binding(BASE/"REPORT_v1.txt"),
    "hand_derivation_before_computation":binding(BASE/"HAND_DERIVATION_v1.txt"),
    "frozen_protocol":binding(BASE/"PROTOCOL_v1.json"),
    "exact_control_certificates":binding(BASE/"CONTROL_CERTIFICATES_v1.json"),
    "actual_runs":runs,
    "original_counts":original["counts"],
    "original_counts_by_category":original["counts_by_category"],
    "repair_counts":repair["counts"],
    "run_accounting":"Original run actually exited 1 with 144 successes and one failed structural-equality negative-control assertion. One replacement assertion plus a diagnosis and original-output binding passed in a separate 3/0 run. The 144 successes are reused; there was no fresh clean 145-condition run.",
    "preserved_failure":{
        "identity":"damage_omit_transformed_connection",
        "reason":"SymPy expression-tree equality rejected (2*lambda+1)^2/4 versus (lambda+1/2)^2, although their exact algebraic difference is zero.",
        "repair":"Use exact cancellation for equivalence, retain rejection of +1/2 and verify double damaged root -1/2. No source/model/criterion change; original script and failed output retained.",
        "replacement_control":"damage_omit_transformed_connection_replacement"
    },
    "conclusion":{
        "normal_matrix":"[[0,1],[3/4,-1]]",
        "normal_eigenvalues":["1/2","-3/2"],
        "absolute_x_exponents":["-3/2","-7/2"],
        "source_correction_required":False,
        "physical_meaning":"Absolute x decay coexists with growth of x/y and its relative potential/kinetic contribution. Generic attraction to this particular normalized radiation point cannot select x=0.",
        "local_nonlinear_scope":"Five-dimensional local stable manifold and one unstable direction of the limiting six-variable autonomous flow, conditional on the supplied four stable even eigenvalues. Invariant x=x'=0 plane is a subset; stable tangent cancellation is not a full nonlinear manifold equation."
    },
    "reused_input":"The complete supplied finite-k reduction source provides the already checked four stable even eigenvalues. No fresh invariant-plane spectrum or history run was performed.",
    "new_rigorous_controls":"12 rational certificate families: eight bounded normal cubic remainders and four full-action finite-y acceleration remainders, with positive-chart bounds. They are local pointwise controls, not full histories.",
    "scope_limits":[
        "Fixed 0<k<1/3, finite nu, ideal trace-free radiation, bounded u,z and normal neighborhood, large positive y.",
        "No uniform k limit, global basin or probability assignment, full-action future saddle, actual thermal history, matching or empirical exclusion.",
        "Finite-y mean-value error bounds concern specified instantaneous full-action states, not long-time trajectory error.",
        "The parent remains direct author; no formal audit or authority/status promotion."
    ],
    "independence":{
        "producer_transverse_code_or_results_read_imported_or_run":False,
        "new_agents_or_other_chats":False,
        "empirical_data":False,
        "parent_source_model_git_branch_pr_runtime_lock_or_audit_changes":False,
        "write_scope":"initial_state/transverse_radiation/independent_v1 only"
    },
    "environment":{"python":sys.version,"sympy":sympy.__version__},
    "seal_policy":"All listed artifacts are immutable; any later correspondence must use a distinct new subfolder and receipt. MANIFEST_v1.json excludes itself."
}
write_new(BASE/"RECEIPT_v1.json",receipt)
artifacts=[binding(path) for path in sorted(BASE.rglob("*")) if path.is_file() and path.name!="MANIFEST_v1.json"]
write_new(BASE/"MANIFEST_v1.json",{"version":1,"sealed_utc":now,"scope":"Focused transverse-radiation independent check",
    "artifact_count":len(artifacts),"artifacts":artifacts,"excluded":["MANIFEST_v1.json itself"]})
for row in artifacts:
    assert binding(BASE/row["path"])==row
print(json.dumps({"sealed_artifacts":len(artifacts),"source_pairs_verified":len(sources),
    "report":binding(BASE/"REPORT_v1.txt"),"receipt":binding(BASE/"RECEIPT_v1.json"),
    "manifest":binding(BASE/"MANIFEST_v1.json")},indent=2))
