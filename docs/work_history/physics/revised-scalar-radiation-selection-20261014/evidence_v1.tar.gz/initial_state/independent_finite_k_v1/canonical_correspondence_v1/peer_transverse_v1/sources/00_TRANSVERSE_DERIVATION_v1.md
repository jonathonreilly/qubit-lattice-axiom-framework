# Transverse scalar mode of the radiation solution

Direct author /root, 2026-10-14. Candidate derivation frozen before its new
symbolic computation. No empirical data, parameter fit, new selector or
initial state is supplied. The full action is the previously declared one;
this block asks whether x=0 can itself follow from radiation attraction.

Take fixed 0<k<1/3, finite nu>0, exact trace-free radiation, y>0 large,
bounded u,z=log(y/y_b), and now allow v=x/y near zero. Write ell=log y.
The previously supplied kinetic coefficients give, in the large-y limit,

    ds_field^2=A(u)du^2+B(u)/(1+v^2)
      [(4/3)(dv+v d ell)^2+d ell^2],
    A=J/F^2, B=(1+s)k/[2(1+k)F].

The limiting potential divided by y_b^2 is

    W(u,z,v)=exp(2z)[(k/2)v^2 exp(-lambda_x u)
                         +(k/3)exp(-lambda_y u)].

These follow by x=v*y and dx=y(dv+v d ell), not by postulating new action
terms. The limit is local at bounded v,u,z. At v=0, the exact reduced
radiation point is u=z=p=0, q=ell'=-2, v=v'=0,
Hbar=2(1+k)/3 and h=H_E'/H_E=-2. N=log a_E.
Reflection x->-x implies that transverse linear perturbations decouple
from the even (u,z,p,q) block. Scalar stress, W and Hbar have no first-order
transverse change, but the off-diagonal v/ell kinetic term matters.

An ordinary derivation in the original physical field coordinate x avoids
mixing the v-dependent kinetic coefficients prematurely. To linear order in
x at this point,

    K_xx=2k/[3(1+k)y^2],
    Gamma^x_xy=-1/y,
    Gamma^x_yy=(3/4)x/y^2+O(x^3/y^4),
    partial_x U=k x   (u=0).

The background u' is zero. Dividing the x equation by H_E^2 gives

    x''+(3+h-2q)x'+[(3/4)q^2
                    +Hv^2 k/(K_xx H_E^2)]x=0.

At the radiation point the square-bracket potential term is 3+9/4=21/4,
so

    x''+5x'+(21/4)x=0,
    x proportional to exp(-3N/2) or exp(-7N/2).

But the reference radiation field y proportional to exp(-2N). Therefore
v=x/y obeys

    v''+v'-(3/4)v=0,
    lambda_transverse=+1/2, -3/2.

The growing mode in v cannot be dismissed because x itself decays: at
u=0 its x-to-y potential ratio is (3/2)v^2, which grows as exp(N) along
the growing mode. The normal mode eventually leaves the local radiation
solution's neighborhood in normalized field/energy variables.

Together with the previous four strictly stable eigenvalues, the autonomous
six-dimensional ideal large-y system has five stable and one unstable
linear direction. Smoothness implies the fixed point is a hyperbolic saddle.
A local stable manifold has dimension five; convergence inside its local
neighborhood requires lying on that manifold. The exact x=x'=0 invariant
plane is one subset. The calculation neither says it is the entire stable
manifold nor assigns a probability measure to initial data. In particular,
setting the linear growing-mode coefficient to zero is only the tangent
condition, not the full nonlinear stable-manifold equation.

This eliminates the proposed use of generic attraction to this particular
radiation point as a derivation of x=0. It does not eliminate the supplied
action, all possible histories, other large-y fixed points, finite-y effects,
thermal trace-driven evolution, or other initial-state mechanisms. The local
stable four-dimensional restriction and the slow-mode bound remain correct
on their stated invariant plane. No uniform-in-k, global or actual-data claim
is made. The limit is a radiation-era equation reduction, not an arbitrarily
long full-action cosmology.

Planned new checks: reconstruct the field metric by coordinate transformation;
compute its Christoffels at first transverse order; obtain the normal block
from the full constrained six-dimensional flow including the clock term;
verify the +1/2,-3/2 roots for all k; compare exact-rational off-plane examples
and reject deliberately omitted mixed-connection and inverted-ratio formulas.
Independent checking must use this source and the complete action, not the
parent's checker. No evidence or numeric outcome is asserted before execution.
