#!/usr/bin/env python3
"""Seal this correspondence once; --verify performs only byte-identity reads."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[6]
INITIAL = HERE.parents[1]
CAMPAIGN = HERE.parents[2]
EXCLUDED = {"MANIFEST_v1.json", "RECEIPT_v1.json", "RECEIPT_v1.sha256"}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def artifact(path, base=HERE):
    return {"path":str(path.relative_to(base)),"bytes":path.stat().st_size,"sha256":digest(path)}


def validate_rows(base, rows):
    for row in rows:
        p = base / row["path"]
        assert p.stat().st_size == row["bytes"] and digest(p) == row["sha256"], str(p)
    return len(rows)


def prior_records():
    finite_path = HERE.parent / "RECEIPT_v1.json"
    relaxation_base = INITIAL / "independent_relaxation_bound_v1"
    relaxation_path = relaxation_base / "RECEIPT_v1.json"
    peer_base = INITIAL / "transverse_radiation/independent_v1"
    peer_path = peer_base / "RECEIPT_v1.json"
    expected = [(finite_path,"0c07e8051bef08ec85c5cedc916bec70a07ce5d8c2939caf5f8c7c28c6401694"),
                (relaxation_path,"0caee9cb3e59fd6a32095df2ceb5d13b6d3cb64dd487045e532783f192c80d02"),
                (peer_path,"c3e1eae38953f9d84e0f1d83e73c7e1534601d39e1424f095971ff849b44071b")]
    for path, sha in expected:
        assert digest(path) == sha, str(path)
    finite = read(finite_path)
    relaxation = read(relaxation_path)
    relaxation_manifest_path = relaxation_base / relaxation["manifest_path"]
    assert digest(relaxation_manifest_path) == relaxation["manifest_sha256"]
    counts = {
        "finite_k_original":validate_rows(ROOT/finite["artifact_paths_relative_to"],finite["artifacts"]),
        "relaxation_original":validate_rows(relaxation_base,read(relaxation_manifest_path)["artifacts"]),
        "transverse_peer":validate_rows(peer_base,read(peer_base/"MANIFEST_v1.json")["artifacts"]),
    }
    assert counts == {"finite_k_original":20,"relaxation_original":20,"transverse_peer":18}
    return {"artifact_counts":counts,"receipts":[{"path":str(p.relative_to(ROOT)),"sha256":h} for p,h in expected]}


def current_sources():
    camp = str(CAMPAIGN.relative_to(ROOT))
    pairs = [
        ("docs/EXPONENTIAL_SCALAR_RADIATION_SELECTION_BOUNDED_THEOREM_NOTE_2026-10-14.md","source_snapshot/CANONICAL_NOTE_v2.md","final canonical science note"),
        ("scripts/exponential_scalar_radiation_selection_check.py","source_snapshot/CANONICAL_RUNNER_v6.py","final primary source, read for correspondence only"),
        ("logs/runner-cache/exponential_scalar_radiation_selection_check.txt","parent_final_v6/CACHE_v6.txt","completed final primary cache"),
        ("docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md","source_snapshot/FULL_ACTION_NOTE.md","complete supplied action"),
        (camp+"/initial_state/FINITE_K_RADIATION_DERIVATION_v2.md","source_snapshot/FINITE_K_CHECKED_SOURCE_v2.md","previously checked finite-k source"),
        (camp+"/initial_state/CROSS_DOMAIN_RELAXATION_BOUND_v1.md","source_snapshot/RELAXATION_CHECKED_SOURCE_v1.md","previously checked relaxation source"),
        (camp+"/initial_state/transverse_radiation/DERIVATION_v1.md","peer_transverse_v1/sources/00_TRANSVERSE_DERIVATION_v1.md","separately checked transverse source"),
        (camp+"/initial_state/independent_finite_k_v1/RECEIPT_v1.json","source_snapshot/PRIOR_FINITE_K_RECEIPT_v1.json","original immutable independent receipt"),
        (camp+"/initial_state/independent_relaxation_bound_v1/RECEIPT_v1.json","source_snapshot/PRIOR_RELAXATION_RECEIPT_v1.json","original immutable independent receipt"),
        (camp+"/initial_state/transverse_radiation/independent_v1/RECEIPT_v1.json","peer_transverse_v1/RECEIPT_v1.json","separate independent transverse receipt"),
        (camp+"/initial_state/transverse_radiation/independent_v1/REPORT_v1.txt","peer_transverse_v1/REPORT_v1.txt","separate independent transverse report"),
        ("scripts/runner_cache.py","source_snapshot/RUNNER_CACHE_HELPER_v1.py","reference for fingerprint encoding, not new science evidence"),
    ]
    rows=[]
    for original,snapshot,role in pairs:
        live,frozen=ROOT/original,HERE/snapshot
        assert live.read_bytes()==frozen.read_bytes(),original
        rows.append(dict(original_path=original,snapshot_path=snapshot,sha256=digest(frozen),bytes=frozen.stat().st_size,role=role))
    return rows


def verify():
    receipt=read(HERE/"RECEIPT_v1.json")
    manifest=read(HERE/"MANIFEST_v1.json")
    assert digest(HERE/"MANIFEST_v1.json")==receipt["manifest_sha256"]
    assert digest(HERE/"REPORT_v1.md")==receipt["report_sha256"]
    assert (HERE/"RECEIPT_v1.sha256").read_text()==digest(HERE/"RECEIPT_v1.json")+"  RECEIPT_v1.json\n"
    count=validate_rows(HERE,manifest["artifacts"])
    assert count==manifest["artifact_count"]==receipt["artifact_count"]
    actual={str(p.relative_to(HERE)) for p in HERE.rglob("*") if p.is_file() and str(p.relative_to(HERE)) not in EXCLUDED}
    assert actual=={r["path"] for r in manifest["artifacts"]}
    assert current_sources()==receipt["current_sources"]
    assert prior_records()==receipt["reused_sealed_records"]
    return dict(verified=True,artifact_count=count,current_source_pairs=len(receipt["current_sources"]),
                prior_artifact_counts=receipt["reused_sealed_records"]["artifact_counts"],
                receipt_sha256=digest(HERE/"RECEIPT_v1.json"),manifest_sha256=digest(HERE/"MANIFEST_v1.json"),
                report_sha256=digest(HERE/"REPORT_v1.md"))


if "--verify" in sys.argv:
    print(json.dumps(verify(),indent=2))
    raise SystemExit(0)

sources=current_sources()
prior=prior_records()
now=dt.datetime.now(dt.timezone.utc).isoformat()
lineage=read(HERE/"results/completed_lineage_run02.json")
delivery5=read(HERE/"results/final_delivery_run01.json")
delivery6=read(HERE/"results/final_delivery_run02.json")
assert lineage["counts"]=={"passed":21,"failed":0}
assert delivery5["counts"]=={"passed":45,"failed":0}
assert delivery6["counts"]=={"passed":61,"failed":0}
artifacts=[artifact(p) for p in sorted(HERE.rglob("*")) if p.is_file() and str(p.relative_to(HERE)) not in EXCLUDED]
manifest=dict(schema="canonical_correspondence_manifest_v1",created_utc=now,artifact_count=len(artifacts),
              excluded_self_and_receipt_files=sorted(EXCLUDED),artifacts=artifacts)
with (HERE/"MANIFEST_v1.json").open("x") as f:
    json.dump(manifest,f,indent=2);f.write("\n")
receipt=dict(
    schema="focused_canonical_correspondence_receipt_v1",created_utc=now,checker="/root/scalar_energy_check",
    scientific_author="/root",formal_audit=False,
    scope="Canonical source/action/claim correspondence, completed primary cache and actual-damage evidence; reuse prior independent mathematics and the separate transverse receipt without rerun.",
    outcome="Final bounded source corresponds to checked results. One intermediate actual-flow binding gap was identified and repaired; no outstanding source-equation correction in this scope.",
    current_sources=sources,reused_sealed_records=prior,
    initial_canonical_note_sha256="af45e8a725fc8e00f088bb41c0baab8af30cd44c795044388b58412f55264cb8",
    final_canonical_note_sha256=sources[0]["sha256"],final_runner_sha256=sources[1]["sha256"],final_cache_sha256=sources[2]["sha256"],
    final_primary=dict(version=6,passed=117,failed=0,exit_code=0,elapsed_seconds=1.6406099796295166,declared_timeout_seconds=120,
                       declared_input_fingerprint=delivery6["cache_header"]["input_fingerprint_sha256"]),
    actual_final_damaged_copies=dict(count=9,all_detected=True,protocol_path="parent_final_v6/mutations_v3/PROTOCOL_v3.json",results_path="parent_final_v6/mutations_v3/RESULTS_v3.json"),
    new_correspondence_controls=dict(completed_lineage=lineage["counts"],intermediate_v5_delivery=delivery5["counts"],final_v6_delivery_and_peer=delivery6["counts"]),
    issue=dict(identity="unbound_generic_lowered_checks_in_v2_to_v4",author_repair="v5 actual u and ell flow bindings",actual_regression="p**3 drift fails only actual_u_matches_lowered_solution",resolved=True),
    preserved_failures=[
        "Primary v1 SIGTERM after 189.502394 s; declared 120 s budget exceeded; 35 s diagnostic stopped at expanded lowered_u.",
        "Primary v2 actually 84/1 and exit 1; stored radical residual is zero on the stated positive domain; v3 normalization retained all targets.",
        "This correspondence reader v1 actually failed parsing serialized symbol lambda; token-only reader v2 repair, full original stderr preserved.",
        "Read-only REPORT_v1.md lookup failed; correct peer report REPORT_v1.txt read and hashed.",
        "Peer transverse original 144/1 with one structural-equality negative-control failure; separate 3/0 narrow repair, no new clean 145-condition run claimed.",
    ],
    science_rerun=False,producer_runner_imported_or_executed=False,primary_source_read_for_delivery=True,
    peer_science_rederived_or_rerun=False,empirical_data_or_inherited_histories_accessed=False,
    alternative_radiation_material_accessed=False,parent_source_git_pr_runtime_lock_audit_or_prior_receipts_modified=False,
    claim_limits=["Fixed-k ideal trace-free large-y limiting system and local chart; supplied action and parameters.",
                  "Four-dimensional attraction and exact slow-component rate bound on the invariant x plane.",
                  "Transverse saddle is a local result of the six-variable limiting flow; no full-action future or generic history exclusion.",
                  "No uniform nonlinear basin, full history, empirical likelihood, initial-state measure or observational selection."],
    write_scope=str(HERE.relative_to(ROOT)),report_path="REPORT_v1.md",report_sha256=digest(HERE/"REPORT_v1.md"),
    manifest_path="MANIFEST_v1.json",manifest_sha256=digest(HERE/"MANIFEST_v1.json"),artifact_count=len(artifacts),
    seal_policy="Append future work only in a distinct folder/receipt. This receipt and its hash file are excluded from their own artifact manifest; the receipt binds the manifest. --verify performs reads only.")
with (HERE/"RECEIPT_v1.json").open("x") as f:
    json.dump(receipt,f,indent=2);f.write("\n")
with (HERE/"RECEIPT_v1.sha256").open("x") as f:
    f.write(digest(HERE/"RECEIPT_v1.json")+"  RECEIPT_v1.json\n")
print(json.dumps(verify(),indent=2))
