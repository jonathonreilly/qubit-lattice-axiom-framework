# Independent relaxation-bound extension check

The all-k inequality is correct: within the already checked ideal radiation
reduction, 0<-lambda_s<k for every 0<k<1/3. An actually applicable bound
0<k<=b<1/3 therefore gives tau>1/b and a nonzero linear slow-mode amplitude
ratio greater than exp(-b DeltaN) for DeltaN>0. No source correction is
requested. These are Einstein e-fold, single-mode, conditional statements;
they establish neither a physical coupling bound nor a full-history or
nonlinear relaxation bound.

/root remains scientific author; /root/scalar_energy_check performed this
small focused extension check. No producer code/output, empirical data,
cosmological trajectory, git/PR/runtime/lock/audit change or subagent was
used. No formal audit disposition is assigned.

## Independent proof and exact scope

I read the full extension and finite-k radiation v2 note. The action-to-flow
and Jacobian review already sealed in the prior finite-k receipt is reused,
not repeated. The exact quartic and its previously checked spectrum are
the imported mathematical hypotheses. They apply to fixed k, ideal trace-free
large-positive-y radiation at bounded u,z, x=x'=0, and the local reduced
fixed point. They are not the equations of an entire thermal history.

Independent substitution verifies

    P(-k)=-k^2 L(k)/[(1+k)(1-3k)^2].

The supplied L polynomial is exact. Its claimed bound L>746/27 follows by
expressing L-746/27 as the sum of 43k,14k^3,15k^4,
66(1/9-k^2) and 9(1/243-k^5), all strictly positive on this interval.
A distinct decomposition even gives L>35; the looser source bound is valid
and sufficient. The denominator is positive, hence P(-k)<0<P(0).

As an alternative root proof, the intermediate-value theorem places a root
in (-k,0), contained in (-1/2,0). The checked factorization gives exactly
one real root in (-1/2,0), the slow root, so -k<lambda_s<0. The author's
factor route is also correct: the large factor at -k exceeds 187/12, making
the small factor negative, and t-t^2 is strictly increasing on (0,1/2).
No truncated small-k expansion is used in either argument.

For a nonzero slow coefficient a_s the linear ratio is exactly
|a_s(N+DeltaN)|/|a_s(N)|=exp(lambda_s DeltaN). Thus

    tau>1/k>=1/b,
    exp(lambda_s DeltaN)>exp(-k DeltaN)>=exp(-b DeltaN).

The strict conclusions hold also at k=b. The source's b=1/79999 is an
already exposed development proxy only. It is not an independently
applicable experimental limit, new extraction or confidence interval.
Conditionally inserting it with the preassigned DeltaN=24 gives tau>79999
and retention greater than exp(-24/79999), approximately
0.999700041246578314. Exact rational alternating-series bounds on that
exponential are preserved; the decimal is a display, not empirical evidence.

The argument does not identify N with physical time or a general Jordan
e-fold interval, derive DeltaN, fix the initial slow amplitude or give a
time to an observational tolerance. Its pure linear eigenmode is not a
numerical cosmology or a nonlinear stability-rate bound. Zero slow projection
is allowed. Thermal/mass transitions, finite-y corrections, nonlinear
excursions and other possible attractors remain outside the conclusion.

## Scope controls and computed evidence

The complete action supplies g(u)=a/J and g(0)=k. A pointwise algebraic
control with k=1/10, E=106360/7 gives g=1/100000<1/79999<k. It therefore
rejects the substitution of an unrelated non-vacuum g bound for a k bound.
This is a finite positive-chart coupling example, not a constructed
stationary or experimentally realized environment. Establishing a physical
k constraint still requires the actual environmental, source, range and
readout bridge, as the source states.

A pure fast real eigenmode supplies the other scope control. Its eigenvalue
is <-1/2<-b, so its norm ratio is smaller than exp(-b DeltaN); its slow
projection is zero. This rejects extending the slow-component retention
bound to every linear perturbation or total-state norm. It does not
contradict the stated conditional single-mode claim.

Exact rational Sturm counts and 100-step bisections were independently run
at k=1/1000000,1/79999,1/137,1/10,2/9 and 1/3-1/1000000. Every case has
the same unique slow root in both (-k,0) and (-1/2,0), and one fast real
root in (-1,-1/2). Every stored
slow-root bracket has exact opposite polynomial endpoint signs, lies
strictly inside (-k,0), and yields a tau bracket above 1/k. Examples:

| k | Slow eigenvalue (display) | tau (display) | 1/k |
|---|---:|---:|---:|
| 1/1000000 | -9.99997812493211e-7 | 1000002.18751157 | 1000000 |
| 1/79999 | -1.24998144332728e-5 | 80001.18764469 | 79999 |
| 1/10 | -.0720488740496363 | 13.8794674197 | 10 |
| 2/9 | -.0679096611759565 | 14.7254452855 | 4.5 |
| 1/3-1/1000000 | -7.49999249996250e-7 | 1333334.66667467 | about 3.000009 |

The all-k theorem follows from the proof, not from this finite list. The
script's 25 top-level compound checks passed; six case checks each contain
eight explicit subchecks, without counting them again as independent proofs.
Four damage controls reject the wrong factorization sign, declaring -k the
exact root, the non-vacuum coupling substitution and universal state-norm
retention. All exact fractions and residuals are in the full JSON output.

One initial execution failed at JSON serialization because SymPy root counts
were symbolic integers. Its original script and complete traceback are
preserved, and no failed-run JSON was backfilled. The separate v2 script
converts only the three recorded counts to native integers and selects a
new result path. No equation, input, bound or check changed. It exits 0 with
all 25 checks passing. The script diff and failure diagnosis are preserved.

## Hash-bound inputs

| Input | SHA-256 |
|---|---|
| Cross-domain extension v1 | `a7cd2f5c3a2fbf836f222c5a98a52dae7df969801eadffa171cdffcfc74bafd5` |
| Finite-k radiation derivation v2 | `88d7f4300dfb710818ac7c0da070b9710ee2f993f2dbb7392367347d3b54b664` |
| Complete canonical action | `39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000` |
| Reused original finite-k independent receipt | `0c07e8051bef08ec85c5cedc916bec70a07ce5d8c2939caf5f8c7c28c6401694` |

The current receipt binds source snapshots, hand derivation/protocol,
original and corrected independent programs, actual stdout/stderr, exact
results, failure records and this report. Prior evidence remains unchanged.
The earlier receipt is identity-bound here; its entire prior computation
pack was not rerun or newly audited as part of this extension.
