#!/usr/bin/env python3
"""Direct full-action lowered-momentum limit versus independently derived flow."""
import hashlib
import json
from pathlib import Path
import mpmath as mp


def main():
    mp.mp.dps=80
    out=Path(__file__).resolve().parent
    target=out/'results/large_y_run01.json'
    if target.exists():raise RuntimeError('Preserving an existing result')
    def constants(k):
        a=(1-k)*(1+3*k)/4
        return a,mp.sqrt(a),(1+k)/(k*(1-3*k))

    def full_action(u,ell,k,nu):
        a,alpha,s=constants(k)
        y=mp.exp(ell);E=mp.exp(2*alpha*u);F=1+s*E
        J=1+(1-3*a)*s*E
        D=1+2*(1+k)*y*y/3
        K=[J/F**2,(1+s)*k*y*y/(3*F*D)]
        ly=(1+k)/alpha
        U=mp.mpf('1.5')+3*s*mp.expm1(2*alpha*u)**2/(2*F**2)+k*y*y*mp.exp(-ly*u)/3+nu*(1+s)*u*u/(2*F**2)
        return K,U,(1+s)*E/F,alpha/F

    def full_flow(k,nu,u,z,p,q,yb):
        ell=mp.log(yb)+z
        K,U,C,ab=full_action(u,ell,k,nu)
        coordinates=[u,ell]; velocity=[p,q]
        dK=[[mp.diff(lambda w,j=j,i=i:full_action(*(coordinates[:j]+[w]+coordinates[j+1:]),k,nu)[0][i],coordinates[j]) for j in range(2)] for i in range(2)]
        dU=[mp.diff(lambda w,j=j:full_action(*(coordinates[:j]+[w]+coordinates[j+1:]),k,nu)[1],coordinates[j]) for j in range(2)]
        T=sum(K[i]*velocity[i]**2 for i in range(2))
        sigma=C*C*yb*yb
        H2=2*(U+sigma)/(3-T)
        h=-T-4*sigma/(3*H2)
        # d_N(K_i H velocity_i) from the full action's momentum equation;
        # solve for each contravariant N acceleration.
        acceleration=[]
        for i in range(2):
            metric_work=sum(dK[j][i]*velocity[j]**2 for j in range(2))/2
            metric_time_derivative=sum(dK[i][j]*velocity[j] for j in range(2))
            acceleration.append(-(3+h)*velocity[i]+metric_work/K[i]-metric_time_derivative*velocity[i]/K[i]-dU[i]/(K[i]*H2))
        return [p,q+2+2*ab*p,*acceleration],T

    def reduced(k,u,z,p,q):
        a,alpha,s=constants(k)
        def geometry(uu):
            E=mp.exp(2*alpha*uu);F=1+s*E
            return (1+(1-3*a)*s*E)/F**2,(1+s)*k/(2*(1+k)*F),(1+s)*E/F,alpha/F
        A,B,C,ab=geometry(u)
        Au=mp.diff(lambda uu:geometry(uu)[0],u)
        Bu=mp.diff(lambda uu:geometry(uu)[1],u)
        ly=(1+k)/alpha;W=k*mp.exp(2*z-ly*u)/3
        T=A*p*p+B*q*q;Hbar=2*(C*C+W)/(3-T)
        h=-T-4*C*C/(3*Hbar)
        return [p,q+2+2*ab*p,-(3+h)*p-Au*p*p/(2*A)+Bu*q*q/(2*A)+ly*W/(A*Hbar),-(3+h)*q-Bu*p*q/B-2*W/(B*Hbar)],T

    cases=[];failures=[]
    # Frozen before evaluation: fixed compact off-orbit states, four finite k,
    # and fixed nu (including a large nu, which still decouples in this limit).
    for ks in ['1e-5','.01','.1','.32']:
        for ns,st in [('1',['-.4','.1','.07','-1.8']),('100',['.35','-.15','-.12','-2.1'])]:
            k,nu=mp.mpf(ks),mp.mpf(ns);u,z,p,q=map(mp.mpf,st)
            reduced_value,Tr=reduced(k,u,z,p,q)
            rows=[]
            for ybs in ['100','10000','1000000']:
                yb=mp.mpf(ybs)
                exact,Tf=full_flow(k,nu,u,z,p,q,yb)
                errors=[abs(v-w) for v,w in zip(exact,reduced_value)]
                maximum=max(errors)
                rows.append({'yb':ybs,'full_flow':list(map(str,exact)),'component_errors':list(map(str,errors)),'max_error':str(maximum),'yb_squared_times_max_error':str(yb*yb*maximum),'full_T':str(Tf)})
            observed=[mp.mpf(row['max_error']) for row in rows]
            # At least quadratic error reduction under each 100-fold yb
            # increase, with 10% tolerance for pre-asymptotic corrections.
            checks={'reduced_chart':Tr<3,'full_chart':all(mp.mpf(row['full_T'])<3 for row in rows),
                    'clock_exact_at_all_yb':all(mp.mpf(row['component_errors'][1])==0 for row in rows),
                    'at_least_inverse_square_error':all(observed[i+1]<=observed[i]/9000 for i in range(2))}
            if not all(checks.values()):failures.append({'k':ks,'nu':ns,'failed':[key for key,value in checks.items() if not value]})
            cases.append({'k':ks,'nu':ns,'state_u_z_p_q':st,'reduced_flow':list(map(str,reduced_value)),'reduced_T':str(Tr),'rows':rows,'checks':checks})
    result={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mp_dps':mp.mp.dps,
      'scope':'Eight off-orbit full-action coefficient/force limits; not trajectories or observed-history tests.',
      'method':'Full action differentiated at fixed physical ell, then direct lowered-momentum acceleration; compare with reduced contravariant equations.',
      'cases':cases,'failures':failures,'status':'completed_no_check_failures' if not failures else 'completed_with_failures'}
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'case_count':len(cases),'failures':failures,'limits':[{'k':case['k'],'nu':case['nu'],'errors':[r['max_error'] for r in case['rows']]} for case in cases]},indent=2))
    if failures:raise SystemExit(1)


if __name__=='__main__':main()
