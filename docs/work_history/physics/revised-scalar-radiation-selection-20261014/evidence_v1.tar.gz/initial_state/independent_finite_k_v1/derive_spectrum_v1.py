#!/usr/bin/env python3
"""Derive reduced flow/Jacobian in t=2alpha*u coordinates from the action."""
import hashlib
import json
from pathlib import Path
import sympy as sp
import mpmath as mp


def main():
    out=Path(__file__).resolve().parent
    target=out/'results/spectrum_run01.json'
    if target.exists():raise RuntimeError('Preserving existing result; use a fresh version')
    k=sp.symbols('k',positive=True)
    t,z,r,q=sp.symbols('t z r q',real=True)
    a=(1-k)*(1+3*k)/4
    s=(1+k)/(k*(1-3*k))
    E=sp.exp(t);F=1+s*E;J=1+(1-3*a)*s*E
    # Transform the full action's u metric by du=dt/(2alpha).
    A=J/(4*a*F**2)
    B=(1+s)*k/(2*(1+k)*F)
    C=(1+s)*E/F
    L=(1+k)/(2*a)
    Y,Yb=sp.symbols('Y Yb',positive=True)
    U_rad=k*Y**2*sp.exp(-L*t)/3
    # Differentiate at fixed physical Y, then change to relative z.
    W=sp.simplify((U_rad/Yb**2).subs(Y,Yb*sp.exp(z)))
    U_t_over_yb2=sp.simplify((sp.diff(U_rad,t)/Yb**2).subs(Y,Yb*sp.exp(z)))
    U_ell_over_yb2=sp.simplify((Y*sp.diff(U_rad,Y)/Yb**2).subs(Y,Yb*sp.exp(z)))
    T=A*r*r+B*q*q
    Hbar=2*(C*C+W)/(3-T)
    h=-T-4*C*C/(3*Hbar)
    flow=sp.Matrix([
        r,
        q+2+r/F,
        -(3+h)*r-sp.diff(A,t)*r*r/(2*A)+sp.diff(B,t)*q*q/(2*A)-U_t_over_yb2/(A*Hbar),
        -(3+h)*q-sp.diff(B,t)*r*q/B-U_ell_over_yb2/(B*Hbar)
    ])
    point={t:0,z:0,r:0,q:-2}
    residual=[sp.factor(v.subs(point)) for v in flow]
    matrix=flow.jacobian([t,z,r,q]).subs(point).applyfunc(sp.factor)
    lam=sp.symbols('lambda')
    polynomial=sp.factor(matrix.charpoly(lam).as_expr())
    D=(1+k)*(1-3*k)**2
    n=-3*k**3+10*k*k+k+4
    S=4*n/D;P=16*k/((1+k)*(1-3*k))
    expected=(lam*lam+lam)**2+S*(lam*lam+lam)+P
    polynomial_difference=sp.factor(polynomial-expected)
    c1,c2,c3=sp.symbols('c1 c2 c3')
    expansion=c1*k+c2*k*k+c3*k**3
    series=sp.series(polynomial.subs(lam,expansion),k,0,4).removeO().expand()
    solved={}
    for power,unknown in [(1,c1),(2,c2),(3,c3)]:
        coefficient=sp.factor(series.coeff(k,power).subs(solved))
        solved[unknown]=sp.solve(coefficient,unknown)[0]
    known=-k+sp.Rational(35,16)*k*k+sp.Rational(869,128)*k**3
    checked_series=sp.factor(expansion.subs(solved)-known)
    # Manual differentiation result, independent of symbolic differentiation.
    hand=sp.Matrix([
        [0,0,1,0],
        [0,0,k*(1-3*k)/(4*a),1],
        [4*(3*k**3+29*k*k-9*k-3)/((1-3*k)**2*(k+3)),
         96*a/((1-3*k)**2*(k+3)),-1,
         48*a*(1+k)/((1-3*k)**2*(k+3))],
        [(1+2*k-7*k*k)/(2*a*(1+k)),-4/(1+k),-(1+k)/(2*a),-1]
    ])
    hand_residual=(matrix-hand).applyfunc(sp.factor)
    # Exact all-k sign proof remainders.
    sign_identities={
       'n_minus_four':sp.factor(n-4-k*(1+10*k-3*k*k)),
       'n_minus_fourD':sp.factor(n-4*D-k*(21-2*k-39*k*k)),
       'positive_margin_over_16k':sp.factor(21-2*k-39*k*k-16-(1-3*k)*(13*k+5)),
       'quadratic_maximum':sp.factor(sp.Rational(1,12)-k*(1-3*k)-3*(k-sp.Rational(1,6))**2),
       'P_over_S':sp.factor(P/S-4*k*(1-3*k)/n)
    }
    wrong_clock=matrix.copy();wrong_clock[1,2]=0
    wrong_clock_difference=sp.factor(wrong_clock.charpoly(lam).as_expr()-polynomial)
    wrong_potential_fixedpoint=sp.factor((2*W/(F*A*Hbar)).subs(point))
    wrong_ell_fixedpoint=sp.factor((W/(B*Hbar)).subs(point))

    mp.mp.dps=80
    numeric_matrix=sp.lambdify(k,matrix,'mpmath')
    rates=[]
    for kval in ['1e-6','1e-5','.001','.01','.1','.3','.32']:
        km=mp.mpf(kval)
        mat=numeric_matrix(km)
        eigenvalues=mp.eig(mat,left=False,right=False)
        slow=max(eigenvalues,key=lambda value:mp.re(value))
        nm=-3*km**3+10*km*km+km+4
        sm=4*nm/((1+km)*(1-3*km)**2)
        pm=16*km/((1+km)*(1-3*km))
        small=2*pm/(sm+mp.sqrt(sm*sm-4*pm))
        stable=-2*small/(1+mp.sqrt(1-4*small))
        rates.append({'k':kval,'lambda_slow_from_matrix':str(slow),
            'lambda_slow_stable_closed_form':str(stable),
            'rate_agreement_absolute':str(abs(slow-stable)),
            'Einstein_efold_relaxation_time':str(-1/stable),
            'linear_amplitude_after_24_efolds':str(mp.exp(24*stable)),
            'eigenvalues':[{'real':str(mp.re(v)),'imag':str(mp.im(v))} for v in eigenvalues],
            'r_small':str(small),'r_large':str(sm-small)})
    checks={
       'fixed_point':all(v==0 for v in residual),
       'jacobian_matches_hand_derivative':all(v==0 for v in hand_residual),
       'claimed_characteristic_polynomial':polynomial_difference==0,
       'cubic_slow_root':checked_series==0,
       'all_sign_identities':all(v==0 for v in sign_identities.values()),
       'clock_omission_detected':wrong_clock_difference!=0,
       'wrong_potential_derivative_detected':wrong_potential_fixedpoint!=0,
       'wrong_ell_gradient_detected':wrong_ell_fixedpoint!=0,
       'numeric_rates_from_independent_matrix_agree':all(mp.mpf(row['rate_agreement_absolute'])<mp.mpf('1e-65') for row in rates),
       'numeric_spectra_stable':all(mp.mpf(v['real'])<0 for row in rates for v in row['eigenvalues'])
    }
    result={'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'coordinates':['t=2alpha*u','z','r=t_prime','q=ell_prime'],
        'fixed_point_residuals':list(map(str,residual)),
        'jacobian':[[str(v) for v in matrix.row(i)] for i in range(4)],
        'characteristic_polynomial':str(polynomial),
        'claimed_polynomial_residual':str(polynomial_difference),
        'jacobian_manual_residual':str(hand_residual),
        'slow_series_coefficients':{str(key):str(val) for key,val in solved.items()},
        'slow_series_comparison_residual':str(checked_series),
        'sign_identity_residuals':{key:str(value) for key,value in sign_identities.items()},
        'mutation_controls':{'omit_physical_clock_polynomial_difference':str(wrong_clock_difference),'differentiate_U_at_fixed_z_and_N_fixed_point_defect':str(wrong_potential_fixedpoint),'halve_ell_gradient_fixed_point_defect':str(wrong_ell_fixedpoint)},
        'rates':rates,'checks':{key:bool(value) for key,value in checks.items()},
        'status':'completed_no_check_failures' if all(checks.values()) else 'completed_with_failures'}
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if not all(checks.values()):raise SystemExit(1)


if __name__=='__main__':main()
