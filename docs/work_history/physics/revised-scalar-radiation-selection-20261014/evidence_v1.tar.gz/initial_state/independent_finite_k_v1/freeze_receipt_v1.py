#!/usr/bin/env python3
"""Freeze this independent check; never change parent sources or old receipts."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json


def main():
    out = Path(__file__).resolve().parent
    repo = out.parents[5]
    receipt_path = out / 'RECEIPT_v1.json'
    hash_path = out / 'RECEIPT_v1.sha256'
    verify_path = out / 'RECEIPT_VERIFICATION_v1.json'
    for target in (receipt_path, hash_path, verify_path):
        if target.exists():
            raise RuntimeError('Preserve already frozen output: ' + str(target))
    sha = lambda data: hashlib.sha256(data).hexdigest()
    sources = []
    for name in ('SOURCE_MANIFEST_v1.json', 'SOURCE_MANIFEST_v2.json'):
        manifest = json.loads((out / name).read_text())
        for item in manifest['sources']:
            original = Path(item.get('source', '')) if 'source' in item else repo / item['original_path']
            snapshot = out / item.get('snapshot', item.get('snapshot_path'))
            original_bytes = original.read_bytes()
            snapshot_bytes = snapshot.read_bytes()
            assert original_bytes == snapshot_bytes
            assert sha(snapshot_bytes) == item['sha256']
            sources.append({'original_path': str(original.relative_to(repo)),
                            'snapshot_path': str(snapshot.relative_to(out)),
                            'sha256': item['sha256'],
                            'bytes': len(snapshot_bytes),
                            'current_source_matches_snapshot': True})
    spectrum = json.loads((out / 'results/spectrum_run01.json').read_text())
    limit = json.loads((out / 'results/large_y_run01.json').read_text())
    assert all(spectrum['checks'].values())
    assert not limit['failures']
    assert all(all(case['checks'].values()) for case in limit['cases'])
    for script, result in (('derive_spectrum_v1.py', spectrum),
                           ('check_large_y_limit_v1.py', limit)):
        assert sha((out / script).read_bytes()) == result['script_sha256']
    excluded = {receipt_path.name, hash_path.name, verify_path.name}
    artifacts = []
    for file in sorted(out.rglob('*')):
        if file.is_file() and file.name not in excluded:
            data = file.read_bytes()
            artifacts.append({'path': str(file.relative_to(out)),
                              'bytes': len(data), 'sha256': sha(data)})
    receipt = {
        'kind': 'focused_independent_mathematics_check',
        'checker': '/root/scalar_energy_check',
        'scientific_author': '/root',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'Full-action fixed-k large-y trace-free radiation reduction on x=x_prime=0; local Jacobian, spectrum, nonlinear stability, cubic slow root and independent rate/limit controls.',
        'sources': sources,
        'producer_runner_read_or_imported': False,
        'parent_runner_results_used_as_independent_evidence': False,
        'mathematical_outcome': 'No unresolved mathematical correction within checked reduced system; one v1 scope qualification resolved by byte-bound v2.',
        'resolved_qualification': 'Only the linear slow-mode factor has the demonstrated noncommuting limits; no common nonlinear basin supplied.',
        'evidence': {
            'hand_derivation': 'HAND_DERIVATION_v1.md',
            'report': 'REPORT_v1.md',
            'failure_log': 'FAILURE_LOG_v1.md',
            'spectrum_compound_checks_true': len(spectrum['checks']),
            'symbolic_damage_probes': len(spectrum['mutation_controls']),
            'independent_matrix_rate_cases': len(spectrum['rates']),
            'precision_decimal_digits': 80,
            'large_y_off_orbit_cases': len(limit['cases']),
            'large_y_full_action_evaluations': sum(len(c['rows']) for c in limit['cases']),
            'actual_execution_or_check_failures': [],
            'run_counts': {'derive_spectrum_v1.py': 1, 'check_large_y_limit_v1.py': 1},
            'execution_exit_codes': {'derive_spectrum_v1.py': 0, 'check_large_y_limit_v1.py': 0}
        },
        'not_established': ['generic attraction to x=0', 'global basin or finite capture',
                            'uniform nonlinear k-limit exchange', 'full-action asymptotic history tracking',
                            'observed initial-state selection', 'full thermal-history or observational test',
                            'cosmological-to-local bridge'],
        'formal_audit_performed': False,
        'repository_authority_or_audit_state_modified': False,
        'parent_sources_or_git_state_modified': False,
        'prior_receipts_modified': False,
        'artifact_count': len(artifacts),
        'artifact_paths_relative_to': str(out.relative_to(repo)),
        'artifacts': artifacts,
        'self_hash_exclusion': sorted(excluded)
    }
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    receipt_sha = sha(receipt_path.read_bytes())
    hash_path.write_text(receipt_sha + '  RECEIPT_v1.json\n')
    roundtrip = json.loads(receipt_path.read_text())
    for row in roundtrip['artifacts']:
        data = (out / row['path']).read_bytes()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
    verify = {'created_utc': datetime.now(timezone.utc).isoformat(),
              'receipt_path': receipt_path.name, 'receipt_sha256': receipt_sha,
              'artifact_count_verified': len(artifacts),
              'source_count_verified_current': len(sources),
              'all_artifact_hashes_and_sizes_match': True,
              'all_current_sources_match_snapshots': True,
              'script_hashes_match_frozen_results': True,
              'receipt_sidecar_matches': hash_path.read_text().split()[0] == receipt_sha}
    verify_path.write_text(json.dumps(verify, indent=2) + '\n')
    print(json.dumps(verify, indent=2))


if __name__ == '__main__':
    main()
