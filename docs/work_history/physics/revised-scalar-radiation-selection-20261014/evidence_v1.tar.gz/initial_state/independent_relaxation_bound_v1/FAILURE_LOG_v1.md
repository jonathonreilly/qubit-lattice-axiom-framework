# Actual failure and damage record

`python3 check_relaxation_v1.py > results/exact_run01.stdout.txt 2> results/exact_run01.stderr.txt`
exited 1 during JSON serialization. `Poly.count_roots` returned SymPy
integer objects, and the unconverted list of three root counts contained
`One`, which the JSON encoder rejected. The complete traceback and empty
stdout are preserved. No first-run JSON exists and no checks are counted
as published by that failed run.

The new check_relaxation_v2.py converts just those three output counts to
native int and uses results/exact_run02.json. CHECKER_V1_V2.diff records
the exact changes. No scientific formula, input, criterion, Sturm call or
bisection changed. The second command, with fresh stdout/stderr destinations,
exited 0. All 25 top-level compound checks passed and stderr is empty.

Four explicit damage controls reject incorrect or overextended claims;
they are not mutations of producer source or concealed failed versions.
No source correction is requested. All previous independent evidence and
actual failures remain unchanged. This extension assigns no formal audit
verdict and does not convert the exposed proxy into a measured bound.
