# Independent sign/root derivation and control protocol

Checker /root/scalar_energy_check; scientific author /root. This is the
small relaxation-bound extension only. The full extension and finite-k v2
source were read, and the already checked full-action radiation reduction
is reused. It is not rerun or newly promoted to a full-history result. The
complete supplied action is used only for a pointwise coupling damage
control. No producer code/output or empirical data is accessed.

This derivation and protocol are written before the independent program
execution. All calculations below keep 0<k<1/3 fixed, ideal trace-free
large-positive-y radiation, bounded u,z, x=x'=0 and the local ideal reduced
fixed point. N is the Einstein e-fold variable.

## Polynomial and an independent root argument

Set D=(1+k)(1-3k)^2, n=-3k^3+10k^2+k+4,
S=4n/D and P0=16k/[(1+k)(1-3k)]. The checked characteristic polynomial is

    P(l)=(l^2+l)^2+S(l^2+l)+P0.

D and P0 are positive. The previous spectrum proof gives S>16, P0/S<1/12,
and a positive discriminant in the auxiliary quadratic. In detail,
n-4D=k(21-2k-39k^2)>16k; also n>4 and
k(1-3k)<=1/12. Thus S^2-4P0>0. The factors are
l^2+l+r_s and l^2+l+r_l, where
0<r_s<2P0/S<1/6 and r_l=S-r_s>16-1/6. There is exactly one real root in
(-1/2,0), another real root in (-1,-1/2), and a complex pair with real
part -1/2. This identifies the slow root without a numerical root label.

Direct substitution, independently clearing D, gives

    P(-k)=-k^2 L(k)/D,
    L=35+43k-66k^2+14k^3+15k^4-9k^5.

The source's lower bound is valid:

    L-746/27 = 43k+14k^3+15k^4
              +66(1/9-k^2)+9(1/243-k^5) > 0.

As a distinct simple positivity check, write
L=35+k(43-66k)+14k^3+k^4(15-9k). On the interval,
43-66k>21 and 15-9k>12, so even L>35 follows. No tighter relaxation
claim is needed from that stronger algebraic observation.

Consequently P(-k)<0 while P(0)=P0>0. The intermediate-value theorem
places a real root in (-k,0), which is contained in (-1/2,0). The checked
spectrum identifies that root uniquely as lambda_s. Therefore

    -k<lambda_s<0, or 0<-lambda_s<k.

This supplies an alternative to the source's factor-sign comparison. The
source's route is correct too: at -k the large factor obeys
k^2-k+r_l> -1/4+16-1/6=187/12>0. The small factor is then negative,
so r_s<k-k^2. The map t->t-t^2 is strictly increasing on (0,1/2), and
t=-lambda_s is its small positive solution. Hence t<k.

On (-k,0), P'(l)=(2l+1)[2(l^2+l)+S]>0 as well: the first factor is
greater than 1/3 and the second greater than S-1/2. This supports an
independent exact-rational bisection certificate at selected k values.
The all-k conclusion comes from the proof, not the finite checks.

## Conditional bound and its exact meaning

For a nonzero coefficient a_s of the real linear slow eigenmode,
|a_s(N+DeltaN)|/|a_s(N)|=exp(lambda_s DeltaN). If an independently
applicable constraint actually establishes 0<k<=b<1/3 and DeltaN>0, then

    -lambda_s<k<=b,
    tau=1/(-lambda_s)>1/k>=1/b,
    exp(lambda_s DeltaN)>exp(-k DeltaN)>=exp(-b DeltaN).

The strict inequality survives when k=b. These are dimensionless Einstein
e-fold rates. They are not physical-time rates or automatically Jordan
e-fold intervals. The stipulated DeltaN is not an inferred cosmic duration.

The previously exposed b=1/79999 is used only as an exact rational proxy,
without a new data extraction, likelihood or confidence interpretation.
At DeltaN=24, the conditional statement is tau>79999 and amplitude ratio
greater than exp(-24/79999). An alternating-series bound can enclose that
last mathematical exponential without implying any experiment applies.

At the scalar vacuum the action gives g=alpha_m^2=k. Away from it, the
pointwise coupling is g(u)=a/J, where a=(1-k)(1+3k)/4 and
J=1+(1-3a)sE, s=(1+k)/[k(1-3k)], E=exp(2 sqrt(a)u). An algebraic example
with k=1/10 and target g=1/100000 has
E=(a/g-1)/[(1-3a)s]>0, hence a finite real u, and g<b<k for the exposed
proxy. This does not construct a physically realized or stationary local
environment. It does show why the pointwise non-vacuum coupling cannot
be silently replaced by the vacuum identity; actual source/range/readout
and environment assumptions are still needed to transfer a physical bound.

The bound is on the specified nonzero slow-mode component. A pure fast
real eigenmode is an immediate counterexample to a universal lower bound
on the norm of every linear perturbation: its eigenvalue is <-1/2<-b,
and its norm ratio is smaller than exp(-b DeltaN). Its slow projection is
zero. More general mode mixtures do not turn the single-mode formula into
a total-state norm bound. Nonlinear terms, finite-y corrections, thermal
traces, transitions and different attractors are outside this result.
No initial slow amplitude, time-to-tolerance, common nonlinear basin or
initial-state selector has been supplied.

## Frozen execution plan

Use exact symbolic algebra for the P(-k) identity, both positive decompositions
of L, polynomial derivative and spectrum inequalities. Use exact rational
test points k=1/1000000,1/79999,1/137,1/10,2/9 and 1/3-1/1000000.
For each, count roots by a separate Sturm calculation and bisect the slow
root on (-k,0) for 100 steps using exact rational polynomial signs. Retain
all brackets and any failed controls. These finite checks support the
hand proof and do not replace the all-k argument.

For x=24/79999<1, use the degree-9 and degree-8 alternating Taylor sums as
strict lower/upper rational bounds on exp(-x). No floating value is used
as a certificate. Display decimal approximations only for readability.

Damage controls will reject the wrong sign in P(-k), replacing the exact
slow root by -k, applying a non-vacuum g bound directly to k, and extending
the single-mode retention bound to every linear state. One independent
program and its complete output are sufficient; no trajectory or producer
program is needed. All artifacts and source identities will be sealed.
