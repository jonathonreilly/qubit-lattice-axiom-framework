#!/usr/bin/env python3
"""Independent exact polynomial, root-location and scope damage controls."""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import sympy as s


def main():
    out=Path(__file__).resolve().parent
    target=out/'results/exact_run02.json'
    if target.exists():raise RuntimeError('Preserve existing result')
    k,l=s.symbols('k lambda',real=True)
    D=(1+k)*(1-3*k)**2;n=-3*k**3+10*k**2+k+4
    S=4*n/D;P0=16*k/((1+k)*(1-3*k))
    P=(l*l+l)**2+S*(l*l+l)+P0
    L=35+43*k-66*k*k+14*k**3+15*k**4-9*k**5
    cleared=s.expand(D*(l*l+l)**2+4*n*(l*l+l)+16*k*(1-3*k))
    checks={}
    def check(name,value):checks[name]=bool(value)
    def zero(expr):return s.simplify(expr)==0
    check('independent_denominator_clearing',zero(cleared-D*P))
    check('P_minus_k_factorization',zero(P.subs(l,-k)+k*k*L/D))
    decomposition=43*k+14*k**3+15*k**4+66*(s.Rational(1,9)-k*k)+9*(s.Rational(1,243)-k**5)
    check('source_positive_L_decomposition',zero(L-s.Rational(746,27)-decomposition))
    stronger=35+k*(43-66*k)+14*k**3+k**4*(15-9*k)
    check('independent_positive_L_decomposition',zero(L-stronger))
    check('strict_lower_bound_constants',s.Rational(35)-s.Rational(66,9)-s.Rational(9,243)==s.Rational(746,27))
    check('S_bound_n_minus_4D_identity',zero(n-4*D-k*(21-2*k-39*k*k)))
    check('n_larger_than_four_decomposition',zero(n-4-k*(1+k*(10-3*k))))
    check('P0_over_S_identity',zero(P0/S-4*k*(1-3*k)/n))
    check('k_one_minus_3k_bound',zero(s.Rational(1,12)-k*(1-3*k)-3*(k-s.Rational(1,6))**2))
    check('polynomial_derivative_factorization',zero(s.diff(P,l)-(2*l+1)*(2*(l*l+l)+S)))
    check('large_factor_positive_margin_constant',16-s.Rational(1,6)-s.Rational(1,4)==s.Rational(187,12))
    # The sign decomposition is a proof on 0<k<1/3; these exact points
    # exercise independent Sturm counts and root brackets, not a replacement.
    points=[s.Rational(1,1000000),s.Rational(1,79999),s.Rational(1,137),s.Rational(1,10),s.Rational(2,9),s.Rational(1,3)-s.Rational(1,1000000)]
    rows=[];proxy_row=None
    for kval in points:
        poly=s.Poly(cleared.subs(k,kval),l,domain=s.QQ)
        lo=-kval;hi=s.Rational(0)
        assert poly.eval(lo)<0 and poly.eval(hi)>0
        for _ in range(100):
            mid=(lo+hi)/2;value=poly.eval(mid)
            if value<0:lo=mid
            elif value>0:hi=mid
            else:raise RuntimeError('Unexpected exact root: preserve and handle explicitly, do not silently change bracket semantics.')
        count_short=poly.count_roots(-kval,0)
        count_slow=poly.count_roots(-s.Rational(1,2),0)
        count_fast=poly.count_roots(-1,-s.Rational(1,2))
        Lvalue=L.subs(k,kval);Dvalue=D.subs(k,kval)
        tau_lower=-1/lo;tau_upper=-1/hi
        case_checks={
            'open_candidate_domain':0<kval<s.Rational(1,3),
            'L_strictly_above_source_bound':Lvalue>s.Rational(746,27),
            'L_independently_above_35':Lvalue>35,
            'exact_P_minus_k_negative':P.subs({k:kval,l:-kval})<0,
            'sturm_unique_root_in_minus_k_to_zero':count_short==1,
            'sturm_slow_and_fast_locations':count_slow==1 and count_fast==1,
            'certified_bracket_signs':poly.eval(lo)<0 and poly.eval(hi)>0 and -kval<lo<hi<0,
            'tau_interval_strictly_above_inverse_k':tau_lower>1/kval and tau_upper>tau_lower,
        }
        check('rational_k_'+str(kval).replace('/','_')+'_case',all(case_checks.values()))
        row={'k':str(kval),'L':str(Lvalue),'D':str(Dvalue),
             'P_minus_k':str(s.factor(P.subs({k:kval,l:-kval}))),
             'lambda_s_lower':str(lo),'lambda_s_upper':str(hi),'bracket_width':str(hi-lo),
             'lambda_s_decimal_display':str(s.N((lo+hi)/2,28)),
             'tau_lower':str(tau_lower),'tau_upper':str(tau_upper),
             'tau_decimal_display':str(s.N((tau_lower+tau_upper)/2,28)),
             'inverse_k':str(1/kval),'sturm_counts':[int(count_short),int(count_slow),int(count_fast)],
             'checks':{key:bool(value) for key,value in case_checks.items()}}
        rows.append(row)
        if kval==s.Rational(1,79999):proxy_row=(row,lo,hi)
    b=s.Rational(1,79999);elapsed=s.Integer(24);xx=b*elapsed
    upper=sum((-xx)**j/s.factorial(j) for j in range(9))
    lower=sum((-xx)**j/s.factorial(j) for j in range(10))
    check('proxy_argument_in_alternating_series_domain',0<xx<1)
    check('proxy_rational_exponential_bracket_order',0<lower<upper<1)
    check('proxy_retention_exceeds_display_bound',lower>s.Rational(99970004,100000000))
    # Pointwise non-vacuum coupling example; not a constructed physical state.
    kval=s.Rational(1,10);g_target=s.Rational(1,100000)
    aa=(1-kval)*(1+3*kval)/4;ss=(1+kval)/(kval*(1-3*kval))
    E=(aa/g_target-1)/((1-3*aa)*ss)
    evaluated_g=s.factor(aa/(1+(1-3*aa)*ss*E))
    check('pointwise_coupling_example_finite_positive_chart',aa>0 and E>0 and evaluated_g==g_target)
    check('nonvacuum_bound_does_not_imply_k_bound',g_target<b<kval)
    # The exact fast eigenvalue is -1-lambda_s. This entire bracket is
    # below -b, contradicting a universal retention claim for every mode.
    _,slowlo,slowhi=proxy_row
    fastlo=-1-slowhi;fasthi=-1-slowlo
    check('fast_mode_rejects_universal_retention_bound',fastlo<fasthi<-b)
    damaged_sign=s.factor(P.subs(l,-k)-k*k*L/D)
    damaged_linear_rate=s.factor(P.subs(l,-k))
    check('wrong_P_minus_k_sign_detected',not zero(damaged_sign))
    check('lambda_equals_minus_k_as_exact_root_rejected',not zero(damaged_linear_rate))
    result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'hand_protocol_sha256':hashlib.sha256((out/'HAND_DERIVATION_AND_PROTOCOL_v1.md').read_bytes()).hexdigest(),
            'arithmetic':'Exact SymPy rational polynomial signs, Sturm counts and 100-step bisection; decimal strings are displays only.',
            'symbolic_factorization_residual':str(s.factor(P.subs(l,-k)+k*k*L/D)),
            'source_L_positive_decomposition_residual':str(s.expand(L-s.Rational(746,27)-decomposition)),
            'independent_L_positive_decomposition_residual':str(s.expand(L-stronger)),
            'cases':rows,
            'proxy':{'b':str(b),'DeltaN':str(elapsed),'status':'Previously exposed development proxy only; no physical applicability established.',
                     'tau_conditional_strict_lower':str(1/b),'exp_lower_rational':str(lower),'exp_upper_rational':str(upper),
                     'exp_lower_decimal_display':str(s.N(lower,28)),'exp_upper_decimal_display':str(s.N(upper,28)),
                     'exp_bound_width':str(upper-lower)},
            'damage_controls':{'wrong_P_minus_k_sign_residual':str(damaged_sign),'incorrect_exact_lambda_minus_k_residual':str(damaged_linear_rate),
                               'nonvacuum_pointwise_example':{'k':str(kval),'g':str(evaluated_g),'E':str(E),'b':str(b),'physical_state_realization_claim':False},
                               'fast_only_linear_mode':{'lambda_lower':str(fastlo),'lambda_upper':str(fasthi),'comparison_threshold_minus_b':str(-b),'slow_projection':0,'nonlinear_history_claim':False}},
            'checks':checks,'failures':[key for key,value in checks.items() if not value],
            'environment':{'python':sys.version,'sympy':s.__version__},
            'scope':'All-k sign/root proof in the previously checked ideal radiation reduction; conditional applicable k bound and nonzero linear slow-mode amplitude only.'}
    result['status']='completed_no_check_failures' if not result['failures'] else 'completed_with_failures'
    target.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
    if result['failures']:raise SystemExit(1)


if __name__=='__main__':main()
