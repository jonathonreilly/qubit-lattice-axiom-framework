#!/usr/bin/env python3
"""Seal or read-only verify the focused relaxation-extension artifacts."""
from pathlib import Path
import datetime
import hashlib
import json
import sys


OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
EXCLUDE={'MANIFEST_v1.json','RECEIPT_v1.json','RECEIPT_v1.sha256'}


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def verify():
    receipt=json.loads((OUT/'RECEIPT_v1.json').read_text())
    expected=(OUT/'RECEIPT_v1.sha256').read_text().split()[0]
    assert sha(OUT/'RECEIPT_v1.json')==expected
    assert sha(OUT/'MANIFEST_v1.json')==receipt['manifest_sha256']
    manifest=json.loads((OUT/'MANIFEST_v1.json').read_text())
    for row in manifest['artifacts']:
        path=OUT/row['path'];assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256'],row['path']
    for row in receipt['sources']:
        assert sha(ROOT/row['original_path'])==sha(OUT/row['snapshot_path'])==row['sha256']
    expected_paths={row['path'] for row in manifest['artifacts']}|EXCLUDE
    actual_paths={str(p.relative_to(OUT)) for p in OUT.rglob('*') if p.is_file()}
    assert actual_paths==expected_paths
    assert len(manifest['artifacts'])==manifest['artifact_count']==receipt['artifact_count']
    print(json.dumps({'status':'verified','receipt_sha256':expected,'artifacts':len(manifest['artifacts']),
                      'live_source_receipt_pairs':len(receipt['sources']),'named_compound_checks':receipt['named_compound_checks']},indent=2))


def seal():
    for name in EXCLUDE|{'SOURCE_VERIFICATION_v1.json','EXECUTION_RECORD_v1.json'}:
        if (OUT/name).exists():raise RuntimeError('Preserve existing '+name)
    stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
    sources=json.loads((OUT/'SOURCE_MANIFEST_v1.json').read_text())['sources']
    bindings=[]
    for row in sources:
        live=ROOT/row['original_path'];snap=OUT/row['snapshot_path']
        bindings.append({**row,'live_sha256':sha(live),'snapshot_sha256':sha(snap),
                         'matches':sha(live)==sha(snap)==row['sha256'] and live.stat().st_size==snap.stat().st_size==row['bytes']})
    verification={'verified_utc':stamp,'source_and_receipt_bindings':bindings,'all_match':all(x['matches'] for x in bindings)}
    (OUT/'SOURCE_VERIFICATION_v1.json').write_text(json.dumps(verification,indent=2)+'\n')
    assert verification['all_match']
    result=json.loads((OUT/'results/exact_run02.json').read_text())
    assert not result['failures'] and all(result['checks'].values())
    assert result['script_sha256']==sha(OUT/'check_relaxation_v2.py')
    assert result['hand_protocol_sha256']==sha(OUT/'HAND_DERIVATION_AND_PROTOCOL_v1.md')
    assert not (OUT/'results/exact_run01.json').exists()
    assert 'TypeError: Object of type One is not JSON serializable' in (OUT/'results/exact_run01.stderr.txt').read_text()
    assert (OUT/'results/exact_run02.stderr.txt').read_bytes()==b''
    assert (OUT/'results/exact_run02.stdout.txt').read_bytes()==(OUT/'results/exact_run02.json').read_bytes()
    execution={'observed_runs':[{'command':'python3 check_relaxation_v1.py > results/exact_run01.stdout.txt 2> results/exact_run01.stderr.txt','exit_code':1,'cause':'SymPy root-count Integer is not JSON serializable.'},{'command':'python3 check_relaxation_v2.py > results/exact_run02.stdout.txt 2> results/exact_run02.stderr.txt','exit_code':0}],
               'completed_result_sha256':sha(OUT/'results/exact_run02.json'),'named_compound_checks':len(result['checks']),
               'failed_named_checks_in_completed_run':0,'failed_execution_count':1,'damage_controls':4,
               'reused_prior_finite_k_science':True,'producer_or_cosmology_execution':False}
    (OUT/'EXECUTION_RECORD_v1.json').write_text(json.dumps(execution,indent=2)+'\n')
    artifacts=[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':sha(p)}
               for p in sorted(OUT.rglob('*')) if p.is_file() and str(p.relative_to(OUT)) not in EXCLUDE]
    manifest={'schema':'focused_independent_artifact_manifest_v1','created_utc':stamp,'artifact_count':len(artifacts),
              'excluded_self_and_receipt_files':sorted(EXCLUDE),'artifacts':artifacts}
    (OUT/'MANIFEST_v1.json').write_text(json.dumps(manifest,indent=2)+'\n')
    receipt={'schema':'focused_independent_math_check_receipt_v1','created_utc':stamp,
             'checker':'/root/scalar_energy_check','scientific_author':'/root','formal_audit':False,
             'scope':'All-k exact quartic sign/root comparison and conditional linear slow-mode relaxation implication; prior finite-k reduction review reused.',
             'sources':sources,'source_verification_sha256':sha(OUT/'SOURCE_VERIFICATION_v1.json'),
             'report_path':'REPORT_v1.md','report_sha256':sha(OUT/'REPORT_v1.md'),
             'manifest_path':'MANIFEST_v1.json','manifest_sha256':sha(OUT/'MANIFEST_v1.json'),
             'artifact_count':len(artifacts),'named_compound_checks':len(result['checks']),
             'failed_checks_in_completed_run':0,'failed_execution_count':1,'damage_control_count':4,
             'source_corrections_requested':[],
             'checked_claim':'For all 0<k<1/3 under the checked ideal radiation hypotheses, 0<-lambda_s<k. An applicable k<=b gives tau>1/b and nonzero linear slow-mode retention>exp(-b DeltaN).',
             'essential_limitations':['b=1/79999 is an exposed development proxy only, not a new physical bound.','A non-vacuum coupling g is not automatically k; the physical source/range/readout bridge is required.','The result is for a nonzero linear slow-mode component in Einstein e-folds, not every state norm, nonlinear rate or full history.','No initial amplitude, cosmic duration, common nonlinear basin or initial-state selection is derived.'],
             'prior_receipt_sha256':'0c07e8051bef08ec85c5cedc916bec70a07ce5d8c2939caf5f8c7c28c6401694',
             'prior_receipt_identity_only_reused':True,'producer_code_or_output_read':False,
             'empirical_data_or_inherited_cosmology_accessed':False,
             'parent_source_git_pr_runtime_lock_audit_or_prior_receipts_modified':False}
    (OUT/'RECEIPT_v1.json').write_text(json.dumps(receipt,indent=2)+'\n')
    digest=sha(OUT/'RECEIPT_v1.json');(OUT/'RECEIPT_v1.sha256').write_text(digest+'  RECEIPT_v1.json\n')
    verify()


if __name__=='__main__':
    if not sys.argv[1:]:seal()
    elif sys.argv[1:]==['--verify']:verify()
    else:raise SystemExit('Use no argument to seal or --verify for read-only verification.')
