#!/usr/bin/env python3
"""Direct-author full kinetic-metric check of the transverse radiation mode."""
from pathlib import Path
import hashlib
import json
import sympy as s

root=Path(__file__).resolve().parent
out=root/'results_v1'
out.mkdir(exist_ok=False)
rows=[]
def ck(name,value): rows.append({'name':name,'passed':bool(value)})
def zero(name,expr):
    r=s.factor(s.cancel(expr));rows.append({'name':name,'passed':r==0,'residual':str(r)})

k,y,v,z,ell,u=s.symbols('k y v z ell u',real=True)
b,a=s.symbols('b a',positive=True)
# Original x,y large-y kinetic metric, pulled back by x=v exp(ell), y=exp(ell).
old=s.diag(4*b/(3*(1+v*v)*s.exp(2*ell)),b/((1+v*v)*s.exp(2*ell)))
pull=s.Matrix([[s.exp(ell),v*s.exp(ell)],[0,s.exp(ell)]])
G=s.simplify(pull.T*old*pull)
expected=b/(1+v*v)*s.Matrix([[s.Rational(4,3),4*v/3],[4*v/3,1+4*v*v/3]])
for i in range(2):
 for j in range(2):zero(f'pullback_{i}{j}',G[i,j]-expected[i,j])
Gi=s.simplify(G.inv());coords=(v,ell)
Gamma=[[[s.simplify(sum(Gi[i,l]*(s.diff(G[l,h],coords[j])+s.diff(G[l,j],coords[h])-s.diff(G[j,h],coords[l]))/2 for l in range(2))) for h in range(2)] for j in range(2)] for i in range(2)]
zero('Gamma_v_ell_ell_linear',s.diff(Gamma[0][1][1],v).subs(v,0)+s.Rational(1,4))
zero('Gamma_v_v_ell_at_zero',Gamma[0][0][1].subs(v,0))
zero('Gamma_ell_v_ell_at_zero',Gamma[1][0][1].subs(v,0))
zero('Gamma_ell_ell_ell_linear',s.diff(Gamma[1][1][1],v).subs(v,0))
# Potential differentiated in (v,ell) before identifying ell-log(y_b)=z.
W=s.exp(2*ell)*(k*v*v/2+k/3)
grad=s.Matrix([s.diff(W,c) for c in coords]);force=s.simplify(Gi*grad/s.exp(2*ell))
zero('mixed_inverse_metric_potential_force',s.diff(force[0],v).subs(v,0)-k/(12*b))
zero('ell_force_even',s.diff(force[1],v).subs(v,0))
B0=k/(2*(1+k));HB0=2*(1+k)/3
zero('normal_mass_force',s.diff(force[0],v).subs({v:0,b:B0})/HB0-s.Rational(1,4))
r,q,h=s.symbols('r q h',real=True)
vel=(r,q)
normal=-(3+h)*r-sum(Gamma[0][i][j]*vel[i]*vel[j] for i in range(2) for j in range(2))-force[0]/HB0
normal=normal.subs({b:B0,q:-2,h:-2})
linear=s.Matrix([r,normal]).jacobian((v,r)).subs({v:0,r:0})
target=s.Matrix([[0,1],[s.Rational(3,4),-1]])
for i in range(2):
 for j in range(2):zero(f'normal_block_{i}{j}',linear[i,j]-target[i,j])
lam=s.symbols('lambda')
zero('normal_characteristic_polynomial',linear.charpoly(lam).as_expr()-(lam-s.Rational(1,2))*(lam+s.Rational(3,2)))
zero('growing_eigenvector', (linear*s.Matrix([2,1])-s.Matrix([1,s.Rational(1,2)]))[1])
ck('normal_hyperbolic_saddle',set(linear.eigenvals())=={s.Rational(1,2),-s.Rational(3,2)})

# Independent original-field connection, using the full finite-y D factor.
x=s.symbols('x',real=True)
D=1+2*(1+k)*(x*x+y*y)/3
Kx=4*k/(9*D);Ky=k/(3*D)
Gxy=-s.diff(Kx,y)*0+s.diff(Kx,y)/(2*Kx)
Gyy=-s.diff(Ky,x)/(2*Kx)
zero('original_mixed_connection_limit',s.limit(y*Gxy.subs(x,0),y,s.oo)+1)
zero('original_normal_connection_limit',s.limit(y*y*s.diff(Gyy,x).subs(x,0),y,s.oo)-s.Rational(3,4))
masscoef=s.limit(k/(Kx.subs(x,0)*y*y*HB0),y,s.oo)
zero('original_potential_coefficient',masscoef-s.Rational(9,4))
P_x=lam*lam+5*lam+s.Rational(21,4)
zero('x_roots',P_x-(lam+s.Rational(3,2))*(lam+s.Rational(7,2)))
zero('x_to_ratio_clock_shift',P_x.subs(lam,lam-2)-(lam*lam+lam-s.Rational(3,4)))
zero('energy_ratio', (k*x*x/2)/(k*y*y/3)-3*(x/y)**2/2)

# Damages: omit the off-diagonal inverse-metric force, mixed original-field
# connection, or mistake decay of x for decay of its ratio to radiation.
bad_force=s.diff((Gi[0,0]*grad[0]/s.exp(2*ell)),v).subs({v:0,b:B0})/HB0
ck('damage.omitted_inverse_mixed_force',bad_force!=s.Rational(1,4))
bad_x=lam*lam+(3-2)*lam+s.Rational(21,4)
ck('damage.omitted_original_mixed_connection',s.expand(bad_x-P_x)!=0)
ck('damage.x_decay_does_not_imply_ratio_decay',-s.Rational(3,2)<0 and -s.Rational(3,2)+2>0)
ck('scope.fast_transverse_mode_also_exists',-s.Rational(7,2)+2<0)

result={'scope':'Exact local transverse linearization of supplied full-field large-y radiation limit; no full history or empirical fit.',
 'source_sha256':hashlib.sha256((root/'DERIVATION_v1.md').read_bytes()).hexdigest(),
 'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'metric':str(G),'inverse_metric':str(Gi),'normal_flow':str(s.factor(normal)),
 'normal_jacobian':str(linear),'checks':rows,'passed':sum(r['passed'] for r in rows),'failed':sum(not r['passed'] for r in rows)}
(out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));raise SystemExit(result['failed']!=0)
