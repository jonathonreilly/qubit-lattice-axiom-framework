# Direct initial-covariance reconstruction controls

The corrected checker passed70/0 exact algebra/constraint/population controls.
It realizes centered finite covariance with eight bounded Rademacher triples in
each of two specified positive-radiation backgrounds. These are synthetic local
initial states, not observational fits or full cosmological trajectories. Each
has maximum chosen dimensionless weak amplitude1/100. The output amplitude is
rescaled separately for the two backgrounds; no same fixed observed amplitude
across backgrounds is claimed. Generic complex and rank-deficient controls
separate PSD feasibility from transfer-support constraints.

The original checker failed before writing results because Sympy has no S.Zero
attribute. Its source, exception and incomplete output directory remain intact;
no partial pass count is assigned. V2 changes only S.Zero to S.Integer(0).
Three actually changed v2 copies separately reject missing complex adjoint,
wrong momentum coefficient and wrong radiation coefficient. Full code, diffs,
commands, results and stdout/stderr are retained. Independent source review is
pending at this writing. No action, state, scale or measured parameter selected.
