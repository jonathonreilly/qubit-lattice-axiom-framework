# What a free initial covariance prevents one epoch from determining

Direct author /root, conditional-support, 2026-10-14. The observed E_G example
and its actual projected-estimator limitations are recorded in
../observable_bridge_v1/DERIVATION_v2.md. Here I ask what even an ideal complete
matched covariance could determine. No new observed covariance, raw likelihood,
calibrated parameter fit or held-out empirical test is available in this block.

## Eliminate covariance as a nuisance without selecting it

For a specified background, parameters, mode, observation operator and interval,
let centered linear initial amplitudes X in C^n give readouts Y=T X in C^m.
Let P=E[XX^dagger]>=0 be finite and otherwise unrestricted. Then the exact
centered readout covariance is S=T P T^dagger. With T^+ the Moore-Penrose
inverse and Pi=T T^+ the orthogonal projector onto range(T),

    there exists P>=0 with S=T P T^dagger
    iff S=S^dagger>=0 and (I-Pi)S=0.                    (1)

Necessity follows because every column of S lies in range(T). For sufficiency,
choose

    P0=T^+ S (T^+)^dagger>=0.

Then T P0 T^dagger=Pi S Pi=S. This is a constructive covariance reconstruction,
not a dynamical state selector. Adding any N>=0 supported in ker(T) gives
another solution P0+N. That family is not asserted to list all possible
solutions: positive observed/null cross blocks can also be allowed.

If T has full row rank, Pi=I. Every finite PSD S is then algebraically feasible
for that parameter choice. One epoch's complete covariance cannot identify
parameters merely by fitting it when P is completely free and the transfer
remains surjective. Other information, such as known background constraints,
weak-amplitude bounds or state restrictions, can still constrain parameters.
The statement is about this covariance fit conditional on the supplied
background, not all possible observations or whole cosmic histories.

A PSD S has a bounded realization: take a finite square root B, let its input
coordinates be independent centered Rademacher variables, and set Y=B Z.
For a complex Fourier mode the paired negative mode can enforce reality.
Neither Gaussianity nor an unbounded random tail is required. Common amplitude
rescaling shrinks S and every reconstructed finite state. This establishes
local weak feasibility for sufficiently small amplitudes, not realizability
of an arbitrary fixed measured amplitude within a linear theory.

## An explicit right inverse of this candidate at a regular event

Use the checked dust/radiation/scalar equations of
../kinetic_radiation_v1/DERIVATION_v3.md. Choose a regular event of the supplied
homogeneous background with phi=0 and dot(phi)=0, positive dust and radiation,
Q>0, Hv>0, 0<k<1/3 and nu>0. At that event C=A^2=1, grad U=0, U=3/2, and

    H^2=Hv^2+2(Rm+Rr)/3,
    Rm=rho_m,E/(2Q)>0, Rr=rho_r,E/(2Q)>0.

This is allowed instantaneous initial data for the background equations.
Dust gives a nonzero subsequent scalar acceleration; the background is not
being falsely held at a stationary vacuum over an interval. The selected
origin event is an explicit premise of this counterexample, not an inferred
state of our universe.

Let p>0. At this event set scalar perturbations xi=pi_scalar=0 and radiation
multipoles Theta_l=0 for l>=1. The radiation monopole Theta0, dust number
contrast n and velocity divergence theta are free subject to the Hamiltonian
constraint. The shear is zero initially, T_metric=L, and

    J=Rm theta/p^2,
    C_H=p^2 L+Rm n+4Rr Theta0+3H Rm theta/p^2=0.       (2)

The physical outputs are W=(T_J+L_J)/2=L, theta_J=theta and
Delta_m,J=n. More generally Delta_m,J=n-3 b.xi, so the last equality uses the
specified zero scalar perturbation. Thus with X=(n,theta,Theta0) and
Y=(W,theta_J,Delta_m,J), the constrained initial output map is

          [ -Rm/p^2   -3H Rm/p^4   -4Rr/p^2 ]
    T0 =  [     0          1             0   ],
          [     1          0             0   ]
    det T0=4Rr/p^2>0.                                (3)

For any proposed output triplet the explicit inverse is

    n=Delta_m,J,
    theta=theta_J,
    Theta0=-(p^2 W+Rm Delta_m,J+3H Rm theta_J/p^2)/(4Rr). (4)

The candidate therefore has a surjective instantaneous three-readout map in
this declared background class for every allowed k and nu. Constraint solving
has not selected the relative radiation/dust state. No phenomenological
single-growing-mode relation is inserted. Nonzero shear and scalar waves
are not required for this counterexample, although they supply additional
independent initial directions in the general theory.

The perturbations in (4) are initial data. The coupled evolution immediately
generates their derivatives and generally higher angular moments. They are not
an exact static or permanently perfect-radiation solution. For smooth regular
background coefficients on a finite short interval, the linear transport
integral equation coupled to the finite metric/scalar/dust equations has local
solutions by the usual bounded linear integral evolution; the initial
Hamiltonian constraint is preserved by the checked coupled identity. This
provides local compatibility, not a past-complete solution or an observed
expansion/transfer history.

When Rr is small or p is large, the reconstructed monopole can be large. The
bound |4Theta0|<<1, weak potentials, nonrelativistic velocities and positive
matter/radiation populations must be checked at fixed amplitudes. They do not
follow from PSD alone. For any fixed finite parameters with Rr>0 and p>0,
a sufficiently small common amplitude and bounded seeds satisfy these local
requirements. The neighborhood is not uniform as Rr->0 or p->infinity.

## What additional observations would have to add

Several matched epochs from the same initial amplitudes have stacked transfer
Tstack=(T1;...;Tr), with full cross-time covariance

    Sstack=Tstack P Tstack^dagger.

If Tstack is rank deficient on the readout space, its left-null relations
L Tstack=0 require L Sstack=0. This condition may constrain parameters without
prescribing P. As an exact illustration, one seed with readouts (X,a X) requires
S12=a* S11 and S22=|a|^2 S11. Nonzero S11 then fixes that transfer ratio.
A PSD two-time covariance incompatible with those identities is infeasible
for that specified transfer. Replacing the one seed by two independent readout
seeds removes that restriction. It is the transfer support, not an assumed
covariance normalization, that supplies the constraint.

The full initial angular distribution in the candidate supplies many possible
modes. A finite chosen transfer truncation or arbitrary finite set of epochs
is not automatically rank deficient, so this paragraph does not promise that
more bins identify the scalar parameters. Nor do redshift bins automatically
measure a time series of the same mode or the needed cross-time covariances.
Actual projection, velocity bias, noise, light-cone geometry and selection must
be included in T before applying (1) to a survey. One must also distinguish
estimated noisy S from an exact PSD signal covariance.

## Assumption accounting

Equation(1) eliminates a chosen initial covariance from an exact feasibility
question. It does not derive or select the actual covariance, quantum state,
background, matter sector or action. Equation(4) supplies a concrete local
candidate witness that even three ideal equal-time observables can be matched
by changing allowed initial amplitudes. It does not claim agreement with the
observed universe, prohibit constraints from other observations, or show that
all parameters can fit a complete survey. The useful next target is an actual
matched observable operator and its support/rank with physical amplitude
bounds; inserting a single common seed would restore a supplied assumption.
