"""Exact support reconstruction and local candidate constraint witnesses."""
import argparse,itertools,json,pathlib
import sympy as S

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);out=pathlib.Path(ap.parse_args().output);out.mkdir(parents=True,exist_ok=False);rows=[]
 def ck(n,b,d=None):rows.append({'name':n,'ok':bool(b),'details':d})
 def zero(n,x):
  v=S.simplify(x);b=v==S.zeros(*v.shape) if isinstance(v,S.MatrixBase) else v==0;ck(n,b,str(v))
 i=S.I
 T=S.Matrix([[1,i,0],[0,1,1]]);B=S.Matrix([[1,2*i],[3-i,1]]);C=B*B.H
 R=T.H*(T*T.H).inv()
 P=R*C*R.T
 zero('general.right_inverse',T*R-S.eye(2));zero('general.reconstructed_covariance',T*P*T.H-C);zero('general.P_hermitian',P-P.H);zero('general.P_factorization',P-(R*B)*(R*B).H)
 z=S.Matrix([-i,1,-1]);zero('general.kernel_vector',T*z);N=z*z.H;zero('general.kernel_family',T*(P+N)*T.H-C)
 Ccross=R*B+z*S.Matrix([[1,i]]);Pc=Ccross*Ccross.H
 zero('general.cross_block_feasible',T*Pc*T.H-C);ck('general.kernel_addition_not_exhaustive',T*(Pc-P)!=S.zeros(2,3))
 # Rank-deficient exact projection. The impossible covariance is PSD but outside transfer support.
 a=2-i;Ts=S.Matrix([1,a]);Rs=Ts.H/(Ts.H*Ts)[0];Pi=Ts*Rs;Cs=3*Ts*Ts.H
 zero('rank.projector',Pi*Pi-Pi);zero('rank.projector_hermitian',Pi-Pi.H);zero('rank.feasible_support',(S.eye(2)-Pi)*Cs);zero('rank.exact_reconstruction',Ts*(Rs*Cs*Rs.H)*Ts.H-Cs)
 bad=S.eye(2);ck('rank.PSD_alone_not_enough',(S.eye(2)-Pi)*bad!=S.zeros(2));zero('rank.ordered_complex_cross',Cs[0,1]-S.conjugate(a)*Cs[0,0]);ck('rank.wrong_conjugation_rejected',Cs[0,1]!=a*Cs[0,0])
 left=S.Matrix([[-a,1]]);zero('rank.left_null',left*Ts);zero('rank.left_covariance',left*Cs);ck('rank.incompatible_left_witness',left*bad!=S.zeros(1,2))
 # Candidate Hamiltonian constraint in the declared origin event with zero field perturbations.
 H,rm,rr,p=S.symbols('H rm rr p',positive=True);W,th,de=S.symbols('W th de',real=True)
 momentum_factor=3
 radiation_factor=4
 T0=S.Matrix([[-rm/p**2,-momentum_factor*H*rm/p**4,-radiation_factor*rr/p**2],[0,1,0],[1,0,0]])
 R0=S.Matrix([[0,0,1],[0,1,0],[-p**2/(4*rr),-3*H*rm/(4*rr*p**2),-rm/(4*rr)]])
 zero('candidate.determinant',T0.det()-4*rr/p**2);zero('candidate.right_inverse',T0*R0-S.eye(3))
 n,theta,mon=S.symbols('n theta mon',real=True);XX=S.Matrix([n,theta,mon]);YY=T0*XX
 zero('candidate.initial_constraint',p*p*YY[0]+rm*n+4*rr*mon+3*H*rm*theta/p**2)
 zero('candidate.physical_density',YY[2]-n);zero('candidate.physical_velocity',YY[1]-theta)
 target=S.Matrix([W,th,de]);initial=R0*target
 zero('candidate.reconstructed_constraint',p*p*W+rm*initial[0]+4*rr*initial[2]+3*H*rm*initial[1]/p**2)
 zero('candidate.monopole_charge',initial[2]+(p*p*W+rm*de+3*H*rm*th/p**2)/(4*rr))
 # Dust forces subsequent motion: the initial origin is not a constant vacuum background.
 k=S.symbols('k',positive=True);ak=(1-k)*(1+3*k)/4;sk=(1+k)/(k*(1-3*k));j0=1+(1-3*ak)*sk;ku=j0/(1+sk)**2;bu=S.sqrt(ak)/(1+sk)
 zero('candidate.origin_coupling',bu*bu/ku-k)
 for kv in [S.Rational(1,10),S.Rational(2,13)]:
  acc=(-rm*bu/ku).subs({k:kv,rm:S.Rational(3,4)})
  ck('candidate.dust_acceleration_nonzero',acc!=0,str(acc))
 # Bounded exact Rademacher populations realize the requested output covariance at two synthetic backgrounds.
 B0=S.Matrix([[1,2,0],[0,1,1],[1,0,3]]);configs=[{H:1,rm:S.Rational(3,4),rr:S.Rational(3,8),p:S.Rational(5,3),'Hv':S.Rational(1,2)},{H:S.Rational(6,5),rm:S.Rational(8,5),rr:S.Rational(1,50),p:S.Rational(7,4),'Hv':S.Rational(3,5)}];data=[]
 for q in configs:
  sub={key:v for key,v in q.items() if key!='Hv'};tm=T0.subs(sub);rc=R0.subs(sub);load=rc*B0
  scales=[sum(abs(x) for x in load.row(0)),sum(abs(x) for x in load.row(1))/q[p],4*sum(abs(x) for x in load.row(2)),sum(abs(x) for x in B0.row(0))];eps=1/(100*max(scales));cov=S.zeros(3);icov=S.zeros(3);worst=S.Integer(0)
  zero('realization.background_constraint',q[H]**2-q['Hv']**2-2*(q[rm]+q[rr])/3)
  for signs in itertools.product([-1,1],repeat=3):
   zz=S.Matrix(signs);yy=eps*B0*zz;xx=rc*yy;actual=tm*xx;cov+=actual*actual.T/8;icov+=xx*xx.T/8
   zero('realization.each_constraint',(p*p*yy[0]+rm*xx[0]+4*rr*xx[2]+3*H*rm*xx[1]/p**2).subs(sub))
   ck('realization.positive_populations',1+xx[0]>0 and 1+4*xx[2]>0)
   worst=max(worst,abs(xx[0]),abs(4*xx[2]),abs(xx[1])/q[p],abs(yy[0]))
  zero('realization.exact_output_covariance',cov-eps**2*B0*B0.T);zero('realization.exact_initial_covariance',icov-rc*(eps**2*B0*B0.T)*rc.T);ck('realization.weak_bounds',worst<=S.Rational(1,100),str(worst));data.append({'background':{str(key):str(v) for key,v in q.items()},'common_amplitude':str(eps),'largest_dimensionless_amplitude':str(worst),'output_covariance':str(cov),'initial_covariance':str(icov)})
 # Small-radiation and high-p obstruction to uniform fixed-amplitude realization.
 monopole=-(p*p*W+rm*de+3*H*rm*th/p**2)/(4*rr)
 zero('limits.inverse_radiation_scaling',S.diff(monopole,rr)+monopole/rr)
 ck('limits.high_p_fixed_W_unbounded',S.limit(monopole.subs({W:1,de:0,th:0,rr:1}),p,S.oo)==-S.oo)
 result={'scope':'Exact algebra and bounded synthetic initial data, no orbit/observational fit or state selector.','passed':sum(r['ok'] for r in rows),'failed':sum(not r['ok'] for r in rows),'checks':rows,'bounded_realizations':data};(out/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));raise SystemExit(bool(result['failed']))
if __name__=='__main__':main()
