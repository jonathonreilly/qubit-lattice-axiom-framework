# A bounded homogeneous isotropic local witness

This addendum strengthens only the local covariance counterexample, not a
cosmic history or observation fit. Use the same fixed positive-p origin event,
T0 and R0=T0^{-1} as ../DERIVATION_v2.md. Let a real symmetric PSD output
matrix S0 have a real finite factor B B^T=S0. Let Z have independent centered
Rademacher coordinates with E[ZZ^T]=I, Phi be uniform on[0,2pi), and n be
uniform on the unit sphere, all independent. At physical position x define

    Y(x)=sqrt(2) epsilon B Z cos(p n.x+Phi),
    X(x)=R0 Y(x).                                      (1)

All components are real and bounded. Uniform phase gives zero mean and

    E_Phi[2 cos(p n.x+Phi)cos(p n.y+Phi)]
      =cos[p n.(x-y)].

Uniform direction then gives, for r=|x-y|,

    E[Y(x)Y(y)^T]=epsilon^2 S0 sin(pr)/(pr),            (2)

with limit1 at r=0. More than second-moment invariance holds: translating all
positions just shifts the uniform phase conditional on n; rotation or parity
changes the uniform direction. Thus the ensemble has homogeneous, isotropic,
parity-invariant finite-dimensional distributions. This supplies an explicit
allowed ensemble; it does not prove that observations select it. It is a
monochromatic-shell example, not a broadband measured spectrum or ergodicity
claim. Its special realization structure need not represent sky statistics.

The linear Hamiltonian constraint and readout map hold for every realization
because all scalar components share the same Laplacian eigenvalue -p^2 and
T0 is independent of direction. For the velocity output theta(x)=A_theta
cos(p n.x+Phi), choose physical peculiar velocity

    v(x)=A_theta n sin(p n.x+Phi)/p.

Its physical divergence is theta(x). Its amplitude is bounded by
|A_theta|/p. The scalar background still has the unselected origin event and
subsequent dust-driven acceleration; the perturbations still evolve and
produce higher radiation angular moments. This is not a permanent perfect
fluid or static metric solution.

For every realization, row l1 norms bound |BZ| and |R0 BZ|. A sufficiently
small common epsilon makes |W|, |n_m|, |4Theta0| and |theta|/p less than a
fixed small eta. In particular it keeps dust and radiation density positive.
Relative to the earlier eight-sign construction, reduce epsilon by sqrt(2)
to preserve the same1/100 worst-case margin. The target covariance then has
the correspondingly reduced amplitude; arbitrary fixed observed amplitudes
are not claimed feasible. The neighborhood remains nonuniform as radiation
vanishes or p approaches zero/infinity.

Equations(1)-(2) show that homogeneous/isotropic/parity symmetry alone does
not restore unique initial covariance or scalar couplings in this local
counterexample. A particular P, observed spectrum, ensemble statistics,
ergodicity, earlier history and physical calibration are not derived. A
real survey requires its actual windows, noise and evolution; none is fit here.
