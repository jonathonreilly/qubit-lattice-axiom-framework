import argparse,json,pathlib,itertools
import sympy as S
ap=argparse.ArgumentParser();ap.add_argument('--output',required=True);out=pathlib.Path(ap.parse_args().output);out.mkdir(parents=True,exist_ok=False);rows=[]
def zero(n,e):
 v=S.simplify(S.trigsimp(e));rows.append({'name':n,'ok':bool(v==0),'residual':str(v)})
def ck(n,b):rows.append({'name':n,'ok':bool(b)})
f,a,b=S.symbols('f a b',real=True)
zero('phase.zero_mean',S.integrate(S.cos(a+f),(f,0,2*S.pi)))
zero('phase.cross_covariance',S.integrate(2*S.cos(a+f)*S.cos(b+f),(f,0,2*S.pi))/(2*S.pi)-S.cos(a-b))
u=S.symbols('u',real=True);z=S.symbols('z',positive=True);sphere=S.integrate(S.cos(z*u),(u,-1,1))/2
zero('sphere.isotropic_kernel',sphere-S.sin(z)/z);zero('sphere.equal_point_limit',S.limit(sphere,z,0)-1)
zero('phase.translation_invariance',S.cos((a+f)-(b+f))-S.cos(a-b));zero('sphere.parity_invariance',S.cos(z*u)-S.cos(-z*u))
x,y,w=S.symbols('x y w',real=True);p,A=S.symbols('p A',positive=True);n=S.Matrix([S.Rational(2,3),S.Rational(-1,3),S.Rational(2,3)]);pos=S.Matrix([x,y,w]);phase=p*n.dot(pos)+f;vel=A*n*S.sin(phase)/p
zero('velocity.physical_divergence',sum(S.diff(vel[j],pos[j]) for j in range(3))-A*S.cos(phase));zero('spatial.mode_eigenvalue',sum(S.diff(S.cos(phase),t,2) for t in pos)+p*p*S.cos(phase));zero('velocity.unit_direction',n.dot(n)-1)
B=S.Matrix([[1,2,0],[0,1,1],[1,0,3]]);H=S.Rational(1);rm=S.Rational(3,4);rr=S.Rational(3,8);pv=S.Rational(5,3);R=S.Matrix([[0,0,1],[0,1,0],[-pv**2/(4*rr),-3*H*rm/(4*rr*pv**2),-rm/(4*rr)]]);load=R*B;scales=[sum(abs(q) for q in load.row(0)),sum(abs(q) for q in load.row(1))/pv,4*sum(abs(q) for q in load.row(2)),sum(abs(q) for q in B.row(0))];eps=1/(100*S.sqrt(2)*max(scales));G=S.zeros(3)
for sign in itertools.product([-1,1],repeat=3):
 Z=S.Matrix(sign);am=S.sqrt(2)*eps*B*Z;initial=R*am;G+=am*am.T/16
 ck('bounded.every_sign',max(abs(initial[0]),4*abs(initial[2]),abs(initial[1])/pv,abs(am[0]))<=S.Rational(1,100))
 zero('constraint.every_sign',pv*pv*am[0]+rm*initial[0]+4*rr*initial[2]+3*H*rm*initial[1]/pv**2)
for j in range(3):
 for k in range(3):zero('covariance.phase_signs_'+str(j)+str(k),(G-eps**2*B*B.T)[j,k])
r={'scope':'Exact phase/sphere integration and bounded local initial-data realization. No actual survey, ergodicity, evolution or state-selection inference.','passed':sum(x['ok'] for x in rows),'failed':sum(not x['ok'] for x in rows),'checks':rows,'epsilon':str(eps),'S0':str(B*B.T)};(out/'RESULTS.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));raise SystemExit(bool(r['failed']))
