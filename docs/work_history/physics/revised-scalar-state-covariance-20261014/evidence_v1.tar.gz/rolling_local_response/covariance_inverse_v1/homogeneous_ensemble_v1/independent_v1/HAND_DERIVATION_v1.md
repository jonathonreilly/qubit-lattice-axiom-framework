# Independent derivation before executable construction

This is a separate check of the bounded homogeneous ensemble. Scientific authorship remains with /root. The new derivation and protocol and the parent covariance v2 have been read in full. No producer code or output has been read. The main independent map/constraint review is reused by exact receipt, report and manifest identity, with every one of its 56 manifest artifacts and eight live/source pairs verified without alteration or rerun.

## Ensemble and second moments

Let B be a finite real m-by-d matrix, S0=B B^T, Z uniform on {-1,+1}^d with independent coordinates, Phi uniform on the circle, and n uniform on S^2. These variables are mutually independent. Set q(x)=p n dot x+Phi with fixed p>0, and Y(x)=sqrt(2) epsilon BZ cos q(x). The scalar output channels W, theta_J and Delta_m,J are rotational scalars; theta is a velocity divergence, not a component of velocity.

For fixed n,Z, integration over Phi gives E cos q=0 and

    2 E_Phi[cos q(x) cos q(y)]=cos[p n dot (x-y)].

This uses the actual normalized circle measure dPhi/(2pi). Averaging ZZ^T=I yields epsilon^2 S0 times that cosine. Choosing the polar axis along x-y, the normalized sphere measure makes mu=cos(theta) uniform on [-1,1]. Hence

    E_n cos(p n dot r) = (1/2) integral_-1^1 cos(p |r| mu) dmu
                       = sin(p|r|)/(p|r|),

with continuous limit one at r=0. The exact real covariance is therefore epsilon^2 S0 sinc(p|x-y|). Negative sinc values at some separations do not violate covariance positivity: for any finite vectors a_j the kernel quadratic form is the nonnegative expectation of (sum_j a_j dot Y(x_j))^2. Equivalently its spectral measure is a positive matrix-valued measure supported on |q|=p. S0 may be singular or zero; no strict positivity is required.

## Full finite-dimensional laws

For any finite list of locations and any translation h, q(x_j+h)=p n dot x_j+(Phi+p n dot h). Conditional on n,Z, the shifted phase is still uniform modulo 2pi. Indeed, independence is retained because every conditional phase law is the same normalized circle measure. This is a measure-preserving coupling of the entire finite list, not merely a covariance identity.

For any O in O(3), n dot O x=(O^T n) dot x. The transformed n'=O^T n is uniform on S^2 and independent of Phi,Z. This proves the full scalar-channel joint law invariant under rotations and improper orthogonal transformations, including parity. It does not require a Gaussian distribution or an orthogonally invariant distribution of the channel amplitude BZ.

The physical velocity derived below obeys V(O x;n)=O V(x;O^T n). Thus the joint scalar/vector distribution has the correct polar-vector covariance under rotations and parity. The velocity is not to be treated as a scalar channel.

## Velocity and constraints on the initial slice

The x in this construction is physical position at the declared origin event, where C=A^2=1. Define

    V(x) = A_theta n sin(p n dot x+Phi)/p,
    theta(x)=A_theta cos(p n dot x+Phi).

Then div_x V=A_theta |n|^2 cos q=theta and curl_x V=0, with |V|<=|A_theta|/p. There is no omitted scale factor when differentiating with respect to physical position at this slice. If instead using comoving coordinates, the physical derivative and wave number must both be converted. A later-time evolution tracks the same comoving mode; this construction does not fix its physical wavelength for all times.

Reuse the checked initial map at phi=dot(phi)=xi=pi_scalar=0, positive Rm,Rr, and H^2=Hv^2+2(Rm+Rr)/3:

    T0=[[-Rm/p^2,-3H Rm/p^4,-4Rr/p^2], [0,1,0], [1,0,0]],
    R0=[[0,0,1], [0,1,0], [-p^2/(4Rr),-3H Rm/(4Rr p^2),-Rm/(4Rr)]].

For X=R0 Y, n_m=Y_3, theta=Y_2 and the radiation monopole is fixed by

    p^2 W+Rm n_m+4Rr Theta0+3H Rm theta/p^2=0.

All spatial components share the same Laplacian eigenvalue -p^2. Thus this amplitude identity and T0 X=Y hold pointwise for every realization, including every phase and direction. The corresponding initial lapse equals W (zero shear), and the momentum constraint supplies Wdot=-H W+Rm theta/p^2. Setting xi=pi=0 does not set those derivatives or the radiation dipole derivative to zero.

The main seal already checks the initial propagation identity and local kinetic evolution. Here that result is reused by identity, not repeated. The initially isotropic angular radiation perturbation is a monopole in particle-direction space; that is distinct from the random direction of the spatial wave. Later transport generally creates angular multipoles. The background scalar is accelerated by dust. This is initial-data and local-solution compatibility, not a stationary background, static perturbation or permanent perfect-fluid radiation approximation.

## Uniform weak bound

For every Rademacher seed, |(BZ)_i|<=||B_i||_1, and similarly for R0B. Define

    M=max{||B_W||_1, ||(R0 B)_n||_1,
          4||(R0 B)_Theta0||_1, ||B_theta||_1/p}.

For M>0, any 0<epsilon<eta/(sqrt(2) M) guarantees |W|, |n_m|, |4Theta0| and |V|<eta for every x,Z,Phi,n. At M=0 the ensemble is identically zero. Taking eta<1 ensures positive initial dust number/energy density and radiation brightness for an initially positive base population with this bounded fractional modulation. This does not certify every phase-space realization, nonlinear evolution or arbitrary observed amplitude.

Because the latent variables range over a compact set (finite Z, circle and sphere) and fixed-p linear evolution has bounded local coefficients, strict weak margins can persist on a common sufficiently short interval; neither that interval nor the margin is uniform in singular limits. The actual proof reused is the earlier local linear compatibility result. Rr->0, p->0 and p->infinity can make R0 or the velocity conversion badly conditioned.

The source's epsilon/sqrt(2) statement is a safe sufficient scaling of the earlier coefficient-level Y=epsilon_old BZ convention: the new real-field amplitude sqrt(2) epsilon_new BZ then equals epsilon_old BZ. The main independent earlier conjugate-pair realization had a further factor two, so this scaling is conservative against that particular real-field bound. It must not be interpreted as preserving an arbitrary measured covariance amplitude. The source explicitly reduces the target covariance.

## Independently chosen exact witness

Use k=2/13, nu=9/7, Q0=13/10, Q=3/2; Hv=1/2, H=3/2, Rm=5/4, Rr=7/4 and p=5/2. The background Friedmann relation is exact. Choose the distinct rank-two factor

    B=[[1,2],[2,-1],[1/2,3/2]],
    epsilon=1/(10000 sqrt(2)), so sqrt(2)epsilon=1/10000.

Enumerate the four Rademacher pairs. R0 B has monopole row (-347/280,-539/280). The worst spatial amplitudes are

    |W| <= 3/10000,
    |n_m| <= 1/5000,
    |V| <= 3/25000,
    |4Theta0| <= 443/350000.

All are strictly below 1/100. This explicit covariance is rank two and positive semidefinite, showing that singular S0 is allowed. Each seed will be checked against the constraint and inverse, and all phase/direction integrations are exact.

For Z=(1,1), the reused initial derivative formula gives Theta1dot=-23/1680000 and pi_dot/b=-1/1000. This is a direct nonstatic witness, not another kinetic-system review.

## What this construction does not identify

The spatial covariance has the fixed shell shape sinc(pr). A free finite matrix S0 changes channel covariance, not the radial spectrum. This is not an arbitrary covariance function or observed survey spectrum. A generic realization is anisotropic and nonergodic. In the distinct example, spatial averaging over expanding balls gives Y_W^2 -> epsilon^2 (Z1+2Z2)^2, which is either 9 epsilon^2 or epsilon^2, while the ensemble variance is 5 epsilon^2. Thus even a simple spatial average need not recover the ensemble moment. Translation also leaves the realization's spatial wave axis unchanged.

Homogeneity/isotropy/parity are properties of the ensemble law, not a requirement that each realization have those symmetries. The fourth moment is generally non-Gaussian; boundedness already prevents a nondegenerate Gaussian one-point law. No ergodicity, broadband spectrum, primordial state, actual sky likelihood, full history or calibrated parameter degeneracy follows. The source explicitly states these limits. Independent background/calibration or fixed-amplitude restrictions remain operative exactly as in the main seal.

## Planned changed-formula controls

The own executable will be copied and actually changed: remove the sqrt(2) normalization; reverse the physical velocity sign; replace normalized uniform-solid-angle measure by uniform polar-angle measure. Required witnesses are respectively equal-point covariance, divergence, and directional isotropy/shell kernel. A nonuniform phase example will separately expose translation failure without weakening the true construction. These are checks of my implementation, not unread producer code. Every run and failure will be preserved.
