# Independent bounded homogeneous ensemble check

The construction has the stated zero mean and exact shell covariance, and its complete finite-dimensional distributions are translation-, rotation- and parity-invariant. The physical velocity has the correct divergence. Applying the previously checked direction-independent inverse gives valid initial constraints for each realization, and finite row norms give a uniform weak-amplitude bound over all seeds, phases, directions and positions. No source correction was identified.

This is a possible local linear ensemble. It selects neither an initial state nor scalar couplings. Its spectrum is supported on one wave-number shell, and a single realization need not reproduce its ensemble moments. The report below makes that limitation exact rather than treating ensemble symmetry as an ergodicity or survey-fit statement.

The one independent baseline passed 109 exact controls. Three actual changed-formula copies were executed and rejected by their intended witnesses. There were no unexpected failures or repairs. Scientific authorship remains with /root; this is a focused check, not a formal audit.

## Sources, ordering and reuse

The following sources were read completely and frozen before constructing the new executable:

| Source | SHA-256 |
| --- | --- |
| homogeneous_ensemble_v1/DERIVATION_v1.md | 007496f50c0346781f7923ca622f744deb372f1b73067645d1cf5352cf9e2355 |
| homogeneous_ensemble_v1/PROTOCOL_v1.json | 80d03b19bbdec65cac6d03029c21172d5864f3ebd6afb6bcda5fca20bc91ba10 |
| covariance_inverse_v1/DERIVATION_v2.md | d10a1d93cf48b0f8a22fa01ce8a11e97118b2268e2683de84f5e14f44c33f8aa |

The main instantaneous-map review is reused by exact identity:

| Sealed main artifact | SHA-256 |
| --- | --- |
| RECEIPT_v1.json | 4fd52eb3973d02cffc714e8806faba80a90515cde23f46c5685a40640c8f92f3 |
| REPORT_v1.md | 1202ba0c2285c5d6b07a569a669044b57dbc8830f9c229074880be454ea82bba |
| MANIFEST_v1.json | d6226a8794ab6762dbdb67e41570a7b29669c9653615a2087ad22bb93df25ff7 |

Every one of the main manifest's 56 artifacts, its exact 58-file inventory, and all eight live/source pairs were verified read-only. The new directory includes immutable copies of the three main seal artifacts and a detailed identity-verification record. The main seal explicitly excluded this follow-on and remains unchanged. Its prior 98/0 science run is reused evidence, not a new run or a result of this follow-on.

In particular, the previously checked action normalization, origin-event background, kinetic radiation equations, initial Einstein map and first constraint-propagation derivative are reused. The underlying canonical action hash is 39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000, and the kinetic source v3 hash is 4fec305653d9e51a4cf1ccbffb2914574c55c41732f6a46624b16535ed23102a. This receipt does not repeat that complete science review.

The independent hand derivation and protocol preceded the new code. The background, factor B and four Rademacher seeds are distinct from the main independent example. No producer implementation, producer results, trajectories or empirical data were read. The new observations below are mathematical consequences of the exposed source, not blind empirical evidence.

## Mean and exact covariance

Write q(x)=p n dot x+Phi, with p>0 fixed. The source supplies independent variables: centered Rademacher coordinates Z, uniform phase Phi on the circle, and uniform direction n on S^2. For real finite B, the field is

    Y(x)=sqrt(2) epsilon BZ cos q(x), S0=B B^T.

Conditional on n and Z, the phase integral gives zero mean. The normalized phase product is

    E_Phi[cos q(x) cos q(y)]=cos[p n dot (x-y)]/2.

The factor sqrt(2) therefore matters: it cancels this 1/2. Rademacher independence gives E[ZZ^T]=I. The covariance after the phase and seed averages is epsilon^2 S0 cos[p n dot (x-y)].

For a uniform sphere direction, the polar variable mu=n dot r/|r| is uniform on [-1,1]. Hence

    E_n cos(p n dot r)=(1/2) integral_-1^1 cos(p |r| mu) dmu
                      =sin(p|r|)/(p|r|).

The removable value at r=0 is one. Thus the source's covariance is correct, including its normalization and zero-separation limit. Singular PSD S0 and the zero matrix are permitted.

The kernel may be negative at a separation without ceasing to be a positive-semidefinite covariance kernel. At p|r|=3pi/2 it is -2/(3pi). For arbitrary finite locations and channel coefficients, its quadratic form is the expectation of the square of a real linear combination of Y at those locations and is nonnegative. This proves the full kernel property; finite test matrices are only controls. Equivalently the spectral measure is positive and concentrated on |q|=p.

The independent executable computes the actual normalized phase integrals and sphere moments. Its sinc antiderivative is also directly differentiated against the implemented direction measure. This binding matters: a changed measure is not allowed to inherit the sinc formula merely because a separately entered expression still looks correct.

## Full joint distributions, including parity

For any finite list of positions and any translation h,

    p n dot (x_j+h)+Phi=p n dot x_j+(Phi+p n dot h).

Conditional on n and Z, adding p n dot h modulo 2pi preserves uniform phase. Because the conditional law remains the same circle measure for every n,Z, it remains independent of them. This is a measure-preserving coupling of the entire vector of field values at all chosen locations. It establishes full finite-dimensional homogeneity, not only a stationary two-point function.

For any orthogonal O, n dot O x=(O^T n) dot x. The uniform S^2 law is invariant under O^T, including det(O)=-1. Its independence from phase and seed is preserved. This proves isotropy and parity invariance of all scalar-channel joint distributions. No rotational invariance of BZ in channel space is needed: W, the velocity divergence and the density contrast are spatial scalars.

For the physical velocity vector defined below,

    V(O x;n)=O V(x;O^T n).

Consequently the joint scalar/vector field has the correct polar-vector transformation under rotations and parity. Treating velocity components as scalar observables would be a different claim. The code checks exact couplings at three independently selected rational positions for a proper rotation, a reflection and a translation; the general measure-preserving argument gives the quantifiers beyond those finite checks.

Uniform phase is substantive. If it is fixed to zero while directions remain uniform, the equal-point covariance at a point of radius r is proportional to [1+sinc(2pr)]/2. It differs between the origin and pr=pi/2, so that altered ensemble is not translation invariant. Rademacher centering alone would still give zero mean and would not repair that failure.

## Physical velocity and initial constraints

The construction uses physical position on the specified origin slice, where the conformal factor C=A^2=1. For a divergence amplitude A_theta, take

    theta(x)=A_theta cos(p n dot x+Phi),
    V(x)=A_theta n sin(p n dot x+Phi)/p.

Direct differentiation gives div_x V=theta because |n|=1, and curl_x V=0. Its speed is bounded by |A_theta|/p. The sign in the source is correct. There is no missing scale factor in a physical-coordinate derivative on this slice. In comoving coordinates the derivative and wave number must both be converted; subsequent evolution follows the same comoving mode and does not keep p physically fixed at every time.

At the already checked origin event, the background obeys

    H^2=Hv^2+2(Rm+Rr)/3,

with positive Rm,Rr, and the scalar background and perturbation velocities initially vanish. Zero initial radiation shear gives the two metric potentials equal. The constrained map is

    Y=(W,theta_J,Delta_m,J), X=(n_m,theta,Theta0),
    T0=[[-Rm/p^2,-3H Rm/p^4,-4Rr/p^2], [0,1,0], [1,0,0]],
    R0=[[0,0,1], [0,1,0], [-p^2/(4Rr),-3H Rm/(4Rr p^2),-Rm/(4Rr)]].

Each realization of X=R0Y satisfies T0X=Y and

    p^2 W+Rm n_m+4Rr Theta0+3H Rm theta/p^2=0.

All scalar fields share the Laplacian eigenvalue -p^2, and T0 has no direction dependence. Thus the amplitude constraint is a pointwise real-space constraint for every phase and direction, not just an ensemble-averaged condition. The momentum constraint supplies Wdot=-H W+Rm theta/p^2. The physical density contrast here is the declared Newtonian-gauge matter contrast at this slice, not automatically an observed galaxy field or a gauge-invariant comoving-density variable.

The source correctly retains subsequent evolution. The background scalar is accelerated by dust, and the initially isotropic radiation angular perturbation generally generates a dipole and higher moments. The random direction of a spatial plane wave is distinct from the particle-direction argument of the radiation distribution. Setting its initial angular multipoles to zero does not make collisionless radiation a permanent perfect fluid.

The main sealed local kinetic compatibility and constraint propagation are reused by identity. This follow-on checks the new realization map and its spatial velocity, without repeating a full kinetic-system proof or a history calculation. It remains a linear initial-data/local-solution statement. Exact nonlinear constraints or second-order backreaction have not been certified.

## Uniform bounds and distinct rational control

For every seed, each row of BZ is bounded by the row's l1 norm. The same applies to R0BZ. Define

    M=max{||B_W||_1, ||(R0B)_n||_1,
          4||(R0B)_Theta0||_1, ||B_theta||_1/p}.

For M>0, any epsilon<eta/(sqrt(2) M) makes |W|, |n_m|, |4Theta0| and the physical speed less than eta simultaneously for every seed, phase, direction and position. M=0 gives the identically zero ensemble. Taking eta<1 gives positive initial density and brightness when applied to positive background populations. The construction can use a small bounded fractional brightness modulation; it does not certify every microscopic spectral distribution or impose a unique thermal state.

The independently chosen example is

    k=2/13, nu=9/7, Q0=13/10, Q=3/2,
    Hv=1/2, H=3/2, Rm=5/4, Rr=7/4, p=5/2,
    B=[[1,2],[2,-1],[1/2,3/2]], epsilon=1/(10000 sqrt(2)).

The Friedmann relation holds exactly. S0=B B^T is rank-two PSD with null vector (7,-1,-10). All four independent Rademacher pairs are enumerated. R0 has final row (-25/28,-9/70,-5/28), and R0B has monopole row (-347/280,-539/280), with the latter's second entry also equal to -77/40.

| Quantity | Exact worst-case amplitude |
| --- | --- |
| Metric potential | 3/10000 |
| Dust contrast | 1/5000 |
| Physical speed | 3/25000 |
| Radiation brightness contrast | 443/350000 |

All are strictly below the synthetic margin 1/100. This margin is a supplied smallness example, not an observational accuracy threshold. Every seed exactly satisfies the Hamiltonian constraint and reconstructs the three readouts. The equal-point covariance is epsilon^2 S0, and the reconstructed covariance is epsilon^2 R0S0R0^T.

For the all-positive seed, the previously checked initial rate formulas give Theta1dot=-23/1680000 and pi_scalar_dot/b=-1/1000. These explicit nonzero values reject a static interpretation. They are one reuse of the existing rate identities, not a new full evolution run.

The source's proposed epsilon/sqrt(2) reduction is algebraically sufficient against a coefficient-level earlier field epsilon_old BZ: sqrt(2) epsilon_new=epsilon_old. Against the main independent check's conjugate-pair real-field convention, which had a further factor two, it is conservative. No earlier producer implementation or numerical bound was inspected here. The rescaling reduces the covariance amplitude and is not a claim of feasibility at a fixed observed amplitude.

For a fixed positive p and Rr all row bounds are finite. They are not uniform as Rr->0, p->0 or p->infinity. The p->0 velocity conversion and inverse momentum term remain material. On a sufficiently short regular interval, the reused bounded linear evolution and the compact latent-variable set can preserve strict initial weak margins; no uniform interval at singular limits or all-history result follows.

## Shell spectrum and nonergodic realization

Changing S0 changes the channel covariance matrix; it does not change the radial sinc shape or create a broadband spectrum. The construction is a monochromatic-shell ensemble. It is not an arbitrary prescribed covariance function, a finite-energy localized source, a set of actual survey windows, or a likelihood for a sky realization.

The distinction from ergodicity is concrete in this example. For a single seed and direction, the spatial average over expanding balls satisfies

    average_x Y_W(x)^2 -> epsilon^2 (Z1+2Z2)^2.

The oscillatory correction decays because the normalized ball Fourier factor is 3(sin t-t cos t)/t^3, bounded by 3(1+t)/t^3. The limiting variance is either epsilon^2 or 9 epsilon^2, each with probability one half, whereas the ensemble variance is 5 epsilon^2. The full spatial-average covariance for each realization is rank one, while the ensemble S0 is rank two. This gives an explicit failure of the spatial average to reproduce the ensemble moment. The wave axis is also unchanged by translations of an individual realization.

Full ensemble symmetry therefore does not imply symmetric individual realizations or an ergodic field. The bounded distribution is also generally non-Gaussian: in this example E[(Z1+2Z2)^4]=41, and the W fourth-moment defect from the Gaussian value is -27 epsilon^4/2. None of these facts invalidates the source's stated possibility claim; the source expressly excludes ergodicity and sky representativeness.

The constructed ensemble does not select the covariance or scalar couplings. It gives conditional local feasibility for a class with freely supplied state covariance and an unselected origin background event. Independently known physical background densities, calibration, amplitude restrictions, evolution, survey projections and cross-time support can still constrain the parameters. No actual observed amplitude, state-preparation mechanism, cosmic history or fitted survey is inferred.

## Executed controls and preserved failures

The independent code SHA-256 is 45fdcb58ed226200f992d5738f382b40605cb2e21b2be2d7c12153eb51fa33d2. Its baseline completed 109 passed / 0 failed under Python 3.12.8 and Sympy 1.14.0; the result SHA-256 is 193c8d061a8a397c4d0f84f6e1530ead9c8d9b145a8d88d844942fce8155dbbc.

| Actual source-copy alteration | Result | Mathematical witness |
| --- | --- | --- |
| Replace sqrt(2) field normalization by 1 | 100 passed / 9 failed, exit 1 | Phase covariance is too small by 1/2; equal-point covariance fails |
| Reverse the physical velocity sign | 108 passed / 1 failed, exit 1 | div V-theta=-2 A_theta cos q |
| Replace sin(theta)/2 polar density by uniform 1/pi | 101 passed / 8 failed, exit 1 | E[n_z^2]=1/2 instead of 1/3; sinc antiderivative no longer matches the actual measure |

The changed copies, exact diffs, protocols, execution arguments, code hashes, stdout/stderr, complete check results and failure witnesses are preserved. These are damage controls of the independent implementation, not tests of unread producer code. The total count includes repeated sample identities and bookkeeping; the written derivation supplies the general symmetry, covariance positivity and boundedness quantifiers.

No source or code repair was needed, no failed run was overwritten, and no main evidence was expanded. All writes for this unit are confined to the new homogeneous_ensemble_v1/independent_v1 directory. No git, PR, runtime, lock, formal audit or authority state was changed.
