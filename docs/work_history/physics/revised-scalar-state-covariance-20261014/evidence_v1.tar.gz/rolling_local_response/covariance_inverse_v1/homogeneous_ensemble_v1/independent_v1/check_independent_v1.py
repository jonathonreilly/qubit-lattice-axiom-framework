"""Independent exact ensemble controls; reads no producer source or output."""
from pathlib import Path
import argparse,datetime,hashlib,itertools,json,platform,sys
import sympy as s

parser=argparse.ArgumentParser()
parser.add_argument('--output',required=True)
args=parser.parse_args()
out=Path(args.output)
out.mkdir(parents=True,exist_ok=True)
R=s.Rational
checks=[]
witnesses={}

def simp(v):
    return s.trigsimp(s.simplify(v))

def zero(v):
    if isinstance(v,s.MatrixBase):return all(simp(e)==0 for e in v)
    return simp(v)==0

def eq(name,actual,expected=0):
    residual=actual-expected
    ok=zero(residual)
    checks.append({'name':name,'passed':bool(ok),'actual':str(actual),'expected':str(expected),'residual':str(residual.applyfunc(simp) if isinstance(residual,s.MatrixBase) else simp(residual))})

def truth(name,value,detail):
    checks.append({'name':name,'passed':bool(value),'detail':str(detail)})

# Mutation targets affect the actual implemented fields or integration measure.
field_normalization = s.sqrt(2)
velocity_sign = s.Integer(1)
polar=s.symbols('polar',real=True)
polar_density = s.sin(polar)/2

phase,alpha,beta=s.symbols('phase alpha beta',real=True)
phase_mean=s.integrate(s.cos(phase+alpha),(phase,0,2*s.pi))/(2*s.pi)
phase_product=s.integrate(s.expand_trig(s.cos(phase+alpha)*s.cos(phase+beta)),(phase,0,2*s.pi))/(2*s.pi)
phase_square=s.integrate(s.cos(phase)**2,(phase,0,2*s.pi))/(2*s.pi)
phase_fourth=s.integrate(s.cos(phase)**4,(phase,0,2*s.pi))/(2*s.pi)
eq('phase.zero_mean',phase_mean)
eq('phase.unit_normalization',s.integrate(1,(phase,0,2*s.pi))/(2*s.pi),1)
eq('phase.covariance_normalization',field_normalization**2*phase_product,s.cos(alpha-beta))
eq('phase.square',phase_square,R(1,2))
eq('phase.fourth',phase_fourth,R(3,8))

polar_norm=s.integrate(polar_density,(polar,0,s.pi))
m2=s.integrate(s.cos(polar)**2*polar_density,(polar,0,s.pi))
m4=s.integrate(s.cos(polar)**4*polar_density,(polar,0,s.pi))
eq('sphere.normalized_measure',polar_norm,1)
eq('sphere.second_moment_z',m2,R(1,3))
eq('sphere.second_moment_x',(1-m2)/2,R(1,3))
eq('sphere.fourth_moment_z',m4,R(1,5))
eq('sphere.mixed_fourth_moment',(m2-m4)/2,R(1,15))
eq('sphere.fourth_moment_x',R(3,8)*(1-2*m2+m4),R(1,5))
mu=s.symbols('mu',real=True)
a=s.symbols('a',positive=True)
mu_density=s.simplify(polar_density.subs(polar,s.acos(mu))/s.sqrt(1-mu**2))
primitive=s.sin(a*mu)/(2*a)
eq('sphere.kernel_primitive_matches_actual_measure',s.diff(primitive,mu),s.cos(a*mu)*mu_density)
kernel=s.simplify(primitive.subs(mu,1)-primitive.subs(mu,-1))
eq('sphere.shell_kernel',kernel,s.sin(a)/a)
eq('sphere.zero_separation_limit',s.limit(kernel,a,0),1)
eq('sphere.kernel_quadratic_coefficient',-m2/2,-R(1,6))
eq('sphere.kernel_quartic_coefficient',m4/24,R(1,120))
# The last kernel identity is valid for the actual measure only if the binding
# above passes. An altered measure must not inherit the antiderivative claim.

k,nu,Q0=R(2,13),R(9,7),R(13,10)
Q=Q0*(1+k)
Hv,H,Rm,Rr,p=R(1,2),R(3,2),R(5,4),R(7,4),R(5,2)
eq('background.Q',Q,R(3,2))
eq('background.Friedmann',H**2,Hv**2+R(2,3)*(Rm+Rr))
truth('background.domain',0<k<R(1,3) and nu>0 and Rm>0 and Rr>0 and p>0,'k=2/13, nu=9/7, Rm=5/4, Rr=7/4, p=5/2')
B=s.Matrix([[1,2],[2,-1],[R(1,2),R(3,2)]])
S=B*B.T
R0=s.Matrix([[0,0,1],[0,1,0],[-p**2/(4*Rr),-3*H*Rm/(4*Rr*p**2),-Rm/(4*Rr)]])
T0=s.Matrix([[-Rm/p**2,-3*H*Rm/p**4,-4*Rr/p**2],[0,1,0],[1,0,0]])
RB=R0*B
eq('map.right_inverse',T0*R0,s.eye(3))
eq('map.left_inverse',R0*T0,s.eye(3))
eq('map.determinant',T0.det(),4*Rr/p**2)
eq('covariance.factor_value',S,s.Matrix([[5,0,R(7,2)],[0,5,-R(1,2)],[R(7,2),-R(1,2),R(5,2)]]))
truth('covariance.singular_PSD',S.is_positive_semidefinite is True and S.rank()==2 and B.rank()==2,str(S))
eq('covariance.null_direction',S*s.Matrix([7,-1,-10]),s.zeros(3,1))
eq('map.monopole_row',RB[2,:],s.Matrix([[-R(347,280),-R(539,280)]]))

epsilon=1/(10000*s.sqrt(2))
amp=s.simplify(field_normalization*epsilon)
eta=R(1,100)
seeds=[s.Matrix(z) for z in itertools.product([-1,1],repeat=2)]
EZ=sum(seeds,s.zeros(2,1))/len(seeds)
EZZ=sum((z*z.T for z in seeds),s.zeros(2))/len(seeds)
eq('seeds.centered',EZ,s.zeros(2,1))
eq('seeds.identity_covariance',EZZ,s.eye(2))
EY=sum((B*z for z in seeds),s.zeros(3,1))/len(seeds)
EC=sum(((B*z)*(B*z).T for z in seeds),s.zeros(3))/len(seeds)
eq('seeds.correlated_factor_covariance',EC,S)
eq('seeds.correlated_factor_mean',EY,s.zeros(3,1))
point_cov=s.simplify(field_normalization**2*epsilon**2*phase_square)*EC
eq('covariance.equal_point',point_cov,epsilon**2*S)
eq('covariance.reconstructed_equal_point',R0*point_cov*R0.T,epsilon**2*RB*RB.T)

l1=lambda row:sum(abs(v) for v in row)
bounds={'W':amp*l1(B[0,:]),'n_m':amp*l1(RB[0,:]),'speed':amp*l1(B[1,:])/p,'radiation_contrast':4*amp*l1(RB[2,:])}
expected={'W':R(3,10000),'n_m':R(1,5000),'speed':R(3,25000),'radiation_contrast':R(443,350000)}
for name,value in bounds.items():
    eq('bounds.exact_'+name,value,expected[name])
    truth('bounds.weak_'+name,0<value<eta,str(value))
truth('bounds.dust_positive',1-bounds['n_m']>0,str(1-bounds['n_m']))
truth('bounds.radiation_positive',1-bounds['radiation_contrast']>0,str(1-bounds['radiation_contrast']))
M=max(l1(B[0,:]),l1(RB[0,:]),4*l1(RB[2,:]),l1(B[1,:])/p)
eq('bounds.max_row_factor',M,R(443,35))
truth('bounds.epsilon_below_uniform_threshold',epsilon<eta/(s.sqrt(2)*M),str(eta/(s.sqrt(2)*M)))

sample_records=[]
spatial_outer=[]
for i,z in enumerate(seeds):
    ya=amp*B*z
    xa=R0*ya
    W,theta,nm=ya
    monopole=xa[2]
    ch=p**2*W+Rm*nm+4*Rr*monopole+3*H*Rm*theta/p**2
    f=-H*W+Rm*theta/p**2
    eq(f'seed{i}.readout',T0*xa,ya)
    eq(f'seed{i}.Hamiltonian',ch)
    eq(f'seed{i}.momentum',f+H*W,Rm*theta/p**2)
    truth(f'seed{i}.uniform_bound',abs(W)<=bounds['W'] and abs(nm)<=bounds['n_m'] and abs(theta)/p<=bounds['speed'] and abs(4*monopole)<=bounds['radiation_contrast'],str(ya))
    outer=s.simplify(amp**2/2)*(B*z)*(B*z).T
    truth(f'seed{i}.spatial_outer_rank_one',outer.rank()==1,str(outer))
    spatial_outer.append(outer)
    sample_records.append({'Z':str(z),'Y_amplitude':str(ya),'X_amplitude':str(xa),'Wdot_amplitude':str(f),'Hamiltonian_residual':str(ch),'spatial_average_outer':str(outer)})
allplus=seeds[-1]
yplus=amp*B*allplus
xplus=R0*yplus
eq('initial.nonzero_dipole_derivative',p*(xplus[2]+yplus[0])/3,-R(23,1680000))
eq('initial.nonzero_scalar_acceleration_coefficient',-Rm*(xplus[0]+2*yplus[0]),-R(1,1000))

xx,yy,zz=s.symbols('xx yy zz',real=True)
pos=s.Matrix([xx,yy,zz])
direction=s.Matrix([R(2,7),-R(3,7),R(6,7)])
A=s.symbols('A',real=True)
def field_phase(x,n,ph):return s.expand(p*n.dot(x)+ph)
def velocity(x,n,ph):return velocity_sign*A*n*s.sin(field_phase(x,n,ph))/p
q=field_phase(pos,direction,phase)
vel=velocity(pos,direction,phase)
div=sum(s.diff(vel[i],pos[i]) for i in range(3))
curl=s.Matrix([s.diff(vel[2],yy)-s.diff(vel[1],zz),s.diff(vel[0],zz)-s.diff(vel[2],xx),s.diff(vel[1],xx)-s.diff(vel[0],yy)])
eq('velocity.unit_direction',direction.dot(direction),1)
eq('velocity.divergence',div,A*s.cos(q))
eq('velocity.curl',curl,s.zeros(3,1))
eq('field.laplacian',sum(s.diff(s.cos(q),u,2) for u in pos),-p**2*s.cos(q))
eq('velocity.norm_coefficient',velocity_sign**2*direction.dot(direction)/p**2,1/p**2)

h=s.Matrix([R(3,5),-R(2,7),R(4,9)])
locations=[s.Matrix([R(1,4),R(2,3),-R(1,2)]),s.Matrix([-R(3,2),R(1,5),R(2,7)]),s.Matrix([0,R(4,3),R(5,6)])]
for i,x in enumerate(locations):
    eq(f'joint.translation_phase_{i}',field_phase(x+h,direction,phase),field_phase(x,direction,phase+p*direction.dot(h)))
    eq(f'joint.translation_velocity_{i}',velocity(x+h,direction,phase),velocity(x,direction,phase+p*direction.dot(h)))
Oplus=s.Matrix([[0,1,0],[0,0,1],[1,0,0]])
Ominus=s.diag(-1,1,1)
for label,O in [('rotation',Oplus),('reflection',Ominus)]:
    eq('joint.'+label+'_orthogonal',O.T*O,s.eye(3))
    eq('joint.'+label+'_determinant',O.det(),1 if label=='rotation' else -1)
    for i,x in enumerate(locations):
        eq(f'joint.{label}_scalar_{i}',field_phase(O*x,direction,phase),field_phase(x,O.T*direction,phase))
        eq(f'joint.{label}_polar_velocity_{i}',velocity(O*x,direction,phase),O*velocity(x,O.T*direction,phase))
# These couplings illustrate exact identities; normalized Haar measure arguments
# in the handwritten proof give all translations and all orthogonal matrices.

negative_kernel=s.simplify(kernel.subs(a,3*s.pi/2))
eq('kernel.negative_correlation_allowed',negative_kernel,-2/(3*s.pi))
K=s.Matrix([[1,negative_kernel],[negative_kernel,1]])
truth('kernel.two_point_PSD_despite_negative_entry',K[0,0]>0 and K.det()>0,str(K.det()))
# Positive kernel in general follows from its direct random-field variance,
# not from entrywise positivity or finite matrix sampling.
t=s.symbols('t',positive=True)
ball_factor=3*(s.sin(t)-t*s.cos(t))/t**3
primitive_ball=-t*s.cos(t)+s.sin(t)
eq('nonergodic.ball_integral_derivative',s.diff(primitive_ball,t),t*s.sin(t))
eq('nonergodic.ball_zero_limit',s.limit(ball_factor,t,0),1)
eq('nonergodic.ball_bound_decay',s.limit(3*(1+t)/t**3,t,s.oo),0)
truth('nonergodic.distinct_spatial_variances',spatial_outer[0][0,0]!=spatial_outer[1][0,0],str([o[0,0] for o in spatial_outer]))
for i,outer in enumerate(spatial_outer):
    truth(f'nonergodic.seed{i}_differs_from_ensemble',outer[0,0]!=point_cov[0,0],str(outer[0,0]-point_cov[0,0]))
eq('nonergodic.ensemble_of_spatial_moments',sum(spatial_outer,s.zeros(3))/len(spatial_outer),point_cov)
Eamp4=sum((B*z)[0]**4 for z in seeds)/len(seeds)
eq('distribution.rademacher_W_fourth',Eamp4,41)
fourth=field_normalization**4*epsilon**4*phase_fourth*Eamp4
truth('distribution.nonGaussian_fourth_moment',s.simplify(fourth-3*point_cov[0,0]**2)!=0,str(s.simplify(fourth-3*point_cov[0,0]**2)))
# With a fixed phase 0 but uniform spatial direction, equal-point variance
# is proportional to (1+sinc(2pr))/2 and depends on distance to the origin.
fixed_phase_origin=field_normalization**2*epsilon**2*S
fixed_phase_at_halfpi=field_normalization**2*epsilon**2*S/2
truth('counterexample.nonuniform_phase_breaks_translation',fixed_phase_origin!=fixed_phase_at_halfpi,str(fixed_phase_origin-fixed_phase_at_halfpi))
# Algebraic epsilon rescaling, without inspecting an earlier producer run.
eps_old=s.symbols('eps_old',positive=True)
eq('scaling.sqrt_two_reduction',s.sqrt(2)*(eps_old/s.sqrt(2)),eps_old)
truth('scaling.conservative_against_paired_mode',eps_old<=2*eps_old,'Earlier independent real-pair convention had factor 2; this is a bound comparison, not equal covariance.')

witnesses.update({'background':{key:str(v) for key,v in [('k',k),('nu',nu),('Q0',Q0),('Q',Q),('Hv',Hv),('H',H),('Rm',Rm),('Rr',Rr),('p',p)]},'B':str(B),'S0':str(S),'R0':str(R0),'R0B':str(RB),'epsilon':str(epsilon),'field_normalization':str(field_normalization),'polar_density':str(polar_density),'velocity_sign':str(velocity_sign),'weak_bounds':{key:str(value) for key,value in bounds.items()},'point_covariance':str(point_cov),'samples':sample_records,'kernel':str(kernel),'actual_mu_density':str(mu_density),'negative_kernel':str(negative_kernel),'spatial_variances':[str(o[0,0]) for o in spatial_outer],'ensemble_W_variance':str(point_cov[0,0]),'fourth_moment_defect':str(s.simplify(fourth-3*point_cov[0,0]**2))})
failed=[c for c in checks if not c['passed']]
result={'schema':'independent-exact-ensemble-check-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'code_path':str(Path(__file__).resolve()),'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':platform.python_version(),'sympy':s.__version__,'counts':{'passed':len(checks)-len(failed),'failed':len(failed),'total':len(checks)},'checks':checks,'failures':failed,'witnesses':witnesses,'producer_access':False,'science_reuse':'Main instantaneous-map/initial-propagation receipt by hash; no main science rerun'}
(out/'RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'counts':result['counts'],'code_sha256':result['code_sha256'],'failed_checks':[c['name'] for c in failed]},indent=2))
for c in failed:print(json.dumps(c))
sys.exit(1 if failed else 0)
