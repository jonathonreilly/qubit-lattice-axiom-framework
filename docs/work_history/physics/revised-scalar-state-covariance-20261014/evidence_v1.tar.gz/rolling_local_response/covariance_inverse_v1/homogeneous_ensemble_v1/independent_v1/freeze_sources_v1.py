from pathlib import Path
import hashlib,json,datetime,sys,platform
ROOT=Path(__file__).resolve().parent
REPO=Path("/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go")
PK=REPO/".claude/science/physics-loops/revised-scalar-derivation-24h-20261013/rolling_local_response/covariance_inverse_v1"
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
source_specs=[
 (PK/"homogeneous_ensemble_v1/DERIVATION_v1.md","HOMOGENEOUS_DERIVATION_v1.md","007496f50c0346781f7923ca622f744deb372f1b73067645d1cf5352cf9e2355"),
 (PK/"homogeneous_ensemble_v1/PROTOCOL_v1.json","HOMOGENEOUS_PROTOCOL_v1.json","80d03b19bbdec65cac6d03029c21172d5864f3ebd6afb6bcda5fca20bc91ba10"),
 (PK/"DERIVATION_v2.md","PARENT_COVARIANCE_DERIVATION_v2.md","d10a1d93cf48b0f8a22fa01ce8a11e97118b2268e2683de84f5e14f44c33f8aa")]
reuse_specs=[
 (PK/"independent_v1/RECEIPT_v1.json","MAIN_RECEIPT_v1.json","4fd52eb3973d02cffc714e8806faba80a90515cde23f46c5685a40640c8f92f3"),
 (PK/"independent_v1/MANIFEST_v1.json","MAIN_MANIFEST_v1.json","d6226a8794ab6762dbdb67e41570a7b29669c9653615a2087ad22bb93df25ff7"),
 (PK/"independent_v1/REPORT_v1.md","MAIN_REPORT_v1.md","1202ba0c2285c5d6b07a569a669044b57dbc8830f9c229074880be454ea82bba")]
(ROOT/"sources").mkdir()
bindings=[]
for group,specs in [("source",source_specs),("reused_sealed_evidence",reuse_specs)]:
 for live,name,expected in specs:
  data=live.read_bytes();assert sha(data)==expected,(str(live),sha(data))
  dest=ROOT/"sources"/name
  with dest.open("xb") as f:f.write(data)
  bindings.append(dict(kind=group,original_path=str(live.relative_to(REPO)),snapshot_path=str(dest.relative_to(ROOT)),bytes=len(data),sha256=sha(data)))
main=PK/"independent_v1"
manifest=json.loads((main/"MANIFEST_v1.json").read_text())
receipt=json.loads((main/"RECEIPT_v1.json").read_text())
checks=[]
for item in manifest["artifacts"]:
 f=main/item["path"];d=f.read_bytes()
 assert len(d)==item["bytes"] and sha(d)==item["sha256"],str(f)
 checks.append(dict(path=item["path"],bytes=len(d),sha256=sha(d),unchanged=True))
expected={e["path"] for e in manifest["artifacts"]}|{"MANIFEST_v1.json","RECEIPT_v1.json"}
actual={str(f.relative_to(main)) for f in main.rglob("*") if f.is_file()}
assert actual==expected,sorted(actual^expected)
source_checks=[]
for item in receipt["source_bindings"]:
 live=REPO/item["original_path"];snap=main/item["snapshot_path"]
 assert live.read_bytes()==snap.read_bytes()
 assert sha(live.read_bytes())==item["sha256"]
 source_checks.append(dict(original_path=item["original_path"],sha256=item["sha256"],live_and_snapshot_equal=True))
record=dict(created_utc=now(),sources=[b for b in bindings if b["kind"]=="source"],reuse_bindings=[b for b in bindings if b["kind"]!="source"],producer_code_or_results_read=False)
(ROOT/"SOURCE_MANIFEST_v1.json").write_text(json.dumps(record,indent=2)+"\n")
verify=dict(created_utc=now(),main_receipt_sha256=sha((main/"RECEIPT_v1.json").read_bytes()),main_manifest_sha256=sha((main/"MANIFEST_v1.json").read_bytes()),main_report_sha256=sha((main/"REPORT_v1.md").read_bytes()),artifact_count=len(checks),source_pair_count=len(source_checks),exact_inventory=True,artifact_checks=checks,source_checks=source_checks,science_rerun=False,all_main_files_read_only=True)
(ROOT/"REUSE_IDENTITY_v1.json").write_text(json.dumps(verify,indent=2)+"\n")
execution=dict(created_utc=now(),argv=sys.argv,python=sys.executable,python_version=platform.python_version(),cwd=str(Path.cwd()),script_sha256=sha(Path(__file__).read_bytes()),source_count=3,reuse_count=3,main_artifacts_verified=len(checks),main_source_pairs_verified=len(source_checks))
(ROOT/"FREEZE_EXECUTION_v1.json").write_text(json.dumps(execution,indent=2)+"\n")
print(json.dumps(execution,indent=2))
