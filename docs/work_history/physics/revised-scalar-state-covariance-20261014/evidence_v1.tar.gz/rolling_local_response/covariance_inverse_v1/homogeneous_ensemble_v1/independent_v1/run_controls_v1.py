from pathlib import Path
import datetime,difflib,hashlib,json,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
source=ROOT/'check_independent_v1.py'
text=source.read_text()

def run(code,out):
    out.mkdir(parents=True,exist_ok=False)
    argv=[sys.executable,'-B',str(code),'--output',str(out)]
    begin=now();start=time.monotonic()
    completed=subprocess.run(argv,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=120)
    (out/'stdout.txt').write_text(completed.stdout)
    (out/'stderr.txt').write_text(completed.stderr)
    results=json.loads((out/'RESULTS_v1.json').read_text()) if (out/'RESULTS_v1.json').exists() else None
    record={'started_utc':begin,'finished_utc':now(),'elapsed_seconds':time.monotonic()-start,'argv':argv,'cwd':str(ROOT),'script_sha256':sha(code),'exit_code':completed.returncode,'stdout_sha256':sha(out/'stdout.txt'),'stderr_sha256':sha(out/'stderr.txt'),'results_sha256':sha(out/'RESULTS_v1.json') if results else None,'counts':results['counts'] if results else None}
    (out/'EXECUTION.json').write_text(json.dumps(record,indent=2)+'\n')
    return record,results

base_record,base=run(source,ROOT/'baseline_v1')
print('BASELINE',json.dumps(base_record))
if base_record['exit_code']!=0:sys.exit(2)
mutations=[
 ('missing_sqrt_two','field_normalization = s.sqrt(2)','field_normalization = s.Integer(1)','phase.covariance_normalization'),
 ('velocity_sign','velocity_sign = s.Integer(1)','velocity_sign = s.Integer(-1)','velocity.divergence'),
 ('uniform_polar_angle','polar_density = s.sin(polar)/2','polar_density = 1/s.pi','sphere.second_moment_z')]
root=ROOT/'damages_v1';root.mkdir()
summary=[]
for name,before,after,witness in mutations:
    d=root/name;d.mkdir()
    assert text.count(before)==1,(name,text.count(before))
    modified=text.replace(before,after)
    code=d/'check_damaged_v1.py';code.write_text(modified)
    (d/'SOURCE.diff').write_text(''.join(difflib.unified_diff(text.splitlines(True),modified.splitlines(True),fromfile='check_independent_v1.py',tofile=name+'/check_damaged_v1.py')))
    protocol={'created_utc':now(),'name':name,'base_sha256':sha(source),'damaged_sha256':sha(code),'replacement_before':before,'replacement_after':after,'required_failed_check':witness,'actual_source_copy_executed':True}
    (d/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2)+'\n')
    record,res=run(code,d/'execution')
    names=[c['name'] for c in res['failures']] if res else []
    detected=record['exit_code']==1 and witness in names
    summary.append({'name':name,'protocol':protocol,'execution':record,'failed_checks':names,'intended_witness_detected':detected})
    print('DAMAGE',name,json.dumps({'exit_code':record['exit_code'],'counts':record['counts'],'intended_witness_detected':detected,'failed_checks':names}))
(root/'SUMMARY.json').write_text(json.dumps({'created_utc':now(),'baseline_code_sha256':sha(source),'all_intended_detected':all(v['intended_witness_detected'] for v in summary),'damages':summary},indent=2)+'\n')
sys.exit(0 if all(v['intended_witness_detected'] for v in summary) else 3)
