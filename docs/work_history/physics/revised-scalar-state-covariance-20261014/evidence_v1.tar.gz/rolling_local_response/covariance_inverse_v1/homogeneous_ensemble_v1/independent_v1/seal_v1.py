from pathlib import Path
import datetime,hashlib,json
ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda data:hashlib.sha256(data).hexdigest()
def item(name):
 p=ROOT/name;data=p.read_bytes()
 return {'path':name,'bytes':len(data),'sha256':sha(data)}
def write(name,data):
 with (ROOT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
source_manifest=json.loads((ROOT/'SOURCE_MANIFEST_v1.json').read_text())
identity=[]
for b in source_manifest['sources']+source_manifest['reuse_bindings']:
 live=REPO/b['original_path'];snap=ROOT/b['snapshot_path']
 data=live.read_bytes()
 assert data==snap.read_bytes() and sha(data)==b['sha256'] and len(data)==b['bytes'],b
 identity.append({'kind':b['kind'],'original_path':b['original_path'],'snapshot_path':b['snapshot_path'],'sha256':b['sha256'],'bytes':b['bytes'],'byte_identical':True})
# Verify the old main seal again without any writes to that directory.
main=ROOT.parent.parent/'independent_v1'
m=json.loads((main/'MANIFEST_v1.json').read_text())
for b in m['artifacts']:
 d=(main/b['path']).read_bytes();assert len(d)==b['bytes'] and sha(d)==b['sha256']
expected={b['path'] for b in m['artifacts']}|{'MANIFEST_v1.json','RECEIPT_v1.json'}
assert {str(p.relative_to(main)) for p in main.rglob('*') if p.is_file()}==expected
write('FINAL_IDENTITY_v1.json',{'created_utc':now(),'current_live_snapshot_pairs':identity,'main_artifacts_reverified':len(m['artifacts']),'main_exact_inventory_unchanged':True,'source_edits_required':False,'main_evidence_changed':False})
baseline=json.loads((ROOT/'baseline_v1/RESULTS_v1.json').read_text())
summary=json.loads((ROOT/'damages_v1/SUMMARY.json').read_text())
assert baseline['counts']=={'passed':109,'failed':0,'total':109}
assert summary['all_intended_detected'] and len(summary['damages'])==3
for d in summary['damages']:
 assert d['execution']['exit_code']==1 and d['intended_witness_detected']
manifest_paths=sorted(str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p.name not in {'MANIFEST_v1.json','RECEIPT_v1.json'})
artifacts=[item(p) for p in manifest_paths]
write('MANIFEST_v1.json',{'schema':'independent-artifact-manifest-v1','created_utc':now(),'artifact_root':str(ROOT.relative_to(REPO)),'artifact_count':len(artifacts),'excludes':['MANIFEST_v1.json','RECEIPT_v1.json'],'artifacts':artifacts})
receipt={
 'schema':'focused-independent-mathematical-check-receipt-v1','created_utc':now(),
 'unit':'rolling_local_response/covariance_inverse_v1/homogeneous_ensemble_v1/independent_v1',
 'scientific_author':'/root','independent_checker':'/root/scalar_energy_check','formal_audit':False,'formal_grade_or_authority_state_changed':False,
 'source_bindings':source_manifest['sources'],'reused_sealed_evidence_bindings':source_manifest['reuse_bindings'],
 'manifest':item('MANIFEST_v1.json'),'report':item('REPORT_v1.md'),'hand_derivation':item('HAND_DERIVATION_v1.md'),'protocol':item('PROTOCOL_v1.json'),
 'independent_code':item('check_independent_v1.py'),'execution_driver':item('run_controls_v1.py'),'baseline_execution':item('baseline_v1/EXECUTION.json'),'baseline_results':item('baseline_v1/RESULTS_v1.json'),'baseline_counts':baseline['counts'],
 'damage_summary':item('damages_v1/SUMMARY.json'),'damage_counts':[{'name':d['name'],'counts':d['execution']['counts'],'exit_code':d['execution']['exit_code'],'intended_witness_detected':d['intended_witness_detected']} for d in summary['damages']],
 'failure_ledger':item('FAILURES_v1.json'),'command_index':item('COMMAND_INDEX_v1.json'),'reused_main_identity':item('REUSE_IDENTITY_v1.json'),'final_identity':item('FINAL_IDENTITY_v1.json'),
 'scope':['Zero mean, exact phase and normalized direction integrations, sinc shell covariance and zero-separation normalization','Full finite-dimensional translation and O(3) invariance including parity via measure-preserving coupling','Physical velocity divergence, curl and transformation as a polar vector','Per-realization instantaneous inverse, initial constraints and distinct exact bounded seeds','Uniform row-norm weak bounds and local-compatibility interpretation using the main checked equations by identity','Explicit nonergodic spatial-average witness and absence of broadband, state-selection or survey-fit conclusions'],
 'source_disposition':{'mathematical_correction_required':False,'new_derivation_v1_matches_checked_claims_with_stated_limits':True,'earlier_epsilon_scaling_checked_algebraically':True,'earlier_producer_implementation_or_results_inspected':False},
 'independence':{'own_hand_derivation_and_protocol_before_execution':True,'producer_code_results_trajectories_accessed':False,'new_empirical_data_accessed':False,'main_science_rerun':False,'all_writes_confined_to_this_new_directory':True,'prior_evidence_or_parent_source_changed':False,'git_PR_runtime_lock_or_audit_state_changed':False},
 'limits':['A supplied possible local linear ensemble, not a selected covariance, background, matter state or scalar coupling.','Real scalar-channel covariance with a monochromatic-shell spatial spectrum; no arbitrary broadband or observed covariance function is realized.','Homogeneous/isotropic/parity-invariant finite-dimensional laws do not require individual-realization symmetry and do not establish ergodicity.','Weak and positive initial populations require a sufficiently small rescaled covariance at fixed p>0 and Rr>0; no uniform singular-limit bound or arbitrary measured amplitude.','The old action, initial constraint-propagation and local kinetic compatibility are reused by exact identity; no new full kinetic or history calculation.','Physical coordinates refer to the selected slice; fixed physical wave number at all times is not asserted.','No exact nonlinear constraint/backreaction certificate, actual survey fit, calibration determination, empirical acceptance or formal audit.']}
write('RECEIPT_v1.json',receipt)
print(json.dumps({'artifact_count':len(artifacts),'source_pair_count':len(source_manifest['sources']),'reused_seal_pair_count':len(source_manifest['reuse_bindings']),'report':item('REPORT_v1.md'),'manifest':item('MANIFEST_v1.json'),'receipt':item('RECEIPT_v1.json')},indent=2))
