# Independent covariance support and instantaneous candidate inverse check

The PSD support criterion and constructive pseudoinverse are correct. The supplied action and initial Einstein constraints give the stated three-readout map, determinant 4Rr/p^2, and explicit radiation-monopole inverse. This establishes algebraic equal-time covariance feasibility and local compatibility near the declared regular background event. It does not establish that arbitrary fixed observed amplitudes, survey operators, calibrated backgrounds, or complete histories are feasible.

The independent baseline passed 98 exact controls. All four actual damaged-formula copies failed their intended witnesses. V1's fixed-p local claim was valid, but its list of nonuniform amplitude limits omitted p->0, and mode-pair reality did not by itself specify ensemble symmetries. Those two qualifications were reported before code and are now explicitly supplied in preserved v2. All displayed equations are unchanged.

Scientific authorship remains with /root. This is a focused independent check, not a formal audit. No producer code, results, trajectory arrays or new empirical data were accessed. The optional homogeneous_ensemble_v1 follow-on was not inspected and is outside this receipt.

## Sources and exact correspondence

The initial five sources were read in full and frozen before the independent executable: the new derivation and protocol, the named kinetic and observable notes, and the full canonical action. The later v2 source and its author diff/qualification record were separately frozen. There are eight live/snapshot bindings.

| Source | SHA-256 |
| --- | --- |
| covariance_inverse_v1/DERIVATION_v1.md | 9ce6b645bda34e4a28ca2b12c8cb99df5e93f9f273f719a2b17620b55a845bed |
| covariance_inverse_v1/DERIVATION_v2.md | d10a1d93cf48b0f8a22fa01ce8a11e97118b2268e2683de84f5e14f44c33f8aa |
| covariance_inverse_v1/PROTOCOL_v1.json | c1d923999aab7e01eca996d36f2a04ec942523ec33f4727bb007f8681851bf3c |
| kinetic_radiation_v1/DERIVATION_v3.md | 4fec305653d9e51a4cf1ccbffb2914574c55c41732f6a46624b16535ed23102a |
| observable_bridge_v1/DERIVATION_v2.md | 6fe7152ee4b082a577e597f9aea829824e63cf2d9540cd69cba3edaf9ae51729 |
| Full canonical future-confinement action note | 39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000 |

SOURCE_MANIFEST_v2.json additionally binds the exact author QUALIFICATION_v2.diff and QUALIFICATION_v2.json bytes and paths. SOURCE_CORRESPONDENCE_v2.json reconstructs v2 from exactly the two stated prose replacements, checks that the displayed equation lines are identical, and matches the author diff exactly. V1 and the original independent findings remain preserved. No producer execution or rerun is claimed by this correspondence.

HAND_DERIVATION_v1.md and the independent protocol were saved before check_independent_v1.py. The exact complex matrices, rational background, correlated covariance factor and eight bounded seed realizations were independently chosen. The named kinetic equations supply the already developed matter/transport system; this unit independently reconstructs the initial constraint map and its first propagation derivative, rather than repeating a full kinetic-system review or numerical history.

## PSD support criterion and reconstruction

For centered finite-second-moment X in C^n, P=E[XX^dagger] is Hermitian PSD. For a specified finite-dimensional linear transfer T:C^n->C^m, its output covariance S=TPT^dagger is Hermitian PSD, and every column of S lies in range(T). Let Pi=TT^+ be the orthogonal projector on that range. Necessity of

    S=S^dagger>=0, (I-Pi)S=0

is immediate.

Conversely, these conditions imply Pi S=S and, by Hermitian conjugation, S Pi=S. The proposed

    P0=T^+ S (T^+)^dagger

is PSD, since each quadratic form of P0 is a quadratic form of S after applying (T^+)^dagger. It satisfies T P0 T^dagger=Pi S Pi=S. This includes singular and zero covariances. The covariance must be Hermitian as well as supported; the one-sided range condition without Hermiticity would not justify the second projector equality.

The independent rank-one complex example uses a=(1,2)^T, b=(1,-i,0)^T and T=a b^dagger. Its pseudoinverse is constructed directly as b a^dagger/10, and all four Moore-Penrose identities are checked. With S=(5/3)aa^dagger, the result is P0=(5/12)bb^dagger. A full-rank PSD target outside the one-dimensional output support is rejected. Replacing that target by Pi S Pi would change the data; it would not establish feasibility of the original target.

A separate full-row-rank complex 2-by-3 map checks the constructive formula with a distinct correlated covariance. Full row rank makes Pi=I, so every finite PSD S is algebraically feasible for that specified transfer. This is a conditional statement about fitting S with unrestricted P. It is not a statement that background or calibration information cannot constrain parameters.

Adding a PSD N supported in ker(T) is a valid invisible family, but is not exhaustive. For T=(1,0), S=1 and P0=diag(1,0), take

    P=[[1,(1+i)/2],[(1-i)/2,1]].

P is positive definite and has the same output, while det(P-P0)=-1/2. Thus P cannot equal P0 plus a PSD kernel-only covariance. The source's observed/null cross-block language must be understood as cross correlations allowed inside a PSD completion, not positivity of an individual rectangular cross block. Such cross blocks are not arbitrary: the exact example with a zero observed diagonal and nonzero cross block is indefinite.

## Bounded realizations and mode assumptions

For finite Hermitian PSD S=B B^dagger, independent real Rademacher coordinates Z give centered Y=BZ with covariance S. The support is finite and bounded. When the support condition holds, X=T^+Y is bounded too and has covariance P0. Common amplitude scaling by epsilon multiplies both covariances by epsilon^2 and shrinks all states.

This proves small-amplitude existence for each fixed finite transfer; it does not prove admissibility of an arbitrary fixed measured covariance. Gaussianity is not needed, and neither a chosen covariance nor a quantum state has been derived.

For a nonzero Fourier wavevector, assigning the negative mode the conjugate ensures a real field. It does not alone impose statistical homogeneity, isotropy, parity or a proper complex covariance. The independent Rademacher construction has a generally nonzero pseudocovariance E[YY^T]. A real standing-wave coefficient gives real-space variance proportional to cos^2(q.x), explicitly showing the lack of homogeneity despite mode-pair reality.

An independently supplied uniform phase can preserve the Hermitian same-mode covariance while removing this standing-wave variance dependence. The checker integrates that phase exactly. This is only an illustration that boundedness and mode reality are compatible with additional ensemble choices; it is not a selected state, a direction-isotropic ensemble, a broadband power spectrum or the unread optional follow-on.

Any actual observed spectrum must also obey its reality, symmetry and estimator requirements. The finite complex algebra does not override those constraints. Self-conjugate or zero Fourier modes require separate real-amplitude treatment; the candidate construction explicitly assumes p>0.

## Deriving the instantaneous candidate map

The full action has scalar energy density

    rho_phi=Q |v|_K^2+2Q Hv^2 U, Q=Q0(1+k).

At phi=v=0 it gives C=A^2=1, U=3/2 and grad U=0. With dimensionful Rm=rho_m,E/(2Q)>0 and Rr=rho_r,E/(2Q)>0, the Hamiltonian equation is

    H^2=Hv^2+2(Rm+Rr)/3.

This uses the action's absence of a 1/2 before K. The source's H, Hv and Rm,Rr here are in the dimensionful kinetic-system normalization; they are not silently substituted for the future theorem's dimensionless density variables.

This is admissible instantaneous background data. It is not a stationary background with dust. The scalar equation is

    D_t v=-3 H v-V-Rm b, V=Hv^2 grad U.

At the event D_t v=-Rm b, and direct differentiation of the actual action gives |b|_K^2=k>0 at the origin. Hence the dust-driven acceleration is nonzero. In HAND_DERIVATION_v1.md the compact product “3Hv” in that vector equation means 3 H times v, not the vacuum scale Hv by itself.

The initial background rates are

    Hdot=-Rm-4Rr/3, Rm_dot=-3H Rm,
    Rr_dot=-4H Rr, p_dot=-Hp.

With the Einstein metric time potential T and spatial potential L, the Fourier Einstein constraints are

    p^2 L+3H(Ldot+HT)=-delta rho_total/(2Q),
    Ldot+HT=<v,xi>+J,
    J=Rm theta/p^2+4Rr Theta1/p.

The scalar excitation density contribution is <v,pi>-|v|^2T+<V,xi>. Dust's Einstein energy contrast is n+c, where c=<b,xi>, and the radiation energy contrast is 4Theta0. These reconstruct the named source's complete Hamiltonian constraint.

At v=xi=pi=0 and initially vanishing radiation multipoles with l>=1, c=0 and scalar excitation density vanishes. Zero shear makes T=L. Thus

    CH=p^2 L+Rm n+4Rr Theta0+3H Rm theta/p^2=0.

The velocity term comes from the momentum constraint and cannot be dropped merely because the scalar perturbation velocity is zero.

The physical-frame transformations are T_J=T+c, L_J=L-c, theta_J=theta/A and Delta_m,J=n-3c. Here Delta_m,J is the physical Newtonian-gauge matter density contrast explicitly defined in the source. It is not automatically the common gauge-invariant comoving-density variable sometimes denoted Delta, nor an observed galaxy fluctuation on a light cone. At this chosen event the outputs reduce to W=L, theta_J=theta and Delta_m,J=n.

Solving CH for L gives the actual map

    Y=T0 X, X=(n,theta,Theta0), Y=(W,theta_J,Delta_m,J),
    T0=[[-Rm/p^2,-3H Rm/p^4,-4Rr/p^2],
        [0,1,0],
        [1,0,0]],
    det(T0)=4Rr/p^2>0.

Its inverse is

    n=Delta_m,J, theta=theta_J,
    Theta0=-(p^2 W+Rm Delta_m,J+3H Rm theta_J/p^2)/(4Rr).

Both left and right inverse identities and direct substitution into the actual Hamiltonian constraint are checked. When Rr=0 the displayed map loses rank and a left-null output relation remains. The radiation monopole is therefore a substantive free direction in this construction, rather than an algebraic variable that disappeared from the constraints.

## Initial data, generated derivatives and local compatibility

At the specified initial slice the perturbation rates are

    F=Ldot=-HL+Rm theta/p^2,
    n_dot=-theta+3F, theta_dot=-2Htheta+p^2L,
    Theta0_dot=F, Theta1_dot=p(Theta0+L)/3,
    pi_dot=-Rm b(n+2L).

Although Theta1 is initially zero, its derivative is generally nonzero. The independent check differentiates the full momentum source J, including this generated dipole, and verifies

    CH_dot+3H CH=0

at the declared slice. Dropping the dipole derivative leaves the exact residual -4H Rr(L+Theta0). The initially zero quadrupole has zero first derivative on this slice, but generally acquires later derivatives as the dipole evolves. None of these facts supports a static perturbation or a permanent perfect-radiation truncation.

For local existence, the angular brightness can be treated as an element of C([-1,1]), coupled to the finite metric/scalar/dust state. Multiplication by -i p(t)mu is bounded, and the low angular moment functionals are bounded. On a sufficiently short regular background interval, p remains positive and all coefficients after eliminating the metric constraints are bounded and continuous. The resulting linear integral evolution has local solutions and continuous dependence on the initial data.

General constraint propagation uses the same conserved matter/scalar stress and Einstein system and the named kinetic identity. This unit independently checks the initial map and its propagation derivative, not every coefficient of that earlier full kinetic proof. It does not run a finite multipole closure, an angular discretization, or a complete history. Strict weak-amplitude margins for a finite bounded seed ensemble persist for a sufficiently short common interval, rather than establishing all-time validity.

## Distinct exact bounded control

The independent background uses

    k=1/11, nu=7/5, Q0=11/8, Q=3/2,
    Hv=1/2, H=1, Rm=2/5, Rr=29/40, p=7/3.

All densities are positive and the background Friedmann equation holds exactly. A distinct real covariance factor is

    B=[[1,1/2,0],[0,2,1/3],[1/4,0,3/2]], S0=B B^T.

All eight independent Rademacher triples are enumerated. With epsilon=1/10000, set Y=epsilon BZ and X=T0^-1 Y. Every sample satisfies the Hamiltonian constraint and reproduces the three outputs exactly. The empirical finite-ensemble covariances equal epsilon^2 S0 and the reconstructed P exactly.

For the real field made from the conjugate pair, the maximum initial amplitudes are:

| Quantity | Exact bound |
| --- | --- |
| Metric potential amplitude 2\|W\| | 3/10000 |
| Dust contrast amplitude 2\|n\| | 7/20000 |
| Longitudinal physical speed 2\|theta\|/p | 1/5000 |
| Radiation brightness contrast 8\|Theta0\| | 197/76125 |

All are below the synthetic test threshold 1/100. The threshold is an example of an explicit margin, not a universal observational validity criterion. In particular the initial matter number density and radiation brightness remain positive. A positive base radiation population with a small bounded fractional modulation supplies an initial population realization without imposing a unique thermal spectral perturbation. The calculation does not certify every phase-space realization or a nonlinear Einstein-Boltzmann solution.

For the all-positive seed, Theta1_dot=-2113/15660000 and the coefficient of b in pi_dot is -19/100000. This explicitly rejects treating these initial states as static.

## Conditioning and preserved qualifications

The inverse monopole contains coefficients proportional to p^2/Rr, Rm/Rr and H Rm/(Rr p^2). Every fixed finite p>0 and Rr>0 admits a sufficiently small bounded ensemble. No uniform neighborhood follows when these coefficients diverge.

The original text explicitly mentioned Rr->0 and p->infinity. There is also a p->0 limitation: choose output theta_J=eta p, W=Delta=0 with eta fixed. The physical speed theta_J/p remains eta, but

    Theta0=-3H Rm eta/(4Rr p)

diverges. A fixed nonzero theta_J gives an even stronger p^-2 divergence and also an unbounded speed. The determinant itself diverges as p->0, showing why a nonzero or large determinant is not an amplitude-conditioning certificate.

V2 adds this small-p limitation and states that conjugate mode pairing alone does not establish ensemble homogeneity, isotropy or parity. The support theorem, map, inverse and numbered equations are unchanged. The v1 fixed-parameter conclusion was not refuted; the preserved findings concern its incomplete boundary/symmetry qualifications.

PSD feasibility also does not remove independently calibrated background information. For example, at this origin event,

    H^2-Hv^2=(rho_m,E+rho_r,E)/[3Q0(1+k)].

If H, Hv, Q0 and the total density were all independently specified, this equation could constrain k before any covariance fit. The source explicitly allows such constraints. Its non-identification conclusion is correctly limited to matching an equal-time covariance with otherwise unrestricted initial covariance in a surjective transfer class.

## Cross-time support is additional information

Stacked epochs must share the same initial amplitudes and their cross-time covariance. The same support theorem then applies to the stacked transfer. The independent one-seed example takes the ratio a=2+i and variance 3/2. It satisfies

    S12=a* S11, S22=|a|^2 S11.

With S11>0 the cross block determines a. The two diagonal blocks alone do not determine its complex phase. An exact positive diagonal matrix with the same two marginal autos but zero cross block is PSD and separately feasible at each epoch, yet fails the one-seed stacked support condition. Replacing the one-seed transfer by two independent readout seeds changes the problem and removes that particular restriction.

This does not prove that adding a given number of survey bins identifies parameters. The candidate has many possible angular initial modes, and the actual stacked operator may remain surjective. Redshift bins need not track the same mode or supply the needed cross-time blocks. Projection, gauge/readout conventions, bias, noise and geometry must enter the observation operator before applying this algebra to data.

## Executions, damage controls and scope

The one baseline completed 98 passed / 0 failed, exit zero, under Python 3.12.8 and Sympy 1.14.0. The checker SHA-256 is b3fa80311b20e99f61f3d75bf6aa9aea65fddfd7a3cc9091f4431d73294cda11; baseline results SHA-256 is 69de68d7155901b15989f0e87b69097de2b014621f7e1564520ed23be844450c.

| Actual changed implementation | Result | Required witness |
| --- | --- | --- |
| Use transpose instead of adjoint in covariance reconstruction | 92 passed / 6 failed | Complex support reconstruction and PSD fail |
| Change the radiation map factor from 4 to 3 | 85 passed / 13 failed | Hamiltonian residual Rr Theta0 |
| Reverse the dust momentum sign in the output map | 85 passed / 13 failed | Hamiltonian residual 6H Rm theta/p^2 |
| Omit the generated dipole from the initial momentum derivative | 97 passed / 1 failed | Constraint-propagation residual -4H Rr(L+Theta0) |

All altered source copies, diffs, protocols, commands, complete stdout/stderr, results and failure witnesses are preserved. These are tests of the independent implementation, not of the unread producer code. There were no unexpected baseline failures, exceptions, repairs or hidden reruns. The count includes bookkeeping and repeated exact sample checks; the written proof supplies the general quantifiers.

Within this scope, v2 is consistent with the independently derived mathematics. It gives a conditional local equal-time feasibility result, with explicit small-amplitude and state freedom. It does not derive the state covariance, establish a stationary dust background, match an observed spectrum, exclude other parameter constraints, or prove all-history parameter degeneracy. The optional homogeneous-ensemble follow-on remains unreviewed by this receipt.
