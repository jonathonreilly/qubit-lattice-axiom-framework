# Independent covariance inverse derivation before code

Author of the science source: /root. Independent focused checker: /root/scalar_energy_check. The source/protocol, full named kinetic and observable notes, and full action were read before this derivation. No producer code, results, trajectories or empirical data are accessed.

1. For a finite-dimensional complex linear map T:C^n->C^m and centered finite-second-moment X, P=E[XX^dagger] is Hermitian PSD and S=TPT^dagger is Hermitian PSD. Its range lies in range(T) because it is a product with T on the left. Let Pi=TT^+ be the orthogonal projector on that range. Necessity is therefore (I-Pi)S=0.

Conversely, if S=S^dagger>=0 and Pi S=S, Hermitian conjugation also gives S Pi=S. Set P0=T^+ S (T^+)^dagger. For every vector z, z^dagger P0 z=[(T^+)^dagger z]^dagger S [(T^+)^dagger z]>=0. Hence P0 is a finite PSD covariance and T P0 T^dagger=Pi S Pi=S. This includes singular and zero matrices. Full row rank means Pi=I; every finite PSD readout covariance is then algebraically feasible, conditional on the same specified transfer and no additional state restriction.

2. Adding a PSD N with range(N) in ker(T) preserves the output. This is not the complete feasible family. For T=(1,0), S=1, P0=diag(1,0), choose

    P=[[1,(1+i)/2],[(1-i)/2,1]].

P is positive definite, TPT^dagger=1, but P-P0 has determinant -1/2. Thus it cannot be a PSD covariance supported only in ker(T). The observed/null cross block is allowed as part of a PSD completion; it is not independently a positive matrix. In a rank-adapted basis, the PSD condition restricts cross blocks jointly with the null block. It is wrong to claim arbitrary cross blocks are allowed. If the observed covariance is zero, positivity forces its cross block to vanish.

3. A finite Hermitian PSD S has a finite factor S=B B^dagger. With independent real Rademacher Z_j=+/-1, E[Z]=0 and E[ZZ^dagger]=I, Y=BZ has the desired S and finite bounded support. X=T^+Y has covariance P0 and is also bounded whenever the support condition holds. A sufficiently small common amplitude epsilon rescales S and P by epsilon^2 and uniformly shrinks every state in this finite ensemble. It does not prove that an arbitrary fixed measured S obeys weak-field or distribution-positivity restrictions.

For a generic nonzero Fourier wavevector, assign the negative mode the complex conjugate to obtain real fields. That condition alone does not select statistical homogeneity, isotropy, parity, proper complex covariance or a power spectrum. For example a purely real Rademacher coefficient makes a standing-wave ensemble with position-dependent variance. One can preserve the same Hermitian S while adding an independent common uniform phase, so bounded realizations can also enforce a translation-invariant one-mode ensemble if desired. This adds a supplied ensemble choice, not a selected physical state. Extra symmetry restrictions on observed spectra must be enforced separately. The k=0 Fourier mode and self-conjugate discrete modes require real rather than arbitrary complex amplitudes; the candidate map assumes p>0.

4. From the complete action, scalar energy is Q |v|_K^2+2Q Hv^2 U. At phi=v=0, U=3/2, grad U=0, C=A^2=1. With Rm=rho_m,E/(2Q)>0 and Rr=rho_r,E/(2Q)>0, the background Hamiltonian constraint is

    H^2=Hv^2+2(Rm+Rr)/3.

The scalar equation has D_t v=-3Hv-V-Rm b, where V=Hv^2 grad U and b is the metric gradient of ln A. At this event D_t v=-Rm b, which is nonzero: the actual action gives |b|_K^2=k>0 at the origin. This is a regular instantaneous background state, not a stationary dust/vacuum solution. The background derivatives at the event are

    Hdot=-Rm-4Rr/3, Rm_dot=-3H Rm, Rr_dot=-4H Rr, p_dot=-Hp.

5. Write the Einstein metric as -(1+2T)dt^2+a_E^2(1-2L)dx^2. The Fourier Hamiltonian and momentum constraints of the action are

    p^2 L+3H(Ldot+HT)=-delta rho_total/(2Q),
    Ldot+HT=<v,xi>+J,
    J=Rm theta/p^2+4Rr Theta1/p.

The scalar contribution to delta rho/(2Q) is <v,pi>-|v|^2T+<V,xi>. Dust has Einstein energy contrast n+c with c=<b,xi>, and radiation energy contrast 4Theta0. These statements reproduce the named source's full constraint. At v=xi=pi=0 and Theta_l=0 for l>=1, c=0 and scalar excitation density vanishes. Zero initial shear gives T=L. The remaining constraint is

    CH=p^2 L+Rm n+4Rr Theta0+3H Rm theta/p^2=0.

Physical-frame conversions are T_J=T+c, L_J=L-c, theta_J=theta/A and Delta_m,J=n-3c. Here Delta denotes the physical Newtonian-gauge matter density contrast as explicitly defined, not an independently assumed gauge-invariant comoving density observable. At this event W=L, theta_J=theta, Delta_m,J=n.

Thus the actual constrained output map from X=(n,theta,Theta0) to Y=(W,theta_J,Delta_m,J) is

    T0=[[-Rm/p^2,-3H Rm/p^4,-4Rr/p^2],
        [0,1,0],
        [1,0,0]].

Its determinant is 4Rr/p^2>0. The inverse is

    n=Delta_m,J, theta=theta_J,
    Theta0=-(p^2 W+Rm Delta_m,J+3H Rm theta_J/p^2)/(4Rr).

The dust velocity enters CH through the momentum constraint; setting theta=0 would discard an allowed initial direction. The factor 4 comes from radiation brightness-to-density conversion. Neither a growing-mode relation nor a relation selecting radiation/dust amplitudes is used.

6. Initial data do not mean time-independent perturbations. At the specified event,

    F=Ldot=-HL+Rm theta/p^2,
    n_dot=-theta+3F,
    theta_dot=-2Htheta+p^2L,
    Theta0_dot=F,
    Theta1_dot=p(Theta0+L)/3,
    pi_dot=-Rm b(n+2L).

The initial Theta2_dot vanishes because Theta1=Theta3=0, but higher moments are subsequently generated for generic data. Computing the derivative of CH with the full initial derivatives, including the initially zero dipole's nonzero derivative in Jdot, gives

    CH_dot+3H CH=0.

Omitting the dipole contribution would falsely spoil this identity. The independent checker will verify this initial propagation relation. The named source's full identity has the shear residual H[p^2(L-T)-8RrTheta2], which vanishes on the shear constraint.

The local-existence argument can be made precise without assuming a finite multipole closure. Use the Banach space C([-1,1]) for the brightness angular function together with the finite dust/scalar/metric state. Multiplication by -i p(t)mu is bounded on this space, and its first few moment functionals are bounded. After using the momentum and shear constraints to eliminate T, Ldot and Tdot, every coefficient is a bounded continuous operator on a sufficiently short regular background interval with p bounded away from zero. A linear integral equation therefore has a local solution. Constraint propagation follows from the coupled Einstein/matter/scalar system (and the named identity); this check is not a fresh global review of the whole kinetic system. Continuous dependence preserves strict initial weak margins on a sufficiently short interval for the finite bounded seed ensemble.

7. Weak and population constraints are separate from PSD. For the paired real Fourier field, scalar potential amplitude is at most 2|W|, dust number contrast at most 2|n|, physical longitudinal velocity amplitude at most 2|theta|/p, and radiation brightness contrast at most 8|Theta0|. Choosing a positive isotropic base brightness with fractional modulation 4Theta0 realizes positive initial radiation populations when this modulation is small. It does not assume a unique thermal spectral perturbation shape or a quantum state.

The inverse coefficients scale as p^2/Rr for W, Rm/Rr for Delta, and H Rm/(Rr p^2) for theta. The valid weak neighborhood need not be uniform as Rr->0 or p->infinity. It also need not be uniform as p->0: even theta=epsilon p keeping velocity finite produces Theta0 proportional to epsilon/p for the pure-velocity output. The latter limit is an additional qualification of the source's nonuniform-limit list; its fixed-p claim is correct. This was reported to the parent before code.

The independent exact background will use k=1/11, nu=7/5, Q0=11/8 so Q=3/2, Hv=1/2, H=1, Rm=2/5, Rr=29/40 and p=7/3. These satisfy the Friedmann equation with positive densities. Let

    B=[[1,1/2,0],[0,2,1/3],[1/4,0,3/2]], S=B B^T.

Enumerate the eight Rademacher states, take Y=epsilon BZ with epsilon=1/10000, and reconstruct X by the inverse. Every sample must satisfy CH exactly, reproduce Y, and obey explicit small upper bounds on the four real-space amplitudes above. The numerical threshold used in this demonstration is only a synthetic control, not a universal validity criterion or an observational bound.

8. Across epochs for the same initial X, stack the maps. Feasibility is controlled by range(Tstack), including cross-time blocks. For one seed and map (1,a), S12=a* S11 and S22=|a|^2 S11. With S11>0 this fixes a from the cross ratio, whereas auto spectra alone leave its complex phase unspecified. A PSD matrix violating the support condition is infeasible for that map. Introducing independent seeds changes the map and removes that particular restriction. An arbitrary extra number of epochs need not force a support deficit for a theory with a freely chosen angular distribution.

The instantaneous result does not prove that the same initial covariance fits many times, that the parameters satisfy known background calibrations, or that an actual projected survey operator is surjective. A single fixed measured covariance can also impose physical amplitude restrictions even where the algebraic support condition is trivial. No broad all-history or measured-gravity non-identification claim follows.
