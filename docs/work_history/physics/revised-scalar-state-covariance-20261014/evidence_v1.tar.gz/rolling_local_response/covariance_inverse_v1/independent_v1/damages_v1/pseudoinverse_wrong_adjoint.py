#!/usr/bin/env python3
"""Independent exact covariance and candidate initial-constraint controls."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import platform
import sys
import time
import sympy as s

COVARIANCE_RECONSTRUCTION_ADJOINT = False
RADIATION_MAP_FACTOR = 4
MOMENTUM_MAP_SIGN = -1
INCLUDE_GENERATED_DIPOLE = 1

parser=argparse.ArgumentParser()
parser.add_argument("--output-dir",required=True)
args=parser.parse_args()
out=Path(args.output_dir)
out.mkdir(parents=True,exist_ok=True)
started=time.monotonic()
checks=[]
details={}
q=s.Rational

def serial(x):
    if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [serial(v) for v in x]
    if isinstance(x,(str,int,bool,float)) or x is None:return x
    return str(x)
def record(name,passed,witness=None):
    row={"name":name,"passed":bool(passed)}
    if witness is not None:row["witness"]=serial(witness)
    checks.append(row)
    print(("PASS " if passed else "FAIL ")+name,flush=True)
def zero(name,expr):
    seq=list(expr) if isinstance(expr,s.MatrixBase) else [expr]
    values=[s.factor(s.simplify(x)) for x in seq]
    record(name,all(x==0 for x in values),values)
def adj(M):return M.conjugate().T
def reconstruct(Tplus,S):
    right=adj(Tplus) if COVARIANCE_RECONSTRUCTION_ADJOINT else Tplus.T
    return s.simplify(Tplus*S*right)
def psd(M):
    if s.simplify(M-adj(M))!=s.zeros(M.rows):return False
    for size in range(1,M.rows+1):
        for indices in itertools.combinations(range(M.rows),size):
            minor=s.simplify(M.extract(indices,indices).det())
            if minor.is_nonnegative is not True:return False
    return True

# Rank-one complex map: construct the Moore-Penrose inverse by its outer factors.
aa=s.Matrix([1,2]); bb=s.Matrix([1,-s.I,0])
T=aa*adj(bb)
Tp=bb*adj(aa)/((adj(aa)*aa)[0]*(adj(bb)*bb)[0])
Pi=s.simplify(T*Tp)
zero("PSD.MP_TTpT",T*Tp*T-T)
zero("PSD.MP_TpTTp",Tp*T*Tp-Tp)
zero("PSD.MP_output_projector_Hermitian",Pi-adj(Pi))
zero("PSD.MP_input_projector_Hermitian",Tp*T-adj(Tp*T))
zero("PSD.projector_idempotent",Pi*Pi-Pi)
S=q(5,3)*aa*adj(aa)
P0=reconstruct(Tp,S)
zero("PSD.support_condition",(s.eye(2)-Pi)*S)
zero("PSD.complex_support_reconstruction",T*P0*adj(T)-S)
record("PSD.constructed_covariance_PSD",psd(P0),P0)
zero("PSD.rank_one_expected_P0",P0-q(5,12)*bb*adj(bb))
Sbad=s.eye(2)
record("PSD.rank_deficient_rejects_unmatched_PSD",psd(Sbad) and (s.eye(2)-Pi)*Sbad!=s.zeros(2))
record("PSD.projecting_changes_target",Pi*Sbad*Pi!=Sbad)
zero("PSD.rank_bound",S.rank()-T.rank())
null=s.Matrix([0,0,1])
Nnull=3*null*adj(null)
zero("PSD.kernel_addition_invisible",T*Nnull*adj(T))
record("PSD.kernel_addition_PSD",psd(P0+Nnull))
zero("PSD.zero_map_zero_output",s.zeros(2,3)*s.eye(3)*s.zeros(3,2))
record("PSD.zero_map_rejects_nonzero_S",Sbad!=s.zeros(2))

# A full-row-rank non-square complex map, with a different rational covariance.
Tf=s.Matrix([[1,s.I,2],[0,1,1-s.I]])
Tfp=adj(Tf)*(Tf*adj(Tf)).inv()
Bf=s.Matrix([[1,1+s.I],[2*s.I,3]])
Sf=Bf*adj(Bf)
Pf=reconstruct(Tfp,Sf)
zero("PSD.full_row_right_inverse",Tf*Tfp-s.eye(2))
zero("PSD.full_row_reconstruction",Tf*Pf*adj(Tf)-Sf)
record("PSD.full_row_constructed_PSD",psd(Pf),Pf)
record("PSD.full_row_target_positive_definite",Sf.det()>0 and Sf[0,0]>0)

# The kernel-only family is genuinely nonexhaustive.
Ts=s.Matrix([[1,0]])
base=s.diag(1,0)
completion=s.Matrix([[1,(1+s.I)/2],[(1-s.I)/2,1]])
record("PSD.cross_block_completion_positive",psd(completion))
zero("PSD.cross_block_output",(Ts*completion*adj(Ts))[0]-1)
record("PSD.completion_not_P0_plus_PSD_kernel",(completion-base).det()<0,
       {"difference_det":(completion-base).det()})
badcompletion=s.Matrix([[0,1],[1,2]])
record("PSD.zero_observed_block_forbids_cross",not psd(badcompletion),
       {"det":badcompletion.det()})

# Bounded complex realization and Fourier reality versus ensemble symmetry.
z2=[s.Matrix(z) for z in itertools.product([-1,1],repeat=2)]
Y2=[Bf*z for z in z2]
mean2=sum(Y2,s.zeros(2,1))/4
cov2=sum([y*adj(y) for y in Y2],s.zeros(2))/4
pseudo2=sum([y*y.T for y in Y2],s.zeros(2))/4
zero("bounded.complex_Rademacher_mean",mean2)
zero("bounded.complex_Rademacher_covariance",cov2-Sf)
record("bounded.Rademacher_pseudocovariance_not_selected",pseudo2!=s.zeros(2))
phase,position=s.symbols("phase position",real=True)
coefficient=1+2*s.I
field=coefficient*s.exp(s.I*position)+s.conjugate(coefficient)*s.exp(-s.I*position)
zero("reality.conjugate_pair_is_real",s.conjugate(field)-field)
record("reality.standing_wave_variance_not_homogeneous",
       4*s.cos(0)**2!=4*s.cos(s.pi/2)**2)
phase_var=s.integrate(4*s.cos(position+phase)**2,(phase,0,2*s.pi))/(2*s.pi)
zero("reality.uniform_phase_same_mode_variance",phase_var-2)
zero("reality.uniform_phase_pseudocovariance",s.integrate(s.exp(2*s.I*phase),(phase,0,2*s.pi))/(2*s.pi))

# Bind the actual complete action at the chosen origin event.
k,nu,Q0,Q,Hv=s.symbols("k nu Q0 Q Hv",positive=True)
u,fx,fy=s.symbols("u fx fy",real=True)
ak=(1-k)*(1+3*k)/4; alpha=s.sqrt(ak)
ss=(1+k)/(k*(1-3*k)); E=s.exp(2*alpha*u); F=1+ss*E
J=1+(1-3*ak)*ss*E
C=(1+ss)*E/F
Kuu=J/F**2
U=q(3,2)+3*ss*(E-1)**2/(2*F**2)+(k/2)*fx**2*s.exp(-(1-k)*u/alpha)+(k/3)*fy**2*s.exp(-(1+k)*u/alpha)+nu*(1+ss)*u*u/(2*F**2)
origin={u:0,fx:0,fy:0}
bu=s.diff(s.log(C)/2,u)
zero("action.C_origin",C.subs(origin)-1)
zero("action.U_origin",U.subs(origin)-q(3,2))
zero("action.origin_gradients",s.Matrix([s.diff(U,var).subs(origin) for var in [u,fx,fy]]))
zero("action.origin_coupling_norm",(bu**2/Kuu).subs(origin)-k)
Rm,Rr,H,p=s.symbols("Rm Rr H p",positive=True)
zero("background.Friedmann_normalization",
     (3*Q*H**2-3*Q*Hv**2-2*Q*(Rm+Rr))/(3*Q)
      -(H**2-Hv**2-q(2,3)*(Rm+Rr)))
zero("background.dust_acceleration_norm",Rm**2*(bu**2/Kuu).subs(origin)-Rm**2*k)
record("background.dust_acceleration_nonzero",(Rm**2*k).is_positive)

# Einstein Hamiltonian/momentum constraints determine the actual first row.
n,theta,th0,L,c=s.symbols("n theta th0 L c",real=True)
momentum=Rm*theta/p**2
delta_rho=2*Q*(Rm*n+4*Rr*th0)
CH_Einstein=p**2*L+3*H*momentum+delta_rho/(2*Q)
CH=p**2*L+Rm*n+4*Rr*th0+3*H*Rm*theta/p**2
zero("candidate.CH_from_Einstein",CH_Einstein-CH)
Tmap=s.Matrix([[-Rm/p**2,MOMENTUM_MAP_SIGN*3*H*Rm/p**4,-RADIATION_MAP_FACTOR*Rr/p**2],
               [0,1,0],[1,0,0]])
X=s.Matrix([n,theta,th0])
Lfrommap=(Tmap*X)[0]
zero("candidate.map_matches_Hamiltonian",CH.subs(L,Lfrommap))
zero("candidate.determinant",Tmap.det()-4*Rr/p**2)
record("candidate.positive_determinant",(4*Rr/p**2).is_positive)
Tinv=s.Matrix([[0,0,1],[0,1,0],[-p**2/(4*Rr),-3*H*Rm/(4*Rr*p**2),-Rm/(4*Rr)]])
zero("candidate.explicit_right_inverse",Tmap*Tinv-s.eye(3))
zero("candidate.explicit_left_inverse",Tinv*Tmap-s.eye(3))
W,velocity,Delta=s.symbols("W velocity Delta",real=True)
Y=s.Matrix([W,velocity,Delta])
back=Tinv*Y
zero("candidate.inverse_satisfies_constraint",CH.subs({L:W,n:back[0],theta:back[1],th0:back[2]}))
epsilon=s.symbols("epsilon",real=True)
physical_contrast=s.diff((1+epsilon*n)/(1+epsilon*c)**3,epsilon).subs(epsilon,0)
zero("frame.physical_density_contrast",physical_contrast-(n-3*c))
Tmetric=s.symbols("Tmetric",real=True)
zero("frame.W_coupling_cancels",((Tmetric+c)+(L-c))/2-(Tmetric+L)/2)
zero("frame.origin_readouts",s.Matrix([(Tmetric+L).subs(Tmetric,L)/2-L,(n-3*c).subs(c,0)-n]))

# Initial jet, including the generated dipole in the momentum derivative.
th1=s.symbols("th1",real=True)
Jfull=Rm*theta/p**2+4*Rr*th1/p
CHfull=p**2*L+Rm*n+4*Rr*th0+3*H*Jfull
Ldot=-H*L+Rm*theta/p**2
jet={
    Rm:-3*H*Rm,Rr:-4*H*Rr,H:-Rm-q(4,3)*Rr,p:-H*p,
    L:Ldot,n:-theta+3*Ldot,theta:-2*H*theta+p**2*L,
    th0:Ldot,th1:INCLUDE_GENERATED_DIPOLE*p*(th0+L)/3
}
CHdot=sum(s.diff(CHfull,var)*rate for var,rate in jet.items()).subs(th1,0)
zero("candidate.initial_constraint_propagation",CHdot+3*H*CH)
zero("candidate.initial_zero_shear_derivative",p*(2*0-3*0)/5)

# Exact constraint-compatible background and distinct correlated covariance.
values={k:q(1,11),nu:q(7,5),Q0:q(11,8),Q:q(3,2),Hv:q(1,2),H:1,Rm:q(2,5),Rr:q(29,40),p:q(7,3)}
zero("example.Q_binding",(Q-Q0*(1+k)).subs(values))
zero("example.background_constraint",(H**2-Hv**2-q(2,3)*(Rm+Rr)).subs(values))
M=s.simplify(Tmap.subs(values)); Minv=s.simplify(Tinv.subs(values))
B=s.Matrix([[1,q(1,2),0],[0,2,q(1,3)],[q(1,4),0,q(3,2)]])
Sreal=B*B.T
scale=q(1,10000)
Pstate=Minv*(scale**2*Sreal)*Minv.T
zero("example.covariance_reconstruction",M*Pstate*M.T-scale**2*Sreal)
record("example.S_positive_definite",psd(Sreal) and Sreal.det()>0)
record("example.P_positive_definite",psd(Pstate) and Pstate.det()>0)
samples=[]
for index,z in enumerate(itertools.product([-1,1],repeat=3)):
    ys=scale*B*s.Matrix(z)
    xs=Minv*ys
    zero("bounded.sample_map_"+str(index),M*xs-ys)
    zero("bounded.sample_constraint_"+str(index),
         CH.subs(values).subs({L:ys[0],n:xs[0],theta:xs[1],th0:xs[2]}))
    samples.append({"seed":z,"Y":ys,"X":xs})
zero("bounded.output_mean",sum([r["Y"] for r in samples],s.zeros(3,1))/8)
zero("bounded.input_mean",sum([r["X"] for r in samples],s.zeros(3,1))/8)
zero("bounded.output_covariance",sum([r["Y"]*r["Y"].T for r in samples],s.zeros(3))/8-scale**2*Sreal)
zero("bounded.input_covariance",sum([r["X"]*r["X"].T for r in samples],s.zeros(3))/8-Pstate)
bounds={
    "paired_potential":max(2*abs(r["Y"][0]) for r in samples),
    "paired_dust_contrast":max(2*abs(r["X"][0]) for r in samples),
    "paired_physical_velocity":max(2*abs(r["X"][1])/values[p] for r in samples),
    "paired_radiation_contrast":max(8*abs(r["X"][2]) for r in samples)
}
for name,bound in bounds.items():
    record("bounded."+name+"_small",bound<q(1,100),{"exact_bound":bound,"synthetic_threshold":q(1,100)})
record("bounded.dust_population_positive",bounds["paired_dust_contrast"]<1)
record("bounded.radiation_population_positive",bounds["paired_radiation_contrast"]<1)
chosen=samples[-1]
dipole_rate=values[p]*(chosen["X"][2]+chosen["Y"][0])/3
scalar_factor=-values[Rm]*(chosen["X"][0]+2*chosen["Y"][0])
record("dynamics.generic_dipole_generated",dipole_rate!=0,{"Theta1_dot":dipole_rate})
record("dynamics.generic_scalar_acceleration",scalar_factor!=0,{"pi_dot_coefficient_of_b":scalar_factor})

# Domain edges and conditioning do not follow from a positive determinant alone.
eta=s.symbols("eta",positive=True)
monopole_velocity=Tinv[2,1]*eta*p
record("conditioning.small_p_even_fixed_velocity",
       s.limit(monopole_velocity,p,0,dir="+")==-s.oo)
zero("conditioning.fixed_physical_velocity",(eta*p)/p-eta)
record("conditioning.large_p_fixed_W",s.limit(Tinv[2,0]*eta,p,s.oo)==-s.oo)
record("conditioning.small_Rr",s.limit(Tinv[2,0]*eta,Rr,0,dir="+")==-s.oo)
record("conditioning.small_p_determinant_misleads",s.limit(4*Rr/p**2,p,0,dir="+")==s.oo)
Mzero=Tmap.subs(Rr,0)
record("rank.no_radiation_loses_surjectivity",Mzero.rank()==2)
left=s.Matrix([[1,3*H*Rm/p**4,Rm/p**2]])
zero("rank.no_radiation_left_null",left*Mzero)

# Same initial seed across two epochs: exact support versus separate marginals.
aratio=2+s.I
Tstack=s.Matrix([1,aratio])
Pseed=q(3,2)
Sstack=Pseed*Tstack*adj(Tstack)
zero("time.correct_cross_orientation",Sstack[0,1]-s.conjugate(aratio)*Sstack[0,0])
zero("time.correct_second_auto",Sstack[1,1]-aratio*s.conjugate(aratio)*Sstack[0,0])
zero("time.ratio_from_nonzero_cross",s.conjugate(Sstack[0,1])/Sstack[0,0]-aratio)
Stime_bad=s.diag(Sstack[0,0],Sstack[1,1])
left_time=s.Matrix([[-aratio,1]])
zero("time.transfer_left_null",left_time*Tstack)
record("time.same_marginals",Stime_bad[0,0]==Sstack[0,0] and Stime_bad[1,1]==Sstack[1,1])
record("time.PSD_but_infeasible_joint",psd(Stime_bad) and left_time*Stime_bad!=s.zeros(1,2))
zero("time.two_independent_seeds_remove_this_restriction",s.eye(2)*Stime_bad*s.eye(2)-Stime_bad)
record("time.autos_do_not_fix_complex_phase",abs(aratio)**2==abs(s.conjugate(aratio))**2 and aratio!=s.conjugate(aratio))

details["complex_rank_one"]={"T":T,"Tplus":Tp,"S":S,"P0":P0}
details["nonexhaustive_kernel_family"]={"P0":base,"completion":completion,"difference_det":(completion-base).det()}
details["candidate"]={"T0":Tmap,"T0_inverse":Tinv,"exact_parameters":{str(a):b for a,b in values.items()},"S_factor":B,"S":Sreal,"scaled_P":Pstate}
details["bounded_samples"]=samples
details["real_field_bounds"]=bounds
details["initial_jet"]={"generated_dipole_rate":dipole_rate,"scalar_acceleration_coefficient_of_b":scalar_factor}
result={
    "schema":"independent-covariance-inverse-exact-results-v1",
    "scientific_author":"/root","checker":"/root/scalar_energy_check",
    "code_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "producer_access":False,"empirical_data_access":False,
    "formula_constants":{"adjoint_reconstruction":COVARIANCE_RECONSTRUCTION_ADJOINT,"radiation_factor":RADIATION_MAP_FACTOR,"momentum_sign":MOMENTUM_MAP_SIGN,"generated_dipole":INCLUDE_GENERATED_DIPOLE},
    "versions":{"python":sys.version,"sympy":s.__version__,"platform":platform.platform()},
    "counts":{"passed":sum(c["passed"] for c in checks),"failed":sum(not c["passed"] for c in checks),"total":len(checks)},
    "checks":checks,"details":details,"elapsed_seconds":time.monotonic()-started,
    "limits":["Exact finite-dimensional covariance theorem; no initial state selected.",
              "Initial candidate constraint and first jet only, not full trajectory integration.",
              "Bounded weak realization uses common amplitude rescaling, not a fixed measured covariance.",
              "Mode-pair reality is not an ensemble symmetry premise.",
              "No all-history parameter degeneracy, survey fit or formal audit."]
}
(out/"RESULTS_v1.json").write_text(json.dumps(serial(result),indent=2)+"\n")
print(json.dumps(result["counts"]),flush=True)
sys.exit(0 if result["counts"]["failed"]==0 else 1)
