#!/usr/bin/env python3
"""Freeze the requested note/protocol and named theory sources only."""
from pathlib import Path
import datetime as dt
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[6]
RR=".claude/science/physics-loops/revised-scalar-derivation-24h-20261013/rolling_local_response"
items=[
    (RR+"/covariance_inverse_v1/PROTOCOL_v1.json","PROTOCOL_v1.json",None),
    (RR+"/covariance_inverse_v1/DERIVATION_v1.md","DERIVATION_v1.md","9ce6b645bda34e4a28ca2b12c8cb99df5e93f9f273f719a2b17620b55a845bed"),
    (RR+"/kinetic_radiation_v1/DERIVATION_v3.md","KINETIC_DERIVATION_v3.md",None),
    (RR+"/observable_bridge_v1/DERIVATION_v2.md","OBSERVABLE_DERIVATION_v2.md","6fe7152ee4b082a577e597f9aea829824e63cf2d9540cd69cba3edaf9ae51729"),
    ("docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md","FULL_ACTION_CANONICAL_NOTE.md","39a0dd9e107edba23adbfe8cf070f8f279190c40c651dc905af9d59911cad000")
]
folder=ROOT/"sources"
folder.mkdir(exist_ok=False)
rows=[]
for rel,name,expected in items:
    data=(REPO/rel).read_bytes()
    digest=hashlib.sha256(data).hexdigest()
    assert expected is None or digest==expected
    snap=folder/name
    snap.write_bytes(data)
    rows.append({"original_path":rel,"snapshot_path":str(snap.relative_to(ROOT)),"bytes":len(data),"sha256":digest})
record={"created_utc":dt.datetime.now(dt.timezone.utc).isoformat(),"argv":[sys.executable,str(Path(__file__).resolve())],
        "cwd":str(Path.cwd()),"sources":rows,"all_sources_read_in_full":True,
        "producer_code_or_results_accessed":False,"new_empirical_data_accessed":False}
(ROOT/"SOURCE_MANIFEST_v1.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps(record,indent=2))
