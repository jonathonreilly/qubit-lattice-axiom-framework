#!/usr/bin/env python3
from pathlib import Path
import datetime as dt
import difflib
import hashlib
import json

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[6]
PARENT=ROOT.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=json.loads((ROOT/"SOURCE_MANIFEST_v1.json").read_text())
for name in ["DERIVATION_v2.md","QUALIFICATION_v2.diff","QUALIFICATION_v2.json"]:
    original=PARENT/name
    snap=ROOT/"sources"/name
    assert not snap.exists()
    data=original.read_bytes()
    if name=="DERIVATION_v2.md":
        assert hashlib.sha256(data).hexdigest()=="d10a1d93cf48b0f8a22fa01ce8a11e97118b2268e2683de84f5e14f44c33f8aa"
    snap.write_bytes(data)
    record["sources"].append({"original_path":str(original.relative_to(REPO)),"snapshot_path":str(snap.relative_to(ROOT)),"bytes":len(data),"sha256":sha(snap)})
old=(ROOT/"sources/DERIVATION_v1.md").read_text()
new=(ROOT/"sources/DERIVATION_v2.md").read_text()
changes=[
    ("Neither Gaussianity nor an unbounded random tail is required. Common amplitude",
     "That pairing alone does not establish statistical homogeneity, isotropy or\nparity of an ensemble; those survey conditions must be supplied or constructed\nseparately. Neither Gaussianity nor an unbounded random tail is required. Common amplitude"),
    ("requirements. The neighborhood is not uniform as Rr->0 or p->infinity.",
     "requirements. The neighborhood is not uniform as Rr->0, p->0 or p->infinity. At small p\nthe velocity contribution to Theta0 scales as theta_J/p^2 and the physical\npeculiar velocity scales as theta_J/p.")
]
reconstructed=old
for before,after in changes:
    assert reconstructed.count(before)==1
    reconstructed=reconstructed.replace(before,after)
assert reconstructed==new
assert [x for x in old.splitlines() if x.startswith("    ")]==[x for x in new.splitlines() if x.startswith("    ")]
diff="".join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile="DERIVATION_v1.md",tofile="DERIVATION_v2.md"))
assert diff==(ROOT/"sources/QUALIFICATION_v2.diff").read_text()
record["created_utc"]=dt.datetime.now(dt.timezone.utc).isoformat()
record["supplement"]="Preserved v1 and added v2 plus the exact author qualification diff/metadata."
assert not (ROOT/"SOURCE_MANIFEST_v2.json").exists()
(ROOT/"SOURCE_MANIFEST_v2.json").write_text(json.dumps(record,indent=2)+"\n")
correspondence={
    "created_utc":record["created_utc"],
    "v1_sha256":sha(ROOT/"sources/DERIVATION_v1.md"),
    "v2_sha256":sha(ROOT/"sources/DERIVATION_v2.md"),
    "exactly_two_stated_prose_replacements":True,
    "replacements":[{"before":a,"after":b} for a,b in changes],
    "displayed_equations_identical":True,
    "author_diff_exactly_matches":True,
    "mathematical_equations_changed":False,
    "original_findings_preserved":[
        "Fixed-p local weak feasibility was valid in v1, but the list of nonuniform limits omitted p->0.",
        "Mode pairing enforces reality; it is not an ensemble homogeneity/isotropy/parity premise."
    ],
    "producer_execution_accessed_or_rerun_claimed":False
}
(ROOT/"SOURCE_CORRESPONDENCE_v2.json").write_text(json.dumps(correspondence,indent=2)+"\n")
print(json.dumps({"source_pairs":len(record["sources"]),"v2_sha256":correspondence["v2_sha256"],"two_prose_changes_only":True},indent=2))
