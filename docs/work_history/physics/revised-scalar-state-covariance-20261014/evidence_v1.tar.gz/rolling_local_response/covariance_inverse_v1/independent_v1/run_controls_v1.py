#!/usr/bin/env python3
from pathlib import Path
import argparse
import datetime as dt
import difflib
import hashlib
import json
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
CODE=ROOT/"check_independent_v1.py"
parser=argparse.ArgumentParser()
parser.add_argument("phase",choices=["baseline","damages"])
args=parser.parse_args()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def execute(code,out):
    out.mkdir(parents=True,exist_ok=False)
    cmd=[sys.executable,str(code),"--output-dir",str(out)]
    rec={"argv":cmd,"cwd":str(ROOT),"code_sha256":sha(code),"started_utc":dt.datetime.now(dt.timezone.utc).isoformat()}
    (out/"COMMAND.json").write_text(json.dumps(rec,indent=2)+"\n")
    start=time.monotonic()
    try:
        proc=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,timeout=90)
        stdout,stderr,rc=proc.stdout,proc.stderr,proc.returncode
    except subprocess.TimeoutExpired as exc:
        stdout,stderr,rc=exc.stdout or "",exc.stderr or "",124
        if isinstance(stdout,bytes):stdout=stdout.decode(errors="replace")
        if isinstance(stderr,bytes):stderr=stderr.decode(errors="replace")
        stderr+="\nIndependent execution timeout at 90 seconds.\n"
    (out/"stdout.txt").write_text(stdout)
    (out/"stderr.txt").write_text(stderr)
    rec.update(returncode=rc,elapsed_seconds=time.monotonic()-start,completed_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
               stdout_sha256=sha(out/"stdout.txt"),stderr_sha256=sha(out/"stderr.txt"))
    if (out/"RESULTS_v1.json").exists():
        result=json.loads((out/"RESULTS_v1.json").read_text())
        rec.update(results_sha256=sha(out/"RESULTS_v1.json"),counts=result["counts"],
                   failed_checks=[c["name"] for c in result["checks"] if not c["passed"]])
    (out/"EXECUTION.json").write_text(json.dumps(rec,indent=2)+"\n")
    print(json.dumps(rec,indent=2),flush=True)
    return rec
if args.phase=="baseline":
    rec=execute(CODE,ROOT/"baseline_v1")
    sys.exit(rec["returncode"])
base=json.loads((ROOT/"baseline_v1/EXECUTION.json").read_text())
assert base["returncode"]==0
changes=[
    ("pseudoinverse_wrong_adjoint","COVARIANCE_RECONSTRUCTION_ADJOINT = True","COVARIANCE_RECONSTRUCTION_ADJOINT = False","PSD.complex_support_reconstruction"),
    ("candidate_radiation_factor","RADIATION_MAP_FACTOR = 4","RADIATION_MAP_FACTOR = 3","candidate.map_matches_Hamiltonian"),
    ("candidate_velocity_sign","MOMENTUM_MAP_SIGN = -1","MOMENTUM_MAP_SIGN = 1","candidate.map_matches_Hamiltonian"),
    ("omit_generated_dipole","INCLUDE_GENERATED_DIPOLE = 1","INCLUDE_GENERATED_DIPOLE = 0","candidate.initial_constraint_propagation")
]
folder=ROOT/"damages_v1"
folder.mkdir(exist_ok=False)
protocol={"saved_before_execution":True,"baseline_sha256":sha(CODE),
          "changes":[{"name":n,"before":a,"after":b,"required_failure":req} for n,a,b,req in changes],"producer_access":False}
(folder/"PROTOCOL.json").write_text(json.dumps(protocol,indent=2)+"\n")
original=CODE.read_text()
records=[]
for name,before,after,required in changes:
    assert original.count(before)==1
    changed=original.replace(before,after)
    code=folder/(name+".py")
    code.write_text(changed)
    (folder/(name+".diff")).write_text("".join(difflib.unified_diff(original.splitlines(keepends=True),changed.splitlines(keepends=True),fromfile=CODE.name,tofile=code.name)))
    rec=execute(code,folder/name)
    rec.update(name=name,required_failure=required,detected=rec["returncode"]==1 and required in rec.get("failed_checks",[]))
    records.append(rec)
summary={"all_detected":all(r["detected"] for r in records),"controls":records,
         "protocol_sha256":sha(folder/"PROTOCOL.json"),"baseline_sha256":sha(CODE)}
(folder/"SUMMARY.json").write_text(json.dumps(summary,indent=2)+"\n")
sys.exit(0 if summary["all_detected"] else 1)
