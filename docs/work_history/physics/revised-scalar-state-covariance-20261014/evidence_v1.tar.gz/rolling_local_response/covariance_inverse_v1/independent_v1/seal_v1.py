#!/usr/bin/env python3
"""Seal only this completed covariance check, with the original findings preserved."""
from pathlib import Path
import datetime as dt
import hashlib
import json

ROOT=Path(__file__).resolve().parent
REPO=ROOT.parents[6]
for name in ["FAILURES_v1.json","COMMAND_INDEX_v1.json","MANIFEST_v1.json","RECEIPT_v1.json"]:
    assert not (ROOT/name).exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def bind(rel):
    p=ROOT/rel
    return {"path":rel,"bytes":p.stat().st_size,"sha256":sha(p)}
def write(name,obj):
    p=ROOT/name
    assert not p.exists()
    p.write_text(json.dumps(obj,indent=2)+"\n")
sources=json.loads((ROOT/"SOURCE_MANIFEST_v2.json").read_text())["sources"]
for row in sources:
    live=REPO/row["original_path"];snap=ROOT/row["snapshot_path"]
    assert sha(live)==sha(snap)==row["sha256"]
    assert live.stat().st_size==snap.stat().st_size==row["bytes"]
base=json.loads((ROOT/"baseline_v1/EXECUTION.json").read_text())
assert base["returncode"]==0 and base["counts"]=={"passed":98,"failed":0,"total":98}
assert base["code_sha256"]==sha(ROOT/"check_independent_v1.py")
for field,file in [("results_sha256","RESULTS_v1.json"),("stdout_sha256","stdout.txt"),("stderr_sha256","stderr.txt")]:
    assert base[field]==sha(ROOT/"baseline_v1"/file)
summary=json.loads((ROOT/"damages_v1/SUMMARY.json").read_text())
assert summary["all_detected"] and len(summary["controls"])==4
damage_failures=[]
for row in summary["controls"]:
    folder=ROOT/"damages_v1"/row["name"]
    assert row["code_sha256"]==sha(ROOT/"damages_v1"/(row["name"]+".py"))
    for field,file in [("results_sha256","RESULTS_v1.json"),("stdout_sha256","stdout.txt"),("stderr_sha256","stderr.txt")]:
        assert row[field]==sha(folder/file)
    result=json.loads((folder/"RESULTS_v1.json").read_text())
    failed=[v for v in result["checks"] if not v["passed"]]
    assert row["returncode"]==1 and row["required_failure"] in [v["name"] for v in failed]
    damage_failures.append({"name":row["name"],"counts":row["counts"],"exit_code":row["returncode"],
                            "required_failure":row["required_failure"],"actual_failures":failed,
                            "code_sha256":row["code_sha256"],"results_sha256":row["results_sha256"]})
write("FAILURES_v1.json",{
    "unexpected_baseline_failures":[],
    "tooling_exceptions_timeouts_or_repairs":[],
    "baseline_counts":base["counts"],
    "original_source_findings":[
        {"issue":"The weak neighborhood also becomes nonuniform as p->0.",
         "original_status":"V1 fixed-p theorem remained correct; listed boundary qualifications were incomplete.",
         "witness":"theta_J=eta p keeps physical speed finite while inverse Theta0=-3H Rm eta/(4Rr p) diverges.",
         "resolution":"Explicitly added to v2; v1 remains frozen."},
        {"issue":"Conjugate Fourier pairing alone does not impose ensemble homogeneity/isotropy/parity.",
         "witness":"Real Rademacher standing-wave variance is position dependent.",
         "resolution":"Explicitly qualified in v2; no covariance equation changed."}
    ],
    "actual_expected_damage_failures":damage_failures,
    "additional_source_equation_error_identified":False,
    "producer_code_or_results_accessed":False,
    "failures_hidden_or_overwritten":False
})
write("COMMAND_INDEX_v1.json",{
    "source_freeze_command":"SOURCE_MANIFEST_v1.json",
    "source_v2_correspondence":"SOURCE_CORRESPONDENCE_v2.json",
    "baseline_command":"baseline_v1/COMMAND.json",
    "baseline_execution":"baseline_v1/EXECUTION.json",
    "baseline_stdout":"baseline_v1/stdout.txt","baseline_stderr":"baseline_v1/stderr.txt",
    "damages":[{"name":row["name"],"command":"damages_v1/"+row["name"]+"/COMMAND.json",
                "execution":"damages_v1/"+row["name"]+"/EXECUTION.json",
                "stdout":"damages_v1/"+row["name"]+"/stdout.txt",
                "stderr":"damages_v1/"+row["name"]+"/stderr.txt"} for row in summary["controls"]],
    "producer_or_optional_followon_access":False,
    "new_empirical_access":False
})
now=dt.datetime.now(dt.timezone.utc).isoformat()
files=sorted(p for p in ROOT.rglob("*") if p.is_file())
assert not any(p.is_symlink() for p in ROOT.rglob("*"))
assert not any(p.suffix in {".pyc",".npz"} for p in files)
artifacts=[bind(str(p.relative_to(ROOT))) for p in files]
write("MANIFEST_v1.json",{
    "schema":"independent-review-artifact-manifest-v1",
    "created_utc":now,"artifact_root":str(ROOT),"artifact_count":len(artifacts),
    "excludes":["MANIFEST_v1.json","RECEIPT_v1.json"],"artifacts":artifacts
})
write("RECEIPT_v1.json",{
    "schema":"focused-independent-mathematical-check-receipt-v1",
    "created_utc":now,"unit":"rolling_local_response/covariance_inverse_v1/independent_v1",
    "scientific_author":"/root","independent_checker":"/root/scalar_energy_check",
    "formal_audit":False,"formal_grade_or_authority_state_changed":False,
    "source_bindings":sources,
    "manifest":bind("MANIFEST_v1.json"),"report":bind("REPORT_v1.md"),
    "hand_derivation":bind("HAND_DERIVATION_v1.md"),"protocol":bind("PROTOCOL_v1.json"),
    "independent_code":bind("check_independent_v1.py"),"execution_driver":bind("run_controls_v1.py"),
    "baseline_execution":bind("baseline_v1/EXECUTION.json"),
    "baseline_results":bind("baseline_v1/RESULTS_v1.json"),"baseline_counts":base["counts"],
    "damage_summary":bind("damages_v1/SUMMARY.json"),
    "damage_counts":[{"name":r["name"],"counts":r["counts"],"exit_code":r["returncode"],"detected":r["detected"]} for r in summary["controls"]],
    "failure_ledger":bind("FAILURES_v1.json"),
    "source_correspondence":bind("SOURCE_CORRESPONDENCE_v2.json"),
    "command_index":bind("COMMAND_INDEX_v1.json"),
    "scope":[
        "Finite complex PSD covariance support and constructive pseudoinverse",
        "Valid but nonexhaustive kernel-addition family",
        "Bounded initial realizations and complex mode reality qualifications",
        "Action origin, background constraint, and physical instantaneous output map",
        "Radiation-monopole inverse, rank and initial Hamiltonian propagation derivative",
        "Distinct exact bounded samples, conditioning limits and stacked covariance support",
        "Narrow v1-to-v2 qualification correspondence"
    ],
    "source_disposition":{
        "displayed_equations_unchanged":True,
        "v1_scope_findings_preserved":True,
        "v2_qualifications_confirmed":True,
        "additional_mathematical_equation_correction_required":False,
        "producer_rerun_claimed":False
    },
    "independence":{
        "own_hand_derivation_and_protocol_before_execution":True,
        "producer_code_results_trajectories_accessed":False,
        "new_empirical_data_accessed":False,
        "optional_homogeneous_ensemble_followon_inspected":False,
        "all_writes_confined_to_this_new_directory":True,
        "previous_evidence_or_parent_source_changed":False,
        "git_PR_runtime_lock_or_audit_state_changed":False
    },
    "limits":[
        "No state, quantum covariance, background or matter sector is selected.",
        "Full-row-rank feasibility is conditional on the specified transfer and unrestricted initial covariance.",
        "The origin event is explicit initial data; dust immediately accelerates the background scalar.",
        "The independent kinetic check here is of the initial constraints and their first propagation derivative, not a full repeated kinetic review or numerical history.",
        "Small bounded realizations use rescaled covariance and do not certify arbitrary fixed measured amplitudes.",
        "Positive initial brightness/density and weak readouts do not certify every phase-space realization or nonlinear completion.",
        "Mode-pair reality is distinct from ensemble symmetry; the optional ensemble follow-on is excluded.",
        "No all-history parameter degeneracy, survey fit, empirical acceptance or formal audit."
    ]
})
for row in artifacts:
    p=ROOT/row["path"]
    assert sha(p)==row["sha256"] and p.stat().st_size==row["bytes"]
assert len([p for p in ROOT.rglob("*") if p.is_file()])==len(artifacts)+2
print(json.dumps({
    "artifact_count_excluding_manifest_receipt":len(artifacts),"total_regular_files":len(artifacts)+2,
    "source_pairs":len(sources),"report_sha256":sha(ROOT/"REPORT_v1.md"),
    "manifest_sha256":sha(ROOT/"MANIFEST_v1.json"),"receipt_sha256":sha(ROOT/"RECEIPT_v1.json"),
    "all_bound_artifacts_verified":True
},indent=2))
