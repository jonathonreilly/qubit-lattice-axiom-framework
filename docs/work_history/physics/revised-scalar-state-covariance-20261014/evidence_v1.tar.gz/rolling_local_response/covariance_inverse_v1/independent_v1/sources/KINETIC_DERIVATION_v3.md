# Remove the perfect-radiation closure rather than assuming it

Direct scientific author /root. Conditional-support. The preceding two-fluid
system is internally consistent for explicitly perfect fluids, but that premise
is not a consequence of masslessness or of this scalar action. I reconstruct
the standard collisionless transport equation and derive its consequences for
this candidate's physical gravity readout. The primary methodological source is
Ma and Bertschinger (1995), equations23d,47,48,50,
https://arxiv.org/pdf/astro-ph/9506072 . This is exposed theory/development
material, not observational data or an independent empirical test. The saved
source protocol and PDF checksum are in radiation_dust_transfer_v1.

## Conventions and transport

Use Einstein metric ds^2=-(1+2T)dt^2+a_E^2(1-2L)dx^2. Unlike the earlier
perfect-fluid block, do not identify time potential T and spatial potential L.
Write p=q/a_E>0. A collisionless massless population with isotropic background
and linear temperature/brightness perturbation Theta(t,mu) obeys the null
geodesic transport equation

    dot Theta+i p mu(Theta+T)=dot L.                  (1)

This uses the supplied universal conformal metric coupling and an explicit
classical, collisionless, massless matter model. Null propagation is conformally
invariant; it does not select the particle spectrum, distribution or abundance.
Expand Theta=sum_l(-i)^l(2l+1)Theta_l P_l(mu). Angular integration of(1) gives

 dot Theta_0=-p Theta_1+dot L,
 dot Theta_1=p(Theta_0+T-2Theta_2)/3,
 dot Theta_l=p[l Theta_(l-1)-(l+1)Theta_(l+1)]/(2l+1), l>=2. (2)

The Einstein radiation density contrast is4Theta_0, physical-velocity divergence
is theta_r=3pTheta_1, and shear variable sigma_r=2Theta_2. These definitions fix
all factors and signs. Conformal time is the same in both frames. For the
physical brightness monopole Theta_J0=Theta_0-c, c=<b,xi>; l>=1 moments are
unchanged. The physical potentials are T_J=T+c and L_J=L-c.

Setting every multipole l>=2 to zero throughout an open time interval is not
generically invariant at nonzero p. The quadrupole equation then forces
Theta_1=0, the dipole equation forces Theta_0=-T, and the monopole equation
requires dot(L+T)=0. This leaves an exceptional force-balanced solution of the transport subsystem.
Its compatibility with a nontrivial solution of the full coupled Einstein,
scalar and dust equations is not proved here. It does not justify a generic
perfect-fluid truncation. For a prescribed constant
metric and initially isotropic Theta_i, the exact solution is

 Theta(tau,mu)=(Theta_i+T)exp[-i q mu(tau-tau_i)]-T,
 Theta_l=(Theta_i+T) j_l(q Delta tau), l>=1,
 Theta_0=(Theta_i+T)j_0(q Delta tau)-T.                (3)

Thus an initially zero quadrupole is generated at order(q Delta tau)^2 unless
Theta_i=-T. This is a transport counterexample in an externally prescribed
metric, not a self-consistent radiation cosmology. It rejects the generic exact
perfect-fluid route. Collisions could provide a controlled approximation, but
an actual collision operator, rate and initial-state error would then need
justification; none is inserted here.

## Close the dust, radiation, scalar and metric constraints

Keep the supplied field geometry, b=grad ln sqrt(C), V=Hv^2 grad U and
Q,Hv. Set R_m=rho_m/(2Q), R_r=rho_r/(2Q). Background equations are the
previous two-fluid equations at w_m=0,w_r=1/3. Radiation is trace-free even
with these linear anisotropies and has dot rho_r=-4H rho_r.

For the angular stress, delta T^z_z-delta T^x_x equals -4rho_r Theta_2.
The traceless Einstein equation consequently gives

    Z=L-T=8 R_r Theta_2/p^2,
    dot Z=8R_r[dot Theta_2-2HTheta_2]/p^2.            (4)

This equation is to be independently checked, including its normalization.
Canonical scalar fields and pressureless dust have no first-order anisotropic
stress, so no other shear term enters under these matter premises.

Let n_m be the Einstein proper number contrast and theta_m its divergence.
The independent metric evolution is

 F=dot L=-H T+<v,xi>+J,
 J=R_m theta_m/p^2+4R_r Theta_1/p,
 T=L-Z, dot T=F-dot Z.                               (5)

Then the remaining closed equations are

 dot n_m=-theta_m+3F,
 dot theta_m=-(2H+<b,v>)theta_m+p^2(T+c),
 D_t xi=pi,
 D_t pi=-3Hpi-(p^2 I+M)xi+v(dot T+3F)
                           -2(V+R_m b)T-R_m b n_m,
 M xi=nabla_xi V+Riem(xi,v)v+R_m[nabla_xi b+b<b,xi>]. (6)

Together with the full angular equation(1), this is an untruncated linear
collisionless transfer system. An angular discretization is still a numerical
approximation and must be tested; no finite multipole closure is asserted.
The initial Hamiltonian constraint is

 C_H=p^2 L-|v|^2 T+3H<v,xi>+<V,xi>+<v,pi>
                         +R_m(n_m+c)+4R_rTheta_0+3HJ=0. (7)

Before imposing(4), my proposed propagation identity is

 dot C_H+3H C_H=H[p^2(L-T)-8R_rTheta_2].              (8)

If confirmed, the physical shear constraint preserves the Hamiltonian
constraint; it does not select the initial scalar wave or angular distribution.
This exact check must precede the coupled numerical experiment.

## Consequence for reconstructed gravity

Using the same common source in definitions of mu and Sigma, the physical
potential ratio is

 g_obs=mu/Sigma-1=(T_J-L_J)/(T_J+L_J)
                  =(2c-Z)/(2L-Z),                  (9)

where the mean is nonzero. It reduces to c/L when Z=0. More precisely, where
L and 2L-Z are nonzero, g_obs-c/L=Z(c-L)/[L(2L-Z)]. Equality can also hold
at c=L with nonzero Z, giving both ratios one; this exceptional algebraic
branch does not establish a dynamically selected solution. A vanishing observed
ratio could therefore reflect2c=Z rather than absent scalar coupling. This is an
algebraic possibility, not a derived dynamically selected cancellation. Source
calibration, finite-body response, galaxy bias, light-cone transfer and a data
likelihood remain absent. No published phenomenological bound is substituted.
