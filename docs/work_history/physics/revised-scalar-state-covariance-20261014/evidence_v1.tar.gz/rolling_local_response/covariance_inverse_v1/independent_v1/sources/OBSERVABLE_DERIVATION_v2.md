# From measured lensing and velocities to a testable state assumption

Direct author /root. Observations motivate this block: the accessible quantities
are projected correlations and redshift distortions, not paired local potential
time traces. The calculation below reconstructs established measurement
kinematics and applies a covariance test to the supplied scalar transfer model.
It derives no particle content, initial spectrum or numerical theory parameter.

The primary observational example is [Reyes et al. (2010)](https://arxiv.org/pdf/1003.2185),
equations1-3 and pages2-6: an annular lensing/clustering ratio divided by an
estimated redshift-distortion parameter. Its reported scale-averaged E_G is
0.392+-0.065 at effective redshift0.32 over10-50 h^-1 Mpc. Bias corrections
and lensing calibration enter the analysis. This historical result is exposed
development information, not a newly fitted or independently reserved test.
The raw catalogues, covariance and full estimator likelihood are not obtained.

[Zhang et al. (2007)](https://arxiv.org/pdf/0704.1932), equations1,5,6,
formulates a ratio of lensing/galaxy and velocity/galaxy cross spectra. Its
metric convention is psi=T_J, phi=-L_J in ours, and its dimensionless velocity
divergence is theta_J/H_J. Its bias/amplitude cancellation and conversion from
redshift-space spectra have linear-regime and geometry assumptions. Neither
paper's summary statistic equals our vacuum g(N) trace. No published gravity
interval is transferred to k or nu here.

## Physical velocity dynamics without an initial velocity selector

In the physical matter metric let T_J,L_J be its time/space potentials,
W=(T_J+L_J)/2, t_J proper background time, H_J its expansion rate and
p_J=q/a_J>0. For a separately conserved pressureless freely falling tracer,

    dot theta_J+2H_J theta_J=p_J^2 T_J.             (1)

This follows from physical stress conservation, already checked in the dust
transfer block. It assumes an actual velocity tracer for this matter law;
galaxy velocity bias, pressure and selection are not eliminated by notation.
With a C^1 compact weight w that vanishes at its endpoints,

    integral(-dot w+2H_J w)theta_J dt_J
        =integral w p_J^2 T_J dt_J.                (2)

No prescribed initial theta_J appears in (2); the measured velocity history
retains its effect. Subtracting integral w p_J^2 W gives the weighted slip
integral. A ratio to that nonzero integral is a weighted potential comparison,
not the instantaneous g=(T_J-L_J)/(T_J+L_J), unless additional constancy holds.
Measured H_J,p_J, matched spacetime support and error envelopes are still
needed. Redshift-distortion power spectra do not directly provide this entire
proper-time velocity history of one Fourier mode.

With the primary paper's Fourier/velocity conventions, its ideal mode E_G
would be

    E_G=2 a_J^3 p_J^2 H_J W/(3H0^2 theta_J),        (3)

where a_J(today)=1 and H0 is a specified physical calibration. It involves
the evolved velocity, not just the ratio T_J/W. For a narrow matched bin the
correlation version replaces W/theta_J by P_gW/P_gtheta, with the paper's
sign convention for its named galaxy-velocity power translated consistently.
Actual projection kernels, geometry and sample selection still need a forward
model; equation(3) is not a direct replacement for an annular survey estimator.

## Which initial-state dependence cancels?

For fixed supplied background and parameters, the linear transfer system maps
initial amplitudes X to W=w.X, theta_J=v.X and delta_g=d.X. Use centered
perturbation amplitudes with E[X]=0 and finite second moments. Let P be their
positive-semidefinite initial covariance. For nonzero means the conclusions
below instead concern centered readouts; covariance alone does not constrain
the uncentered mean. These second moments do not require Gaussianity. Then

    P_gW=d P w*, P_gtheta=d P v*,
    R=P_gW/P_gtheta.                               (4)

A common overall normalization of P cancels. A deterministic common galaxy
bias d=b d_m also cancels. Neither cancellation removes the direction or
relative eigenvalues of P. The scalar and angular transfer system permits
several independent initial modes; replacing them by one common growing seed
would be an additional assumption.

For two uncorrelated real seeds with variances P1,P2,

    R=(P1 d1 w1+P2 d2 w2)/(P1 d1 v1+P2 d2 v2).     (5)

For example d=(1,1),w=(2,1),v=(1,3) gives
R=(2P1+P2)/(P1+3P2), even though common bias and overall amplitude cancel.
These generic coefficients illustrate the algebra only. A separate frozen
post-processing experiment uses two actual constraint-satisfying solutions
of this candidate's kinetic transfer system, rather than claiming these
arbitrary coefficients arise from that action.

## Turn coherence into an observable condition

The covariance inequality gives

    D_obs=P_WW P_thetatheta-|P_Wtheta|^2>=0.        (6)

For the two real seeds it is exactly

    D_obs=P1 P2 (w1 v2-w2 v1)^2.                   (7)

If D_obs>0, these two readouts cannot be represented by a single deterministic
transfer ratio on the stochastic support. If D_obs=0 and P_thetatheta>0,
there exists lambda=P_Wtheta/P_thetatheta such that
E[|W-lambda theta_J|^2]=0. Thus W=lambda theta_J in mean square, even if
many hidden initial modes exist. Any tracer with nonzero cross correlation
then gives R=lambda* with equation(4)'s P_gW=E[delta_g W*] convention;
for real transfer/readout data this is R=lambda. Coherence does not prove a single physical seed or select the
initial state. It does supply a condition that could be tested using matched,
noise-corrected auto/cross spectra instead of being silently assumed.

An apparent violation of (6) in estimated spectra can reflect noise subtraction,
finite samples or mismatched windows; it is not an automatic gravity falsification.
Actual lensing and velocity reconstruction kernels must be matched before
such an interpretation. The existing E_G summary alone is insufficient to
evaluate this coherence condition or infer the scalar coupling. A successful
synthetic test will therefore establish a measurement dependency, not a fit.
