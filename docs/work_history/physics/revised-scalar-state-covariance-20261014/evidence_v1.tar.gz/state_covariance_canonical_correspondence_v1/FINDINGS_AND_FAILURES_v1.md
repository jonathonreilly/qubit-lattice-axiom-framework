# Findings and preserved failures

## Resolved new prose findings

- The initial staged wrapper's unqualified “that freedom” could attribute arbitrary complex Hermitian covariance to the real symmetric spatial construction. Parent changed only the introductory phrase to specify real symmetric covariance.
- “Single-mode premise” could conflict with the construction's monochromatic-shell nature. Parent changed it to “single common growing-seed premise.”

Original staged note SHA256: `c47aeb6e2cdd0617bc62a0cdfb841adff5bfa33c9917cbe60b2f2090cc49a65f`. Final note SHA256: `5ac1796b19252dc3f04579bca00959e4c4f13a091344be989bbd50e515a629ba`. Initial snapshot, author history, exact parent diff, independently generated diff and both lineages are preserved. The independent check proves there are only those two replacements. No numerical rerun was needed or performed for the prose correction.

## Historical failure and repair retained

The original covariance checker attempted `S.Zero`, causing `AttributeError` before writing its result. Its source, streams, command/execution and exact one-line repair to `S.Integer(0)` are retained. The subsequent successful run is not relabelled as the first run. The later proof qualification preserves the distinction between a real paired mode and a symmetric ensemble, and the nonuniform small-amplitude domain.

## Intended damaged executions retained

Prior independent CI baseline: 98/0; four actual altered independent programs: 92/6, 85/13, 85/13 and 97/1, each exit 1. Prior independent HE baseline: 109/0; three altered programs: 100/9, 108/1 and 101/8, each exit 1. These are inherited exact evidence.

New parent staged altered programs: 100/4 for omitted momentum factor, 99/5 for wrong radiation factor and 95/9 for missing sqrt(2) spatial amplitude. Each intended witness fails and each recorded exit is 1. All saved rows and exact altered sources were inspected, not rerun.

New reviewer wrapper controls: deliberately failing unit data produce 3/1 and exit 1 in each of two cases; an all-pass provider produces 4/0 and exit 0. These expected nonzero exits are sensitivity evidence, not hidden review errors. No scientific function is executed by these wrappers.

## Reviewer outcome

Initial correspondence: 495/0. Affected final-note identity check: 406/0. No unexpected reviewer process or assertion failure occurred in those executions. All findings, original failed producer evidence, altered-program failures and versioned sources remain recoverable. No sealed earlier report or receipt was modified.
