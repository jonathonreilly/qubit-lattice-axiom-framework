# Focused staged state-covariance correspondence review

Reviewer: `/root/direct_field_check`. Scientific author: `/root`. Date: 2026-10-14.

The final staged note and runner preserve the two checked source arguments and their complete scientific outputs. Two ambiguities in the new introductory/concluding prose were identified during this review and corrected by the author. The original note remains recoverable. No unresolved discrepancy was found within this staged correspondence scope.

This is a source-bound correspondence check, not a new proof of the whole action, an empirical assessment, a formal audit, a retained-grade decision, or a confirmation of a committed delivery. The original scientific computations and prior independent checks were reused by exact identity. They were not rerun.

## Exact final subjects and recovery

Paths below are relative to the campaign pack unless stated otherwise.

- Final note: `state_covariance_packaging/staged/EXPONENTIAL_SCALAR_STATE_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-14.md`, SHA256 `5ac1796b19252dc3f04579bca00959e4c4f13a091344be989bbd50e515a629ba`.
- Runner: `state_covariance_packaging/staged/exponential_scalar_state_covariance_check.py`, SHA256 `4130039628b51f00abc98d42b77cf1aa7e1512d04a839a34b9fc10eea75e8f1a`.
- Original staged note: SHA256 `c47aeb6e2cdd0617bc62a0cdfb841adff5bfa33c9917cbe60b2f2090cc49a65f`. It is preserved in both this review's initial snapshot and the author's `state_covariance_packaging/history/STAGED_NOTE_v1.md`.
- `CANONICAL_LINEAGE_v1.json` remains unchanged. The separate v2 lineage and exact note diff are captured in `affected_v2/sources/`.

`SOURCE_BINDINGS_v1.json` froze 172 original/snapshot pairs. `SOURCE_BINDINGS_v2.json` added 21 files containing the completed parent damage runs and output comparison, giving 193 pairs. The coordinated prose correction added four separately captured version bindings: final note, v2 lineage, original-note history, and exact diff. Thus 197 frozen version bindings cover 196 unique source paths. `original_dispositions_v1.json` gives an explicit original hash, recovery location/hash, disposition, and final location/hash for every path. Only the initial staged-note path has different original and final hashes; its change is fully accounted for.

## Complete correspondence and execution evidence

I read the complete staged note and runner, both prior independent reports, their actual receipt/manifest schemas, the source protocols and correction records, and the preserved kinetic/observable context. I compared the complete original proof bodies with the staged bodies after the declared title removal, heading demotion and three reference replacements. Both body byte comparisons are exact. Their final body hashes are `849369ac7529caed365274d84bfe2d4b44315563ea38e7370b53532795d7f218` and `ecaaab7e31c41cfd0d851f801d3b5cacd357ac26ed3ed476a517c39d0809a66f`.

The scientific function bodies match the original producer code as complete ASTs: 72 covariance/support statements and 35 ensemble statements. The changes are the documented removal of old entrypoint/file-output plumbing, localization in two functions, return of complete original result objects, and an outer wrapper. These comparisons include the result construction; no changed scientific statement was excused as packaging.

All 70 covariance/support rows and all 34 ensemble rows were compared in order, preserving duplicate row names, after only renaming `ok` to `passed` and adding the unit namespace. Every other row field agrees. All saved scientific tables, scope strings, bounded-realization values, the ensemble covariance matrix and amplitude agree exactly. The saved staged result is 104/0; its source hash binds the frozen runner, its stdout equals the result bytes, stderr is empty, and the command and successful execution record agree. This is verification of the recorded execution, not another execution of the producer's science.

The initial reviewer computation produced 495 passed assertions and zero failed assertions. The affected-only final-note computation produced 406 passed assertions and zero failed assertions. These are correspondence/identity counts, not additional physical control families. They are preserved with full code, commands, streams and row-level results.

## Prior independent evidence reused

The covariance review receipt is `4fd52eb3973d02cffc714e8806faba80a90515cde23f46c5685a40640c8f92f3`. I verified its 56 manifest artifacts, closed inventory, eight original/snapshot source pairs, report and evidence references. Its independently executed baseline was 98/0. Its four actual damaged independent programs produced 92/6, 85/13, 85/13 and 97/1, each with the intended failed witness and exit 1.

The ensemble review receipt is `abeaef063931055ffaa52157a30e57a91b0af361f28f3b86d386509b0f46c08a`. I verified its 48 manifest artifacts, closed inventory, three science-source pairs and three reused covariance seal pairs. Its baseline was 109/0; its three actual damaged independent programs produced 100/9, 108/1 and 101/8, each with the intended failed witness and exit 1. The 104 prior manifest artifacts are a separate count from the 104 staged scientific assertion rows. These earlier computations are reused, not claimed as newly executed review evidence.

## Actual damage and wrapper sensitivity

The new author-supplied staged damages are actual altered-program executions, distinct from algebraic damaged-expression examples and from the earlier independent programs. I compared each full altered source against the frozen staged runner, verified its one declared replacement and exact diff, consumed all 104 result rows, and checked its recorded execution, source identity, failed witness and streams:

| Actual change | Saved passed/failed | Required witness | Exit |
|---|---:|---|---:|
| Momentum factor 3 to 0 | 100/4 | `inverse::candidate.right_inverse` | 1 |
| Radiation factor 4 to 3 | 99/5 | `inverse::candidate.determinant` | 1 |
| Remove spatial amplitude sqrt(2) | 95/9 | `ensemble::covariance.phase_signs_00` | 1 |

These three author runs were inspected, not rerun. In addition I executed the exact new outer wrapper with small stub result providers, without importing or running either scientific function. Deliberately incorrect provider counts and repeated row names test that the wrapper recomputes counts from rows, preserves all rows/tables, normalizes the boolean field, and returns exit 1 when either unit fails. The all-pass case exits 0; both intended failing cases exit 1. All three wrapper tests behaved as required.

## Findings and scope

The first new wrapper said the spatial ensemble realized “that freedom” immediately after the general positive-semidefinite covariance statement. Part I allows complex Hermitian mode covariance, while the explicit Part II construction uses real symmetric S0 and a real factor. The author narrowed this sentence to “the real symmetric covariance freedom.” The final line's “single-mode premise” was also ambiguous because the ensemble is a monochromatic shell. It now says “single common growing-seed premise.” Both changes are independently reproduced as exactly two string replacements; neither proof body, runner, result, prior seal or other frozen source changed. The new v2 lineage and parent diff match the actual bytes. These are resolved wording findings, preserved rather than erased from the review history.

The mathematical scope remains appropriately bounded. The support theorem concerns exact centered signal covariance for a specified finite linear transfer: positivity and range containment are necessary and sufficient. The displayed null-space additions do not purport to exhaust all positive completions with cross blocks. Full row rank removes identification from that unrestricted covariance fit; it does not remove background, amplitude, independent-observation or state restrictions.

The candidate right inverse is at an allowed origin event with positive radiation and dust and fixed finite p>0. Dust immediately accelerates the scalar background; the note does not freeze it at a vacuum over time. Radiation multipoles initially set to zero generally develop, and the initial monopole is not a permanently perfect-fluid ansatz. The weak neighborhood is nonuniform as radiation vanishes or wavelength limits are approached. The density readout uses the declared physical Newtonian-gauge contrast, not an unqualified observed galaxy or comoving-density estimator.

The bounded ensemble supplies real fields, translation/rotation/parity-invariant laws and the sinc-shell covariance. It does not select an initial state, imply ergodicity, furnish a measured broadband spectrum, solve the nonlinear initial constraints, or show arbitrary fixed observed amplitudes are weak. Multi-epoch support helps only when the actual stacked transfer has left-null relations and the requisite common-state cross-time covariance is available. The note preserves the light-cone, projection, noise, velocity and selection qualifications; a finite number of bins is not asserted to force rank deficiency.

No observational data or likelihood was added to the staged runner. The historical E_G discussion remains exposed context from the recovered observable note, not a new calibrated transfer or empirical acceptance. The complete action is supplied as a dependency. No state-selection, universal survey no-go, finite-epoch no-go, or formal status promotion is established by this port.

## Failure preservation and disposition

The original covariance producer's first execution failed with SymPy's absent `Zero` attribute before a result file was written. The exact original source, traceback and one-line `S.Zero` to `S.Integer(0)` repair remain in the frozen recovery. The successful original 70/0 run belongs to the repaired checker and its recorded original proof input; later prose qualifications are not retroactively presented as that executed input. Prior independent damaged-run failures, new staged damaged-run failures, and intentional wrapper failures remain complete.

There was no unexpected reviewer computational failure in this correspondence stage. The two wrapper wording findings were resolved through separately captured author revisions. This report, the source dispositions, complete evidence inventory and receipt bind the final staged state only. Public archive contents, canonical live cache, branch commit, topology and mechanical delivery gates are outside this check and would require a separate delivery confirmation.
