"""Reviewer-owned complete staged source/recovery/final mappings; no source mutation."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

OUT = Path(__file__).resolve().parent
PACK = OUT.parent
ROOT = PACK.parents[3]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

def save(name, value):
    with (OUT/name).open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

initial = load(OUT/'SOURCE_BINDINGS_v2.json')['sources']
affected = load(OUT/'affected_v2/SOURCE_BINDINGS.json')['sources']
all_rows = initial + [r for r in affected if r['original_path'] not in {x['original_path'] for x in initial}]
affected_by_path = {r['original_path']: r for r in affected}
dispositions = []
for row in all_rows:
    original = ROOT/row['original_path']
    recovery = OUT/row['snapshot_path']
    assert sha(recovery) == row['sha256'] and recovery.stat().st_size == row['bytes']
    final_hash = sha(original)
    changed = final_hash != row['sha256']
    final_row = affected_by_path[row['original_path']] if changed else row
    assert final_hash == final_row['sha256']
    d = {'original_path': row['original_path'], 'original_sha256': row['sha256'], 'disposition': 'two_scope_clarifications_only_original_preserved' if changed else 'preserved_exact_in_staged_review', 'recovery': {'path': recovery.relative_to(ROOT).as_posix(), 'review_relative_path': row['snapshot_path'], 'bytes': row['bytes'], 'sha256': row['sha256']}, 'final_path': row['original_path'], 'final_sha256': final_hash}
    if changed:
        history = PACK/'state_covariance_packaging/history/STAGED_NOTE_v1.md'
        assert sha(history) == row['sha256']
        d['parent_original_recovery'] = {'path': history.relative_to(ROOT).as_posix(), 'sha256': sha(history)}
        d['final_review_recovery'] = {'path': (OUT/final_row['snapshot_path']).relative_to(ROOT).as_posix(), 'sha256': final_hash}
    dispositions.append(d)
versions = []
for row in initial + affected:
    p = OUT/row['snapshot_path']
    assert sha(p) == row['sha256'] and p.stat().st_size == row['bytes']
    versions.append(row)
assert len(dispositions) == 196 and len(versions) == 197
assert len({r['original_path'] for r in dispositions}) == len(dispositions)
assert sum(r['original_sha256'] != r['final_sha256'] for r in dispositions) == 1
save('original_dispositions_v1.json', {'created_utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Staged correspondence only; not a committed/public delivery map.', 'source_root': str(ROOT), 'review_root_relative': OUT.relative_to(ROOT).as_posix(), 'initial_source_count': 193, 'affected_version_count': 4, 'source_version_binding_count': len(versions), 'unique_original_path_count': len(dispositions), 'original_dispositions': dispositions, 'source_version_bindings': versions})
save('COVERAGE_v1.json', {'created_utc': datetime.now(timezone.utc).isoformat(), 'complete_note_read': {'path': str(PACK/'state_covariance_packaging/staged/EXPONENTIAL_SCALAR_STATE_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-14.md'), 'sha256': sha(PACK/'state_covariance_packaging/staged/EXPONENTIAL_SCALAR_STATE_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-14.md')}, 'complete_runner_read': {'path': str(PACK/'state_covariance_packaging/staged/exponential_scalar_state_covariance_check.py'), 'sha256': sha(PACK/'state_covariance_packaging/staged/exponential_scalar_state_covariance_check.py')}, 'proof_bodies_compared': 2, 'scientific_AST_statements_compared': 107, 'all_original_result_rows_compared': 104, 'all_substantive_outputs_compared': True, 'prior_sealed_artifacts_checked': 104, 'prior_science_source_pairs_checked': 11, 'prior_reused_seal_pairs_checked': 3, 'prior_scientific_executions_reused_not_rerun': True, 'actual_parent_altered_programs_consumed_not_rerun': 3, 'own_wrapper_only_executions': 3, 'initial_review_assertions': {'passed': 495, 'failed': 0}, 'affected_only_assertions': {'passed': 406, 'failed': 0}, 'all_frozen_versions_preserved': 197, 'complete_disposition_paths': 196, 'limitations': ['No producer scientific rerun.', 'No new independent theory or empirical test.', 'No live canonical path/cache/commit or archive delivery confirmation.', 'Prior independent proof checks reused by exact source and seal identity.']})
print(json.dumps({'source_version_bindings': len(versions), 'original_dispositions': len(dispositions), 'changed_originals': 1}))
