"""Freeze and check only the two coordinated prose corrections; no science execution."""
from pathlib import Path
from datetime import datetime, timezone
import difflib
import hashlib
import json
import sys

OUT = Path(__file__).resolve().parent
PACK = OUT.parent
ROOT = PACK.parents[3]
PKREL = PACK.relative_to(ROOT)
SP = PACK / 'state_covariance_packaging'
RUN = OUT / 'affected_v2'
RUN.mkdir(exist_ok=False)
checks = []

def sha(b):
    return hashlib.sha256(b).hexdigest()

def save(name, value):
    p = RUN / name
    p.parent.mkdir(parents=True, exist_ok=True)
    if not isinstance(value, bytes):
        value = (value if isinstance(value, str) else json.dumps(value, indent=2) + '\n').encode()
    with p.open('xb') as f:
        f.write(value)
    return {'path': p.relative_to(OUT).as_posix(), 'bytes': len(value), 'sha256': sha(value)}

def ck(name, condition, detail=None):
    checks.append({'name': name, 'passed': bool(condition), 'detail': detail})

def load(path):
    return json.loads(path.read_text())

note_name = 'staged/EXPONENTIAL_SCALAR_STATE_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-14.md'
runner_name = 'staged/exponential_scalar_state_covariance_check.py'
affected = [note_name, 'CANONICAL_LINEAGE_v2.json', 'history/STAGED_NOTE_v1.md', 'STAGED_NOTE_v1_v2.diff']
bindings = []
for name in affected:
    path = SP / name
    data = path.read_bytes()
    snap = save('sources/' + name, data)
    bindings.append({'original_path': path.relative_to(ROOT).as_posix(), 'snapshot_path': snap['path'], 'bytes': len(data), 'sha256': sha(data)})
save('SOURCE_BINDINGS.json', {'created_utc': datetime.now(timezone.utc).isoformat(), 'sources': bindings})

initial = load(OUT / 'SOURCE_BINDINGS_v2.json')['sources']
old_note_row = next(r for r in initial if r['original_path'] == (SP / note_name).relative_to(ROOT).as_posix())
old_note = (OUT / old_note_row['snapshot_path']).read_bytes()
new_note = (RUN / 'sources' / note_name).read_bytes()
history = (RUN / 'sources/history/STAGED_NOTE_v1.md').read_bytes()
ck('original_note_pin', sha(old_note) == 'c47aeb6e2cdd0617bc62a0cdfb841adff5bfa33c9917cbe60b2f2090cc49a65f')
ck('final_note_pin', sha(new_note) == '5ac1796b19252dc3f04579bca00959e4c4f13a091344be989bbd50e515a629ba')
ck('parent_history_exact_original', history == old_note)
changes = [
    (b'realizes that freedom.', b'realizes the real symmetric covariance freedom.'),
    (b'Gaussian or single-mode premise', b'Gaussian or single common growing-seed premise'),
]
expected = old_note
for before, after in changes:
    ck('single_replacement:' + before.decode(), expected.count(before) == 1)
    expected = expected.replace(before, after)
ck('complete_note_only_two_corrections', expected == new_note)
diff = ''.join(difflib.unified_diff(old_note.decode().splitlines(True), new_note.decode().splitlines(True), fromfile='v1', tofile='v2'))
save('INDEPENDENT_CHANGE.diff', diff)
ck('parent_diff_exact', (RUN / 'sources/STAGED_NOTE_v1_v2.diff').read_text() == diff)

old_lineage = load(OUT / 'source_snapshot' / PKREL / 'state_covariance_packaging/CANONICAL_LINEAGE_v1.json')
lineage = load(RUN / 'sources/CANONICAL_LINEAGE_v2.json')
for key in ['note_bodies', 'scientific_sources', 'allowed_code_changes', 'runner_sha256']:
    ck('unchanged_lineage:' + key, lineage[key] == old_lineage[key])
ck('lineage_note_versions', lineage['note_sha256'] == sha(new_note) and lineage['previous_note_sha256'] == sha(old_note))
ck('lineage_two_corrections', len(lineage['wrapper_only_corrections']) == 2)
markers = ['## 1. Exact covariance feasibility and candidate right inverse\n', '## 2. Bounded homogeneous isotropic realization\n', '## Computation and empirical limits\n']
text = new_note.decode()
for i in range(2):
    body = text.split(markers[i], 1)[1].split(markers[i+1], 1)[0].strip() + '\n'
    original = (OUT / ('run01/body_%s_expected.md' % i)).read_text()
    ck('whole_proof_body_unchanged:' + str(i), body == original and sha(body.encode()) == lineage['note_bodies'][i]['body_sha256'])

live = []
for row in initial:
    original = ROOT / row['original_path']
    data = original.read_bytes()
    expected_sha = sha(new_note) if original == SP / note_name else row['sha256']
    frozen = (OUT / row['snapshot_path']).read_bytes()
    ck('original_snapshot:' + row['original_path'], sha(frozen) == row['sha256'] and len(frozen) == row['bytes'])
    ck('final_live:' + row['original_path'], sha(data) == expected_sha)
    live.append({'path': row['original_path'], 'original_sha256': row['sha256'], 'final_sha256': sha(data), 'expected_sha256': expected_sha, 'expected_change': original == SP / note_name})
for row in bindings:
    ck('affected_input_unchanged:' + row['original_path'], sha((ROOT / row['original_path']).read_bytes()) == row['sha256'])
save('LIVE_FINAL_IDENTITY.json', live)
initial_result = load(OUT / 'run01/RESULTS.json')
ck('prior_review_result_reused', initial_result['passed'] == 495 and initial_result['failed'] == 0)
result = {'created_utc': datetime.now(timezone.utc).isoformat(), 'passed': sum(r['passed'] for r in checks), 'failed': sum(not r['passed'] for r in checks), 'checks': checks, 'affected_versions_frozen': len(bindings), 'prior_source_pairs_rechecked': len(initial), 'science_executed': False, 'prior_review_results': {'path': 'run01/RESULTS.json', 'sha256': sha((OUT/'run01/RESULTS.json').read_bytes())}}
save('RESULTS.json', result)
print(json.dumps({k: v for k, v in result.items() if k != 'checks'}))
raise SystemExit(1 if result['failed'] else 0)
