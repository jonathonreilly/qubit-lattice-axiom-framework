"""Exact frozen-source correspondence; never imports or runs producer science."""
from pathlib import Path
from datetime import datetime,timezone
import ast,difflib,hashlib,json,subprocess,sys
OUT=Path(__file__).resolve().parent
PACK=OUT.parent
ROOT=PACK.parents[3]
PKREL=PACK.relative_to(ROOT)
CI='rolling_local_response/covariance_inverse_v1'
SP='state_covariance_packaging'
RUN=OUT/'run01';RUN.mkdir(exist_ok=False)
checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def ck(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
def save(name,value):
    p=RUN/name;p.parent.mkdir(parents=True,exist_ok=True)
    text=value if isinstance(value,str) else json.dumps(value,indent=2)+'\n'
    with p.open('x') as f:f.write(text)
    return {'path':p.relative_to(OUT).as_posix(),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
def snap(rel):return OUT/'source_snapshot'/rel
def src(rel):return snap(PKREL/rel)
def load(p):return json.loads(p.read_text())
bindings=load(OUT/'SOURCE_BINDINGS_v2.json')
live=[]
for r in bindings['sources']:
    b=(OUT/r['snapshot_path']).read_bytes()
    ck('frozen:'+r['original_path'],sha(b)==r['sha256'] and len(b)==r['bytes'])
    live.append({'path':r['original_path'],'frozen_sha256':r['sha256'],'current_sha256':sha((ROOT/r['original_path']).read_bytes()),'matches':(ROOT/r['original_path']).read_bytes()==b})
save('LIVE_OBSERVATION.json',live)
seals=[]
pins={CI+'/independent_v1':'4fd52eb3973d02cffc714e8806faba80a90515cde23f46c5685a40640c8f92f3',CI+'/homogeneous_ensemble_v1/independent_v1':'abeaef063931055ffaa52157a30e57a91b0af361f28f3b86d386509b0f46c08a'}
for unit,pin in pins.items():
    base=src(unit);r=load(base/'RECEIPT_v1.json');m=load(base/r['manifest']['path'])
    ck('receipt:'+unit,sha((base/'RECEIPT_v1.json').read_bytes())==pin)
    for field in ['manifest','report','hand_derivation','protocol','independent_code','execution_driver','baseline_execution','baseline_results','damage_summary','failure_ledger','command_index']:
        row=r[field];b=(base/row['path']).read_bytes();ck('receipt_field:'+unit+':'+field,sha(b)==row['sha256'] and len(b)==row['bytes'])
    actual=sorted(p.relative_to(base).as_posix() for p in base.rglob('*') if p.is_file() and p.relative_to(base).as_posix() not in m['excludes'])
    ck('closed_inventory:'+unit,actual==sorted(x['path'] for x in m['artifacts']) and len(actual)==m['artifact_count'])
    for row in m['artifacts']:
        b=(base/row['path']).read_bytes();ck('artifact:'+unit+'/'+row['path'],sha(b)==row['sha256'] and len(b)==row['bytes'])
    pairs=r['source_bindings']+r.get('reused_sealed_evidence_bindings',[])
    for row in pairs:
        b=snap(row['original_path']).read_bytes();ck('pair:'+unit+'/'+row['snapshot_path'],b==(base/row['snapshot_path']).read_bytes() and sha(b)==row['sha256'])
    seals.append({'unit':unit,'receipt_sha256':pin,'report':r['report'],'manifest':r['manifest'],'artifacts':len(m['artifacts']),'source_pairs':len(r['source_bindings']),'reused_seal_pairs':len(r.get('reused_sealed_evidence_bindings',[])),'baseline_counts':r['baseline_counts'],'damage_counts':r['damage_counts'],'reused_not_rerun':True})
save('REUSED_SEALS.json',seals)
lineage=load(src(SP+'/CANONICAL_LINEAGE_v1.json'))
notepath=SP+'/staged/EXPONENTIAL_SCALAR_STATE_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-14.md'
runnerpath=SP+'/staged/exponential_scalar_state_covariance_check.py'
note=src(notepath).read_text();runner=src(runnerpath).read_text()
ck('note_pin',sha(note.encode())==lineage['note_sha256']);ck('runner_pin',sha(runner.encode())==lineage['runner_sha256'])
markers=['## 1. Exact covariance feasibility and candidate right inverse\n','## 2. Bounded homogeneous isotropic realization\n','## Computation and empirical limits\n']
bodies=[]
for i,row in enumerate(lineage['note_bodies']):
    source=src(row['source']).read_text();ck('proof_source:'+row['source'],sha(source.encode())==row['sha256'])
    body=source.split('\n',1)[1].strip()
    for old,new in row['reference_replacements'].items():
        ck('single_reference:'+old,body.count(old)==1);body=body.replace(old,new)
    body='\n'.join('#'+x if x.startswith('#') else x for x in body.split('\n'))+'\n'
    actual=note.split(markers[i],1)[1].split(markers[i+1],1)[0].strip()+'\n'
    ck('whole_proof_body:'+row['source'],body==actual and sha(body.encode())==row['body_sha256'])
    bodies.append({'source':row['source'],'expected':save('body_%s_expected.md'%i,body),'staged':save('body_%s_staged.md'%i,actual),'equal':body==actual})
    save('body_%s.diff'%i,''.join(difflib.unified_diff(body.splitlines(True),actual.splitlines(True),fromfile='expected',tofile='staged')))
save('PROOF_CORRESPONDENCE.json',bodies)
tree=ast.parse(runner);functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
astrows=[]
for name,path in [('inverse',CI+'/check_covariance_inverse_v2.py'),('ensemble',CI+'/homogeneous_ensemble_v1/check_ensemble_v1.py')]:
    oldtree=ast.parse(src(path).read_text());oldbody=next(n for n in oldtree.body if isinstance(n,ast.FunctionDef) and n.name=='main').body if name=='inverse' else oldtree.body
    start=next(i for i,n in enumerate(oldbody) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='rows' for t in n.targets))
    oldnodes=oldbody[start:-3];newnodes=functions['check_'+name].body[:-1]
    a=ast.dump(ast.Module(body=oldnodes,type_ignores=[]),include_attributes=False,indent=2)+'\n';b=ast.dump(ast.Module(body=newnodes,type_ignores=[]),include_attributes=False,indent=2)+'\n'
    ck('whole_science_AST:'+name,a==b)
    astrows.append({'name':name,'source':path,'slice_start':start,'tail_IO_nodes_excluded':3,'statement_count':len(oldnodes),'original':save('AST_'+name+'_original.txt',a),'staged':save('AST_'+name+'_staged.txt',b),'equal':a==b,'new_return':ast.unparse(functions['check_'+name].body[-1])})
    save('AST_'+name+'.diff',''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='original',tofile='staged')))
save('AST_CORRESPONDENCE.json',astrows)
originals={'inverse':load(src(CI+'/baseline_v2/RESULTS.json')),'ensemble':load(src(CI+'/homogeneous_ensemble_v1/baseline_v1/RESULTS.json'))}
result=load(src(SP+'/STAGED_RESULTS_v1.json'));expected=[];outputs={};pairs=[]
for name,original in originals.items():
    for row in original['checks']:
        item=dict(row);item['passed']=item.pop('ok');item['name']=name+'::'+item['name'];expected.append(item)
    outputs[name]={k:v for k,v in original.items() if k not in ['checks','passed','failed']}
    ck('unit_census:'+name,result['units'][name]=={'passed':original['passed'],'failed':original['failed']})
ck('complete_rows_census',len(expected)==len(result['checks'])==104)
for i,(a,b) in enumerate(zip(expected,result['checks'])):
    ck('row:'+str(i)+':'+a['name'],a==b);pairs.append({'index':i,'name':a['name'],'original_normalized':a,'staged':b,'equal':a==b})
ck('all_rows_ordered',expected==result['checks']);ck('complete_outputs',outputs==result['substantive_outputs'])
ck('combined_census',result['passed']==104 and result['failed']==0 and all(x['passed'] for x in result['checks']))
ck('result_source_pin',result['checker_sha256']==sha(runner.encode()))
save('COMPLETE_ROW_CORRESPONDENCE.json',pairs);save('COMPLETE_OUTPUT_CORRESPONDENCE.json',{'expected':outputs,'staged':result['substantive_outputs'],'all_equal':outputs==result['substantive_outputs']})
ck('stdout_exact',src(SP+'/STAGED_stdout_v1.txt').read_bytes()==src(SP+'/STAGED_RESULTS_v1.json').read_bytes())
ck('stderr_empty',src(SP+'/STAGED_stderr_v1.txt').stat().st_size==0)
execution=load(src(SP+'/STAGED_EXECUTION_v1.json'));command=load(src(SP+'/STAGED_COMMAND_v1.json'))
ck('stage_execution',execution['exit_code']==0 and execution['argv']==command['argv'] and command['source_sha256']==sha(runner.encode()))
for path,code,proof,field in [(CI+'/RUN_v2.json',CI+'/check_covariance_inverse_v2.py',CI+'/DERIVATION_v1.md','source_sha256'),(CI+'/homogeneous_ensemble_v1/RUN_v1.json',CI+'/homogeneous_ensemble_v1/check_ensemble_v1.py',CI+'/homogeneous_ensemble_v1/DERIVATION_v1.md','derivation_sha256')]:
    r=load(src(path));ck('original_execution:'+path,r['exit_code']==0 and r['code_sha256']==sha(src(code).read_bytes()) and r[field]==sha(src(proof).read_bytes()))
protocol=load(src(SP+'/damages_v1/PROTOCOL_v1.json'));summary=load(src(SP+'/damages_v1/SUMMARY_v1.json'));damages=[]
ck('damage_protocol_source',protocol['source_sha256']==sha(runner.encode()))
for i,edit in enumerate(protocol['edits']):
    name=edit['name'];base=SP+'/damages_v1/'+name;changed=src(base+'.py').read_text();r=load(src(base+'_RESULTS.json'));ex=load(src(base+'_EXECUTION.json'))
    ck('actual_damage_source:'+name,runner.count(edit['old'])==1 and changed==runner.replace(edit['old'],edit['new'],1))
    generated=''.join(difflib.unified_diff(runner.splitlines(True),changed.splitlines(True),fromfile='canonical',tofile=name))
    # Compare patch hunk bodies, independent of human-selected header labels.
    recorded=src(base+'.diff').read_text();ck('actual_damage_diff:'+name,generated.splitlines()[2:]==recorded.splitlines()[2:])
    ck('actual_damage_identity:'+name,r['checker_sha256']==sha(changed.encode()) and ex==summary[i])
    failed=[x['name'] for x in r['checks'] if not x['passed']]
    ck('actual_damage_witness:'+name,edit['witness'] in failed and failed==ex['failed_names'] and ex['exit_code']==1)
    ck('actual_damage_counts:'+name,len(r['checks'])==104 and r['failed']==len(failed)==ex['failed'] and r['passed']==104-len(failed)==ex['passed'])
    ck('actual_damage_streams:'+name,src(base+'_stdout.txt').read_bytes()==src(base+'_RESULTS.json').read_bytes() and src(base+'_stderr.txt').stat().st_size==0)
    damages.append({'name':name,'script_sha256':sha(changed.encode()),'result_sha256':sha(src(base+'_RESULTS.json').read_bytes()),'passed':r['passed'],'failed':r['failed'],'witness':edit['witness'],'failed_names':failed,'changed_rows':[{'index':j,'original':a,'damaged':b} for j,(a,b) in enumerate(zip(result['checks'],r['checks'])) if a!=b],'reviewer_reran':False})
save('ACTUAL_DAMAGE_CORRESPONDENCE.json',damages)
main=next(n for n in tree.body if isinstance(n,ast.If) and ast.unparse(n.test)=="__name__ == '__main__'")
maintext=ast.get_source_segment(runner,main)+'\n';save('EXACT_WRAPPER.py.fragment',maintext)
wrappers=[]
for fail in [None,'inverse','ensemble']:
    tag=fail or 'none';body='from pathlib import Path\nimport json,hashlib,argparse\n'
    for name in ['inverse','ensemble']:
        stub={'checks':[{'name':'same','ok':True},{'name':'same','ok':name!=fail}],'passed':999,'failed':999,'scope':name,'table':[1,2,3]}
        body+='def check_%s():\n    return %r\n'%(name,stub)
    body+=maintext;p=RUN/('wrapper_'+tag+'.py');p.write_text(body);out=RUN/('wrapper_'+tag+'_RESULT.json')
    argv=[sys.executable,'-B',str(p),'--output',str(out)];pr=subprocess.run(argv,cwd=RUN,capture_output=True,text=True,timeout=10)
    save('wrapper_'+tag+'_stdout.txt',pr.stdout);save('wrapper_'+tag+'_stderr.txt',pr.stderr);r=load(out)
    ck('wrapper_exit:'+tag,pr.returncode==(0 if fail is None else 1))
    ck('wrapper_recomputed_counts:'+tag,r['passed']==(4 if fail is None else 3) and r['failed']==(0 if fail is None else 1))
    ck('wrapper_retains_duplicate_rows:'+tag,[x['name'] for x in r['checks']]==['inverse::same','inverse::same','ensemble::same','ensemble::same'])
    ck('wrapper_tables_identity:'+tag,r['substantive_outputs']=={n:{'scope':n,'table':[1,2,3]} for n in ['inverse','ensemble']} and r['checker_sha256']==sha(p.read_bytes()) and json.loads(pr.stdout)==r and not pr.stderr)
    wrappers.append({'case':tag,'argv':argv,'exit_code':pr.returncode,'program_sha256':sha(p.read_bytes()),'result_sha256':sha(out.read_bytes()),'science_executed':False})
save('WRAPPER_EXECUTIONS.json',wrappers)
final={'created_utc':datetime.now(timezone.utc).isoformat(),'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'checks':checks,'frozen_source_count':len(bindings['sources']),'proof_bodies':2,'scientific_AST_statements':sum(x['statement_count'] for x in astrows),'original_science_rows_compared':104,'actual_parent_damaged_runs_verified_not_rerun':3,'wrapper_only_runs':3,'prior_science_reused_not_rerun':True}
save('RESULTS.json',final);print(json.dumps({k:v for k,v in final.items() if k!='checks'}));raise SystemExit(bool(final['failed']))
