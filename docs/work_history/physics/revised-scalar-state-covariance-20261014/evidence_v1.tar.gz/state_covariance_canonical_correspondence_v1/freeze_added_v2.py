from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
OUT=Path(__file__).resolve().parent
PACK=OUT.parent
ROOT=PACK.parents[3]
old=json.loads((OUT/'SOURCE_BINDINGS_v1.json').read_text())
for row in old['sources']:
    assert hashlib.sha256((OUT/row['snapshot_path']).read_bytes()).hexdigest()==row['sha256']
files=list((PACK/'state_covariance_packaging/damages_v1').rglob('*'))
files.append(PACK/'state_covariance_packaging/PARENT_OUTPUT_CORRESPONDENCE_v1.json')
added=[]
for src in sorted(p for p in files if p.is_file()):
    assert not src.is_symlink()
    b=src.read_bytes();rel=src.relative_to(ROOT).as_posix();dst=OUT/'source_snapshot'/rel
    dst.parent.mkdir(parents=True,exist_ok=True)
    with dst.open('xb') as f:f.write(b)
    added.append({'original_path':rel,'snapshot_path':dst.relative_to(OUT).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
record={'created_utc':datetime.now(timezone.utc).isoformat(),'initial_binding':'SOURCE_BINDINGS_v1.json','initial_binding_sha256':hashlib.sha256((OUT/'SOURCE_BINDINGS_v1.json').read_bytes()).hexdigest(),'source_count':len(old['sources'])+len(added),'added_count':len(added),'sources':old['sources']+added,'scope':'Frozen original staged v1 scope plus three completed actual parent damage executions and full-output comparison.'}
with (OUT/'SOURCE_BINDINGS_v2.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({'source_count':record['source_count'],'added':len(added),'binding_sha256':hashlib.sha256((OUT/'SOURCE_BINDINGS_v2.json').read_bytes()).hexdigest()}))
