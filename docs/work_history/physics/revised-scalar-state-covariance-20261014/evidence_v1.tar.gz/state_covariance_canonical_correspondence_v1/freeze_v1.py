from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

OUT = Path(__file__).resolve().parent
PACK = OUT.parent
ROOT = PACK.parents[3]
CI = PACK / "rolling_local_response/covariance_inverse_v1"
files = {p for p in CI.rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"}
for unit in [CI / "independent_v1", CI / "homogeneous_ensemble_v1/independent_v1"]:
    receipt = json.loads((unit / "RECEIPT_v1.json").read_text())
    for row in receipt["source_bindings"] + receipt.get("reused_sealed_evidence_bindings", []):
        files.add(ROOT / row["original_path"])
for rel in ["CANONICAL_LINEAGE_v1.json", "STAGED_COMMAND_v1.json", "STAGED_EXECUTION_v1.json",
            "STAGED_RESULTS_v1.json", "STAGED_stderr_v1.txt", "STAGED_stdout_v1.txt",
            "staged/EXPONENTIAL_SCALAR_STATE_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-14.md",
            "staged/exponential_scalar_state_covariance_check.py"]:
    files.add(PACK / "state_covariance_packaging" / rel)
rows = []
for src in sorted(files):
    assert src.is_file() and not src.is_symlink()
    b = src.read_bytes()
    rel = src.relative_to(ROOT).as_posix()
    dst = OUT / "source_snapshot" / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    with dst.open("xb") as f:
        f.write(b)
    rows.append({"original_path": rel, "snapshot_path": dst.relative_to(OUT).as_posix(),
                 "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()})
record = {"created_utc": datetime.now(timezone.utc).isoformat(), "sources": rows, "source_count": len(rows),
          "scope": "Complete CI and HE source/evidence/review trees, referenced original contexts and eight initial staged packaging files.",
          "science_executed": False, "parent_sources_modified": False}
with (OUT / "SOURCE_BINDINGS_v1.json").open("x") as f:
    json.dump(record, f, indent=2)
    f.write("\n")
print(json.dumps({"source_count": len(rows), "binding_sha256": hashlib.sha256((OUT / "SOURCE_BINDINGS_v1.json").read_bytes()).hexdigest()}))
