from pathlib import Path
import json,hashlib,argparse
def check_inverse():
    return {'checks': [{'name': 'same', 'ok': True}, {'name': 'same', 'ok': True}], 'passed': 999, 'failed': 999, 'scope': 'inverse', 'table': [1, 2, 3]}
def check_ensemble():
    return {'checks': [{'name': 'same', 'ok': True}, {'name': 'same', 'ok': False}], 'passed': 999, 'failed': 999, 'scope': 'ensemble', 'table': [1, 2, 3]}
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--output');args=a.parse_args()
    checks=[];units={};outputs={}
    for name,fn in [('inverse',check_inverse),('ensemble',check_ensemble)]:
        r=fn();rows=[]
        for old in r['checks']:
            row=dict(old);row['passed']=row.pop('ok');row['name']=name+'::'+row['name'];rows.append(row)
        checks.extend(rows);units[name]={'passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows)}
        outputs[name]={k:v for k,v in r.items() if k not in ['checks','passed','failed']}
    result={'passed':sum(x['passed'] for x in checks),'failed':sum(not x['passed'] for x in checks),'checks':checks,'units':units,'substantive_outputs':outputs,'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Conditional initial-covariance feasibility and bounded homogeneous isotropic witness; no observed fit or selected state.'}
    if args.output:
        out=Path(args.output);assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2));raise SystemExit(bool(result['failed']))
