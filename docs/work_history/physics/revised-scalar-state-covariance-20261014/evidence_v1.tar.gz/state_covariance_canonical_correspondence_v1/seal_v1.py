"""Close this staged review's inventory once, without editing any checked source."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

OUT = Path(__file__).resolve().parent
PACK = OUT.parent
ROOT = PACK.parents[3]
EXCLUDES = ['MANIFEST_v1.json', 'RECEIPT_v1.json']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

def record(path):
    return {'path': path.relative_to(OUT).as_posix(), 'bytes': path.stat().st_size, 'sha256': sha(path)}

def save(name, value):
    with (OUT/name).open('x') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

assert not any((OUT/n).exists() for n in EXCLUDES)
mapping = load(OUT/'original_dispositions_v1.json')
for row in mapping['original_dispositions']:
    assert sha(ROOT/row['final_path']) == row['final_sha256']
    recovery = ROOT/row['recovery']['path']
    assert sha(recovery) == row['original_sha256'] == row['recovery']['sha256']
    assert recovery.stat().st_size == row['recovery']['bytes']
    if 'parent_original_recovery' in row:
        assert sha(ROOT/row['parent_original_recovery']['path']) == row['original_sha256']
        assert sha(ROOT/row['final_review_recovery']['path']) == row['final_sha256']
for row in mapping['source_version_bindings']:
    recovery = OUT/row['snapshot_path']
    assert sha(recovery) == row['sha256'] and recovery.stat().st_size == row['bytes']
for name, count in [('run01/RESULTS.json', 495), ('affected_v2/RESULTS.json', 406)]:
    r = load(OUT/name)
    assert r['passed'] == count and r['failed'] == 0
    assert len(r['checks']) == count and all(c['passed'] for c in r['checks'])
report = (OUT/'REPORT_v1.md').read_text()
seals = load(OUT/'run01/REUSED_SEALS.json')
assert all(r['receipt_sha256'] in report for r in seals)
assert 'abeaef063931055ffaa52157a30e57a31b0af361f28f3b86d386509b0f46c08a' not in report
assert sha(OUT/'REPORT_v1.md') == '9e2cd8d162426f783ba6bcb0b8c8186bb33c3952e22bd63ad8faa25b278abf4f'
artifacts = []
for path in sorted(OUT.rglob('*')):
    assert not path.is_symlink(), str(path)
    if path.is_file() and path.relative_to(OUT).as_posix() not in EXCLUDES:
        artifacts.append(record(path))
manifest = {'created_utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Focused staged correspondence; no science rerun, delivery confirmation, formal audit or authority mutation.', 'excludes': EXCLUDES, 'artifact_count': len(artifacts), 'artifacts': artifacts}
save('MANIFEST_v1.json', manifest)
receipt = {'created_utc': datetime.now(timezone.utc).isoformat(), 'status': 'Focused staged correspondence complete; two new wrapper wording findings resolved in separately preserved v2 note.', 'scientific_author': '/root', 'reviewer': '/root/direct_field_check', 'review_root_relative': OUT.relative_to(ROOT).as_posix(), 'source_root': str(ROOT), 'manifest': record(OUT/'MANIFEST_v1.json'), 'report': record(OUT/'REPORT_v1.md'), 'methods': record(OUT/'METHODS_v1.md'), 'findings_and_failures': record(OUT/'FINDINGS_AND_FAILURES_v1.md'), 'source_dispositions': record(OUT/'original_dispositions_v1.json'), 'coverage': record(OUT/'COVERAGE_v1.json'), 'command_index': record(OUT/'COMMAND_INDEX_v1.json'), 'initial_results': record(OUT/'run01/RESULTS.json'), 'affected_results': record(OUT/'affected_v2/RESULTS.json'), 'preseal_draft_correction': record(OUT/'draft_history/CORRECTION.json'), 'artifact_count': len(artifacts), 'original_path_count': len(mapping['original_dispositions']), 'source_version_binding_count': len(mapping['source_version_bindings']), 'correspondence_counts': {'initial': {'passed': 495, 'failed': 0}, 'affected_final_note': {'passed': 406, 'failed': 0}}, 'reused_seals': seals, 'new_actual_parent_damages_consumed_not_rerun': record(OUT/'run01/ACTUAL_DAMAGE_CORRESPONDENCE.json'), 'reviewer_wrapper_only_executions': record(OUT/'run01/WRAPPER_EXECUTIONS.json'), 'final_note_sha256': '5ac1796b19252dc3f04579bca00959e4c4f13a091344be989bbd50e515a629ba', 'runner_sha256': '4130039628b51f00abc98d42b77cf1aa7e1512d04a839a34b9fc10eea75e8f1a', 'limitations': ['Staged paths only; canonical public delivery and live cache not checked.', 'Prior science reused by exact identity, not freshly executed.', 'No empirical acceptance, formal audit verdict or claim-status mutation.', 'No unexpected reviewer process/assertion failures; a pre-seal report draft hash typo was corrected with original draft and diff preserved.']}
save('RECEIPT_v1.json', receipt)
for row in artifacts:
    assert record(OUT/row['path']) == row
print(json.dumps({'artifact_count': len(artifacts), 'report': record(OUT/'REPORT_v1.md'), 'manifest': record(OUT/'MANIFEST_v1.json'), 'receipt': record(OUT/'RECEIPT_v1.json'), 'dispositions': record(OUT/'original_dispositions_v1.json')}, indent=2))
