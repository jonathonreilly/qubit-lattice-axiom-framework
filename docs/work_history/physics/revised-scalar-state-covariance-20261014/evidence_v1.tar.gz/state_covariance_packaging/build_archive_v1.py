from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,datetime
wt=Path.cwd();pk=wt/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013';pack=pk/'state_covariance_packaging';dest=wt/'docs/work_history/physics/revised-scalar-state-covariance-20261014'
roots=['rolling_local_response/covariance_inverse_v1','state_covariance_canonical_correspondence_v1','state_covariance_packaging']
seal_units=['rolling_local_response/covariance_inverse_v1/independent_v1','rolling_local_response/covariance_inverse_v1/homogeneous_ensemble_v1/independent_v1','state_covariance_canonical_correspondence_v1']
assert (pack/'CACHE_RUN_v1.json').is_file(), 'fresh live cache must precede archive'
for rel in seal_units:
 for name in ['REPORT_v1.md','RECEIPT_v1.json']:assert (pk/rel/name).is_file(),(rel,name)
assert not dest.exists();dest.mkdir(parents=True)
items=[]
for root in roots:
 for f in sorted((pk/root).rglob('*')):
  if f.is_dir():continue
  assert f.is_file() and not f.is_symlink(),f
  if '__pycache__' in f.parts or f.suffix=='.pyc' or f.name=='ARCHIVE_BUILD_v1.json':continue
  items.append((f.relative_to(pk).as_posix(),f.read_bytes()))
assert len(set(n for n,b in items))==len(items)
rows=[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in items]
manifest={'schema':'campaign-recovery-manifest-v1','source_roots':roots,'artifact_count':len(rows),'payloads':rows,'scope':'Conditional covariance support/right inverse and bounded real homogeneous ensemble with full source histories and independent checks. No selected action/state/scale or measured likelihood.','exclusions':['Python bytecode/cache and later archive-own-hash build record.'],'counts_are_not_new_science':True};mb=(json.dumps(manifest,indent=2)+'\n').encode();archive=dest/'evidence_v1.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for n,b in items+[('RECOVERY_MANIFEST_v1.json',mb)]:
    assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
    t=tarfile.TarInfo(n);t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)+1
 for row in rows:
  t=tar.getmember(row['path']);assert t.isfile();b=tar.extractfile(t).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
sha=hashlib.sha256(archive.read_bytes()).hexdigest();msha=hashlib.sha256(mb).hexdigest();record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive.relative_to(wt)),'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'payloads':len(rows),'total_members':len(members),'manifest_sha256':msha,'all_payloads_verified':True};(pack/'ARCHIVE_BUILD_v1.json').write_text(json.dumps(record,indent=2)+'\n')
refs=[]
for rel in seal_units:
 for name in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json']:
  if not (pk/rel/name).exists():continue
  refs.append(rel+'/'+name+' SHA256 '+hashlib.sha256((pk/rel/name).read_bytes()).hexdigest())
readme="""Recovery evidence for revised scalar state-covariance limits

Live claim: docs/EXPONENTIAL_SCALAR_STATE_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-14.md
Scientific author: /root. Conditional support; no formal audit or main merge.
Archive SHA256: {sha}
Archive bytes: {size}
Payloads: {count} plus RECOVERY_MANIFEST_v1.json
Internal manifest SHA256: {msha}

For a specified finite linear transfer T, an arbitrary centered signal covariance
S is realizable by some positive initial covariance iff S is positive and its
range lies in range(T). The explicit candidate transfer has a right inverse at
an admissible origin event with positive dust/radiation and fixed finite momentum.
This demonstrates nonidentification from unrestricted one-epoch covariances;
it does not fit measured amplitudes, a survey estimator, or a complete history.
The background immediately evolves, and weak-field control is not uniform as
radiation vanishes or momentum goes to zero/infinity.

The separately constructed bounded real homogeneous/isotropic/parity ensemble
realizes real symmetric covariance freedom on a monochromatic momentum shell.
It does not select a state, prove ergodicity, provide an observed broadband
spectrum, or solve nonlinear constraints. A single common growing-seed premise
would be additional input. Cross-time support can constrain a common state only
when the actual stacked transfer has left-null relations and measurements
provide the necessary cross-time covariance.

Fresh canonical104/0: covariance70 and ensemble34, exactly matching complete
original rows/tables. Actual altered staged programs fail4,5,9 controls.
Independent original checks98/0 and109/0, with4 and3 damaged programs, are reused
by exact identity. Staged495/0 and affected406/0 are correspondence controls,
not additional science or observational data.

The original producer missing SymPy Zero attribute failure and repair remain.
The initial staged wrapper conflated general complex covariance with the real
ensemble and used an ambiguous single-mode phrase; original note, exact two
wording replacements, final note and original-reviewer confirmation are retained.
No mathematical body, result or runner changed with those wording corrections.

The original kinetic and observable hand-source snapshots are retained within
rolling_local_response/covariance_inverse_v1/independent_v1/sources/. They supply
context for the covariance statement; this milestone is not a canonicalization
or new review of every kinetic/observational computation in the campaign.
All synthetic cases are exposed development data. No initial probability law,
physical state, unique action/scale or empirical acceptance is derived.

Extract safe regular relative members and verify each manifest size/hash.
Archive-build/commit, delivery and UNIT records follow this archive.
Independent source and staged-correspondence identities:
{refs}
""".format(sha=sha,size=archive.stat().st_size,count=len(rows),msha=msha,refs='\n'.join(refs))
(dest/'README.txt').write_text(readme);print(json.dumps(record))
