# Thermal canonical correspondence review

Reviewer: `/root/direct_field_check`. Scientific author: `/root`.

The frozen canonical note and runner preserve the three source proofs and four calculation bodies. I found no mathematical or data-loss discrepancy introduced by this port. All saved check objects and substantive tables are retained. This is a focused correspondence and linkage check, not a formal audit, claim grade, publication decision, or new construction of a cosmological history.

The new reviewer execution completed **1,161 passed, 0 failed**. Of these, **60 are new exact-rational linkage controls**; the remaining 1,101 check source identity, text/AST correspondence, saved outputs, prior seals, or recorded damaged executions. The author's **278/0** is reused execution evidence, not a second scientific run by this reviewer. Neither producer code nor earlier independent science checkers were imported or executed.

## Frozen scope and complete correspondence

The source inventory contains 425 distinct originals: the initial 326-file capture and 99 additional files captured when the final calibration seal became available. Existing partial snapshots were verified rather than overwritten. `INPUT_FREEZE_v1.json` and `CALIBRATION_CAPTURE_v1.json` bind each original and exact recovery copy. `original_dispositions_v1.json` gives the original path/hash, recovery location, disposition, and final path/hash for every constituent. All 425 live originals still matched their snapshots at the correspondence execution; sealing checks these identities again.

The final source identities are:

| Source | SHA-256 |
| --- | --- |
| Canonical thermal note | `e3ea8ccbfb4137e6640abe704f458a658e4148dfee4715727f8c4b385840845c` |
| Canonical runner | `39fd1c93bef6a1399dcfb914c9faad68168b7c03f89cad4c1a9d2447a978a4b9` |
| Actual canonical cache | `5d81d91d01bb14846c6cf7c503997a23c28ff1f910a3bc04dcad1bf62dbd94f9` |
| Thermal trace DERIVATION_v2 | `f4286e2ff5caa5d464e93a82d0abfe6b3adbb9ec8a4870ffbd7851c3955ffbde` |
| Finite-mass DERIVATION_v2 | `356b3cdbc71d862223da2e6197f09eab816807afcf40bd17a3ec3335e8da6e23` |
| Measured-calibration ADDENDUM_v2 | `f244ce056e951622f6c0149e78d791b78352c77d0d2f207e6535f3a0c1041920` |

I read the complete canonical note and runner, all four original checkers including their I/O wrappers, the original execution and repair records, and all three final independent reports and hand derivations. The three complete source proof bodies equal their canonical counterparts after only dropping the original first heading and nesting internal headings. The four complete calculation bodies, including comments, equal the isolated canonical function bodies after indentation removal and exclusion of the new final return. Their AST statement trees also agree. The lineage's body hashes use exterior whitespace stripping; this convention was identified and recorded rather than guessed.

The new main wrapper preserves each function's checks, prefixes names by the unit, counts the actual Boolean values, retains other result fields under `substantive_outputs`, records the executing source hash, and exits nonzero on failure. Its optional output path refuses overwriting. Its declared input paths and 120-second bound agree with the cache header. The note's proposed metadata does not constitute a formal grade promotion; its actual text limits the result to conditional support under stated assumptions.

The subsequent active `joint_entropy_bounce_v1` route is absent from the fixed inventory and has not been read or included. The current seal is specifically the three-part, four-function version. No archive, commit, landing, or future Part IV is certified by this receipt.

## Saved results and failure provenance

The canonical cache contains **27 trace-bridge + 8 general-trace + 229 finite-mass + 14 calibration = 278** passing checks. General-trace 8/0 is a distinct later calculation, not a relabeling of the original 27/0. Each of the 278 saved source check objects equals the canonical counterpart after only the name prefix, including residuals and pass fields.

Every substantive result is retained, with JSON types and binary64 values compared exactly using `float.hex` where applicable: all 61 finite-mass grid records and their four error estimates, all seven alternate quadrature records and derivatives/errors, both analytic endpoint values, all three synthetic calibration examples, the ideal total-bath and photon factors, the illustrative growth budget, and both bounce/calibration constants. No substantive table was dropped into a summary count. In particular, the recorded total-bath factor is about 1.4010196653, the distinct photon factor about 3.8528040797, the bare coefficient about 1.0706487833, and the calibrated coarse coefficient about 0.8029865874. These are conditional/synthetic quantities, not observations.

The cache input fingerprint was reconstructed independently from the three length-prefixed declared paths and exact bytes, yielding `f42675583ca1cab9693f104bd4f0f19186755d1462d344476991ee1cfb13bcae`. The cached runner hash and stdout's own source hash agree. The actual JSON stdout is 64,852 characters, below the utility's 200,000-character retention limit, and parses completely. The header records exit 0 and elapsed 0.62 seconds. The formatted stderr block is one framing newline; it is not asserted to be a recovered original in-memory object.

There are two distinct preserved author wrapper failures. The canonical API executed successfully and wrote the cache, after which outer JSON serialization of its `(result, Path)` return raised `TypeError` for `PosixPath`. `CACHE_RUN_RECOVERED_v1.json` reproduces the actual cache header and formatted streams exactly. It is explicitly evidence reconstructed from the cache, not an original API return. Separately, the general-trace outer wrapper encountered `NameError` for `json` before the scientific command ran. The repaired execution record and 8/0 result remain distinct from that pre-science failure.

The original trace, finite-mass and calibration executions were bound to their then-current v1 note bytes. Subsequent v2 prose qualifications did not rewrite those old run records. The final canonical execution binds the complete corrected canonical input note. All historical sources, deltas and failed executions remain in the recovery inventory.

I inspected the exact changed-source diffs for all 11 producer damages and checked their source/result/run hashes, exit 1, failed names and counts: four trace damages, four finite-mass damages, and three calibration damages. Their failures are mathematical controls rather than hash mismatches. These executions are reused, not replayed. The recorded damage counts remain 26/1, 25/2, 26/1, 26/1; 227/2, 225/4, 225/4, 82/147; and 6/8, 7/7, 11/3 respectively.

## Independent linkage and scope

`METHOD_AND_SCOPE_v1.md` preceded the new executable controls. `check_correspondence_v1.py` uses the standard library and exact rational arithmetic; it imports no producer module. Thirty-two controls differentiate the physical component equation at rational expanding and contracting states, separately recovering the Einstein exchange term, equal conformal charge, time conversion and physical trace/source equation. From

    rho_E = A^4 rho_J,  dt_J = A dt_E,  H_J = (H_E+L)/A,
    rho_J' = Q_J - 3 H_J (rho_J+p_J),

the calculation gives

    dot(rho_E)+3H_E(rho_E+p_E)
      = L(rho_E-3p_E)+A^5 Q_J,
    D_J' = a_J^4 [H_J(rho_J-3p_J)+Q_J].

Thus trace-free isolation is sufficient for conserved D; universal coupling alone does not produce separately conserved photons in an interacting bath. Positive massive trace can change total-bath D without microscopic photon-production dynamics being specified. Neither the canonical port nor these sampled controls derives thermal equilibrium or a reaction rate.

Twenty-four further controls construct strict Einstein-bounce data by choosing positive density, Hdot, Q and nonnegative kinetic/remaining enthalpy, then defining curvature by the acceleration equation. They recover the strict same-bath cap f_b<2/[3(1+w_b)] and verify the calibrated endpoint bound and the strict Ccrit threshold. Cubing positive expressions permits exact arithmetic with R^3=11/4 and avoids floating-point decisions about fractional powers. At C=Ccrit the target ratio is exactly 8/(27 f_b^3)>1; equality cannot satisfy the weak product target.

Four remaining controls check the exact bare cube 27/22>1, the calibrated cube 729/1408<1, the photon-fraction cancellation, and a countertuple to inferring a measured obstruction from a bare obstruction. These 60 finite rational controls test normalization/linkage. They do not replace the continuous thermodynamic proof or exhibit a full bounce history.

The complete source proof retains the distinction between a trace-free bounce cap f_b<1/2 in the first part and the finite-mass cap f_b<2/[3(1+w_b)]<=2/3 in the second. The potential-independent strict Einstein-bounce bound is pointwise; Jordan-only bounces and later smaller Einstein radii are not covered by the N>=0 corollary. A regular final Z is required for the separate curvature/expansion diagnostics. The same total bath must appear in both the bounce fraction and charge ratio. The larger photon charge factor cannot be inserted while retaining the total-bath initial fraction.

For fixed physical mass, ideal photon/pair content and zero chemical potential, positive heat capacity and the thermodynamic identity give monotone G=rho/s^(4/3) and the uniform endpoint ratio. Equilibrium at endpoints with supplied entropy ratio is distinct from reversible isolation throughout; assigning entropy production is not a microscopic production mechanism. The coefficient obtained by separately weakening bounce and thermodynamic bounds need not be jointly sharp. A calibrated coefficient below one is not evidence of an escaping physical solution.

Measured normalization divides the bare diagnostic by positive gamma=G_cal/G_bare. This gamma is not PPN gamma. The same-background cap requires its locally frozen weak principal regime, or the separately conditional positive-metric/nonnegative-mass Yukawa model, plus an independently supplied eta. Distinct-background calibration uses the separate principal ceiling and common action/physical units; it does not construct an environment or a connecting history. The target product is necessary, not sufficient, for its two component inequalities. The positive target domain remains explicit.

The corrected boundary statement is important: Ccrit=1 still forces C_c<1 and scalar energy strictly above 3/2, but gives no uniform positive excess. Ccrit>1 alone gives no negative-u energy floor. An energy lower bound is a necessary cost, not a contradiction without an independent upper bound.

No observational array, fitted abundance, likelihood, measured gravitational normalization, selected temperature scale, interaction law, initial state or completed background trajectory is introduced by the runner. The action, matter content/distributions, equilibrium and endpoint premises are supplied. There is no new empirical acceptance, arbitrary-body screening theorem or all-history result. Prior primary-source access belongs to the cited independent review records; I did not perform a fresh literature read or claim a new full-PDF inspection in this correspondence task. Figure files are preserved by identity; I did not rerender them or add a new visual-QA claim.

## Reused independent checks and complete failure accounting

All three final reports and hand derivations were read. Their complete local manifests, exact inventories, final receipts, and 20 original/snapshot source pairs were verified: thermal 98 artifacts plus two seals; finite-mass 92 plus two; calibration 91 plus two. The three receipt hashes are respectively `33dfdc4ad29db76706947f79c64630e20329d24a94070d68c55f899baa3accde`, `af527b7be8f1c0e00d30b4118e24b6436332e3e08de03d7ad5e7ffded6b82098`, and `8023b970ac692735fc88ac2a1048239c9b96d53a44821668f5fdb9ca5d5e8b40`. Earlier gravity mathematics inside the calibration dependency is reused through its pinned report/receipt and the calibration review's recorded verification; I do not claim to have rerun or newly inspected its entire older 85-file tree here.

The thermal reviewer preserves its original 63/2 run and the 65/0 exact-rational repair, plus 9/0 affected correspondence and nine actual damaged copies. The finite-mass reviewer preserves its original 177/0 run containing four vacuous guard rows, the corrected 180/0 control set, seven actual damages, the 56/0 source qualification check, and its wrong-working-directory tool failure. The calibration reviewer records 56/0 baseline, 24/0 mixed correspondence/definition checks, 1/0 supplemental semantic witness, and eight actual damaged implementations; the extra failing semantic witness reuses one of those eight and is not a ninth mutation. These numbers are not added to the new review's science count or treated as interchangeable reruns.

This reviewer had two genuine lookup failures before the successful correspondence run: an incorrect cache-utility path interrupted initial capture after 318 snapshots, and a read loop guessed a nonexistent top-level damage-plan filename. Their exact records remain `CAPTURE_FAILURE_v1.json` and `READ_FAILURE_v1.json`. The repaired capture verified the partial copies and completed 326 originals; later calibration capture added 99. Neither failure executed science or changed parent source. No baseline or mathematical failure occurred in the new 1,161-check execution.

A third reviewer failure occurred after that successful run while preparing metadata: `prepare_metadata_v1.py` guessed `HAND_DERIVATION_v1.md` where the finite-mass review uses `HAND_PROOF_v1.md`. Its completed constituent mapping and initial failure ledger remain unchanged; its executed code and actual FileNotFoundError are preserved in `METADATA_PREPARATION_FAILURE_v1.json`. The separately versioned v2 script completed only the missing coverage/index and an updated failure ledger. It did not rerun successful science or recreate the constituent map. The unsealed report draft before this late failure was copied exactly to `REPORT_PRE_METADATA_FAILURE_v1.md`; the final report adds this chronology before sealing. No sealed artifact was modified.

`FAILURE_LEDGER_v2.json` preserves and references v1, and the command index and copied earlier failure ledgers preserve these distinctions. Only this designated review directory was written. Parent source, prior seals, Git, runtime, locks, PRs, models and audit state were unchanged. Final filenames are `REPORT_v1.md`, `MANIFEST_v1.json`, and `RECEIPT_v1.json`; the manifest excludes only itself and the receipt. No file in this unit is to be changed after that seal. Later affected work must use a new versioned directory or addendum.
