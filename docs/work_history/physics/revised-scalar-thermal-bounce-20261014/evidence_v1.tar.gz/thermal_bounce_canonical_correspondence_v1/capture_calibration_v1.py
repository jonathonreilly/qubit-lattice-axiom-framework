"""Capture final calibration seal and any original dependency not already copied."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
PK=ROOT/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013'
HERE=Path(__file__).resolve().parent
TT=PK/'thermal_trace_bridge_v1'
CAL=TT/'finite_mass_bounce_bound_v1/calibration_independent_v1'
expected={'REPORT_v1.md':'01642b7b6020617770165743c8293261472ca348e2df9fc9edf63322337248c6','MANIFEST_v1.json':'e3d7bd72381b49e5cab8ed9909a7f0608ce9876501c1fd331ff72790722b7a32','RECEIPT_v1.json':'8023b970ac692735fc88ac2a1048239c9b96d53a44821668f5fdb9ca5d5e8b40'}
for name,value in expected.items():
    assert hashlib.sha256((CAL/name).read_bytes()).hexdigest()==value
paths=[p for p in sorted(CAL.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']
for unit in [TT/'independent_v1',TT/'finite_mass_bounce_bound_v1/independent_v1',CAL]:
    receipt=json.loads((unit/'RECEIPT_v1.json').read_bytes())
    for row in receipt.get('source_bindings',receipt.get('source_pairs',[])):
        original=Path(row['original_path'])
        original=original if original.is_absolute() else ROOT/original
        original.relative_to(ROOT)
        assert hashlib.sha256(original.read_bytes()).hexdigest()==row['sha256']
        paths.append(original)
new=[]
existing=[]
for p in sorted(set(paths)):
    assert not p.is_symlink()
    body=p.read_bytes();target=HERE/'source_snapshot'/p.relative_to(ROOT)
    record={'original_path':str(p),'snapshot':str(target),'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}
    if target.exists():
        assert target.read_bytes()==body
        existing.append(record)
    else:
        target.parent.mkdir(parents=True,exist_ok=True)
        with target.open('xb') as f:f.write(body)
        new.append(record)
    assert p.read_bytes()==body
result={'created_utc':datetime.now(timezone.utc).isoformat(),'scope':'Final calibration review and its original dependencies, including original dependency bytes already recovered inside the earlier two review trees. No scientific rerun.','inputs':new,'count':len(new),'existing_inputs_verified':existing,'final_calibration_pins':expected,'capture_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with (HERE/'CALIBRATION_CAPTURE_v1.json').open('x') as f:f.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({'new_files':len(new),'existing_verified':len(existing),'capture_sha256':hashlib.sha256((HERE/'CALIBRATION_CAPTURE_v1.json').read_bytes()).hexdigest()},indent=2))
