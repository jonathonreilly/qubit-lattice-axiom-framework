"""Complete initial capture after a preserved wrong-path lookup; never overwrite."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
PK=ROOT/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013'
HERE=Path(__file__).resolve().parent
paths=[]
for folder in [PK/'thermal_trace_bridge_v1',PK/'thermal_bounce_packaging']:
    for p in sorted(folder.rglob('*')):
        if p.is_file() and 'calibration_independent_v1' not in p.parts and '__pycache__' not in p.parts and p.suffix!='.pyc':
            paths.append(p)
for name in ['docs/EXPONENTIAL_SCALAR_THERMAL_BOUNCE_BOUNDED_THEOREM_NOTE_2026-10-14.md','docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md','docs/EXPONENTIAL_SCALAR_PHYSICAL_PAST_BOUNDED_THEOREM_NOTE_2026-10-14.md','scripts/exponential_scalar_thermal_bounce_check.py','logs/runner-cache/exponential_scalar_thermal_bounce_check.txt','scripts/runner_cache.py']:
    paths.append(ROOT/name)
rows=[]
preexisting=0
for p in sorted(set(paths)):
    assert not p.is_symlink()
    data=p.read_bytes()
    out=HERE/'source_snapshot'/p.relative_to(ROOT)
    if out.exists():
        assert out.is_file() and not out.is_symlink() and out.read_bytes()==data
        preexisting+=1
    else:
        out.parent.mkdir(parents=True,exist_ok=True)
        with out.open('xb') as f:
            f.write(data)
    assert p.read_bytes()==data
    rows.append({'original_path':str(p),'snapshot':str(out),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
record={'created_utc':datetime.now(timezone.utc).isoformat(),'scope':'Initial frozen canonical note/runner/cache, declared inputs, complete producer source/evidence and two final independent-review units. Final calibration review intentionally deferred until its seal is supplied.','inputs':rows,'count':len(rows),'total_bytes':sum(r['bytes'] for r in rows),'preexisting_partial_snapshots_checked_unchanged':preexisting,'excluded':['calibration_independent_v1 pending final seal','Python bytecode and cache files'],'producer_execution':False,'capture_failure':'CAPTURE_FAILURE_v1.json','capture_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with (HERE/'INPUT_FREEZE_v1.json').open('x') as f:
    f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps({'count':len(rows),'bytes':record['total_bytes'],'preexisting_preserved':preexisting,'freeze_sha256':hashlib.sha256((HERE/'INPUT_FREEZE_v1.json').read_bytes()).hexdigest()},indent=2))
