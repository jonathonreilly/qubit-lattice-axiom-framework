#!/usr/bin/env python3
"""Independent stdlib correspondence and rational linkage checks; no producer imports."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime, timezone
import ast
import difflib
import hashlib
import json
import re
import sys
import textwrap

HERE = Path(__file__).resolve().parent
SNAP = HERE / 'source_snapshot'
PACK_REL = Path('.claude/science/physics-loops/revised-scalar-derivation-24h-20261013')
PACK = SNAP / PACK_REL
TT = PACK / 'thermal_trace_bridge_v1'
FM = TT / 'finite_mass_bounce_bound_v1'
NOTE = Path('docs/EXPONENTIAL_SCALAR_THERMAL_BOUNCE_BOUNDED_THEOREM_NOTE_2026-10-14.md')
RUNNER = Path('scripts/exponential_scalar_thermal_bounce_check.py')
CACHE = Path('logs/runner-cache/exponential_scalar_thermal_bounce_check.txt')
rows = []
details = {}

def sha(b):
    return hashlib.sha256(b).hexdigest()

def readj(p):
    return json.loads(p.read_text())

def check(name, test, evidence=None, category='correspondence'):
    row = {'name': name, 'passed': bool(test), 'category': category}
    if evidence is not None:
        row['evidence'] = evidence
    rows.append(row)

def typed(value):
    """Retain JSON types and binary64 values, including signed zero."""
    if isinstance(value, dict):
        return ('dict', tuple((k, typed(v)) for k, v in sorted(value.items())))
    if isinstance(value, list):
        return ('list', tuple(map(typed, value)))
    return (type(value).__name__, value.hex() if type(value) is float else value)

def identity(p, rec):
    b = p.read_bytes()
    return len(b) == rec['bytes'] and sha(b) == rec['sha256']

def main():
    freezes = [readj(HERE / x) for x in ('INPUT_FREEZE_v1.json', 'CALIBRATION_CAPTURE_v1.json')]
    inputs = [rec for freeze in freezes for rec in freeze['inputs']]
    originals = {rec['original_path']: rec for rec in inputs}
    check('unique_original_inventory', len(originals) == len(inputs) == 425, len(inputs), 'identity')
    check('subsequent_joint_route_excluded', not any('joint_entropy_bounce_v1' in s for s in originals), category='identity')
    for i, rec in enumerate(inputs):
        check(f'input_snapshot_and_live_{i}', identity(Path(rec['snapshot']), rec) and identity(Path(rec['original_path']), rec), rec['original_path'], 'identity')
    lineage = readj(PACK / 'thermal_bounce_packaging/CANONICAL_LINEAGE_v1.json')
    note = (SNAP / NOTE).read_text()
    code = (SNAP / RUNNER).read_text()
    check('canonical_note_lineage_hash', sha((SNAP / NOTE).read_bytes()) == lineage['canonical_note_sha256'])
    check('canonical_runner_lineage_hash', sha((SNAP / RUNNER).read_bytes()) == lineage['canonical_runner_sha256'])
    for i, rec in enumerate(lineage['proof_sources']):
        source = (SNAP / rec['path']).read_text()
        check(f'proof_source_hash_{i}', sha(source.encode()) == rec['sha256'])
        body = '\n'.join(source.splitlines()[1:]).strip()
        body = re.sub(r'(?m)^(#+) ', r'#\1 ', body)
        marker = '## ' + rec['title'] + '\n'
        end = ('## ' + lineage['proof_sources'][i + 1]['title'] + '\n') if i < 2 else '## Computational scope and assumption accounting\n'
        actual = note.split(marker, 1)[1].split(end, 1)[0].strip()
        check(f'complete_proof_body_{i}', actual == body, {'source_chars': len(body), 'canonical_chars': len(actual)})
    tree = ast.parse(code)
    functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
    lines = code.splitlines(keepends=True)
    body_pins = []
    for rec in lineage['runner_bodies']:
        source = (SNAP / rec['source']).read_text()
        check(rec['name'] + '_source_hash', sha(source.encode()) == rec['source_sha256'])
        start = rec['extraction_start'].replace('\\n', '\n')
        begin = source.index(start)
        body = source[begin:source.index(rec['extraction_stop'], begin)]
        variants = {'raw': body, 'strip': body.strip(), 'strip_plus_LF': body.strip() + '\n'}
        matches = [name for name, val in variants.items() if sha(val.encode()) == rec['body_sha256']]
        check(rec['name'] + '_body_hash_convention', bool(matches), matches)
        fn = functions['check_' + rec['name']]
        check(rec['name'] + '_one_final_wrapper_return', isinstance(fn.body[-1], ast.Return))
        fn_body = textwrap.dedent(''.join(lines[fn.lineno:fn.body[-1].lineno - 1])).strip()
        check(rec['name'] + '_complete_body_text', fn_body == body.strip())
        source_ast = ast.parse(body.strip()).body
        check(rec['name'] + '_complete_body_AST', ast.dump(ast.Module(body=source_ast, type_ignores=[])) == ast.dump(ast.Module(body=fn.body[:-1], type_ignores=[])))
        body_pins.append({'name': rec['name'], 'source_sha256': rec['source_sha256'], 'normalized_body_sha256': sha(body.strip().encode()), 'declared_hash_matches': matches})
    details['code_bodies'] = body_pins
    decl = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in ('AUDIT_TIMEOUT_SEC', 'AUDIT_INPUT_PATHS'):
                    decl[target.id] = ast.literal_eval(node.value)
    check('declared_timeout', decl['AUDIT_TIMEOUT_SEC'] == 120)
    check('declared_inputs_exact', decl['AUDIT_INPUT_PATHS'] == [str(NOTE), 'docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md', 'docs/EXPONENTIAL_SCALAR_PHYSICAL_PAST_BOUNDED_THEOREM_NOTE_2026-10-14.md'])
    h = hashlib.sha256(b'runner-cache-input-fingerprint-v1\0')
    for rel in decl['AUDIT_INPUT_PATHS']:
        name = rel.encode(); body = (SNAP / rel).read_bytes()
        h.update(len(name).to_bytes(8, 'big')); h.update(name)
        h.update(len(body).to_bytes(8, 'big')); h.update(body)
    cache_bytes = (SNAP / CACHE).read_bytes(); cache = cache_bytes.decode()
    header, streams = cache.split('----- stdout -----\n', 1)
    stdout, stderr = streams.split('----- stderr -----\n', 1)
    recovery = readj(PACK / 'thermal_bounce_packaging/CACHE_RUN_RECOVERED_v1.json')
    check('actual_cache_recovery_hash', sha(cache_bytes) == recovery['cache_sha256'])
    check('actual_cache_recovery_streams', (header, stdout, stderr) == (recovery['header'], recovery['stdout'], recovery['stderr']))
    hdr = dict(line.split(': ', 1) for line in header.splitlines() if ': ' in line)
    check('cache_input_fingerprint', hdr['input_fingerprint_sha256'] == h.hexdigest(), h.hexdigest())
    check('cache_runner_identity', hdr['runner_sha256'] == sha((SNAP / RUNNER).read_bytes()))
    check('cache_success_and_timeout', hdr['exit_code'] == '0' and hdr['status'] == 'ok' and hdr['timeout_sec'] == '120')
    check('stdout_below_retention_limit', len(stdout) < 200000, len(stdout))
    check('formatted_blank_stderr', stderr == '\n', repr(stderr))
    output = json.loads(stdout)
    check('output_own_source_identity', output['checker_sha256'] == sha((SNAP / RUNNER).read_bytes()))
    configs = [('trace_bridge', TT / 'RESULTS_v1.json', 27), ('general_trace', TT / 'GENERAL_TRACE_RESULTS_v2.json', 8), ('finite_mass', FM / 'RESULTS_v1.json', 229), ('calibration', FM / 'CALIBRATED_RESULTS_v1.json', 14)]
    expected_checks = []
    science_tables = {}
    for unit, path, count in configs:
        old = readj(path)
        count_actual = sum(x['passed'] is True for x in old['checks'])
        check(unit + '_saved_count', count_actual == count == old['passed'] and old['failed'] == 0 and len(old['checks']) == count)
        source_pin = next(x['source_sha256'] for x in lineage['runner_bodies'] if x['name'] == unit)
        check(unit + '_saved_source_identity', old['checker_sha256'] == source_pin)
        check(unit + '_unit_counts', typed(output['units'][unit]) == typed({'passed': count, 'failed': 0}))
        for row in old['checks']:
            expected = dict(row, name=unit + '::' + row['name'])
            idx = len(expected_checks); expected_checks.append(expected)
            check(f'saved_check_object_{idx}', typed(output['checks'][idx]) == typed(expected))
        extra = {k: v for k, v in old.items() if k not in ('passed', 'failed', 'checks', 'checker_sha256', 'scope')}
        check(unit + '_all_substantive_outputs', typed(output['substantive_outputs'][unit]) == typed(extra))
        science_tables[unit] = {k: len(v) if isinstance(v, list) else v for k, v in extra.items()}
    check('complete_check_list_and_namespace', len(output['checks']) == len(expected_checks) == len({x['name'] for x in expected_checks}) == 278)
    check('total_from_actual_Booleans', output['passed'] == sum(x['passed'] is True for x in output['checks']) == 278 and output['failed'] == 0)
    finite = output['substantive_outputs']['finite_mass']
    check('all_grid_rows_and_errors', len(finite['grid']) == 61 and all(len(x['error_estimates']) == 4 for x in finite['grid']))
    check('all_alternate_quadratures', len(finite['alternate_quadrature']) == 7)
    check('all_calibration_examples', len(output['substantive_outputs']['calibration']['synthetic_examples']) == 3)
    details['preserved_science_tables'] = science_tables
    details['cache_evidence_origin'] = recovery['evidence_origin']
    seals = [('thermal', TT / 'independent_v1', '33dfdc4ad29db76706947f79c64630e20329d24a94070d68c55f899baa3accde'), ('finite_mass', FM / 'independent_v1', 'af527b7be8f1c0e00d30b4118e24b6436332e3e08de03d7ad5e7ffded6b82098'), ('calibration', FM / 'calibration_independent_v1', '8023b970ac692735fc88ac2a1048239c9b96d53a44821668f5fdb9ca5d5e8b40')]
    seal_summary = []
    for name, folder, pin in seals:
        receipt = readj(folder / 'RECEIPT_v1.json'); manifest = readj(folder / 'MANIFEST_v1.json')
        check(name + '_final_receipt_pin', sha((folder / 'RECEIPT_v1.json').read_bytes()) == pin, category='seal_identity')
        for key in ('manifest', 'report'):
            check(name + '_' + key + '_bound', identity(folder / receipt[key]['path'], receipt[key]), category='seal_identity')
        for i, artifact in enumerate(manifest['artifacts']):
            check(f'{name}_sealed_artifact_{i}', identity(folder / artifact['path'], artifact), artifact['path'], 'seal_identity')
        present = {str(p.relative_to(folder)) for p in folder.rglob('*') if p.is_file()}
        declared = {x['path'] for x in manifest['artifacts']} | {'MANIFEST_v1.json', 'RECEIPT_v1.json'}
        check(name + '_exact_sealed_inventory', present == declared, {'actual': len(present), 'declared': len(declared)}, 'seal_identity')
        pairs = receipt.get('source_bindings', receipt.get('source_pairs'))
        for i, pair in enumerate(pairs):
            check(f'{name}_source_pair_{i}', identity(SNAP / pair['original_path'], pair) and identity(folder / pair['snapshot_path'], pair), pair['original_path'], 'seal_identity')
        seal_summary.append({'name': name, 'receipt_sha256': pin, 'artifact_count': len(manifest['artifacts']), 'file_count': len(present), 'source_pairs': len(pairs), 'science_rerun': False})
    details['reused_seals'] = seal_summary
    damage_groups = [(TT / 'DAMAGE_SUMMARY_v1.json', TT / 'damages_v1', TT / 'check_trace_bridge_v1.py', '_RESULTS.json', '_RUN.json'), (FM / 'DAMAGE_SUMMARY_v1.json', FM / 'damages', FM / 'check_finite_mass_v1.py', '_results.json', '_run.json'), (FM / 'CALIBRATION_DAMAGE_SUMMARY_v1.json', FM / 'calibration_damages', FM / 'check_calibrated_budget_v1.py', '_results.json', '_run.json')]
    damages = []
    for summary_path, folder, original, result_suffix, run_suffix in damage_groups:
        for rec in readj(summary_path):
            name = rec['name']; damaged = folder / (name + '.py'); result = readj(folder / (name + result_suffix)); run = readj(folder / (name + run_suffix))
            pin = sha(damaged.read_bytes()); original_pin = sha(original.read_bytes())
            key = folder.name + '.' + name
            check(key + '_actual_damaged_source', pin != original_pin and result['checker_sha256'] == pin and run.get('checker_sha256', run.get('script_sha256')) == pin, category='reused_damage')
            fail_names = [x['name'] for x in result['checks'] if not x['passed']]
            check(key + '_actual_failed_math', run['exit_code'] == 1 and result['failed'] == rec['failed'] == len(fail_names) > 0 and result['passed'] == rec['passed'] and fail_names == rec.get('failed_checks', rec.get('failure_names')), category='reused_damage')
            diff = ''.join(difflib.unified_diff(original.read_text().splitlines(True), damaged.read_text().splitlines(True), fromfile=str(original.relative_to(SNAP)), tofile=str(damaged.relative_to(SNAP))))
            damages.append({'name': key, 'source_sha256': pin, 'original_sha256': original_pin, 'passed': result['passed'], 'failed': result['failed'], 'exit_code': run['exit_code'], 'failure_names': fail_names, 'exact_diff': diff})
    details['reused_actual_parent_damages'] = damages
    wrapper = readj(PACK / 'thermal_bounce_packaging/CACHE_WRAPPER_FAILURE_v1.json')
    general = readj(TT / 'GENERAL_TRACE_WRAPPER_FAILURE_v1.json')
    check('wrapper_failure_preserved', 'TypeError' in json.dumps(wrapper) and 'PosixPath' in json.dumps(wrapper))
    check('general_trace_pre_science_failure_preserved', 'NameError' in json.dumps(general) and 'json' in json.dumps(general))
    details['preserved_wrapper_records'] = [wrapper, general]
    rational_checks()
    return {'created_utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Exact source/text/AST/cache/row/seal correspondence plus independent rational linkage; no producer science rerun', 'checker_sha256': sha(Path(__file__).read_bytes()), 'passed': sum(r['passed'] for r in rows), 'failed': sum(not r['passed'] for r in rows), 'category_counts': {c: {'passed': sum(r['passed'] for r in rows if r['category'] == c), 'failed': sum(not r['passed'] for r in rows if r['category'] == c)} for c in sorted({r['category'] for r in rows})}, 'checks': rows, 'details': details}

def rational_checks():
    rational_rows = []
    for i, (A, w, src) in enumerate((a, w, q) for a in (F(2, 3), F(4, 5)) for w in (F(1, 9), F(1, 3)) for q in (F(-1, 7), F(1, 5))):
        H = F(-2, 5) if i % 2 else F(3, 7); L = F(1, 11); rho = F(7, 5); p = w * rho; aE = F(4, 3)
        HJ = (H + L) / A; aJ = A * aE
        drhoJ = src - 3 * HJ * (rho + p)
        rhoE, pE = A**4 * rho, A**4 * p
        drhoE = 4 * L * rhoE + A**5 * drhoJ
        dDE = aE**4 * (drhoE + 4 * H * rhoE)
        dDJ = aJ**4 * (drhoJ + 4 * HJ * rho)
        prefix = f'rational_conformal_{i}_'
        check(prefix + 'Einstein_balance', drhoE + 3 * H * (rhoE + pE) == L * (rhoE - 3 * pE) + A**5 * src, category='rational')
        check(prefix + 'charge_equality', rhoE * aE**4 == rho * aJ**4, category='rational')
        check(prefix + 'time_chain', dDE / A == dDJ, category='rational')
        check(prefix + 'trace_and_source', dDJ == aJ**4 * (HJ * (rho - 3 * p) + src), category='rational')
        rational_rows.append({'A': str(A), 'w': str(w), 'source': str(src), 'H': str(H), 'L': str(L), 'dD_J': str(dDJ)})
    R3 = F(11, 4)
    for i, (w, q) in enumerate((w, q) for w in (F(0), F(1, 5), F(1, 3)) for q in (F(1, 17), F(1, 4))):
        Q, rho, Hdot, kinetic, other = F(3, 7), F(7, 5), F(1, 11), F(1, 13), F(2, 17)
        kappa = Hdot + kinetic + (rho * (1 + w) + other) / (2 * Q)
        f = rho / (3 * Q * kappa)
        lam = F(1) if i % 2 else F(3, 2)
        sigma, eta, target = F(27, 8), F(1, 10), F(1, 10)
        gamma = (1 + eta) * (1 + q)
        pcal3 = lam**6 / (f**3 * R3 * sigma**4 * gamma**3)
        lower3 = F(9, 8)**3 * lam**6 / (R3 * sigma**4 * (1 + eta)**3)
        ccrit3 = 8 * R3 * sigma**4 * (1 + eta)**3 * (1 + q)**3 * target**3 / (27 * lam**6)
        atcrit3 = lam**6 * ccrit3 / (f**3 * R3 * sigma**4 * (1 + eta)**3 * (1 + q)**3)
        prefix = f'rational_bounce_{i}_'
        check(prefix + 'strict_fraction', 0 < f < 2 / (3 * (1 + w)), category='rational')
        check(prefix + 'calibrated_bound', pcal3 > lower3, category='rational')
        check(prefix + 'threshold_identity', atcrit3 / target**3 == 8 / (27 * f**3), category='rational')
        check(prefix + 'threshold_equality_rejected', atcrit3 > target**3, category='rational')
        rational_rows.append({'w': str(w), 'q': str(q), 'f': str(f), 'Pcal_cube': str(pcal3), 'lower_cube': str(lower3), 'threshold_target_ratio': str(atcrit3 / target**3)})
    check('rational_bare_coefficient_cube', F(3, 2)**3 / R3 == F(27, 22) > 1, category='rational')
    check('rational_calibrated_coefficient_cube', 0 < F(9, 8)**3 / R3 == F(729, 1408) < 1, category='rational')
    check('rational_same_component_photon_cancellation', F(4, 11)**3 * R3**4 == R3, category='rational')
    check('rational_bare_does_not_imply_measured', F(6, 5) > 1 and F(6, 5) / F(5, 4) == F(24, 25) < 1, category='rational')
    details['rational_states'] = rational_rows

if __name__ == '__main__':
    result = main()
    target = HERE / 'CORRESPONDENCE_RESULTS_v1.json'
    with target.open('x') as f:
        json.dump(result, f, indent=2); f.write('\n')
    print(json.dumps({k: result[k] for k in ('passed', 'failed', 'category_counts')}, indent=2))
    raise SystemExit(bool(result['failed']))
