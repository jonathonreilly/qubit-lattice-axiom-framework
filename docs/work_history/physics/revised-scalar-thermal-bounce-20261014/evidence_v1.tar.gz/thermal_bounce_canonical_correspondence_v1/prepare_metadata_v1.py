#!/usr/bin/env python3
"""Build reviewer-owned constituent mapping and scope records; no source mutations."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

HERE = Path(__file__).resolve().parent
SNAP = HERE / 'source_snapshot'
P = Path('.claude/science/physics-loops/revised-scalar-derivation-24h-20261013')
TT = P / 'thermal_trace_bridge_v1'
FM = TT / 'finite_mass_bounce_bound_v1'
NOTE = 'docs/EXPONENTIAL_SCALAR_THERMAL_BOUNCE_BOUNDED_THEOREM_NOTE_2026-10-14.md'
RUNNER = 'scripts/exponential_scalar_thermal_bounce_check.py'
NOW = datetime.now(timezone.utc).isoformat()

def load(p):
    return json.loads(p.read_text())

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save(name, data):
    with (HERE / name).open('x') as f:
        json.dump(data, f, indent=2); f.write('\n')

freezes = [load(HERE / f) for f in ('INPUT_FREEZE_v1.json', 'CALIBRATION_CAPTURE_v1.json')]
inputs = [row for freeze in freezes for row in freeze['inputs']]
lineage = load(SNAP / P / 'thermal_bounce_packaging/CANONICAL_LINEAGE_v1.json')
root = Path(str(HERE).split('/.claude/')[0])
ports = {x['path']: (NOTE, 'complete_proof_body_ported_with_heading_changes_original_preserved') for x in lineage['proof_sources']}
ports.update({x['source']: (RUNNER, 'complete_calculation_body_ported_with_function_and_IO_wrapper_original_preserved') for x in lineage['runner_bodies']})
dispositions = []
for row in inputs:
    original = Path(row['original_path']); rel = str(original.relative_to(root))
    final_path, disposition = ports.get(rel, (rel, 'exact_original_preserved_and_recovered_no_status_promotion'))
    final = SNAP / final_path
    assert final.is_file()
    dispositions.append({'original_path': rel, 'original_sha256': row['sha256'], 'disposition': disposition, 'recovery': str(Path(row['snapshot']).relative_to(HERE)), 'final_path': final_path, 'final_sha256': sha(final), 'bytes': row['bytes'], 'original_remains_unchanged': True})
assert len(dispositions) == len({x['original_path'] for x in dispositions}) == 425
save('original_dispositions_v1.json', {'created_utc': NOW, 'scope': 'Frozen three-part thermal milestone only; excludes subsequent joint_entropy_bounce_v1', 'original_root': str(root), 'recovery_root': str(HERE), 'original_dispositions': dispositions})
results = load(HERE / 'CORRESPONDENCE_RESULTS_v1.json')
save('FAILURE_LEDGER_v1.json', {
    'created_utc': NOW,
    'new_science_or_correspondence_failures': [],
    'reviewer_tool_failures': [{'record': f, 'sha256': sha(HERE / f)} for f in ('CAPTURE_FAILURE_v1.json', 'READ_FAILURE_v1.json')],
    'producer_wrapper_failures': results['details']['preserved_wrapper_records'],
    'producer_damaged_runs': [{k: v for k, v in x.items() if k != 'exact_diff'} for x in results['details']['reused_actual_parent_damages']],
    'producer_damaged_diffs': 'CORRESPONDENCE_RESULTS_v1.json#/details/reused_actual_parent_damages',
    'prior_reviewer_failures': [
        {'unit': str(TT / 'independent_v1'), 'original': '63 passed / 2 failed from Python literal division; corrected exact rational run 65/0', 'additional': '9/0 correspondence; 9 actual changed copies rejected'},
        {'unit': str(FM / 'independent_v1'), 'original': '177/0 contained four vacuous guard rows; retained, corrected control set 180/0', 'additional': 'wrong-cwd process failure retained; 7 actual damages; 56/0 affected source correspondence'},
        {'unit': str(FM / 'calibration_independent_v1'), 'original': 'no unexpected baseline/tool failure; original Ccrit equality wording finding retained', 'additional': '8 actual changed implementations, 9 rejected executions including second semantic witness for same damage'}
    ],
    'source_corrections_preserved': ['general trace and ideal endpoint qualification', 'positive target domain qualification', 'Ccrit=1 strict energy but no uniform gap qualification'],
    'failure_counts_not_added_to_new_science': True
})
full_read = [NOTE, RUNNER] + [x['path'] for x in lineage['proof_sources']] + [x['source'] for x in lineage['runner_bodies']]
for folder in (TT / 'independent_v1', FM / 'independent_v1', FM / 'calibration_independent_v1'):
    full_read.extend(str(folder / fn) for fn in ('REPORT_v1.md', 'HAND_DERIVATION_v1.md'))
full_read.append(str(FM / 'calibration_independent_v1/SUPPLEMENT_DERIVATION_v1.md'))
save('COVERAGE_v1.json', {
    'created_utc': NOW,
    'full_principal_text_reads': [{'path': f, 'sha256': sha(SNAP / f)} for f in full_read],
    'selected_cache_utility_functions_read': {'path': 'scripts/runner_cache.py', 'sha256': sha(SNAP / 'scripts/runner_cache.py'), 'functions': ['declared_input_paths', 'declared_input_fingerprint', 'write_cache', 'execute_and_write_cache'], 'whole_module_read_claimed': False},
    'all_originals_hashed_and_recovered': 425,
    'complete_source_result_objects_compared': 278,
    'complete_grid_records_compared': 61,
    'alternate_quadrature_records_compared': 7,
    'synthetic_calibration_examples_compared': 3,
    'complete_prior_manifest_files_verified': 287,
    'prior_source_pairs_verified': 20,
    'reviewer_new_rational_controls': 60,
    'producer_science_or_previous_independent_code_executed': False,
    'all_recovery_files_claimed_semantically_reread': False,
    'preservation_only_includes': ['figure PDF/PNG bytes and prior visual-QA receipts', 'older nested source recovery', 'previous independent commands and unchanged evidence, reused through exact manifests'],
    'old_gravity_dependency': 'pinned reports and receipt plus calibration review verification reused; not a fresh entire older-tree review',
    'primary_sources': 'previous source access recorded by earlier reviewers; no fresh network or full-PDF read claimed',
    'new_joint_entropy_route': 'excluded; not read',
    'metadata_or_authority': 'conditional support only; no formal audit/grade, Git, PR, runtime or lock mutation'
})
save('COMMAND_INDEX_v1.json', {
    'created_utc': NOW,
    'actual_executable_commands': [
        {'command': 'python3 capture_inputs_v2.py', 'command_record': 'CAPTURE_COMMAND_v2.json', 'execution_record': 'CAPTURE_EXECUTION_v2.json', 'scope': 'capture and verification only'},
        {'command': 'python3 capture_calibration_v1.py', 'command_record': 'CALIBRATION_CAPTURE_COMMAND_v1.json', 'execution_record': 'CALIBRATION_CAPTURE_EXECUTION_v1.json', 'scope': 'capture and verification only'},
        {'command': 'python3 check_correspondence_v1.py', 'command_record': 'CORRESPONDENCE_COMMAND_v1.json', 'execution_record': 'CORRESPONDENCE_EXECUTION_v1.json', 'scope': 'new comparisons and rational arithmetic'},
        {'command': 'python3 prepare_metadata_v1.py', 'source': 'prepare_metadata_v1.py', 'source_sha256': sha(Path(__file__)), 'scope': 'this metadata construction; source checksums used, no science rerun'},
        {'command': 'python3 seal_review_v1.py', 'command_record': 'SEAL_COMMAND_v1.json', 'scope': 'final original/recovery identity verification and immutable manifest/receipt creation'}
    ],
    'read_only_inspection_commands': ['rg --files --hidden source_snapshot', 'cat exact frozen note, runner, proof, report and failure paths', 'Python stdlib JSON/path inventory and explicit key/record reads', 'Python stdlib exact source-diff display from recorded damaged copies'],
    'known_failed_commands': [{'record': 'CAPTURE_FAILURE_v1.json', 'kind': 'wrong utility path, partial capture preserved'}, {'record': 'READ_FAILURE_v1.json', 'kind': 'wrong guessed plan filename, no writes'}],
    'producer_execution_reruns': [],
    'old_science_reuse_records': results['details']['reused_seals'],
    'note': 'The executable source and actual command/execution receipts are recoverable here; interactive read transcripts remain tool history and are not represented as independently executed science.'
})
print(json.dumps({'original_dispositions': len(dispositions), 'metadata_files_created': 4, 'new_science_execution': False}))
