#!/usr/bin/env python3
"""Complete only outstanding metadata after preserved v1 filename failure."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

HERE = Path(__file__).resolve().parent
SNAP = HERE / 'source_snapshot'
P = Path('.claude/science/physics-loops/revised-scalar-derivation-24h-20261013')
TT = P / 'thermal_trace_bridge_v1'
FM = TT / 'finite_mass_bounce_bound_v1'
NOW = datetime.now(timezone.utc).isoformat()

def readj(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, data):
    with (HERE / name).open('x') as f:
        json.dump(data, f, indent=2); f.write('\n')

failure = readj(HERE / 'METADATA_PREPARATION_FAILURE_v1.json')
for rec in failure['completed_outputs_preserved']:
    assert sha(HERE / rec['path']) == rec['sha256']
ledger = readj(HERE / 'FAILURE_LEDGER_v1.json')
ledger['created_utc'] = NOW
ledger['supersedes_without_overwriting'] = {'path': 'FAILURE_LEDGER_v1.json', 'sha256': sha(HERE / 'FAILURE_LEDGER_v1.json')}
ledger['reviewer_tool_failures'].append({'record': 'METADATA_PREPARATION_FAILURE_v1.json', 'sha256': sha(HERE / 'METADATA_PREPARATION_FAILURE_v1.json')})
save('FAILURE_LEDGER_v2.json', ledger)
lineage = readj(SNAP / P / 'thermal_bounce_packaging/CANONICAL_LINEAGE_v1.json')
full_read = ['docs/EXPONENTIAL_SCALAR_THERMAL_BOUNCE_BOUNDED_THEOREM_NOTE_2026-10-14.md', 'scripts/exponential_scalar_thermal_bounce_check.py']
full_read += [x['path'] for x in lineage['proof_sources']]
full_read += [x['source'] for x in lineage['runner_bodies']]
for folder, hand in [(TT / 'independent_v1', 'HAND_DERIVATION_v1.md'), (FM / 'independent_v1', 'HAND_PROOF_v1.md'), (FM / 'calibration_independent_v1', 'HAND_DERIVATION_v1.md')]:
    full_read += [str(folder / 'REPORT_v1.md'), str(folder / hand)]
full_read.append(str(FM / 'calibration_independent_v1/SUPPLEMENT_DERIVATION_v1.md'))
save('COVERAGE_v1.json', {
    'created_utc': NOW,
    'full_principal_text_reads': [{'path': f, 'sha256': sha(SNAP / f)} for f in full_read],
    'selected_cache_utility_functions_read': {'path': 'scripts/runner_cache.py', 'sha256': sha(SNAP / 'scripts/runner_cache.py'), 'functions': ['declared_input_paths', 'declared_input_fingerprint', 'write_cache', 'execute_and_write_cache'], 'whole_module_read_claimed': False},
    'all_originals_hashed_and_recovered': 425,
    'complete_source_result_objects_compared': 278,
    'complete_grid_records_compared': 61,
    'alternate_quadrature_records_compared': 7,
    'synthetic_calibration_examples_compared': 3,
    'complete_prior_manifest_files_verified': 287,
    'prior_source_pairs_verified': 20,
    'reviewer_new_rational_controls': 60,
    'producer_science_or_previous_independent_code_executed': False,
    'all_recovery_files_claimed_semantically_reread': False,
    'preservation_only_includes': ['figure PDF/PNG bytes and prior visual-QA receipts', 'older nested source recovery', 'previous independent commands and unchanged evidence, reused through exact manifests'],
    'old_gravity_dependency': 'pinned reports and receipt plus calibration review verification reused; not a fresh entire older-tree review',
    'primary_sources': 'previous source access recorded by earlier reviewers; no fresh network or full-PDF read claimed',
    'new_joint_entropy_route': 'excluded; not read',
    'metadata_or_authority': 'conditional support only; no formal audit/grade, Git, PR, runtime or lock mutation',
    'metadata_recovery': 'Only previously missing coverage/index and versioned failure ledger created; v1 partial outputs preserved'
})
results = readj(HERE / 'CORRESPONDENCE_RESULTS_v1.json')
save('COMMAND_INDEX_v1.json', {
    'created_utc': NOW,
    'actual_executable_commands': [
        {'command': 'python3 capture_inputs_v2.py', 'command_record': 'CAPTURE_COMMAND_v2.json', 'execution_record': 'CAPTURE_EXECUTION_v2.json', 'scope': 'capture and verification only'},
        {'command': 'python3 capture_calibration_v1.py', 'command_record': 'CALIBRATION_CAPTURE_COMMAND_v1.json', 'execution_record': 'CALIBRATION_CAPTURE_EXECUTION_v1.json', 'scope': 'capture and verification only'},
        {'command': 'python3 check_correspondence_v1.py', 'command_record': 'CORRESPONDENCE_COMMAND_v1.json', 'execution_record': 'CORRESPONDENCE_EXECUTION_v1.json', 'scope': 'new comparisons and rational arithmetic'},
        {'command': 'python3 prepare_metadata_v1.py', 'source_sha256': sha(HERE / 'prepare_metadata_v1.py'), 'exit_code': 1, 'failure_record': 'METADATA_PREPARATION_FAILURE_v1.json', 'partial_outputs': ['original_dispositions_v1.json', 'FAILURE_LEDGER_v1.json']},
        {'command': 'python3 prepare_metadata_v2.py', 'source_sha256': sha(Path(__file__)), 'scope': 'this affected metadata completion; no science rerun'},
        {'command': 'python3 seal_review_v1.py', 'command_record': 'SEAL_COMMAND_v1.json', 'scope': 'final identity verification and immutable manifest/receipt creation'}
    ],
    'read_only_inspection_commands': ['rg --files --hidden source_snapshot', 'cat exact frozen note, runner, proof, report and failure paths', 'Python stdlib JSON/path inventory and explicit key/record reads', 'Python stdlib exact source-diff display from recorded damaged copies'],
    'known_failed_commands': [{'record': 'CAPTURE_FAILURE_v1.json', 'kind': 'wrong utility path, partial capture preserved'}, {'record': 'READ_FAILURE_v1.json', 'kind': 'wrong guessed plan filename, no writes'}, {'record': 'METADATA_PREPARATION_FAILURE_v1.json', 'kind': 'wrong hand-proof filename; prior outputs and executed source preserved'}],
    'producer_execution_reruns': [],
    'old_science_reuse_records': results['details']['reused_seals'],
    'note': 'Executable source and actual command/execution receipts are recoverable here; interactive read transcripts remain tool history and are not represented as independently executed science.'
})
print(json.dumps({'partial_v1_outputs_verified_unchanged': 2, 'new_metadata_files': 3, 'science_rerun': False}))
