#!/usr/bin/env python3
"""Final read-only identity checks followed by one immutable local review seal."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

HERE = Path(__file__).resolve().parent
SNAP = HERE / 'source_snapshot'

def load(p):
    return json.loads(p.read_text())

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def rec(p):
    return {'path': str(p.relative_to(HERE)), 'bytes': p.stat().st_size, 'sha256': sha(p)}

def save(name, obj):
    with (HERE / name).open('x') as f:
        json.dump(obj, f, indent=2); f.write('\n')

assert not (HERE / 'MANIFEST_v1.json').exists()
assert not (HERE / 'RECEIPT_v1.json').exists()
freeze_names = ('INPUT_FREEZE_v1.json', 'CALIBRATION_CAPTURE_v1.json')
sources = [r for name in freeze_names for r in load(HERE / name)['inputs']]
assert len(sources) == len({r['original_path'] for r in sources}) == 425
bindings = []
for r in sources:
    original, recovery = Path(r['original_path']), Path(r['snapshot'])
    assert sha(original) == sha(recovery) == r['sha256']
    assert original.stat().st_size == recovery.stat().st_size == r['bytes']
    assert 'joint_entropy_bounce_v1' not in r['original_path']
    bindings.append({'original_path': str(original), 'recovery': str(recovery.relative_to(HERE)), 'bytes': r['bytes'], 'sha256': r['sha256']})
mapping = load(HERE / 'original_dispositions_v1.json')
assert len(mapping['original_dispositions']) == 425
for r in mapping['original_dispositions']:
    assert sha(HERE / r['recovery']) == r['original_sha256']
    assert sha(SNAP / r['final_path']) == r['final_sha256']
    assert str(Path(mapping['original_root']) / r['original_path']) in {s['original_path'] for s in sources}
command = load(HERE / 'CORRESPONDENCE_COMMAND_v1.json')
for r in command['input_pins']:
    assert sha(Path(r['path'])) == r['sha256']
execution = load(HERE / 'CORRESPONDENCE_EXECUTION_v1.json')
assert execution['exit_code'] == 0 and execution['inputs_unchanged'] is True
assert sha(HERE / 'correspondence_v1.stdout') == execution['stdout_sha256']
assert sha(HERE / 'correspondence_v1.stderr') == execution['stderr_sha256']
results = load(HERE / 'CORRESPONDENCE_RESULTS_v1.json')
assert results['checker_sha256'] == sha(HERE / 'check_correspondence_v1.py')
assert results['passed'] == sum(r['passed'] is True for r in results['checks']) == 1161
assert results['failed'] == 0 and all(r['passed'] is True for r in results['checks'])
assert results['category_counts']['rational'] == {'passed': 60, 'failed': 0}
finalization = load(HERE / 'REPORT_PRE_SEAL_FINALIZATION_v1.json')
for key in ('old', 'final', 'diff'):
    assert sha(HERE / finalization[key]['path']) == finalization[key]['sha256']
failure = load(HERE / 'METADATA_PREPARATION_FAILURE_v1.json')
for r in failure['completed_outputs_preserved']:
    assert sha(HERE / r['path']) == r['sha256']
assert sha(HERE / failure['executed_script']['path']) == failure['executed_script']['sha256']
assert len(load(HERE / 'FAILURE_LEDGER_v2.json')['reviewer_tool_failures']) == 3
assert load(HERE / 'METADATA_RECOVERY_EXECUTION_v2.json')['exit_code'] == 0
now = datetime.now(timezone.utc).isoformat()
save('FINAL_SOURCE_IDENTITY_v1.json', {'created_utc': now, 'bindings': bindings, 'count': 425, 'all_live_and_recovery_bytes_match': True, 'scope_excludes_subsequent_joint_route': True, 'source_mutations': False})
save('SEAL_VALIDATION_v1.json', {
    'created_utc': now,
    'source_and_recovery_pairs_verified': 425,
    'disposition_recovery_and_final_pairs_verified': 425,
    'all_execution_input_pins_unchanged': True,
    'comparison_result_counts_verified': results['category_counts'],
    'pre_seal_report_draft_and_finalization_diff_verified': True,
    'preserved_partial_metadata_and_failed_executed_script_verified': True,
    'new_report_is_final_before_manifest': True,
    'no_science_rerun': True,
    'only_review_directory_written': True
})
excluded = {'MANIFEST_v1.json', 'RECEIPT_v1.json'}
artifacts = [rec(p) for p in sorted(HERE.rglob('*')) if p.is_file() and str(p.relative_to(HERE)) not in excluded]
manifest = {'schema': 'focused-canonical-correspondence-manifest-v1', 'created_utc': now, 'artifact_root': str(HERE), 'artifact_count': len(artifacts), 'excludes': sorted(excluded), 'artifacts': artifacts, 'immutable_after_seal': True}
save('MANIFEST_v1.json', manifest)
receipt = {
    'schema': 'focused-canonical-correspondence-receipt-v1',
    'created_utc': now,
    'unit': 'thermal_bounce_canonical_correspondence_v1',
    'scientific_author': '/root',
    'independent_checker': '/root/direct_field_check',
    'scope': 'Frozen three-part thermal canonical note and four-function runner; excludes subsequent joint entropy route',
    'formal_audit': False,
    'formal_grade_or_landing_authority': False,
    'report': rec(HERE / 'REPORT_v1.md'),
    'manifest': rec(HERE / 'MANIFEST_v1.json'),
    'artifact_count': len(artifacts),
    'source_pair_count': 425,
    'original_dispositions': {'path': 'original_dispositions_v1.json', 'pointer': '/original_dispositions', 'sha256': sha(HERE / 'original_dispositions_v1.json'), 'count': 425},
    'source_identity': rec(HERE / 'FINAL_SOURCE_IDENTITY_v1.json'),
    'coverage': rec(HERE / 'COVERAGE_v1.json'),
    'method': rec(HERE / 'METHOD_AND_SCOPE_v1.md'),
    'results': rec(HERE / 'CORRESPONDENCE_RESULTS_v1.json'),
    'command_index': rec(HERE / 'COMMAND_INDEX_v1.json'),
    'failure_ledger': rec(HERE / 'FAILURE_LEDGER_v2.json'),
    'pre_seal_report_chronology': rec(HERE / 'REPORT_PRE_SEAL_FINALIZATION_v1.json'),
    'seal_validation': rec(HERE / 'SEAL_VALIDATION_v1.json'),
    'reviewer_execution': {'passed': 1161, 'failed': 0, 'new_rational_controls': 60, 'other_identity_correspondence_controls': 1101, 'category_counts': results['category_counts']},
    'reused_author_execution': {'passed': 278, 'failed': 0, 'unit_counts': {'trace_bridge': 27, 'general_trace': 8, 'finite_mass': 229, 'calibration': 14}, 'replayed': False, 'grid_rows': 61, 'alternate_quadratures': 7, 'calibration_examples': 3},
    'reused_independent_seals': results['details']['reused_seals'],
    'substantive_findings': 'No mathematical or data-loss discrepancy introduced by this frozen canonical port; original scope qualifications and all actual failures retained.',
    'source_corrections_inherited': ['general trace and finite ideal endpoint qualification', 'positive target domain', 'Ccrit=1 strict above-vacuum energy but no uniform positive gap'],
    'failure_accounting': {'author_post_cache_serialization_failure_preserved': True, 'author_pre_science_NameError_preserved': True, 'reviewer_tool_failures_preserved': 3, 'parent_actual_damaged_runs_reused': 11, 'previous_reviewer_repairs_and_damages_preserved': True},
    'limits': ['conditional matter and supplied action', 'pointwise Einstein bounce and regular endpoint hypotheses', 'same total bath and explicit entropy/calibration inputs', 'no constructed history or body/environment solution', 'no empirical likelihood or acceptance', 'no fresh primary-source or figure visual-QA claim', 'no Git/runtime/audit/PR mutation', 'future joint entropy route not read or included'],
    'immutable_after_seal': True
}
save('RECEIPT_v1.json', receipt)
assert set(str(p.relative_to(HERE)) for p in HERE.rglob('*') if p.is_file()) == {r['path'] for r in artifacts} | excluded
for r in artifacts:
    assert sha(HERE / r['path']) == r['sha256']
assert sha(HERE / receipt['report']['path']) == receipt['report']['sha256']
assert sha(HERE / receipt['manifest']['path']) == receipt['manifest']['sha256']
print(json.dumps({'artifact_count': len(artifacts), 'total_files': len(artifacts) + 2, 'source_bindings': 425, 'final_hashes': {name: sha(HERE / name) for name in ('REPORT_v1.md', 'MANIFEST_v1.json', 'RECEIPT_v1.json', 'original_dispositions_v1.json')}}, indent=2))
