# Conserved radiation cannot dominate beyond a regular Einstein bounce

Direct derivation by /root, prompted by the exposed rolling-grid failure. This
is an analytic classical comparison, not an observational exclusion or new
initial-state selector. It does not depend on the detailed scalar potential.
The supplied action remains a premise when this result is applied to it.

## Domain and bounce inequality

In a closed classical Einstein FLRW metric let kappa=Kc/a_E^2>0 and let Q>0
be the constant Einstein-Hilbert coefficient. Write rho_o,p_o for every
nonradiation component together. The standard equations from the supplied
action, or any theory with this Einstein matter form, are

    3Q(H_E^2+kappa)=rho_r+rho_o,
    Hdot_E=kappa-[rho_o+p_o+(4/3)rho_r]/(2Q).

At a regular Einstein bounce b require H_E,b=0, Hdot_E,b>0, rho_r,b>0,
and rho_o,b+p_o,b>=0. The supplied positive-metric scalar sector has
rho_phi+p_phi=2Q |phidot|_K^2>=0; ordinary positive-enthalpy matter also
satisfies this requirement. Consequently

    kappa_b > 2 rho_r,b/(3Q),
    f_b := rho_r,b/(3Q kappa_b) < 1/2.                (1)

This uses the acceleration equation at the bounce; the squared Friedmann
constraint alone is insufficient. It does not assume a constant scalar or
v_b=0, nor a selected scalar initial point, potential slope or asymptotic state.

## Charge conservation and the later energy bound

Let N=ln(a_E/a_b). For separately conserved radiation, rho_r=rho_r,b e^-4N
and kappa=kappa_b e^-2N. At any later or earlier regular event with N>=0,

    rho_r/(3Q kappa)=f_b e^-2N,
    rho_r/(rho_r+rho_o)=rho_r/[3Q(H_E^2+kappa)]
                       <= f_b e^-2N < 1/2.           (2)

Therefore rho_o>rho_r. The argument does not require monotonic expansion
between the two events; it needs the radius comparison and preserved radiation
charge. It says nothing at a smaller radius N<0. It also does not equate the
energy fraction in(2) with an H-normalized Omega_r, which can diverge at H=0.
In the radiation-plus-scalar case,

    rho_r/rho_phi <= [f_b e^-2N]/[1-f_b e^-2N] < 1.   (3)

Thus rolling the same positive-kinetic scalar potential cannot create a
radiation-energy-dominated era on the expanding-radius side of this class
of Einstein bounce. This is stronger than the constant-origin reconstruction
and explains the grid outcome without extending finite numerical evidence
into a global numerical claim. The bound holds for arbitrary positive scalar
kinetic metric and any potential along regular solutions with these premises.
It does not prove that such bounces are complete or stable.

Define R_b=rho_r,b/(2Q H_v^2), so scalar rest energy is2Q H_v^2 U_b.
For the chosen time-symmetric data in the grid, R_b=f U_b and v_b=0 give
f_b=f/(1+f). Equation(3) at N>=0 bounds the ratio by its initial f; this is a
prediction checked against all stored grid samples, not a fitted parameter.

## Physical metric and observational scope

Use the supplied physical metric g_J=C g_E, A=sqrt(C)>0, dt_J=A dt_E and
a_J=A a_E. Put Z=H_E+d(ln A)/dt_E so H_J=Z/A. At a regular event with
Z!=0 and positive radiation, define the geometric curvature fraction and
bare-coefficient radiation diagnostic

    d_J = Kc/(a_J^2 H_J^2)=kappa/Z^2,
    F_r,J=H_J^2/[C rho_r,J/(3Q)]=3Q Z^2/rho_r,
    rho_r,J=rho_r/C^2.

They obey the exact identity

    d_J F_r,J=3Q kappa/rho_r=e^(2N)/f_b > 2e^(2N).   (4)

Consequently a near-flat event d_J<<1 cannot simultaneously have F_r,J near1
within this conserved-radiation bounce class. This diagnostic uses the bare
nonminimal Ricci coefficient Q/C, not an unproved identification with measured
Cavendish gravity. It is a conditional bridge to a GR-like radiation expansion,
not a CMB, BBN or local-gravity likelihood. Physical-frame scalar effective
energy includes nonminimal-gravity terms; equation(2) is explicitly Einstein
energy bookkeeping. A Jordan bounce may occur without an Einstein bounce,
so this is not a no-go theorem for every possible physical bounce of the action.
It does not close unknown matter, calibration or quantum effects.

## Necessary radiation production if this route is retained

Allow, as a new explicit hypothesis, a radiation-charge growth factor

    zeta = [rho_r a_E^4]/[rho_r,b a_b^4] > 0.

Then f_b e^-2N in(2) is replaced by f_b zeta e^-2N. Radiation fraction above
one half requires, but is not guaranteed by,

    zeta > e^(2N)/(2 f_b).                            (5)

If d_J<=epsilon and F_r,J<=1+delta for positive epsilon and delta>=0, the
physical identity requires

    zeta >= e^(2N)/[f_b epsilon(1+delta)].             (6)

These are lower bounds on an additional energy-transfer mechanism. They do
not derive reheating, a particle sector, an initial charge, the absolute
radiation density or any new allowed history. A source that grows radiation
must also obey the full coupled energy balance; simply choosing zeta is not
a self-consistent repair. Violation of the bounce enthalpy premise, a different
metric action or a smaller-radius history are other routes outside this theorem,
not solutions supplied by it.
