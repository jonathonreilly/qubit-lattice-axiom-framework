# Direct conditional thermal bookkeeping checks

The first direct execution passed27/0. Four actual one-edit damaged implementations
were rejected; command, code, stdout/stderr and complete results are retained.
No equations were fitted to observational data. The ideal isolated electromagnetic
bath has a total endpoint radiation-charge factor1.4010196653276935603, while
the photon-only factor is3.8528040796511572909. Their consistent bounce budgets
are identical because f_b,photon=(4/11)f_b,total. Mixing the larger photon factor
with the total initial fraction is invalid.

The illustrative epsilon=1/100,delta=1/10,f_b=1/4,N=0 requires zeta>=4000/11;
none of these target numbers was acquired from a likelihood. The ideal single
pair threshold falls far below that invented example, which is a control and
not an observational exclusion. Actual finite-mass endpoints, additional species,
noninstantaneous decoupling, chemical potentials, nonadiabatic entropy production
and a physical source reservoir require separate modeling. The prescribed-H
transfer family verifies continuity nonuniqueness, not an Einstein-field history.

Gravity fixes conformal trace exchange; a separate radiation source is not
derived until the matter interactions and state are supplied. This labels a
surviving assumption rather than replacing it by a claimed derived selector.
