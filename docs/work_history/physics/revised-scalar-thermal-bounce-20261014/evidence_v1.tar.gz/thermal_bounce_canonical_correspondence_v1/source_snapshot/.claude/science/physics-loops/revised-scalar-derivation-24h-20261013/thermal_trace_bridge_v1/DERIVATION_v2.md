# Radiation conservation, conformal exchange and conditional thermal repair

Direct derivation by /root. The past-history theorems explicitly assume a
positive separately conserved radiation charge. This block asks how much of
that premise follows from the supplied universal matter action. The observed
existence of massive particles and thermal transitions makes this a real
applicability question; a one-component w=1/3 fluid is not automatically the
whole early-universe matter sector.

## What the universal metric coupling fixes

Let g_J=A^2g_E, C=A^2, dt_J=A dt_E, a_J=A a_E,
L=dot(A)/A=b.dot(phi), H=H_E, Z=H+L and H_J=Z/A.
For an isotropic component i, define a Jordan energy-exchange density Q_i,J by

    d rho_i,J/dt_J + 3 H_J(rho_i,J+p_i,J)=Q_i,J.

Total on-shell matter diffeomorphism invariance gives sum_i Q_i,J=0 when the
split includes all interacting matter components and no external source.
It does not individually set every Q_i,J to zero. With
rho_i,E=A^4rho_i,J, p_i,E=A^4p_i,J, direct differentiation gives

    dot rho_i,E+3H(rho_i,E+p_i,E)
      =L(rho_i,E-3p_i,E)+A^5 Q_i,J.                  (1)

The trace term is fixed by the conformal coupling. Internal transfer is a
property of the specified matter interactions and state, not fixed by A
alone. The factor A^5 matters: Q_i,J is per physical proper time and volume.
For an exactly traceless component, p_r=rho_r/3, define the frame-invariant
radiation charge

    D_r=rho_r,E a_E^4=rho_r,J a_J^4.

Then

    dot D_r=a_E^4 A^5 Q_r,J,
    d D_r/dt_J=a_J^4 Q_r,J.                          (2)

For a component or whole bath that is not exactly traceless, the same charge
expression D_i=rho_i,J a_J^4 instead obeys the exact general identity

    dD_i/dt_J=a_J^4[H_J(rho_i,J-3p_i,J)+Q_i,J].       (2a)

This follows by differentiating D_i and inserting the component continuity
equation. At a massive threshold the total bath may have Q_total,J=0 but
rho_total-3p_total!=0, so its charge can grow. That is consistent with (2),
whose absence of a trace term required p_r=rho_r/3. It is not a direct
scalar-to-photon production rate. The focused independent check highlighted
this distinction; the author added this explicit derivation to make the
endpoint thermodynamic calculation's intermediate assumptions visible.

An isolated classical tracefree sector has Q_r,J=0, so D_r is conserved.
This is a derived consequence conditional on isolation and tracelessness.
The bare gravitational action does not derive a thermal distribution,
radiation abundance, entropy constant, particle masses or the separate
absence of transfer. Quantum anomalies, nonrelativistic thresholds and
interactions require their actual stress tensors and microscopic inputs.

For a decoupled massive component Q_i,J=0, equation (1) still has a trace
source in Einstein time. That source is a frame conversion, not by itself
creation of photons. A scalar force sourced by a thermal trace must not be
counted as a radiation-production rate without a component exchange model.

## Inverse bookkeeping is not an interaction law

In a Jordan dust/radiation split with rho_d,rho_r>=0, choose an actual
interaction rate J(t_J) and let Q_r,J=J,Q_d,J=-J. Then

    dot_J rho_r+4H_J rho_r=J,
    dot_J rho_d+3H_J rho_d=-J.

The sum always obeys total conservation. Conservation alone allows an
infinite family of such transfer histories and does not determine J or its
sign. A nonnegative J can be sustained only while the source reservoir and
its dynamics support it. Specifying J=Gamma rho_d introduces Gamma and a
microscopic interaction assumption; it is not a derivation from diffeomorphism
invariance. Inferring J from a supplied history is a reconstruction, not a
prediction of that history.

If a positive radiation charge changes between two events, let
zeta=D_r,f/D_r,b. In an Einstein-bounce setting with fixed positive curvature
and f_b=rho_r,b/(3Q kappa_b)<1/2, the endpoint identity becomes

    d_J,f F_bare,f=(a_E,f/a_E,b)^2/(f_b zeta).         (3)

A target d_J,f<=epsilon, F_bare,f<=1+delta therefore requires

    zeta >= exp(2N)/[f_b epsilon(1+delta)],
    N=log(a_E,f/a_E,b).                              (4)

This uses the initial bounce bound and endpoint identities, not conserved
radiation in between. It supplies a necessary charge budget, not a source.
If other energy conditions, the target calibration or radius ordering change,
they must be checked explicitly. Here N>=0 for the radius-growing use case.

## Equilibrium entropy supplies a conditional endpoint budget

Adopt a thermal endpoint definition in physical units, zero chemical potentials,
and a comoving entropy S=s_J a_J^3 for a specified bath:

    rho_J=(pi^2/30)g_* T^4,
    s_J=(2pi^2/45)g_*s T^3.

Eliminating T and a_J shows

    D=rho_J a_J^4
      =(pi^2/30)(45/(2pi^2))^(4/3)
        [g_*/g_*s^(4/3)] S^(4/3).

Thus between endpoint thermal states

    zeta=(g_*,f/g_*,b)(g_*s,b/g_*s,f)^(4/3)
          (S_f/S_b)^(4/3).                          (5)

If both endpoints have all bath species ultrarelativistic at one common
 temperature, g_*=g_*s=g, and

    zeta=(g_b/g_f)^(1/3)(S_f/S_b)^(4/3).             (6)

An adiabatic transition with S_f=S_b can increase D even though total
matter conservation holds; assuming D constant across a change in degrees
of freedom would silently strengthen the model. Conversely, a large required
zeta cannot be supplied by an arbitrarily small change in g. Combining
(4) and (6) gives the necessary entropy condition

    S_f/S_b >= [exp(2N)/(f_b epsilon(1+delta))]^(3/4)
                (g_f/g_b)^(1/4).                   (7)

Endpoint chemical potentials, species out of equilibrium, different bath
temperatures and conserved charges require the corresponding thermodynamic
relations; (5)–(7) are not universal entropy theorems.

## Ideal electron-positron/photon illustration and a split-sector warning

For a supplied isolated equilibrium electromagnetic bath well above the
electron mass, photon spin states contribute2 and electron/positron states
contribute(7/8)*4, so g_b=11/2. Well below the mass, g_f=2. With ideal adiabatic
annihilation and negligible remnant pair abundance,

    zeta_total_bath=(11/4)^(1/3).                     (8)

If instead D refers only to the photon component at both ends, the same
entropy calculation yields

    zeta_photon=(11/4)^(4/3).                         (9)

The degrees-of-freedom values are ideal ultrarelativistic/nonrelativistic
endpoint limits, not exact finite-temperature values at a specified T/m.
Finite-mass endpoint corrections require their actual distributions.

These are different charges. The initial bounce fraction f_b in (3) must
refer to the same component used for zeta; one cannot combine a total initial
radiation fraction with the larger photon-only factor. Massive pairs near
threshold are not exactly traceless radiation; the endpoint construction and
energy transfer explicitly replace that intermediate assumption.

This illustration does not model neutrino decoupling, QED corrections, nuclear
reactions, a complete standard-model species history, a scalar-induced decay,
or measured light-element abundances. It introduces the specified observed
particle sector and a chosen thermal state as inputs; neither is selected by
the candidate gravity action. The fixed charge budget makes a proposed repair
checkable without declaring a freely supplied production law to be derived.
