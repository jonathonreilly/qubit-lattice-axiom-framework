from pathlib import Path
import sympy as S
import json,sys,hashlib
out=Path(sys.argv[1]); assert not out.exists()
rows=[]
def eq(name,expr):
 value=S.factor(S.expand(expr)); rows.append(dict(name=name,passed=value==0,residual=str(value)))
A,a,r,p,H,L,Q=S.symbols('A a rho pressure H L Q',real=True,nonzero=True)
Z=H+L; hj=Z/A; aj=A*a
rjprime=Q-3*hj*(r+p)
# Direct physical differentiation, no traceless or isolated component premise.
djprime=aj**4*(rjprime+4*hj*r)
expected=aj**4*(hj*(r-3*p)+Q)
eq('general_physical_charge_equation',djprime-expected)
# Independently differentiate the Einstein expression A^4 rho_J a_E^4.
dedot=A**4*a**4*(4*L*r+A*rjprime+4*H*r)
eq('charge_derivatives_proper_time_conversion',dedot-A*djprime)
eq('general_Einstein_charge_trace_and_source',dedot-a**4*((H+L)*(A**4*r-3*A**4*p)+A**5*Q))
eq('traceless_source_limit',djprime.subs(p,r/3)-aj**4*Q)
eq('isolated_traceful_limit',djprime.subs(Q,0)-aj**4*hj*(r-3*p))
eq('isolated_dust_charge_growth',djprime.subs({Q:0,p:0})-hj*r*aj**4)
r1,r2,p1,p2,j=S.symbols('r1 r2 p1 p2 j',real=True)
pair=djprime.subs({r:r1,p:p1,Q:j})+djprime.subs({r:r2,p:p2,Q:-j})
eq('complete_bath_sources_cancel_but_trace_survives',pair-aj**4*hj*(r1+r2-3*(p1+p2)))
# The conditional logarithmic budget retains a nonzero trace across a threshold.
w=S.symbols('w',real=True)
eq('isolated_logarithmic_charge_rate',djprime.subs({Q:0,p:w*r})/(hj*r*aj**4)-(1-3*w))
result={'passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),'checks':rows,'scope':'Eight exact identities checking new Eq2a only. Original 27/0 thermodynamic/component checks reused, not rerun; no microscopic thermal history or observed fit.','checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
out.write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result));sys.exit(bool(result['failed']))
