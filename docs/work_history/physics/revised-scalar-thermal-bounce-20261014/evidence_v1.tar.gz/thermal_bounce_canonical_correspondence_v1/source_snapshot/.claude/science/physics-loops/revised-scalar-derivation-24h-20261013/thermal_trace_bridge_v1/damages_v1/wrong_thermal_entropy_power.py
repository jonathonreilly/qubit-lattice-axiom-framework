from pathlib import Path
import json,sys,hashlib
import sympy as S
out=Path(sys.argv[1]);assert not out.exists();rows=[]
def ck(n,b,d=None):rows.append(dict(name=n,passed=bool(b),detail=d))
def eq(n,x):v=S.factor(S.simplify(x));ck(n,v==0,str(v))
A,a,r,p=S.symbols('A a r p',positive=True);L,H,src=S.symbols('L H source',real=True)
Z=H+L;HJ=Z/A;rdot=A*(src-3*HJ*(r+p));rhoE=A**4*r;pressE=A**4*p
rEdot=4*L*rhoE+A**4*rdot
rhs=L*(rhoE-3*pressE)+A**5*src
eq('conformal_component_balance',rEdot+3*H*(rhoE+pressE)-rhs)
eq('tracefree_scalar_exchange_vanishes',(L*(rhoE-3*pressE)).subs(p,r/3))
DE=rhoE*a**4;DJ=r*(A*a)**4
eq('radiation_charge_frame_invariant',DE-DJ)
Ddot=(rEdot*a**4+4*H*rhoE*a**4).subs(p,r/3)
eq('radiation_charge_Einstein_source',Ddot-a**4*A**5*src)
eq('radiation_charge_physical_source',Ddot/A-(A*a)**4*src)
eq('isolated_radiation_charge',Ddot.subs(src,0))
rd,pd,rdJ,rpJ=S.symbols('rho_d p_d Qd Qr',real=True)
eq('internal_sources_cancel',(A**5*rdJ+A**5*rpJ).subs(rdJ,-rpJ))
# Two possible transfer laws solve the same total continuity identity.
t,h,ga,r0,d0=S.symbols('t h Gamma r0 d0',positive=True)
d=d0*S.exp(-(3*h+ga)*t);rsol=S.exp(-4*h*t)*(r0+ga*d0*(S.exp((h-ga)*t)-1)/(h-ga));J=ga*d
for n,e in [('dust_transfer',S.diff(d,t)+3*h*d+J),('radiation_transfer',S.diff(rsol,t)+4*h*rsol-J),('total_continuity',S.diff(d+rsol,t)+3*h*(d+S.Rational(4,3)*rsol))]:eq(n,e)
resonant=S.exp(-4*h*t)*(r0+h*d0*t)
eq('resonant_transfer_limit',S.limit(rsol,ga,h)-resonant)
eq('no_transfer_control',rsol.subs(ga,0)-r0*S.exp(-4*h*t))
eq('same_initial_radiation_for_distinct_rates',rsol.subs(t,0)-r0)
eq('same_initial_dust_for_distinct_rates',d.subs(t,0)-d0)
# These prescribed-H solutions are continuity controls, not Einstein/scalar histories.
fb,lam,zet,eps,delta,calS=S.symbols('fb lambda zeta epsilon delta entropy_ratio',positive=True)
rhob,kapb,Q=S.symbols('rhob kapb Q',positive=True);rhof=zet*rhob/lam**4;kapf=kapb/lam**2
product=3*Q*kapf/rhof
eq('endpoint_charge_budget',product.subs(rhob,3*Q*kapb*fb)-lam**2/(fb*zet))
threshold=lam**2/(fb*eps*(1+delta))
eq('necessary_growth_threshold_saturates',(lam**2/(fb*zet)).subs(zet,threshold)-eps*(1+delta))
# Thermodynamic endpoint identity from rho(T) and entropy(T), no chosen temperature scale.
g,gs,ent,rad=S.symbols('g gs entropy radius',positive=True)
TT=(45*ent/(2*S.pi**2*gs*rad**3))**S.Rational(1,3)
D=S.pi**2*g*TT**4*rad**4/30
coef=(S.pi**2/30)*(45/(2*S.pi**2))**S.Rational(4,3)
eq('thermal_charge_entropy_identity',D-coef*g*ent**S.Rational(4,3)/gs**S.Rational(4,3))
gb,gf,gsb,gsf,Sb,Sf=S.symbols('gb gf gsb gsf Sb Sf',positive=True)
zthermal=gf/gb*(gsb/gsf)**S.Rational(4,3)*(Sf/Sb)**S.Rational(1,3)
eq('thermal_endpoint_ratio',(D.subs({g:gf,gs:gsf,ent:Sf})/D.subs({g:gb,gs:gsb,ent:Sb}))-zthermal)
zcommon=(gb/gf)**S.Rational(1,3)*(Sf/Sb)**S.Rational(4,3)
eq('common_temperature_endpoint_reduction',zthermal.subs({gsb:gb,gsf:gf})-zcommon)
smin=threshold**S.Rational(3,4)*(gf/gb)**S.Rational(1,4)
eq('necessary_entropy_threshold',zcommon.subs(Sf,Sb*smin)-threshold)
# Specified ideal electromagnetic bath; component identity prevents budget inflation.
gstart=S.Rational(2)+S.Rational(7,8)*4;gend=S.Rational(2)
zall=(gstart/gend)**S.Rational(1,3);zphot=(gstart/gend)**S.Rational(4,3)
eq('electron_pair_spin_weight',gstart-S.Rational(11,2))
eq('total_bath_charge_factor',zall-(S.Rational(11,4))**S.Rational(1,3))
eq('photon_charge_factor',zphot-(S.Rational(11,4))**S.Rational(4,3))
fph=(gend/gstart)*fb
eq('same_component_budget_cancellation',fph*zphot-fb*zall)
ck('larger_photon_factor_is_not_total_factor',zphot>zall>1)
# Exposed illustrative threshold, not Planck/BBN observation.
example={fb:S.Rational(1,4),lam:S.Rational(1),eps:S.Rational(1,100),delta:S.Rational(1,10)}
needed=threshold.subs(example);ck('illustrative_adiabatic_pair_budget_insufficient',needed>zall)
wrong=fb*zphot;correct=fb*zall;ck('mixed_component_budget_overstates_repair',wrong>correct)
res={'passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),'checks':rows,'ideal_pair_total_factor':str(S.N(zall,20)),'ideal_pair_photon_factor':str(S.N(zphot,20)),'illustrative_required_growth':str(needed),'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Exact conformal/entropy bookkeeping under explicit matter and endpoint premises; no microscopic interaction law, abundance likelihood or actual bounce repair.'};out.write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({k:v for k,v in res.items() if k!='checks'}));
for x in rows:
 if not x['passed']:print('FAILED',x)
raise SystemExit(1 if res['failed'] else 0)
