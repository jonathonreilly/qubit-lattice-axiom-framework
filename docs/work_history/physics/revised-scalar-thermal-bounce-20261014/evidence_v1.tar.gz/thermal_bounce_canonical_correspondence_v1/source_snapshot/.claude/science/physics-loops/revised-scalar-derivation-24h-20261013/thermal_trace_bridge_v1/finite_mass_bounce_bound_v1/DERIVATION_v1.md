# Finite-mass equilibrium threshold and a conditional bounce obstruction

Direct scientific author: /root. This addresses a specific physical loophole in
the separately conserved radiation assumption: observed massive pairs are not
traceless through annihilation. No microscopic matter theory, equilibrium state,
interaction rate, entropy abundance or initial history is selected here.

## Adopted matter sector and exact thermodynamics

Use the same supplied universal physical metric g_J=A^2 g_E. Adopt an ideal
isotropic photon plus electron/positron bath, common positive physical T,
zero chemical potentials, two photon and four fermion spin states, fixed
physical pair mass m>0, and distributions f_gamma=(exp(p/T)-1)^-1 and
f_e=(exp(sqrt(p^2+m^2)/T)+1)^-1. The particle content, mass and distributions
are matter inputs. The gravity action by itself does not imply equilibration.
The standard distribution, stress and entropy definitions are given in PDG's
2025 Big-Bang Cosmology review, Eqs22.35–22.42; the distinct equilibrium-rate
condition is discussed in Eq22.45. This source is exposed development context,
not a likelihood or evidence that this candidate satisfies the rate condition.
https://pdg.lbl.gov/2025/reviews/rpp2025-rev-bbang-cosmology.pdf

For x=m/T, y=p/T, Ehat=sqrt(y^2+x^2), and f=(exp(Ehat)+1)^-1, write

    rho_J=T^4 r(x),       p_J=T^4 P(x),
    r=pi^2/15 + (2/pi^2) integral_0^infinity y^2 Ehat f dy,
    P=pi^2/45 + (2/(3pi^2)) integral_0^infinity y^4 f/Ehat dy.

Positive integrands give 0<p_J<=rho_J/3. The exact trace is

    rho_J-3p_J = (2m^2/pi^2) integral_0^infinity p^2 f_e/E dp >0

at any finite m,T>0. Differentiating at fixed physical momentum gives

    rho_T = 4pi^2 T^3/15
       +(2/(pi^2 T^2)) integral_0^infinity p^2 E^2 f_e(1-f_e) dp >0.

Integration by parts, with vanishing endpoint terms, yields p_T=(rho+p)/T.
Let s=(rho+p)/T. Differentiating this relation gives s_T=rho_T/T. These
identities include the continuous finite-mass transition; no step in g is used.
All derivatives here vary physical T at fixed m and fixed matter definitions.

## Isolation derives entropy conservation within equilibrium

For a bath with Q_total,J=0, physical continuity is
rho_T dot_J T+3H_J(rho+p)=0. Therefore

    dot_J(s a_J^3)=a_J^3[rho_T dot_J T/T+3H_J s]=0.

The positive constant S is an unselected integration constant. Isolation and
reversible local equilibrium imply its conservation, not its value. Departure
from equilibrium, chemical potentials, dissipative entropy, changing masses or
external transfers require new equations. No collision-rate check has been
performed to establish equilibrium for a candidate bouncing trajectory.

Define D=rho_J a_J^4=rho_E a_E^4 and G(T)=rho/s^(4/3). With fixed S,
D=S^(4/3)G(T). Exact differentiation gives

    d ln G/dT = rho_T (3p-rho)/[3rho(rho+p)] <=0.       (1)

The asymptotic ideal gas integrals give effective weights g_hot=11/2 and
g_cold=2. Thus G is between its hot and cold limits, whose ratio is

    R=G_cold/G_hot=(11/4)^(1/3).                      (2)

For any two finite positive temperatures on one fixed-entropy history,

    1/R <= zeta=D_f/D_b <= R.                        (3)

The weak endpoint inequalities suffice; neither a temperature ordering nor
monotone physical expansion is needed. A nonmonotone scalar conformal factor
does not defeat (3), because the charge is exactly frame invariant. For this
ideal m>0 gas finite endpoint bounds are strict, but the proof below only uses
weak bounds. The numerical integral grid checks the formulas; monotonicity
and the analytic limiting integrals establish the uniform statement.

## Einstein-bounce inequality with a traceful bath

Let Q>0 be the gravitational coefficient, w_phi=|dot phi|_K^2>=0,
kappa=Kc/a_E^2, and let other nonbath matter satisfy rho_o+p_o>=0 at a strict
Einstein bounce H_E,b=0, dot H_E,b>0. The action has scalar kinetic energy
Q w_phi, without a 1/2 in its kinetic Lagrangian. Raychaudhuri is

    dot H_E=kappa-w_phi-[rho_B,E+p_B,E+rho_o+p_o]/(2Q).

All bath stresses transform with the same positive A^4, so w_B=p_B/rho_B
is frame invariant and nonnegative. At the bounce,

    kappa_b > rho_B,b(1+w_B,b)/(2Q),
    f_B,b=rho_B,b/(3Q kappa_b) < 2/[3(1+w_B,b)] <=2/3. (4)

This derives positive Kc directly from Raychaudhuri and the positive bath.
Unlike the traceless radiation bound, no p_B=rho_B/3 assumption is made.
No special form or height of the scalar potential is used in this step.

At a later event with Z_f=H_E,f+dot A_f/A_f nonzero, define

    d_J,f=kappa_f/Z_f^2,
    F_bare,B,f=3Q Z_f^2/rho_B,E,f,
    N=ln(a_E,f/a_E,b).

The same total bath must be used in f_B and zeta. Endpoint kinematics gives

    d_J,f F_bare,B,f = exp(2N)/(f_B,b zeta)
      > [3(1+w_B,b)/(2R)] exp(2N)
      >= [3/(2R)] exp(2N).                           (5)

For this bath, (3/(2R))^3=27/22>1. Consequently every such Einstein bounce
and later event with a_E,f>=a_E,b obeys d_J,f F_bare,B,f>1. It cannot reach
a target d_J,f<=epsilon and F_bare,B,f<=1+delta with epsilon(1+delta)<=1.
The ideal pair threshold alone therefore cannot remove this specific bound.
This is a conditional mathematical obstruction, not a likelihood exclusion.
It concerns the bare cosmological normalization and a total-bath diagnostic;
it is not automatically a bound on a photon-only or measured-G radiation law.

For a finite set of ideal equilibrium species at fixed masses and zero chemical
potentials, the same positive-trace/heat-capacity argument gives R=(g_hot/g_cold)^(1/3),
provided some massless species remain and the same bath is isolated. The coarse
bounce obstruction with N>=0 is guaranteed whenever R<=3/2. For a larger
ratio it is not guaranteed by this estimate; that does not construct a repair.
An externally allowed entropy increase sigma=S_f/S_b multiplies the maximum
charge ratio by sigma^(4/3). A necessary escape budget becomes

    sigma > [3 exp(2N)/(2R epsilon(1+delta))]^(3/4),   (6)

using the strict bounce inequality. Specifying sigma is not a production law.
For different measured-gravity normalizations the additional calibration factor
must be inserted before any observational assertion.

## Scope of the progress

Within a stated matter sector, constant D has been replaced by the derived
finite-mass charge range, and the restricted Einstein-bounce obstruction still
holds. The result removes the need for exact tracelessness throughout this
particular argument. It retains, and does not derive, isolation, reversible
equilibrium, the particle theory, positive kinetic/enthalpy conditions, radius
ordering and the target epoch/calibration. No full bouncing thermal solution,
reaction network, observed abundance, independent empirical test, general
Jordan-bounce theorem, perturbation stability or quantum origin is established.
