# Calibrated-gravity and entropy limits of the finite-mass bounce result

Direct author /root. This is an integration of the finite-mass thermodynamic
bound with the separately checked conditional calibration formulas. It is not
a new local-body solution, a measured calibration, or an empirical likelihood.

Let P_bare=d_J F_bare,B and let G_bare,c=C_c/(8pi Q)>0 at the final
cosmological event. For an actually chosen positive measured normalization
G_cal, define gamma=G_cal/G_bare,c. Then

    F_cal,B=F_bare,B/gamma,      P_cal=P_bare/gamma.        (1)

The finite-mass proof gives P_bare>3 exp(2N)/(2R) at fixed bath entropy,
R=(11/4)^(1/3), with the same total-bath diagnostic at all endpoints.
For different positive entropy constants at the two equilibrium endpoints,
let sigma=S_f/S_b. The endpoint thermodynamic bounds instead give

    zeta<=R sigma^(4/3),
    P_cal>3 exp(2N)/[2R sigma^(4/3) gamma].               (2)

No process that changes sigma is derived. At sigma=1 the original isolated
reversible model is recovered. Eq2 uses the actual bounce cap and thermal
endpoint definitions; it does not require equilibrium throughout an entropy
producing interval, but the interval must still be an actual gravitational
history before this becomes an applicability statement.

## Same-background weak-source calibration

In the previously derived instantaneous weak-source principal limit,
G_pr=G_bare,c(1+q_c), 0<q_c<1/3. The additional nonnegative self-adjoint
constant-mass Yukawa model gives 1<=gamma<=1+q_c for its radial force.
These are specified response regimes, not a theorem for arbitrary bodies,
tachyonic modes, a changing environment, or nonlinear screening.

If an independently justified relative-error ceiling eta>=0 gives
G_cal<=(1+eta)G_pr, then gamma<(4/3)(1+eta) and

    P_cal>9 exp(2N)/[8R sigma^(4/3)(1+eta)].             (3)

The same-background eta=0,sigma=1 coefficient 9/(8R) is below one.
Thus the bare statement P_bare>1 does not by itself imply P_cal>1.
A positive target L=epsilon(1+delta), epsilon>0, delta>=0, requires

    exp(2N) < (8/9) R sigma^(4/3)(1+eta)L.              (4)

When N>=0 and the right-hand side is <=1, the target is impossible under
these explicit calibration assumptions. Otherwise Eq4 is a necessary radius
budget, not evidence that a background solution or an observational fit exists.

## Arbitrary finite calibration background under the principal ceiling

The supplied action's checked coupling identity gives, at any finite local
field point, C_l(1+q_l)<=1+k with 0<k<1/3. If the local measurement is in the
same principal regime with the stated error ceiling, then

    gamma<=(1+eta)(1+k)/C_c.

Combining with Eq2 gives a necessary small-C condition for the positive target:

    C_c<Ccrit,
    Ccrit=2R sigma^(4/3)(1+eta)(1+k)L exp(-2N)/3.        (5)

Neither the relation between local and cosmological states nor the history
that produces either state has been supplied by this inequality. If 0<Ccrit<1,
the previously proved negative-u monotonicity of the scalar potential gives

    rho_phi,E/(2Q Hv^2)>U0(Ccrit),
    U0(C)=3/2+(3s/2)(1-C)^2
       +nu(1+s-sC)^2 log^2[C/(1+s-sC)]/[8a(1+s)].      (6)

Here a=(1-k)(1+3k)/4, s=(1+k)/[k(1-3k)], nu>0 and the full potential has
nonnegative x,y additions. Eq6 is a required scalar-energy cost, not a measured
upper bound or a contradiction. If Ccrit=1, the strict C_c<1 still gives
energy strictly above3/2, but no uniform positive excess above the vacuum
floor is supplied. If Ccrit>1, this argument forces neither C_c<1 nor that
negative-u threshold floor. The choice of k,nu,Hv and an entropy source remains
unselected. The positive-target condition excludes division by a nonpositive
L; a nonpositive target is already impossible because P_cal>0.

All endpoint budgets refer to the specified total electromagnetic bath.
Additional decoupled species, chemical potentials, QED corrections and finite
body measurement effects require their own energy and calibration equations.
The numerical constants below are synthetic evaluations of these exact
coefficients; no data values or fitted errors have been substituted.
