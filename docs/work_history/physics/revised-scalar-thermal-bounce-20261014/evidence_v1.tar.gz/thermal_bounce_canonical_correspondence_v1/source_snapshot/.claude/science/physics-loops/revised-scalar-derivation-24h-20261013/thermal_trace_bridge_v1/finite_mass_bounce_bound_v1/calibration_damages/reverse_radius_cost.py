from pathlib import Path
import sympy as S
import json,sys,hashlib
out=Path(sys.argv[1]);assert not out.exists();rows=[]
def eq(n,e):
 v=S.factor(S.simplify(e));rows.append(dict(name=n,passed=v==0,residual=str(v)))
def ck(n,b,d=None):rows.append(dict(name=n,passed=bool(b),detail=d))
R,sigma,gamma,lam,eta,L,C,Q,Gcal=S.symbols('R sigma gamma radius_ratio eta L C Q Gcal',positive=True)
k,q=S.symbols('k q',positive=True)
fb=S.symbols('fb',positive=True)
Gbare=C/(8*S.pi*Q);Fbare=S.symbols('Fbare',positive=True)
eq('measured_normalization_conversion',Fbare*Gbare/Gcal-Fbare/(Gcal/Gbare))
charge=R*sigma**S.Rational(4,3)
bare=3*lam**2/(2*charge)
measured=bare/gamma
eq('same_background_principal_ceiling',measured.subs(gamma,S.Rational(4,3)*(1+eta))-9*lam**2/(8*R*sigma**S.Rational(4,3)*(1+eta)))
threshold=S.Rational(8,9)*R*sigma**S.Rational(4,3)*(1+eta)*L
eq('radius_budget_boundary',measured.subs(gamma,S.Rational(4,3)*(1+eta)).subs(lam,S.sqrt(threshold))-L)
Ccrit=2*R*sigma**S.Rational(4,3)*(1+eta)*(1+k)*L*lam**2/3
local=measured.subs(gamma,(1+eta)*(1+k)/C)
eq('arbitrary_background_C_budget',local-3*C*lam**2/(2*R*sigma**S.Rational(4,3)*(1+eta)*(1+k)))
eq('Ccrit_boundary',local.subs(C,Ccrit)-L)
eq('Ccrit_positive_slack',local.subs(C,Ccrit+S.Symbol('h',positive=True))-L-3*S.Symbol('h',positive=True)*lam**2/(2*R*sigma**S.Rational(4,3)*(1+eta)*(1+k)))
Rpair=S.Rational(11,4)**S.Rational(1,3)
coef=S.Rational(9,8)/Rpair
eq('calibrated_coefficient_cube',coef**3-S.Rational(729,1408))
ck('measured_coefficient_below_one',S.Rational(729,1408)<1)
ck('bare_coefficient_above_one',S.Rational(27,22)>1)
# Positive explicit corners are exposed algebra controls, not real observations.
examples=[]
for kv,ev,sv,lv,nv in [(S.Rational(1,5),S.Rational(0),S.Rational(1),S.Rational(1,100),S.Rational(1)),(S.Rational(1,10),S.Rational(1,20),S.Rational(3,2),S.Rational(1,10),S.Rational(2)),(S.Rational(3,10),S.Rational(1,5),S.Rational(2),S.Rational(1),S.Rational(1))]:
 vals={k:kv,eta:ev,sigma:sv,L:lv,lam:nv,R:Rpair}
 cc=Ccrit.subs(vals);ccf=float(cc);examples.append(dict(k=str(kv),eta=str(ev),sigma=str(sv),target=str(lv),radius_ratio=str(nv),Ccrit=str(S.N(cc,20)),negative_u_floor_applies=ccf<1))
 eq('corner_Ccrit_saturation_'+str(len(examples)),local.subs(C,Ccrit).subs(vals)-lv)
# The calibration dependency supplies U0 monotonicity on0<C<1. These
# controls only check substitution and domain gates, not a new proof of it.
a,ss,nu=S.symbols('a s nu',positive=True)
U0=S.Rational(3,2)+S.Rational(3,2)*ss*(1-C)**2+nu*(1+ss-ss*C)**2*S.log(C/(1+ss-ss*C))**2/(8*a*(1+ss))
eq('potential_origin_floor',U0.subs(C,1)-S.Rational(3,2))
ck('domain_floor_not_claimed_above_one',not (0<S.Rational(5,4)<1))
result={'passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows),'checks':rows,'same_background_pair_coefficient':str(S.N(coef,25)),'synthetic_examples':examples,'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'New algebraic integration only; source calibration and negative-u monotonicity reused from checked dependency, no new body solution or empirical normalization.'}
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='checks'}));
for row in rows:
 if not row['passed']:print('FAILED',row)
sys.exit(bool(result['failed']))
