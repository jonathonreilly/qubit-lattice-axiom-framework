# Independent calibration integration derivation

Prepared before this unit's executable controls, 2026-10-14. Reviewer:
/root/scalar_energy_check. Scientific source author: /root. This is a focused
conditional algebra check, not a derivation of the underlying gas integrals,
bounce history, local body response, or empirical calibration.

## Inputs and their distinct provenance

The supplied finite-mass DERIVATION_v2 assumes a positive-temperature ideal
photon/pair bath with fixed physical mass, zero chemical potential and the
specified equilibrium endpoint definitions. It supplies

    D_i = rho_i a_i^4 = S_i^(4/3) G_i,
    0 < G_f/G_b <= R,      R^3 = 11/4,
    0 < f_b < 2/3,
    P_bare = r/(f_b zeta), r = exp(2N) > 0.

The stronger bounce cap contains (1+w_b); using w_b>=0 suffices here. The
strictness comes from a strict Einstein bounce, not from assuming that either
finite-temperature endpoint reaches an ideal infinite/cold limit. The supplied
proof requires the same total bath in f_b and zeta, positive kinetic metric,
other nonnegative enthalpy, and a regular later diagnostic event with Z != 0.
I do not independently recheck that proof in this unit.

The separate gravity DERIVATION_v2 and immutable independent seal supply the
locally frozen, weak nonrelativistic principal response

    G_pr = C(1+q)/(8 pi Q),     0 < q < 1/3,
    C_l(1+q_l) <= 1+k,        0 < k < 1/3,

and the negative-u potential formula and its strict monotonicity. A positive
self-adjoint nonnegative-mass frozen Yukawa extension has a force in
[G_bare,G_pr]. None of these are arbitrary finite-body, tachyonic, time-varying
or screening theorems. Only these gravity results are reused; the older
physical-turnaround theorem's m=1 or 2 bound is not an input to this new bounce
integration. Old science code is not rerun or imported.

## Entropy and calibration conversion

Let sigma=S_f/S_b>0 and h=sigma^(4/3). Dividing the endpoint identity gives
zeta=h G_f/G_b <= h R. Positivity and f_b<2/3 imply

    P_bare > A0,             A0 = 3r/(2Rh) > 0.

No sign or temperature ordering for N is needed for this inequality. N>=0 is
used later only to imply r>=1. Equilibrium at both endpoints supplies their
thermodynamic identities. The interval may leave equilibrium, but sigma is
then an additional endpoint input; an actual compatible gravitational and
matter evolution is still required. There is no entropy production law here.

The diagnostic is inversely proportional to its chosen positive gravitational
normalization. For gamma=G_cal/G_bare,c>0,

    F_cal = F_bare/gamma,     P_cal = P_bare/gamma > A0/gamma.

Thus the measured quantity is not obtained by multiplying by gamma. A ceiling
on G_cal without its positivity is insufficient for these divisions and
inequality directions. The source explicitly assumes positivity.

## Same-background bound and strict radius budget

Suppose eta>=0 is an independently justified relative-error ceiling, so
gamma <= (1+eta)(1+q) < 4(1+eta)/3. Then

    P_cal > 3A0/[4(1+eta)] = 9r/[8Rh(1+eta)].

To show strictness without relying on decimal rounding, let P_bare=A0+Delta,
Delta>0. Even at the largest admitted gamma for a given q,

    (A0+Delta)/[(1+eta)(1+q)] - 3A0/[4(1+eta)]
      = [A0(1-3q)+4Delta]/[4(1+eta)(1+q)] > 0.

If P_cal<=L with L>0, this implies the strict necessary condition

    r < (8/9) Rh(1+eta)L.

At N>=0, a right-hand side <=1 is impossible, including equality. If the
right-hand side is >1, N < (1/2) log[(8/9)Rh(1+eta)L] is necessary, not an
existence claim. Equivalently, for a freely allowed positive endpoint entropy
ratio, sigma > [9r/(8R(1+eta)L)]^(3/4). This is a budget, not a mechanism.

The exact cube comparisons are

    (3/(2R))^3 = 27/22 > 1,
    (9/(8R))^3 = 729/1408 < 1.

Consequently the bare statement P_bare>1 alone does not imply P_cal>1.
For example P_bare=6/5 and gamma=5/4, compatible with the abstract q=1/4
principal ceiling, give P_cal=24/25. This is only a counterexample to that
logical inference. It is not a gas/bounce solution: w_b, endpoint G values
and field histories may correlate, and the coarse inequality need not be
jointly sharp. A coefficient below one does not establish a physical escape.

For the joint target d<=epsilon and F_cal<=1+delta with d,F_cal>0,
L=epsilon(1+delta)>0 is a necessary product bound. Conversely P_cal<=L
does not imply both individual targets. E.g. epsilon=1/5, delta=0,
d=1/100 and F_cal=10 satisfy the product but fail the F target.

## Distinct-background bound and C threshold

With the same action constants and physical matter units in the calibration
and cosmic event, the global principal ceiling gives

    gamma <= (1+eta)(1+k)/C_c.

This is weaker than supplying an actual environment or connecting history.
Combining it with the strict lower bound gives

    P_cal > A0 C_c/[(1+eta)(1+k)].

Thus P_cal<=L necessarily implies

    0 < C_c < Ccrit,
    Ccrit = 2Rh(1+eta)(1+k)L/(3r).

Strictness survives a weak calibration ceiling because the bounce inequality
is strict. Equality C_c=Ccrit is inadmissible for this target. Increasing
entropy, error allowance, or target loosens this threshold; increasing r
tightens it. The corresponding necessary entropy budget is

    sigma > [3r C_c/(2R(1+eta)(1+k)L)]^(3/4).

No conclusion about a locally realized calibration state, the value of eta,
the selected cosmological state, or the existence of an interpolating history
follows. A nonpositive L is impossible because P_cal>0 and is not substituted
into the fractional-power budget formulas.

## Energy threshold and its boundary

The reused gravity proof gives, for finite 0<C<1,

    U0(C) = 3/2 + (3s/2)(1-C)^2
      + nu(1+s-sC)^2 log^2[C/(1+s-sC)]/[8a(1+s)],
    a=(1-k)(1+3k)/4, s=(1+k)/[k(1-3k)], nu>0.

U0 strictly decreases with C on this interval. The full potential has
nonnegative transverse additions; the positive scalar kinetic term gives
rho_phi,E/(2Q Hv^2)>=U>=U0(C_c). Therefore 0<Ccrit<1 and C_c<Ccrit yield

    rho_phi,E/(2Q Hv^2) >= U0(C_c) > U0(Ccrit) > 3/2.

This is a required energy cost, not a contradiction with an independently
established upper bound. It does not calibrate Q, Hv, k or nu.

At Ccrit=1 the threshold still implies C_c<1 and a strict energy >3/2.
However U0(C)->3/2 as C approaches one from below, so there is no uniform
positive excess over 3/2. The v1 wording 'Ccrit>=1 ... no such ... floor'
was imprecise at equality. Source v2 now distinguishes this case exactly.
For Ccrit>1, C_c=1 is allowed by the necessary threshold and can have vacuum
energy 3/2. The negative-u conclusion and U0(Ccrit) threshold floor do not
follow. If Ccrit lies beyond the finite-field coupling range, one must not
even substitute it into U0's real logarithm as if it were a physical C.

## What is new and what is not claimed

This independent work checks integration, positivity, normalization factors,
strictness, exact constants and boundary/scope logic. The old action and
gravity mathematics is reused by sealed identity; the finite-mass thermodynamic
and strict-bounce result is a supplied dependency, separately assigned to
another reviewer. The mathematical point at Ccrit=1 is corrected in source
v2 without changing equations. No actual measurement, empirical tolerance,
abundance calculation, body solution, entropy-production law, selected initial
state, completed thermal history, or all-history impossibility is established.
