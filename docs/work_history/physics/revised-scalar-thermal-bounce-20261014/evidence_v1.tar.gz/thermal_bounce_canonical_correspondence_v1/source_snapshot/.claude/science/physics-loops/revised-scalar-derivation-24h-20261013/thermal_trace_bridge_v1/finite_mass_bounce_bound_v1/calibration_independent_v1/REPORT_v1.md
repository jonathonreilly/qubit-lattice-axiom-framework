# Independent measured-calibration integration check

Reviewer: /root/scalar_energy_check. Direct scientific author: /root.
This is a focused conditional mathematics and source-correspondence check,
not a formal audit, grade, landing decision, or delegated scientific authorship.

The calibration, entropy, radius and scalar-energy inequalities in the final
addendum agree with the supplied inputs. The original wording at Ccrit=1
needed a narrow clarification: equality still forces C_c<1 and scalar energy
strictly above 3/2, although it supplies no uniform positive excess above that
vacuum value. The author preserved v1 and made precisely this clarification
in v2. No equations changed. No unresolved mathematical correction was found
within the checked integration scope.

The conclusion is conditional on the finite-mass thermodynamic/bounce result
supplied in DERIVATION_v2 and on the explicitly restricted calibration regime.
This unit does not independently establish the underlying gas integral theorem,
construct a thermal history, solve an environment or body response, or supply
a measured gravitational normalization or error ceiling.

## Sources and reused evidence

Eight live-source/snapshot pairs are listed in SOURCE_MANIFEST_v2.json. All
were verified byte-for-byte at the correspondence run and will be checked at
sealing. The principal source hashes are:

| Source | SHA256 |
| --- | --- |
| Original measured addendum v1 | `163b792cd3a299349165e4e5064794750782bc7014417da7a7b1b2765a783fc8` |
| Final measured addendum v2 | `f244ce056e951622f6c0149e78d791b78352c77d0d2f207e6535f3a0c1041920` |
| Supplied finite-mass DERIVATION_v2 | `356b3cdbc71d862223da2e6197f09eab816807afcf40bd17a3ec3335e8da6e23` |
| Reused gravity DERIVATION_v2 | `22f51459c09d50b17fa38967595cbf3c8d7608e6020c4720f9251648faa42bb8` |
| Reused independent gravity receipt | `c469038e0f353d01f0c311108900b6ebfc2972ab73bafa5f442ebe2edbe2065f` |
| Reused independent gravity report | `7667e5f40fbbfb714ee345425fa135aa998072bb9514daa71f088370c71c6c6c` |
| Reused independent gravity manifest | `bdbf747530e38256dd4ec8a2a4a66b4dc8d2cdba683724256b3eb32a343d0855` |

The gravity seal's 83 artifact hashes and sizes, exact 85-file inventory and
seven live-source/snapshot pairs were verified. Old mathematics code was neither
imported nor rerun. Its action-normalized weak-source coefficient, force cap,
global principal ceiling and negative-u potential theorem are reused by identity.
The old physical-turnaround theorem's m=1 or m=2 bound is not used as the new
bounce premise. REUSED_GRAVITY_SEAL_v1.json records that distinction.

The full measured addendum v1/v2, supplied finite-mass source v2, and gravity
source were read. No producer addendum checker or results, no finite-mass
checker/results, no unrelated trajectory or empirical data were inspected.
The separate underlying thermodynamic/bounce review remains the parent's
integration responsibility; its outcome is not represented as evidence in
this receipt. The saved PDG citation is not revalidated in this algebra unit.

## Independent derivation and exact scope

HAND_DERIVATION_v1.md was written before the new executable controls. A separate
SUPPLEMENT_DERIVATION_v1.md records the direct physical diagnostic normalization
and the concrete energy-floor extension counterexample before their executions.

At the final event, H_J=Z/A, rho_J=rho_E/A^4, kappa_J=kappa_E/A^2 and
G_bare=A^2/(8 pi Q). Consequently d_J=kappa_E/Z^2 and
F_bare=3Q Z^2/rho_E. Replacing G_bare by gamma G_bare divides F and its
product with d_J by gamma. This independently checks the direction of the
measured conversion from physical definitions; it never identifies the bare
coefficient with an actual measured G.

Let r=exp(2N)>0, sigma=S_f/S_b>0 and R=(11/4)^(1/3). The supplied endpoint
identities give zeta=sigma^(4/3)G_f/G_b<=R sigma^(4/3). With the strict bounce
cap f_b<2/3 and the same total bath at both endpoints,

    P_bare = r/(f_b zeta) > 3r/[2R sigma^(4/3)].

The endpoint product follows directly from kappa_f=kappa_b/r and
rho_E,f=zeta rho_E,b/r^2. The strictness follows from the strict bounce
condition even when the weaker, non-strict thermodynamic endpoint bound is
used. Finite-temperature endpoints need not saturate that bound. Positive
G_cal and gamma permit division without reversing the inequality.

For a same-background ceiling gamma<=(1+eta)(1+q), q<1/3 and eta>=0,

    P_cal > 9r/[8R sigma^(4/3)(1+eta)].

The exact positive remainder when P_bare=A0+Delta, Delta>0, is

    [A0(1-3q)+4Delta]/[4(1+eta)(1+q)] > 0.

Thus a positive product target P_cal<=L necessarily requires the strict
radius budget

    r < (8/9)R sigma^(4/3)(1+eta)L.

For N>=0, a right-hand side <=1 makes that target impossible, including the
equality boundary. Otherwise it is merely a necessary inequality. The same
rearrangement gives the necessary entropy budget
sigma>[9r/(8R(1+eta)L)]^(3/4). The algebra allows any positive endpoint ratio;
an entropy increase, decrease, or production mechanism is not derived by
assigning it a value. Isolation plus reversible equilibrium recovers sigma=1.

The exact cubes are 27/22 for the bare coefficient and 729/1408 for the
same-background calibrated coefficient. Their display values are approximately
1.070648783255412 and 0.802986587441559. Hence P_bare>1 alone does not imply
P_cal>1. The rational tuple P_bare=6/5, gamma=5/4 gives P_cal=24/25 and
demonstrates that logical limitation. It is not an actual bounce solution.
The coarse bounce and thermal bounds need not be jointly sharp: the bounce
equation of state and endpoint G values can correlate. A coefficient below
one is not evidence that a full thermal history escapes the target.

For a distinct finite calibration background, the reused global ceiling gives
gamma<=(1+eta)(1+k)/C_c. Therefore

    P_cal > 3r C_c/[2R sigma^(4/3)(1+eta)(1+k)]

and a positive target requires

    C_c < Ccrit = 2R sigma^(4/3)(1+eta)(1+k)L/(3r).

Both the direction and strictness are correct. The threshold increases with
entropy allowance, eta, k and L, and decreases with r. Equality is rejected
even if the calibration saturates its weak ceiling. This is not a construction
of either background or a history joining them.

For 0<Ccrit<1, the reused potential theorem and positive kinetic/transverse
energies give

    rho_phi,E/(2Q Hv^2) >= U0(C_c) > U0(Ccrit) > 3/2.

The full U0 formula in the addendum matches the checked gravity source, with
only the algebraically identical typography (3s/2) versus (3/2)s. The error
ceiling and measured-to-bare conversion remain separate physical inputs.

At Ccrit=1, C_c<1 still gives energy>3/2. For fixed admissible k and nu,
U0(C) tends continuously to 3/2 as C approaches one, including its squared-log
term; thus no uniform positive excess is obtained. At Ccrit>1, the necessary
threshold admits C_c=1 and does not force a negative-u point. A concrete
counterexample to extending the threshold floor is k=1/5, s=15,
Ccrit=31/30 and C_c=1. The threshold lies inside the physical coupling range
0<C<16/15, but U0(Ccrit)>=3/2+1/40 while the vacuum value is 3/2.
The real logarithm is well defined. This falsifies the extended implication,
not a claim about a realized bouncing vacuum history. Beyond the physical
coupling range, substituting Ccrit into the real potential formula would be
an additional domain error.

## Executed controls and full failure history

The executable environment was Python 3.12.8 and SymPy 1.14.0. Exact rationals
and symbolic identities determine pass/fail; the displayed decimal constants
are not evidence for a universal inequality. All scripts import no producer
module. The only dynamic module load is this reviewer's own fresh implementation
and its preserved damaged copy in the supplementary counterexample check.

| Execution | Actual result |
| --- | --- |
| Independent algebra/strict-domain baseline | 56 passed, 0 failed |
| Source correspondence, endpoint definitions and reused seal identity | 24 passed, 0 failed |
| Additional concrete energy-implication baseline | 1 passed, 0 failed |
| Eight distinct actual changed-formula copies | All exited 1 and failed their predeclared mathematical/domain witness |
| Same energy-floor damaged copy, additional semantic counterexample | 0 passed, 1 failed; expected rejection |

The 24 correspondence checks include byte identity and bookkeeping as well as
the five direct endpoint definitions; they are not labeled as 24 new scientific
theorems. The additional damaged run is a second witness for one existing
mutation, not a ninth distinct changed implementation. There was no unexpected
baseline failure, repair, or hidden retry in this new unit. The v1 source
boundary issue is preserved separately from executable failures.

The eight actual damages were: multiplication by gamma; entropy power 1;
omitting the factor 3/4; admitting equality at the radius boundary; replacing
(1+k) by its reciprocal in Ccrit; reversing the factor of r in Ccrit;
reversing C_c<Ccrit; and extending the positive energy-gap classification
above Ccrit=1. Full changed sources, exact diffs, stdout, stderr, exit codes,
code hashes and failed-witness names are retained. No damage is merely a
description or a manually fabricated expected output. The superunit damage
also fails the concrete false requirement 3/2>3/2+1/40.

EXECUTION_RESULTS_v1.json, SUPPLEMENT_RESULTS_v1.json, COMMAND_INDEX_v1.json
and FAILURE_LEDGER_v1.json link the exact actual run history. Normal assertion
failures in altered equations are expected adversarial evidence, not source
failures. Both original and corrected source wording remain snapshotted.

## Applicability limits that survive

The finite-mass input is the stated total equilibrium electromagnetic bath,
not photon-only radiation or an arbitrary set of extra species. The bounce
assumptions, same-component endpoint definitions, regular final Z, positive
normalizations, and common physical units remain required. Only the
N>=0 corollary uses radius ordering. The integration does not require an
unjustified epsilon<=1 restriction; its positive product target L is sufficient.

The response theorem concerns the stated weak, locally frozen nonrelativistic
principal regime, or a separately conditional constant positive-metric,
nonnegative self-adjoint mass Yukawa model. The source does not assert this for
arbitrary bodies, unstable modes, unknown boundary modes, varying environments
or nonlinear screening. Eta is independently supplied, not calculated here.

A product target is necessary for the two individual inequalities, not
sufficient. An explicit countertuple satisfies the product while failing the
individual expansion target. A scalar-energy floor is a necessary cost and
not a contradiction without an independent upper bound. No source chooses
k, nu, Hv, the entropy ratio, a matter abundance, a local environment or an
initial state. There is no new full-body solution, reaction network,
primordial-abundance comparison, measured-gravity completion, empirical
exclusion or all-history claim.

Only the designated calibration_independent_v1 directory was written. Parent
science, prior sealed evidence, Git, PR, runtime/lock and audit state were not
changed. The final receipt filenames are REPORT_v1.md, MANIFEST_v1.json and
RECEIPT_v1.json; the manifest excludes only itself and the receipt, and the
receipt binds both the manifest and this report.
