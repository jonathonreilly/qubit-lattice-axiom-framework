# Direct diagnostic normalization and a concrete threshold-floor witness

This supplements the already executed independent algebra without replacing
HAND_DERIVATION_v1 or any baseline/mutation output. It supplies a direct
definition-to-product check and a second, mathematical witness for the existing
superunit-energy-floor damaged implementation.

At a regular endpoint let A>0, C=A^2, H_J=Z/A, rho_J=rho_E/A^4,
kappa_J=kappa_E/A^2 and G_bare=C/(8 pi Q). Then

    d_J = kappa_J/H_J^2 = kappa_E/Z^2,
    F_bare = H_J^2 / [(8 pi G_bare/3)rho_J]
           = 3Q Z^2/rho_E,
    d_J F_bare = 3Q kappa_E/rho_E.

Replacing G_bare by gamma G_bare divides F and the product by gamma.
This does not identify G_bare with a measurement. Let r=exp(2N), so
kappa_f=kappa_b/r and rho_E,f=zeta rho_E,b/r^2. Substitution gives
P_bare,f=r/(f_b zeta), f_b=rho_E,b/(3Q kappa_b). This is endpoint kinematics,
not a reconstruction of the finite-mass thermodynamics or bounce evolution.

For the previously used strict-threshold counterexample choose k=1/5, giving
s=15 and physical coupling range 0<C<16/15. Let Ccrit=31/30 and C_c=1.
The strict necessary threshold C_c<Ccrit holds, and the vacuum energy is 3/2.
The reused U0 expression at the threshold has

    U0(Ccrit) >= 3/2 + (3s/2)(1-Ccrit)^2 = 3/2 + 1/40.

Its remaining term is nonnegative; its logarithm is real since
1+s-sCcrit=1/2>0. Thus asserting the negative-u threshold energy floor for
this Ccrit would require 3/2 > 3/2+1/40, an exact false statement. The
supplementary executable checks the semantic implication of the implementation's
energy classification on this concrete allowed threshold tuple. It is run
against both the unmodified checker and the already preserved damaged copy.
This is a counterexample to extending the necessary-threshold argument, not
a claim that a complete bouncing vacuum/thermal history meets the target.
