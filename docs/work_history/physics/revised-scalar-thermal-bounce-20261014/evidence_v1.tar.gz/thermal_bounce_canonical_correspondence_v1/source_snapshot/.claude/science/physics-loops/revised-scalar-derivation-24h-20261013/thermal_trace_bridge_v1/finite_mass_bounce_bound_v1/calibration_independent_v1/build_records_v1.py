#!/usr/bin/env python3
from pathlib import Path
import datetime
import hashlib
import json

ROOT = Path(__file__).resolve().parent
NOW = datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def put(name, data):
    with (ROOT / name).open("x") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


sources = json.loads((ROOT / "SOURCE_MANIFEST_v2.json").read_text())["sources"]
execution = json.loads((ROOT / "EXECUTION_RESULTS_v1.json").read_text())
supplement = json.loads((ROOT / "SUPPLEMENT_RESULTS_v1.json").read_text())
assert execution["baseline"]["pass_count"] == 56 and execution["baseline"]["fail_count"] == 0
assert all(x["expected_outcome_confirmed"] for x in execution["mutations"])
assert all(x["expected_outcome_confirmed"] for x in supplement)

put("ACCESS_AND_SCOPE_v1.json", {
    "created_utc": NOW,
    "independent_checker": "/root/scalar_energy_check",
    "scientific_author": "/root",
    "formal_audit": False,
    "formal_grade_assigned": False,
    "landing_authority": False,
    "write_root": str(ROOT),
    "source_inventory": "SOURCE_MANIFEST_v2.json",
    "full_hand_sources_read": [sources[i]["original_path"] for i in [0, 1, 2, 6]],
    "prior_gravity_report_read_and_seal_reused": True,
    "producer_addendum_or_thermo_code_or_outputs_accessed": False,
    "old_mathematics_code_imported_or_rerun": False,
    "old_artifacts_read_only_for_integrity_hashing": True,
    "new_empirical_data_or_external_network": False,
    "git_pr_runtime_lock_audit_mutations": False,
    "new_agents_or_other_chats": False,
    "supplied_dependency": "Finite-mass DERIVATION_v2 thermodynamic and strict-bounce theorem; not independently established by this integration unit",
    "reused_dependency": "Gravity source v2 and immutable receipt c469038e0f353d01f0c311108900b6ebfc2972ab73bafa5f442ebe2edbe2065f",
    "not_reused": "Old physical-turnaround m=1 or m=2 theorem is not the new bounce premise",
    "scope_limits": ["conditional positive measured-G ceiling", "same total bath and common physical units", "necessary target budgets only", "no claimed sharpness or constructed history", "no body solution, empirical normalization or error tolerance"]
})

finding = {
    "id": "Ccrit_equality_boundary",
    "original_source_sha256": sources[0]["sha256"],
    "finding": "The v1 Ccrit>=1 no-floor wording obscured the strict above-vacuum conclusion at equality. No uniform positive gap exists at Ccrit=1; Ccrit>1 does not force a negative-u state.",
    "status": "clarified_in_author_v2",
    "final_source_sha256": sources[6]["sha256"],
    "equations_changed": False,
    "independent_diff": "SOURCE_V1_V2_INDEPENDENT.diff",
    "original_and_final_preserved": True,
    "remaining_mathematical_correction_within_scope": None
}
put("FINDINGS_v1.json", {"created_utc": NOW, "findings": [finding], "unresolved_within_checked_scope": [], "no_claim_of_underlying_thermo_or_history_completion": True})

commands = []
for p in sorted(list((ROOT / "runs").glob("*/COMMAND_v1.json")) + list((ROOT / "mutations").glob("*/run_v1/COMMAND_v1.json"))):
    x = json.loads(p.read_text())
    commands.append({"record_path": str(p.relative_to(ROOT)), "record_sha256": sha(p), "argv": x["argv"], "cwd": x["cwd"], "exit_code": x["exit_code"], "pass_count": x["pass_count"], "fail_count": x["fail_count"], "expected_outcome_confirmed": x["expected_outcome_confirmed"]})
put("COMMAND_INDEX_v1.json", {"created_utc": NOW, "actual_checker_execution_count": len(commands), "commands": commands, "orchestrator_launch_records": [{"path": str(p.relative_to(ROOT)), "sha256": sha(p)} for p in [ROOT / "runs/LAUNCH_v1.json", ROOT / "runs/SUPPLEMENT_LAUNCH_v1.json"]], "bootstrap_note": "Source snapshot creation and handwritten-file edits were direct local tooling. All mathematical/identity script invocations have exact executable argv, cwd, hashes, stdout/stderr and exit records. No unrecorded mathematical trial run is claimed."})

failures = []
for row in execution["mutations"]:
    failures.append({"kind": "expected_actual_changed_equation_rejection", "mutation": row["mutation"], "command": "mutations/" + row["mutation"] + "/run_v1/COMMAND_v1.json", "exit_code": row["exit_code"], "failed_witnesses": row["failed_witnesses"], "expected_witness": row["expected_witness"], "stdout_sha256": row["stdout_sha256"], "stderr_sha256": row["stderr_sha256"]})
last = supplement[-1]
failures.append({"kind": "second_semantic_witness_for_existing_damage", "mutation": "superunit_energy_floor", "command": "runs/energy_semantic_damage_v1/COMMAND_v1.json", "exit_code": last["exit_code"], "failed_witnesses": last["failed_witnesses"], "expected_witness": last["expected_witness"], "stdout_sha256": last["stdout_sha256"], "stderr_sha256": last["stderr_sha256"]})
put("FAILURE_LEDGER_v1.json", {"created_utc": NOW, "unexpected_baseline_or_tool_failures": [], "unrecorded_retries": False, "science_source_findings": [finding], "actual_failed_executions": failures, "distinct_damaged_implementations": 8, "expected_failed_executions": 9, "note": "The ninth failure is an additional concrete implication check of the same preserved superunit-energy damaged copy. It is not a ninth distinct mutation."})

dispositions = []
for i, row in enumerate(sources):
    final = sources[6] if i == 0 else row
    kind = "preserved_original_boundary_wording_superseded_by_v2" if i == 0 else "final_addendum_checked" if i == 6 else "supplied_thermo_bounce_dependency_only" if i == 1 else "reused_gravity_science_by_seal_identity" if i == 2 else "immutable_reused_seal_bytes_verified" if i in [3, 4, 5] else "author_correction_record_bound"
    dispositions.append({"original_path": row["original_path"], "original_sha256": row["sha256"], "disposition": kind, "recovery": row["snapshot_path"], "final_path": final["original_path"], "final_sha256": final["sha256"]})
put("SOURCE_DISPOSITIONS_v1.json", {"created_utc": NOW, "original_dispositions": dispositions, "source_deletion_or_mutation_by_checker": False})
put("FINAL_SOURCE_IDENTITY_v1.json", {"created_utc": NOW, "final_addendum": sources[6], "original_addendum": sources[0], "supplied_finite_mass_dependency": sources[1], "reused_gravity_derivation": sources[2], "reused_gravity_receipt": sources[3], "source_v1_to_v2_only_boundary_prose": True, "equations_identical": True, "correspondence_output": "runs/correspondence_v1/stdout.json", "correspondence_output_sha256": sha(ROOT / "runs/correspondence_v1/stdout.json"), "all_eight_pairs_verified_at_correspondence_execution": True})
print(json.dumps({"created_records": 6, "checker_executions": len(commands), "expected_failed_executions": len(failures)}, indent=2))
