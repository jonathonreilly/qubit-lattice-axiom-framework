#!/usr/bin/env python3
"""Narrow source correspondence, direct definitions, and sealed dependency identity."""
from pathlib import Path
import hashlib
import json
import re
import sys

import sympy as sp

ROOT = Path(__file__).resolve().parent
SOURCES = ROOT / "sources"
MANIFEST = json.loads((ROOT / "SOURCE_MANIFEST_v2.json").read_text())
WORKTREE = Path(MANIFEST["worktree"])
checks = []


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def add(name, passed, detail=None):
    checks.append({"name": name, "passed": bool(passed), "detail": detail})


def compact(text):
    return re.sub(r"\s+", "", text)


def potential_block(text):
    block = text.split("U0(C)=", 1)[1].split("\n\n", 1)[0]
    block = re.sub(r"\(\d+\)\s*$", "", block).strip().rstrip(".")
    return compact(block)


def main():
    for row in MANIFEST["sources"]:
        source, snap = WORKTREE / row["original_path"], ROOT / row["snapshot_path"]
        add("source.identity." + row["snapshot_path"], source.stat().st_size == snap.stat().st_size == row["bytes"] and digest(source) == digest(snap) == row["sha256"])
    v1 = (SOURCES / "01_MEASURED_CALIBRATION_ADDENDUM_v1.md").read_text()
    v2 = (SOURCES / "07_MEASURED_CALIBRATION_ADDENDUM_v2.md").read_text()
    before = "upper bound or a contradiction. If Ccrit>=1, this argument gives no such\nnegative-u energy floor. The choice of k,nu,Hv and an entropy source remains"
    after = "upper bound or a contradiction. If Ccrit=1, the strict C_c<1 still gives\nenergy strictly above3/2, but no uniform positive excess above the vacuum\nfloor is supplied. If Ccrit>1, this argument forces neither C_c<1 nor that\nnegative-u threshold floor. The choice of k,nu,Hv and an entropy source remains"
    add("correspondence.only_boundary_prose_changed", v1.count(before) == 1 and v1.replace(before, after) == v2)
    equations1 = re.findall(r"^    .*", v1, flags=re.M)
    equations2 = re.findall(r"^    .*", v2, flags=re.M)
    add("correspondence.all_displayed_equation_lines_identical", equations1 == equations2, {"line_count": len(equations1)})
    qualification = json.loads((SOURCES / "08_CALIBRATION_BOUNDARY_QUALIFICATION_v2.json").read_text())
    add("correspondence.author_qualification_hashes", qualification["original_sha256"] == hashlib.sha256(v1.encode()).hexdigest() and qualification["final_sha256"] == hashlib.sha256(v2.encode()).hexdigest())

    gravity = (SOURCES / "03_DERIVATION_v2.md").read_text()
    finite = (SOURCES / "02_DERIVATION_v2.md").read_text()
    add("dependency.U0_formula_same", potential_block(gravity) == potential_block(v2).replace("(3s/2)", "(3/2)s"))
    add("dependency.distinct_calibration_ceiling_same", "gamma<=(1+eta)(1+k)/C_c" in compact(gravity) and "gamma<=(1+eta)(1+k)/C_c" in compact(v2))
    add("dependency.finite_mass_inputs_explicit", all(x in compact(finite) for x in ["D=S^(4/3)G(T)", "1/R<=zeta=D_f/D_b<=R", "f_B,b=rho_B,b/(3Qkappa_b)<2/[3(1+w_B,b)]<=2/3"]))
    add("dependency.positive_calibration_and_same_bath_explicit", "actuallychosenpositivemeasurednormalization" in compact(v2) and "sametotal-bathdiagnostic" in compact(v2))

    # Independent endpoint definitions, not the producer's implemented formulas.
    A, Z, Qg, rho, kappa, gamma, rr, zet, rhob, kappab = sp.symbols("A Z Q rho kappa gamma r zeta rho_b kappa_b", positive=True)
    hj2, rhoj, kappaj = Z ** 2 / A ** 2, rho / A ** 4, kappa / A ** 2
    gbare = A ** 2 / (8 * sp.pi * Qg)
    d = kappaj / hj2
    fb = hj2 / ((8 * sp.pi * gbare / 3) * rhoj)
    fc = hj2 / ((8 * sp.pi * gamma * gbare / 3) * rhoj)
    add("definitions.d_J", sp.simplify(d - kappa / Z ** 2) == 0)
    add("definitions.F_bare", sp.simplify(fb - 3 * Qg * Z ** 2 / rho) == 0)
    add("definitions.F_cal_divides_by_gamma", sp.simplify(fc - fb / gamma) == 0)
    add("definitions.product", sp.simplify(d * fb - 3 * Qg * kappa / rho) == 0)
    endpoint = (d * fb).subs({kappa: kappab / rr, rho: zet * rhob / rr ** 2})
    f_b = rhob / (3 * Qg * kappab)
    add("definitions.endpoint_product", sp.simplify(endpoint - rr / (f_b * zet)) == 0)

    # Byte-only verification: no historical checker is executed or imported.
    reuse = json.loads((ROOT / "REUSED_GRAVITY_SEAL_v1.json").read_text())
    old = Path(reuse["root"])
    oldmanifest = json.loads((SOURCES / "06_MANIFEST_v1.json").read_text())
    oldreceipt = json.loads((SOURCES / "04_RECEIPT_v1.json").read_text())
    artifacts = oldmanifest["artifacts"]
    artifact_failures = [row["path"] for row in artifacts if (old / row["path"]).stat().st_size != row["bytes"] or digest(old / row["path"]) != row["sha256"]]
    add("reuse.all_83_artifact_hashes_and_sizes", len(artifacts) == 83 and not artifact_failures, artifact_failures)
    actual_inventory = {str(p.relative_to(old)) for p in old.rglob("*") if p.is_file()}
    expected_inventory = {x["path"] for x in artifacts} | set(oldmanifest["excludes"])
    add("reuse.exact_85_file_inventory", actual_inventory == expected_inventory and len(actual_inventory) == 85)
    add("reuse.receipt_report_manifest_hashes", all(digest(old / name) == sha for name, sha in reuse["receipt_report_manifest_hashes"].items()))
    pairs = oldreceipt["source_bindings"]
    old_pairs_ok = all((WORKTREE / x["original_path"]).stat().st_size == (old / x["snapshot_path"]).stat().st_size == x["bytes"] and digest(WORKTREE / x["original_path"]) == digest(old / x["snapshot_path"]) == x["sha256"] for x in pairs)
    add("reuse.all_seven_live_source_snapshot_pairs", len(pairs) == 7 and old_pairs_ok)

    result = {"pass_count": sum(x["passed"] for x in checks), "fail_count": sum(not x["passed"] for x in checks), "checks": checks, "source_pair_count": len(MANIFEST["sources"]), "reused_artifact_count": len(artifacts), "reused_file_count": len(actual_inventory), "reused_source_pair_count": len(pairs), "old_science_execution_or_import": False}
    print(json.dumps(result, indent=2))
    return int(result["fail_count"] != 0)


if __name__ == "__main__":
    sys.exit(main())
