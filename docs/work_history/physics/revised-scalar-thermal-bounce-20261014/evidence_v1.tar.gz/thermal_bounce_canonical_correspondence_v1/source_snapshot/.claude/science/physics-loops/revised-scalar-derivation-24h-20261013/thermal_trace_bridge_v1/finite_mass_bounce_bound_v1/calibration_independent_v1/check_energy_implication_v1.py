#!/usr/bin/env python3
"""Use a concrete allowed vacuum to challenge the reviewer's floor classifier."""
import importlib.util
import json
from pathlib import Path
import sys

import sympy as sp

sys.dont_write_bytecode = True
script = Path(sys.argv[1]).resolve()
spec = importlib.util.spec_from_file_location("own_energy_implementation", script)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
Q = sp.Rational
threshold, c_actual = Q(31, 30), sp.Integer(1)
energy_actual, floor_lower = Q(3, 2), Q(3, 2) + Q(1, 40)
classification = module.energy_class(threshold)
imposes_floor = classification == "uniform_positive_gap" and c_actual < threshold
claim_true_on_countertuple = (not imposes_floor) or bool(energy_actual > floor_lower)
result = {
    "implementation": str(script),
    "classification": classification,
    "countertuple": {"k": "1/5", "s": "15", "Cmax": "16/15", "Ccrit": "31/30", "C_actual": "1", "energy_actual": "3/2", "U0_threshold_lower_bound": "3/2+1/40"},
    "claim_imposed": bool(imposes_floor),
    "pass_count": int(claim_true_on_countertuple),
    "fail_count": int(not claim_true_on_countertuple),
    "checks": [{"name": "energy.claim_consistent_with_allowed_vacuum_countertuple", "passed": bool(claim_true_on_countertuple)}],
    "scope": "Counterexample to an extended threshold implication; no bouncing vacuum history is claimed. Only the fresh reviewer implementation is loaded."
}
print(json.dumps(result, indent=2))
sys.exit(int(not claim_true_on_countertuple))
