#!/usr/bin/env python3
"""Execute this reviewer's checker and real changed-source copies, preserving all output."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save_json(path, value):
    with path.open("x") as f:
        json.dump(value, f, indent=2)
        f.write("\n")


def execute(script, folder, expected):
    folder.mkdir()
    argv = [sys.executable, "-B", str(script)]
    env = os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE="1", PYTHONHASHSEED="0")
    before = datetime.datetime.now(datetime.timezone.utc).isoformat()
    t0 = time.monotonic()
    proc = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True, timeout=60)
    elapsed = time.monotonic() - t0
    (folder / "stdout.json").write_bytes(proc.stdout)
    (folder / "stderr.txt").write_bytes(proc.stderr)
    try:
        parsed = json.loads(proc.stdout)
        failed = [x["name"] for x in parsed["checks"] if not x["passed"]]
        parse_error = None
    except Exception as exc:
        parsed = None
        failed = []
        parse_error = repr(exc)
    record = {
        "started_utc": before,
        "elapsed_seconds": elapsed,
        "argv": argv,
        "cwd": str(ROOT),
        "environment_overrides": {"PYTHONDONTWRITEBYTECODE": "1", "PYTHONHASHSEED": "0"},
        "script_relative": str(script.relative_to(ROOT)),
        "script_sha256": sha(script.read_bytes()),
        "hand_derivation_sha256": sha((ROOT / "HAND_DERIVATION_v1.md").read_bytes()),
        "protocol_sha256": sha((ROOT / "PROTOCOL_v1.json").read_bytes()),
        "stdout_sha256": sha(proc.stdout),
        "stderr_sha256": sha(proc.stderr),
        "exit_code": proc.returncode,
        "pass_count": parsed["pass_count"] if parsed else None,
        "fail_count": parsed["fail_count"] if parsed else None,
        "failed_witnesses": failed,
        "expected_witness": expected,
        "expected_outcome_confirmed": (proc.returncode == 0 and not failed and parsed is not None) if expected is None else (proc.returncode == 1 and expected in failed and parse_error is None),
        "parse_error": parse_error,
    }
    save_json(folder / "COMMAND_v1.json", record)
    return record


def main():
    base = ROOT / "check_integration_v1.py"
    text = base.read_text()
    baseline = execute(base, ROOT / "runs/baseline_v1", None)
    summary = {"baseline": baseline, "mutations": []}
    if not baseline["expected_outcome_confirmed"]:
        save_json(ROOT / "EXECUTION_RESULTS_v1.json", summary)
        print(json.dumps({"baseline_failed": baseline}, indent=2))
        return 1
    cases = [
        ("multiply_gamma", "return p_bare / gamma", "return p_bare * gamma", "calibration.inverse_normalization"),
        ("entropy_linear", "return sigma ** Q(4, 3)", "return sigma", "entropy.power_rational_sigma_8_over_27"),
        ("omit_three_quarters", "return Q(3, 4) * bare_floor(r, sigma) / (1 + eta)", "return bare_floor(r, sigma) / (1 + eta)", "same.coefficient_elimination"),
        ("radius_nonstrict", "return r < cap", "return r <= cap", "same.radius_equal_rejected"),
        ("inverse_one_plus_k", "return 2 * R * entropy_power(sigma) * (1 + eta) * (1 + k) * target / (3 * r)", "return 2 * R * entropy_power(sigma) * (1 + eta) * target / (3 * r * (1 + k))", "distinct.threshold_rearrangement"),
        ("radius_factor_reversed", "return 2 * R * entropy_power(sigma) * (1 + eta) * (1 + k) * target / (3 * r)", "return 2 * R * entropy_power(sigma) * (1 + eta) * (1 + k) * target * r / 3", "distinct.threshold_rearrangement"),
        ("reverse_C_inequality", "return c < threshold", "return c > threshold", "distinct.threshold_below_allowed"),
        ("superunit_energy_floor", 'return "no_negative_u_requirement"', 'return "uniform_positive_gap"', "energy.superunit_threshold_no_floor"),
    ]
    save_json(ROOT / "mutations/PROTOCOL_v1.json", {"baseline_sha256": sha(base.read_bytes()), "cases": [{"name": n, "original": a, "replacement": b, "expected_witness": w} for n, a, b, w in cases]})
    for name, old, new, witness in cases:
        assert text.count(old) == 1, (name, text.count(old))
        changed = text.replace(old, new)
        folder = ROOT / "mutations" / name
        folder.mkdir()
        script = folder / "damaged_check_v1.py"
        script.write_text(changed)
        diff = "".join(difflib.unified_diff(text.splitlines(True), changed.splitlines(True), fromfile="check_integration_v1.py", tofile=str(script.relative_to(ROOT))))
        (folder / "SOURCE_CHANGE.diff").write_text(diff)
        row = execute(script, folder / "run_v1", witness)
        row["mutation"] = name
        row["source_diff_sha256"] = sha(diff.encode())
        summary["mutations"].append(row)
    summary["all_expected_outcomes_confirmed"] = all(x["expected_outcome_confirmed"] for x in summary["mutations"])
    save_json(ROOT / "EXECUTION_RESULTS_v1.json", summary)
    print(json.dumps({"baseline": [baseline["pass_count"], baseline["fail_count"]], "mutations": [{"name": x["mutation"], "exit_code": x["exit_code"], "failed_witnesses": x["failed_witnesses"], "expected_outcome_confirmed": x["expected_outcome_confirmed"]} for x in summary["mutations"]]}, indent=2))
    return 0 if summary["all_expected_outcomes_confirmed"] else 1


if __name__ == "__main__":
    sys.exit(main())
