#!/usr/bin/env python3
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
rows = []
cases = [
    ("correspondence_v1", "check_correspondence_v1.py", [], 0, None),
    ("energy_semantic_baseline_v1", "check_energy_implication_v1.py", ["check_integration_v1.py"], 0, None),
    ("energy_semantic_damage_v1", "check_energy_implication_v1.py", ["mutations/superunit_energy_floor/damaged_check_v1.py"], 1, "energy.claim_consistent_with_allowed_vacuum_countertuple"),
]
for name, script, args, expected_exit, witness in cases:
    folder = root / "runs" / name
    folder.mkdir()
    paths = [root / script] + [root / x for x in args]
    argv = [sys.executable, "-B", *map(str, paths)]
    env = os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE="1", PYTHONHASHSEED="0")
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    proc = subprocess.run(argv, cwd=root, env=env, capture_output=True, timeout=60)
    elapsed = time.monotonic() - tick
    (folder / "stdout.json").write_bytes(proc.stdout)
    (folder / "stderr.txt").write_bytes(proc.stderr)
    try:
        parsed = json.loads(proc.stdout)
        failures = [x["name"] for x in parsed["checks"] if not x["passed"]]
        parse_error = None
    except Exception as exc:
        parsed = {}
        failures = []
        parse_error = repr(exc)
    row = {"started_utc": started, "elapsed_seconds": elapsed, "argv": argv, "cwd": str(root), "environment_overrides": {"PYTHONDONTWRITEBYTECODE": "1", "PYTHONHASHSEED": "0"}, "source_hashes": {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}, "stdout_sha256": hashlib.sha256(proc.stdout).hexdigest(), "stderr_sha256": hashlib.sha256(proc.stderr).hexdigest(), "exit_code": proc.returncode, "expected_exit": expected_exit, "expected_witness": witness, "failed_witnesses": failures, "pass_count": parsed.get("pass_count"), "fail_count": parsed.get("fail_count"), "parse_error": parse_error}
    row["expected_outcome_confirmed"] = proc.returncode == expected_exit and parse_error is None and (witness in failures if witness else not failures)
    with (folder / "COMMAND_v1.json").open("x") as f:
        json.dump(row, f, indent=2)
        f.write("\n")
    rows.append(row)
with (root / "SUPPLEMENT_RESULTS_v1.json").open("x") as f:
    json.dump(rows, f, indent=2)
    f.write("\n")
print(json.dumps(rows, indent=2))
sys.exit(0 if all(x["expected_outcome_confirmed"] for x in rows) else 1)
