#!/usr/bin/env python3
"""Independent exact controls for the calibration integration, not gas/action reruns.

Run by path. This file imports no project or producer module and reads no source
or result files. Every expected identity follows from HAND_DERIVATION_v1.md.
"""
import json
import sys
import traceback

import sympy as sp

Q = sp.Rational
R = sp.real_root(Q(11, 4), 3)


def calibrated_product(p_bare, gamma):
    return p_bare / gamma


def entropy_power(sigma):
    return sigma ** Q(4, 3)


def endpoint_charge_ratio(sigma, gf_over_gb):
    return entropy_power(sigma) * gf_over_gb


def bare_floor(r, sigma):
    return 3 * r / (2 * R * entropy_power(sigma))


def same_floor(r, sigma, eta):
    return Q(3, 4) * bare_floor(r, sigma) / (1 + eta)


def radius_cap(sigma, eta, target):
    return Q(8, 9) * R * entropy_power(sigma) * (1 + eta) * target


def radius_allowed(r, cap):
    return r <= cap


def ccrit(r, sigma, eta, k, target):
    return 2 * R * entropy_power(sigma) * (1 + eta) * (1 + k) * target / (3 * r)


def c_allowed(c, threshold):
    return c < threshold


def energy_class(threshold):
    if threshold <= 0:
        return "nonpositive_threshold_no_positive_C"
    if threshold < 1:
        return "uniform_positive_gap"
    if threshold == 1:
        return "strict_above_vacuum_no_uniform_gap"
    return "no_negative_u_requirement"


def same_entropy_budget(r, eta, target):
    return (9 * r / (8 * R * (1 + eta) * target)) ** Q(3, 4)


def distinct_entropy_budget(r, c, eta, k, target):
    return (3 * r * c / (2 * R * (1 + eta) * (1 + k) * target)) ** Q(3, 4)


checks = []


def record(name, condition, detail=""):
    try:
        value = condition() if callable(condition) else condition
        good = bool(value)
        row = {"name": name, "passed": good, "detail": str(detail)}
        if not good:
            row["actual"] = str(value)
    except Exception:
        row = {"name": name, "passed": False, "detail": str(detail),
               "exception": traceback.format_exc()}
    checks.append(row)


def zero(expr):
    return sp.simplify(expr) == 0


def positive(expr):
    return sp.simplify(expr).is_positive is True


def main():
    r, sigma, eta, target, c, k = sp.symbols("r sigma eta L C k", positive=True)
    gamma, pb, delta, a0 = sp.symbols("gamma P_bare Delta A0", positive=True)
    q = sp.symbols("q", positive=True)
    sf, sb, gf, gb = sp.symbols("S_f S_b G_f G_b", positive=True)

    # Independently start with the ratio of the two endpoint charge definitions.
    endpoint_direct = (sf ** Q(4, 3) * gf) / (sb ** Q(4, 3) * gb)
    record("entropy.endpoint_ratio", zero(endpoint_direct - endpoint_charge_ratio(sf / sb, gf / gb)))
    record("calibration.inverse_normalization", zero(calibrated_product(pb, gamma) * gamma - pb))
    record("calibration.rational_witness", calibrated_product(Q(6, 5), Q(5, 4)) == Q(24, 25))
    record("entropy.power_rational_sigma_8_over_27", entropy_power(Q(8, 27)) == Q(16, 81))
    record("entropy.power_rational_sigma_125_over_64", entropy_power(Q(125, 64)) == Q(625, 256))
    record("entropy.isolated_limit", endpoint_charge_ratio(sp.Integer(1), gf / gb) == gf / gb)

    # Exact denominator decomposition: 1/(f*zeta)-3/(2*R*h)>0 under the two inputs.
    # f=2/(3(1+d_f)), zeta=R*h/(1+d_z), d_f>0,d_z>=0.
    df, dz = sp.symbols("d_f d_z", positive=True)
    h = sigma ** Q(4, 3)
    f = 2 / (3 * (1 + df))
    zeta = R * h / (1 + dz)
    direct_pb = r / (f * zeta)
    expected_margin = 3 * r * (df + dz + df * dz) / (2 * R * h)
    record("bounce.strict_margin_identity", zero(direct_pb - bare_floor(r, sigma) - expected_margin))
    record("bounce.margin_positive", positive(expected_margin))
    record("bounce.strictness_even_weak_zeta_boundary", positive(expected_margin.subs(dz, 0)))

    # Eliminate the independent positive ceiling. Algebra uses q symbolically;
    # sign is then checked by q=(1-v)/3 with 0<v<1 (below).
    direct_same = calibrated_product(a0 + delta, (1 + eta) * (1 + q))
    margin = (a0 * (1 - 3 * q) + 4 * delta) / (4 * (1 + eta) * (1 + q))
    record("same.positive_margin_identity", zero(direct_same - 3 * a0 / (4 * (1 + eta)) - margin))
    v = sp.symbols("v", positive=True)
    numerator = sp.factor(sp.together(margin).as_numer_denom()[0])
    record("same.margin_numerator_positive_domain", positive(numerator.subs(q, (1 - v) / 3)))
    record("same.coefficient_elimination", zero(same_floor(r, sigma, eta) - bare_floor(r, sigma) / (Q(4, 3) * (1 + eta))))
    record("same.radius_rearrangement", zero(same_floor(r, sigma, eta).subs(r, radius_cap(sigma, eta, target)) - target))
    record("same.radius_below_allowed", radius_allowed(Q(7, 6), Q(4, 3)))
    record("same.radius_equal_rejected", not radius_allowed(Q(4, 3), Q(4, 3)))
    record("same.radius_above_rejected", not radius_allowed(Q(3, 2), Q(4, 3)))
    record("same.N_nonnegative_cap_one_rejected", not radius_allowed(sp.Integer(1), sp.Integer(1)))
    record("same.N_nonnegative_cap_below_one_rejected", not radius_allowed(sp.Integer(1), Q(9, 10)))
    record("same.negative_N_is_not_prohibited_by_radius_order_argument", radius_allowed(Q(1, 2), Q(3, 4)))

    # Exact algebraic constants; no decimal comparison or parameter sweep proves them.
    record("constant.bare_cube", zero((3 / (2 * R)) ** 3 - Q(27, 22)))
    record("constant.calibrated_cube", zero((9 / (8 * R)) ** 3 - Q(729, 1408)))
    record("constant.bare_above_one", positive(Q(27, 22) - 1))
    record("constant.calibrated_below_one", positive(1 - Q(729, 1408)))
    record("scope.bare_only_does_not_imply_measured", Q(6, 5) > 1 and Q(5, 4) < Q(4, 3) and calibrated_product(Q(6, 5), Q(5, 4)) < 1)
    record("scope.product_does_not_imply_joint_target", Q(1, 100) * 10 <= Q(1, 5) and 10 > 1)

    # Distinct calibration: direct ceiling substitution, then solve its threshold.
    gmax = (1 + eta) * (1 + k) / c
    direct_distinct = calibrated_product(bare_floor(r, sigma), gmax)
    record("distinct.ceiling_elimination", zero(direct_distinct - 3 * r * c / (2 * R * sigma ** Q(4, 3) * (1 + eta) * (1 + k))))
    record("distinct.threshold_rearrangement", zero(direct_distinct.subs(c, ccrit(r, sigma, eta, k, target)) - target))
    record("distinct.threshold_below_allowed", c_allowed(Q(1, 3), Q(1, 2)))
    record("distinct.threshold_equal_rejected", not c_allowed(Q(1, 2), Q(1, 2)))
    record("distinct.threshold_above_rejected", not c_allowed(Q(2, 3), Q(1, 2)))
    record("distinct.decreases_with_radius_ratio", positive(-sp.diff(ccrit(r, sigma, eta, k, target), r)))
    record("distinct.increases_with_entropy", positive(sp.diff(ccrit(r, sigma, eta, k, target), sigma)))
    record("distinct.increases_with_error_allowance", positive(sp.diff(ccrit(r, sigma, eta, k, target), eta)))
    record("distinct.increases_with_target", positive(sp.diff(ccrit(r, sigma, eta, k, target), target)))
    record("distinct.increases_with_k", positive(sp.diff(ccrit(r, sigma, eta, k, target), k)))

    # Independent exact corner tuples. Algebraic R cancels by construction of L;
    # synthetic tuples do not assert a physical thermal or field history.
    tuples = [
        (Q(1), Q(1), Q(0), Q(1, 9), Q(1, 2)),
        (Q(9, 4), Q(8, 27), Q(1, 6), Q(2, 11), Q(2, 5)),
        (Q(1, 4), Q(125, 64), Q(3, 5), Q(3, 10), Q(4, 5)),
    ]
    for i, (rr, ss, ee, kk, cc) in enumerate(tuples, 1):
        ll = 3 * rr * cc / (2 * R * ss ** Q(4, 3) * (1 + ee) * (1 + kk))
        record(f"corner.{i}.threshold_exact", zero(ccrit(rr, ss, ee, kk, ll) - cc))
        # P_bare strictly larger, so the target is violated at C=Ccrit even
        # when the calibration attains its weak upper bound.
        actual = calibrated_product(3 * rr / (2 * R * ss ** Q(4, 3)) + Q(1, 7), (1 + ee) * (1 + kk) / cc)
        record(f"corner.{i}.strict_target_failure_at_boundary", positive(actual - ll))

    # Fractional inversion checked by choosing an exact positive sigma first.
    ss = Q(8, 27)
    rr, ee, kk, cc = Q(5, 3), Q(2, 9), Q(1, 6), Q(3, 7)
    ls = 9 * rr / (8 * R * ss ** Q(4, 3) * (1 + ee))
    ld = 3 * rr * cc / (2 * R * ss ** Q(4, 3) * (1 + ee) * (1 + kk))
    record("entropy.same_inverse_boundary", zero(same_entropy_budget(rr, ee, ls) - ss))
    record("entropy.distinct_inverse_boundary", zero(distinct_entropy_budget(rr, cc, ee, kk, ld) - ss))
    record("entropy.same_below_budget_violates_target", positive(same_floor(rr, ss / 8, ee) - ls))
    record("entropy.distinct_below_budget_violates_target", positive(3 * rr * cc / (2 * R * (ss / 8) ** Q(4, 3) * (1 + ee) * (1 + kk)) - ld))

    # These are integration-domain controls using the already proved potential
    # properties; no differentiation or action-to-potential rerun is performed.
    record("energy.subunit_threshold_has_gap", energy_class(Q(3, 5)) == "uniform_positive_gap")
    record("energy.unit_threshold_has_no_uniform_gap", energy_class(sp.Integer(1)) == "strict_above_vacuum_no_uniform_gap")
    record("energy.superunit_threshold_no_floor", energy_class(Q(31, 30)) == "no_negative_u_requirement")
    record("energy.nonpositive_threshold_no_positive_C", energy_class(sp.Integer(0)) == "nonpositive_threshold_no_positive_C")
    # A concrete safe-domain extension counterwitness: k=1/5 gives s=15 and
    # Cmax=16/15. Ccrit=31/30 is physical, but C_c=1 is admitted by C_c<Ccrit.
    # U0(Ccrit)-3/2 >= (3s/2)(1-Ccrit)^2=1/40, whereas U0(1)=3/2.
    s = sp.Integer(15)
    ct = Q(31, 30)
    record("energy.superunit_counterwitness_C_domain", 1 < ct < (1 + s) / s)
    record("energy.superunit_counterwitness_vacuum_admitted", c_allowed(sp.Integer(1), ct))
    record("energy.superunit_counterwitness_positive_threshold_quadratic", Q(3, 2) * s * (1 - ct) ** 2 == Q(1, 40))
    # At equality Ccrit=1, the inherited continuity U0(C)->3/2 prevents a
    # uniform gap. The explicit nonnegative quadratic contribution also tends
    # to zero and cannot itself supply one.
    n = sp.symbols("n", positive=True)
    record("energy.unit_boundary_quadratic_gap_tends_zero", sp.limit(Q(3, 2) * s / n ** 2, n, sp.oo) == 0)

    # Positive model domains are essential, not arbitrary sign conventions.
    record("domain.nonpositive_target_impossible_for_positive_product", Q(1, 10) > 0 and not Q(1, 10) <= 0)
    record("domain.negative_gamma_would_invalidate_positive_diagnostic", calibrated_product(Q(6, 5), Q(-1)) < 0)
    record("domain.entropy_ratio_positive", entropy_power(Q(8, 27)) > 0)

    result = {
        "schema": "independent-calibration-integration-v1",
        "python": sys.version,
        "sympy": sp.__version__,
        "pass_count": sum(c["passed"] for c in checks),
        "fail_count": sum(not c["passed"] for c in checks),
        "checks": checks,
        "constant_display_only": {"R": str(sp.N(R, 30)), "bare_coefficient": str(sp.N(3 / (2 * R), 30)), "same_calibrated_coefficient": str(sp.N(9 / (8 * R), 30))},
        "scope": "Exact conditional integration; finite controls do not certify actual calibration, thermodynamic history, or joint sharpness of coarse bounds. Old gravity theorem reused without rerun."
    }
    print(json.dumps(result, indent=2))
    return int(result["fail_count"] != 0)


if __name__ == "__main__":
    sys.exit(main())
