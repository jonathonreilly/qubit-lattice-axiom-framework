#!/usr/bin/env python3
"""Identity-only final validation and new receipt creation. No science execution."""
from pathlib import Path
import datetime
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(name):
    return json.loads((ROOT / name).read_text())


def put(name, value):
    with (ROOT / name).open("x") as f:
        json.dump(value, f, indent=2)
        f.write("\n")


def ref(name):
    p = ROOT / name
    return {"path": name, "bytes": p.stat().st_size, "sha256": digest(p)}


def main():
    assert not (ROOT / "MANIFEST_v1.json").exists()
    assert not (ROOT / "RECEIPT_v1.json").exists()
    sources = read("SOURCE_MANIFEST_v2.json")
    worktree = Path(sources["worktree"])
    for x in sources["sources"]:
        a, b = worktree / x["original_path"], ROOT / x["snapshot_path"]
        assert a.stat().st_size == b.stat().st_size == x["bytes"]
        assert digest(a) == digest(b) == x["sha256"]
    oldinfo = read("REUSED_GRAVITY_SEAL_v1.json")
    oldroot = Path(oldinfo["root"])
    oldmanifest = read("sources/06_MANIFEST_v1.json")
    oldreceipt = read("sources/04_RECEIPT_v1.json")
    for row in oldmanifest["artifacts"]:
        p = oldroot / row["path"]
        assert p.stat().st_size == row["bytes"] and digest(p) == row["sha256"]
    oldinventory = {str(p.relative_to(oldroot)) for p in oldroot.rglob("*") if p.is_file()}
    assert oldinventory == {x["path"] for x in oldmanifest["artifacts"]} | set(oldmanifest["excludes"])
    for name, value in oldinfo["receipt_report_manifest_hashes"].items():
        assert digest(oldroot / name) == value
    for row in oldreceipt["source_bindings"]:
        a, b = worktree / row["original_path"], oldroot / row["snapshot_path"]
        assert a.stat().st_size == b.stat().st_size == row["bytes"]
        assert digest(a) == digest(b) == row["sha256"]

    command_index = read("COMMAND_INDEX_v1.json")
    for entry in command_index["commands"]:
        record_path = ROOT / entry["record_path"]
        assert digest(record_path) == entry["record_sha256"]
        row = json.loads(record_path.read_text())
        assert row["expected_outcome_confirmed"]
        assert digest(record_path.parent / "stdout.json") == row["stdout_sha256"]
        assert digest(record_path.parent / "stderr.txt") == row["stderr_sha256"]
        if "script_relative" in row:
            assert digest(ROOT / row["script_relative"]) == row["script_sha256"]
            assert digest(ROOT / "HAND_DERIVATION_v1.md") == row["hand_derivation_sha256"]
            assert digest(ROOT / "PROTOCOL_v1.json") == row["protocol_sha256"]
        else:
            for name, value in row["source_hashes"].items():
                assert digest(ROOT / name) == value
    for row in command_index["orchestrator_launch_records"]:
        assert digest(ROOT / row["path"]) == row["sha256"]
    execution = read("EXECUTION_RESULTS_v1.json")
    supplement = read("SUPPLEMENT_RESULTS_v1.json")
    assert (execution["baseline"]["pass_count"], execution["baseline"]["fail_count"]) == (56, 0)
    assert len(execution["mutations"]) == 8
    assert all(x["expected_outcome_confirmed"] for x in execution["mutations"])
    assert [(x["pass_count"], x["fail_count"]) for x in supplement] == [(24, 0), (1, 0), (0, 1)]
    assert all(x["expected_outcome_confirmed"] for x in supplement)
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    put("SEAL_INPUT_VALIDATION_v1.json", {
        "created_utc": now, "argv": [sys.executable, "-B", *sys.argv],
        "script_sha256": digest(Path(__file__).resolve()),
        "validation_only_no_mathematics_execution": True,
        "live_source_snapshot_pairs_verified": len(sources["sources"]),
        "old_gravity_artifacts_verified": len(oldmanifest["artifacts"]),
        "old_gravity_inventory_file_count": len(oldinventory),
        "old_gravity_live_source_pairs_verified": len(oldreceipt["source_bindings"]),
        "new_actual_checker_records_verified": len(command_index["commands"]),
        "unexpected_execution_failures": 0,
        "expected_changed_implementation_failed_executions": 9,
        "all_checks_completed_before_manifest_and_receipt_creation": True
    })
    artifacts = []
    for p in sorted(ROOT.rglob("*")):
        assert not p.is_symlink(), p
        if p.is_file():
            artifacts.append(ref(str(p.relative_to(ROOT))))
    put("MANIFEST_v1.json", {"schema": "independent-evidence-manifest-v1", "created_utc": now, "artifact_root": str(ROOT), "artifact_count": len(artifacts), "excludes": ["MANIFEST_v1.json", "RECEIPT_v1.json"], "artifacts": artifacts})
    final = sources["sources"][6]
    receipt = {
        "schema": "independent-focused-check-receipt-v1",
        "created_utc": now,
        "unit": "finite_mass_bounce_measured_calibration_integration",
        "scientific_author": "/root",
        "independent_checker": "/root/scalar_energy_check",
        "formal_audit": False, "formal_grade_assigned": False, "landing_authority": False,
        "final_source": final["original_path"], "final_source_sha256": final["sha256"],
        "original_source_sha256": sources["sources"][0]["sha256"],
        "source_bindings": sources["sources"], "source_pair_count": len(sources["sources"]),
        "manifest": ref("MANIFEST_v1.json"), "artifact_count": len(artifacts),
        "report": ref("REPORT_v1.md"), "hand_derivation": ref("HAND_DERIVATION_v1.md"),
        "supplement_derivation": ref("SUPPLEMENT_DERIVATION_v1.md"),
        "protocol": ref("PROTOCOL_v1.json"), "findings": ref("FINDINGS_v1.json"),
        "failure_ledger": ref("FAILURE_LEDGER_v1.json"), "command_index": ref("COMMAND_INDEX_v1.json"),
        "source_dispositions": ref("SOURCE_DISPOSITIONS_v1.json"),
        "original_dispositions": read("SOURCE_DISPOSITIONS_v1.json")["original_dispositions"],
        "access_and_scope": ref("ACCESS_AND_SCOPE_v1.json"),
        "final_source_identity": ref("FINAL_SOURCE_IDENTITY_v1.json"),
        "seal_validation": ref("SEAL_INPUT_VALIDATION_v1.json"),
        "baseline": {"passed": 56, "failed": 0, "command": ref("runs/baseline_v1/COMMAND_v1.json")},
        "correspondence": {"passed": 24, "failed": 0, "command": ref("runs/correspondence_v1/COMMAND_v1.json"), "includes_bookkeeping_not_24_new_science_theorems": True},
        "semantic_floor_witness": {"baseline_passed": 1, "baseline_failed": 0, "same_existing_damage_passed": 0, "same_existing_damage_failed": 1, "baseline_command": ref("runs/energy_semantic_baseline_v1/COMMAND_v1.json"), "damage_command": ref("runs/energy_semantic_damage_v1/COMMAND_v1.json")},
        "actual_damaged_implementations": 8,
        "actual_expected_failed_executions": 9,
        "unexpected_baseline_failures": 0,
        "mutations": [{"name": x["mutation"], "expected_witness": x["expected_witness"], "failed_witnesses": x["failed_witnesses"], "exit_code": x["exit_code"], "command": ref("mutations/" + x["mutation"] + "/run_v1/COMMAND_v1.json")} for x in execution["mutations"]],
        "reused_gravity_seal": {"receipt_sha256": oldinfo["receipt_report_manifest_hashes"]["RECEIPT_v1.json"], "artifacts_verified": 83, "files_verified": 85, "source_pairs_verified": 7, "mathematics_rerun": False},
        "supplied_finite_mass_dependency": {"path": sources["sources"][1]["original_path"], "sha256": sources["sources"][1]["sha256"], "underlying_thermo_and_bounce_mathematics_independently_rederived_here": False},
        "source_correction": {"equations_changed": False, "correction": "Ccrit=1 strict above-vacuum energy with no uniform positive gap; Ccrit>1 does not force negative-u", "v1_preserved": True, "v2_correspondence_checked": True},
        "checked_scope": ["physical endpoint diagnostic and inverse-G normalization", "entropy endpoint power and strict product bound", "same-background radius/entropy budgets and exact constants", "distinct-background Ccrit factors, domain, strictness and parameter directions", "energy-floor integration and equality/superunit boundary", "source v2 and reused seal identity"],
        "limits": ["conditional finite-mass theorem supplied separately", "conditional weak-source principal or positive-spectrum frozen Yukawa regime and positive measured-G ceiling", "same bath and common physical units required", "necessary bounds are not full-history, environment or body solutions", "coarse bound sharpness and real thermal escape not established", "no empirical calibration or error estimate, abundance likelihood or initial-state selector"]
    }
    put("RECEIPT_v1.json", receipt)
    print(json.dumps({"artifact_count": len(artifacts), "total_files": len(artifacts) + 2, "source_pairs": len(sources["sources"]), "report": ref("REPORT_v1.md"), "manifest": ref("MANIFEST_v1.json"), "receipt": ref("RECEIPT_v1.json")}, indent=2))


if __name__ == "__main__":
    main()
