from pathlib import Path
import json, sys, hashlib, math
import sympy as S
import numpy as np
from scipy.integrate import quad
from scipy.special import expit

out = Path(sys.argv[1])
assert not out.exists()
rows = []
def ck(name, passed, detail=None):
    rows.append(dict(name=name, passed=bool(passed), detail=detail))
def eq(name, expr):
    value = S.factor(S.simplify(expr))
    ck(name, value == 0, str(value))

rho, p, T, rhoT, H, a, Q, kap, kinetic, other, hd = S.symbols(
    'rho pressure T rhoT H a Q kappa kinetic other_enthalpy Hdot', positive=True)
s = (rho+p)/T
pT = s
sT = (rhoT+pT)/T-(rho+p)/T**2
eq('equilibrium_entropy_derivative', sT-rhoT/T)
tdot = -3*H*(rho+p)/rhoT
eq('isolation_implies_comoving_entropy', sT*tdot+3*H*s)
dlogG = rhoT/rho-S.Rational(4,3)*sT/s
eq('charge_monotonicity_identity', dlogG-rhoT*(3*p-rho)/(3*rho*(rho+p)))
eq('physical_charge_trace_rate', dlogG*tdot-H*(rho-3*p)/rho)
E, mom, mass = S.symbols('E momentum mass', positive=True)
eq('massive_trace_integrand', (mom**2*E-mom**4/E-mass**2*mom**2/E).subs(E,S.sqrt(mom**2+mass**2)))
w = S.symbols('w', nonnegative=True)
kap_at_bounce = hd+kinetic+(rho*(1+w)+other)/(2*Q)
margin = 3*Q*kap_at_bounce-rho*S.Rational(3,2)*(1+w)
eq('strict_bounce_margin', margin-3*Q*(hd+kinetic)-S.Rational(3,2)*other)
ck('strict_bounce_margin_positive', S.expand(margin).is_positive)
fbcap = 2/(3*(1+w))
eq('pressure_weakening_bound', S.Rational(2,3)-fbcap-2*w/(3*(1+w)))
fb, lam, zeta, rb, kb = S.symbols('fb radius_ratio zeta rhob kappab', positive=True)
eq('same_bath_endpoint_budget', (3*Q*(kb/lam**2)/(zeta*rb/lam**4)).subs(rb,3*Q*kb*fb)-lam**2/(fb*zeta))
gb, gf, Sb, Sf = S.symbols('gb gf Sb Sf', positive=True)
R = (S.Rational(11,4))**S.Rational(1,3)
coefficient = S.Rational(3,2)/R
eq('pair_bath_ratio_cube', R**3-S.Rational(11,4))
eq('coarse_bounce_coefficient_cube', coefficient**3-S.Rational(27,22))
ck('coefficient_strictly_above_one', S.Rational(27,22)>1)
eq('photon_bath_initial_fraction_consistency', S.Rational(4,11)*(S.Rational(11,4))**S.Rational(4,3)-R)
eps, delta, sigma = S.symbols('epsilon delta sigma', positive=True)
sigcrit = (3*lam**2/(2*R*eps*(1+delta)))**S.Rational(3,4)
eq('entropy_escape_threshold', (3*lam**2/(2*R*sigma**S.Rational(4,3))).subs(sigma,sigcrit)-eps*(1+delta))

# Actual finite-mass phase-space integration. The endpoint range is proved in
# the note; these numerical samples only check formula implementation.
pi = math.pi
def integral(fun):
    value, error = quad(fun, 0, np.inf, epsabs=2e-11, epsrel=2e-11, limit=300)
    return value, error
def gas(x):
    def vals(y):
        e=math.hypot(y,x); f=float(expit(-e))
        return e,f
    rr, er = integral(lambda y:y*y*vals(y)[0]*vals(y)[1])
    pp, ep = integral(lambda y:y**4/vals(y)[0]*vals(y)[1])
    tr, et = integral(lambda y:x*x*y*y/vals(y)[0]*vals(y)[1])
    cv, ec = integral(lambda y:y*y*vals(y)[0]**2*vals(y)[1]*(1-vals(y)[1]))
    r=pi*pi/15+2*rr/pi**2
    pressure=pi*pi/45+2*pp/(3*pi**2)
    return dict(x=float(x),r=r,p=pressure,trace=2*tr/pi**2,
                heat=4*pi*pi/15+2*cv/pi**2,
                G=r/(r+pressure)**(4/3),w=pressure/r,
                error_estimates=[er,ep,et,ec])

grid=[gas(float(x)) for x in np.geomspace(1e-3,100,61)]
def masslessG(g):
    rr=pi*pi*g/30
    return rr/(4*rr/3)**(4/3)
Ghot=masslessG(5.5); Gcold=masslessG(2)
for j,row in enumerate(grid):
    r,pressure,tr=row['r'],row['p'],row['trace']
    ck('finite_mass_trace_'+str(j),abs(r-3*pressure-tr)<2e-11*max(1,r),r-3*pressure-tr)
    ck('finite_mass_stress_domain_'+str(j),0<pressure<=r/3+3e-12 and tr>=0 and row['heat']>0)
    ck('finite_mass_charge_range_'+str(j),Ghot-3e-12<=row['G']<=Gcold+3e-12)
ck('charge_monotone_in_m_over_T',all(b['G']>=a['G']-3e-12 for a,b in zip(grid,grid[1:])))
ck('hot_endpoint_convergence',abs(grid[0]['G']/Ghot-1)<1e-6)
ck('cold_endpoint_convergence',abs(grid[-1]['G']/Gcold-1)<1e-12)
ck('endpoint_ratio_numerical',abs(Gcold/Ghot-float(R))<2e-15)

alternate=[]
for x in [0.001,0.03,0.3,1.0,3.0,10.0,100.0]:
    base=gas(x)
    # Independent energy-coordinate integral, e=x+z, dp/de=e/p.
    ir,er=integral(lambda z:(x+z)**2*math.sqrt(z*(z+2*x))*float(expit(-x-z)))
    ip,ep=integral(lambda z:(z*(z+2*x))**1.5*float(expit(-x-z)))
    ra=pi*pi/15+2*ir/pi**2; pa=pi*pi/45+2*ip/(3*pi**2)
    ck('energy_coordinate_rho_'+str(x),abs(ra-base['r'])<2e-10*max(1,abs(ra)))
    ck('energy_coordinate_pressure_'+str(x),abs(pa-base['p'])<2e-10*max(1,abs(pa)))
    # Differentiate dimensional rho(T),p(T) at fixed m=x and T=1.
    step=1e-4
    plus=gas(x/(1+step)); minus=gas(x/(1-step))
    dr=((1+step)**4*plus['r']-(1-step)**4*minus['r'])/(2*step)
    dp=((1+step)**4*plus['p']-(1-step)**4*minus['p'])/(2*step)
    ck('fixed_mass_heat_derivative_'+str(x),abs(dr/base['heat']-1)<3e-7,dr/base['heat']-1)
    ck('fixed_mass_pressure_entropy_'+str(x),abs(dp/(base['r']+base['p'])-1)<3e-7,dp/(base['r']+base['p'])-1)
    alternate.append(dict(x=x,r=ra,p=pa,quadrature_errors=[er,ep],rho_T_numeric=dr,p_T_numeric=dp))

result=dict(passed=sum(r['passed'] for r in rows),failed=sum(not r['passed'] for r in rows),
    checks=rows,grid=grid,alternate_quadrature=alternate,
    R=str(S.N(R,25)),bounce_coefficient=str(S.N(coefficient,25)),
    analytic_endpoint_G=[Ghot,Gcold],checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    scope='Exact conditional identities and finite-mass synthetic quadrature, no observed fit, no full background histories, no microscopic derivation of equilibrium or particle content.')
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['checks','grid','alternate_quadrature']}))
for row in rows:
    if not row['passed']: print('FAILED',row)
sys.exit(bool(result['failed']))
