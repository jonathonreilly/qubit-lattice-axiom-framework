# Independent hand proof before executable controls

This is a blind focused check of the supplied v1 derivation and protocol. No author checker, results, grids or other new-route outputs have been read. The complete action is frozen separately. The earlier slow-past seal is not used as a numerical oracle or rerun. The parent has acknowledged the target-denominator domain observation below and reports a later v2 prose clarification; its correspondence will be checked separately after this proof and the independent calculations are frozen.

## Finite-mass thermodynamics

With degeneracy g=4 and fixed physical mass m, the isotropic fermion stress is rho_F=g/(2pi^2) integral p^2 E f dp and p_F=g/(6pi^2) integral p^4 f/E dp. Adding two massless photon states gives the author's coefficients. The integral subtraction is rho_F-3p_F=g m^2/(2pi^2) integral p^2 f/E dp, strictly positive at finite m,T>0. Photon pressure is positive, so 0<p<rho/3 at finite m,T, with limiting radiation equations of state at either end.

At fixed p,m, d_T f=E f(1-f)/T^2 and d_p f=-p f(1-f)/(ET). Thus rho_T has the stated strictly positive photon-plus-fermion integrand. Pressure differentiation gives p_T,F=g/(6pi^2 T^2) integral p^4 f(1-f) dp. Integration by parts using d_p f turns this into g/(6pi^2 T) integral (3p^2 E+p^4/E) f dp=(rho_F+p_F)/T. Its boundary term p^3 E f vanishes at zero and infinity. Photon terms satisfy the same identity. Consequently s=(rho+p)/T, p_T=s and s_T=rho_T/T. All derivatives keep the physical mass and species definitions fixed; an Einstein mass m_E=A m must not be held fixed while pretending to take this physical derivative.

Physical isolation gives rho_T dot_J T=-3H_J(rho+p); dividing by T proves dot_J(s a_J^3)=0. Neither the entropy value nor equilibrium reaction rates follow. In particular H_E=0 is not the condition H_J=0 if A rolls. Equilibration is an adopted matter condition throughout the interval, not implied by the gravitational action or the word bounce.

For fixed S=s a_J^3, D=rho a_J^4=S^(4/3)G(T), G=rho/s^(4/3). Differentiating exactly gives

 d ln G/dT = rho_T/rho - 4rho_T/[3(rho+p)]
            =rho_T(3p-rho)/[3rho(rho+p)]<0.

There is no need to order the two temperatures or demand monotone physical expansion. Positivity and dominated convergence justify differentiation and the massive limiting integrals. The massless Bose integral is pi^4/15 and the Fermi integral is (1-2^-3)Gamma(4)zeta(4)=7pi^4/120. Hence rho/T^4 approaches (pi^2/30)g with g_hot=2+(7/8)4=11/2 and g_cold=2. Entropy becomes (4/3)(pi^2 g/30)T^3 at either end, so G=(3/4)^(4/3)(pi^2 g/30)^(-1/3) there. Thus G_cold/G_hot=(11/4)^(1/3)=R. For finite endpoint temperatures the bounds are strict; the source's weak [1/R,R] ratio range is conservative and sufficient.

## Action, frames and bounce normalization

The candidate action has -Q K_AB dphi^A dphi^B, without the conventional extra1/2. Its homogeneous kinetic energy and pressure contributions are both Qw_phi. Einstein variation therefore yields

 dot_E H_E=kappa-w_phi-(rho_B,E+p_B,E+rho_o+p_o)/(2Q).

At a strict Einstein bounce dot_E H_E>0, w_phi>=0 and other-matter enthalpy>=0 imply kappa_b>rho_B,b(1+w_B,b)/(2Q)>0 and f_B,b<2/[3(1+w_B,b)]<=2/3. The positive curvature is derived; no positive potential or Friedmann projection is needed for this local inequality. The potential and constraint still matter for existence of a full solution; an algebraically allowed local Raychaudhuri state is not an asserted thermal history.

Physical stresses transform as rho_E=A^4 rho_J, p_E=A^4 p_J, while a_J=A a_E and dt_J=A dt_E. Therefore D=rho_J a_J^4=rho_E a_E^4, w_B is unchanged and H_J=(H_E+dot_E ln A)/A=Z/A. The bare physical cosmological coefficient is Q/C in the R_J/2 convention. Thus the source's positive-curvature diagnostic is d_J=kappa/Z^2=-Omega_K and F_bare=3Q Z^2/rho_B,E. A physical expansion sign is not needed for this squared endpoint readout, but Z_f!=0 is required. The theorem is specifically about an Einstein bounce; it is not a generic Jordan-bounce theorem.

Let r_a=a_E,f/a_E,b=exp N and zeta=D_f/D_b. Direct kinematics gives rho_f/rho_b=zeta/r_a^4 and kappa_f/kappa_b=r_a^-2. Hence

 d_J,f F_bare,B,f=r_a^2/(f_B,b zeta)
   >3(1+w_B,b)r_a^2/(2R)>=3r_a^2/(2R).

The first inequality remains strict even at zeta=R. Since [3/(2R)]^3=27/22>1, N>=0 supplies the claimed >1 obstruction. N<0 does not: the coarse bound can fall below1 and no conclusion is supplied without a radius-ordering condition. No full monotone Einstein expansion between the two endpoints is necessary for this algebra.

The same total bath must be used in the bounce fraction, D and endpoint F. An instructive failure of a photon substitution is its hot-to-cold isolated-pair-annihilation charge ratio D_gamma,cold/D_gamma,hot=(11/4)^(4/3), versus R=(11/4)^(1/3) for the total bath. The factor11/4 difference is not a conformal effect; it is a component change. At finite m/T the photon-only entropy is not the conserved total entropy.

## Extension and escape domains

For a finite collection of noninteracting equilibrium species with fixed nonnegative masses, zero chemical potentials, common temperature and some massless species, each massive trace is nonnegative and every heat capacity is positive. The same argument gives R=(g_hot/g_cold)^(1/3). It needs stable ideal particle definitions, no condensate chemical potentials and the same isolated bath, as in the source. R<=3/2 suffices with N>=0, including equality because the bounce inequality is strict. R>3/2 only defeats this coarse estimate; it neither constructs a solution nor proves escape impossible. The stronger factor1+w_B,b can still constrain particular states.

If isolation is relaxed but the endpoint equilibrium definitions remain valid, sigma=S_f/S_b>0 gives zeta=sigma^(4/3)G_f/G_b<=sigma^(4/3)R. A proposed positive target product P=epsilon(1+delta)>0 requires

 sigma>[3 exp(2N)/(2 R P)]^(3/4).

Strictness is necessary: equality cannot achieve dF<=P. This is a necessary budget, not a production law, not sufficient for a trajectory, and not evidence that one can inject entropy without changing other relevant matter. If P<=0, dF>0 makes the target impossible and there is no finite formula obtained by dividing by P. The original source left that displayed domain implicit; I reported it to the author, who preserved v1 and reports a separate clarification. A meaningful near-flat target convention is epsilon>0,delta>=0. Any measured-G target also needs its calibration factor, independently of this budget.

## Intended checks and limits

Exact controls will cover the distribution derivatives, integration-by-parts algebra, thermodynamic G derivative, entropy/frame powers, massless weights and limiting ratio, strict bounce algebra, endpoint radius/charge identity, target positivity, and species/entropy boundary probes. Independent finite-mass quadrature will use off-grid dimensionless masses 0.007,0.11,0.6,1.3,2.9,6.7,14,24. Momentum quadrature will be compared with fixed-node rapidity integration at selected values. Exact identities establish the uniform bounds; numerical grids only check the implementation and evaluate the assumed gas.

Actual damaged scripts will change trace sign, entropy exponent, frame density power, endpoint radius exponent, bounce enthalpy coefficient, total/photon component, and the Fermi degeneracy. Every executed failure will be kept. No observation, reaction network, chosen entropy abundance, complete thermal history, measured-gravity calibration, perturbation stability, or quantum mechanism is derived by this focused check.
