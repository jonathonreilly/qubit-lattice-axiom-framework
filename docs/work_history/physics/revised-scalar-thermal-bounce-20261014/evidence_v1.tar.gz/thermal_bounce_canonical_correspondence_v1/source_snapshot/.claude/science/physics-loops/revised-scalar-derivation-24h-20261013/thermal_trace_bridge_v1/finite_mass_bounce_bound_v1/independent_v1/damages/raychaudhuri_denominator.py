"""Independent exact and finite-mass controls. No producer code imported."""
from pathlib import Path
from datetime import datetime, timezone
from functools import lru_cache
import hashlib, json, math, sys, warnings
import sympy as sp
import numpy as np
import scipy
from scipy.integrate import quad
from scipy.special import roots_legendre
TRACE_SIGN = 1
ENTROPY_POWER = sp.Rational(4, 3)
FRAME_POWER = 4
RADIUS_POWER = 2
RAY_DEN = 3
USE_TOTAL = True
FERMION_DEGENERACY = 4
rows=[]; evidence={}; numeric_warnings=[]
def check(name, okay, detail=None):
    rows.append({'name':name,'passed':bool(okay),'detail':detail})
def zero(name, expr):
    residual=sp.simplify(expr)
    check(name,residual==0,str(residual))
def near(name, actual, expected, tol=2e-10):
    gap=abs(actual-expected);scale=max(1.,abs(actual),abs(expected))
    check(name,math.isfinite(actual) and math.isfinite(expected) and gap<=tol*scale,{'actual':actual,'expected':expected,'absolute_gap':gap,'scaled_tolerance':tol*scale})
# Direct distribution derivatives, with physical m and momentum fixed.
p,m,T,g=sp.symbols('p m T g',positive=True)
energy=sp.sqrt(p*p+m*m);fd=1/(sp.exp(energy/T)+1)
zero('fixed_mass_temperature_derivative',sp.diff(fd,T)-energy*fd*(1-fd)/T**2)
zero('momentum_derivative',sp.diff(fd,p)+p*fd*(1-fd)/(energy*T))
zero('stress_trace_integrand',p*p*energy-3*p**4/(3*energy)-TRACE_SIGN*m*m*p*p/energy)
zero('pressure_integration_by_parts_weight',sp.diff(p**3*energy,p)-(3*p*p*energy+p**4/energy))
zero('pressure_IBP_lower_endpoint',sp.limit(p**3*energy*fd,p,0,dir='+'))
# Exponential tail dominates every fixed polynomial: the actual massless tail is an upper bound.
zero('pressure_IBP_upper_endpoint',sp.limit(p**4*sp.exp(-p/T),p,sp.oo))
rho,pressure,rhot=sp.symbols('rho pressure rhot',positive=True)
zero('entropy_temperature_identity',(rhot+(rho+pressure)/T)/T-(rho+pressure)/T**2-rhot/T)
Glog=rhot/rho-ENTROPY_POWER*rhot/(rho+pressure)
zero('G_temperature_identity',Glog-rhot*(3*pressure-rho)/(3*rho*(rho+pressure)))
H,aJ=sp.symbols('H aJ',real=True)
Tdot=-3*H*(rho+pressure)/rhot
zero('isolated_entropy_continuity',rhot*Tdot/T+3*H*(rho+pressure)/T)
S=sp.symbols('S',positive=True)
zero('fixed_entropy_charge_exponent',rho*(S/((rho+pressure)/T))**sp.Rational(4,3)-S**ENTROPY_POWER*rho/((rho+pressure)/T)**ENTROPY_POWER)
IB=sp.gamma(4)*sp.zeta(4);IF=(1-sp.Rational(1,8))*IB
zero('Bose_massless_integral',IB-sp.pi**4/15)
zero('Fermi_massless_integral',IF-7*sp.pi**4/120)
ghot=2+sp.Rational(7,8)*FERMION_DEGENERACY;gcold=sp.Integer(2)
zero('adopted_hot_species_weight',ghot-sp.Rational(11,2))
rhot_hot=2*IB/(2*sp.pi**2)+FERMION_DEGENERACY*IF/(2*sp.pi**2)
zero('adopted_hot_energy_coefficient',rhot_hot-11*sp.pi**2/60)
R=(ghot/gcold)**sp.Rational(1,3)
zero('total_charge_range_cubed',R**3-sp.Rational(11,4))
zero('coarse_bounce_coefficient_cubed',(sp.Rational(3,2)/R)**3-sp.Rational(27,22))
check('pair_coefficient_above_one',sp.Rational(27,22)>1)
Rphoton=(sp.Rational(11,4))**sp.Rational(4,3)
zero('photon_vs_total_charge_ratio',Rphoton/(sp.Rational(11,4))**sp.Rational(1,3)-sp.Rational(11,4))
check('photon_charge_range_is_larger',sp.simplify(Rphoton-R)>0)
# No half in the supplied scalar kinetic action.
Q,ws,V,rb,pb,ho,kappa=sp.symbols('Q ws V rb pb ho kappa',positive=True)
rhophi=Q*ws+V;pphi=Q*ws-V
ray_from_action=kappa-(rhophi+pphi+rb+pb+ho)/(2*Q)
ray_proposed=kappa-ws-(rb+pb+ho)/(RAY_DEN*Q)
zero('action_Raychaudhuri_normalization',ray_proposed-ray_from_action)
wb,eta=sp.symbols('wb eta',positive=True)
kb=ws+(rb*(1+wb)+ho)/(2*Q)+eta
fb=rb/(3*Q*kb)
cap=sp.Rational(RAY_DEN,3)/(1+wb)
true_slack=2*(2*Q*(ws+eta)+ho)/(3*(1+wb)*(2*Q*(ws+eta)+rb*(1+wb)+ho))
zero('strict_bounce_fraction_slack',cap-fb-true_slack)
check('strict_bounce_positive_slack',true_slack.is_positive)
check('strict_bounce_derives_positive_curvature',kb.is_positive)
# Conformal density, radius and clock conversions are checked before cancellation.
A,aE,rJ,H_E,Adot=sp.symbols('A aE rJ H_E Adot',positive=True)
rE=A**FRAME_POWER*rJ
zero('conformal_charge_invariance',rE*aE**4-rJ*(A*aE)**4)
zero('physical_clock_conversion',(Adot*aE+A*H_E*aE)/(A*A*aE)-(H_E+Adot/A)/A)
Z=sp.symbols('Z',nonzero=True,real=True)
dJ=kappa/Z**2;F=3*Q*Z**2/rE
zero('common_source_product',dJ*F-3*Q*kappa/rE)
zero('bare_physical_rate_normalization',3*(Q/A**2)*(Z/A)**2/rJ-3*Q*Z**2/(A**4*rJ))
ra,zeta,f,phib,phif=sp.symbols('ra zeta f phib phif',positive=True)
rhof=rb*zeta/ra**4;kf=rb/(3*Q*f*ra**2)
actual=3*Q*kf/rhof
zero('endpoint_radius_charge_identity',actual-ra**RADIUS_POWER/(f*zeta))
used_f=f if USE_TOTAL else phib*f
used_zeta=zeta if USE_TOTAL else zeta*phif/phib
zero('same_total_component_diagnostic',actual-ra**RADIUS_POWER/(used_f*used_zeta))
# Strictness and scope probes use exact supplied inequality variables, not histories.
for vv in [sp.Rational(1,12),sp.Rational(1,5),sp.Rational(1,3)]:
    for gap in [sp.Rational(1,9),sp.Rational(1,2)]:
        frac=2/(3*(1+vv))*(1-gap)
        for rad in [sp.Rational(1,2),sp.Integer(1),sp.Rational(5,3)]:
            product=rad**2/(frac*R)
            lower=3*(1+vv)*rad**2/(2*R)
            check('strict_endpoint_'+str((vv,gap,rad)),sp.simplify(product-lower)>0)
check('negative_N_not_covered_by_coarse_obstruction',sp.Rational(3,2)/R*sp.Rational(1,4)<1)
for ratio in [sp.Rational(8,1),sp.Rational(27,8),sp.Rational(2,1)]:
    rr=ratio**sp.Rational(1,3)
    coefficient=sp.Rational(3,2)/rr
    check('species_boundary_'+str(ratio),(coefficient>=1)==(ratio<=sp.Rational(27,8)))
Ptarget,sigma=sp.symbols('Ptarget sigma',positive=True)
threshold=(3*ra**2/(2*R*Ptarget))**(1/ENTROPY_POWER)
zero('entropy_escape_inverse_exponent',threshold**sp.Rational(4,3)-3*ra**2/(2*R*Ptarget))
zero('entropy_charge_ratio_power',sigma**ENTROPY_POWER-sigma**sp.Rational(4,3))
for target in [sp.Rational(1,10),sp.Integer(1),sp.Rational(3,2)]:
    sig0=(sp.Rational(3,2)/(R*target))**sp.Rational(3,4)
    zero('entropy_threshold_equality_'+str(target),3/(2*R*sig0**sp.Rational(4,3))-target)
    slack=sp.Symbol('strict_fraction_slack',positive=True)
    attained=1/((sp.Rational(2,3)/(1+slack))*R*sig0**sp.Rational(4,3))
    zero('actual_product_at_equal_budget_'+str(target),attained-target*(1+slack))
    check('equality_budget_excluded_by_strict_bounce_'+str(target),sp.simplify(attained-target).is_positive)
check('nonpositive_target_impossible',dJ.is_positive and F.is_positive)
d_at_zero=dJ.subs(Z,0);F_at_zero=F.subs(Z,0)
check('zero_endpoint_rate_diagnostic_undefined',d_at_zero==sp.zoo and F_at_zero==0 and d_at_zero*F_at_zero==sp.nan,{'d_at_zero':str(d_at_zero),'F_at_zero':str(F_at_zero),'uncancelled_product':str(d_at_zero*F_at_zero)})
evidence['domain_probes']={'target_positive_required_for_budget':True,'nonpositive_target':'impossible because dF>0','zero_Z':'d and F cannot be separately used at Z=0 even though their cancelled product has a continuous algebraic expression','negative_N':'coarse coefficient times exp(2N) need not exceed one','larger_species':'failure of this sufficient estimate does not construct escape'}
# Independent finite-mass quadrature. No parent grid or output is consulted.
pi=math.pi;deg=float(FERMION_DEGENERACY);ep=float(ENTROPY_POWER)
@lru_cache(maxsize=None)
def moments(x):
    def raw(y,kind):
        e=math.hypot(y,x);em=math.exp(-e);f0=em/(1+em)
        if kind=='r':return y*y*e*f0
        if kind=='p':return y**4*f0/e
        if kind=='trace':return x*x*y*y*f0/e
        if kind=='cv':return y*y*e*e*f0*(1-f0)
        if kind=='pt':return y**4*f0*(1-f0)
        raise ValueError(kind)
    vals={};errs={}
    for kind in ['r','p','trace','cv','pt']:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            value,error=quad(lambda y:raw(y,kind),0,np.inf,epsabs=2e-13,epsrel=2e-12,limit=300)
        for w in caught:numeric_warnings.append({'x':x,'moment':kind,'warning':str(w.message)})
        vals[kind]=value;errs[kind]=error
    rr=pi*pi/15+deg/(2*pi*pi)*vals['r'];pp=pi*pi/45+deg/(6*pi*pi)*vals['p']
    trace=TRACE_SIGN*deg/(2*pi*pi)*vals['trace']
    cv=4*pi*pi/15+deg/(2*pi*pi)*vals['cv'];pt=4*pi*pi/45+deg/(6*pi*pi)*vals['pt']
    GG=(1/x)**(4-3*ep)*rr/(rr+pp)**ep
    return {'x':x,'r':rr,'p':pp,'trace':trace,'cv':cv,'pT':pt,'G':GG,'errors':errs}

def rapidity(x,n):
    nodes,weights=roots_legendre(n)
    upper=math.acosh((x+80)/x);t=(nodes+1)*upper/2;weights=weights*upper/2
    y=x*np.sinh(t);e=x*np.cosh(t);ee=np.exp(-e);ff=ee/(1+ee)
    rr=pi*pi/15+deg/(2*pi*pi)*np.dot(weights,y*y*e*e*ff)
    pp=pi*pi/45+deg/(6*pi*pi)*np.dot(weights,y**4*ff)
    cv=4*pi*pi/15+deg/(2*pi*pi)*np.dot(weights,y*y*e**3*ff*(1-ff))
    tr=deg/(2*pi*pi)*np.dot(weights,x*x*y*y*ff)
    M=x+80
    tail_r=deg/(2*pi*pi)*math.exp(-M)*(M**3+3*M*M+6*M+6)
    tail_cv=deg/(2*pi*pi)*math.exp(-M)*(M**4+4*M**3+12*M*M+24*M+24)
    return {'r':float(rr),'p':float(pp),'cv':float(cv),'trace':float(tr),'energy_cut':M,'tail_r_upper':tail_r,'tail_cv_upper':tail_cv}
xs=[0.007,0.11,0.6,1.3,2.9,6.7,14.,24.]
Gh=(11*pi*pi/60)/(4*(11*pi*pi/60)/3)**(4/3)
Gc=(pi*pi/15)/(4*(pi*pi/15)/3)**(4/3)
results=[]
for x in xs:
    z=moments(x);results.append(z)
    check('finite_mass_positive_stress_'+str(x),0<z['p']<z['r']/3)
    check('positive_trace_and_heat_capacity_'+str(x),z['trace']>0 and z['cv']>0)
    near('trace_subtraction_'+str(x),z['r']-3*z['p'],z['trace'])
    near('pressure_temperature_identity_'+str(x),z['pT'],z['r']+z['p'])
    check('finite_G_range_'+str(x),Gh<z['G']<Gc,{'Ghot':Gh,'G':z['G'],'Gcold':Gc})
    h=0.0002
    lg=lambda delta:math.log(moments(x*math.exp(-delta))['G'])
    finite_difference=(-lg(2*h)+8*lg(h)-8*lg(-h)+lg(-2*h))/(12*h)
    expected=z['cv']*(3*z['p']-z['r'])/(3*z['r']*(z['r']+z['p']))
    near('finite_mass_G_derivative_'+str(x),finite_difference,expected,2e-7)
    check('negative_temperature_G_derivative_'+str(x),expected<0)
for left,right in zip(results,results[1:]):
    check('G_increases_with_m_over_T_'+str((left['x'],right['x'])),left['G']<right['G'])
secondary=[]
for x in [0.11,1.3,6.7,24.]:
    baseline=moments(x);z256=rapidity(x,256);z512=rapidity(x,512)
    for kind in ['r','p','cv','trace']:
        near('rapidity_vs_momentum_'+str((x,kind)),z512[kind],baseline[kind])
        near('rapidity_node_refinement_'+str((x,kind)),z256[kind],z512[kind])
    check('rapidity_tail_bound_'+str(x),0<z512['tail_r_upper']<1e-25 and 0<z512['tail_cv_upper']<1e-24)
    secondary.append({'x':x,'nodes256':z256,'nodes512':z512})
# Endpoint charge and clock factors may vary without a temperature ordering.
endpoints=[]
for xb,xf in [(0.11,6.7),(6.7,0.11),(1.3,14.),(24.,0.6)]:
    b=moments(xb);f0=moments(xf);Tb,Tf=1/xb,1/xf
    Sb=3.7;Cb=0.43;Cf=1.02
    sb=Tb**3*(b['r']+b['p']);sf=Tf**3*(f0['r']+f0['p'])
    ajb=(Sb/sb)**(1/3);ajf=(Sb/sf)**(1/3)
    aeb=ajb/math.sqrt(Cb);aef=ajf/math.sqrt(Cf)
    rhojb=Tb**4*b['r'];rhojf=Tf**4*f0['r']
    rhoeb=Cb**2*rhojb;rhoef=Cf**2*rhojf
    Db=rhojb*ajb**4;Df=rhojf*ajf**4
    rat=Df/Db
    near('endpoint_G_charge_'+str((xb,xf)),rat,f0['G']/b['G'])
    near('endpoint_frame_charge_'+str((xb,xf)),rhoef*aef**4/(rhoeb*aeb**4),rat)
    check('endpoint_unordered_range_'+str((xb,xf)),1/float(R)<rat<float(R))
    endpoints.append({'x_b':xb,'x_f':xf,'S':Sb,'C_b':Cb,'C_f':Cf,'D_ratio':rat,'N_E':math.log(aef/aeb),'classification':'endpoint thermodynamic/frame data, not a complete cosmological solution'})
# A finite-mass local Einstein-bounce datum satisfies the actual action constraint.
z=moments(1.3);temp=1/1.3;rho0=temp**4*z['r'];p0=temp**4*z['p']
V0=3.;kap0=(V0+rho0)/3.;Hdot=kap0-(rho0+p0)/2.;fraction=rho0/(3*kap0)
near('local_full_action_constraint',3*kap0,V0+rho0)
check('local_strict_Einstein_bounce',Hdot>0)
check('local_finite_mass_bounce_fraction',fraction<2/(3*(1+p0/rho0)))
check('local_bath_has_nonzero_scalar_trace_source',rho0-3*p0>0)
evidence['local_bounce_datum']={'Q':1,'Hv':1,'k':'1/5','nu':'9/7','fields':'u=x=y=0','scalar_velocities':'all zero','m':1,'T':temp,'rho_B':rho0,'p_B':p0,'V':V0,'aE':1,'Kc':kap0,'H_E':0,'Hdot_E':Hdot,'f_B':fraction,'scope':'regular local constraint/bounce data; scalar trace generally accelerates the fields, no stationary finite-mass background or full history asserted'}
check('quadrature_no_warnings',not numeric_warnings,numeric_warnings)
evidence['quadrature']=results;evidence['rapidity_comparison']=secondary;evidence['unordered_endpoints']=endpoints
evidence['limits']={'Ghot':Gh,'Gcold':Gc,'R':float(R),'coarse_bounce_coefficient':1.5/float(R),'photon_charge_ratio':float(Rphoton)}
result={'created_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'pass':sum(z['passed'] for z in rows),'fail':sum(not z['passed'] for z in rows),'checks':rows,'evidence':evidence,'scope':'new blind independent math and synthetic gas controls only','producer_code_or_results_accessed':False,'versions':{'python':sys.version,'sympy':sp.__version__,'scipy':scipy.__version__,'numpy':np.__version__}}
out=Path(sys.argv[1]);assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pass':result['pass'],'fail':result['fail'],'failed_checks':[z for z in rows if not z['passed']],'limits':evidence['limits'],'local_bounce_datum':evidence['local_bounce_datum'],'warnings':numeric_warnings},indent=2))
sys.exit(1 if result['fail'] else 0)
