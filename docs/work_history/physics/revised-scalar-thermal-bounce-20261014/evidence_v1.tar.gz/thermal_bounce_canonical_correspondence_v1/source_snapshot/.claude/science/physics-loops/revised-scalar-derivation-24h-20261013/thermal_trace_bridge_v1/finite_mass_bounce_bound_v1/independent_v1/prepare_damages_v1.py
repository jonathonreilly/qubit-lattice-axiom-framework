from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,difflib
here=Path(__file__).resolve().parent
baseline=here/'check_thermal_bound_v2.py';text=baseline.read_text()
changes=[
 ('trace_sign','TRACE_SIGN = 1','TRACE_SIGN = -1','stress_trace_integrand'),
 ('entropy_exponent','ENTROPY_POWER = sp.Rational(4, 3)','ENTROPY_POWER = sp.Rational(1, 1)','G_temperature_identity'),
 ('frame_density_power','FRAME_POWER = 4','FRAME_POWER = 2','conformal_charge_invariance'),
 ('radius_exponent','RADIUS_POWER = 2','RADIUS_POWER = -2','endpoint_radius_charge_identity'),
 ('raychaudhuri_denominator','RAY_DEN = 2','RAY_DEN = 3','action_Raychaudhuri_normalization'),
 ('photon_component','USE_TOTAL = True','USE_TOTAL = False','same_total_component_diagnostic'),
 ('fermion_degeneracy','FERMION_DEGENERACY = 4','FERMION_DEGENERACY = 2','adopted_hot_species_weight')]
folder=here/'damages';assert not folder.exists();folder.mkdir()
rows=[]
for name,old,new,required in changes:
 assert text.count(old)==1
 changed=text.replace(old,new)
 path=folder/(name+'.py');path.write_text(changed)
 diff=folder/(name+'.diff');diff.write_text(''.join(difflib.unified_diff(text.splitlines(True),changed.splitlines(True),fromfile='check_thermal_bound_v2.py',tofile=str(path.relative_to(here)))))
 rows.append({'name':name,'script':str(path.relative_to(here)),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'diff':str(diff.relative_to(here)),'old':old,'new':new,'required_failed_check':required,'expected_child_exit':1})
o={'created_utc':datetime.now(timezone.utc).isoformat(),'baseline_sha256':hashlib.sha256(baseline.read_bytes()).hexdigest(),'baseline_actual_result_sha256':hashlib.sha256((here/'independent_thermal_results_v2.json').read_bytes()).hexdigest(),'before_actual_damaged_execution':True,'damages':rows}
p=here/'DAMAGE_PLAN_v1.json';assert not p.exists();p.write_text(json.dumps(o,indent=2)+'\n')
print(json.dumps(o,indent=2))
