"""Run a child script and retain exact invocation, output and exit status."""
from pathlib import Path
from datetime import datetime, timezone
import subprocess, sys, json, hashlib
here=Path(__file__).resolve().parent
name=sys.argv[1]
script=(here/sys.argv[2]).resolve()
assert script.is_relative_to(here)
argv=[sys.executable,'-B',str(script),*sys.argv[3:]]
paths={k:here/(name+'.'+k+'.txt') for k in ['stdout','stderr']}
record=here/(name+'.json')
assert not record.exists() and all(not p.exists() for p in paths.values())
started=datetime.now(timezone.utc).isoformat()
timed_out=False
try:
 p=subprocess.run(argv,cwd=here,text=True,capture_output=True,timeout=180)
 out,err,code=p.stdout,p.stderr,p.returncode
except subprocess.TimeoutExpired as e:
 timed_out=True;code=124
 out=e.stdout or '';err=e.stderr or ''
 if isinstance(out,bytes):out=out.decode(errors='replace')
 if isinstance(err,bytes):err=err.decode(errors='replace')
finished=datetime.now(timezone.utc).isoformat()
for key,value in [('stdout',out),('stderr',err)]:paths[key].write_text(value)
result={'command':argv,'cwd':str(here),'started_utc':started,'finished_utc':finished,'exit_code':code,'timeout_seconds':180,'timed_out':timed_out,'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest()}
for key,path in paths.items():result[key]={'path':path.name,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
record.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2));print(out);print(err)
