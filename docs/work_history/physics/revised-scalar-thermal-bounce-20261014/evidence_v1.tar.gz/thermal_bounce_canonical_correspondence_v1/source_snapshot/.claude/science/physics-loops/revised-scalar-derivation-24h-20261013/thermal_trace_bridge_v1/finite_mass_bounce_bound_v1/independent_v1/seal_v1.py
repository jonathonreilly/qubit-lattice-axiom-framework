"""Seal independent artifacts with final source and command identity checks."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,sys
here=Path(__file__).resolve().parent
root=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
folder=here/'source_correspondence_v2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((here/n).read_text())
def write(p,o):
 with p.open('x') as f:json.dump(o,f,indent=2);f.write('\n')
def bound(p,base=here):return {'path':str(p.relative_to(base)),'bytes':p.stat().st_size,'sha256':sha(p)}
def verify_source(pair):
 live=root/pair['original_path'];snap=here/pair['snapshot_path']
 assert live.read_bytes()==snap.read_bytes()
 assert sha(live)==pair['sha256'] and live.stat().st_size==pair['bytes']
for p in [here/'COMMANDS_v1.json',here/'FINAL_SOURCE_BINDING_v1.json',here/'SEAL_VALIDATION_v1.json',here/'MANIFEST_v1.json',here/'RECEIPT_v1.json',folder/'MANIFEST_v2.json',folder/'RECEIPT_v2.json']:
 assert not p.exists(),str(p)
validation=read('EVIDENCE_VALIDATION_v1.json')
assert (validation['pass'],validation['fail'])==(134,0)
pairs=validation['source_pairs'];assert len(pairs)==5
for pair in pairs:verify_source(pair)
assert pairs[0]['sha256']=='0675d2e7134c09921c474d3e6887ae95f9638e38b560b8856a21e9e02fe8105f'
assert pairs[3]['sha256']=='356b3cdbc71d862223da2e6197f09eab816807afcf40bd17a3ec3335e8da6e23'
freeze=read('INDEPENDENT_SCIENCE_FREEZE_v1.json')
for item in freeze['artifacts']:
 p=here/item['path'];assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
hand=read('HAND_PROOF_FREEZE_v1.json')
for item in hand['files']:
 p=here/item['path'];assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
first=read('independent_thermal_results_v1.json');final=read('independent_thermal_results_v2.json')
assert (first['pass'],first['fail'])==(177,0)
assert (final['pass'],final['fail'])==(180,0)
assert final['script_sha256']==sha(here/'check_thermal_bound_v2.py')
quality=read('CHECKER_QUALITY_REPAIR_v2.json');assert quality['old_vacuous_rows_not_relabelled_as_evidence']
assert not quality['author_sources_changed']
tool_failure=read('TOOL_FAILURES_v1.json')
assert not tool_failure['command_ran'] and not tool_failure['files_written_by_failed_attempt']
assert tool_failure['script_sha256']==sha(here/'verify_evidence_v1.py')
commands=[]
for path in sorted(here.glob('*_run_v*.json')):
 r=json.loads(path.read_text());expect=1 if path.name.startswith('damage_') else 0
 assert r['exit_code']==expect and not r['timed_out']
 assert Path(r['cwd'])==here
 assert sha(Path(r['command'][2]))==r['script_sha256']
 for name in ['stdout','stderr']:
  info=r[name];p=here/info['path'];assert sha(p)==info['sha256'] and p.stat().st_size==info['bytes']
 commands.append({'record':path.name,'record_sha256':sha(path),**r})
assert len(commands)==12
for item in validation['actual_damages']:
 assert item['exit_code']==1 and item['fail']>0
 r=read(item['result']);assert (r['pass'],r['fail'])==(item['pass'],item['fail'])
 assert item['required_failed_check'] in [x['name'] for x in r['checks'] if not x['passed']]
 assert r['script_sha256']==sha(here/item['script'])==item['sha256']
assert len(validation['actual_damages'])==7
cor=read('source_correspondence_v2/RESULTS_v2.json')
assert (cor['pass'],cor['fail'])==(56,0)
for p in here.rglob('*'):assert not p.is_symlink(),str(p)
now=datetime.now(timezone.utc).isoformat()
seal_command={'command':[sys.executable,'-B',str(Path(__file__).resolve())],'cwd':str(here),'script_sha256':sha(Path(__file__)),'scope':'identity checks and immutable serialization; no science rerun'}
# Independent later-source receipt: this does not alter any frozen science.
cor_excluded={'MANIFEST_v2.json','RECEIPT_v2.json'}
cor_artifacts=[bound(p,folder) for p in sorted(folder.rglob('*')) if p.is_file() and str(p.relative_to(folder)) not in cor_excluded]
cor_manifest={'created_utc':now,'unit':str(folder.relative_to(root)),'artifact_count':len(cor_artifacts),'artifacts':cor_artifacts,'source_pairs':read('source_correspondence_v2/SOURCE_MANIFEST_v2.json')['sources'],'excluded_seal_files':sorted(cor_excluded),'immutable_after_seal':True}
write(folder/'MANIFEST_v2.json',cor_manifest)
cor_receipt={'created_utc':now,'type':'narrow affected-source correspondence; metadata only','checker':'/root/local_response_check','direct_scientific_author':'/root','report':bound(folder/'REPORT_v2.md',folder),'manifest':bound(folder/'MANIFEST_v2.json',folder),'artifact_count':len(cor_artifacts),'pass':56,'fail':0,'science_reused':{'pass':180,'fail':0,'new_run':False,'frozen_evidence':bound(here/'INDEPENDENT_SCIENCE_FREEZE_v1.json')},'original_source_sha256':pairs[0]['sha256'],'corrected_source_sha256':pairs[3]['sha256'],'later_source_pairs':cor_manifest['source_pairs'],'original_reviewer_confirmation':cor['original_reviewer_confirmation'],'command_record_relative_to_enclosing_unit':bound(here/'correspondence_run_v2.json'),'producer_code_results_accessed':False,'immutable_after_seal':True}
write(folder/'RECEIPT_v2.json',cor_receipt)
write(here/'COMMANDS_v1.json',{'created_utc':now,'child_runs':commands,'preserved_nonexecution_tool_failure':bound(here/'TOOL_FAILURES_v1.json'),'seal_command':seal_command})
final_binding={'created_utc':now,'checker':'/root/local_response_check','source_pairs':pairs,'original_v1_preserved':True,'final_mathematical_source':'DERIVATION_v2.md','finding':'Original entropy escape formula omitted an explicit positive denominator domain.','author_correction':'The positive target domain and impossible nonpositive-product case are now explicit; only two prose blocks changed.','original_reviewer_confirmation':cor['original_reviewer_confirmation'],'later_correspondence_receipt':bound(folder/'RECEIPT_v2.json'),'producer_code_or_results_accessed':False}
write(here/'FINAL_SOURCE_BINDING_v1.json',final_binding)
write(here/'SEAL_VALIDATION_v1.json',{'created_utc':now,'scope':'identity checks only','live_source_pairs_verified':len(pairs),'frozen_hand_artifacts_verified':len(hand['files']),'frozen_science_artifacts_verified':len(freeze['artifacts']),'child_run_records_verified':len(commands),'actual_damaged_scripts_rejected':7,'source_correspondence':{'pass':56,'fail':0},'stored_evidence_validation':{'pass':134,'fail':0},'preserved_defects':['CHECKER_QUALITY_REPAIR_v2.json','TOOL_FAILURES_v1.json'],'seal_command':seal_command})
excluded={'MANIFEST_v1.json','RECEIPT_v1.json'}
artifacts=[bound(p) for p in sorted(here.rglob('*')) if p.is_file() and str(p.relative_to(here)) not in excluded]
manifest={'created_utc':now,'unit':str(here.relative_to(root)),'artifact_count':len(artifacts),'artifacts':artifacts,'source_pairs':pairs,'excluded_seal_files':sorted(excluded),'immutable_after_seal':True}
write(here/'MANIFEST_v1.json',manifest)
receipt={
 'created_utc':now,'type':'focused blind independent mathematics and synthetic gas check; not formal audit',
 'checker':'/root/local_response_check','direct_scientific_author':'/root','unit':str(here.relative_to(root)),
 'report':bound(here/'REPORT_v1.md'),'manifest':bound(here/'MANIFEST_v1.json'),'artifact_count':len(artifacts),'live_source_pair_count':len(pairs),'source_pairs':pairs,
 'science':{'corrected_actual_run':{'pass':180,'fail':0,'exit_code':0,'script':bound(here/'check_thermal_bound_v2.py'),'result':bound(here/'independent_thermal_results_v2.json'),'command':bound(here/'independent_thermal_run_v2.json')},'preserved_original_run':{'pass':177,'fail':0,'exit_code':0,'script':bound(here/'check_thermal_bound_v1.py'),'result':bound(here/'independent_thermal_results_v1.json'),'command':bound(here/'independent_thermal_run_v1.json'),'four_vacuous_guard_rows_not_counted_as_validation':True},'quality_repair':bound(here/'CHECKER_QUALITY_REPAIR_v2.json'),'counts_not_added_or_relabelled':True,'previous_units_reused_or_rerun':False},
 'actual_damaged_copies':validation['actual_damages'],
 'source_correction':{'original_omission_preserved':True,'finding':'Explicit positivity domain missing for divided entropy target in original v1.','corrected_by_author':True,'v2_correspondence_pass':56,'v2_correspondence_fail':0,'new_science':False,'original_reviewer_confirmation':cor['original_reviewer_confirmation'],'correspondence_receipt':bound(folder/'RECEIPT_v2.json')},
 'metadata':{'pass':134,'fail':0,'new_science':False,'validation':bound(here/'EVIDENCE_VALIDATION_v1.json'),'seal_validation':bound(here/'SEAL_VALIDATION_v1.json')},
 'preserved_failures_and_defects':[bound(here/'CHECKER_QUALITY_REPAIR_v2.json'),bound(here/'TOOL_FAILURES_v1.json')],
 'commands':bound(here/'COMMANDS_v1.json'),'seal_command':seal_command,
 'primary_reference_access':{'record':bound(here/'PDG_ACCESS_v1.json'),'url':'https://pdg.lbl.gov/2025/reviews/rpp2025-rev-bbang-cosmology.pdf','role':'context for adopted equilibrium definitions and separate rate condition','local_pdf_byte_hash_claimed':False},
 'bounded_conclusion':'The ideal fixed-mass photon/pair bath has the stated continuous G range. At a strict Einstein bounce the same total-bath diagnostic satisfies d_J F_bare > [3/(2R)] exp(2N), R=(11/4)^(1/3). The restricted N>=0 obstruction and conditional entropy budget hold with the corrected positive target domain.',
 'limitations':['Adopted matter species, distributions, reversible equilibrium and isolation are not derived from the scalar action.','Synthetic gas quadrature does not validate reaction rates, abundance, a complete thermal history or observations.','Same total bath and bare Q/C normalization are essential; photon-only or measured-G targets need separate conversion.','The event is an Einstein bounce and the final rate must be nonzero; N>=0 is a supplied endpoint radius condition.','Larger species or entropy ratios remove only the sufficiency of this coarse estimate; they do not construct a solution.','No prior independent science is rerun or promoted, and no formal audit, runtime or authority status is changed.'],
 'writes_confined_to_unit':True,'producer_code_or_results_accessed':False,'git_runtime_settings_or_authority_changed':False,'immutable_after_seal':True
}
write(here/'RECEIPT_v1.json',receipt)
# No writes after this point.
for item in artifacts:
 p=here/item['path'];assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
assert {str(p.relative_to(here)) for p in here.rglob('*') if p.is_file()}=={x['path'] for x in artifacts}|excluded
assert sha(here/'MANIFEST_v1.json')==receipt['manifest']['sha256']
for pair in pairs:verify_source(pair)
for item in cor_artifacts:
 p=folder/item['path'];assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
assert sha(folder/'MANIFEST_v2.json')==cor_receipt['manifest']['sha256']
print(json.dumps({'sealed_utc':now,'artifact_count':len(artifacts),'live_source_pairs':len(pairs),'postseal_identity_verification':'passed','science':'180/0; original177/0 preserved with four vacuous guards disclosed','actual_damaged_rejections':7,'source_correspondence':'56/0 metadata','report':bound(here/'REPORT_v1.md'),'manifest':bound(here/'MANIFEST_v1.json'),'receipt':bound(here/'RECEIPT_v1.json'),'correspondence_receipt':bound(folder/'RECEIPT_v2.json')},indent=2))
