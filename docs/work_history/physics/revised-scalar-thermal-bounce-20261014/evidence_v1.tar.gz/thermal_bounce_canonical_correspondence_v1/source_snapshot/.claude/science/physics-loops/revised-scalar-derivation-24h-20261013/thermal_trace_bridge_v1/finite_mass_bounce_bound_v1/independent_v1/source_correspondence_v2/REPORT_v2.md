# Narrow confirmation of the target-domain correction

The original independent checker confirms DERIVATION_v2.md addresses the explicit-domain omission reported against v1. The target now states epsilon>0 and delta>=0; the entropy budget explicitly requires epsilon(1+delta)>0. A nonpositive target product is impossible because d_J F_bare>0, and no divided entropy-budget expression is asserted there.

The complete v2 source was read after INDEPENDENT_SCIENCE_FREEZE_v1.json froze the independent hand proof, corrected 180/0 computation and all seven actual damaged runs. The correspondence command completed **56/0 metadata checks**. It proves that exactly the two requested prose blocks changed, that every displayed equation is unchanged, and that all frozen independent science bytes remain identical. This is not a new science run or a relabeling of 180/0.

| Source | SHA-256 |
| --- | --- |
| Preserved DERIVATION_v1.md | 0675d2e7134c09921c474d3e6887ae95f9638e38b560b8856a21e9e02fe8105f |
| Corrected DERIVATION_v2.md | 356b3cdbc71d862223da2e6197f09eab816807afcf40bd17a3ec3335e8da6e23 |
| TARGET_DOMAIN_REPAIR_v2.json | 7877488fcacbcbd913f5c2b1bf8a09f5fea3f38c6103df9c9e527117a9f40bb8 |

The original missing qualification remains part of the evidence history. The author made the correction; this checker did not edit either source. All conclusions remain conditional on the same total isolated equilibrium bath, fixed physical particle masses, Einstein-bounce and radius-ordering premises, and bare cosmological normalization. No producer code or output was consulted.

RESULTS_v2.json binds the original three source pairs and the two later pairs. The exact command and stdout/stderr hashes are in the enclosing unit's correspondence_run_v2.json. This folder's manifest and receipt bind this separate affected-source confirmation; the enclosing unit's immutable manifest also includes them.
