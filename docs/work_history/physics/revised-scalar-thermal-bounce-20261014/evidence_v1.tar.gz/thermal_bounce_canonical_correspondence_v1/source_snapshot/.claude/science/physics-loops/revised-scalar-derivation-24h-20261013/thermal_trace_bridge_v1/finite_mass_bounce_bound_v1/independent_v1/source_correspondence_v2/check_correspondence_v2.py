from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,sys
folder=Path(__file__).resolve().parent;unit=folder.parent
root=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
rows=[]
def check(n,b):rows.append({'name':n,'passed':bool(b)})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
orig=json.loads((unit/'SOURCE_MANIFEST_v1.json').read_text())['sources']
new=json.loads((folder/'SOURCE_MANIFEST_v2.json').read_text())['sources']
for label,base,pairs in [('original',unit,orig),('later',folder,new)]:
 for j,pair in enumerate(pairs):
  live=root/pair['original_path'];snap=base/pair['snapshot_path']
  check(label+'_live_hash_'+str(j),sha(live)==pair['sha256'])
  check(label+'_snapshot_hash_'+str(j),sha(snap)==pair['sha256'])
  check(label+'_bytes_'+str(j),live.read_bytes()==snap.read_bytes() and snap.stat().st_size==pair['bytes'])
v1=(unit/'sources/DERIVATION_v1.md').read_text();v2=(folder/'sources/DERIVATION_v2.md').read_text()
old1='a target d_J,f<=epsilon and F_bare,B,f<=1+delta with epsilon(1+delta)<=1.\n'
new1='a target d_J,f<=epsilon and F_bare,B,f<=1+delta with epsilon>0, delta>=0\nand epsilon(1+delta)<=1.\n'
old2='using the strict bounce inequality. Specifying sigma is not a production law.\n'
new2='using the strict bounce inequality and the positive target product\nepsilon(1+delta)>0. If that product is nonpositive, the positive diagnostic\nproduct already makes the target impossible; no finite budget expression is\nasserted there. Specifying sigma is not a production law.\n'
check('target_old_text_unique',v1.count(old1)==1)
check('budget_old_text_unique',v1.count(old2)==1)
check('only_requested_domain_prose_changed',v2==v1.replace(old1,new1).replace(old2,new2))
check('all_displayed_equations_unchanged',[x for x in v1.splitlines() if x.startswith('    ')]==[x for x in v2.splitlines() if x.startswith('    ')])
repair=json.loads((folder/'sources/TARGET_DOMAIN_REPAIR_v2.json').read_text())
check('repair_original_hash',repair['source_v1_sha256']==sha(unit/'sources/DERIVATION_v1.md'))
check('repair_corrected_hash',repair['source_v2_sha256']==sha(folder/'sources/DERIVATION_v2.md'))
check('repair_preserves_original',repair['original_preserved'])
check('positive_budget_domain_explicit','epsilon(1+delta)>0' in v2)
check('nonpositive_target_no_budget_explicit','no finite budget expression is\nasserted there' in v2)
freeze=json.loads((unit/'INDEPENDENT_SCIENCE_FREEZE_v1.json').read_text())
for j,item in enumerate(freeze['artifacts']):
 p=unit/item['path'];check('frozen_science_'+str(j),sha(p)==item['sha256'] and p.stat().st_size==item['bytes'])
check('corrected180_reused_not_rerun',freeze['corrected_new_run']=={'pass':180,'fail':0,'exit_code':0})
check('producer_not_accessed',not freeze['author_producer_accessed'])
check('not_relabelled177',freeze['original_run']['four_vacuous_rows_not_counted_as_validation'])
result={'created_utc':datetime.now(timezone.utc).isoformat(),'pass':sum(z['passed'] for z in rows),'fail':sum(not z['passed'] for z in rows),'checks':rows,'original_source_pairs':orig,'later_source_pairs':new,'scope':'narrow source identity and domain correspondence, not fresh science','original_reviewer_confirmation':'The source author has corrected the explicit target domain identified by this checker. Only the two stated prose blocks changed; all displayed equations and scientific controls are unchanged. The frozen180/0 result is reused, not rerun.','script_sha256':sha(Path(__file__))}
out=folder/'RESULTS_v2.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pass':result['pass'],'fail':result['fail'],'failed_checks':[x for x in rows if not x['passed']],'original_reviewer_confirmation':result['original_reviewer_confirmation']},indent=2))
sys.exit(1 if result['fail'] else 0)
