"""Evidence checks only; no math or quadrature is rerun."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
here=Path(__file__).resolve().parent
root=Path('/Users/jonBridger/.codex/worktrees/revised-scalar-derivation-24h-20261013/New Axioms Lets Go')
checks=[]
def check(name,okay):checks.append({'name':name,'passed':bool(okay)})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(n):return json.loads((here/n).read_text())
pairs=read('SOURCE_MANIFEST_v1.json')['sources']
for item in read('source_correspondence_v2/SOURCE_MANIFEST_v2.json')['sources']:
 pairs.append({**item,'snapshot_path':'source_correspondence_v2/'+item['snapshot_path'],'role':'later_narrow_domain_correction'})
for i,pair in enumerate(pairs):
 live=root/pair['original_path'];snap=here/pair['snapshot_path']
 check('live_sha_'+str(i),sha(live)==pair['sha256'])
 check('snapshot_sha_'+str(i),sha(snap)==pair['sha256'])
 check('bytes_'+str(i),live.read_bytes()==snap.read_bytes() and snap.stat().st_size==pair['bytes'])
for freeze_name,key in [('HAND_PROOF_FREEZE_v1.json','files'),('INDEPENDENT_SCIENCE_FREEZE_v1.json','artifacts')]:
 for i,row in enumerate(read(freeze_name)[key]):
  p=here/row['path'];check(freeze_name+'_'+str(i),sha(p)==row['sha256'] and p.stat().st_size==row['bytes'])
commands=[]
for p in sorted(here.glob('*_run_v*.json')):
 r=json.loads(p.read_text());expect=1 if p.name.startswith('damage_') else 0
 check(p.name+'_exit',r['exit_code']==expect and not r['timed_out'])
 check(p.name+'_script',sha(Path(r['command'][2]))==r['script_sha256'])
 check(p.name+'_cwd',Path(r['cwd'])==here)
 for key in ['stdout','stderr']:
  z=r[key];file=here/z['path'];check(p.name+'_'+key,sha(file)==z['sha256'] and file.stat().st_size==z['bytes'])
 commands.append({'record':p.name,**r})
for version,passed in [('v1',177),('v2',180)]:
 r=read('independent_thermal_results_'+version+'.json')
 check(version+'_actual_count',(r['pass'],r['fail'])==(passed,0))
 check(version+'_script_bound',r['script_sha256']==sha(here/('check_thermal_bound_'+version+'.py')))
 check(version+'_blind',not r['producer_code_or_results_accessed'])
repair=read('CHECKER_QUALITY_REPAIR_v2.json')
check('vacuous_rows_disclosed',repair['old_vacuous_rows_not_relabelled_as_evidence'])
check('initial_guard_rows_preserved','sp.Integer(0))' in (here/'check_thermal_bound_v1.py').read_text())
corrected=read('independent_thermal_results_v2.json')
zero_guard=[x for x in corrected['checks'] if x['name']=='zero_endpoint_rate_diagnostic_undefined'][0]
check('corrected_zero_rate_actual_substitution',zero_guard['detail']=={'d_at_zero':'zoo','F_at_zero':'0','uncancelled_product':'nan'})
plan=read('DAMAGE_PLAN_v1.json');damages=[]
for item in plan['damages']:
 name=item['name'];result=read('damages/'+name+'_results_v1.json');record=read('damage_'+name+'_run_v1.json')
 failures=[z['name'] for z in result['checks'] if not z['passed']]
 check(name+'_script_bound',sha(here/item['script'])==item['sha256']==result['script_sha256'])
 check(name+'_result_counts',result['pass']+result['fail']==180 and result['fail']==len(failures))
 check(name+'_intended_failure',item['required_failed_check'] in failures and record['exit_code']==1)
 damages.append({**item,'pass':result['pass'],'fail':result['fail'],'exit_code':record['exit_code'],'result':'damages/'+name+'_results_v1.json','command_record':'damage_'+name+'_run_v1.json','failed_checks':failures})
cor=read('source_correspondence_v2/RESULTS_v2.json')
check('v2_source_correspondence',(cor['pass'],cor['fail'])==(56,0))
check('v2_original_reviewer_confirmation','Only the two stated prose blocks changed' in cor['original_reviewer_confirmation'])
check('no_symlinks',not any(p.is_symlink() for p in here.rglob('*')))
max_cross=max(z['detail']['absolute_gap'] for z in corrected['checks'] if z['name'].startswith('rapidity_vs_momentum_'))
max_deriv=max(z['detail']['absolute_gap'] for z in corrected['checks'] if z['name'].startswith('finite_mass_G_derivative_'))
quad_records=corrected['evidence']['quadrature']
summary={'maximum_rapidity_momentum_absolute_gap':max_cross,'maximum_G_derivative_absolute_gap':max_deriv,'gas_rows':[{'x':z['x'],'r':z['r'],'P':z['p'],'w':z['p']/z['r'],'G':z['G'],'trace':z['trace']} for z in quad_records]}
result={'created_utc':datetime.now(timezone.utc).isoformat(),'scope':'metadata verification and extraction of already stored results; no fresh science','pass':sum(z['passed'] for z in checks),'fail':sum(not z['passed'] for z in checks),'checks':checks,'source_pairs':pairs,'commands':commands,'actual_damages':damages,'stored_numerical_summary':summary,'source_correspondence_counts':{'pass':56,'fail':0,'new_science':False},'quality_failure_preserved':'CHECKER_QUALITY_REPAIR_v2.json','producer_or_other_route_accessed':False,'script_sha256':sha(Path(__file__))}
out=here/'EVIDENCE_VALIDATION_v1.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'pass':result['pass'],'fail':result['fail'],'failed_checks':[x for x in checks if not x['passed']],'source_pairs':len(pairs),'command_records':len(commands),'numerical_summary':summary},indent=2))
sys.exit(1 if result['fail'] else 0)
