from pathlib import Path
import json,hashlib,datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
p=Path(__file__).parent;r=json.loads((p/'RESULTS_v1.json').read_text());g=r['grid'];x=np.array([v['x'] for v in g]);ratio=np.array([v['G']/r['analytic_endpoint_G'][0] for v in g]);w=np.array([v['w'] for v in g]);R=float(r['R'])
fig,axs=plt.subplots(1,2,figsize=(11.6,4.5),constrained_layout=True)
for a in axs:
 a.set_xscale('log');a.set_xlabel(r'$m_e/T$ (specified equilibrium bath)',fontsize=11);a.grid(alpha=.18);a.spines[['top','right']].set_visible(False)
axs[0].plot(x,ratio,color='#226b9b',lw=2.5,label=r'$G(T)/G_{\rm hot}$ at fixed entropy')
axs[0].axhline(R,color='#226b9b',ls='--',lw=1.2,label=r'Maximum charge ratio $R=1.40102$')
axs[0].axhline(1.5,color='#ab493c',ls=':',lw=2,label=r'Bare target requires $\zeta>1.5$ at $N=0$')
axs[0].set_ylim(.96,1.57);axs[0].set_ylabel('Thermal charge growth factor',fontsize=11)
axs[0].legend(loc='center left',bbox_to_anchor=(.015,.44),fontsize=8.5,frameon=True,facecolor='white',edgecolor='none',framealpha=.96)
axs[0].set_title('A derived charge budget',loc='left',fontsize=13)
axs[1].plot(x,w,color='#30775b',lw=2.5,label=r'$p/\rho$, including finite pair mass')
axs[1].axhline(1/3,color='#555555',ls='--',lw=1,label='Traceless limit')
axs[1].set_ylim(.24,.345);axs[1].set_ylabel('Total-bath equation of state',fontsize=11);axs[1].legend(loc='lower left',fontsize=9,frameon=False);axs[1].set_title('The intermediate bath is traceful',loc='left',fontsize=13)
fig.suptitle('Charge growth through the electron–positron threshold',fontsize=15)
for ext in ['png','pdf']:
 f=p/('THERMAL_CHARGE_BUDGET_v2.'+ext);assert not f.exists();fig.savefig(f,dpi=180)
meta={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'data':'RESULTS_v1.json','data_sha256':hashlib.sha256((p/'RESULTS_v1.json').read_bytes()).hexdigest(),'renderer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'change':'Only left legend position/backdrop changed after visual QA; same checked numerical data.','role':'Synthetic ideal-bath quadrature, not observed data. Red line is bare total-bath target conditional on Einstein bounce and N=0.','artifacts':[{'path':n,'sha256':hashlib.sha256((p/n).read_bytes()).hexdigest()} for n in ['THERMAL_CHARGE_BUDGET_v2.png','THERMAL_CHARGE_BUDGET_v2.pdf']]};(p/'FIGURE_SOURCE_v2.json').write_text(json.dumps(meta,indent=2)+'\n');print(json.dumps(meta))
