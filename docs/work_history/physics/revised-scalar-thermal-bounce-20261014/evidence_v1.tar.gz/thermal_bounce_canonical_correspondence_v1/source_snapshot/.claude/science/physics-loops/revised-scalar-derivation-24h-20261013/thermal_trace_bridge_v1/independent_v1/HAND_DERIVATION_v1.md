# Independent handwritten thermal/trace derivation

Written before mathematical control code. Parent /root remains the scientific author; this is a focused independent check. No producer implementation/results or prior independent code has been read.

## Matter action and component conversion

The complete supplied action has matter dependence Sm[A² g_E,matter] and no additional explicit scalar dependence in the Jordan description. On the matter equations of motion, diffeomorphism invariance gives nabla_J T_total,J=0. A component decomposition T_total=sum_i T_i gives energy-transfer projections Q_i,J whose sum is zero, provided interaction energy and all transferring components are included and there is no external source. It does not force each component divergence to vanish. In a homogeneous isotropic common fluid frame, the energy equations are rho_i,J' +3H_J(rho_i,J+p_i,J)=Q_i,J, with prime denoting physical proper time.

At fixed scalar fields, metric variation gives T_E,mu nu=A² T_J,mu nu. Since u_E=A u_J for unit fluid velocities, rho_E=A⁴rho_J and p_E=A⁴p_J. Let dots denote Einstein time, L=dot A/A, H=dot a_E/a_E, a_J=A a_E and dt_J=A dt_E. Then H_J=(H+L)/A. Direct differentiation, keeping the time conversion, gives

dot rho_E=4L rho_E+A⁵ rho_J' =4L rho_E-3(H+L)(rho_E+p_E)+A⁵ Q_J.

Therefore dot rho_E+3H(rho_E+p_E)=L(rho_E-3p_E)+A⁵Q_J. The extra A beyond density scaling is the conversion from physical proper-time derivative. The sign also agrees with the Einstein Ward identity nabla_E T_E^{mu nu}=b_A T_E grad^nu phi^A: its homogeneous energy component is L(rho_E-3p_E).

For any component, D=rho_E a_E⁴=rho_J a_J⁴ is frame invariant, irrespective of its equation of state. Its general derivatives are

dot D=a_E⁴[(H+L)(rho_E-3p_E)+A⁵Q_J],
D'=a_J⁴[H_J(rho_J-3p_J)+Q_J].

Only when the same component is exactly traceless do these reduce to equation (2). Thus an isolated tracefree component has conserved D. A total electromagnetic bath during a massive threshold can have Q_bath=0 yet changing D through its trace; a photon-only component stays traceless in the ideal model but has Q_gamma from internal transfer. The two descriptions do not conflict. A decoupled massive sector's Einstein trace term is not, without an interaction, a source for photons.

## Conservation alone does not pick a transfer history

For dust and radiation in the same Jordan background, Q_r=J and Q_d=-J cancel in the total equation. Choosing J=Gamma rho_d is an additional interaction prescription. At prescribed a_J=exp(t_J/3), with initial rho_d=7/5 and rho_r=2/9, Gamma=0 gives rho_d=(7/5)exp(-t_J) and rho_r=(2/9)exp(-4t_J/3). Gamma=1/2 instead gives rho_d=(7/5)exp(-3t_J/2) and

rho_r=exp(-4t_J/3)[2/9+(21/5)(1-exp(-t_J/6))].

Both are nonnegative for t_J>=0 and obey total conservation, with different radiation charge growth. These are conservation-only examples on a prescribed background, not solutions of the supplied gravitational equations or models of actual reheating. They show why the conservation identity cannot choose Gamma, its sign, a state, or a transfer mechanism.

## Endpoint bound with a possibly changing charge

At the initial Einstein bounce require the imported conditions H_E,b=0, dot H_E,b>0, kappa_b>0, Q>0, rho_r,b>0, and nonradiation enthalpy nonnegative. The selected initial r component must obey p_r,b=rho_r,b/3. The initial Raychaudhuri equation then gives 0<f_b=rho_r,b/(3Q kappa_b)<1/2. No intermediate conservation is needed for that pointwise bound.

For the same chosen component between endpoints, let zeta=D_f/D_b>0 and R=(a_E,f/a_E,b)²=exp(2N). Then rho_r,f=rho_r,b*zeta/R² and kappa_f=kappa_b/R. With A_f>0, Z_f!=0 and positive final density, d_J= kappa_f/Z_f² and F_bare=3Q Z_f²/rho_r,f. Consequently d_J F_bare=R/(f_b zeta). For positive epsilon and 1+delta, the target product is at most epsilon(1+delta), so zeta>=R/[f_b epsilon(1+delta)]. Equality is possible in this algebra with the actual f_b. If only f_b<1/2 is used, the corresponding universal bound is strict zeta>2R/[epsilon(1+delta)]. N>=0 is a radius comparison, not an assumption of monotone expansion throughout the interval.

The density in the initial f_b, the endpoint ratio zeta, and final F_bare must describe the same component/bath. The bound itself constructs no trajectory or transfer mechanism. The selected component can be nontraceless between the endpoints; then its D evolution requires the general identity above, not the isolated radiation conservation law.

## Thermal endpoints and entropy

Adopt a specified equilibrium bath, a common physical temperature, zero chemical potentials and the supplied statistical species content. Define alpha=pi²/30 and beta=2pi²/45. With rho=alpha g_* T⁴, entropy density s=beta g_*s T³ and S=s a_J³,

D=alpha g_* (T a_J)⁴ =alpha beta^(-4/3) [g_*/g_*s^(4/3)] S^(4/3).

Thus zeta=(g_*,f/g_*,b)(g_*s,b/g_*s,f)^(4/3)(S_f/S_b)^(4/3). All factors must be positive for the real power and order manipulations. If all included species are ideal ultrarelativistic at each endpoint, then p=rho/3 and Ts=rho+p imply g_*s=g_*=g. The ratio becomes zeta=(g_b/g_f)^(1/3)(S_f/S_b)^(4/3). Monotonicity of positive powers gives S_f/S_b >= [R/(f_b epsilon(1+delta))]^(3/4)(g_f/g_b)^(1/4).

At a finite mass threshold the equality g_*s=g_* is generally false. In equilibrium with zero chemical potentials, g_*s=(3/4)(1+w)g_*. This provides a concrete check on using equation (6) outside its ultrarelativistic endpoint domain. Equation (5) retains the separate g_* and g_*s. Adiabaticity S_f=S_b is additional state/history information; total conservation alone does not select it or prove an entropy-production law.

## Photon/pair factors and exact component consistency

The species content is supplied, not obtained from the gravity action. Given ideal Bose/Fermi thermal distributions, the 7/8 energy weight follows from 1/(exp(x)+1)=1/(exp(x)-1)-2/(exp(2x)-1) and the x³ integral's 2^-4 rescaling. Photons contribute two spin states; the supplied electron/positron states contribute four fermionic states. Therefore g_b=2+(7/8)*4=11/2 and g_f=2 after neglecting residual pairs. In the ideal adiabatic limit (T_f a_f)/(T_b a_b)=(11/4)^(1/3).

The total-bath D ratio includes the change of energy coefficient: zeta_bath=(g_f/g_b)*(11/4)^(4/3)=(11/4)^(1/3). Photons alone have the same two-state coefficient at both endpoints, so zeta_gamma=(11/4)^(4/3). At the initial endpoint rho_gamma/rho_bath=4/11; at the final ideal endpoint they coincide. Hence

f_gamma,b=(4/11)f_bath,b,
f_gamma,b*zeta_gamma=f_bath,b*zeta_bath.

Thus the larger photon factor supplies no extra budget when the initial fraction is changed consistently. Indeed f_bath,b<1/2 implies f_gamma,b<2/11 for this supplied equilibrium initial bath. Using an independently near-1/2 photon fraction alongside the same pair bath would omit its initial energy/enthalpy.

An exact algebraic warning witness uses f_bath,b=2/5, R=6/5, epsilon=4/5, delta=0. The required zeta with that total fraction is 15/4. The total factor has cube 11/4<(15/4)³, so it fails. Substituting the photon factor without changing f_b falsely passes because (11/4)^4>(15/4)³. Correcting f_gamma,b to8/55 restores the failure and the equal product. This is a bookkeeping witness, not an evolved universe.

A related conditional check: for R>=1 and epsilon(1+delta)<=1, the initial bound requires zeta>2, but the ideal total-bath factor has cube 11/4<8. Therefore this single ideal adiabatic threshold cannot alone meet that particular symbolic target under the imported bounce hypotheses. The photon-only calculation gives exactly the same result with its matching fraction. This has no empirical tolerance or abundance interpretation.

The numerical factors (8)–(9) are exact in the declared ideal endpoint model (massless/high-temperature limit initially, absent residual pairs finally). At finite temperatures, residual massive contributions and nonideal corrections require an actual thermodynamic model and an error estimate. Neutrino decoupling, separate temperatures, chemical potentials, conserved charges, interaction entropy and nonequilibrium states are outside the simplified formulas unless included explicitly. No actual BBN, microscopic rate, entropy selection, measured dimensional scale or state derivation has been supplied or checked.
