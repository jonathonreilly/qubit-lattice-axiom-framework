# Focused independent thermal-trace bridge check

Scientific author: /root. Independent checker: /root/scalar_energy_check. This is a conditional mathematical check, not an audit, empirical validation or completed physical history.

## Conclusion and final source

The final source DERIVATION_v2.md is consistent with the supplied universal matter coupling and its stated thermal/bounce hypotheses. I independently checked equations (1)–(9), the new general-component equation (2a), the strict initial bounce-premise boundary, and the photon-versus-whole-bath distinction. No material source equation error or further source correction was found.

V2 adds the exact nontraceless charge derivative and makes the ideal endpoint limits explicit. The original first independent run had already checked the general derivative. I read v2 fully and verified that its diff consists only of the two added blocks, with equations (1)–(9) unchanged. The first source remains preserved. Final source SHA: f4286e2ff5caa5d464e93a82d0abfe6b3adbb9ec8a4870ffbd7851c3955ffbde.

## Independent mathematical argument

The supplied matter action depends on the scalars through g_J=A²g_E. On the matter equations of motion, Jordan diffeomorphism invariance constrains the total matter stress tensor. It only implies sum Q_i,J=0 for a complete consistent component split without an external source. It does not identify particles, choose a state, determine the component exchange rates, or make every component separately conserved. The component equations assume the homogeneous isotropic energy projections; a microscopic stress split and transfer four-vectors are additional information in a less symmetric problem.

At fixed scalar fields, metric variation gives T_E,cov=A²T_J,cov. Unit-velocity conversion then gives rho_E=A⁴rho_J and p_E=A⁴p_J. Differentiating rho_E with dt_J=A dt_E and H_J=(H+L)/A yields

    dot rho_E+3H(rho_E+p_E)=L(rho_E-3p_E)+A⁵Q_J.

Both the positive trace sign and the fifth power of A follow from that chain rule. The extra A converts the physical proper-time rate. For any component, D=rho_E a_E⁴=rho_J a_J⁴ is frame invariant, but its general physical-time derivative is

    D'=a_J⁴[H_J(rho_J-3p_J)+Q_J].

For an exactly traceless isolated component this vanishes. For an isolated massive component it need not vanish; for photons exchanging energy it need not vanish either. A closed whole bath can therefore change D through its massive trace during expansion while its internal Q values sum to zero. This is not a direct scalar-to-photon production law. The original derivation correctly restricted equation (2) to traceless components; v2 makes the general identity explicit.

Two exact positive dust/radiation histories illustrate the information missing from total conservation. On the prescribed Jordan background a_J=exp(t_J/3), both start with rho_d=7/5, rho_r=2/9. One has J=0. The other takes the additional prescription J=rho_d/2, giving rho_d=(7/5)exp(-3t_J/2) and rho_r=exp(-4t_J/3)[2/9+(21/5)(1-exp(-t_J/6))]. Both obey the summed equation and have different D_r. They are conservation-only constructions, not solutions of the gravitational background equations or a derived microscopic decay model.

For the endpoint calculation, let R=(a_E,f/a_E,b)²=exp(2N). The same chosen component obeys rho_r,f=rho_r,b*zeta/R² by definition of zeta, and fixed spatial curvature gives kappa_f=kappa_b/R. Inserting these into the physical curvature diagnostic and the bare-Q/C expansion diagnostic gives

    d_J,f F_bare,f=R/(f_b zeta).

Positive f_b,zeta,epsilon and 1+delta permit the necessary inequality zeta>=R/[f_b epsilon(1+delta)]. Equality is allowed with the actual f_b. If only the strict bounce cap f_b<1/2 is used, then zeta>2R/[epsilon(1+delta)]. No conservation law in the intervening era was used in this identity. It does not produce a transfer mechanism or ensure that the two endpoints belong to a solution.

The imported initial cap requires a regular strict Einstein bounce, positive selected radiation, and nonnegative remaining enthalpy, with the selected initial component traceless. It is not a general bound for a finite-mass total bath: with initial p_b=w_b rho_b, the same pointwise argument gives f_b<2/[3(1+w_b)] for w_b>-1. For example w_b=1/5 gives 5/9. The source's ideal relativistic initial bath meets the tracefree limit, while a finite-temperature comparison needs its actual enthalpy. N>=0 compares Einstein radii; monotone expansion over the interval is not inferred. The final diagnostics also require a regular positive-density event with A_f>0 and Z_f nonzero.

The thermodynamic step introduces a specified equilibrium bath, physical temperature, zero chemical potentials and comoving entropy. Eliminating T a_J from rho=(pi²/30)g_*T⁴ and S=(2pi²/45)g_*s(T a_J)³ gives D proportional to g_*g_*s^(-4/3)S^(4/3). This proves equation (5), including the entropy exponent. The ultrarelativistic common-temperature limit has Ts=rho+p=4rho/3, so g_*s=g_* and equation (6) follows. Positive-power inversion gives the entropy lower bound in equation (7), with (g_f/g_b)^(1/4) in that direction. It does not derive S_f/S_b or assert adiabaticity.

At a finite mass threshold Ts=rho+p instead gives g_*s=(3/4)(1+w)g_*. A concrete equilibrium endpoint with w=1/5, g_*=10 has g_*s=9. With final g_*=g_*s=2 and constant S, the cube of the correct equation-(5) ratio is 6561/2000, whereas an improper ultrarelativistic substitution gives 5. Thus equation (6) cannot be extended to arbitrary threshold endpoints.

The electron/positron/photon count is supplied microscopic content. Within the assumed ideal Bose/Fermi distributions, the fermion weight 7/8 follows from the exact distribution identity B(x)-2B(2x)=F(x) and the x³ integral's 2^-4 scaling. This gives g_b=11/2 and g_f=2. Entropy conservation yields a temperature-times-scale-factor ratio (11/4)^(1/3). The total-bath charge includes the change in its energy coefficient and grows by (11/4)^(1/3); photon-only D has the same two-state coefficient at both endpoints and grows by (11/4)^(4/3).

At the initial endpoint f_gamma,b=(4/11)f_bath,b. Therefore f_gamma,b*zeta_gamma=f_bath,b*zeta_bath. The larger photon factor gives no larger endpoint budget when the component is matched correctly. Also f_bath,b<1/2 implies f_gamma,b<2/11 in this same ideal initial bath. Treating the photon fraction as independently close to one half would omit the pair contribution.

An exact mixed-component witness uses f_bath,b=2/5, R=6/5, epsilon=4/5, delta=0, requiring zeta>=15/4. The total factor fails because its cube is 11/4<(15/4)³. Incorrectly using the photon factor with the same total fraction falsely passes because (11/4)^4>(15/4)³. Correcting the photon fraction to8/55 restores failure and the equal product. This is an algebraic warning, not a cosmological fit.

As a conditional check of the budget, R>=1 and epsilon(1+delta)<=1 would require zeta>2 under the initial total-bath cap, while the single ideal adiabatic threshold has zeta_total³=11/4<8. It alone cannot meet that particular symbolic target. No observed epsilon/delta, abundance or likelihood is supplied by this implication.

## Execution history and adversarial controls

The handwritten derivation was saved before executable controls, SHA 5d16c526dfeb40fba8a4a1cada5c08bc3f69e67bf2f94b25d53da34d7ac950c5. No producer code/results, grids or previous independent code were read or imported.

Actual execution lineage is **63/2 → 65/0**, followed by **9/0** narrow source-correspondence checks. The first failures were in intended exact thermal corner comparisons: ordinary Python integer division introduced floats before SymPy saw four calls. Two exact equality checks failed; two finite-mass diagnostics had the same float contamination. Only those input literals changed to SymPy integers in check_independent_v2.py. The formulas, expected constants and exact-zero criterion were unchanged. CHECKER_REPAIR_v2.json and the complete diff preserve this repair; all original scripts, results, stdout and stderr remain. This was a checker defect, not a failed source equation, and the final 65/0 is not presented as the only run.

The independent controls include general symbolic chain rules; six rational points on two nonconstant conformal factors; the two transfer histories; exact endpoint inequalities; a nonadiabatic rational corner g_b/g_f=8, S_f/S_b=27/8, zeta=81/8; distribution identities; and the component/finite-mass domain witnesses. The first conformal factor A=2+t tests the general conformal identity and is not claimed as a candidate-action background. A second A=(2+t)/(3+2t) stays in C<1. Neither prescribed scale-factor history solves the gravitational equations.

Nine actual changed-formula copies of the repaired checker were executed. All exited 1 with their intended mathematical witnesses. Scripts, diffs, full outputs, result JSON and exact command records are preserved. These are targeted discrimination controls, not exhaustive verification.

| Actual damage | Passed/failed assertions | Intended witness |
|---|---:|---|
| exchange_A4 | 55/10 | `conformal.component_from_chain_rule` |
| trace_sign | 54/11 | `conformal.isolated_trace_sign` |
| missing_clock_conversion | 63/2 | `charge.radiation_J_time` |
| radius_power | 63/2 | `endpoint.direct_density_curvature_product` |
| inverted_charge_budget | 59/6 | `endpoint.charge_threshold` |
| entropy_power | 62/3 | `thermal.general_ratio_cubed` |
| bath_uses_photon_factor | 58/7 | `bath.total_charge_factor_cubed` |
| mixed_initial_fraction | 61/4 | `bath.same_component_product` |
| entropy_count_ratio_inverted | 62/3 | `thermal.entropy_requirement_fourth_power` |

## Source scope and evidence boundaries

The final source was read fully. Original equations (1)–(9) are unchanged; the general equation (2a) and ideal-limit qualification are the two additions. Seven source/snapshot pairs are bound below. The bounce-energy note is used only for its initial bound and stated endpoint premises; its implementation, results and trajectories were not accessed or rerun. The complete supplied action is preserved in the canonical local-response note, whose matter coupling is the only action input needed here.

These conclusions require consistent components, positive endpoint quantities, a specified bath and the stated thermodynamic approximations. Species content, chemical potentials, entropy history, microscopic interactions and quantum/finite-mass corrections are not fixed by universal metric coupling. Ideal endpoint limits do not supply controlled finite-T/m errors. No neutrino decoupling, QED correction, full particle history, state selector, scalar-induced decay, measured-gravity normalization, BBN fit or current observational tolerance is established.

| Source snapshot | SHA-256 |
|---|---|
| sources/01_DERIVATION_v1.md | `c5612e5b2b007b63b9f1e2ce5332561595fc5efad0d2224ac586b355df58df23` |
| sources/02_PROTOCOL_v1.json | `fabb244cd852aacd6ae293d6b9df77ebf67fa2abd3aadd584aa67b2dc5aad556` |
| sources/03_DERIVATION_v2.md | `b353fa284154aff687a1a80a41ea8d8d7b66ec6bf01c4391ead6ee46584d2a8d` |
| sources/04_EXPONENTIAL_SCALAR_LOCAL_RESPONSE_BOUNDED_THEOREM_NOTE_2026-10-13.md | `b4080f1e5c63109f66a4a8b15c2e4888c5331384654ddcbca5c9c0eb97a3cd68` |
| sources/05_DERIVATION_v2.md | `f4286e2ff5caa5d464e93a82d0abfe6b3adbb9ec8a4870ffbd7851c3955ffbde` |
| sources/06_TRACE_QUALIFICATION_v2.json | `ded10d2fa4264dadc5239d001d652a9ccaa333db2df79f74ed5a34bfd671674e` |
| sources/07_TRACE_QUALIFICATION_v2.diff | `f587a1a176d587c20dcfd342f48f9dd39eaa912dc2d3b72959070dc923dae6b7` |

Final files are REPORT_v1.md, MANIFEST_v1.json and RECEIPT_v1.json. The manifest binds all evidence except itself and the receipt; the receipt binds the manifest/report, source versions, repair lineage, commands and results. All writes were confined to this new independent_v1 directory. Prior receipts and parent sources remain untouched. No Git/PR, campaign runtime/lock, other-chat, audit or authority operation was performed.
