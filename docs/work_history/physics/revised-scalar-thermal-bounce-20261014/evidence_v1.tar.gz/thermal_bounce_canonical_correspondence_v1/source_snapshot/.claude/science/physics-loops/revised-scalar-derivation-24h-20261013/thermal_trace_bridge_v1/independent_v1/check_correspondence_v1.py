from pathlib import Path
import argparse,difflib,hashlib,json
p=Path(__file__).resolve().parent;checks=[]
def ck(n,ok,e):checks.append({'name':n,'passed':bool(ok),'evidence':e});print(('PASS ' if ok else 'FAIL ')+n)
meta=json.loads((p/'SOURCE_MANIFEST_v2.json').read_text());w=Path(meta['worktree'])
valid=[]
for r in meta['sources']:
 b=(w/r['original_path']).read_bytes();valid.append(b==(p/r['snapshot_path']).read_bytes() and len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'])
ck('source.seven_live_pairs',all(valid),{'pair_count':len(valid),'matches':valid})
v1=(p/'sources/01_DERIVATION_v1.md').read_text();v2=(p/'sources/05_DERIVATION_v2.md').read_text()
ck('source.original_hash',hashlib.sha256(v1.encode()).hexdigest()=='c5612e5b2b007b63b9f1e2ce5332561595fc5efad0d2224ac586b355df58df23',{'sha256':hashlib.sha256(v1.encode()).hexdigest()})
ck('source.final_hash',hashlib.sha256(v2.encode()).hexdigest()=='f4286e2ff5caa5d464e93a82d0abfe6b3adbb9ec8a4870ffbd7851c3955ffbde',{'sha256':hashlib.sha256(v2.encode()).hexdigest()})
diff=''.join(difflib.unified_diff(v1.splitlines(True),v2.splitlines(True),fromfile='DERIVATION_v1.md',tofile='DERIVATION_v2.md'))
ck('source.exact_diff',diff==(p/'sources/07_TRACE_QUALIFICATION_v2.diff').read_text(),{'computed_diff_sha256':hashlib.sha256(diff.encode()).hexdigest()})
ops=[o for o in difflib.SequenceMatcher(None,v1.splitlines(True),v2.splitlines(True)).get_opcodes() if o[0]!='equal']
ck('source.only_two_insertions',len(ops)==2 and all(o[0]=='insert' for o in ops),{'operations':ops})
old_eq=[l for l in v1.splitlines() if l.startswith('    ')];new_eq=[l for l in v2.splitlines() if l.startswith('    ') and '(2a)' not in l]
ck('source.original_equations_unchanged',old_eq==new_eq,{'original_indented_lines':len(old_eq)})
q=json.loads((p/'sources/06_TRACE_QUALIFICATION_v2.json').read_text())
ck('source.qualification_hashes',q['original_sha256']==hashlib.sha256(v1.encode()).hexdigest() and q['new_sha256']==hashlib.sha256(v2.encode()).hexdigest(),q)
old_results=json.loads((p/'runs/baseline_v1/RESULTS_v1.json').read_text());old_map={r['name']:r['passed'] for r in old_results['checks']}
ck('source.added_identity_independently_checked_in_original_run',old_map['charge.general_J_trace_plus_exchange'] and old_map['domain.finite_mass_not_ultra_ratio'],{'original_general_identity_check':'passed before source qualification was read','caution':'The original finite-mass diagnostic carried floats; the repaired run gives exact fractions. The general charge identity did not have that issue.','old_results_sha256':hashlib.sha256((p/'runs/baseline_v1/RESULTS_v1.json').read_bytes()).hexdigest()})
ck('source.ideal_endpoint_limits_explicit','not exact finite-temperature values at a specified T/m' in v2 and 'Finite-mass endpoint corrections require their actual distributions.' in v2,{'scope':'ideal thermal species/state assumptions remain supplied'})
passed=sum(x['passed'] for x in checks);failed=len(checks)-passed
parser=argparse.ArgumentParser();parser.add_argument('--result',required=True);ns=parser.parse_args()
Path(ns.result).write_text(json.dumps({'counts':{'passed':passed,'failed':failed,'total':len(checks)},'checks':checks,'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'narrow source-v2 correspondence; no producer checks read'},indent=2)+'\n')
print(f'TOTAL: PASS={passed} FAIL={failed}');raise SystemExit(bool(failed))
