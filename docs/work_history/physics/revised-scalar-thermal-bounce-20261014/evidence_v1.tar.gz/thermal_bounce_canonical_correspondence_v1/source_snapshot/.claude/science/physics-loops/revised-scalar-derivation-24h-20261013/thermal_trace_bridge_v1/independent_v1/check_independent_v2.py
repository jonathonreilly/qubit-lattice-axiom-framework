#!/usr/bin/env python3
"""Independent thermal/trace controls; no producer or prior-checker imports."""
from pathlib import Path
import argparse,hashlib,json,platform,sys
import sympy as S
R=S.Rational
records=[]
def equal(name,left,right):
 residual=S.factor(S.together(left-right))
 if residual!=0:residual=S.simplify(residual)
 ok=residual==0
 records.append({'name':name,'passed':bool(ok),'left':str(left),'right':str(right),'residual':str(residual)})
 print(('PASS ' if ok else 'FAIL ')+name+(' residual='+str(residual) if not ok else ''))
def check(name,ok,evidence):
 records.append({'name':name,'passed':bool(ok),'evidence':evidence});print(('PASS ' if ok else 'FAIL ')+name)

# Candidate formulas are checked against independent chain-rule/endpoint paths.
# Actual altered copies modify exactly one candidate expression each.
def component_rhs(A,L,rE,pE,QJ):
 return L*(rE-3*pE)+A**5*QJ
def physical_time_rate(E_rate,A):
 return E_rate/A
def endpoint_product(radius_sq,fb,zeta):
 return radius_sq/(fb*zeta)
def required_charge(radius_sq,fb,epsilon,delta):
 return radius_sq/(fb*epsilon*(1+delta))
def thermal_ratio(gb,gf,gsb,gsf,entropy_ratio):
 return (gf/gb)*(gsb/gsf)**R(4,3)*entropy_ratio**R(4,3)
def ultra_ratio(gb,gf,entropy_ratio):
 return (gb/gf)**R(1,3)*entropy_ratio**R(4,3)
def photon_ratio(gb,gf,entropy_ratio):
 return (gb/gf)**R(4,3)*entropy_ratio**R(4,3)
def photon_initial_fraction(fbath,gamma_states,gb):
 return fbath*gamma_states/gb
def required_entropy(charge_budget,gb,gf):
 return charge_budget**R(3,4)*(gf/gb)**R(1,4)

# Metric variation gives T_E,cov=A^2 T_J,cov and u_E=A u_J.
A,rJ,pJ,aE=S.symbols('A rhoJ pJ aE',positive=True)
H,L,QJ=S.symbols('H L QJ',real=True)
rE=A**4*rJ;pE=A**4*pJ;HJ=(H+L)/A;aJ=A*aE
rJ_prime=QJ-3*HJ*(rJ+pJ)
rE_dot=4*L*rE+A**5*rJ_prime
from_chain=rE_dot+3*H*(rE+pE)
equal('conformal.component_from_chain_rule',component_rhs(A,L,rE,pE,QJ),from_chain)
equal('conformal.isolated_trace_sign',component_rhs(A,L,rE,pE,0),L*(rE-3*pE))
equal('conformal.tracefree_exchange_factor',component_rhs(A,L,rE,rE/3,QJ),A**5*QJ)
equal('conformal.tracefree_isolation',component_rhs(A,L,rE,rE/3,0),0)
equal('charge.frame_invariance',rE*aE**4,rJ*aJ**4)
D_dot=aE**4*(rE_dot+4*H*rE)
equal('charge.general_E_trace_plus_exchange',D_dot,aE**4*((H+L)*(rE-3*pE)+A**5*QJ))
equal('charge.general_J_trace_plus_exchange',physical_time_rate(D_dot,A),aJ**4*(HJ*(rJ-3*pJ)+QJ))
D_rad_dot=S.factor(D_dot.subs(pJ,rJ/3))
equal('charge.radiation_E_time',D_rad_dot,aE**4*A**5*QJ)
equal('charge.radiation_J_time',physical_time_rate(D_rad_dot,A),aJ**4*QJ)
equal('charge.exchange_free_matter_sum',component_rhs(A,L,rE,pE,QJ)+component_rhs(A,L,2*rE,0,-QJ),L*(3*rE-3*pE))

# Nonconstant-A explicit histories; first tests the general identity, second
# stays in C<1, hence within the candidate coupling range at finite times.
t=S.symbols('t',nonnegative=True)
finite_points=[]
for label,At in [('generic_positive_A',2+t),('candidate_C_below_one',(2+t)/(3+2*t))]:
 at=1+t/3;rt=(5+t)/(1+t)**2;pt=R(2,7)*rt
 ht=S.diff(at,t)/at;lt=S.diff(At,t)/At;hjt=(ht+lt)/At
 qjt=S.diff(rt,t)/At+3*hjt*(rt+pt)
 re=At**4*rt;pe=At**4*pt
 lhs=S.diff(re,t)+3*ht*(re+pe)
 rhs=component_rhs(At,lt,re,pe,qjt)
 equal('finite_history.exact_'+label,lhs,rhs)
 for tv in [S.Integer(0),R(1,3),S.Integer(2)]:
  row={'type':label,'t':str(tv),'A':str(At.subs(t,tv)),'HJ':str(S.factor(hjt.subs(t,tv))),'QJ':str(S.factor(qjt.subs(t,tv))),'residual':str(S.factor((lhs-rhs).subs(t,tv)))}
  finite_points.append(row)
  check('finite_history.point_'+label+'_'+str(tv),S.factor((lhs-rhs).subs(t,tv))==0,row)
 if label=='candidate_C_below_one':
  equal('finite_history.positive_C_margin',1-At**2,((3+2*t)**2-(2+t)**2)/(3+2*t)**2)

# Total conservation leaves the component transfer undetermined.
h=R(1,3);a=S.exp(h*t);d0=R(7,5);r0=R(2,9)
dust0=d0*S.exp(-t);rad0=r0*S.exp(-4*t/3)
dust1=d0*S.exp(-3*t/2);rad1=S.exp(-4*t/3)*(r0+R(21,5)*(1-S.exp(-t/6)))
J1=dust1/2
for name,rd,rr,j in [('no_transfer',dust0,rad0,0),('decay_prescription',dust1,rad1,J1)]:
 equal('transfer.'+name+'.dust_balance',S.diff(rd,t)+3*h*rd,-j)
 equal('transfer.'+name+'.radiation_balance',S.diff(rr,t)+4*h*rr,j)
 equal('transfer.'+name+'.total_balance',S.diff(rd+rr,t)+3*h*(rd+R(4,3)*rr),0)
 equal('transfer.'+name+'.initial_dust',rd.subs(t,0),d0)
 equal('transfer.'+name+'.initial_radiation',rr.subs(t,0),r0)
equal('transfer.decay_charge_growth_derivative',S.diff(S.simplify(a**4*rad1),t),a**4*J1)
check('transfer.distinct_positive_charge_histories',S.simplify((a**4*(rad1-rad0)).subs(t,6*S.log(2)))==R(21,10),{'t':'6 log 2','charge_difference':'21/10','positive_dust_and_radiation':'All exponential densities are positive for t>=0; bracket 1-exp(-t/6)>=0.','scope':'prescribed common background, not a gravitational solution'})
equal('domain.closed_dust_charge_is_not_constant',S.diff(S.simplify(a**4*dust0),t),d0*S.exp(t/3)/3)

# Reconstruct endpoint products from densities/curvature rather than assume Eq3.
ab,af,kappab,rhob,Q,Zf,Af,fb,zeta=S.symbols('ab af kappab rhob Q Zf Af fb zeta',positive=True)
rhof=rhob*zeta*(ab/af)**4;kappaf=kappab*(ab/af)**2
Hjf=Zf/Af;rhofJ=rhof/Af**4
geom=kappaf/(Af**2*Hjf**2)
Fbare=3*Q*Hjf**2/(Af**2*rhofJ)
product=S.factor((geom*Fbare).subs(rhob,3*Q*kappab*fb))
equal('endpoint.direct_density_curvature_product',endpoint_product((af/ab)**2,fb,zeta),product)
equal('endpoint.conformal_factor_cancels',S.diff(product,Af),0)
Rs,eps,delta=S.symbols('radius_sq epsilon delta',positive=True)
budget=S.solve(S.Eq(Rs/(fb*zeta),eps*(1+delta)),zeta)[0]
equal('endpoint.charge_threshold',required_charge(Rs,fb,eps,delta),budget)
equal('endpoint.charge_threshold_gap',eps*(1+delta)-Rs/(fb*zeta),eps*(1+delta)*(zeta-required_charge(Rs,fb,eps,delta))/zeta)
# A strict bounce initial fraction gives a stronger universal budget, without
# changing the non-strict endpoint inequality with the actual f_b.
equal('endpoint.strict_bounce_margin',Rs/(fb*eps*(1+delta))-2*Rs/(eps*(1+delta)),Rs*(1-2*fb)/(fb*eps*(1+delta)))

# Thermodynamic elimination. Positive cubes remove all branch ambiguity.
gb,gf,gsb,gsf,Sratio,Temp,ascale,gs,gr,entropy=S.symbols('gb gf gsb gsf Sratio Temp ascale gs gr entropy',positive=True)
alpha=S.pi**2/30;beta=2*S.pi**2/45
D_direct=alpha*gr*Temp**4*ascale**4
S_direct=beta*gs*Temp**3*ascale**3
D_from_entropy=alpha*beta**(-R(4,3))*gr/gs**R(4,3)*S_direct**R(4,3)
equal('thermal.entropy_elimination',D_from_entropy,D_direct)
# Independently compare Df/Db with each endpoint entropy and density formula.
Db=alpha*gb*(S.Integer(1)/(beta*gsb))**R(4,3)
Df=alpha*gf*(Sratio/(beta*gsf))**R(4,3)
equal('thermal.general_ratio_cubed',thermal_ratio(gb,gf,gsb,gsf,Sratio)**3,(Df/Db)**3)
equal('thermal.ultrarelativistic_reduction_cubed',ultra_ratio(gb,gf,Sratio)**3,thermal_ratio(gb,gf,gb,gf,Sratio)**3)
w=S.symbols('w',real=True)
gs_from_enthalpy=S.solve(S.Eq(beta*gs,alpha*gr*(1+w)),gs)[0]
equal('thermal.finite_mass_enthalpy_relation',gs_from_enthalpy,R(3,4)*(1+w)*gr)
equal('thermal.massless_enthalpy_equality',gs_from_enthalpy.subs(w,R(1,3)),gr)
req=S.symbols('required_zeta',positive=True)
equal('thermal.entropy_requirement_fourth_power',required_entropy(req,gb,gf)**4,req**3*gf/gb)
equal('thermal.entropy_requirement_reproduces_budget',ultra_ratio(gb,gf,required_entropy(req,gb,gf))**3,req**3)
# Rational nonadiabatic corner: g ratio 8, entropy ratio 27/8 gives zeta81/8.
equal('thermal.rational_nonadiabatic_ratio',thermal_ratio(S.Integer(16),S.Integer(2),S.Integer(16),S.Integer(2),R(27,8)),R(81,8))
equal('thermal.rational_entropy_threshold',required_entropy(R(81,8),S.Integer(16),S.Integer(2)),R(27,8))
equal('thermal.rational_bounce_budget',required_charge(R(9,8),R(2,9),R(1,2),0),R(81,8))
equal('thermal.rational_target_saturation',endpoint_product(R(9,8),R(2,9),R(81,8)),R(1,2))
check('thermal.rational_underbudget_rejected',endpoint_product(R(9,8),R(2,9),S.Integer(8))>R(1,2),{'charge':8,'required_charge':'81/8','target_product':'1/2'})

# Statistics are explicitly supplied microscopic assumptions, not gravity outputs.
x=S.symbols('x',positive=True)
B=1/(S.exp(x)-1);Fermi=1/(S.exp(x)+1)
equal('statistics.fermion_boson_kernel',Fermi,B-2/(S.exp(2*x)-1))
weight=1-2*R(1,2)**4
equal('statistics.massless_fermion_weight',weight,R(7,8))
g_bath_b=2+weight*4;g_bath_f=S.Integer(2)
equal('statistics.initial_EM_bath_count',g_bath_b,R(11,2))
G=g_bath_b/g_bath_f
# Entropy conservation determines T*a ratio; use its cube and positivity.
Ta_ratio=G**R(1,3)
bath_from_def=(g_bath_f/g_bath_b)*Ta_ratio**4
photon_from_def=Ta_ratio**4
zbath=ultra_ratio(g_bath_b,g_bath_f,1);zphoton=photon_ratio(g_bath_b,g_bath_f,1)
equal('bath.total_charge_factor_cubed',zbath**3,bath_from_def**3)
equal('bath.photon_charge_factor_cubed',zphoton**3,photon_from_def**3)
equal('bath.photon_to_total_factor',zphoton/zbath,R(11,4))
f_bath=S.symbols('f_bath',positive=True)
f_gamma=photon_initial_fraction(f_bath,2,g_bath_b)
equal('bath.initial_photon_fraction',f_gamma,R(4,11)*f_bath)
equal('bath.same_component_product',f_gamma*zphoton,f_bath*zbath)
equal('bath.photon_initial_bounce_cap',photon_initial_fraction(R(1,2),2,g_bath_b),R(2,11))
# Exact false-success witness if total f_b is paired with photon-only zeta.
fbv=R(2,5);rv=R(6,5);epv=R(4,5);reqv=required_charge(rv,fbv,epv,0)
equal('domain.mixed_component_required_budget',reqv,R(15,4))
check('domain.total_bath_budget_fails',S.simplify(zbath**3)<reqv**3,{'zeta_total_cube':str(S.simplify(zbath**3)),'required_cube':str(reqv**3)})
check('domain.wrong_mixed_charge_falsely_passes',S.simplify(zphoton**3)>reqv**3,{'wrong_zeta_cube':str(S.simplify(zphoton**3)),'required_cube':str(reqv**3),'error':'Using total f_b with photon-only zeta'})
req_gamma=required_charge(rv,photon_initial_fraction(fbv,2,g_bath_b),epv,0)
check('domain.correct_photon_budget_also_fails',S.simplify(zphoton**3)<req_gamma**3,{'initial_photon_fraction':str(photon_initial_fraction(fbv,2,g_bath_b)),'correct_photon_budget':str(req_gamma),'actual_photon_factor_cube':str(S.simplify(zphoton**3))})
check('domain.ideal_threshold_below_required_two',S.simplify(zbath**3)<8,{'total_factor_cube':str(S.simplify(zbath**3)),'premises':'N>=0, epsilon(1+delta)<=1 and f_bath<1/2 imply required zeta>2; no empirical target supplied.'})
# A finite-mass equilibrium endpoint has g_s != g_* even at zero chemical potential.
finite_gs=gs_from_enthalpy.subs({w:R(1,5),gr:10})
true_massive=thermal_ratio(S.Integer(10),S.Integer(2),finite_gs,S.Integer(2),S.Integer(1))
wrong_ultra=ultra_ratio(S.Integer(10),S.Integer(2),S.Integer(1))
equal('domain.finite_mass_entropy_count',finite_gs,9)
check('domain.finite_mass_not_ultra_ratio',S.simplify(true_massive**3-wrong_ultra**3)!=0,{'g_star_b':10,'g_s_b':str(finite_gs),'w_b':'1/5','true_ratio_cube':str(S.simplify(true_massive**3)),'wrong_ultra_cube':str(S.simplify(wrong_ultra**3))})

parser=argparse.ArgumentParser();parser.add_argument('--result',required=True);args=parser.parse_args()
passed=sum(c['passed'] for c in records);failed=len(records)-passed
result={'scope':'Independent exact conformal/endpoint/thermal checks and explicit domain witnesses; no producer evidence','python':sys.version,'sympy':S.__version__,'platform':platform.platform(),'checker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'counts':{'passed':passed,'failed':failed,'total':len(records)},'checks':records,'finite_points':finite_points,'physical_claim_limit':'No solved gravitational background, microscopic interaction law, measured calibration or observational tolerance.'}
Path(args.result).write_text(json.dumps(result,indent=2)+'\n');print(f'TOTAL: PASS={passed} FAIL={failed}');raise SystemExit(bool(failed))
