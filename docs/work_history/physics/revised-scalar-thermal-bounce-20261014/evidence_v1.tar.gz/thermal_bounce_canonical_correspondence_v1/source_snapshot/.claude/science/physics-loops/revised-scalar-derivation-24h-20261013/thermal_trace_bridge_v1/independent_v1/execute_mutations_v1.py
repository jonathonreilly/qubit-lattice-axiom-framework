from pathlib import Path
import datetime,difflib,hashlib,json,os,subprocess,sys,time
p=Path(__file__).resolve().parent;src=(p/'check_independent_v2.py').read_text()
cases=[
('exchange_A4','L*(rE-3*pE)+A**5*QJ','L*(rE-3*pE)+A**4*QJ','conformal.component_from_chain_rule'),
('trace_sign','return L*(rE-3*pE)+A**5*QJ','return -L*(rE-3*pE)+A**5*QJ','conformal.isolated_trace_sign'),
('missing_clock_conversion','return E_rate/A','return E_rate','charge.radiation_J_time'),
('radius_power','return radius_sq/(fb*zeta)','return radius_sq**2/(fb*zeta)','endpoint.direct_density_curvature_product'),
('inverted_charge_budget','return radius_sq/(fb*epsilon*(1+delta))','return fb*epsilon*(1+delta)/radius_sq','endpoint.charge_threshold'),
('entropy_power','return (gf/gb)*(gsb/gsf)**R(4,3)*entropy_ratio**R(4,3)','return (gf/gb)*(gsb/gsf)**R(4,3)*entropy_ratio','thermal.general_ratio_cubed'),
('bath_uses_photon_factor','return (gb/gf)**R(1,3)*entropy_ratio**R(4,3)','return (gb/gf)**R(4,3)*entropy_ratio**R(4,3)','bath.total_charge_factor_cubed'),
('mixed_initial_fraction','return fbath*gamma_states/gb','return fbath','bath.same_component_product'),
('entropy_count_ratio_inverted','return charge_budget**R(3,4)*(gf/gb)**R(1,4)','return charge_budget**R(3,4)*(gb/gf)**R(1,4)','thermal.entropy_requirement_fourth_power')]
(p/'mutations/PROTOCOL_v1.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_checker':'check_independent_v2.py','base_sha256':hashlib.sha256(src.encode()).hexdigest(),'scope':'Actual single-expression changed copies; expected mathematical witnesses fixed before execution.','cases':[{'name':n,'old':o,'new':v,'intended_witness':wit} for n,o,v,wit in cases]},indent=2)+'\n')
records=[];env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
for n,old,new,wit in cases:
 assert src.count(old)==1,(n,src.count(old));d=p/'mutations'/n;assert not d.exists();d.mkdir()
 changed=src.replace(old,new);f=d/'check_damaged.py';f.write_text(changed)
 (d/'SOURCE.diff').write_text(''.join(difflib.unified_diff(src.splitlines(True),changed.splitlines(True),fromfile='check_independent_v2.py',tofile=n+'/check_damaged.py')))
 argv=[sys.executable,'-B',str(f),'--result',str(d/'RESULTS_v1.json')]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();tic=time.monotonic();r=subprocess.run(argv,cwd=p,env=env,capture_output=True,timeout=90)
 (d/'stdout.txt').write_bytes(r.stdout);(d/'stderr.txt').write_bytes(r.stderr)
 result=json.loads((d/'RESULTS_v1.json').read_text()) if (d/'RESULTS_v1.json').exists() else None
 failed=[x['name'] for x in result['checks'] if not x['passed']] if result else []
 record={'name':n,'argv':argv,'cwd':str(p),'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':time.monotonic()-tic,'exit_code':r.returncode,'script_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'counts':result['counts'] if result else None,'intended_witness':wit,'failed_witnesses':failed,'detected':r.returncode==1 and wit in failed,'runtime_error':result is None}
 (d/'COMMAND_v1.json').write_text(json.dumps(record,indent=2)+'\n');records.append(record)
 print(json.dumps({k:record[k] for k in ['name','counts','exit_code','detected','failed_witnesses']}))
(p/'mutations/RESULTS_v1.json').write_text(json.dumps({'actual_executions':len(records),'detected':sum(x['detected'] for x in records),'undetected':sum(not x['detected'] for x in records),'cases':records},indent=2)+'\n')
raise SystemExit(any(not x['detected'] for x in records))
