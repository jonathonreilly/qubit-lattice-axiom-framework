from pathlib import Path
import datetime,hashlib,json
p=Path(__file__).resolve().parent
assert not (p/'MANIFEST_v1.json').exists() and not (p/'RECEIPT_v1.json').exists()
def sha(b):return hashlib.sha256(b).hexdigest()
def ref(n):
 b=(p/n).read_bytes();return {'path':n,'bytes':len(b),'sha256':sha(b)}
meta=json.loads((p/'SOURCE_MANIFEST_v2.json').read_text());w=Path(meta['worktree'])
for r in meta['sources']:
 f=w/r['original_path'];b=f.read_bytes();assert f.is_file() and not f.is_symlink()
 assert b==(p/r['snapshot_path']).read_bytes() and len(b)==r['bytes'] and sha(b)==r['sha256'],r
runpaths=['baseline_v1','baseline_v2','correspondence_v1'];expected=[(63,2,1),(65,0,0),(9,0,0)];runs=[]
for name,(pas,fail,code) in zip(runpaths,expected):
 path='runs/'+name;r=json.loads((p/path/'RESULTS_v1.json').read_text());c=json.loads((p/path/'COMMAND_v1.json').read_text())
 assert r['counts']=={'passed':pas,'failed':fail,'total':pas+fail} and c['exit_code']==code
 assert sha((p/path/'stdout.txt').read_bytes())==c['stdout_sha256']
 assert sha((p/path/'stderr.txt').read_bytes())==c['stderr_sha256']
 checker=Path(c['argv'][2]);assert checker.parent==p and sha(checker.read_bytes())==c['checker_sha256']==r['checker_sha256']
 runs.append({'name':name,'counts':r['counts'],'exit_code':code,'checker':ref(checker.name),'command':ref(path+'/COMMAND_v1.json'),'results':ref(path+'/RESULTS_v1.json'),'stdout':ref(path+'/stdout.txt'),'stderr':ref(path+'/stderr.txt')})
repair=json.loads((p/'CHECKER_REPAIR_v2.json').read_text());old=(p/'check_independent_v1.py').read_text();changed=old
for before,after in repair['changes']:
 assert changed.count(before)==1;changed=changed.replace(before,after)
assert changed==(p/'check_independent_v2.py').read_text()
assert sha(old.encode())==repair['old_checker_sha256'] and sha(changed.encode())==repair['new_checker_sha256']
mut=json.loads((p/'mutations/RESULTS_v1.json').read_text());assert mut['actual_executions']==9 and mut['detected']==9 and mut['undetected']==0
for x in mut['cases']:
 d=p/'mutations'/x['name'];assert x['exit_code']==1 and x['intended_witness'] in x['failed_witnesses']
 assert sha((d/'check_damaged.py').read_bytes())==x['script_sha256']
 assert sha((d/'stdout.txt').read_bytes())==x['stdout_sha256'] and sha((d/'stderr.txt').read_bytes())==x['stderr_sha256']
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
(p/'FINAL_SOURCE_IDENTITY_v1.json').write_text(json.dumps({'created_utc':now,'source_pair_count':len(meta['sources']),'all_live_snapshot_hash_size_pairs_match':True,'pairs':meta['sources'],'source_v1_preserved':True,'final_source_sha256':meta['sources'][4]['sha256'],'exact_four_input_repair_matches_saved_diff_lineage':True,'all_twelve_run_code_stdout_stderr_bindings_verified':True,'writes_outside_new_folder':False},indent=2)+'\n')
artifacts=[]
for f in sorted(p.rglob('*')):
 if f.is_dir():continue
 assert f.is_file() and not f.is_symlink(),str(f)
 artifacts.append(ref(str(f.relative_to(p))))
manifest={'schema':'focused-independent-mathematical-check-manifest-v1','created_utc':now,'artifact_root':str(p),'artifact_count':len(artifacts),'excludes':['MANIFEST_v1.json','RECEIPT_v1.json'],'artifacts':artifacts}
(p/'MANIFEST_v1.json').write_text(json.dumps(manifest,indent=2)+'\n')
receipt={'schema':'focused-independent-mathematical-check-receipt-v1','created_utc':now,'unit':'thermal_trace_bridge_v1/independent_v1','scientific_author':'/root','independent_checker':'/root/scalar_energy_check','formal_audit':False,'formal_grade_assigned':False,'landing_authority':False,'original_source_sha256':meta['sources'][0]['sha256'],'final_source':'DERIVATION_v2.md','final_source_sha256':meta['sources'][4]['sha256'],'source_pair_count':len(meta['sources']),'source_bindings':meta['sources'],'source_manifest_original':ref('SOURCE_MANIFEST_v1.json'),'source_manifest_final':ref('SOURCE_MANIFEST_v2.json'),'manifest':ref('MANIFEST_v1.json'),'report':ref('REPORT_v1.md'),'hand_derivation':ref('HAND_DERIVATION_v1.md'),'protocol':ref('PROTOCOL_INDEPENDENT_v1.json'),'findings':ref('FINDINGS_v1.json'),'failure_ledger':ref('FAILURES_v1.json'),'command_index':ref('COMMAND_INDEX_v1.json'),'scope_and_access':ref('ACCESS_AND_SCOPE_v1.json'),'initial_endpoint_domain_note':ref('INITIAL_ENDPOINT_DOMAIN_NOTE_v1.md'),'final_source_identity':ref('FINAL_SOURCE_IDENTITY_v1.json'),'actual_execution_lineage':runs,'checker_repair':{'record':ref('CHECKER_REPAIR_v2.json'),'diff':ref('CHECKER_V1_V2.diff'),'scope':'Four numeric call inputs changed from Python int to SymPy Integer; no formula, expected value or exact-equality target changed.','original_failures_preserved':True,'original_counts':{'passed':63,'failed':2,'total':65},'repaired_counts':{'passed':65,'failed':0,'total':65}},'actual_damaged_controls':{'protocol':ref('mutations/PROTOCOL_v1.json'),'results':ref('mutations/RESULTS_v1.json'),'actual_executions':9,'detected':9,'undetected':0,'cases':[{'name':x['name'],'counts':x['counts'],'intended_witness':x['intended_witness'],'command':ref('mutations/'+x['name']+'/COMMAND_v1.json'),'source':ref('mutations/'+x['name']+'/check_damaged.py'),'diff':ref('mutations/'+x['name']+'/SOURCE.diff')} for x in mut['cases']]},'final_source_correspondence':{'same_session_full_source_read':True,'only_changes':'Two insertions: general nontraceless component identity (2a) and ideal finite-T endpoint limitation.','original_equations_1_to_9_unchanged':True,'independent_general_identity_in_original_run':True,'correspondence_counts':{'passed':9,'failed':0,'total':9},'further_source_correction_needed':False},'checked_scope':['Conformal density/time/scale conversion and A^5 exchange factor','Trace-free conserved charge versus general bath trace contribution','Total Ward conservation versus undetermined internal component transfer','Endpoint charge-growth budget under imported initial Einstein-bounce assumptions','Positive entropy factor and inverse, thermodynamic endpoint domain','Ideal total-bath/photon exponents and matching initial fractions','Source-v2 qualification correspondence and preserved verifier failure lineage'],'reused_input_boundary':{'bounce_source':meta['sources'][2],'scope':'Only imported strict initial f_b<1/2 and endpoint theorem premises; no implementation/results or prior trajectories read or rerun.'},'limits':['No microscopic interaction, species content, thermal distribution or initial state derived from universal metric coupling.','No solved gravitational history, full thermal transfer history or self-consistent reheating construction.','Ideal thermal endpoint factors are not exact finite-temperature corrections.','No BBN/abundance likelihood, measured gravity calibration or current observational tolerance.','Finite checks supplement the handwritten conditional proofs; no formal audit or authority status.'],'mutations':{'writes_confined_to_new_independent_folder':True,'parent_sources_or_prior_seals_changed':False,'git_PR_runtime_lock_or_audit_state_changed':False,'other_chats_messaged':False,'subagents_spawned':False}}
(p/'RECEIPT_v1.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'artifact_count':len(artifacts),'total_files':len(artifacts)+2,'source_pair_count':len(meta['sources']),'sealed':{n:ref(n) for n in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json']}},indent=2))
