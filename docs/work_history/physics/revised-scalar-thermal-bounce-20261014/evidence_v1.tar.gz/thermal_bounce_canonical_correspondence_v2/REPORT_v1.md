# Affected thermal canonical v2 correspondence

Reviewer: `/root/direct_field_check`. Scientific author: `/root`.

The added Part IV, new joint function and caller, and changed explanatory text preserve the source argument and its stated limits. No scientific or output-loss discrepancy was found in this extension. Parts I–III and all four previously checked functions remain unchanged. The new source is a substantive strengthening within its stated hypotheses; it does not replace the earlier valid coarse inequalities with different action or matter premises.

The reviewer execution completed **1,332 passed, 0 failed**: 609 affected correspondence checks, 150 input identities, 557 prior/new seal identities, eight recorded-damage checks, and **eight new exact-rational coefficient checks**. These categories are not 1,332 independent scientific theorems. The author's **554/0** and the separate joint reviewer's **64/0** are reused actual evidence. No producer science, earlier science checker, gas quadrature or cosmological history was rerun by this reviewer.

## Exact scope and preservation

The affected capture contains 146 distinct original/snapshot pairs: 61 initial inputs and 85 files captured after the joint independent seal became final. The prior canonical correspondence remains immutable at receipt `045e72aa80bf3a948153c41b0461f6fbd25eaab08de8dcb328ad7d8a3a613f34`. Its entire 464-artifact manifest, exact 466-file inventory and report/manifest bindings were verified without writing to it.

The final identities are:

| Source | SHA-256 |
| --- | --- |
| Canonical v2 note | `99132f4ef16f74c4d1a3b123fb04f364c4ef4f6b2e55d6b90118d46de02b762e` |
| Canonical v2 runner | `dc239acc7df08678984d60e21b7cafa1f7f6b7cfa8d328539a5b7fd9a81a91ad` |
| Actual 554/0 cache | `d8043fc62f7c1f9b818dea6f6906a22c26286e87b9ddaff443ceee5f8f55dd7a` |
| Joint source DERIVATION_v1 | `3ed757fa354fa6ab550d7c4225b62d13d4e3787d7aae0fd730aff9a595aa95e8` |
| Joint source checker | `00101d1eaf4d41877582ddd482ebb917e5186eaa35831100751312877f566bd5` |
| Joint independent receipt | `7210514677660e0142b1378b68cbf20bee856153a10c2701d24aa48a0556cb00` |

The three superseded canonical paths are explicitly mapped in `SUPERSEDED_CANONICAL_DISPOSITIONS_v1.json`. Their former note, runner and cache hashes remain `e3ea8ccbfb4137e6640abe704f458a658e4148dfee4715727f8c4b385840845c`, `39fd1c93bef6a1399dcfb914c9faad68168b7c03f89cad4c1a9d2447a978a4b9`, and `5d81d91d01bb14846c6cf7c503997a23c28ff1f910a3bc04dcad1bf62dbd94f9`. The parent's `canonical_v1` copies equal the immutable earlier review copies byte-for-byte. Each row names those exact recoveries and the new final hash.

The complete final `original_dispositions_v3.json` contains **560 distinct path/hash identities**: 425 inherited identities plus 146 affected captures, deduplicating 11 identical pairs. A canonical path can appear at both preserved versions. Ten inherited destination hashes change: the three canonical originals and seven unchanged source proof/checker bodies whose canonical destination now contains Part IV. The other 415 inherited destinations retain their previous identity. This is recovery/correspondence bookkeeping, not a claim that 560 files were newly reread as scientific arguments.

## Changed proof and code

I read the full new derivation, protocol and standalone checker; the complete new canonical part/function/caller; every changed narrative paragraph; and the final independent report, hand derivation, failure ledger and wrapper-repair record. The complete old I–III text equals the prior canonical text. All four old function texts and ASTs equal their prior versions. The entire remaining program AST is unchanged after removing the one new function and final loop entry.

The complete new proof body equals Part IV after only removal of its first heading and nesting of internal headings. The complete new mathematical body equals the function body after indentation and exclusion of the new return. Its normalized body hash is `64fc19027763017dfb43447a77a34830d77646ac3e52fa1165961059e68fac8f`. The actual note and runner diffs equal the parent's saved diffs, so the reviewed changes are not merely selected excerpts.

The standalone checker read a prior finite-mass result file. The canonical function instead takes `prior`, and its only new caller is `lambda:check_joint_entropy(outputs['finite_mass'])` after the finite-mass block executes. The main loop has already stored that invocation's finite-mass output. The joint function reads its grid and analytic endpoint values and does not mutate them. The old science functions, imports, main aggregation, error exit and output-writing behavior are otherwise unchanged.

This interface change intentionally removes standalone file-I/O/hash wrapper fields from the joint return. The old `prior_results_sha256` is still preserved in the complete standalone result, resolves to the exact earlier finite-mass result, and is separately checked here. The freshly computed canonical grid and analytic endpoints equal those standalone prior inputs exactly. Thus the new caller is tied to the actual current invocation, while its source-development provenance remains recoverable. No observational file is introduced.

## Complete saved-result comparison

The new total is **27 trace + 8 general trace + 229 finite mass + 14 calibration + 276 joint = 554**. The general-trace block remains its own 8/0 calculation, distinct from the original 27/0. All previous 278 check objects and every prior substantive output remain exactly equal to the v1 cache. All 276 new check objects equal the standalone joint result after only adding the unit-name prefix. Comparisons retain JSON types and binary64 values, including signed zero, rather than accepting an approximate agreement.

The original 61-node grid, four per-node integration error estimates, seven alternate quadrature records and three calibration examples remain intact. The added block preserves all 61 postprocessing rows, seven occupation-entropy integral records with estimates, six derivative check records, and all four displayed constants. The all-final-temperature checks retain the maximum over the source's 61 possible final nodes for each bounce node; they are not misrepresented as a newly serialized 3,721-row table or a proof by finite sampling.

The new bare coefficient is approximately 1.427531711007216, the matched calibrated coefficient is approximately 1.070648783255412, and the displayed unit-target eta ceiling is approximately 0.070648783255412. These are exact-formula evaluations under explicit inputs, not fitted uncertainties or observations. The source's seven fresh entropy integrals were executed by the author; their unchanged saved values are compared here, not recomputed.

Unlike v1, the v2 packaging record preserves the actual API result. Its raw stdout is 112,545 characters, below the cache utility's 200,000-character limit; its raw stderr is empty. The cache's newline-framed streams equal those actual returned streams. The result records exit 0, 120-second bound and elapsed 0.8517329692840576 seconds; the header rounds elapsed time to 0.85. The cached and stdout self-source hashes agree. Independent length-prefixed hashing of the three declared inputs gives `db4b0fd157996eb7fd707095d5c94dd376e0ff229e8d324fcd1f0621df3c2b3e`, exactly the header fingerprint. The old TypeError recovery is preserved and is not retroactively recast as a successful original API-return serialization.

## Mathematical interaction and limitations

The independent joint review supplies the new analytic occupation-entropy argument. Its complete report and hand derivation were read, and its 79 manifest artifacts, exact 81-file inventory, report/manifest pins and six source pairs were verified. The report hash is `e27c3d014726ac35a947b3d27e460f2b185f2f494d725f0e268ab4f75d881b5f`; the manifest hash is `2d8c1fa37f8a63cec5e60cf083ed3696f1bf6629d2458ee21a4e199904fc92e3`. It independently checked the new proof from the source without reading the producer checker/results and reused the earlier finite-mass seal by identity.

The key correlation is the zero-chemical-potential Gibbs identity

    (1+w_b)G_b = h_b^(-1/3),  h=s/T^3.

For the stipulated Fermi occupations, the complete hole entropy gives partial_x H_F=-x f(1-f)<0. Integration by parts with vanishing endpoint terms identifies that occupation entropy with (rho+p)/T^4. This provides h_b<=h_hot, while the earlier gas theorem supplies G_f<=G_cold. Combining those inequalities with the strict same-bath bounce cap gives

    f_b zeta < (2/3) sigma^(4/3) G_f h_b^(1/3)
              <= (R/2) sigma^(4/3).

The hot relation G_hot=(3/4)h_hot^(-1/3) is the extra factor missing from separate coarse maximization. Inverting positive quantities gives the new bare coefficient 2/R. Dividing by the explicitly adopted positive same-background calibration ceiling gives 3/[2R(1+eta)], retaining the entropy factor. The finite-state/finite-grid calculations are checks of this implementation; the uniform bound is supplied by the analytic proof, not inferred from the grid.

Eight new standard-library rational checks independently verify the cubed correlated cap, bare and calibrated coefficient cubes 32/11 and 27/22, both improvement ratios (4/3)^3, the unit radius-cap cube 22/27<1, the distinct-background threshold reduction to 3/4 of its old value, and the inconsistency of choosing w_b=0 and G_b=G_hot while keeping h_b<=h_hot. These are narrow coefficient/interdependency checks, not a replacement for the sealed proof or a new thermodynamic integration.

The new result closes the apparent coarse coefficient-below-one possibility only in the stated same-background ideal-bath/calibration domain. It does not assert that the older coarse bound was false, that its loose limit was physically attained, or that any actual observed body supplies the assumed calibration. The particle content and degeneracies, ideal statistics, zero chemical potentials, common positive physical temperature, fixed mass, equilibrium endpoints, entropy allowance/isolation, strict Einstein bounce, positive kinetic/nonnegative other enthalpy, final regular Z and radius ordering remain explicit. A nonzero chemical potential changes both the entropy derivative and Gibbs relation. General baths require their own analogous entropy/G hypotheses and positive massless cold content.

The threshold below one permits the earlier negative-u energy theorem; at threshold one strict above-vacuum energy remains but no uniform positive gap follows; above one no negative-u restriction follows from this threshold alone. The original corrected Part III wording remains in the canonical note. The product target is only necessary for its separate diagnostics. No endpoint-temperature ordering or monotone conformal factor is imposed, but neither is a connecting thermal/gravity history constructed. No action/state/scale selection, reaction rate, observed abundance, likelihood, arbitrary-body theorem, empirical acceptance, general Jordan-bounce obstruction or formal grade promotion is introduced.

## Actual failures and version accounting

All earlier author/reviewer failures remain in the immutable v1 seal and its captured source evidence, including the post-cache tuple/Path serialization failure and pre-science general-trace NameError. The parent's new `PARENT_INSPECTION_FAILURE_v1.json` preserves its guessed disposition filename failure, with no science executed or reviewer artifact changed.

The joint independent review preserved a mutation-wrapper unique-match assertion: the fourth target was a prefix present in two return lines. Its guard stopped before an unintended edit. The already completed 64/0 baseline and first three actual damages remain unchanged; the separate repaired wrapper ran only the remaining five cases. All eight actual damaged implementations failed their intended witnesses. The wrapper failure and repair are not relabeled as a second clean scientific execution.

The four new producer damages are also retained and their exact source changes, result source hashes, failure names, counts and exit 1 verified: 274/2, 274/2, 275/1 and 237/39. The producer's case named `decoupled_pressure_entropy` changes the factor 2/3 to 1/2. It is distinct from the independent review's dropped-correlated-hot-factor mutation, which restores a valid coarse weakening but fails the claimed joint identity/improvement. Neither control establishes that the old coarse theorem was invalid.

No new reviewer execution failed in this affected unit. One pre-seal metadata semantics defect was found during disposition inspection: three inherited `original_remains_unchanged` flags incorrectly remained true for superseded live canonical paths. Their original hashes, recovery bytes and final hashes were already correct. `original_dispositions_v2.json` remains unchanged; separately versioned v3 corrects only those three flags, explicitly retains the old bytes, and records the correction in `DISPOSITION_FLAG_CORRECTION_v1.json`. The executed metadata script and both maps are preserved. This correction changed no science, source, checksum, recovery or prior seal.

Final evidence is linked by `COMMAND_INDEX_v2.json`, `FAILURE_LEDGER_v2.json`, `AFFECTED_RESULTS_v1.json`, the 560-row disposition map and final manifest/receipt. Only this new review directory was written. Previous seals, parent source, Git, runtime/locks, PRs, models and audit state were unchanged. The final filenames are `REPORT_v1.md`, `MANIFEST_v1.json` and `RECEIPT_v1.json`; the manifest excludes only itself and the receipt. This is a pre-packaging correspondence seal, not a committed-tree or archive delivery confirmation.
