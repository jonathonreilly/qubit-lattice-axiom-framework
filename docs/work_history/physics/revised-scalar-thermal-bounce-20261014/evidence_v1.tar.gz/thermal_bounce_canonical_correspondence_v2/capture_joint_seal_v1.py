#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

HERE = Path(__file__).resolve().parent
PACK = HERE.parent
ROOT = Path(str(PACK).split('/.claude/')[0])
UNIT = PACK / 'thermal_trace_bridge_v1/finite_mass_bounce_bound_v1/joint_entropy_bounce_v1/independent_v1'
SNAP = HERE / 'source_snapshot'
pins = {'REPORT_v1.md': 'e27c3d014726ac35a947b3d27e460f2b185f2f494d725f0e268ab4f75d881b5f', 'MANIFEST_v1.json': '2d8c1fa37f8a63cec5e60cf083ed3696f1bf6629d2458ee21a4e199904fc92e3', 'RECEIPT_v1.json': '7210514677660e0142b1378b68cbf20bee856153a10c2701d24aa48a0556cb00'}
for name, expected in pins.items():
    assert hashlib.sha256((UNIT / name).read_bytes()).hexdigest() == expected
receipt = json.loads((UNIT / 'RECEIPT_v1.json').read_text())
files = {p for p in UNIT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc'}
files.update(ROOT / row['original_path'] for row in receipt['source_bindings'])
rows, existing = [], []
for source in sorted(files):
    data = source.read_bytes(); target = SNAP / source.relative_to(ROOT)
    record = {'original_path': str(source), 'snapshot': str(target), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    if target.exists():
        assert target.read_bytes() == data
        existing.append(record)
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as f:
            f.write(data)
        rows.append(record)
record = {'created_utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Final joint independent seal and exact dependencies; existing initial source copies verified unchanged', 'inputs': rows, 'existing_inputs_verified': existing, 'count': len(rows), 'final_seal_pins': pins, 'capture_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with (HERE / 'JOINT_SEAL_CAPTURE_v1.json').open('x') as f:
    json.dump(record, f, indent=2); f.write('\n')
print(json.dumps({'new_files': len(rows), 'existing_inputs_verified': len(existing)}))
