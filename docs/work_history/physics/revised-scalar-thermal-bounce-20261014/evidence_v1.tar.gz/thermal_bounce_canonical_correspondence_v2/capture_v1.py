#!/usr/bin/env python3
"""Freeze affected thermal v2 inputs only; previous seal remains read-only."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

HERE = Path(__file__).resolve().parent
PACK = HERE.parent
ROOT = Path(str(PACK).split('/.claude/')[0])
OLD = PACK / 'thermal_bounce_canonical_correspondence_v1'
JOINT = PACK / 'thermal_trace_bridge_v1/finite_mass_bounce_bound_v1/joint_entropy_bounce_v1'
SNAP = HERE / 'source_snapshot'
pins = {
    ROOT / 'docs/EXPONENTIAL_SCALAR_THERMAL_BOUNCE_BOUNDED_THEOREM_NOTE_2026-10-14.md': '99132f4ef16f74c4d1a3b123fb04f364c4ef4f6b2e55d6b90118d46de02b762e',
    ROOT / 'scripts/exponential_scalar_thermal_bounce_check.py': 'dc239acc7df08678984d60e21b7cafa1f7f6b7cfa8d328539a5b7fd9a81a91ad',
    JOINT / 'DERIVATION_v1.md': '3ed757fa354fa6ab550d7c4225b62d13d4e3787d7aae0fd730aff9a595aa95e8',
    OLD / 'REPORT_v1.md': '3445230e3ed9e033aa062195bb1d73b5e9526a1d7c07d5f1fa2fee8c4ed2716c',
    OLD / 'MANIFEST_v1.json': '37a5be7980c6aeb6433f5066a11399f36cdf9ab4f5f78ba004fc59d88a2cb792',
    OLD / 'RECEIPT_v1.json': '045e72aa80bf3a948153c41b0461f6fbd25eaab08de8dcb328ad7d8a3a613f34'
}
files = set(pins)
files.add(ROOT / 'logs/runner-cache/exponential_scalar_thermal_bounce_check.txt')
files.add(ROOT / 'scripts/runner_cache.py')
files.add(ROOT / 'docs/EXPONENTIAL_SCALAR_FUTURE_CONFINEMENT_BOUNDED_THEOREM_NOTE_2026-10-13.md')
files.add(ROOT / 'docs/EXPONENTIAL_SCALAR_PHYSICAL_PAST_BOUNDED_THEOREM_NOTE_2026-10-14.md')
for base in (PACK / 'thermal_bounce_packaging', JOINT):
    for p in base.rglob('*'):
        rel = p.relative_to(base)
        if p.is_file() and 'independent_v1' not in rel.parts and '__pycache__' not in rel.parts and p.suffix != '.pyc':
            files.add(p)
rows = []
for p in sorted(files):
    data = p.read_bytes(); digest = hashlib.sha256(data).hexdigest()
    if p in pins:
        assert digest == pins[p], str(p)
    target = SNAP / p.relative_to(ROOT)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as f:
        f.write(data)
    rows.append({'original_path': str(p), 'snapshot': str(target), 'bytes': len(data), 'sha256': digest})
record = {'created_utc': datetime.now(timezone.utc).isoformat(), 'scope': 'Affected thermal canonical v2 inputs and exact previous seal references; joint independent final seal captured separately when available', 'inputs': rows, 'count': len(rows), 'excluded': ['pending joint independent_v1 tree', '__pycache__ and pyc'], 'producer_execution': False, 'capture_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with (HERE / 'INPUT_FREEZE_v1.json').open('x') as f:
    json.dump(record, f, indent=2); f.write('\n')
print(json.dumps({'captured': len(rows), 'bytes': sum(r['bytes'] for r in rows), 'originals_mutated': False}))
