#!/usr/bin/env python3
"""Independent affected-only correspondence; never import or execute producer code."""
from pathlib import Path
from fractions import Fraction as F
from datetime import datetime, timezone
import ast
import copy
import difflib
import hashlib
import json
import re
import textwrap

HERE = Path(__file__).resolve().parent
SNAP = HERE / 'source_snapshot'
PACK_REL = Path('.claude/science/physics-loops/revised-scalar-derivation-24h-20261013')
PACK = SNAP / PACK_REL
OLD = HERE.parent / 'thermal_bounce_canonical_correspondence_v1'
OLD_SNAP = OLD / 'source_snapshot'
ROOT = Path(str(HERE).split('/.claude/')[0])
PACKAGE = PACK / 'thermal_bounce_packaging'
JOINT_REL = PACK_REL / 'thermal_trace_bridge_v1/finite_mass_bounce_bound_v1/joint_entropy_bounce_v1'
JOINT = SNAP / JOINT_REL
FM_REL = JOINT_REL.parent
NOTE = Path('docs/EXPONENTIAL_SCALAR_THERMAL_BOUNCE_BOUNDED_THEOREM_NOTE_2026-10-14.md')
RUNNER = Path('scripts/exponential_scalar_thermal_bounce_check.py')
CACHE = Path('logs/runner-cache/exponential_scalar_thermal_bounce_check.txt')
rows, details = [], {}

def load(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def hashtext(s):
    return hashlib.sha256(s.encode()).hexdigest()

def check(name, condition, evidence=None, category='affected_correspondence'):
    item = {'name': name, 'passed': bool(condition), 'category': category}
    if evidence is not None:
        item['evidence'] = evidence
    rows.append(item)

def typed(value):
    if isinstance(value, dict):
        return ('dict', tuple((k, typed(v)) for k, v in sorted(value.items())))
    if isinstance(value, list):
        return ('list', tuple(map(typed, value)))
    return (type(value).__name__, value.hex() if type(value) is float else value)

def identity(path, item):
    return path.stat().st_size == item['bytes'] and sha(path) == item['sha256']

def parse_cache(path):
    header, rest = path.read_text().split('----- stdout -----\n', 1)
    stdout, stderr = rest.split('----- stderr -----\n', 1)
    hdr = dict(line.split(': ', 1) for line in header.splitlines() if ': ' in line)
    return hdr, stdout, stderr, json.loads(stdout)

def verify_seal(name, folder, receipt_pin):
    receipt = load(folder / 'RECEIPT_v1.json'); manifest = load(folder / 'MANIFEST_v1.json')
    check(name + '_receipt_pin', sha(folder / 'RECEIPT_v1.json') == receipt_pin, category='seal_identity')
    for k in ('report', 'manifest'):
        check(name + '_' + k, identity(folder / receipt[k]['path'], receipt[k]), category='seal_identity')
    for i, item in enumerate(manifest['artifacts']):
        check(f'{name}_artifact_{i}', identity(folder / item['path'], item), item['path'], 'seal_identity')
    actual = {str(f.relative_to(folder)) for f in folder.rglob('*') if f.is_file()}
    expected = {r['path'] for r in manifest['artifacts']} | {'MANIFEST_v1.json', 'RECEIPT_v1.json'}
    check(name + '_exact_inventory', actual == expected, {'actual': len(actual), 'declared': len(expected)}, 'seal_identity')
    return {'name': name, 'receipt_sha256': receipt_pin, 'artifacts': len(manifest['artifacts']), 'files': len(actual), 'science_rerun': False}

def main():
    sources = [r for n in ('INPUT_FREEZE_v1.json', 'JOINT_SEAL_CAPTURE_v1.json') for r in load(HERE / n)['inputs']]
    check('unique_new_capture_inventory', len(sources) == len({r['original_path'] for r in sources}) == 146, category='identity')
    for i, r in enumerate(sources):
        check(f'affected_original_recovery_{i}', identity(Path(r['original_path']), r) and identity(Path(r['snapshot']), r), r['original_path'], 'identity')
    details['reused_v1_seal'] = verify_seal('canonical_v1', OLD, '045e72aa80bf3a948153c41b0461f6fbd25eaab08de8dcb328ad7d8a3a613f34')
    details['joint_independent_seal'] = verify_seal('joint_independent', JOINT / 'independent_v1', '7210514677660e0142b1378b68cbf20bee856153a10c2701d24aa48a0556cb00')
    jr = load(JOINT / 'independent_v1/RECEIPT_v1.json')
    for i, r in enumerate(jr['source_bindings']):
        check(f'joint_review_source_pair_{i}', identity(SNAP / r['original_path'], r) and identity(JOINT / 'independent_v1' / r['snapshot_path'], r), category='seal_identity')
    old_note = (OLD_SNAP / NOTE).read_text(); note = (SNAP / NOTE).read_text()
    old_code = (OLD_SNAP / RUNNER).read_text(); code = (SNAP / RUNNER).read_text()
    preservation = load(PACKAGE / 'CANONICAL_V1_PRESERVATION.json')
    superseded = []
    for r in preservation['paths']:
        original = OLD_SNAP / r['original_path']; recovery = SNAP / r['recovery']; final = SNAP / r['original_path']
        check('superseded_' + r['original_path'], sha(original) == sha(recovery) == r['sha256'] and sha(final) != r['sha256'], category='identity')
        superseded.append({'original_path': r['original_path'], 'original_sha256': r['sha256'], 'disposition': 'superseded_canonical_v1_preserved_exactly_before_joint_extension', 'recovery': str(recovery.relative_to(HERE)), 'parent_recovery': r['recovery'], 'final_path': r['original_path'], 'final_sha256': sha(final)})
    details['superseded_original_dispositions'] = superseded
    for filename, a, b in [('canonical_note_v1_to_v2.diff', old_note, note), ('canonical_runner_v1_to_v2.diff', old_code, code)]:
        diff = ''.join(difflib.unified_diff(a.splitlines(True), b.splitlines(True), fromfile='canonical_v1', tofile='canonical_v2'))
        check(filename + '_exact', diff == (PACKAGE / filename).read_text())
    old_lineage = load(OLD_SNAP / PACK_REL / 'thermal_bounce_packaging/CANONICAL_LINEAGE_v1.json')
    lineage = load(PACKAGE / 'CANONICAL_LINEAGE_v2.json')
    check('first_three_proof_lineage_unchanged', typed(lineage['proof_sources'][:3]) == typed(old_lineage['proof_sources']))
    check('first_four_body_lineage_unchanged', typed(lineage['runner_bodies'][:4]) == typed(old_lineage['runner_bodies']))
    check('canonical_note_lineage_hash', sha(SNAP / NOTE) == lineage['canonical_note_sha256'])
    check('canonical_runner_lineage_hash', sha(SNAP / RUNNER) == lineage['canonical_runner_sha256'])
    first = '## ' + lineage['proof_sources'][0]['title'] + '\n'
    last = '## ' + lineage['proof_sources'][3]['title'] + '\n'
    end = '## Computational scope and assumption accounting\n'
    check('all_I_III_text_unchanged', old_note.split(first, 1)[1].split(end, 1)[0] == note.split(first, 1)[1].split(last, 1)[0])
    source_proof = (JOINT / 'DERIVATION_v1.md').read_text()
    transformed = re.sub(r'(?m)^(#+) ', r'#\1 ', '\n'.join(source_proof.splitlines()[1:]).strip())
    check('entire_IV_proof_body', note.split(last, 1)[1].split(end, 1)[0].strip() == transformed)
    old_tree, tree = ast.parse(old_code), ast.parse(code)
    old_functions = {n.name: n for n in old_tree.body if isinstance(n, ast.FunctionDef)}
    functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
    old_lines, lines = old_code.splitlines(True), code.splitlines(True)
    for name, old_fn in old_functions.items():
        fn = functions[name]
        check(name + '_full_AST_unchanged', ast.dump(old_fn) == ast.dump(fn))
        check(name + '_full_text_unchanged', ''.join(old_lines[old_fn.lineno-1:old_fn.end_lineno]) == ''.join(lines[fn.lineno-1:fn.end_lineno]))
    source = (JOINT / 'check_joint_entropy_v1.py').read_text()
    rec = lineage['runner_bodies'][-1]
    check('new_source_hash', sha(JOINT / 'check_joint_entropy_v1.py') == rec['source_sha256'])
    body = source[source.index('rows=[]\n'):source.index('result=dict(passed=')].strip()
    check('new_body_hash', hashtext(body) == rec['body_sha256'])
    fn = functions['check_joint_entropy']
    actual_body = textwrap.dedent(''.join(lines[fn.lineno:fn.body[-1].lineno-1])).strip()
    check('new_body_complete_text', actual_body == body)
    check('new_body_complete_AST', ast.dump(ast.Module(body=fn.body[:-1], type_ignores=[])) == ast.dump(ast.parse(body)))
    check('new_prior_parameter', [a.arg for a in fn.args.args] == ['prior'])
    main_node = next(n for n in tree.body if isinstance(n, ast.If))
    run_loop = next(n for n in main_node.body if isinstance(n, ast.For))
    expected_added = ast.parse("('joint_entropy',lambda:check_joint_entropy(outputs['finite_mass']))", mode='eval').body
    check('caller_uses_current_finite_mass_output', isinstance(run_loop.iter, ast.List) and ast.dump(run_loop.iter.elts[-1]) == ast.dump(expected_added))
    restored = copy.deepcopy(tree)
    restored.body = [n for n in restored.body if not (isinstance(n, ast.FunctionDef) and n.name == 'check_joint_entropy')]
    restored_main = next(n for n in restored.body if isinstance(n, ast.If))
    restored_loop = next(n for n in restored_main.body if isinstance(n, ast.For))
    restored_loop.iter.elts.pop()
    check('entire_remaining_program_AST_unchanged', ast.dump(restored) == ast.dump(old_tree))
    prior_record = load(OLD_SNAP / FM_REL / 'RESULTS_v1.json')
    source_result = load(JOINT / 'RESULTS_v1.json')
    check('standalone_prior_hash', source_result['prior_results_sha256'] == sha(OLD_SNAP / FM_REL / 'RESULTS_v1.json'))
    check('standalone_own_source_hash', source_result['checker_sha256'] == sha(JOINT / 'check_joint_entropy_v1.py'))
    old_hdr, old_stdout, old_stderr, old_output = parse_cache(OLD_SNAP / CACHE)
    hdr, stdout, stderr, output = parse_cache(SNAP / CACHE)
    raw_record = load(PACKAGE / 'CACHE_RUN_v2.json'); raw = raw_record['result']
    check('cache_actual_raw_result_streams', stdout == raw['stdout'] + '\n' and stderr == raw['stderr'] + '\n')
    check('cache_success', raw['exit_code'] == 0 and raw['status'] == 'ok' and hdr['exit_code'] == '0' and hdr['status'] == 'ok')
    check('cache_raw_and_formatted_blank_stderr', raw['stderr'] == '' and stderr == '\n')
    check('cache_hash', sha(SNAP / CACHE) == raw_record['cache_sha256'])
    check('cached_and_returned_output_exact', typed(output) == typed(json.loads(raw['stdout'])))
    check('untruncated_output', len(raw['stdout']) < 200000, len(raw['stdout']))
    check('cache_source_and_output_hash', hdr['runner_sha256'] == output['checker_sha256'] == sha(SNAP / RUNNER))
    decl = {}
    for n in tree.body:
        if isinstance(n, ast.Assign):
            for t in n.targets:
                if isinstance(t, ast.Name) and t.id in ('AUDIT_INPUT_PATHS', 'AUDIT_TIMEOUT_SEC'):
                    decl[t.id] = ast.literal_eval(n.value)
    h = hashlib.sha256(b'runner-cache-input-fingerprint-v1\0')
    for name in decl['AUDIT_INPUT_PATHS']:
        path_bytes = name.encode(); data = (SNAP / name).read_bytes()
        h.update(len(path_bytes).to_bytes(8, 'big')); h.update(path_bytes)
        h.update(len(data).to_bytes(8, 'big')); h.update(data)
    check('fresh_input_fingerprint', hdr['input_fingerprint_sha256'] == h.hexdigest(), h.hexdigest())
    check('declared_timeout', raw['timeout_sec'] == decl['AUDIT_TIMEOUT_SEC'] == int(hdr['timeout_sec']) == 120)
    for i, row in enumerate(old_output['checks']):
        check(f'prior_check_object_{i}', typed(output['checks'][i]) == typed(row))
    for name, previous in old_output['substantive_outputs'].items():
        check(name + '_entire_previous_output', typed(output['substantive_outputs'][name]) == typed(previous))
        check(name + '_previous_unit_counts', typed(output['units'][name]) == typed(old_output['units'][name]))
    fresh_finite = output['substantive_outputs']['finite_mass']
    check('fresh_input_grid_equals_standalone_prior', typed(fresh_finite['grid']) == typed(prior_record['grid']))
    check('fresh_input_endpoint_G_equals_standalone_prior', typed(fresh_finite['analytic_endpoint_G']) == typed(prior_record['analytic_endpoint_G']))
    for i, row in enumerate(source_result['checks']):
        expect = dict(row, name='joint_entropy::' + row['name'])
        check(f'new_joint_check_object_{i}', typed(output['checks'][278+i]) == typed(expect))
    extras = {k: v for k, v in source_result.items() if k not in ('passed', 'failed', 'checks', 'scope', 'checker_sha256', 'prior_results_sha256')}
    check('all_joint_substantive_outputs', typed(output['substantive_outputs']['joint_entropy']) == typed(extras))
    check('all_276_joint_source_checks', source_result['passed'] == 276 and source_result['failed'] == 0 and len(source_result['checks']) == 276)
    check('all_554_canonical_checks', output['passed'] == len(output['checks']) == sum(r['passed'] is True for r in output['checks']) == 554 and output['failed'] == 0)
    check('unique_names', len({r['name'] for r in output['checks']}) == 554)
    check('joint_unit_count', output['units']['joint_entropy'] == {'passed': 276, 'failed': 0})
    check('all_joint_postprocessing_rows', len(extras['postprocessing']) == 61)
    check('all_joint_fresh_entropy_rows', len(extras['fresh_entropy_integrals']) == 7)
    check('all_joint_derivative_controls', len([r for r in source_result['checks'] if r['name'].startswith('entropy_mass_derivative_numeric_')]) == 6)
    details['science_outputs'] = {'old_checks': 278, 'new_checks': 276, 'total_checks': 554, 'joint_postprocessing': 61, 'fresh_entropy_integrals': 7, 'derivative_controls': 6, 'constants': extras['constants'], 'old_grid_and_tables': 'exactly unchanged', 'standalone_prior_hash': source_result['prior_results_sha256']}
    details['actual_cache'] = {'sha256': sha(SNAP / CACHE), 'fingerprint': h.hexdigest(), 'raw_stdout_chars': len(raw['stdout']), 'elapsed_seconds': raw['elapsed_sec'], 'raw_stderr': raw['stderr'], 'evidence_origin': 'serialized actual API result; not reconstructed v1 return'}
    damages = []
    for d in load(JOINT / 'DAMAGE_SUMMARY_v1.json'):
        name = d['name']; base = JOINT / 'damages_v1'; code_path = base / (name + '.py')
        outcome = load(base / (name + '_RESULTS.json')); run = load(base / (name + '_RUN.json'))
        check(name + '_damaged_source_hash', sha(code_path) == outcome['checker_sha256'] and sha(code_path) != sha(JOINT / 'check_joint_entropy_v1.py'), category='reused_damage')
        failures = [r['name'] for r in outcome['checks'] if not r['passed']]
        check(name + '_actual_failed_math', run['exit_code'] == d['exit_code'] == 1 and outcome['failed'] == d['failed'] == len(failures) and failures == d['failed_checks'] and outcome['passed'] == d['passed'], category='reused_damage')
        diff = ''.join(difflib.unified_diff(source.splitlines(True), code_path.read_text().splitlines(True), fromfile='original', tofile=name))
        damages.append({'name': name, 'source_sha256': sha(code_path), 'passed': outcome['passed'], 'failed': outcome['failed'], 'failed_names': failures, 'exact_diff': diff})
    details['producer_actual_damages_reused'] = damages
    fail = load(PACKAGE / 'PARENT_INSPECTION_FAILURE_v1.json')
    check('parent_inspection_failure_preserved', fail['exception'] == 'FileNotFoundError' and fail['science_executed'] is False)
    wrapper = load(JOINT / 'independent_v1/WRAPPER_REPAIR_v2.json')
    check('joint_wrapper_failure_and_partial_execution_preserved', wrapper['failed_prefix_matches'] == 2 and wrapper['baseline_checker_rerun'] is False and wrapper['first_three_controls_rerun'] is False)
    check('joint_independent_baseline_and_damages', jr['baseline']['passed'] == 64 and jr['baseline']['failed'] == 0 and jr['actual_damaged_implementations'] == 8 and jr['all_eight_expected_witnesses_detected'] is True)
    details['new_failure_records'] = {'parent_inspection': fail, 'joint_independent_wrapper': wrapper}
    rational_controls()
    categories = sorted({r['category'] for r in rows})
    return {'created_utc': datetime.now(timezone.utc).isoformat(), 'checker_sha256': sha(Path(__file__)), 'scope': 'Affected-only v2 correspondence and eight rational coefficient controls; no producer science rerun', 'passed': sum(r['passed'] for r in rows), 'failed': sum(not r['passed'] for r in rows), 'category_counts': {c: {'passed': sum(r['passed'] for r in rows if r['category'] == c), 'failed': sum(not r['passed'] for r in rows if r['category'] == c)} for c in categories}, 'checks': rows, 'details': details}

def rational_controls():
    R3 = F(11, 4)
    cap3 = F(2, 3)**3 * F(3, 4)**3 * R3
    bare3 = 1 / cap3; measured3 = bare3 * F(3, 4)**3
    old_bare3 = F(3, 2)**3 / R3; old_measured3 = F(9, 8)**3 / R3
    check('rational_correlated_cap_cube', cap3 == R3 / 8, category='new_rational')
    check('rational_bare_coefficient_cube', bare3 == F(32, 11) > 1, category='new_rational')
    check('rational_measured_coefficient_cube', measured3 == F(27, 22) > 1, category='new_rational')
    check('rational_bare_improvement_ratio', bare3 / old_bare3 == F(4, 3)**3, category='new_rational')
    check('rational_measured_improvement_ratio', measured3 / old_measured3 == F(4, 3)**3, category='new_rational')
    check('rational_unit_radius_threshold', 1 / measured3 == F(22, 27) < 1, category='new_rational')
    check('rational_distinct_threshold_improvement', F(1, 2) / F(2, 3) == F(3, 4), category='new_rational')
    check('rational_separate_maximizers_incompatible', (1 / F(3, 4))**3 == F(64, 27) > 1, category='new_rational')

if __name__ == '__main__':
    result = main()
    with (HERE / 'AFFECTED_RESULTS_v1.json').open('x') as f:
        json.dump(result, f, indent=2); f.write('\n')
    print(json.dumps({k: result[k] for k in ('passed', 'failed', 'category_counts')}, indent=2))
    raise SystemExit(bool(result['failed']))
