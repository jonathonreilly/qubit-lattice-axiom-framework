#!/usr/bin/env python3
"""Preserve v2 mapping and correct three inherited current-path flags before seal."""
from pathlib import Path
from datetime import datetime, timezone
import copy
import hashlib
import json

HERE = Path(__file__).resolve().parent

def load(name):
    return json.loads((HERE / name).read_text())

def sha(name):
    return hashlib.sha256((HERE / name).read_bytes()).hexdigest()

def save(name, value):
    with (HERE / name).open('x') as f:
        json.dump(value, f, indent=2); f.write('\n')

old = load('original_dispositions_v2.json')
new = copy.deepcopy(old)
changes = []
superseded = {(r['original_path'], r['original_sha256']) for r in load('SUPERSEDED_CANONICAL_DISPOSITIONS_v1.json')['original_dispositions']}
for row in new['original_dispositions']:
    if (row['original_path'], row['original_sha256']) in superseded:
        assert row['original_remains_unchanged'] is True
        row['original_remains_unchanged'] = False
        row['original_bytes_preserved_in_recovery'] = True
        changes.append({'original_path': row['original_path'], 'original_sha256': row['original_sha256'], 'field': 'original_remains_unchanged', 'old_value': True, 'final_value': False, 'reason': 'The live canonical path is now v2; v1 bytes remain exact in the declared recovery.'})
assert len(changes) == 3
new['supersedes_mapping_without_overwriting'] = {'path': 'original_dispositions_v2.json', 'sha256': sha('original_dispositions_v2.json')}
new['finalized_utc'] = datetime.now(timezone.utc).isoformat()
save('original_dispositions_v3.json', new)
record = {'recorded_utc': new['finalized_utc'], 'kind': 'pre_seal_reviewer_metadata_semantics_correction', 'old_mapping': {'path': 'original_dispositions_v2.json', 'sha256': sha('original_dispositions_v2.json')}, 'final_mapping': {'path': 'original_dispositions_v3.json', 'sha256': sha('original_dispositions_v3.json')}, 'changes': changes, 'cause': 'Old mapping flag was copied with inherited dispositions; original recovery and final hashes were already correct.', 'science_results_changed': False, 'hash_or_recovery_changed': False, 'prior_seal_changed': False, 'executed_metadata_script_preserved': 'prepare_metadata_v1.py'}
save('DISPOSITION_FLAG_CORRECTION_v1.json', record)
ledger = load('FAILURE_LEDGER_v1.json')
ledger['supersedes_without_overwriting'] = {'path': 'FAILURE_LEDGER_v1.json', 'sha256': sha('FAILURE_LEDGER_v1.json')}
ledger['pre_seal_metadata_findings'] = [record]
save('FAILURE_LEDGER_v2.json', ledger)
index = load('COMMAND_INDEX_v1.json')
index['supersedes_without_overwriting'] = {'path': 'COMMAND_INDEX_v1.json', 'sha256': sha('COMMAND_INDEX_v1.json')}
index['commands'].insert(-1, {'source': 'correct_disposition_flags_v1.py', 'command': 'python3 correct_disposition_flags_v1.py', 'source_sha256': sha('correct_disposition_flags_v1.py'), 'scope': 'Only three stale inherited current-path flags; original map/source/evidence preserved'})
save('COMMAND_INDEX_v2.json', index)
print(json.dumps({'corrected_flags': len(changes), 'old_mapping_preserved': True, 'science_rerun': False}))
