#!/usr/bin/env python3
"""Affected-only source dispositions and preservation metadata."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = Path(str(HERE).split('/.claude/')[0])
OLD = HERE.parent / 'thermal_bounce_canonical_correspondence_v1'
SNAP = HERE / 'source_snapshot'
P = Path('.claude/science/physics-loops/revised-scalar-derivation-24h-20261013')
J = P / 'thermal_trace_bridge_v1/finite_mass_bounce_bound_v1/joint_entropy_bounce_v1'
NOW = datetime.now(timezone.utc).isoformat()

def readj(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(name, value):
    with (HERE / name).open('x') as f:
        json.dump(value, f, indent=2); f.write('\n')

result = readj(HERE / 'AFFECTED_RESULTS_v1.json')
assert result['passed'] == 1332 and result['failed'] == 0
superseded = result['details']['superseded_original_dispositions']
save('SUPERSEDED_CANONICAL_DISPOSITIONS_v1.json', {'created_utc': NOW, 'original_dispositions': superseded, 'count': 3, 'prior_seal_unchanged': True})
canonical_final = {r['final_path']: r['final_sha256'] for r in superseded}
prior = readj(OLD / 'original_dispositions_v1.json')
combined = {}
updated_inherited_destinations = []
for old in prior['original_dispositions']:
    row = dict(old)
    row['recovery'] = '../thermal_bounce_canonical_correspondence_v1/' + old['recovery']
    row['reused_original_disposition_seal'] = '045e72aa80bf3a948153c41b0461f6fbd25eaab08de8dcb328ad7d8a3a613f34'
    if row['final_path'] in canonical_final:
        row['previous_final_sha256'] = row['final_sha256']
        row['final_sha256'] = canonical_final[row['final_path']]
        updated_inherited_destinations.append(row['original_path'])
        match = next((r for r in superseded if r['original_path'] == row['original_path']), None)
        if match:
            row.update(match)
        else:
            row['disposition'] = 'unchanged_previously_checked_source_body_retained_in_extended_canonical_v2_original_preserved'
    combined[(row['original_path'], row['original_sha256'])] = row
sources = [r for n in ('INPUT_FREEZE_v1.json', 'JOINT_SEAL_CAPTURE_v1.json') for r in readj(HERE / n)['inputs']]
lineage = readj(SNAP / P / 'thermal_bounce_packaging/CANONICAL_LINEAGE_v2.json')
new_ports = {str(J / 'DERIVATION_v1.md'): 'docs/EXPONENTIAL_SCALAR_THERMAL_BOUNCE_BOUNDED_THEOREM_NOTE_2026-10-14.md', str(J / 'check_joint_entropy_v1.py'): 'scripts/exponential_scalar_thermal_bounce_check.py'}
for src in sources:
    path = str(Path(src['original_path']).relative_to(ROOT)); key = (path, src['sha256'])
    recovery = str(Path(src['snapshot']).relative_to(HERE))
    if key in combined:
        combined[key]['additional_recovery'] = recovery
        continue
    final_path = new_ports.get(path, path)
    combined[key] = {'original_path': path, 'original_sha256': src['sha256'], 'disposition': 'new_joint_complete_body_ported_original_source_and_IO_recovered' if path in new_ports else 'affected_original_preserved_exactly_no_authority_promotion', 'recovery': recovery, 'final_path': final_path, 'final_sha256': sha(ROOT / final_path), 'bytes': src['bytes'], 'original_remains_unchanged': True}
assert len(combined) == 560 and len(updated_inherited_destinations) == 10
for row in combined.values():
    assert sha(HERE / row['recovery']) == row['original_sha256']
    assert sha(ROOT / row['final_path']) == row['final_sha256']
save('original_dispositions_v2.json', {'created_utc': NOW, 'scope': '425 inherited original identities plus 146 affected captures, deduplicating 11 identical path/hash pairs; original path may occur at both preserved canonical versions', 'original_dispositions': list(combined.values()), 'count': 560, 'inherited_count': 425, 'new_capture_count': 146, 'overlap': 11, 'updated_inherited_final_destinations': updated_inherited_destinations, 'superseded_canonical_pointer': 'SUPERSEDED_CANONICAL_DISPOSITIONS_v1.json#/original_dispositions', 'prior_mapping': {'path': '../thermal_bounce_canonical_correspondence_v1/original_dispositions_v1.json', 'sha256': sha(OLD / 'original_dispositions_v1.json')}, 'prior_seal_unchanged': True})
joint_receipt = readj(SNAP / J / 'independent_v1/RECEIPT_v1.json')
principal_reads = [str(J / 'DERIVATION_v1.md'), str(J / 'PROTOCOL_v1.json'), str(J / 'check_joint_entropy_v1.py'), str(J / 'independent_v1/REPORT_v1.md'), str(J / 'independent_v1' / joint_receipt['hand_derivation']['path']), str(J / 'independent_v1/FAILURE_LEDGER_v1.json'), str(J / 'independent_v1/WRAPPER_REPAIR_v2.json'), str(P / 'thermal_bounce_packaging/canonical_note_v1_to_v2.diff'), str(P / 'thermal_bounce_packaging/canonical_runner_v1_to_v2.diff'), str(P / 'thermal_bounce_packaging/CANONICAL_LINEAGE_v2.json')]
save('COVERAGE_v1.json', {'created_utc': NOW, 'principal_full_reads': [{'path': p, 'sha256': sha(SNAP / p)} for p in principal_reads], 'canonical_scope': 'Complete added Part IV/function/caller and every changed narrative paragraph read; old I-III and four functions reused by exact whole-text and AST identity', 'new_capture_bindings': 146, 'previous_seal_artifacts_verified': 464, 'joint_seal_artifacts_verified': 79, 'joint_source_pairs_verified': 6, 'previous_278_check_objects_compared': True, 'new_276_check_objects_compared': True, 'all_old_and_new_substantive_outputs_compared': True, 'producer_science_executed': False, 'previous_independent_science_executed': False, 'new_exact_rational_checks': 8, 'empirical_data_read': False, 'new_full_history_or_thermodynamic_proof_authored': False, 'primary_source_or_visual_QA_repeated': False})
save('FAILURE_LEDGER_v1.json', {'created_utc': NOW, 'new_reviewer_baseline_or_tool_failures': [], 'prior_review_failures_reused_unchanged': {'path': '../thermal_bounce_canonical_correspondence_v1/FAILURE_LEDGER_v2.json', 'sha256': sha(OLD / 'FAILURE_LEDGER_v2.json')}, 'parent_inspection_failure': result['details']['new_failure_records']['parent_inspection'], 'joint_independent_wrapper_failure': result['details']['new_failure_records']['joint_independent_wrapper'], 'parent_new_actual_damaged_runs': [{k: v for k, v in r.items() if k != 'exact_diff'} for r in result['details']['producer_actual_damages_reused']], 'parent_new_exact_diffs': 'AFFECTED_RESULTS_v1.json#/details/producer_actual_damages_reused', 'joint_independent_damages': '8 exact changed implementations rejected; baseline/first three preserved; five remaining run only after wrapper repair', 'old_author_cache_TypeError_and_general_trace_NameError_preserved': True, 'science_reruns': False})
save('COMMAND_INDEX_v1.json', {'created_utc': NOW, 'commands': [{'source': 'capture_v1.py', 'command_record': 'CAPTURE_COMMAND_v1.json', 'execution_record': 'CAPTURE_EXECUTION_v1.json'}, {'source': 'capture_joint_seal_v1.py', 'command_record': 'JOINT_CAPTURE_COMMAND_v1.json', 'execution_record': 'JOINT_CAPTURE_EXECUTION_v1.json'}, {'source': 'check_affected_v1.py', 'command_record': 'AFFECTED_COMMAND_v1.json', 'execution_record': 'AFFECTED_EXECUTION_v1.json'}, {'source': 'prepare_metadata_v1.py', 'command': 'python3 prepare_metadata_v1.py', 'source_sha256': sha(Path(__file__)), 'scope': 'this metadata construction; no science'}, {'source': 'seal_v1.py', 'command_record': 'SEAL_COMMAND_v1.json', 'scope': 'final exact source/recovery/map verification and seal only'}], 'read_only_inspections': ['explicit source-tree inventory excluding pending independent tree, then exact final-seal capture', 'full source proof/checker/protocol and changed note/runner diffs', 'full independent report/hand derivation/failure ledger', 'compact cache header/API-return metadata and exact changed-source damage diff reads'], 'producer_and_previous_independent_science_commands_replayed': []})
print(json.dumps({'complete_original_dispositions': len(combined), 'explicit_superseded_canonical_paths': 3, 'updated_inherited_destinations': len(updated_inherited_destinations), 'old_seal_mutated': False}))
