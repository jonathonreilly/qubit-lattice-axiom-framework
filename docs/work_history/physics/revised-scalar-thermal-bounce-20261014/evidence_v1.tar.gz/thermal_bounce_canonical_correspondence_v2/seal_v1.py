#!/usr/bin/env python3
"""Seal affected-only correspondence after final live/recovery/semantic checks."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = Path(str(HERE).split('/.claude/')[0])
OLD = HERE.parent / 'thermal_bounce_canonical_correspondence_v1'
SNAP = HERE / 'source_snapshot'

def load(p):
    return json.loads(p.read_text())

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def record(p):
    return {'path': str(p.relative_to(HERE)), 'bytes': p.stat().st_size, 'sha256': sha(p)}

def save(name, value):
    with (HERE / name).open('x') as f:
        json.dump(value, f, indent=2); f.write('\n')

assert not (HERE / 'MANIFEST_v1.json').exists()
assert not (HERE / 'RECEIPT_v1.json').exists()
assert load(HERE / 'SEAL_COMMAND_v1.json')['script_sha256'] == sha(Path(__file__))
sources = [r for n in ('INPUT_FREEZE_v1.json', 'JOINT_SEAL_CAPTURE_v1.json') for r in load(HERE / n)['inputs']]
assert len(sources) == len({r['original_path'] for r in sources}) == 146
for r in sources:
    assert sha(Path(r['original_path'])) == sha(Path(r['snapshot'])) == r['sha256']
    assert Path(r['original_path']).stat().st_size == Path(r['snapshot']).stat().st_size == r['bytes']
old_manifest = load(OLD / 'MANIFEST_v1.json')
assert sha(OLD / 'RECEIPT_v1.json') == '045e72aa80bf3a948153c41b0461f6fbd25eaab08de8dcb328ad7d8a3a613f34'
assert sha(OLD / 'MANIFEST_v1.json') == '37a5be7980c6aeb6433f5066a11399f36cdf9ab4f5f78ba004fc59d88a2cb792'
assert len(old_manifest['artifacts']) == 464
for r in old_manifest['artifacts']:
    assert sha(OLD / r['path']) == r['sha256']
assert {str(p.relative_to(OLD)) for p in OLD.rglob('*') if p.is_file()} == {r['path'] for r in old_manifest['artifacts']} | {'MANIFEST_v1.json', 'RECEIPT_v1.json'}
mapping = load(HERE / 'original_dispositions_v3.json')
assert len(mapping['original_dispositions']) == 560
assert len({(r['original_path'], r['original_sha256']) for r in mapping['original_dispositions']}) == 560
superseded = load(HERE / 'SUPERSEDED_CANONICAL_DISPOSITIONS_v1.json')['original_dispositions']
expected_changed = {(r['original_path'], r['original_sha256']) for r in superseded}
actual_changed = set()
for r in mapping['original_dispositions']:
    assert sha(HERE / r['recovery']) == r['original_sha256']
    assert sha(ROOT / r['final_path']) == r['final_sha256']
    same = sha(ROOT / r['original_path']) == r['original_sha256']
    assert r['original_remains_unchanged'] is same
    if not same:
        actual_changed.add((r['original_path'], r['original_sha256']))
        assert r['original_bytes_preserved_in_recovery'] is True
assert actual_changed == expected_changed and len(actual_changed) == 3
correction = load(HERE / 'DISPOSITION_FLAG_CORRECTION_v1.json')
for key in ('old_mapping', 'final_mapping'):
    assert sha(HERE / correction[key]['path']) == correction[key]['sha256']
assert len(correction['changes']) == 3
command = load(HERE / 'AFFECTED_COMMAND_v1.json')
for r in command['input_pins']:
    assert sha(Path(r['path'])) == r['sha256']
execution = load(HERE / 'AFFECTED_EXECUTION_v1.json')
assert execution['exit_code'] == 0 and execution['inputs_unchanged'] is True
assert sha(HERE / 'affected_v1.stdout') == execution['stdout_sha256']
assert sha(HERE / 'affected_v1.stderr') == execution['stderr_sha256']
results = load(HERE / 'AFFECTED_RESULTS_v1.json')
assert results['checker_sha256'] == sha(HERE / 'check_affected_v1.py')
assert results['passed'] == len(results['checks']) == sum(r['passed'] is True for r in results['checks']) == 1332
assert results['failed'] == 0 and results['category_counts']['new_rational'] == {'passed': 8, 'failed': 0}
now = datetime.now(timezone.utc).isoformat()
save('FINAL_SOURCE_IDENTITY_v1.json', {'created_utc': now, 'bindings': sources, 'count': 146, 'all_originals_and_snapshots_match': True, 'previous_464_artifact_seal_verified_unchanged': True, 'complete_disposition_identities': 560, 'superseded_live_path_versions': superseded, 'no_parent_source_mutations': True})
save('SEAL_VALIDATION_v1.json', {'created_utc': now, 'new_live_recovery_bindings_verified': 146, 'combined_recovery_final_pairs_verified': 560, 'old_seal_artifacts_verified': 464, 'only_live_original_version_changes': len(actual_changed), 'all_disposition_unchanged_flags_match_current_paths': True, 'old_and_corrected_disposition_maps_preserved': True, 'science_result_identity_and_counts_verified': results['category_counts'], 'science_rerun': False, 'prior_seal_mutated': False})
exclude = {'MANIFEST_v1.json', 'RECEIPT_v1.json'}
artifacts = [record(p) for p in sorted(HERE.rglob('*')) if p.is_file() and str(p.relative_to(HERE)) not in exclude]
save('MANIFEST_v1.json', {'schema': 'focused-affected-canonical-correspondence-manifest-v1', 'created_utc': now, 'artifact_root': str(HERE), 'artifact_count': len(artifacts), 'excludes': sorted(exclude), 'artifacts': artifacts, 'immutable_after_seal': True})
receipt = {
    'schema': 'focused-affected-canonical-correspondence-receipt-v1', 'created_utc': now,
    'unit': 'thermal_bounce_canonical_correspondence_v2', 'scientific_author': '/root', 'independent_checker': '/root/direct_field_check',
    'formal_audit': False, 'formal_grade_or_landing_authority': False,
    'report': record(HERE / 'REPORT_v1.md'), 'manifest': record(HERE / 'MANIFEST_v1.json'), 'artifact_count': len(artifacts),
    'original_dispositions': {'path': 'original_dispositions_v3.json', 'pointer': '/original_dispositions', 'sha256': sha(HERE / 'original_dispositions_v3.json'), 'count': 560},
    'superseded_canonical_dispositions': record(HERE / 'SUPERSEDED_CANONICAL_DISPOSITIONS_v1.json'),
    'source_identity': record(HERE / 'FINAL_SOURCE_IDENTITY_v1.json'), 'new_source_pair_count': 146,
    'coverage': record(HERE / 'COVERAGE_v1.json'), 'method': record(HERE / 'METHOD_v1.md'),
    'results': record(HERE / 'AFFECTED_RESULTS_v1.json'), 'command_index': record(HERE / 'COMMAND_INDEX_v2.json'),
    'failure_ledger': record(HERE / 'FAILURE_LEDGER_v2.json'), 'metadata_correction': record(HERE / 'DISPOSITION_FLAG_CORRECTION_v1.json'),
    'seal_validation': record(HERE / 'SEAL_VALIDATION_v1.json'),
    'prior_seal': {'path': '../thermal_bounce_canonical_correspondence_v1/RECEIPT_v1.json', 'sha256': '045e72aa80bf3a948153c41b0461f6fbd25eaab08de8dcb328ad7d8a3a613f34', 'artifacts_verified': 464, 'unchanged': True},
    'joint_seal': results['details']['joint_independent_seal'],
    'reviewer_checks': {'passed': 1332, 'failed': 0, 'new_exact_rational_controls': 8, 'category_counts': results['category_counts']},
    'reused_author_evidence': {'passed': 554, 'failed': 0, 'old_objects_exact': 278, 'new_joint_objects_exact': 276, 'joint_postprocessing_rows': 61, 'fresh_entropy_records': 7, 'derivative_records': 6, 'replayed': False},
    'source_disposition': 'No scientific or output-loss discrepancy in the checked extension; prior body identities and explicit premise limits preserved.',
    'failure_accounting': {'all_old_failures_preserved': True, 'parent_inspection_FileNotFoundError_preserved': True, 'joint_independent_unique_match_failure_and_partial_execution_preserved': True, 'parent_four_new_actual_damages_reused': True, 'independent_eight_damages_reused': True, 'new_reviewer_execution_failures': 0, 'pre_seal_disposition_flag_correction': 'Three stale inherited flags corrected in v3; previous map and executed script retained; no checksum/science/recovery change'},
    'limits': ['affected-only, unchanged I-III science reused', 'conditional ideal-bath and adopted measured-calibration domains', 'no new empirical fit, history, body or source-scale derivation', 'no producer or prior independent science rerun', 'no archive or committed-tree certification', 'no source/Git/runtime/PR/audit/model changes'],
    'immutable_after_seal': True
}
save('RECEIPT_v1.json', receipt)
assert {str(p.relative_to(HERE)) for p in HERE.rglob('*') if p.is_file()} == {r['path'] for r in artifacts} | exclude
for r in artifacts:
    assert sha(HERE / r['path']) == r['sha256']
assert sha(HERE / receipt['report']['path']) == receipt['report']['sha256']
assert sha(HERE / receipt['manifest']['path']) == receipt['manifest']['sha256']
print(json.dumps({'artifact_count': len(artifacts), 'total_files': len(artifacts)+2, 'new_source_bindings': 146, 'complete_original_dispositions': 560, 'final_hashes': {name: sha(HERE / name) for name in ('REPORT_v1.md', 'MANIFEST_v1.json', 'RECEIPT_v1.json', 'original_dispositions_v3.json')}}, indent=2))
