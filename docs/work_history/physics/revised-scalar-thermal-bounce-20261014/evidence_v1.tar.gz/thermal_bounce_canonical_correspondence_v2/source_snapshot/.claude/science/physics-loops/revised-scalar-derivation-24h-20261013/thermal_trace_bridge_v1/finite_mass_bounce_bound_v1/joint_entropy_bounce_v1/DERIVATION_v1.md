# Joint thermal pressure and entropy bound

Author /root. Conditional derivation frozen before new execution. This uses the existing ideal equilibrium photon/electron/positron bath as an explicit matter premise, not a derived particle theory or observed fit. It improves the earlier separately maximized bounce and charge bounds. All earlier bounds remain valid but need not be sharp.

## Inputs and observation-facing target

On a strict Einstein-frame bounce, positive scalar kinetic energy and nonnegative other-component enthalpy give f_b < 2/[3(1+w_b)] for the selected total bath. The same component is used at the final regular physical event. Write N=ln(a_E,f/a_E,b), D=rho_E a_E^4=rho_J a_J^4, zeta=D_f/D_b, d_J=kappa_E/Z^2 and F_bare=3Q Z^2/rho_B,E. Then P_bare=d_J F_bare=exp(2N)/(f_b zeta). The product target is necessary, not sufficient, for individual observational limits. Positive target Ltar, measured calibration and its error budget are supplied quantities; no data likelihood has been acquired.

The supplied bath has photons (g=2) and massive electron/positron fermions (g=4), zero chemical potential, common positive physical temperature, fixed positive mass, ideal statistics and equilibrium at both endpoints. In the reversible isolated case sigma=S_f/S_b=1, with S=s a_J^3. A separately supplied sigma>0 is an algebraic allowance, not a derived entropy source. The previous finite-mass proof establishes rho_T>0, p_T=(rho+p)/T, s=(rho+p)/T, G=rho/s^(4/3), and G_hot <= G(T) <= G_cold, with R=G_cold/G_hot=(11/4)^(1/3).

## Entropy density bound derived from occupations

Let x=m/T, y=p/T, Ehat=sqrt(y^2+x^2), f=1/(exp(Ehat)+1) and h_F(f)=-f ln(f)-(1-f)ln(1-f). For 0<f<=1/2,

 dh_F/df=ln[(1-f)/f]=Ehat >=0,
 df/dEhat=-f(1-f)<0.

At every y>0, increasing x lowers h_F(f). The dimensionless fermion entropy density is

 s_f/T^3 = g/(2 pi^2) integral_0^infinity y^2 h_F(f) dy.

This equals (rho_f+p_f)/T^4 by integration by parts using h_F(f)=Ehat f+ln(1+exp(-Ehat)); the boundary y^3 ln(1+exp(-Ehat)) vanishes at both limits. Thus h(T)=s/T^3 is bounded above by its massless hot value h_hot=11 pi^2/45. Photon entropy gives the positive cold floor h_cold=4 pi^2/45. Finite x>0 gives h(T)<h_hot. These are inequalities for the assumed equilibrium distribution, not a reason the actual early universe must be in that distribution.

## Joint bound

The Gibbs identity links the two previously separate terms exactly:

 (1+w_b) G_b = T_b/s_b^(1/3) = h_b^(-1/3).

Since zeta=sigma^(4/3) G_f/G_b,

 f_b zeta < (2/3) sigma^(4/3) G_f h_b^(1/3)
             <= (2/3) sigma^(4/3) G_cold h_hot^(1/3)
             = (R/2) sigma^(4/3).

The final equality uses G_hot=(3/4)h_hot^(-1/3). No ordering of endpoint temperatures, no monotonic A, and no fitted scalar initial point is required. The strict bounce gives strictness. The endpoint bounds alone do not establish a full history approaching equality.

Therefore

 P_bare > [2/(R sigma^(4/3))] exp(2N).                      (1)

This improves the previous coarse coefficient 3/(2R). The improved bare coefficient has cube 32/11 and is about 1.4275. For N>=0 and sigma=1 it forbids a bare target Ltar<=1. This is a conditional Einstein-bounce obstruction, not every Jordan bounce or a full cosmological exclusion.

## Measured weak-source calibration

Let gamma=G_cal/G_bare,c>0, so P_cal=P_bare/gamma. In the explicitly adopted same-background weak frozen principal regime, or its stated stable Yukawa completion, gamma<=(1+eta)(1+q_c), with eta>=0 and q_c<1/3. Hence

 P_cal > [3/(2R sigma^(4/3)(1+eta))] exp(2N).               (2)

Its eta=0,sigma=1 coefficient has cube 27/22 and is approximately 1.0706487833. Consequently, for N>=0 a positive target Ltar requires

 exp(2N) < (2R/3) sigma^(4/3)(1+eta) Ltar.                 (3)

With sigma=1 and eta=0, Ltar<=1 is impossible under these hypotheses. A necessary entropy allowance is sigma>[3 exp(2N)/(2R(1+eta)Ltar)]^(3/4). This does not prove an entropy production mechanism. Nor does it justify same-background calibration for an actual body or measurement. Different finite calibration backgrounds retain gamma<=(1+eta)(1+k)/C_c and require

 C_c < (R/2) sigma^(4/3)(1+eta)(1+k)Ltar exp(-2N).         (4)

For thresholds below one the previously proved negative-u energy floor applies with this tighter threshold. At threshold one there is no uniform positive gap above vacuum; above one the threshold supplies no negative-u restriction.

For a more general ideal bath with common equilibrium temperature, zero chemical potentials, fixed masses, positive massless species at low temperature, and analogous entropy and G bounds, replace R by (g_hot/g_cold)^(1/3). Equations (1)-(4) follow only when those constituent assumptions hold. R<=2 obstructs the bare unit target at N>=0, sigma=1; R<=3/2 obstructs the same-background eta=0 measured unit target. R above these thresholds is absence of this obstruction, not a constructed solution.

## What was eliminated and what survives

The coarse independent maximization of bounce pressure and thermal charge is eliminated algebraically. The apparent coefficient-below-one loophole from that coarse integration is closed within the stated same-background ideal-bath domain. Particle content, equilibrium, zero chemical potentials, isolation or supplied sigma, a strict Einstein bounce, positive kinetic/nonnegative other enthalpy, and the measured response regime all remain explicit. No initial history, action/potential, physical scale, laboratory environment, collision rate or abundance likelihood is derived. All thermal numerical checks are synthetic development calculations.
