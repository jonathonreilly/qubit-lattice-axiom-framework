from pathlib import Path
import sys, json, math, hashlib
import sympy as S
import numpy as np
from scipy.integrate import quad
from scipy.special import expit

out=Path(sys.argv[1]); base=Path(sys.argv[2]); assert not out.exists()
prior=json.loads(base.read_text()); rows=[]
def ck(name, passed, detail=None): rows.append(dict(name=name,passed=bool(passed),detail=detail))
def eq(name, expr):
 v=S.factor(S.simplify(expr));ck(name,v==0,str(v))
f,E,x,y=S.symbols('f E x y',positive=True)
hf=-f*S.log(f)-(1-f)*S.log(1-f)
eq('entropy_occupation_derivative',S.diff(hf,f)-S.log((1-f)/f))
fd=1/(S.exp(E)+1)
eq('fermi_occupation_energy_derivative',S.diff(fd,E)+fd*(1-fd))
eq('entropy_energy_derivative',S.diff(E*fd+S.log(1+S.exp(-E)),E)+E*fd*(1-fd))
eq('entropy_mass_derivative',(-E*f*(1-f)*x/E)-(-x*f*(1-f)))
Eof=S.sqrt(y*y+x*x); ell=S.log(1+S.exp(-Eof))
eq('entropy_pressure_integration_by_parts',S.diff(y**3*ell,y)-3*y*y*ell+y**4/(Eof*(S.exp(Eof)+1)))
r,p,gf,sigma,eta,gamma,lam,k,C,Ltar=S.symbols('r p Gf sigma eta gamma lam k C Ltar',positive=True)
h=r+p;w=p/r;G=r/h**S.Rational(4,3)
Gibbs=(1+w)*G
eq('joint_pressure_entropy_identity',Gibbs-h**(-S.Rational(1,3)))
fbcap=2/(3*(1+w));zeta=sigma**S.Rational(4,3)*gf/G
jointcap=S.Rational(2,3)*sigma**S.Rational(4,3)*gf*h**S.Rational(1,3)
eq('joint_fraction_charge_cap',fbcap*zeta-jointcap)
R=S.Rational(11,4)**S.Rational(1,3)
hhot=11*S.pi**2/45;hcold=4*S.pi**2/45
Ghot=S.Rational(3,4)*hhot**(-S.Rational(1,3));Gcold=S.Rational(3,4)*hcold**(-S.Rational(1,3))
eq('endpoint_ratio_cube',(Gcold/Ghot)**3-S.Rational(11,4))
eq('joint_cap_at_hot_and_cold',jointcap.subs({gf:Gcold,p:hhot-r})-R*sigma**S.Rational(4,3)/2)
bare=2*lam**2/(R*sigma**S.Rational(4,3))
measured=bare*3/(4*(1+eta))
eq('improved_bare_coefficient_cube',(2/R)**3-S.Rational(32,11))
eq('measured_coefficient_cube',(3/(2*R))**3-S.Rational(27,22))
ck('measured_unit_obstruction',S.Rational(27,22)>1)
converted=bare/gamma
eq('calibration_divides_product',converted*gamma-bare)
eq('same_background_cap',measured-3*lam**2/(2*R*sigma**S.Rational(4,3)*(1+eta)))
q,slack=S.symbols('q slack',nonnegative=True)
# Exact positive remainder at a fixed q<1/3, preserving strict bounce slack.
B=S.symbols('B',positive=True)
rem=(B+slack)/((1+eta)*(1+q))-3*B/(4*(1+eta))
eq('same_background_strict_remainder',rem-(B*(1-3*q)+4*slack)/(4*(1+eta)*(1+q)))
lamcrit=2*R*sigma**S.Rational(4,3)*(1+eta)*Ltar/3
eq('radius_threshold_boundary',measured.subs(lam**2,lamcrit)-Ltar)
sigcrit=(3*lam**2/(2*R*(1+eta)*Ltar))**S.Rational(3,4)
eq('entropy_threshold_boundary',measured.subs(sigma,sigcrit)-Ltar)
Ccrit=R*sigma**S.Rational(4,3)*(1+eta)*(1+k)*Ltar/(2*lam**2)
eq('different_background_threshold',converted.subs(gamma,(1+eta)*(1+k)/C).subs(C,Ccrit)-Ltar)
ck('joint_stronger_than_coarse',S.Rational(2)>S.Rational(3,2))

# Previously exposed finite-mass data: postprocessing, not new independent runs.
grid=prior['grid'];gh,gc=prior['analytic_endpoint_G'];ratio=float(R)
post=[]
for j,a in enumerate(grid):
 hh=a['r']+a['p'];gg=a['G'];ww=a['w']
 tight=1.5*(1+ww)*gg/gc
 ck('entropy_hot_cap_'+str(j),float(hcold)-2e-11<=hh<=float(hhot)+2e-11,hh)
 ck('joint_lower_coefficient_'+str(j),tight>=2/ratio-2e-11,tight)
 ck('gibbs_cube_'+str(j),abs(((1+ww)*gg)**3*hh-1)<3e-14)
 # Compare every final endpoint against this bounce value, with no T ordering.
 endpoints=[(2/(3*(1+ww)))*v['G']/gg for v in grid]
 ck('all_final_temperature_caps_'+str(j),max(endpoints)<=ratio/2+2e-11,max(endpoints))
 post.append(dict(x=a['x'],h=hh,minimum_bare_coefficient=tight,max_fraction_charge_cap=max(endpoints)))

# Fresh entropy integrals in occupation form, separate from saved stress integrals.
pi=math.pi
fresh=[]
def integ(fn):return quad(fn,0,np.inf,epsabs=2e-12,epsrel=2e-12,limit=300)
def entropy(xx):
 def kernel(yy):
  ee=math.hypot(xx,yy);ff=float(expit(-ee))
  return yy*yy*(ee*ff+float(np.logaddexp(0,-ee)))
 ss,err=integ(kernel)
 return 4*pi*pi/45+2*ss/pi**2,err
for j in [0,10,20,30,40,50,60]:
 a=grid[j];xx=a['x'];hh,er=entropy(xx)
 ck('fresh_entropy_matches_stress_'+str(j),abs(hh-a['r']-a['p'])<3e-11,hh-a['r']-a['p'])
 fresh.append(dict(x=xx,h=hh,error_estimate=er))
for xx in [.01,.1,.5,1.,3.,10.]:
 der,er=integ(lambda yy:yy*yy*float(expit(-math.hypot(xx,yy)))*(1-float(expit(-math.hypot(xx,yy)))))
 exact=-2*xx*der/pi**2;step=1e-4*max(.1,xx)
 num=(entropy(xx+step)[0]-entropy(xx-step)[0])/(2*step)
 ck('entropy_mass_derivative_numeric_'+str(xx),exact<0 and abs(num-exact)<3e-8*max(1,abs(exact)),dict(exact_integral=exact,centered=num,error_estimate=er))
result=dict(passed=sum(t['passed'] for t in rows),failed=sum(not t['passed'] for t in rows),checks=rows,postprocessing=post,fresh_entropy_integrals=fresh,
 constants=dict(R=str(S.N(R,25)),bare=str(S.N(2/R,25)),same_background=str(S.N(3/(2*R),25)),unit_target_eta_ceiling=str(S.N(3/(2*R)-1,25))),
 prior_results_sha256=hashlib.sha256(base.read_bytes()).hexdigest(),checker_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 scope='Conditional exact algebra, postprocessing of already exposed synthetic bath data, and seven fresh occupation-entropy integrals. No observed fit or full thermal history; no empirical holdout.')
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['checks','postprocessing','fresh_entropy_integrals']}))
for row in rows:
 if not row['passed']:print('FAILED',row)
sys.exit(bool(result['failed']))
