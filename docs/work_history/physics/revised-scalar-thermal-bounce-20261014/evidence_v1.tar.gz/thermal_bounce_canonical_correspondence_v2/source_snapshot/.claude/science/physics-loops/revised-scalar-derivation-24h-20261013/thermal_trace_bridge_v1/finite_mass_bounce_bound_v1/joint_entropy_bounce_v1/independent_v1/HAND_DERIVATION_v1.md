# Independent joint entropy and bounce derivation

Prepared before executable mathematics for this unit. Reviewer:
/root/scalar_energy_check. Scientific author: /root. The finite-mass gas G
range, strict Einstein bounce normalization and endpoint charge/product
identities are reused from their immutable independent receipt, by identity
only. No previous quadrature or action checker is rerun. The occupation
entropy bound and its joint use with pressure are derived here independently.

## Occupation entropy and statistics

Adopt the source's ideal photon plus electron/positron bath, common physical
temperature T>0, fixed physical mass m>0, zero chemical potential, two photon
and four fermion spin states. These are matter/statistical/equilibrium inputs,
not consequences of the gravitational action. Set x=m/T, y=p/T,
e=sqrt(x^2+y^2), f=(exp(e)+1)^(-1), and

    H_F(f) = -f log f -(1-f)log(1-f).

For 0<f<1, H_F'(f)=log[(1-f)/f]. At these zero-chemical-potential
occupations, log[(1-f)/f]=e, f_e=-f(1-f), so

    dH_F/de = -e f(1-f),
    partial_x H_F(f(sqrt(x^2+y^2))) = -x f(1-f) < 0

for x>0 at finite y. Thus for every y>0 and x>0,
H_F(f(sqrt(x^2+y^2)))<H_F(f(y)). There is no replacement of Fermi statistics
by Maxwell-Boltzmann statistics in this argument. The hole entropy term is
essential.

An exact identity is H_F(f(e))=e f(e)+log(1+exp(-e)). Since
d_y log(1+exp(-e))=-y f/e, integration by parts gives

    integral y^2 log(1+exp(-e)) dy
      = (1/3) integral y^4 f/e dy.

The boundary y^3 log(1+exp(-e)) vanishes at zero (bounded by y^3 log2)
and infinity (bounded by y^3 exp(-y)). Consequently

    g/(2pi^2) integral y^2 H_F(f) dy
      = (rho_F+p_F)/T^4 = s_F/T^3.

This establishes that the occupation bound applies to the thermodynamic
entropy used in the bounce algebra, with the pressure coefficient 1/3 and
the physical-temperature powers intact.

The hot integrals can be evaluated exactly, without a finite-mass quadrature:

    integral y^3/(exp(y)+1) dy = 6(1-2^-3) zeta(4) = 7pi^4/120,
    integral y^2 log(1+exp(-y)) dy = 2(1-2^-3) zeta(4) = 7pi^4/360.

These follow from the exponential series; the sum of integrals of absolute
terms converges as zeta(4), justifying termwise integration. Their sum gives
7g pi^2/180 for the massless Fermi entropy coefficient. With g=4 it is
7pi^2/45. The two photons give 4pi^2/45, so

    h_cold = 4pi^2/45,
    h(T)=s/T^3,
    h_cold < h(T) < h_hot=11pi^2/45

for finite m,T>0. Weak endpoint bounds suffice. The dominating hot entropy
integrand is integrable by the above identity. Dominated convergence gives
the hot limit as x tends to zero and vanishing pair entropy as x tends to
infinity. The uniform upper bound is an analytic occupation argument, not
an inference from a temperature grid.

The zero-chemical-potential premise matters. If f=[exp(e-alpha)+1]^-1,
then partial_x H_F=-(e-alpha)(x/e)f(1-f). It is positive for e<alpha.
For example e=log2, alpha=log8 and x/e=1/2 give f=4/5 and
partial_x H_F=2log4/25>0. Moreover rho+p=Ts+mu n changes the Gibbs identity.
This is an outside-domain counterexample, not a defect in the stated proof.
An ideal Bose generalization uses H_B=(1+f)log(1+f)-f log f and
f_e=-f(1+f), not the fermionic hole formula. Its analogous monotonicity holds
at zero chemical potential, but the general-source claim is conditional on
its explicitly assumed entropy/G bounds and a positive massless cold sector.

## Correlated endpoint bound

At the bounce use positive s_b,T_b,rho_b and the exact zero-chemical-potential
Gibbs identity rho_b+p_b=T_b s_b. With w_b=p_b/rho_b and
G_b=rho_b/s_b^(4/3),

    (1+w_b)G_b = T_b/s_b^(1/3) = h_b^(-1/3).

This prevents independent maximization of the pressure cap and the charge
ratio. For the same selected total bath, the reused strict bounce and
endpoint identities are

    0<f_b<2/[3(1+w_b)],
    zeta=sigma^(4/3)G_f/G_b, sigma=S_f/S_b>0,
    P_bare=r/(f_b zeta), r=exp(2N)>0.

Therefore

    f_b zeta < (2/3)sigma^(4/3)G_f h_b^(1/3)
              <=(2/3)sigma^(4/3)G_cold h_hot^(1/3)
              =(R/2)sigma^(4/3).

Here the reused gas theorem gives G_f<=G_cold and
R=G_cold/G_hot=(11/4)^(1/3). At the hot massless endpoint w_hot=1/3,
so G_hot=(3/4)h_hot^(-1/3). That last factor produces R/2, not 2R/3.
Strictness follows already from f_b's strict cap; the finite-mass endpoint
strictness is additional and not necessary for this conclusion.

For a useful exact representation let v_b=f_b/[2/(3(1+w_b))],
t_f=G_f/G_cold and t_h=h_b/h_hot. Then

    f_b zeta = (R/2)sigma^(4/3) v_b t_f t_h^(1/3),
    0<v_b<1, 0<t_f<=1, 0<t_h<=1.

This represents the comparison proof's scalar slack; it does not claim
arbitrary choices of these factors arise from a gravitational history or
even independent bath endpoints. At finite m,T the endpoint factors are
strictly below their limits. Their apparent joint saturation would require
appropriate hot/cold endpoints and a bounce near its cap, which is not
established by this inequality.

## Bare and calibrated consequences

Inverting only positive quantities gives

    P_bare > 2r/[R sigma^(4/3)].

For R=(11/4)^(1/3), (2/R)^3=32/11>1. At r>=1 and sigma=1 this forbids
a bare product target <=1. This is a statement about the supplied strict
Einstein-bounce class and final radius ordering, not a universal Jordan
bounce result.

For a positive measured calibration gamma=G_cal/G_bare,c, the diagnostic
conversion is P_cal=P_bare/gamma. Adopt the source's explicit same-background
weak frozen principal regime or its stated stable Yukawa extension, with
gamma<=(1+eta)(1+q_c), eta>=0 and q_c<1/3. Thus

    P_cal > 3r/[2R sigma^(4/3)(1+eta)].

The calibration ceiling is an applicability input, not a newly derived
finite-body response or an error estimate. For a positive target L,

    r < (2R/3)sigma^(4/3)(1+eta)L,
    sigma > [3r/(2R(1+eta)L)]^(3/4).

Both are strict. At sigma=1,eta=0,r>=1,L<=1 the radius cap is below one,
because (3/(2R))^3=27/22>1. Hence the earlier coarse coefficient-below-one
possibility is removed for this expressly matched ideal-bath/calibration
domain. This does not validate that domain for a real local measurement.
If L<=0, the positive diagnostic already makes the target impossible; the
divided budget formula is restricted to L>0. Assigning sigma does not supply
an entropy-production law or full matter/gravity evolution.

For distinct backgrounds, assume the source's already checked principal
ceiling gamma<=(1+eta)(1+k)/C_c. Then

    P_cal > 2r C_c/[R sigma^(4/3)(1+eta)(1+k)],
    C_c < Ccrit=(R/2)sigma^(4/3)(1+eta)(1+k)L/r.

For 0<Ccrit<1, the previous negative-u energy theorem applies; this unit
does not rerun that theorem. At Ccrit=1, strict above-vacuum energy remains
but no uniform positive gap follows. Above one no negative-u restriction
is forced. A local/cosmic environmental history remains unconstructed.

The new bare and calibrated lower bounds are 4/3 times the earlier coarse
ones; the distinct-background Ccrit is 3/4 of its earlier coarse value.
Those earlier bounds stay true. For a general bath satisfying the required
entropy and G premises, R<=2 suffices for the bare unit obstruction, and
R<=3/2 for the matched eta=0 measured obstruction. Equality is included
because the bounce bound is strict. A larger R removes this particular
sufficient obstruction; it does not construct an escape.

## Remaining assumptions and scope

The bath species, degeneracies, Fermi/Bose statistics, equilibrium endpoint
states, common positive temperature, fixed physical mass and zero chemical
potentials are explicit premises. Positive massless cold content keeps the
endpoint ratios finite. A different statistics model, photon-only diagnostic,
chemical potential, separate temperatures, species evolution, or a condensate
needs its own entropy and G calculation. The same total bath must occur in
f_b,zeta and the final diagnostic.

The strict Einstein bounce, positive scalar kinetic metric, nonnegative other
enthalpy and regular final Z!=0 are reused hypotheses. A product target is
only necessary for separate curvature and expansion limits. No ordering of
endpoint temperatures, monotone conformal factor or preselected scalar point
is needed for the inequality, but no complete endpoint-to-endpoint history
is supplied. No physical scale, equilibrium rate, measured error, initial-state
selector, body solution or empirical likelihood is derived. No source error
has been identified in this hand check.
