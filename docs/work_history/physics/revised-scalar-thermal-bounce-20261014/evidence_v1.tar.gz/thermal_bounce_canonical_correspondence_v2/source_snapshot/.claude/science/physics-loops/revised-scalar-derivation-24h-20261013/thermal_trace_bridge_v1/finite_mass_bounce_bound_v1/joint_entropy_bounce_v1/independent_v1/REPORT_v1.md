# Independent joint entropy/bounce check

Reviewer: /root/scalar_energy_check. Scientific author: /root.
The new joint argument agrees with an independent derivation from the adopted
occupation entropy, Gibbs identity and reused strict bounce bound. No source
correction was identified. This is a focused conditional proof check, not a
formal audit, grade, landing authority or replacement scientific authorship.

The pressure and charge bounds cannot be independently maximized. Retaining
their Gibbs correlation gives

    f_b zeta < (R/2) sigma^(4/3),
    P_bare > 2 exp(2N)/[R sigma^(4/3)],
    P_cal > 3 exp(2N)/[2R sigma^(4/3)(1+eta)]

for the explicitly matched weak-source calibration domain. For the photon/pair
bath, R=(11/4)^(1/3), the last coefficient at sigma=1,eta=0 is greater than
one. Thus the positive unit product target is impossible when N>=0 under
these hypotheses. This is a strengthened necessary bound; it neither
constructs a thermal history nor validates the calibration assumptions for
an actual measurement.

## Sources and preserved dependency

The new handwritten source and author protocol were read before this unit's
hand derivation and executable controls. All six source/snapshot pairs are
bound in SOURCE_MANIFEST_v1.json:

| Source | SHA256 |
| --- | --- |
| Joint DERIVATION_v1 | `3ed757fa354fa6ab550d7c4225b62d13d4e3787d7aae0fd730aff9a595aa95e8` |
| Joint author PROTOCOL_v1 | `0ae3bcd7c4fed7e2437c832a366cbd3a2c6f708e37fb652bfa8452ce9a5b3ad6` |
| Reused finite-mass DERIVATION_v2 | `356b3cdbc71d862223da2e6197f09eab816807afcf40bd17a3ec3335e8da6e23` |
| Reused independent finite-mass receipt | `af527b7be8f1c0e00d30b4118e24b6436332e3e08de03d7ad5e7ffded6b82098` |
| Reused independent finite-mass report | `d1d48e0b25d653505dc75747dad60217bcf7cf28d90d88b7b4b4e552c86d3808` |
| Reused independent finite-mass manifest | `e7a805ff48e89d68c6e09079eee59af5d97bb73b3c1a7b317ea087131ac53459` |

The complete old report and receipt were read for precise reuse scope. All
92 manifest artifacts, the exact 94-file inventory and all five live-source
pairs of that seal were verified by bytes. The underlying gas quadrature,
action-normalization checker and other old scientific code were not inspected,
imported or rerun. Hashing old artifact bytes for integrity is distinguished
from using their code/results as a new calculation. The old report's 180/0
corrected execution, earlier 177/0 with four disclosed vacuous guards, seven
damage controls and separate metadata checks retain their original status;
none is added to this unit's counts or relabeled as a new run.

The reused results are the same-bath G range and endpoint limits, positive
Gibbs/entropy definitions, strict Einstein-bounce cap
f_b<2/[3(1+w_b)], and the frame-invariant endpoint product. The new occupation
entropy upper bound, joint use of the pressure factor, and resulting improved
calibration budgets are independently checked here. The calibration response
ceiling is adopted as the source explicitly states; this unit does not repeat
the earlier gravity proof or the negative-u potential theorem.

No producer joint checker, output or synthetic grid was read. No new empirical
data or external reference was acquired. All computations use fresh symbolic
identities and exact rational/logarithmic controls. No finite-mass quadrature
was needed.

## Occupation entropy and its domain

HAND_DERIVATION_v1.md was frozen before executable mathematics. For
e=sqrt(x^2+y^2), x=m/T>0, y=p/T and f=(exp(e)+1)^-1,

    H_F=-f log f-(1-f)log(1-f),
    dH_F/df=log[(1-f)/f]=e,
    f_e=-f(1-f),
    partial_x H_F=-x f(1-f)<0.

The last identity gives a pointwise strict upper bound by the massless
occupation entropy. The Fermi hole term is essential; deleting it fails six
actual exact witnesses. The photon contribution is its constant massless
entropy, not the fermionic hole formula applied to bosons.

The identity H_F=e f+log(1+exp(-e)) and integration by parts yield

    integral y^2 log(1+exp(-e)) dy
       = (1/3) integral y^4 f/e dy.

The boundary term y^3 log(1+exp(-e)) is bounded by y^3 log2 at zero and
by y^3 exp(-y) at infinity. Both limits vanish. Multiplying the combined
moments by g/(2pi^2) gives exactly (rho_F+p_F)/T^4=s_F/T^3. The
occupation and thermodynamic entropy therefore agree, including the factor
1/3 and temperature powers.

The hot energy and logarithmic entropy moments follow from convergent
exponential series and the exact fourth zeta value. They are 7pi^4/120 and
7pi^4/360. Four fermion states give 7pi^2/45 for s_F/T^3; the two photons
give 4pi^2/45. Hence

    h_cold=4pi^2/45 < h(T)=s/T^3 < h_hot=11pi^2/45

at finite m,T>0. The hot entropy integrand is an integrable majorant, so
dominated convergence supplies the hot and cold limits. The strict finite
upper bound is analytic and does not depend on a finite temperature grid.

Zero chemical potential is a substantive premise. With a nonzero
alpha=mu/T, the mass derivative becomes
-(e-alpha)(x/e)f(1-f), which can be positive. The exact outside-domain
tuple e=log2, alpha=log8 and x/e=1/2 gives f=4/5 and derivative
2log4/25>0. The Gibbs identity also acquires mu n. This demonstrates why
the proof cannot silently include degenerate finite-density states; it is
not a counterexample within the source's stated domain. General Bose
species require the Bose entropy and f(1+f) derivative, and the source's
generalization is explicitly conditional on analogous entropy and G bounds.

## The correlation and its consequences

For the same total bath at the bounce, rho+p=Ts gives the exact identity

    (1+w_b)G_b=(rho_b+p_b)/s_b^(4/3)
               =T_b/s_b^(1/3)=h_b^(-1/3).

Combining this with zeta=sigma^(4/3)G_f/G_b keeps the bounce pressure and
charge factors linked:

    f_b zeta < (2/3)sigma^(4/3)G_f h_b^(1/3)
              <=(2/3)sigma^(4/3)G_cold h_hot^(1/3).

At the hot endpoint, w_hot=1/3, so G_hot=(3/4)h_hot^(-1/3).
The final expression is precisely (R/2)sigma^(4/3). The strict bounce
cap supplies strictness even if the weaker closed entropy/G endpoint
bounds are used. Finite-temperature endpoint strictness is additional.

One exact control exposes the earlier separate-maximization issue: choosing
w_b=0 and G_b=G_hot simultaneously would require
h_b/h_hot=(4/3)^3=64/27>1 through Gibbs. The entropy bound forbids that
combination. This shows why the old coarse bound can remain true while
missing the stronger conclusion.

Additional controls use exact comparison factors
v_b=f_b/[2/(3(1+w_b))], t_f=G_f/G_cold and t_h=h_b/h_hot. They give

    f_b zeta=(R/2)sigma^(4/3)v_b t_f t_h^(1/3),
    0<v_b<1, 0<t_f<=1, 0<t_h<=1.

These comparison tuples check the algebra and strict margin; they do not
assert arbitrary factor choices are actual independent bath states or
endpoints of a gravitational history. Approaching the comparison bound would
require compatible hot/cold endpoints and a bounce approaching its cap.
The source does not construct such a history or claim sharp attainability.

The bare coefficient is 2/R, whose cube is 32/11 and whose value is
approximately 1.427531711007216. Division by a positive gamma with the
stated same-background ceiling gamma<(4/3)(1+eta) gives the measured
coefficient 3/[2R(1+eta)]. Its eta=0 cube is 27/22, and its value is
approximately 1.070648783255412. Both lower bounds improve the old
coarse values by exactly 4/3.

For a positive target L the strict radius and entropy conditions are

    exp(2N)<(2R/3)sigma^(4/3)(1+eta)L,
    sigma>[3exp(2N)/(2R(1+eta)L)]^(3/4).

The radius cap at sigma=1,eta=0,L=1 has cube 22/27<1. It cannot be
reached by exp(2N)>=1. Equality is also rejected, rather than lost through
rounding or changing '<' to '<='. A nonpositive target is already
impossible for the positive diagnostic and is not substituted into divided
fractional-power budgets. Assigning sigma is an endpoint allowance, not
a production process.

Under the separately adopted distinct-background ceiling, the necessary
threshold is

    C_c<(R/2)sigma^(4/3)(1+eta)(1+k)L exp(-2N).

It is 3/4 of the earlier coarse threshold. Below one the previously checked
negative-u energy theorem can be applied; at one there is no uniform
positive gap above vacuum, and above one the threshold alone forces no
negative-u state. This unit checks the new threshold algebra, not the old
potential theorem or a realized local/cosmic environmental connection.

For an ideal bath satisfying the stated generalized premises, the inclusive
sufficient unit-target thresholds are R<=2 for the bare diagnostic and
R<=3/2 for the matched eta=0 calibrated diagnostic. Equality is included
because the bounce/product lower bound is strict. R above those thresholds
only removes this sufficient obstruction and does not establish a solution.

## Actual execution history and damages

The new mathematical baseline completed **64 passed, 0 failed**, exit 0,
with Python 3.12.8 and SymPy 1.14.0. All comparisons are exact or symbolic;
decimal constants are display only. Separate evidence verification completed
**25/0 metadata checks**. These are not added to the science count.

The first mutation wrapper then stopped on a unique-match assertion. Its
fourth text target was a return-line prefix that occurred in both joint_cap
and distinct_threshold. This was a real orchestration defect, preserved in
the original wrapper, protocol, launch record and traceback. The guard
prevented either unintended change. The baseline and first three actual
damages had completed and remain unchanged.

The repair anchors complete lines with their newline. A separate v2 wrapper
imports only the reviewer's own process/logging helper and executes the five
remaining cases. The baseline, first three controls and mathematical checker
were not changed or rerun. EXECUTION_RESULTS_v2.json assembles those actual
records; it is not a claim of a fresh clean second science run.

| Actual changed implementation | Pass / fail | Intended failed witness |
| --- | --- | --- |
| Delete Fermi hole entropy | 58 / 6 | occupation.fermion_entropy_derivative |
| Pressure integration factor 1/2 | 63 / 1 | ibp.pressure_factor |
| Reverse Gibbs entropy power | 62 / 2 | gibbs.pressure_entropy_identity |
| Drop correlated hot factor | 59 / 5 | joint.hot_endpoint_cap |
| Entropy power 1 | 56 / 8 | joint.entropy_ratio_power |
| Multiply by gamma | 60 / 4 | calibration.inverse_direction |
| Accept strict radius equality | 61 / 3 | measured.radius_equality_rejected |
| Invert distinct-background 1+k | 61 / 3 | distinct.threshold_rearrangement |

Every damaged child exited 1 and failed its predeclared witness. The
decoupling control is classified carefully: it restores a valid coarse
upper bound but fails the exact joint identity and claimed improvement.
It is not evidence that the old coarse inequality was false. Other
changes alter the asserted statistics, algebra, normalization or strict
domain. Full sources, one-edit diffs, command argv/cwd, code hashes,
stdout/stderr, exits and failed-witness names are retained. No producer
script was damaged or used as the oracle.

## Limits and final evidence

The particle content, degeneracies, ideal Fermi/Bose distributions, zero
chemical potentials, common temperature, fixed physical masses and equilibrium
endpoint definitions remain premises. Positive massless cold content is needed
for the finite ratio. The same selected total bath must appear in f_b,
zeta and the final diagnostic; photon-only or additional independently
heated sectors need different formulas.

The strict Einstein bounce, positive scalar kinetic metric, nonnegative other
enthalpy, final Z!=0, and N>=0 for the unit-target corollary remain explicit.
No temperature ordering or monotone conformal factor is used, but neither is
a full thermal/gravity evolution obtained. The product target remains only
necessary for separate curvature and expansion targets. The weak-source
calibration and eta are adopted physical applicability inputs, not a body
solution or measured uncertainty. No rate condition, initial state, physical
scale, abundance likelihood, empirical exclusion, perturbation-stability
result or general Jordan-bounce theorem follows.

Only this new independent_v1 folder was written. Parent science and previous
seals were preserved; no Git, PR, runtime/lock, audit, outside-chat or authority
state changed. REPORT_v1.md, MANIFEST_v1.json and RECEIPT_v1.json form the
final seal. The manifest excludes only itself and the receipt; the receipt
binds both, all sources, the reused seal, actual executions and the preserved
wrapper failure.
