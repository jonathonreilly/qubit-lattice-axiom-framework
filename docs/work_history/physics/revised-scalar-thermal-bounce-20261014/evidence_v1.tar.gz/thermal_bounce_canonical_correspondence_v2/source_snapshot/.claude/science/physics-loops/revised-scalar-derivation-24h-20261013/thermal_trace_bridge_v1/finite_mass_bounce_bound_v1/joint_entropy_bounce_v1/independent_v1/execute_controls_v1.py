#!/usr/bin/env python3
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def put(path, value):
    with path.open("x") as f:
        json.dump(value, f, indent=2)
        f.write("\n")


def run(script, folder, witness):
    folder.mkdir()
    argv = [sys.executable, "-B", str(script)]
    env = os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE="1", PYTHONHASHSEED="0")
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    proc = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True, timeout=60)
    elapsed = time.monotonic() - tick
    (folder / "stdout.json").write_bytes(proc.stdout)
    (folder / "stderr.txt").write_bytes(proc.stderr)
    try:
        result = json.loads(proc.stdout)
        failures = [x["name"] for x in result["checks"] if not x["passed"]]
        error = None
    except Exception as exc:
        result, failures, error = {}, [], repr(exc)
    row = {"started_utc": started, "elapsed_seconds": elapsed, "argv": argv, "cwd": str(ROOT), "environment_overrides": {"PYTHONDONTWRITEBYTECODE": "1", "PYTHONHASHSEED": "0"}, "script_relative": str(script.relative_to(ROOT)), "script_sha256": sha(script.read_bytes()), "hand_derivation_sha256": sha((ROOT / "HAND_DERIVATION_v1.md").read_bytes()), "control_protocol_sha256": sha((ROOT / "CONTROL_PROTOCOL_v1.json").read_bytes()), "stdout_sha256": sha(proc.stdout), "stderr_sha256": sha(proc.stderr), "exit_code": proc.returncode, "pass_count": result.get("pass_count"), "fail_count": result.get("fail_count"), "failed_witnesses": failures, "expected_witness": witness, "parse_error": error}
    row["expected_outcome_confirmed"] = (proc.returncode == 0 and not failures and error is None) if witness is None else (proc.returncode == 1 and witness in failures and error is None)
    put(folder / "COMMAND_v1.json", row)
    return row


def main():
    source = ROOT / "check_joint_v1.py"
    original = source.read_text()
    baseline = run(source, ROOT / "runs/baseline_v1", None)
    result = {"baseline": baseline, "mutations": []}
    if not baseline["expected_outcome_confirmed"]:
        put(ROOT / "EXECUTION_RESULTS_v1.json", result)
        print(json.dumps(result, indent=2))
        return 1
    cases = [
        ("missing_hole_entropy", "return -f * sp.log(f) - (1 - f) * sp.log(1 - f)", "return -f * sp.log(f)", "occupation.fermion_entropy_derivative", "incorrect Fermi entropy"),
        ("pressure_half", "PRESSURE_FACTOR = Q(1, 3)", "PRESSURE_FACTOR = Q(1, 2)", "ibp.pressure_factor", "incorrect integration-by-parts pressure factor"),
        ("gibbs_power_reversed", "return h ** Q(-1, 3)", "return h ** Q(1, 3)", "gibbs.pressure_entropy_identity", "incorrect Gibbs entropy exponent"),
        ("drop_correlated_hot_factor", "return Q(1, 2) * R * entropy_power(sigma)", "return Q(2, 3) * R * entropy_power(sigma)", "joint.hot_endpoint_cap", "valid coarse weakening but fails the asserted correlated identity/improvement; not a false generic upper bound"),
        ("entropy_linear", "return sigma ** Q(4, 3)", "return sigma", "joint.entropy_ratio_power", "incorrect endpoint entropy power"),
        ("gamma_multiply", "return pb / gamma", "return pb * gamma", "calibration.inverse_direction", "incorrect measured normalization"),
        ("nonstrict_radius", "return r < cap", "return r <= cap", "measured.radius_equality_rejected", "incorrect target boundary acceptance"),
        ("inverse_one_plus_k", "return Q(1, 2) * R * entropy_power(sigma) * (1 + eta) * (1 + k) * target / r", "return Q(1, 2) * R * entropy_power(sigma) * (1 + eta) * target / (r * (1 + k))", "distinct.threshold_rearrangement", "incorrect distinct-background threshold"),
    ]
    put(ROOT / "mutations/PROTOCOL_v1.json", {"source_sha256": sha(source.read_bytes()), "cases": [{"name": name, "old": old, "new": new, "expected_witness": witness, "interpretation": interpretation} for name, old, new, witness, interpretation in cases]})
    for name, old, new, witness, interpretation in cases:
        assert original.count(old) == 1
        changed = original.replace(old, new)
        folder = ROOT / "mutations" / name
        folder.mkdir()
        script = folder / "damaged_check_v1.py"
        script.write_text(changed)
        diff = "".join(difflib.unified_diff(original.splitlines(True), changed.splitlines(True), fromfile="check_joint_v1.py", tofile=str(script.relative_to(ROOT))))
        (folder / "SOURCE_CHANGE.diff").write_text(diff)
        row = run(script, folder / "run_v1", witness)
        row.update(mutation=name, interpretation=interpretation, diff_sha256=sha(diff.encode()))
        result["mutations"].append(row)
    result["all_expected_outcomes_confirmed"] = all(x["expected_outcome_confirmed"] for x in result["mutations"])
    put(ROOT / "EXECUTION_RESULTS_v1.json", result)
    print(json.dumps({"baseline": [baseline["pass_count"], baseline["fail_count"]], "mutations": [{"name": x["mutation"], "exit_code": x["exit_code"], "failed_witnesses": x["failed_witnesses"], "expected_outcome_confirmed": x["expected_outcome_confirmed"], "interpretation": x["interpretation"]} for x in result["mutations"]]}, indent=2))
    return int(not result["all_expected_outcomes_confirmed"])


if __name__ == "__main__":
    sys.exit(main())
