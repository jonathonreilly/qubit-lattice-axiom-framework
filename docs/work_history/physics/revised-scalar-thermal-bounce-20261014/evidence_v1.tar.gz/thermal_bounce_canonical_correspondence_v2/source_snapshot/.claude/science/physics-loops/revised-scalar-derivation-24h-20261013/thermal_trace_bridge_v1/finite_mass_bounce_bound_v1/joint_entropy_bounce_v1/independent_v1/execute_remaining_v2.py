#!/usr/bin/env python3
"""Complete only five unexecuted mutations after an exact-match guard failure."""
from pathlib import Path
import datetime
import difflib
import hashlib
import importlib.util
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("own_preserved_control_helpers", ROOT / "execute_controls_v1.py")
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)


def main():
    source = ROOT / "check_joint_v1.py"
    original = source.read_text()
    p1 = json.loads((ROOT / "mutations/PROTOCOL_v1.json").read_text())
    assert hashlib.sha256(source.read_bytes()).hexdigest() == p1["source_sha256"]
    baseline = json.loads((ROOT / "runs/baseline_v1/COMMAND_v1.json").read_text())
    assert baseline["expected_outcome_confirmed"] and baseline["pass_count"] == 64
    prior = []
    for case in p1["cases"][:3]:
        folder = ROOT / "mutations" / case["name"]
        row = json.loads((folder / "run_v1/COMMAND_v1.json").read_text())
        assert row["expected_outcome_confirmed"]
        assert hashlib.sha256((folder / "damaged_check_v1.py").read_bytes()).hexdigest() == row["script_sha256"]
        row.update(mutation=case["name"], interpretation=case["interpretation"], execution_wrapper="launch_v1_preserved")
        prior.append(row)
    replacements = []
    for case in p1["cases"][3:]:
        row = dict(case)
        row["old"] += "\n"
        row["new"] += "\n"
        assert original.count(row["old"]) == 1, case["name"]
        replacements.append(row)
    helpers.put(ROOT / "mutations/PROTOCOL_v2.json", {"source_sha256": p1["source_sha256"], "prior_three_actual_runs_reused_unchanged": [x["name"] for x in p1["cases"][:3]], "remaining_cases": replacements, "repair": "Exact newline anchor; changes intended complete lines only. No mathematical baseline source change or rerun."})
    repair = {"created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "original_wrapper": "execute_controls_v1.py", "original_wrapper_sha256": hashlib.sha256((ROOT / "execute_controls_v1.py").read_bytes()).hexdigest(), "original_launch": "runs/LAUNCH_v1.json", "original_stderr": "runs/launch_v1.stderr.txt", "failure": "A unique-match assertion failed at fourth case because the joint_cap return-line prefix also occurred in the distinct_threshold return line.", "failed_prefix_matches": original.count(p1["cases"][3]["old"]), "partial_mutation_at_failure": False, "executed_before_failure": {"baseline": "64/0", "actual_damages": 3}, "repair": "Anchor each remaining old/new target with the newline, then run only the five unexecuted copies.", "baseline_checker_changed": False, "baseline_checker_rerun": False, "first_three_controls_rerun": False, "new_wrapper_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    helpers.put(ROOT / "WRAPPER_REPAIR_v2.json", repair)
    result = {"baseline": baseline, "mutations": prior, "execution_lineage": "One baseline and three damage executions before preserved wrapper guard failure; five remaining damages after exact-line repair. No new baseline science run."}
    for case in replacements:
        name = case["name"]
        folder = ROOT / "mutations" / name
        folder.mkdir()
        script = folder / "damaged_check_v1.py"
        changed = original.replace(case["old"], case["new"])
        script.write_text(changed)
        diff = "".join(difflib.unified_diff(original.splitlines(True), changed.splitlines(True), fromfile="check_joint_v1.py", tofile=str(script.relative_to(ROOT))))
        (folder / "SOURCE_CHANGE.diff").write_text(diff)
        row = helpers.run(script, folder / "run_v1", case["expected_witness"])
        row.update(mutation=name, interpretation=case["interpretation"], execution_wrapper="launch_v2_remaining_only", diff_sha256=hashlib.sha256(diff.encode()).hexdigest())
        result["mutations"].append(row)
    result["all_expected_outcomes_confirmed"] = all(x["expected_outcome_confirmed"] for x in result["mutations"])
    helpers.put(ROOT / "EXECUTION_RESULTS_v2.json", result)
    print(json.dumps({"baseline_reused": [64, 0], "mutations": [{"name": x["mutation"], "exit_code": x["exit_code"], "failed_witnesses": x["failed_witnesses"], "expected_outcome_confirmed": x["expected_outcome_confirmed"]} for x in result["mutations"]]}, indent=2))
    return int(not result["all_expected_outcomes_confirmed"])


if __name__ == "__main__":
    sys.exit(main())
