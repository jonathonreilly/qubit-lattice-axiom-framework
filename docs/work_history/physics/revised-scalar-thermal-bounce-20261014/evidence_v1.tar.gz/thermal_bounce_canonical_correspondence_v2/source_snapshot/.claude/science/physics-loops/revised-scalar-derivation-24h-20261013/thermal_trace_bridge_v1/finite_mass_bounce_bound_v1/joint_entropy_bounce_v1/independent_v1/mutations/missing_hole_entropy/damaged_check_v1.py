#!/usr/bin/env python3
"""Fresh exact occupation/Gibbs/joint-bound controls. No project imports or quadrature."""
import json
import sys
import traceback

import sympy as sp

Q = sp.Rational
RPAIR = sp.real_root(Q(11, 4), 3)
PRESSURE_FACTOR = Q(1, 3)


def occupation_entropy(f):
    return -f * sp.log(f)


def gibbs_product(h):
    return h ** Q(-1, 3)


def entropy_power(sigma):
    return sigma ** Q(4, 3)


def joint_cap(R, sigma):
    return Q(1, 2) * R * entropy_power(sigma)


def calibrated_product(pb, gamma):
    return pb / gamma


def bare_floor(r, R, sigma):
    return r / joint_cap(R, sigma)


def measured_floor(r, R, sigma, eta):
    return Q(3, 4) * bare_floor(r, R, sigma) / (1 + eta)


def radius_cap(R, sigma, eta, target):
    return Q(2, 3) * R * entropy_power(sigma) * (1 + eta) * target


def radius_allowed(r, cap):
    return r < cap


def distinct_threshold(r, R, sigma, eta, k, target):
    return Q(1, 2) * R * entropy_power(sigma) * (1 + eta) * (1 + k) * target / r


checks = []


def zero(x):
    return sp.simplify(x) == 0


def positive(x):
    return sp.simplify(x).is_positive is True


def record(name, condition, detail=""):
    try:
        value = condition() if callable(condition) else condition
        row = {"name": name, "passed": bool(value), "detail": str(detail)}
        if not row["passed"]:
            row["actual"] = str(value)
    except Exception:
        row = {"name": name, "passed": False, "detail": str(detail), "exception": traceback.format_exc()}
    checks.append(row)


def main():
    f = sp.symbols("f", positive=True)
    e, x, y, t = sp.symbols("e x y t", positive=True)
    hfprime = sp.diff(occupation_entropy(f), f)
    record("occupation.fermion_entropy_derivative", zero(hfprime - (sp.log(1 - f) - sp.log(f))))
    record("occupation.half_occupation_entropy", zero(occupation_entropy(Q(1, 2)) - sp.log(2)))
    record("occupation.rational_log_odds", zero(hfprime.subs(f, Q(1, 5)) - sp.log(4)))
    fe = 1 / (sp.exp(e) + 1)
    record("occupation.zero_mu_odds", zero((1 - fe) / fe - sp.exp(e)))
    record("occupation.distribution_derivative", zero(sp.diff(fe, e) + fe * (1 - fe)))
    # Log expansion is justified by positive exp(e), exp(e)+1 and f in (0,1).
    actual_hfe = sp.simplify(sp.expand_log(hfprime.subs(f, fe), force=True) * sp.diff(fe, e))
    record("occupation.energy_derivative", zero(actual_hfe + e * fe * (1 - fe)))
    record("occupation.mass_derivative", zero(actual_hfe * x / e + x * fe * (1 - fe)))
    record("occupation.mass_derivative_strict_sign", positive(x * fe * (1 - fe)))
    # Boltzmann variable t=exp(-e)>0 avoids treating a CAS radical/log form
    # as evidence. This identity actually holds for every positive t.
    ft = t / (1 + t)
    ht = sp.expand_log(sp.simplify(occupation_entropy(ft)), force=True)
    record("occupation.energy_plus_log_identity", zero(ht - (-sp.log(t) * ft + sp.log(1 + t))))

    energy = sp.sqrt(x ** 2 + y ** 2)
    fy = 1 / (sp.exp(energy) + 1)
    logterm = sp.log(1 + sp.exp(-energy))
    record("ibp.log_derivative", zero(sp.diff(logterm, y) + y * fy / energy))
    primitive = y ** 3 * logterm / 3
    record("ibp.pressure_factor", zero(sp.diff(primitive, y) - (y ** 2 * logterm - PRESSURE_FACTOR * y ** 4 * fy / energy)))
    record("ibp.lower_boundary_majorant", sp.limit(y ** 3 * sp.log(2), y, 0, dir="+") == 0)
    record("ibp.upper_boundary_majorant", sp.limit(y ** 3 * sp.exp(-y), y, sp.oo) == 0)

    n = sp.symbols("n", positive=True)
    moment3 = sp.integrate(y ** 3 * sp.exp(-n * y), (y, 0, sp.oo))
    moment2 = sp.integrate(y ** 2 * sp.exp(-n * y), (y, 0, sp.oo))
    record("hot.laplace_energy_moment", zero(moment3 - 6 / n ** 4))
    record("hot.laplace_log_moment", zero(moment2 / n - 2 / n ** 4))
    alternating_zeta4 = Q(7, 8) * sp.zeta(4)
    hot_energy = 6 * alternating_zeta4
    hot_log = 2 * alternating_zeta4
    record("hot.fermion_energy_integral", zero(hot_energy - 7 * sp.pi ** 4 / 120))
    record("hot.fermion_log_integral", zero(hot_log - 7 * sp.pi ** 4 / 360))
    hfhot = 4 * (hot_energy + hot_log) / (2 * sp.pi ** 2)
    hphot = 2 * Q(4, 3) * (6 * sp.zeta(4)) / (2 * sp.pi ** 2)
    hhot = hfhot + hphot
    record("hot.fermion_degeneracy_four", zero(hfhot - 7 * sp.pi ** 2 / 45))
    record("hot.photon_degeneracy_two", zero(hphot - 4 * sp.pi ** 2 / 45))
    record("hot.total_entropy_coefficient", zero(hhot - 11 * sp.pi ** 2 / 45))
    record("hot.entropy_hot_cold_ratio", zero(hhot / hphot - Q(11, 4)))

    # The monotonicity proof requires the stated statistics and zero mu.
    # This is an exact counterexample outside that domain, not a source error.
    mu_over_T = sp.log(8)
    e0 = sp.log(2)
    f_nonzero_mu = 1 / (sp.exp(e0 - mu_over_T) + 1)
    nonzero_mu_dx = -(e0 - mu_over_T) * Q(1, 2) * f_nonzero_mu * (1 - f_nonzero_mu)
    record("domain.nonzero_mu_reverses_mass_entropy_sign", zero(nonzero_mu_dx - 2 * sp.log(4) / 25) and positive(nonzero_mu_dx))
    record("domain.nonzero_mu_exceeds_half_occupation", f_nonzero_mu == Q(4, 5) and f_nonzero_mu > Q(1, 2))
    bose_f = 1 / (sp.exp(e) - 1)
    record("domain.bose_occupation_is_not_fermi", zero(sp.diff(bose_f, e) + bose_f * (1 + bose_f)) and not zero(sp.diff(bose_f, e) + bose_f * (1 - bose_f)))

    T, sd, wb, hb, H, R, sigma, r, eta, target, k, c = sp.symbols("T s w_b h_b H R sigma r eta L k C", positive=True)
    rho = T * sd / (1 + wb)
    G = rho / sd ** Q(4, 3)
    record("gibbs.pressure_entropy_identity", zero((1 + wb) * G - gibbs_product(sd / T ** 3)))
    record("gibbs.rational_nonunit_entropy", gibbs_product(Q(27, 8)) == Q(2, 3))
    chemical_mu, number = sp.symbols("mu n", positive=True)
    record("domain.chemical_gibbs_has_extra_term", positive(chemical_mu * number / sd ** Q(4, 3)))
    # Derive the joint cap from the pressure-dependent bounce cap, retaining
    # the exact shared bounce G. The hot G comes from w_hot=1/3.
    Gh = Q(3, 4) * H ** Q(-1, 3)
    Gb = hb ** Q(-1, 3) / (1 + wb)
    Gc = R * Gh
    correlated = 2 / (3 * (1 + wb)) * entropy_power(sigma) * Gc / Gb
    record("joint.pressure_cancels_only_through_Gibbs", zero(correlated - Q(2, 3) * entropy_power(sigma) * Gc * hb ** Q(1, 3)))
    record("joint.hot_endpoint_cap", zero(correlated.subs(hb, H) - joint_cap(R, sigma)))
    record("joint.forbidden_coarse_independent_maximum", Q(64, 27) > 1 and zero((Gh ** -3) / H - Q(64, 27)))
    record("joint.entropy_ratio_power", entropy_power(Q(27, 8)) == Q(81, 16))
    # Exact comparison slacks. No claim these freely chosen numbers describe
    # a full bath or field history is made.
    vb, tf, th = Q(13, 17), Q(19, 23), Q(216, 343)
    sig = Q(27, 8)
    direct_product = (vb * 2 / (3 * (1 + Q(1, 4)))) * sig ** Q(4, 3) * (tf * RPAIR * Q(3, 4) / 2) / ((8 * th) ** Q(-1, 3) / (1 + Q(1, 4)))
    factored_product = joint_cap(RPAIR, sig) * vb * tf * th ** Q(1, 3)
    record("joint.exact_correlated_slack_product", zero(direct_product - factored_product))
    record("joint.strict_margin_at_rational_slacks", positive(joint_cap(RPAIR, sig) - direct_product))
    record("joint.strictness_at_weak_endpoint_limits", positive(joint_cap(RPAIR, sig) * (1 - vb)))
    for i, (v0, t0, h0) in enumerate([(Q(9, 10), Q(1), Q(1)), (Q(99, 100), Q(7, 8), Q(64, 125)), (Q(1, 3), Q(3, 4), Q(1))], 1):
        actual = RPAIR * sig ** Q(4, 3) * v0 * t0 * h0 ** Q(1, 3) / 2
        record(f"joint.corner_{i}_strict", positive(joint_cap(RPAIR, sig) - actual))

    record("bare.positive_inverse", zero(bare_floor(r, R, sigma) - 2 * r / (R * sigma ** Q(4, 3))))
    record("bare.coefficient_cube", zero((2 / RPAIR) ** 3 - Q(32, 11)))
    record("bare.improvement_factor", zero((2 / R) / (3 / (2 * R)) - Q(4, 3)))
    pb, gamma = sp.symbols("P_bare gamma", positive=True)
    record("calibration.inverse_direction", zero(calibrated_product(pb, gamma) * gamma - pb))
    record("calibration.rational_conversion", calibrated_product(Q(7, 4), Q(9, 8)) == Q(14, 9))
    record("measured.coefficient_from_ceiling", zero(measured_floor(r, R, sigma, eta) - 3 * r / (2 * R * sigma ** Q(4, 3) * (1 + eta))))
    a0, delta, q = sp.symbols("A0 Delta q", positive=True)
    strict_margin = (a0 * (1 - 3 * q) + 4 * delta) / (4 * (1 + eta) * (1 + q))
    record("measured.strict_calibration_margin_identity", zero(calibrated_product(a0 + delta, (1 + eta) * (1 + q)) - 3 * a0 / (4 * (1 + eta)) - strict_margin))
    record("measured.strict_calibration_rational_corner", positive(strict_margin.subs({a0: Q(7, 5), delta: Q(1, 13), eta: Q(2, 7), q: Q(3, 10)})))
    record("measured.coefficient_cube", zero((3 / (2 * RPAIR)) ** 3 - Q(27, 22)))
    record("measured.unit_coefficient_above_one", Q(27, 22) > 1)
    record("measured.strict_radius_rearrangement", zero(measured_floor(radius_cap(R, sigma, eta, target), R, sigma, eta) - target))
    record("measured.radius_equality_rejected", not radius_allowed(Q(7, 6), Q(7, 6)))
    record("measured.radius_below_allowed", radius_allowed(Q(9, 8), Q(7, 6)))
    record("measured.radius_above_rejected", not radius_allowed(Q(5, 4), Q(7, 6)))
    # For the pair bath, 2R/3<1 follows exactly by cubing positive quantities.
    record("measured.pair_unit_radius_cap_below_one", zero((2 * RPAIR / 3) ** 3 - Q(22, 27)) and Q(22, 27) < 1)
    sig0, r0, eta0 = Q(27, 8), Q(7, 3), Q(2, 5)
    L0 = 3 * r0 / (2 * RPAIR * sig0 ** Q(4, 3) * (1 + eta0))
    budget = (3 * r0 / (2 * RPAIR * (1 + eta0) * L0)) ** Q(3, 4)
    record("entropy.budget_inverse", zero(budget - sig0))
    record("entropy.smaller_sigma_violates_target", positive(measured_floor(r0, RPAIR, sig0 / 8, eta0) - L0))

    gmax = (1 + eta) * (1 + k) / c
    distinct_direct = calibrated_product(2 * r / (R * sigma ** Q(4, 3)), gmax)
    record("distinct.threshold_rearrangement", zero(distinct_direct.subs(c, distinct_threshold(r, R, sigma, eta, k, target)) - target))
    record("distinct.tighter_than_coarse_by_three_quarters", zero(distinct_threshold(r, R, sigma, eta, k, target) / (2 * R * sigma ** Q(4, 3) * (1 + eta) * (1 + k) * target / (3 * r)) - Q(3, 4)))
    record("distinct.threshold_decreases_with_radius", positive(-sp.diff(distinct_threshold(r, R, sigma, eta, k, target), r)))
    record("distinct.threshold_increases_with_k", positive(sp.diff(distinct_threshold(r, R, sigma, eta, k, target), k)))
    # Inclusive sufficient general-bath thresholds, strict in the target itself.
    record("general.bare_R_two_boundary_rejected", not radius_allowed(sp.Integer(1), Q(2) / 2))
    record("general.measured_R_three_halves_boundary_rejected", not radius_allowed(sp.Integer(1), radius_cap(Q(3, 2), Q(1), Q(0), Q(1))))
    record("general.above_threshold_only_removes_obstruction", radius_allowed(sp.Integer(1), radius_cap(Q(7, 4), Q(1), Q(0), Q(1))))
    record("domain.positive_product_cannot_meet_nonpositive_target", Q(1, 10) > 0 and not Q(1, 10) <= 0)
    record("scope.product_not_sufficient_for_individual_targets", Q(1, 100) * 5 <= Q(1, 10) and 5 > 1)
    record("scope.same_component_photon_ratio_differs", zero((Q(11, 4) ** Q(4, 3)) / RPAIR - Q(11, 4)))

    result = {"schema": "independent-joint-entropy-bounce-v1", "python": sys.version, "sympy": sp.__version__, "pass_count": sum(x["passed"] for x in checks), "fail_count": sum(not x["passed"] for x in checks), "checks": checks, "display_only": {"R": str(sp.N(RPAIR, 30)), "bare_coefficient": str(sp.N(2 / RPAIR, 30)), "matched_measured_coefficient": str(sp.N(3 / (2 * RPAIR), 30))}, "finite_mass_quadrature_performed": False, "old_checker_import_or_execution": False, "scope": "Exact occupation and correlated endpoint comparison. Finite exact controls complement the hand proof, not a full thermal or gravitational history."}
    print(json.dumps(result, indent=2))
    return int(result["fail_count"] != 0)


if __name__ == "__main__":
    sys.exit(main())
