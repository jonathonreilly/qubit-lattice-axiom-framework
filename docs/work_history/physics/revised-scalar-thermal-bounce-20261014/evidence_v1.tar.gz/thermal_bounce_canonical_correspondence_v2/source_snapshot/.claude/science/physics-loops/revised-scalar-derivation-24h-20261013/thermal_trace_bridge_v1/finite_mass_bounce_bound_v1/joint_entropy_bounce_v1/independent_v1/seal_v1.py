#!/usr/bin/env python3
"""Validate identities, preserve lineage metadata, and seal this new unit only."""
from pathlib import Path
import datetime
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent


def load(name):
    return json.loads((ROOT / name).read_text())


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def ref(name):
    p = ROOT / name
    return {"path": name, "bytes": p.stat().st_size, "sha256": sha(p)}


def put(name, value):
    with (ROOT / name).open("x") as f:
        json.dump(value, f, indent=2)
        f.write("\n")


def main():
    assert not (ROOT / "MANIFEST_v1.json").exists()
    assert not (ROOT / "RECEIPT_v1.json").exists()
    sources = load("SOURCE_MANIFEST_v1.json")
    worktree = Path(sources["worktree"])
    for x in sources["sources"]:
        a, b = worktree / x["original_path"], ROOT / x["snapshot_path"]
        assert a.stat().st_size == b.stat().st_size == x["bytes"]
        assert sha(a) == sha(b) == x["sha256"]
    reuse = load("REUSED_FINITE_MASS_SEAL_v1.json")
    old = Path(reuse["root"])
    oldm = load("sources/06_FINITE_MASS_MANIFEST_v1.json")
    oldr = load("sources/04_FINITE_MASS_RECEIPT_v1.json")
    for x in oldm["artifacts"]:
        q = old / x["path"]
        assert q.stat().st_size == x["bytes"] and sha(q) == x["sha256"]
    inventory = {str(p.relative_to(old)) for p in old.rglob("*") if p.is_file()}
    assert inventory == {x["path"] for x in oldm["artifacts"]} | set(oldm["excluded_seal_files"])
    assert len(inventory) == 94
    for x in oldr["source_pairs"]:
        a, b = worktree / x["original_path"], old / x["snapshot_path"]
        assert a.stat().st_size == b.stat().st_size == x["bytes"] and sha(a) == sha(b) == x["sha256"]
    for name, field in [("RECEIPT_v1.json", "receipt_sha256"), ("REPORT_v1.md", "report_sha256"), ("MANIFEST_v1.json", "manifest_sha256")]:
        assert sha(old / name) == reuse[field]

    result = load("EXECUTION_RESULTS_v2.json")
    assert result["baseline"]["pass_count"] == 64 and result["baseline"]["fail_count"] == 0
    assert len(result["mutations"]) == 8 and all(x["expected_outcome_confirmed"] for x in result["mutations"])
    commands = []
    paths = [ROOT / "runs/baseline_v1/COMMAND_v1.json"] + sorted((ROOT / "mutations").glob("*/run_v1/COMMAND_v1.json"))
    assert len(paths) == 9
    for p in paths:
        row = json.loads(p.read_text())
        assert row["expected_outcome_confirmed"]
        assert sha(ROOT / row["script_relative"]) == row["script_sha256"]
        assert sha(ROOT / "HAND_DERIVATION_v1.md") == row["hand_derivation_sha256"]
        assert sha(ROOT / "CONTROL_PROTOCOL_v1.json") == row["control_protocol_sha256"]
        assert sha(p.parent / "stdout.json") == row["stdout_sha256"]
        assert sha(p.parent / "stderr.txt") == row["stderr_sha256"]
        commands.append({"record": ref(str(p.relative_to(ROOT))), "argv": row["argv"], "cwd": row["cwd"], "exit_code": row["exit_code"], "passed": row["pass_count"], "failed": row["fail_count"], "expected_outcome_confirmed": row["expected_outcome_confirmed"]})
    evidence = load("runs/evidence_v1/stdout.json")
    ev_command = load("runs/evidence_v1/COMMAND_v1.json")
    assert (evidence["pass_count"], evidence["fail_count"], ev_command["exit_code"]) == (25, 0, 0)
    assert sha(ROOT / "runs/evidence_v1/stdout.json") == ev_command["stdout_sha256"]
    assert sha(ROOT / "runs/evidence_v1/stderr.txt") == ev_command["stderr_sha256"]
    assert sha(ROOT / "verify_evidence_v1.py") == ev_command["script_sha256"]
    for version, expected_exit, script in [(1, 1, "execute_controls_v1.py"), (2, 0, "execute_remaining_v2.py")]:
        row = load(f"runs/LAUNCH_v{version}.json")
        assert row["exit_code"] == expected_exit
        assert sha(ROOT / script) == row["script_sha256"]
        assert sha(ROOT / f"runs/launch_v{version}.stdout.txt") == row["stdout_sha256"]
        assert sha(ROOT / f"runs/launch_v{version}.stderr.txt") == row["stderr_sha256"]

    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    put("ACCESS_AND_SCOPE_v1.json", {"created_utc": now, "scientific_author": "/root", "independent_checker": "/root/scalar_energy_check", "formal_audit": False, "formal_grade_assigned": False, "landing_authority": False, "write_root": str(ROOT), "source_inventory": "SOURCE_MANIFEST_v1.json", "producer_code_or_outputs_accessed": False, "prior_science_code_imported_or_rerun": False, "prior_report_receipt_read_for_reuse": True, "prior_artifact_bytes_hashed_only": True, "own_v1_process_helper_imported_by_repair_wrapper": True, "finite_mass_quadrature_performed": False, "new_external_or_empirical_data": False, "git_pr_runtime_lock_audit_changes": False, "subagents_or_other_chats": False, "reuse_scope": reuse["reused_bounds"], "new_scope": ["occupation entropy bound and IBP", "Gibbs-correlated bounce/charge product", "improved calibrated and target inequalities", "statistics/domain/strictness countercontrols"]})
    put("FINDINGS_v1.json", {"created_utc": now, "source_errors_identified": [], "source_correction_requested": False, "source_unchanged": True, "bounded_conclusion": "The correlated joint bound and measured consequence agree under the explicitly adopted bath, strict bounce, endpoint and calibration premises.", "limitations": ["No full-history or attainability claim", "No real-body calibration or error estimate", "Zero chemical potential and same total bath essential", "General-bath claim conditional on analogous entropy/G bounds"]})
    failed_rows = [{"mutation": x["mutation"], "command": ref("mutations/" + x["mutation"] + "/run_v1/COMMAND_v1.json"), "exit_code": x["exit_code"], "failed_witnesses": x["failed_witnesses"], "interpretation": x["interpretation"]} for x in result["mutations"]]
    put("FAILURE_LEDGER_v1.json", {"created_utc": now, "mathematical_baseline_failures": 0, "unexpected_wrapper_failures": [{"record": ref("runs/LAUNCH_v1.json"), "stderr": ref("runs/launch_v1.stderr.txt"), "failure": "Fourth mutation prefix matched two return lines; unique-match guard stopped before a fourth changed copy.", "repair": ref("WRAPPER_REPAIR_v2.json"), "baseline_and_first_three_runs_preserved": True, "baseline_rerun": False}], "actual_expected_changed_copy_failures": failed_rows, "all_eight_distinct_implementations_rejected": True, "coarse_weakening_interpretation": "Dropping the correlated hot factor returns a valid coarse bound but fails the exact new joint identity and improvement, not the validity of the older coarse theorem."})
    put("COMMAND_INDEX_v1.json", {"created_utc": now, "mathematical_child_executions": 9, "science_commands": commands, "metadata_command": ref("runs/evidence_v1/COMMAND_v1.json"), "wrapper_launches": [ref("runs/LAUNCH_v1.json"), ref("runs/LAUNCH_v2.json")], "ordering": "One baseline plus first three changed copies; wrapper guard failure; exact-line repair and five remaining copies; metadata verification. No second baseline.", "bootstrap": "Source snapshots and handwritten proof were prepared by direct local tools before mathematical execution. Every executed checker has exact argv/cwd, source/output hashes and exit record."})
    dispositions = []
    for i, x in enumerate(sources["sources"]):
        dispositions.append({"original_path": x["original_path"], "original_sha256": x["sha256"], "disposition": "new_hand_derivation_checked_unchanged" if i == 0 else "author_protocol_frozen" if i == 1 else "reused_finite_mass_bounds_by_seal_identity" if i == 2 else "reused_independent_seal_bytes_verified", "recovery": x["snapshot_path"], "final_path": x["original_path"], "final_sha256": x["sha256"]})
    put("SOURCE_DISPOSITIONS_v1.json", {"created_utc": now, "original_dispositions": dispositions, "author_source_mutation": False})
    put("FINAL_SOURCE_IDENTITY_v1.json", {"created_utc": now, "source": sources["sources"][0], "author_protocol": sources["sources"][1], "source_correction_required": False, "all_six_source_pairs_match_at_seal": True, "underlying_finite_mass_source": sources["sources"][2], "reused_finite_mass_receipt_sha256": reuse["receipt_sha256"]})
    put("SEAL_VALIDATION_v1.json", {"created_utc": now, "argv": [sys.executable, "-B", *sys.argv], "script_sha256": sha(Path(__file__).resolve()), "identity_only_no_mathematics_execution": True, "source_pairs_verified": len(sources["sources"]), "prior_artifacts_verified": 92, "prior_exact_file_inventory": 94, "prior_source_pairs_verified": 5, "mathematics_child_records_verified": 9, "metadata_checks": {"passed": 25, "failed": 0}, "wrapper_failure_preserved": True, "source_unchanged": True})
    artifacts = []
    for p in sorted(ROOT.rglob("*")):
        assert not p.is_symlink(), p
        if p.is_file():
            artifacts.append(ref(str(p.relative_to(ROOT))))
    put("MANIFEST_v1.json", {"schema": "independent-evidence-manifest-v1", "created_utc": now, "artifact_root": str(ROOT), "artifact_count": len(artifacts), "excludes": ["MANIFEST_v1.json", "RECEIPT_v1.json"], "artifacts": artifacts})
    receipt = {"schema": "independent-focused-check-receipt-v1", "created_utc": now, "unit": "joint_entropy_bounce_v1", "scientific_author": "/root", "independent_checker": "/root/scalar_energy_check", "formal_audit": False, "formal_grade_assigned": False, "landing_authority": False, "final_source": sources["sources"][0]["original_path"], "final_source_sha256": sources["sources"][0]["sha256"], "source_bindings": sources["sources"], "source_pair_count": len(sources["sources"]), "source_correction_required": False, "source_unchanged": True, "manifest": ref("MANIFEST_v1.json"), "artifact_count": len(artifacts), "report": ref("REPORT_v1.md"), "hand_derivation": ref("HAND_DERIVATION_v1.md"), "control_protocol": ref("CONTROL_PROTOCOL_v1.json"), "findings": ref("FINDINGS_v1.json"), "failure_ledger": ref("FAILURE_LEDGER_v1.json"), "commands": ref("COMMAND_INDEX_v1.json"), "source_dispositions": ref("SOURCE_DISPOSITIONS_v1.json"), "original_dispositions": dispositions, "access_and_scope": ref("ACCESS_AND_SCOPE_v1.json"), "final_source_identity": ref("FINAL_SOURCE_IDENTITY_v1.json"), "seal_validation": ref("SEAL_VALIDATION_v1.json"), "baseline": {"passed": 64, "failed": 0, "exit_code": 0, "command": ref("runs/baseline_v1/COMMAND_v1.json"), "only_baseline_execution": True}, "actual_damaged_implementations": 8, "all_eight_expected_witnesses_detected": True, "mutation_execution_summary": ref("EXECUTION_RESULTS_v2.json"), "mutations": failed_rows, "metadata": {"passed": 25, "failed": 0, "science_rerun": False, "command": ref("runs/evidence_v1/COMMAND_v1.json")}, "execution_failure": {"wrapper_guard_failure_preserved": True, "failure_count": 1, "launch": ref("runs/LAUNCH_v1.json"), "repair": ref("WRAPPER_REPAIR_v2.json"), "remaining_only_launch": ref("runs/LAUNCH_v2.json"), "math_source_changed": False, "baseline_rerun": False, "first_three_controls_rerun": False}, "reused_finite_mass_seal": {"receipt_sha256": reuse["receipt_sha256"], "report_sha256": reuse["report_sha256"], "manifest_sha256": reuse["manifest_sha256"], "artifacts_verified": 92, "files_verified": 94, "source_pairs_verified": 5, "mathematics_rerun": False, "reused_bounds": reuse["reused_bounds"], "historical_failure_lineage_preserved": True}, "checked_scope": ["Fermi occupation entropy, hot/cold bounds and pressure IBP correspondence", "Gibbs pressure/entropy correlation and strict joint product cap", "improved bare and same-background calibrated coefficients", "strict radius/entropy and distinct-background threshold algebra", "general-bath conditional thresholds and statistical/domain limits"], "limits": ["Adopted ideal bath, particle content, common temperature, zero chemical potential and fixed physical masses", "Same total bath in bounce/charge/final diagnostic", "Reused strict Einstein bounce and regular endpoint, N>=0 for unit corollary", "Calibrated response and eta remain adopted applicability inputs", "No complete thermal/gravity history, body solution, empirical calibration or selected state", "General-bath extension conditional on analogous entropy and G bounds", "No new finite-mass quadrature or old scientific checker execution"]}
    put("RECEIPT_v1.json", receipt)
    print(json.dumps({"artifact_count": len(artifacts), "exact_files": len(artifacts) + 2, "source_pairs": len(sources["sources"]), "report": ref("REPORT_v1.md"), "manifest": ref("MANIFEST_v1.json"), "receipt": ref("RECEIPT_v1.json")}, indent=2))


if __name__ == "__main__":
    main()
