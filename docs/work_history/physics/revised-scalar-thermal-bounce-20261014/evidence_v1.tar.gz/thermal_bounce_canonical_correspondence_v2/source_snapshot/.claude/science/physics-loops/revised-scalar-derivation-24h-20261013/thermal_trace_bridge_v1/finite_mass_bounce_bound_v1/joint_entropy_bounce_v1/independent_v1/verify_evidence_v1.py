#!/usr/bin/env python3
"""Source/output identity verification only; no science rerun or old code import."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parent
checks = []


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def add(name, value, detail=None):
    checks.append({"name": name, "passed": bool(value), "detail": detail})


def main():
    manifest = json.loads((ROOT / "SOURCE_MANIFEST_v1.json").read_text())
    worktree = Path(manifest["worktree"])
    for x in manifest["sources"]:
        a, b = worktree / x["original_path"], ROOT / x["snapshot_path"]
        add("source_pair." + x["snapshot_path"], a.stat().st_size == b.stat().st_size == x["bytes"] and sha(a) == sha(b) == x["sha256"])
    author_protocol = json.loads((ROOT / "sources/02_AUTHOR_PROTOCOL_v1.json").read_text())
    add("source.author_protocol_matches_derivation", author_protocol["source_sha256"] == sha(ROOT / "sources/01_JOINT_DERIVATION_v1.md"))
    reuse = json.loads((ROOT / "REUSED_FINITE_MASS_SEAL_v1.json").read_text())
    old = Path(reuse["root"])
    oldm = json.loads((ROOT / "sources/06_FINITE_MASS_MANIFEST_v1.json").read_text())
    oldr = json.loads((ROOT / "sources/04_FINITE_MASS_RECEIPT_v1.json").read_text())
    add("reuse.all_92_artifact_hashes_sizes", len(oldm["artifacts"]) == 92 and all((old / x["path"]).stat().st_size == x["bytes"] and sha(old / x["path"]) == x["sha256"] for x in oldm["artifacts"]))
    actual = {str(p.relative_to(old)) for p in old.rglob("*") if p.is_file()}
    expected = {x["path"] for x in oldm["artifacts"]} | set(oldm["excluded_seal_files"])
    add("reuse.exact_94_file_inventory", actual == expected and len(actual) == 94)
    add("reuse.five_live_source_pairs", len(oldr["source_pairs"]) == 5 and all((worktree / x["original_path"]).stat().st_size == (old / x["snapshot_path"]).stat().st_size == x["bytes"] and sha(worktree / x["original_path"]) == sha(old / x["snapshot_path"]) == x["sha256"] for x in oldr["source_pairs"]))
    add("reuse.receipt_manifest_report", sha(old / "RECEIPT_v1.json") == reuse["receipt_sha256"] and sha(old / "REPORT_v1.md") == reuse["report_sha256"] and sha(old / "MANIFEST_v1.json") == reuse["manifest_sha256"])

    baseline = json.loads((ROOT / "runs/baseline_v1/COMMAND_v1.json").read_text())
    source = ROOT / "check_joint_v1.py"
    control_protocol = json.loads((ROOT / "CONTROL_PROTOCOL_v1.json").read_text())
    add("baseline.source_hand_protocol_hashes", sha(source) == baseline["script_sha256"] and sha(ROOT / "HAND_DERIVATION_v1.md") == baseline["hand_derivation_sha256"] == control_protocol["hand_derivation_sha256"] and sha(ROOT / "CONTROL_PROTOCOL_v1.json") == baseline["control_protocol_sha256"])
    add("baseline.outputs_and_64_0", sha(ROOT / "runs/baseline_v1/stdout.json") == baseline["stdout_sha256"] and sha(ROOT / "runs/baseline_v1/stderr.txt") == baseline["stderr_sha256"] and baseline["exit_code"] == 0 and baseline["pass_count"] == 64 and baseline["fail_count"] == 0)
    result = json.loads((ROOT / "EXECUTION_RESULTS_v2.json").read_text())
    p1 = json.loads((ROOT / "mutations/PROTOCOL_v1.json").read_text())
    p2 = json.loads((ROOT / "mutations/PROTOCOL_v2.json").read_text())
    effective_cases = p1["cases"][:3] + p2["remaining_cases"]
    effective = {x["name"]: x for x in effective_cases}
    original = source.read_text()
    add("damage.inventory_exact_eight", len(effective) == len(result["mutations"]) == 8 and set(effective) == {x["mutation"] for x in result["mutations"]})
    for row in result["mutations"]:
        folder = ROOT / "mutations" / row["mutation"]
        script = folder / "damaged_check_v1.py"
        case = effective[row["mutation"]]
        command = json.loads((folder / "run_v1/COMMAND_v1.json").read_text())
        output = json.loads((folder / "run_v1/stdout.json").read_text())
        names = [x["name"] for x in output["checks"] if not x["passed"]]
        good = original.count(case["old"]) == 1 and script.read_text() == original.replace(case["old"], case["new"]) and sha(script) == command["script_sha256"] and sha(folder / "run_v1/stdout.json") == command["stdout_sha256"] and sha(folder / "run_v1/stderr.txt") == command["stderr_sha256"] and command["exit_code"] == 1 and case["expected_witness"] in names and names == command["failed_witnesses"] and output["fail_count"] == len(names)
        add("damage.actual_source_output_binding." + row["mutation"], good, {"failed_witnesses": names})
    launch1 = json.loads((ROOT / "runs/LAUNCH_v1.json").read_text())
    launch2 = json.loads((ROOT / "runs/LAUNCH_v2.json").read_text())
    add("wrapper.original_failure_preserved", launch1["exit_code"] == 1 and sha(ROOT / "runs/launch_v1.stderr.txt") == launch1["stderr_sha256"] and "AssertionError" in (ROOT / "runs/launch_v1.stderr.txt").read_text())
    add("wrapper.repair_remaining_only", launch2["exit_code"] == 0 and sha(ROOT / "runs/launch_v2.stdout.txt") == launch2["stdout_sha256"] and p2["prior_three_actual_runs_reused_unchanged"] == [x["name"] for x in p1["cases"][:3]])
    add("wrapper.guard_was_ambiguous_prefix_only", original.count(p1["cases"][3]["old"]) == 2 and original.count(p2["remaining_cases"][0]["old"]) == 1)
    output = {"scope": "Metadata, source, prior-seal and actual-output identity only; no mathematical rerun", "pass_count": sum(x["passed"] for x in checks), "fail_count": sum(not x["passed"] for x in checks), "checks": checks, "source_pairs": len(manifest["sources"]), "reused_artifacts": 92, "reused_files": 94, "reused_source_pairs": 5}
    print(json.dumps(output, indent=2))
    return int(output["fail_count"] != 0)


if __name__ == "__main__":
    sys.exit(main())
