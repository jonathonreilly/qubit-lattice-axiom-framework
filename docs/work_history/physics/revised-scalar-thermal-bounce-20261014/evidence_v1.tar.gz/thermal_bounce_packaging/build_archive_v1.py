from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,gzip,io,datetime
wt=Path.cwd();pk=wt/'.claude/science/physics-loops/revised-scalar-derivation-24h-20261013';pack=pk/'thermal_bounce_packaging';dest=wt/'docs/work_history/physics/revised-scalar-thermal-bounce-20261014'
tt='thermal_trace_bridge_v1';fm=tt+'/finite_mass_bounce_bound_v1';joint=fm+'/joint_entropy_bounce_v1'
roots=[tt,'thermal_bounce_canonical_correspondence_v1','thermal_bounce_canonical_correspondence_v2','thermal_bounce_packaging']
seal_units=[tt+'/independent_v1',fm+'/independent_v1',fm+'/calibration_independent_v1',joint+'/independent_v1','thermal_bounce_canonical_correspondence_v1','thermal_bounce_canonical_correspondence_v2']
for rel in seal_units:
 for name in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json']:assert (pk/rel/name).is_file(),(rel,name)
assert not dest.exists();dest.mkdir(parents=True)
items=[]
for root in roots:
 for f in sorted((pk/root).rglob('*')):
  if f.is_dir():continue
  assert f.is_file() and not f.is_symlink(),f
  if '__pycache__' in f.parts or f.suffix=='.pyc' or f.name=='ARCHIVE_BUILD_v1.json':continue
  items.append((f.relative_to(pk).as_posix(),f.read_bytes()))
assert len(set(n for n,b in items))==len(items)
rows=[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in items]
manifest={'schema':'campaign-recovery-manifest-v1','source_roots':roots,'artifact_count':len(rows),'payloads':rows,'scope':'Four-part thermal conservation, finite-mass entropy, measured calibration and correlated bounce theorem; full sources/runs/failures and independent checks. No physical-clock or finite-body follow-on route.','exclusions':['Python bytecode/cache and later archive-own-hash build record.'],'counts_are_not_new_science':True};mb=(json.dumps(manifest,indent=2)+'\n').encode();archive=dest/'evidence_v1.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as z:
  with tarfile.open(fileobj=z,mode='w') as tar:
   for n,b in items+[('RECOVERY_MANIFEST_v1.json',mb)]:
    assert not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts
    t=tarfile.TarInfo(n);t.size=len(b);t.mode=0o644;t.mtime=0;tar.addfile(t,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(rows)+1
 for row in rows:
  t=tar.getmember(row['path']);assert t.isfile();b=tar.extractfile(t).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
sha=hashlib.sha256(archive.read_bytes()).hexdigest();msha=hashlib.sha256(mb).hexdigest();record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':str(archive.relative_to(wt)),'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'payloads':len(rows),'total_members':len(members),'manifest_sha256':msha,'all_payloads_verified':True};(pack/'ARCHIVE_BUILD_v1.json').write_text(json.dumps(record,indent=2)+'\n')
refs=[]
for rel in seal_units:
 for name in ['REPORT_v1.md','MANIFEST_v1.json','RECEIPT_v1.json']:
  refs.append(rel+'/'+name+' SHA256 '+hashlib.sha256((pk/rel/name).read_bytes()).hexdigest())
readme="""Recovery evidence for the revised scalar thermal-bounce milestone

Live claim: docs/EXPONENTIAL_SCALAR_THERMAL_BOUNCE_BOUNDED_THEOREM_NOTE_2026-10-14.md
Scientific author: /root. Conditional support; no formal audit or main merge.

Archive SHA256: {sha}
Archive bytes: {size}
Payloads: {count} plus RECOVERY_MANIFEST_v1.json
Internal manifest SHA256: {msha}

Universal matter coupling fixes the trace/transfer balance but does not choose
an isolated photon fluid. For a specified ideal zero-chemical-potential photon
and electron/positron bath, equilibrium thermodynamics bounds the charge change
by R=(11/4)^(1/3). The joint Gibbs identity links the bounce pressure and entropy,
strengthening the necessary bare product to >2 exp(2N)/(R sigma^(4/3)). The
same-background weak-calibration ceiling gives >3 exp(2N)/(2R sigma^(4/3)(1+eta));
at N>=0,sigma=1,eta=0 the unit target is incompatible with these premises.
This does not construct a full history, environment, microscopic production
law, or observed abundance fit. A larger allowed entropy ratio is not a source.
Particle content/statistics, equilibrium, bounce energy conditions and response
regime remain inputs. Different local/cosmic backgrounds remain explicit.

The fresh canonical runner554/0 comprises27 trace,8 general trace,229 finite-mass,
14 coarse-calibration and276 joint-entropy controls. Its new joint function uses
the same newly computed61-node bath array and preserves all rows and tables.
These are mathematical/synthetic checks, not554 observed tests. The previous
three-part278/0 note/runner/cache are preserved byte-for-byte, with explicit
supersession to the four-part version; their mathematics remains valid but looser.
Independent reports distinguish their own exact proofs, actual damaged copies,
reused computations and metadata. No evidence count is promoted to another run.

The archive preserves every original source, producer and independent program,
result, actual altered implementation, command/stream, and scoped repair in the
included units. This includes the original63/2 trace-review float-input failure,
the four vacuous guards in the initial177/0 finite-mass checker, corrected180/0,
source domain qualifications, and the joint review's mutation-wrapper guard
failure after three damages, followed by only the five remaining executions.
The canonical v1 cache API succeeded before an outer PosixPath serialization
TypeError; recovered evidence is labeled as recovered, not an original object.
The separate general-trace NameError occurred before science execution.
Reviewer and parent lookup failures are likewise retained in their records.

The saved PDG primary source is exposed thermodynamic context, not a scalar
likelihood or proof of actual equilibrium. The thermal and joint PNG/PDF figures
use saved synthetic quadrature data and exact conditional coefficients; parent
visual QA is recorded separately from independent proof review.
Physical-clock/CMB normalization and finite-body calibration follow-ons are
outside this archive and are not certified by this milestone.

Extract only safe regular relative members to an empty destination, then verify
all manifest hashes/sizes. Each payload was verified at build time. The later
ARCHIVE_BUILD record is intentionally outside the archive whose hash it records.
A separate exact-commit delivery mapping will bind the five Git paths.

Independent source and canonical correspondence identities:
{refs}
""".format(sha=sha,size=archive.stat().st_size,count=len(rows),msha=msha,refs='\n'.join(refs))
(dest/'README.txt').write_text(readme);print(json.dumps(record))
