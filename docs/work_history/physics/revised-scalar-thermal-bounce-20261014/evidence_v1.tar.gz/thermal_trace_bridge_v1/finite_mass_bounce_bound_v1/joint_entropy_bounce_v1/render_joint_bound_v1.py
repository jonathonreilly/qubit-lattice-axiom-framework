from pathlib import Path
import json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent
j=json.loads((p/'RESULTS_v1.json').read_text());R=float(j['constants']['R'])
x=np.array([v['x'] for v in j['postprocessing']]);cap=1/np.array([v['minimum_bare_coefficient'] for v in j['postprocessing']])
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(1,2,figsize=(11.8,4.6),gridspec_kw={'width_ratios':[1.18,1]})
ax[0].semilogx(x,cap,color='#126b73',lw=2.3,label='Pressure and entropy linked')
ax[0].axhline(2*R/3,color='#af7a24',ls='--',lw=1.5,label='Separate loose bounds')
ax[0].axhline(R/2,color='#126b73',ls=':',lw=1.3,label='Uniform joint ceiling')
ax[0].axhline(1,color='#8b3244',lw=1.1,label='Bare unit target needs at least 1')
ax[0].set(xlabel=r'Bounce temperature parameter $m/T_b$',ylabel=r'Upper envelope of $f_b\,D_f/D_b$',ylim=(.44,1.07),title='The bounce pressure restricts the thermal gain')
ax[0].legend(loc='lower left',fontsize=9,frameon=False)
vals=[1.5/R,2/R,9/(8*R),3/(2*R)]
colors=['#d8b57b','#126b73','#d8b57b','#126b73']
bars=ax[1].bar(range(4),vals,color=colors,width=.65)
ax[1].axhline(1,color='#8b3244',lw=1.1)
for b,v in zip(bars,vals):ax[1].text(b.get_x()+b.get_width()/2,v+.025,f'{v:.4f}',ha='center',fontsize=10)
ax[1].set_xticks(range(4),['Bare\nloose','Bare\njoint','Calibrated\nloose','Calibrated\njoint'])
ax[1].set(ylim=(0,1.65),ylabel='Strict lower coefficient for the product',title='The matched-calibration bound stays above 1')
fig.suptitle('Thermal pressure and entropy must be used together',fontsize=15,y=1.01)
fig.text(.5,-.015,r'Ideal photon/pair bath; $N=0$, fixed entropy. Calibration panel uses the same-background weak cap with $\eta=0$.'+'\nConditional theorem and synthetic equilibrium checks; no fitted cosmological history or measured environment.',ha='center',fontsize=9)
fig.tight_layout();fig.savefig(p/'JOINT_THERMAL_BOUND_v1.png',dpi=180,bbox_inches='tight');fig.savefig(p/'JOINT_THERMAL_BOUND_v1.pdf',bbox_inches='tight')
provenance={'source_results_sha256':hashlib.sha256((p/'RESULTS_v1.json').read_bytes()).hexdigest(),'plot_code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'no_new_fit':True,'derived_values':vals,'inputs':'61 exposed finite-mass states postprocessed by checked joint identity; exact coefficients use R=(11/4)^(1/3)'}
(p/'FIGURE_PROVENANCE_v1.json').write_text(json.dumps(provenance,indent=2)+'\n')
