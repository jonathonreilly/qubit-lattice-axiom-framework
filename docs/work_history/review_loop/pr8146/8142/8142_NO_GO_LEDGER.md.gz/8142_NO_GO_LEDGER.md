# No-go ledger — admissibility-induced-law-20260906

Routes read at their proofs, not their headlines.

| Route | Where | What was actually shown | Escape / what this block does |
|---|---|---|---|
| "Record consistency forces the rule's form" (archived Opus packet R136) | `archive/campaigns/opus-direct-20260827/POSITIVE_PATH.md`, RESULT 136; floats | Under the static reading (rule = full conditional of one joint law): product form; the sum rule has no joint; the normalizer-constancy argument. | The static reading is a reading; the formation law is the other object. This block proves both exactly and their relation. |
| The consistency-first kernel K* and the frontier-process gate (bridge exercise 2026-08-26) | `archive/campaigns/exercise-bridge-adoption-20260826/SYNTHESIS.md` | On the gravity lane's Gaussian fixture, the sliding-frontier process marginals differ from the static Gram weights by an extent-stable gap. | Fixture-level, floats; this block states the axiom-level finite distinction; it does not explain the gate. |
| Convex-consistency (affine rule output) vs product form (R136/T212/T213) | same packet | Normalizer constant iff no coupling (rank argument; Funk–Hecke on the sphere). | Re-proved exactly on the menu as the two-neighbor normalizer factorization; used for T2(b). |
| Binary full-conditional compatibility (landed 2026-08-10) | `docs/ADMISSIBILITY_BINARY_FULL_CONDITIONAL_COMPATIBILITY_ISING_ACTION_AXIOM_BOUNDARY_BOUNDED_THEOREM_NOTE_2026-08-10.md` | Static half on binary menus; excludes formation dynamics by its own boundary. | Upstream; generalized here; the excluded object is this block's subject. |

## Block 08 (2026-09-15) — negatives at scope, with escapes

- **Translate inconsistency in 3D (planned theorem Q2).** Scope: the monotone box laws of the six-menu product rule at the declared nonconstant triples; the first plane cannot be summed out consistently (reduced to the `2×2` plane-transfer identity, refuted exactly). Escapes: the constant rule (identity holds); another identity than the 2D telescoping (none known; the successor/predecessor-triple lemma explains the mechanism's failure); a proof for every nonconstant triple is not given (executed witnesses only).
- **No long-range record correlation from the monotone formation law in the region `c < 1/3` (planned corollary Q5).** Scope: pair correlations of the box, column and half-space laws; exponential decay proved by coupling. Escapes named for the N-gate: `c ≥ 1/3` (strong coupling; the branching bound is not conclusive); non-product or constraint rules (zero-probability supports; the Gauss-law support-rule line of #8114); other order classes (the random-priority process — the owner's factorial bound, unlanded; the snake); the static law at a critical coupling (a supplied value); a continuum alphabet.

## Block 09 (2026-09-15) — negatives at scope
- **The Z^3 monotone law is not a static law** (R2): proved from L1–L2 in the region at triples with nonzero third difference; escapes: a longer-range "static" rule (not the declared rule); a nonconstant triple with vanishing third difference (none known); c ≥ 1/3 (not constructed).
- **No single covariant law in the monotone class** (R3c): the eight corner laws are distinct and permuted transitively; the covariant object is their mixture; escape: adopting the mixture or a covariant random order as the supplied formation law (owner decision).
- **The plane chain is not reversible** (R4): exact on the 2x2 column; on Z^3 through R3; escape: none within the class (the constant rule is the control).

## Block 10 (2026-09-15) — negative at scope
- **A formation law with a two-element recorded set is not a nearest-neighbor Markov field** (T4's converse), proved on every finite window at triples with nonzero mixed differences; escapes: a vanishing mixed difference at a nonconstant triple (none known); the constant rule; a non-product rule; a non-bipartite carrier (none on `Z^3`).

## Block 11 (2026-09-15) — the open lemma of blocks 09–10 settled
- **"The third difference of `log K_3` is nonzero at every nonconstant triple" is false**: it vanishes at exactly five nonconstant points (three on the collapse lines, one mirror pair off them) and nowhere else (proved by exact elimination). The pair terms survive there (X4), so the Markov-graph conclusions of blocks 09–10 hold everywhere nonconstant; the genuine three-body statements hold off the five points.
