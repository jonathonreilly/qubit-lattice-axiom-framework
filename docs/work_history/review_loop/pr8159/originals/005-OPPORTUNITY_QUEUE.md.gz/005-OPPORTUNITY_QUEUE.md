# Ranked opportunities

1. Fixed finite-clock full physical field scaling. Existing two-point bounds,
   full Haar field limit, and clock smoothing do not by themselves establish the
   all-order characteristic functional with simultaneous electric and magnetic defects.
   First inspect newly integrated sources and test distinct proof mechanisms.
2. Native formation/probability selection. Prior prepared full-domain projective
   corridor permits Born and non-Born laws. Seek an actual derived selector or
   matching-premise discriminator without adding axioms by inference.
3. Mobile matter and small-clock neutral dynamics. Prior pure-gauge external-charge
   energies are not mobile particle masses. Inspect exact existing matter channels
   and physical neutral spin-one obligations before proposing a construction.

Re-rank after each substantive gain or exhausted route. More coefficients or
relabelled corollaries do not constitute a new campaign milestone.


Block7 pivot: field Block6 closes exactly onto dual clock smoothing. The
remaining field problem is substantive and open, but another rewrite of
that loop would add little. Re-read the native full-carrier dictionary,
low-charge U1 dictionary, RK charge-stability and complete D2-connectivity
notes. Investigate actual unitary charge motion and a momentum-resolved
charged-sector source bound for that supplied Hamiltonian. These are
stronger dynamical questions than nonzero hopping support, while long-time
transport, photon background and native action selection remain separate.

Block9 priority: derive local-source response within the exact word carrier,
then compare the actual assumptions of newly landed charged/infrared sources.
An entire-sector spectral floor need not equal a measurable source threshold.

Block10 resolves the polarized local-source question on a symmetry line.
Further work there should target genuinely different physics (generic
momentum or different backgrounds), not merely rephrase its selection
rule. Newly landed native infrared/charged notes deserve comparison before
choosing the next target. The fixed-clock all-order field limit remains open.

Block16 closes the cyclic equilibrium bridge at fixed couplings. Next compare simultaneous weak coupling and regulator growth with the new exact-Gauss hard-cutoff oscillator result. Cyclic wrap may lead to a periodic, rather than Dirichlet, finite-payload scaling limit; derive before simulating.

Block17 next: determine whether a different nonnegative phase-kernel electric generator can improve the cyclic cosine error at fixed curvature. Use the full positive jump cone and explicit escape conditions, not a finite menu of stencils.

Block19 closes the explicit ring slow-gap obligation. Next prioritize volume dependence of global holonomy response or a genuinely interacting native obstruction; do not recount the ring as a bulk photon theorem. Reserve time for a full campaign claim/dependency review and durable PR packaging.

End-stage ranking: prioritize a uniform-in-volume local Ward/response estimate for the same coupled charged model, or a local joint active/spectator reduction for the native sixth-order problem. Blocks20–22 now provide the fixed-box and iterated local comparator, not the fixed-positive-coupling phase. A new exact ring coefficient or more finite-size spectra would add less. The original fixed-clock full field target remains open at physical graph summation/state matching; revisit only with a mechanism that retains the residual signed phases and branching. See README.md for the six review units.

Block24 sharpens the next charged-phase contract: exact Ward cancellation
for a flat EXTERNAL charge twist is available but cannot certify a photon.
Target inelastic transverse spectral weight or a resolvent lower estimate,
with the charged current and compact corrections retained. Block23 provides
an explicitly matched positive-weight free comparator without selecting it.
