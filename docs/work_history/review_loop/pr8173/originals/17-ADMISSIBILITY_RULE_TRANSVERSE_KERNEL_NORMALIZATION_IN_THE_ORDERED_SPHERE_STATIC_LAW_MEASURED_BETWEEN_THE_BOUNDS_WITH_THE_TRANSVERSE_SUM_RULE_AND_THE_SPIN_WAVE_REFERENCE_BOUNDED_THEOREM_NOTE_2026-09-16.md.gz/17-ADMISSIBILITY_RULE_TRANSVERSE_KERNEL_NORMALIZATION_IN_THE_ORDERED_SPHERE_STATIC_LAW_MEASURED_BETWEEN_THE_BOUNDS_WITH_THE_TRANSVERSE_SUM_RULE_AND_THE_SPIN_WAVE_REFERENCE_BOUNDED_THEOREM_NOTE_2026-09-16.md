---
claim_id: admissibility_rule_transverse_kernel_normalization_in_the_ordered_sphere_static_law_measured_between_the_bounds_with_the_transverse_sum_rule_and_the_spin_wave_reference_bounded_theorem_note_2026-09-16
claim_type: bounded_theorem
claim_scope: "For the static law of the covariant rule on the unsoldered sphere menu with weight e^{beta s.s'} on the periodic cubic lattice: (T1) the quadratic transverse model H = (beta/2) sum_bonds |theta_x - theta_y|^2 has k-mode variance exactly 1/(beta E(k)) per component for k != 0, E(k) = 2 sum_j (1 - cos k_j), so beta E(k) <|theta_hat(k)|^2> = 1 is the spin-wave value of the transverse kernel's normalization (proved; the plane-wave eigenvalues and the ring modes symbolic); (T2) for the sphere static law with a field h > 0 along e_3 on any finite torus, beta h N <(m_hat^1)^2> = <m_hat^3> exactly (integration by parts on the sphere), so the transverse response at k = 0 is <m_hat^3>/(beta h) (proved; the one-site instance and the generator's action symbolic); (T3) the mode sum: N^{-1} sum_k <|s_hat^perp(k)|^2> = <|s_x^perp|^2> per component (proved). Executed, not proved: the normalization c(beta, k) = beta E(k) S_perp(k) of the transverse structure factor in the ordered regime, measured on 16^3, 24^3, 32^3 at beta = 0.8, 1, 1.5, 2, 3 for k along an axis, lies at 0.86-0.98 for the modes n >= 2 (the longest mode n = 1 scattering more), rising toward the spin-wave value 1 as beta grows, against block 19's bounds (m^2/3)^2 (0.008-0.08) and 1: the infrared bound is the kernel up to about a tenth; the real-space transverse correlation tracks the torus Green function with the same constant (refuter). No menu, reading, order or coupling is selected as physical; exact arithmetic throughout the runner."
upstream_dependencies:
  - minimal_axioms
  - admissibility_rule_formation_law_versus_static_law_finite_window_classification_bounded_theorem_note_2026-09-06
runner: scripts/admissibility_rule_transverse_kernel_normalization_ordered_sphere_static_law_measured_between_bounds_sum_rule_spin_wave_reference_2026_09_16.py
---

# The transverse kernel's normalization in the ordered sphere static law: measured between the bounds, with the transverse sum rule and the spin-wave reference

**Date:** 2026-09-16
**Type:** bounded_theorem (T1–T3); frontier discovery for the measured normalization
**Status:** bounded-support (exact; conditional on the named supplied readings; the normalization measured on finite lattices, not proved; unaudited)

## Result up front

Blocks 19–23 placed the gravity node's Green-function kernel in the transverse
channel of the ordered sphere static law: for `β > 76/100` and every fixed
`k ≠ 0`, the transverse structure factor lies between `(M²/3)²/(βE(k))` and
`1/(βE(k))` (block 19's G5 with block 22's threshold) — a window of a factor
nine or more, since `M² ≤ 1`. The queue's item "the kernel's normalization on
`Z³`" is hard as a theorem and cheap to measure. This note measures it: the
number `c(β, k) = βE(k)·S_⊥(k)` on lattices of `16³`, `24³` and `32³` sites at
`β = 0.8, 1, 1.5, 2, 3`, for wavevectors along an axis, comes out between
`0.86` and `0.98` for every mode but the longest, rising toward `1` as `β`
grows; the lower bound `(m²/3)²` is `0.008`–`0.08` at the same couplings. So
the infrared bound is the kernel up to about a tenth, the lower bound is loose
by a factor ten to a hundred, and the spin-wave value `1` — which this note
proves exactly for the quadratic transverse model (T1) — is the large-`β`
limit. Two exact anchors: the transverse sum rule in a field (T2), which fixes
the kernel's `k = 0` response at `⟨m̂³⟩/(βh)` and makes the soft mode a
theorem on any finite torus, and the mode sum (T3), which ties the structure
factor's average to the local transverse moment.

In plain words: in the settled arrangement of sphere-valued records at strong
preference, the sideways wiggles of the records are carried across the lattice
by the same law as a Coulomb-type potential, and this note pins the strength of
that carrying: within ten percent of the largest value the general theorem
allows, and closer the stronger the preference. The gravity lane, should it
use this channel, has its number; whether it should is not decided here.

Exactly: the spin-wave reference (T1); the transverse sum rule (T2); the mode sum
(T3). Executed with exact arithmetic: 14 checks, 7 mutations; the measurement
in the control spec, a second estimator, a second chain and the sum rule in a
field in the refuting spec.

## Machine status and trace

```yaml
actual_current_surface_status: bounded-support
target_claim_type: bounded_theorem
trace_class: frontier_discovery
target_claim_id: null
target_blocker_text: "the campaign queue's item 'the kernel's normalization on Z^3' (blocks 19-23 placed the transverse channel's kernel between (M^2/3)^2/(beta E(k)) and 1/(beta E(k)))"
source_of_blocker_text: handoff
reachability_to_target: supports
artifact_role: theorem_plus_decisive_artifact
next_trace_action: "the normalization measured: c(beta, k) in 0.86-0.98 for k along an axis (modes n >= 2) at beta = 0.8-3, rising toward the spin-wave value 1; the infrared bound is the kernel up to a tenth. Open: a proof that c(beta, k) -> 1 as beta -> infinity at fixed k (spin-wave theory as a theorem); the longest mode's finite-size behaviour. Consumers: the gravity lane's kernel question (blocks 19-23); the campaign's decision record"
conditional_surface_status: "T1-T3 proved as stated under the records-only reading, positivity, the sphere menu and the static reading as supplied conditions; the normalization measured on periodic lattices (16^3, 24^3, 32^3), not proved; two standard mathematical imports named at definition level"
hypothetical_axiom_status: null
admitted_observation_status: null
audit_required_before_effective_retained: true
```

## Premises and declared objects

The axioms memo (`docs/MINIMAL_AXIOMS_2026-06-29.md`) is used through the sentences "There is one fixed nearest-neighbor admissibility rule, covariant under lattice translations and proper cubic rotations.", "For each site, the probability distribution over the possibilities is determined by, and varies with, the nearest-neighbor conditions.", "Records form.", and "Only records are readable.". Block 01 (`docs/ADMISSIBILITY_RULE_FORMATION_LAW_VERSUS_STATIC_LAW_FINITE_WINDOW_CLASSIFICATION_BOUNDED_THEOREM_NOTE_2026-09-06.md`, on `main`) supplies the rule's product form and its one-site conditional given a recorded set; the sphere menu and the static reading are declared below (blocks 18, 19, 21, 22, 28 — open PRs #8152, #8153, #8155, #8156, #8172 — are referenced as evidence addresses only). All proposed and unaudited.

Declared objects.
- **The sphere static law.** Values `s_x ∈ S²` on the periodic lattice `T_L = (Z/LZ)³`, `N = L³`; the law `μ_{L,β}(ds) ∝ Π_{⟨xy⟩} e^{β s_x·s_y} Π_x dσ(s_x)`; with a field `h ≥ 0` along `e_3`, the extra factor `Π_x e^{βh s_x^3}`. Its single-site conditional given the six neighbours is the exponential-overlap law with concentration `β|Σ_{y∼x} s_y + h e_3|`.
- **Fourier conventions.** `ŝ^a(k) = N^{−1/2} Σ_x e^{−ik·x} s_x^a`, `k ∈ (2π/L)Z³`; `E(k) = 2Σ_j (1 − cos k_j)`; the graph Laplacian `Δ` with `(Δf)_x = Σ_{y∼x}(f_x − f_y)`, whose plane-wave eigenvalues are `E(k)`.
- **The magnetization and the transverse components.** `m̂ = N^{−1}Σ_x s_x`; for a configuration with `m̂ ≠ 0`, `û = m̂/|m̂|` and `s_x^⊥ = s_x − (s_x·û)û` (two components); the **transverse structure factor** `S_⊥(k) = ⟨|ŝ^⊥(k)|²⟩/2` per component (the average over the two transverse components in the instantaneous frame); the **normalization** `c(β, k) = βE(k) S_⊥(k)`; the **real-space transverse correlation** `T(r) = ⟨s_0^⊥·s_{re_1}^⊥⟩/2`.
- **The quadratic transverse model.** `θ_x ∈ R²` on `T_L` with density `∝ e^{−(β/2)Σ_{⟨xy⟩}|θ_x − θ_y|²}` on the subspace of zero-sum fields (the `k = 0` mode is a free translation and is removed); `θ̂(k)` as above.
- **The torus Green function.** `G_L(r) = N^{−1}Σ_{k≠0} e^{ik·r}/E(k)`.
- **The rotation generator.** For a smooth function `F` on `(S²)^N` and a site `x`, `L_x F = d/da F(…, R_a s_x, …)|_{a=0}` with `R_a` the rotation by `a` about `e_2` in the `(1, 3)` plane; `L_x s_x^1 = s_x^3`, `L_x s_x^3 = −s_x^1`.

## Prior art and what is new

The infrared bound and the Bogoliubov-type lower bound for the transverse channel of the classical Heisenberg model are the Fröhlich–Simon–Spencer and Dyson–Lieb–Simon route, carried for this lane in block 19; the linear spin-wave theory of the ordered phase and the transverse sum rule (a Ward identity of the rotation symmetry) are textbook; Parseval is Parseval. None is used as authority: T1–T3 are proved here at scope, and the measurement uses the campaign's own sampler. What is new: (i) the measured normalization `c(β, k)` of the kernel that blocks 19–23 located, placed between the bounds — the infrared bound is the kernel up to a tenth, the lower bound loose by ten to a hundred; (ii) the spin-wave value proved as the exact normalization of the quadratic model (T1), which the measurement approaches from below; (iii) the sum rule in a field as the exact `k = 0` anchor of the kernel on every finite torus (T2).

## Exact target and obligation graph

| Obligation | Statement | Route | Runner family |
|---|---|---|---|
| T1 | `⟨|θ̂(k)|²⟩ = 1/(βE(k))`; `βE(k)⟨|θ̂(k)|²⟩ = 1` | plane waves diagonalize `Δ`; Gaussian modes | B |
| T2 | `βh·N⟨(m̂¹)²⟩ = ⟨m̂³⟩` | integration by parts on the sphere | C |
| T3 | `N^{−1}Σ_k⟨|ŝ^⊥(k)|²⟩ = ⟨|s^⊥|²⟩` | the mode-sum identity | D |
| executed | `c(β, k)` on three lattices at five couplings | simulation (control, refuter) | — (specs) |

## Theorem T1 — the spin-wave reference

**Statement.** For the quadratic transverse model on `T_L` and `k ≠ 0`, `⟨|θ̂(k)|²⟩ = 1/(βE(k))` per component; hence `βE(k)⟨|θ̂(k)|²⟩ = 1` for every `k ≠ 0`, and `⟨θ_0·θ_r⟩ = 2G_L(r)/β`.

**Proof.** `Σ_{⟨xy⟩}|θ_x − θ_y|² = Σ_x θ_x·(Δθ)_x` per component, and `Δ e^{ik·x} = E(k) e^{ik·x}` (B1, on the `4³` lattice symbolically; the identity `Σ_{y∼x}(e^{ik·x} − e^{ik·y}) = e^{ik·x}Σ_j(2 − e^{ik_j} − e^{−ik_j})` holds on every `L`). In the plane-wave basis the density factorizes into independent Gaussians with variances `1/(βE(k))` per component and mode (B2, the ring modes explicitly); the real-space correlation is the inverse transform. ∎

*Reading.* Linearizing the sphere law about its ordered direction gives this model with `θ` the transverse coordinates, so `c = 1` is the spin-wave prediction; the nonlinearity and the finite magnetization reduce it, by an amount the measurement fixes.

## Theorem T2 — the transverse sum rule in a field

**Statement.** For the sphere static law on any finite torus with field `h > 0` along `e_3`, `βh · N ⟨(m̂¹)²⟩ = ⟨m̂³⟩`. In particular the transverse response at `k = 0`, `N⟨(m̂¹)²⟩`, equals `⟨m̂³⟩/(βh)` and grows without bound as `h ↓ 0` whenever `⟨m̂³⟩` stays bounded away from zero.

**Proof.** For every `x`, the surface measure is invariant under `R_a`, so `∫ L_x F dσ(s_x) = 0` for smooth `F` (C2: the generator's action on `s^1, s^3` and the vanishing of `∫ L(s^1 s^3) dσ`). With the density `w = e^{βΣ_{⟨xy⟩} s_x·s_y + βhΣ_x s_x^3}`, `⟨L_x F⟩ = −⟨F · L_x log w⟩`. Take `F = Σ_y s_y^1` and sum over `x`: `Σ_x L_x F = Σ_x s_x^3 = N m̂³`, while `Σ_x L_x log w = Σ_x [β Σ_{y∼x} (s_x^3 s_y^1 − s_x^1 s_y^3) + βh (−s_x^1)]`; the bond terms cancel in pairs (each bond contributes `s_x^3 s_y^1 − s_x^1 s_y^3` from `x` and its negative from `y`), leaving `−βh Σ_x s_x^1 = −βh N m̂¹`. Hence `⟨N m̂³⟩ = βh ⟨N m̂¹ · N m̂¹⟩/N`, i.e. `βh N⟨(m̂¹)²⟩ = ⟨m̂³⟩`. The one-site instance is `κ E[(s^1)²] = E[s^3]` for the exponential law with concentration `κ = βh` (C1). ∎

*Reading.* At `k = 0` the transverse kernel's normalization is not measured but fixed: `⟨m̂³⟩/(βh)`, the magnetization over the field. This is the exact end of the kernel at long wavelength.

## Theorem T3 — the mode sum

**Statement.** `N^{−1}Σ_k ⟨|ŝ^⊥(k)|²⟩ = ⟨|s_x^⊥|²⟩` (per component, in the instantaneous frame), so `N^{−1}Σ_k S_⊥(k) = ⟨1 − (s_x·û)²⟩/2`.

**Proof.** the mode-sum identity of the discrete Fourier transform (the transform is unitary) on `T_L` (D1, on a ring with rational data), applied to each transverse component and averaged. ∎

*Reading.* With block 19's upper bound this is that block's sum rule; here it is the check that the measured structure factor integrates to the measured local transverse moment.

## Executed: the normalization measured (frontier discovery, not proved)

Control `specs/supervisor_control_block29_kernel.py` (heat-bath checkerboard sweeps with the exact conditional from an aligned start; every second sweep after thermalisation: `m̂`, the transverse components in the instantaneous frame, the structure factor by FFT for `k = (2πn/L, 0, 0)`, and `T(r)` along an axis); refuting spec `specs/supervisor_control_block29_refuter.py` (the normalization from the real-space correlation against the torus Green function computed by FFT; a single-site proposal chain; the sum rule in a field). Outputs in `.out.txt`.

| `L` | `β` | `m` | `(m²/3)²` | `c(β, k)` for `n = 1 … 8` (`k = 2πn/L`) |
|---|---|---|---|---|
| `16` | `0.8` | `0.537` | `0.009` | `0.77 0.92 0.92 0.92 0.91 0.95 0.90 0.89` |
| `16` | `1.0` | `0.688` | `0.025` | `0.86 0.87 0.93 0.91 0.92 0.92 0.89 0.95` |
| `16` | `1.5` | `0.817` | `0.049` | `0.93 0.96 0.93 0.99 0.94 0.96 0.92 1.01` |
| `16` | `2.0` | `0.868` | `0.063` | `0.95 0.96 0.97 0.96 0.91 0.97 0.93 0.98` |
| `16` | `3.0` | `0.915` | `0.078` | `0.96 0.95 0.94 0.99 0.98 1.00 0.99 0.98` |
| `24` | `0.8` | `0.525` | `0.008` | `0.92 0.86 0.91 0.91 0.90 0.90 0.90 0.93` |
| `24` | `1.0` | `0.681` | `0.024` | `0.98 0.86 0.89 0.91 0.89 0.88 0.90 0.94` |
| `24` | `1.5` | `0.813` | `0.049` | `1.05 0.90 0.92 0.91 0.95 0.94 0.92 0.96` |
| `24` | `2.0` | `0.866` | `0.062` | `0.97 0.94 0.92 1.01 0.98 0.98 0.94 0.92` |
| `32` | `1.0` | `0.678` | `0.024` | `0.65 0.88 0.97 0.93 0.96 0.90 0.91 0.94` |
| `32` | `1.5` | `0.811` | `0.048` | `0.92 0.97 0.88 0.88 0.96 0.93 0.93 0.98` |

Refuting spec on `16³`: from the real-space correlation against the torus Green function, `c = T(r)·β/G_L(r)` for `r = 1 … 4` is `0.91, 0.91, 0.91, 0.94` at `β = 1`, `0.96, 0.96, 0.97, 1.00` at `1.5`, `0.96, 0.95, 0.94, 0.91` at `2`; a single-site proposal chain at `β = 1.5` gives `c = 0.80, 1.08, 0.94, 0.94, 1.01, 0.99` for `n = 1 … 6`; the sum rule in a field at `β = 1.5` gives `βh·N⟨(m̂¹)²⟩ = 1.01, 0.71, 0.96` against `⟨m̂³⟩ = 0.82, 0.83, 0.84` at `h = 0.05, 0.1, 0.2` — the `k = 0` transverse mode is the slowest and its `2000`-sweep average carries a scatter of about `±20 %` around the exact value.

What the runs say. (i) For the modes `n ≥ 2` the normalization lies between `0.86` and `1.01` at every lattice size and coupling, with no trend in `k`; the averages over `n = 2 … 8` are about `0.91` at `β = 0.8`–`1`, `0.94` at `1.5`–`2` and `0.97` at `3`: the kernel is the infrared bound up to about a tenth and approaches the spin-wave value from below as `β` grows. (ii) The longest mode `n = 1` scatters more (`0.65`–`1.05`): it is the slowest mode of the chain and the one most exposed to the finite lattice; its scatter grows with `L` at fixed sweeps. (iii) The lower bound `(m²/3)²` is a factor `12` (at `β = 3`) to `110` (at `β = 0.8`) below the measured values. (iv) The real-space transverse correlation gives the same constant (`0.91` at `β = 1`, `0.96`–`1.00` at `1.5`, `0.91`–`0.96` at `2`), a second chain agrees, and the sum rule in a field is met to within the large scatter of the slowest mode (refuter). **The measured normalization (executed):** `c(β) ≈ 0.9` at `β ∈ [0.8, 1]`, `≈ 0.94` at `β ∈ [1.5, 2]`, `≈ 0.97` at `β = 3`, against the bounds `(m²/3)²` and `1` and the spin-wave value `1`.

## No-Go Discipline Gate

The executed sentence measures a constant; its escapes are named.

### N1 — Routes by which the measurement could mislead
1. *The instantaneous frame.* The transverse components are taken orthogonal to the sample's own magnetization; on a finite lattice the direction wanders slowly, and the frame follows it; the structure factor at `k ≠ 0` is insensitive to a rigid rotation.
2. *The longest mode.* Its statistics are the poorest (autocorrelation, finite size); the summary uses the modes `n ≥ 2` and states the `n = 1` scatter.
3. *Equilibration and the aligned start.* Thermalisation of a third of the sweeps; the refuter's single-site chain and the field runs agree.
4. *The bounds' hypotheses.* Block 19's bounds are infinite-volume statements at fixed `k` (`L → ∞`); the measurement is at `L = 16, 24, 32`, whose modes `n ≥ 2` show no size dependence beyond the scatter.

### N2 — Wall-independence audit
No no-go wall of the repository is used.

### N3 — Hidden-wall scan
No hidden dependence: the inputs are the axioms' sentences, block 01's rule, the sphere menu and the static reading as declared.

### N4 — Per-citation table
| Citation | Role | Load-bearing? |
|---|---|---|
| `minimal_axioms` | the four sentences under Premises | yes (premise) |
| block 01 (`main`) | the rule and its one-site conditional | yes (premise, proposed) |
| blocks 19, 22 (open PRs) | the bounds and the threshold the measurement is placed against | placement only (evidence addresses; re-quoted) |
| blocks 18, 21, 28 (open PRs) | the menu; the uniqueness region; the located strength | placement only |

### N5 — Resolution audit
| Claim | per_element | per_site | per_mode | per_block | lattice_wide |
|---|---|---|---|---|---|
| "the transverse kernel's normalization is about nine tenths of the infrared bound" | executed: the plane-wave eigenvalues; the one-site sum rule; the generator's action | executed: the ring modes' variances; the vanishing surface integral | executed: the mode sum; `c(β, k)` for eight modes on three lattices (control), a second estimator and chain (refuter) | executed: the placement between `(m²/3)²` and `1` at five couplings; the sum rule in a field | T1–T3 proved as stated; the normalization measured, not proved |

### N6 — Partial-closure paths and primitive scan
The registered primitives supply no coupling or menu; none is a wall.

### N7 — Steelman
Hostile reviewer: "Spin-wave theory says `c ≈ 1` and the simulation says `c ≈ 0.9`; nothing here is a theorem about the sphere law's kernel." Reply: the number is what the lane's consumers need and it was unknown to within a factor nine; the exact parts are the two anchors (the spin-wave value and the `k = 0` sum rule) between which the measurement sits; the statement is labelled measured. Conceded: `c(β) → 1` as `β → ∞` is not proved; the longest mode is not resolved.

### N8 — Cross-cycle echo
Block 19's G2 (the infrared bound) and G4 (the lower bound) are the two sides of the window; block 22's `76/100` and block 28's located strength `β ∈ (0.66, 0.72)` place the couplings used inside the ordered regime; block 13's contrast (the formation reading's kernel is a heat kernel, not a Green function) is the other half of the gravity lane's question.

## Falsifiers
- A plane wave that is not an eigenvector of `Δ` with eigenvalue `2Σ(1 − cos k_j)`, or a ring mode with variance other than `1/(βE(k))` (B1–B2).
- `κ E[(s^1)²] ≠ E[s^3]` on one site, a generator sending `s^1, s^3` elsewhere than `s^3, −s^1`, or a non-vanishing surface integral of `L(s^1 s^3)` (C1–C2).
- A mode-sum failure on rational data (D1).
- For the measurement: a normalization outside `[(m²/3)², 1]` beyond its scatter, a sum-rule violation in a field beyond the statistical error, or a real-space constant differing from the structure-factor constant.

## Boundaries and non-claims
This note proves the spin-wave reference `βE(k)⟨|θ̂(k)|²⟩ = 1` for the quadratic transverse model, the transverse sum rule `βh·N⟨(m̂¹)²⟩ = ⟨m̂³⟩` for the sphere static law in a field on any finite torus, and the mode sum's identity for the transverse structure factor; the normalization `c(β, k) = βE(k)S_⊥(k)` of the transverse kernel in the ordered sphere static law is measured by simulation on finite lattices and placed between block 19's bounds, not proved; it does not select a menu, reading, order or coupling as physical, and adopts no clause. No bridge, Born-weight, plane-or-sum or gravity statement enters this note as a premise; this note does not fire wake condition 1 of the parked statistical-bridge decision. No value, constant or theorem is imported as authority; the standard mathematical imports are named at definition level.

Further: whether the transverse channel is what the gravity lane should use is not claimed; the large-`β` limit `c → 1` is not proved; the longest mode's finite-size behaviour is not resolved.

## Imports
- `minimal_axioms`: the sentences quoted under Premises.
- Block 01 (on `main`): the rule and its conditional; proposed, unaudited. PRs #8152, #8153, #8155, #8156, #8172 (open) referenced as evidence addresses for the menu, the bounds, the uniqueness region, the threshold and the located strength.
- Re-proved at scope: the Gaussian mode variances of the quadratic model; the integration by parts on the sphere and the cancellation of the bond terms; Parseval on the torus.
- Named standard imports at definition level (never as authority for physics): the discrete Fourier transform on the torus; the heat-bath (Gibbs sampler) and single-site-proposal (Metropolis) chains as samplers of the law on finite lattices.
- Reference only (named, not used): the infrared bound (Fröhlich–Simon–Spencer) and the Bogoliubov-type lower bound (Dyson–Lieb–Simon) as carried in block 19; linear spin-wave theory; the Ward identity of rotation symmetry.

## Review record
Supervisor-run block (owner directive 2026-09-16: keep the campaign running twelve more hours). After block 28 the remaining queue items were hard as theorems; the kernel's normalization was the one with a cheap decisive measurement and two exact anchors. The control ran the sampler on `16³` (`3000` sweeps), `24³` (`3000`) and `32³` (`2400`) at five couplings, measuring the structure factor by FFT in the instantaneous transverse frame; the exact control verified the plane-wave eigenvalues, the one-site sum rule and Parseval. The lens pass is in `GOAL_block29.md`. Facts settled while executing: the normalization is within a tenth of the infrared bound already at `β = 0.8`, just above the located strength, so the lower bound of block 19 is the loose side of the window; the longest mode is the only one with visible finite-size scatter. The refuting pass (`CHECKER_block29_findings.md`) extracted the constant from the real-space correlation against the torus Green function, ran a single-site proposal chain, and tested the sum rule in a field.

## Verification

```bash
python3 scripts/admissibility_rule_transverse_kernel_normalization_ordered_sphere_static_law_measured_between_bounds_sum_rule_spin_wave_reference_2026_09_16.py
python3 scripts/admissibility_rule_transverse_kernel_normalization_ordered_sphere_static_law_measured_between_bounds_sum_rule_spin_wave_reference_2026_09_16.py --list-mutations
python3 scripts/admissibility_rule_transverse_kernel_normalization_ordered_sphere_static_law_measured_between_bounds_sum_rule_spin_wave_reference_2026_09_16.py --mutation sum_rule_wrong
```

Families: A authority and inputs; B the spin-wave reference; C the sum rule; D the mode sum; F fences, forbidden phrases, the floating-point self-scan, the placement of the classical names; G the resolution lines. Each of the 7 declared mutations fails in exactly one family. Expected final line: `TOTAL: PASS=14 FAIL=0`.
