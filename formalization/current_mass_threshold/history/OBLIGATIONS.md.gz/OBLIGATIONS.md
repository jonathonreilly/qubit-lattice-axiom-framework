# Scoped Lean obligation for the current-mass threshold

Parent: CURRENT_MASS_FILTER_PROBE.md, SHA-256
9ce18a3ae1d424193b2d7c04fd63cb7e2b10987bb0f8e462f8ac409a2c674603.
The intended formal statements are the finite reverse-Minkowski polynomial
identity, its ordered positive-energy consequence, and the finite-sum bound
M7. Put u_i=v p_i. Under e_i>=0 and e_i²-u_i²>=m², prove
(sum e_i)²-(sum u_i)²>=(cardinality*m)² for every finite family.
The proof must derive the pairwise lower bound and sum all cross terms;
it must not assume that lower bound as a substitute for the hypotheses.

Also prove exact rational counterexamples to dropping the energy-sign
hypothesis and to replacing the total mass square by a sum of one-particle
mass squares. Compile explicit false arithmetic statements under real
counterexample premises and preserve their kernel rejection. Print the axioms
of every successful declaration; permit ordinary mathlib classical axioms,
never sorryAx or an added physics axiom. Preserve every failed compiler attempt.

Use the already-installed pinned Lean4.35.0-rc4/mathlib939d5d5d runtime.
Rehash its binaries and manifest/toolchain before use; keep this work's sources,
outputs and temporary files in this directory. Each compiler call has a real
120-second timeout and complete separate stdout/stderr plus source snapshot.
No library update or network download is intended.

Root authors the formalization. Kernel checking is a scoped mechanical check,
not independent reconstruction of the surrounding physics. This does not
formalize trigonometric dispersion, the spectral theorem, infinite Fock sums,
maximal domains, threshold null sets, sharp/smooth filter limits or almost
locality. Those remain the parent proof and its fresh analytic review.
