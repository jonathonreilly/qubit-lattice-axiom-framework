# Runtime refinement after two preserved timeout controls

The first separate controls were launched concurrently and both reached their
actual 120-second compiler limits without any diagnostic output. They are
inconclusive timeouts, not logical rejections. Process inventory afterward
showed no remaining processes for this directory. Their sources, raw streams,
inner and outer receipts remain untouched.

The successful main proof had taken about 113 seconds including library load.
Run both unchanged false implication statements in one new file sequentially,
with an explicit real-number import and a 240-second compiler limit (300-second
outer bound). Only the execution allowance/import context changes; the false
propositions and norm_num proof attempts are byte-identical. This is an
execution refinement, not a weakened mathematical gate. Require both diagnostics
to report an unsolved False goal, and nonzero exit without timeout. A timeout
again would remain inconclusive, never an accepted control. No recompile of the
successful theorem is needed.
