from pathlib import Path
import os,sys,subprocess,time,json,hashlib,datetime

D=Path(__file__).resolve().parent
S=D.parent
OLD=S/'lean_audit'
runtime=OLD/'lean-4.35.0-rc4-darwin_aarch64'
identity=json.loads((S/'interspecies_rigidity_lean/runtime_identity.json').read_text())
for row in identity['records'].values():
    assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=OLD/'mathlib',timeout=30).decode().strip()==identity['mathlib_commit']
assert subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=OLD/'mathlib',timeout=30)==b''
source=(D/sys.argv[1]).resolve();label=sys.argv[2]
assert source.is_relative_to(D) and '/' not in label
logs=D/'logs';logs.mkdir(exist_ok=True);r=logs/label;r.mkdir(exist_ok=False)
before=source.read_bytes();(r/'source.lean').write_bytes(before)
for name in ['tmp','cache','cache/xdg','lake_home']:(D/name).mkdir(parents=True,exist_ok=True)
env=dict(os.environ,PATH=str(runtime/'bin')+os.pathsep+os.environ['PATH'],
         MATHLIB_CACHE_DIR=str(D/'cache'),XDG_CACHE_HOME=str(D/'cache/xdg'),
         LAKE_HOME=str(D/'lake_home'),TMPDIR=str(D/'tmp'),LEAN_PATH=str(D))
cmd=[str(runtime/'bin/lake'),'env','lean','-R',str(D),str(source),'-o',str(D/(source.stem+'.olean'))]
start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
out=err=b'';code=None;timed_out=False
try:
    p=subprocess.run(cmd,cwd=OLD/'mathlib',env=env,capture_output=True,
                     stdin=subprocess.DEVNULL,timeout=240)
    out,err,code=p.stdout,p.stderr,p.returncode
except subprocess.TimeoutExpired as e:
    out,err,timed_out=e.stdout or b'',e.stderr or b'',True
for n,b in [('stdout',out),('stderr',err)]:(r/n).write_bytes(b)
receipt=dict(command=cmd,cwd=str(OLD/'mathlib'),started_utc=start,
             elapsed_seconds=time.monotonic()-t,timeout_seconds=240,timed_out=timed_out,
             exit_code=code,source_sha256=hashlib.sha256(before).hexdigest(),
             source_unchanged=source.read_bytes()==before,
             runtime_identity=identity,streams={n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
                                               for n,b in [('stdout',out),('stderr',err)]},
             environment_overrides={k:env[k]for k in ['PATH','MATHLIB_CACHE_DIR','XDG_CACHE_HOME','LAKE_HOME','TMPDIR','LEAN_PATH']})
(r/'execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(out.decode());print(err.decode());print('COMPILER_EXIT',code,'TIMEOUT',timed_out)
assert source.read_bytes()==before
raise SystemExit(code if code is not None else 1)
