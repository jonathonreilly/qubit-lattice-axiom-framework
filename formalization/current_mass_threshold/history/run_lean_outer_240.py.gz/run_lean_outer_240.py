from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
D=Path(__file__).resolve().parent
source,label=sys.argv[1:]
R=D/'outer'/label
R.mkdir(parents=True,exist_ok=False)
cmd=[sys.executable,str(D/'run_lean_240.py'),source,label]
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); t=time.monotonic()
out=err=b''; code=None; timeout=False
try:
    p=subprocess.run(cmd,cwd=D,capture_output=True,timeout=300,stdin=subprocess.DEVNULL)
    out,err,code=p.stdout,p.stderr,p.returncode
except subprocess.TimeoutExpired as e:
    out,err,timeout=e.stdout or b'',e.stderr or b'',True
for name,data in [('stdout',out),('stderr',err)]: (R/name).write_bytes(data)
record=dict(command=cmd,cwd=str(D),started_utc=start,elapsed_seconds=time.monotonic()-t,
    exit_code=code,timeout_seconds=300,timed_out=timeout,
    streams={n:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in [('stdout',out),('stderr',err)]})
(R/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
print(out.decode()); print(err.decode()); print(json.dumps(record,indent=2))
raise SystemExit(code if code is not None else 1)
