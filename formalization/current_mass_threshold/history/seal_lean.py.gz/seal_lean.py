from pathlib import Path
import datetime,hashlib,json
D=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
assert not (D/'SEAL.json').exists()
rows=[]
for folder in sorted((D/'logs').iterdir()):
 r=read(folder/'execution.json')
 assert r['source_unchanged'] and sha(folder/'source.lean')==r['source_sha256']
 for name,value in r['streams'].items():assert sha(folder/name)==value['sha256'] and (folder/name).stat().st_size==value['bytes']
 rows.append(dict(label=folder.name,source_sha256=r['source_sha256'],started_utc=r['started_utc'],elapsed_seconds=r['elapsed_seconds'],timeout_seconds=r['timeout_seconds'],exit_code=r['exit_code'],timed_out=r['timed_out']))
by={r['label']:r for r in rows}
assert set(by)=={'attempt01','attempt02','missing_energy_sign','missing_cross_terms','false_controls_sequential'}
assert by['attempt01']['exit_code']==1 and not by['attempt01']['timed_out']
assert by['attempt02']['exit_code']==0 and not by['attempt02']['timed_out']
assert by['false_controls_sequential']['exit_code']==1 and not by['false_controls_sequential']['timed_out']
assert by['missing_energy_sign']['timed_out'] and by['missing_cross_terms']['timed_out']
assert sha(D/'MassThreshold.lean')==by['attempt02']['source_sha256']
good=(D/'logs/attempt02/stdout').read_text()
assert 'sorryAx' not in good and 'error:' not in good
names=['reverse_minkowski_identity','pair_lower_bound','finite_total_mass_bound','missing_energy_sign_counterexample','missing_cross_terms_counterexample']
assert good.splitlines()==[f"'CurrentMassThreshold.{n}' depends on axioms: [propext, Classical.choice, Quot.sound]"for n in names]
bad=(D/'logs/false_controls_sequential/stdout').read_text()
assert bad.count('error: unsolved goals')==2 and bad.count('⊢ False')==2
assert (D/'MassThreshold.olean').is_file()
for folder in (D/'outer').iterdir():
 r=read(folder/'execution.json')
 for name,value in r['streams'].items():assert sha(folder/name)==value['sha256'] and (folder/name).stat().st_size==value['bytes']
identity=read(D/'logs/attempt02/execution.json')['runtime_identity']
for item in identity['records'].values():assert sha(Path(item['path']))==item['sha256']
files={}
for p in sorted(D.rglob('*')):
 if not p.is_file() or any(x in p.relative_to(D).parts for x in ['tmp','cache','lake_home','__pycache__']):continue
 files[str(p.relative_to(D))]=dict(sha256=sha(p),bytes=p.stat().st_size)
r=dict(sealed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent_note_sha256='9ce18a3ae1d424193b2d7c04fd63cb7e2b10987bb0f8e462f8ac409a2c674603',declarations=names,axioms=['propext','Classical.choice','Quot.sound'],successful_source_sha256=sha(D/'MassThreshold.lean'),object_sha256=sha(D/'MassThreshold.olean'),runtime_identity=identity,attempts=rows,files=files,scope='Root-authored finite algebra certificate, independent of but not a replacement for the analytic source review. No formalization of spectral/domain/locality/M13; no retained audit status.',recording_limit='First compilation has complete inner receipt and tool transcript but no separately saved outer-process receipt.')
(D/'SEAL.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(dict(seal_sha256=sha(D/'SEAL.json'),source_sha256=r['successful_source_sha256'],object_sha256=r['object_sha256'],files=len(files),attempts=rows),indent=2))
