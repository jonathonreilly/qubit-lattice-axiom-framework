import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.Tactic.NormNum
open scoped ComplexConjugate
example : conj (2 : ℂ) + conj (2 : ℂ) = 4 := by norm_num [map_ofNat]
