# Scoped formalization work in progress

Target: exact universal rank-one scattering algebra used by the excluded-walk
current theorem in regular PR #9479, science 0fbdf3fd66fc778faed9ffc11f0f59c4b8994041.
This is not a formalization of the analytic threshold, coarea regularity,
stationary wave-operator theorem, Cook estimates, or a physical dynamics law.
No retained-status audit is applied by building these proofs.

Planned obligations:
1. A complex unit phase produces a unitary rank-one update on a normalized
   Hilbert-space vector.
2. For a bounded self-adjoint observable, its transformed difference is the
   exact two-off-diagonal-rank-one expression after centering the contact
   vector. This is a universal identity, not finite matrix examples.
3. An orthonormal coherent pair has the stated sign-sensitive expectation
   change; a contact-aligned vector has zero expectation change.
4. Orthogonal outgoing projections yield the finite-beam transfer identity,
   with normalization and nonzero-overlap assumptions explicit if included.

Dependencies: Lean v4.35.0-rc4, matching mathlib commit
939d5d5d9e6f07d1d8c80a16fa3fa39a7518b716. Fetched upstream source identities
and the official release archive digest will be recorded. This task-local
runtime does not change a global Lean installation. The proof, compiler output,
axiom printouts and deliberate false-statement controls must be checked before
claiming a certificate. Compilation has not yet run.
