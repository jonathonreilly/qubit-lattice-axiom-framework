"""Source/version/log binding for the scoped formal algebra certificate."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import subprocess

D = Path(__file__).resolve().parent
M = D/'mathlib'
R = D/'lean-4.35.0-rc4-darwin_aarch64'


def sha(p):
    with Path(p).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


expected_archive = '743f536c58c2580577ef890985b4084e90c6039fce099018d5c0c67c13724218'
expected_source = '2f5260a23eecc90c6bf3fabe9e26c4c05a5595fa151b98010097a7ee501b22ae'
archive = D/'lean-4.35.0-rc4-darwin_aarch64.tar.zst'
assert sha(archive) == expected_archive
assert sha(D/'RankOneScattering.lean') == expected_source
assert not re.search(r'\b(sorry|admit|axiom|unsafe|native_decide)\b', (D/'RankOneScattering.lean').read_text())
attempt = json.loads((D/'logs/attempt05.json').read_text())
assert attempt['exit'] == 0 and attempt['source_sha256'] == expected_source
assert sha(D/'logs/attempt05.lean') == expected_source
final_log = (D/'final_compiler.log').read_text()
assert final_log == (D/'logs/attempt05.log').read_text()
assert all(x not in final_log for x in ['error:', 'warning:', 'sorryAx'])
axioms = [x for x in final_log.splitlines() if 'depends on axioms:' in x]
assert len(axioms) == 10
assert all(x.endswith('[propext, Classical.choice, Quot.sound]') for x in axioms)
controls = json.loads((D/'false_controls_manifest.json').read_text())
assert controls['main_source_sha256'] == expected_source
assert controls['main_olean_sha256'] == sha(D/'RankOneScattering.olean')
for x in controls['controls']:
    assert sha(D/x['source']) == x['source_sha256']
    assert sha(D/x['log']) == x['log_sha256']
    assert x['expected_exit'] == x['actual_exit'] and x['reached_intended_mathematical_check']
assert len(controls['controls']) == 7
assert sum(x['expected_exit'] == 1 for x in controls['controls']) == 6
identities = json.loads((D/'source_identities.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=M, text=True).strip() == \
    identities['mathlib_commit'] == '939d5d5d9e6f07d1d8c80a16fa3fa39a7518b716'
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'], cwd=M, text=True)
for path, x in identities['source_files'].items():
    assert sha(M/path) == x['sha256']
for name, commit in identities['packages'].items():
    assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=M/'.lake/packages'/name, text=True).strip() == commit
assert (M/'lean-toolchain').read_text().strip() == 'leanprover/lean4:v4.35.0-rc4'
version = subprocess.check_output([str(R/'bin/lean'),'--version'], text=True).strip()
assert '4.35.0-rc4' in version and 'c29b6dda4f7c20e3eeaa717c4e565663c5cfa364' in version
files = [p for p in D.iterdir() if p.is_file() and p.name not in ['receipt.json', archive.name]]
files += [p for root in [D/'logs', D/'controls'] for p in root.rglob('*') if p.is_file()]
artifacts = [{'path':str(p.relative_to(D)), 'sha256':sha(p), 'bytes':p.stat().st_size}
             for p in sorted(files)]
receipt = {
    'created_at_utc':datetime.now(timezone.utc).isoformat(),
    'scope':'universal complex-Hilbert-space rank-one algebra, not analytic scattering or retained status',
    'main_source':{'path':'RankOneScattering.lean', 'sha256':expected_source, 'lines':202,
                   'complete_final_source_read':True, 'no_sorry_admit_custom_axiom':True},
    'compiled_olean':{'path':'RankOneScattering.olean', 'sha256':sha(D/'RankOneScattering.olean')},
    'final_compile':attempt,
    'final_compiler_log':{'path':'final_compiler.log', 'sha256':sha(D/'final_compiler.log'),
                          'complete_log_read':True, 'errors':0, 'warnings':0},
    'axiom_printouts':{'count':10, 'only_axioms':['propext','Classical.choice','Quot.sound'],
                       'path':'axioms.txt', 'sha256':sha(D/'axioms.txt')},
    'runtime':{'archive':archive.name, 'archive_sha256':expected_archive,
               'verified_before_extraction':True, 'version':version,
               'binaries':{name:sha(R/'bin'/name) for name in ['lean','lake','leantar']}},
    'mathlib':identities,
    'cache':{'execution':json.loads((D/'cache_execution.json').read_text()),
             'targeted_dependency_files':2482, 'full_mathlib_cache_requested':False,
             'trusted_imports':'ordinary source-keyed upstream cached artifacts; dependency library not manually reproved'},
    'false_controls':controls,
    'controls_summary':{'three_closed_true_boundary_witnesses_compile':True,
                        'six_false_statements_rejected_at_mathematical_goals':True,
                        'complete_current_compiler_logs_read':True,
                        'initial_control_harness_failure_preserved':'logs/control_attempt01/'},
    'scope_source':{'path':'SCOPED_OBLIGATIONS.md', 'sha256':sha(D/'SCOPED_OBLIGATIONS.md'),
                    'complete_read':True, 'upstream_science_reference':'0fbdf3fd66fc778faed9ffc11f0f59c4b8994041 as supplied by this scope file; no full analytic-source formalization claimed'},
    'limits':['No analytic threshold, coarea, Cook, wave-operator, global completeness or physical-law theorem formalized.',
              'The model-specific identification of physical scattering with the rank-one update remains external.',
              'Coherent normalization and w=sigma*u are explicit hypotheses; no existence construction of that u is asserted.',
              'The outgoing map is bounded with explicit disjointness; projection/flux interpretation remains explicit.',
              'No retained-status decision or shared-repository change.'],
    'environment_policy':{'installation':'task-local', 'cache':'task-local', 'temp':'task-local',
                          'PATH':'per-process runtime prepend', 'global_elan_or_configuration_changes':False,
                          'editable_prompt_files_changed':[]},
    'artifacts':artifacts,
    'receipt_scope':'All small proof, control and log artifacts are bound. Runtime archive and pinned dependency identities are bound separately. Receipt does not hash itself.'
}
(D/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({'source':expected_source, 'report':sha(D/'SCOPE_REPORT.md'),
                  'receipt':sha(D/'receipt.json'), 'artifacts':len(artifacts),
                  'compiled_theorem_axiom_reports':10, 'rejected_false_statements':6}))
