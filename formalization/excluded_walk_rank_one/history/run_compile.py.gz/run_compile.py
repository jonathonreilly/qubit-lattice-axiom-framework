from pathlib import Path
import os, sys, subprocess, time, json, hashlib

D = Path(__file__).resolve().parent
runtime = D / 'lean-4.35.0-rc4-darwin_aarch64'
source = D / sys.argv[1]
label = sys.argv[2]
logs = D / 'logs'
logs.mkdir(exist_ok=True)
snapshot = logs / (label + '.lean')
snapshot.write_bytes(source.read_bytes())
env = dict(os.environ, PATH=str(runtime/'bin')+os.pathsep+os.environ['PATH'],
           MATHLIB_CACHE_DIR=str(D/'cache'), XDG_CACHE_HOME=str(D/'cache/xdg'),
           LAKE_HOME=str(D/'lake_home'), TMPDIR=str(D/'tmp'))
cmd = [str(runtime/'bin/lake'), 'env', 'lean', '-R', str(D), str(source), '-o', str(D/(source.stem+'.olean'))]
t = time.monotonic()
try:
    p = subprocess.run(cmd, cwd=D/'mathlib', env=env, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
    code, out = p.returncode, p.stdout
except subprocess.TimeoutExpired as ex:
    code, out = 124, ex.stdout or ''
    if isinstance(out, bytes): out = out.decode()
    out += '\nPROCESS TIMEOUT after 180 seconds\n'
(logs/(label+'.log')).write_text(out)
(logs/(label+'.json')).write_text(json.dumps({'command':cmd, 'cwd':str(D/'mathlib'),
    'exit':code, 'elapsed':time.monotonic()-t, 'timeout':180,
    'source_snapshot':str(snapshot), 'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()},indent=2)+'\n')
print(out)
print('COMPILER_EXIT', code)
sys.exit(code)
