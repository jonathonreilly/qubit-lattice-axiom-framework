"""Actual Lean invocations on closed false identities and wrong universal formulas."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

D = Path(__file__).resolve().parent
R = D / 'lean-4.35.0-rc4-darwin_aarch64'
C = D / 'controls'
C.mkdir(exist_ok=True)
env = dict(os.environ, PATH=str(R/'bin')+os.pathsep+os.environ['PATH'],
           MATHLIB_CACHE_DIR=str(D/'cache'), XDG_CACHE_HOME=str(D/'cache/xdg'),
           LAKE_HOME=str(D/'lake_home'), TMPDIR=str(D/'tmp'),
           LEAN_PATH=json.loads((D/'lean_path.json').read_text())['LEAN_PATH'])
header = '''import RankOneScattering
open scoped ComplexConjugate InnerProduct
open InnerProductSpace ContinuousLinearMap RankOneScattering
noncomputable section
set_option autoImplicit false
'''
abstract = '''universe u
variable {E : Type u} [NormedAddCommGroup E] [InnerProductSpace ℂ E] [CompleteSpace E]
local notation "⟪" x ", " y "⟫" => inner ℂ x y
'''
phase = '''example : ((scattering (1 : ℂ) 2)† ∘L scattering (1 : ℂ) 2) 1 = VALUE := by
  rw [scattering_adjoint]
  norm_num [scattering, map_ofNat]
'''
normalization = '''example : ((scattering (2 : ℂ) (-1))† ∘L scattering (2 : ℂ) (-1)) 1 = VALUE := by
  rw [scattering_adjoint]
  norm_num [scattering, map_ofNat]
'''
overlap = '''example : ‖(scattering (1 : ℂ) 1) 1‖ ^ 2 = VALUE := by
  norm_num [scattering]
'''
cases = [
    ('PositiveBoundaryWitnesses', 0, phase.replace('VALUE', '4') + normalization.replace('VALUE', '49') + overlap.replace('VALUE', '1')),
    ('FalsePhaseUnitarity', 1, phase.replace('VALUE', '1')),
    ('FalseVectorNormalization', 1, normalization.replace('VALUE', '1')),
    ('FalseOverlappingOutgoingZero', 1, overlap.replace('VALUE', '0')),
    ('FalseMissingConjugation', 1, abstract + '''example (g : E →L[ℂ] E) (hg : g† = g) (v : E)
    {s : ℂ} (hs : ‖s‖ = 1) :
    (scattering v s)† ∘L g ∘L scattering v s - g =
      (s - 1) • rankOne ℂ (centered g v) v +
      (s - 1) • rankOne ℂ v (centered g v) := by
  rw [observable_difference g hg v hs]
  ext x
  simp only [_root_.add_apply, _root_.smul_apply, rankOne_apply]
  module
'''),
    ('FalseCoherentSign', 1, abstract + '''example (g : E →L[ℂ] E) (hg : g† = g) {v u : E}
    (hv : ‖v‖ = 1) (hu : ‖u‖ = 1) (hvu : ⟪v, u⟫ = 0)
    {s : ℂ} (hs : ‖s‖ = 1) (sigma : ℝ)
    (hw : centered g v = (sigma : ℂ) • u) {r : ℝ} (hr : 2 * r ^ 2 = 1) :
    ⟪coherent v u r,
      ((scattering v s)† ∘L g ∘L scattering v s - g) (coherent v u r)⟫ =
      (-sigma * s.im : ℝ) := by
  rw [coherent_current g hg hv hu hvu hs sigma hw hr]
  norm_cast
  ring
'''),
    ('FalseMissingCapWeight', 1, abstract + '''example (A Q : E →L[ℂ] E) (hA : A† = A) (hAA : A ∘L A = A)
    (v : E) (hne : A v ≠ 0) (s : ℂ) (hdisjoint : Q (A v) = 0) :
    ‖Q (scattering v s (capVector A v))‖ ^ 2 =
      ‖s - 1‖ ^ 2 * ‖Q v‖ ^ 2 := by
  rw [cap_transfer A Q hA hAA v hne s hdisjoint]
  ring
'''),
]


def run(case):
    name, expected, body = case
    p = C / (name + '.lean')
    p.write_text(header + body)
    cmd = [str(R/'bin/lean'), '-R', str(D), str(p)]
    start = time.monotonic()
    proc = subprocess.run(cmd, cwd=D/'mathlib', env=env, stdout=subprocess.PIPE,
                          stderr=subprocess.STDOUT, text=True, timeout=180)
    log = C / (name + '.log')
    log.write_text(proc.stdout)
    if expected == 1:
        intended = ('unsolved goals' in proc.stdout or 'ring failed' in proc.stdout)
        # Reject tooling failures: the control must reach a mathematical goal.
        intended = intended and not any(x in proc.stdout for x in
            ['unknown identifier', 'does not exist', 'unexpected token', 'failed to synthesize',
             'Tactic `rewrite` failed', 'Tactic `apply` failed'])
    else:
        intended = 'error:' not in proc.stdout
    record = {'case':name, 'command':cmd, 'cwd':str(D/'mathlib'), 'expected_exit':expected,
              'actual_exit':proc.returncode, 'reached_intended_mathematical_check':intended,
              'elapsed_seconds':time.monotonic()-start, 'timeout_seconds':180,
              'source':str(p.relative_to(D)), 'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
              'log':str(log.relative_to(D)), 'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    print(json.dumps(record), flush=True)
    return record


selected = set(sys.argv[1:])
prior = D/'false_controls_manifest.json'
records = [] if not selected or not prior.exists() else [r for r in json.loads(prior.read_text())['controls'] if r['case'] not in selected]
with ThreadPoolExecutor(max_workers=2) as pool:
    for future in as_completed([pool.submit(run, case) for case in cases if not selected or case[0] in selected]):
        records.append(future.result())
manifest = {'main_source_sha256':hashlib.sha256((D/'RankOneScattering.lean').read_bytes()).hexdigest(),
            'main_olean_sha256':hashlib.sha256((D/'RankOneScattering.olean').read_bytes()).hexdigest(),
            'scope':'six mathematically false statements, plus three compiled scalar boundary witnesses',
            'controls':sorted(records, key=lambda x:x['case'])}
(D/'false_controls_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert all(r['actual_exit']==r['expected_exit'] and r['reached_intended_mathematical_check'] for r in records)
