# Conditional elimination of receiver error scale and a test of its supplier

Root's working derivation, 2026-10-15. This block starts from the observed
failure of a quantization-only constant-modulus waveform in the fixed Cassini
development window. M10 did not supply a physical discrepancy bound. The present
question is whether the **scale** of stochastic error can instead be eliminated,
and whether the required error law survives a direct observation-level challenge.
No scalar action, physical initial state, absolute scale or environment is derived.

## What is assumed, and what is eliminated

Let a training observation T select any measurable reference frequency g(T).
For a distinct validation vector of N complex samples, with N >= 3, suppose

    y = c u_f + epsilon,       u_f,j = exp(2 pi i f t_j).

The complex amplitude c and frequency f are unknown. Times are the specified
uniform grid, centered for numerical convenience. Frequencies are identified
modulo the sample rate fs. Conditional on T, suppose the direction
epsilon/||epsilon|| is uniform on the complex unit sphere and the radius is
strictly positive almost surely. Its radial distribution is entirely unspecified;
even direction-radius independence is unnecessary for the ratios below.
Independent proper complex Gaussian white noise is one sufficient example.
This angular symmetry is an explicit candidate physical import, not a consequence
of an equal output bandwidth and sample rate, a large fitted tone fraction,
isotropic covariance, a choice of filter, or a central-limit slogan.

The actual code vector is z. A separate ideal, unsaturated ADC premise implies
||z-y|| <= q. In doubled midrise code units, unit half-width in each real and
imaginary component gives q = sqrt(2N). A digital truncation convention alone
does not establish that this is the entire physical error. Here q describes only
quantization; epsilon describes all other admitted discrepancy.

Conditional angular symmetry eliminates the need to supply a stochastic noise
scale or radial law for the stated tests. It supplies **no deterministic upper
bound on error energy** and does not establish its own physical applicability.
All previously exposed Cassini data remain model-development data. The words
training and validation here name an internal sample split, not an independent
empirical test after campaign-level exposure.

## Frequency test without a supplied variance

Let P_f be the orthogonal projection onto span(u_f), P_S the projection onto
S = span(u_f,u_g), p = dim(S), A = P_S-P_f, and B = I-P_S. A and B are mutually
orthogonal projections with complex ranks r=p-1 and s=N-p. At the true f,

    Ay = A epsilon,       By = B epsilon.

For p=2, r=1 and s=N-2. A uniform sphere direction may be represented as G/||G||
for a proper complex standard Gaussian vector G; this represents the direction
only and does not assert Gaussian errors. Orthogonal groups of its coordinates
have independent Gamma(r,1) and Gamma(s,1) squared norms. The shared normalization
and actual error radius cancel. Consequently

    (s/r) ||Ay||^2 / ||By||^2  ~  F_(2r,2s), conditional on T.

The denominator is positive almost surely under the positive-radius premise.
For upper-tail probability alpha, put

    tau^2 = (r/s) F_(2r,2s)^(-1)(1-alpha).

For r=1 this simplifies to tau^2 = alpha^(-1/s)-1 by integrating the Beta(1,s)
tail. Accept f when ||Ay|| <= tau ||By||. This is inversion of a fixed-f test;
it does not require a multiplicity correction for a continuum of candidate
frequencies to cover the single true f. Simultaneous claims for many records do
require their own allocation. If p=1, use an always-accepted frequency test;
never divide by r=0. No numerical optimizer's selected g is asserted to be a
global spectral optimum, and no validation result enters its training algorithm.

The signal may be absent (c=0); coverage still holds while frequency identification
can become uninformative. A physical nonzero signal cannot be supplied by labeling
the largest numerical periodogram peak a carrier.

## Exact quantizer-safe cone geometry

For fixed orthogonal nonzero-rank A and B and tau>0 define

    K = {w: ||Aw|| <= tau ||Bw||}.

Its unused orthogonal component is unconstrained. If a=||Az|| and b=||Bz||,

    dist(z,K) = (a-tau b)_+ / sqrt(1+tau^2).

For a>tau b, the nearest radial norms are

    b'=(tau a+b)/(1+tau^2),       a'=tau b'.

Choose the projected directions aligned with Az and Bz, and leave the unused
component unchanged. If b=0, any direction in the nonempty range(B) suffices.
The norm reverse-triangle inequality shows every other point has at least this
radial distance, proving optimality. If a<=tau b the distance is zero. This does
not require convexity of K, which generally is absent.

Therefore the Euclidean ball of possible analog vectors intersects K exactly iff

    ||Az|| <= tau ||Bz|| + q sqrt(1+tau^2).

The true ADC cell box lies inside that ball, so this enlargement is conservative
for the cell premise. Under the candidate direction law, accepting by this rule
covers true f with probability at least 1-alpha. A larger q can only enlarge the
set. It is not a fitted residual bound or a claim that all analog vectors in the
outer ball are physically available ADC values.

## Fixed-frequency amplitude and joint coverage

At the true f, write c_hat = u_f^* z/N and E_z=||(I-P_f)z||^2. For analog y,

    (N-1) N |c_hat_y-c|^2 / ||(I-P_f)y||^2 ~ F_(2,2N-2).

Applying the same translated cone geometry gives the quantizer-safe disk

    |c-c_hat| <= [tau_c sqrt(E_z)+q sqrt(1+tau_c^2)]/sqrt(N),
    tau_c^2 = alpha_c^(-1/(N-1))-1.

Combining this with frequency inversion at alpha_f gives joint coverage at least
1-alpha_f-alpha_c by the union bound, conditional on the premises. This avoids
asserting independence of arbitrary reused statistics. In the nested unquantized
projection decomposition, a stronger product result can be derived from the
Dirichlet grouping law; it is not needed for the present code or empirical plan.
An inferred phase interval additionally requires a disk excluding zero. No
nonzero-amplitude or phase-unwrapping assumption is silently added.

## Observations can challenge the angular supplier

At candidate f, derotate by D_f^*=diag(exp(-2 pi i f t_j)), take a unitary DFT,
and omit the DC coordinate. The assumed constant tone then disappears exactly.
Split non-DC indices into H: |frequency|>=fs/4, and L: 0<|frequency|<fs/4.
Let a_f and b_f be the L and H coordinate norms, and let r and s be their complex
ranks. The corresponding projections are orthogonal and annihilate u_f. Under
the candidate angular law their normalized squared-norm ratio again has the
F_(2r,2s) distribution. Both tails can be tested with the same ADC-safe cone.

For N=500 and fs=1000 Hz, r=248 and s=251. At the true f, a low/high imbalance
is a model test, not a measurement of noise variance. Low/high energies evaluated
only at a fitted frequency are nuisance-dependent diagnostics; the next enclosure
keeps all candidate f instead of treating that fit as exact.

Let Z=||z||, R=|<u_g/sqrt(N),z>|/Z, and
k=|<u_f,u_g>|/N. For p=2 the normalized g tone decomposes into its f component
and a perpendicular unit vector v. Thus

    ||Az|| >= max(0,R-k) Z,       ||Bz|| <= Z.

The omitted factor 1/sqrt(1-k^2) could strengthen the first bound; discarding it
is conservative. With carrier threshold tau and Z>0, no frequency can be accepted
where

    R-k > tau + q sqrt(1+tau^2)/Z.

For aliased distance d between f and g in (0,fs/2], the uniform-grid Dirichlet
kernel gives

    k = |sin(pi N d/fs)|/[N sin(pi d/fs)]
      <= 1/[N sin(pi D/fs)]            whenever d>=D>0.

If this supplies a strict far-frequency exclusion, all remaining frequencies lie
on the arc g-D to g+D modulo fs. If the bound fails, the code declares the global
enclosure uninformative instead of selecting a convenient local interval.

For any spectral projection P,

    | ||P D_f^* z|| - ||P D_h^* z|| | <= 2 pi ||t z|| |f-h|.

This follows from the derivative of the diagonal unitary and the contraction of
an orthogonal projection. Hence the color cone score a_f-tau b_f has Lipschitz
constant at most (1+tau) 2 pi ||t z||. At each midpoint of an arc partition,
subtract this bound times the half-width and the ADC enlargement. A positive
lower score excludes that entire cell. Either color tail can exclude each cell;
if every cell is excluded, the joint frequency/color acceptance set is empty.

Use alpha_record/2 for the frequency statistic and alpha_record/4 per color tail.
The false-rejection probability of this full composite procedure is at most
alpha_record under the stated model at its true f, irrespective of correlation
among its three statistics. For the 1200 fixed records, alpha_record=.01/1200
also bounds the probability of any false rejection of their joint candidate
model by .01, without assuming independence across records. These are properties
of the fixed procedure under its premises, not a newly independent observational
test after the data helped motivate this class of procedures.

The current code evaluates the analytic enclosures in ordinary floating point.
It retains margins but is **not an outward-rounded interval proof** of observed
exclusion. Numerical outcomes are explicitly reported as development diagnostics.
Raw-level frequency aliasing, training-law failure, constant-amplitude/chirp
failure, colored noise, gain changes and unmodeled receiver behavior are possible
explanations of a discrepancy. A rejection cannot isolate error color or infer
new gravitational physics.

## Failure witness: covariance isotropy is insufficient

In C^N let epsilon choose a basis vector uniformly and multiply it by an
independent uniform phase, with fixed norm. Its mean is zero and covariance is
I/N, but its direction is atomic rather than sphere-uniform. For a rank-one A
aligned with one basis vector, the upper-tail cone rejects that atom with
probability 1/N, and accepts the other atoms (including any 0/0 case by the cone
inequality). For N=40 and nominal alpha=.01, actual rejection is .025. Merely
measuring equal variances and zero two-point correlations does not establish
this direction law. Similarly, unspecified FIR coefficients do not supply a
whitening transformation, and choosing one would add an import.

## Empirical roles and next gate

The registered first 600 seconds of the two previously exposed 13:35 products
remain the only observations in this block. Each record is split at sample500;
the frequency reference uses the first half only. All 1200 records, flags and
competing peaks are retained. Expected FGAIN Px/No settings are summarized as
instrument settings, never as measured C/N0. No new raw product is opened.

If the conditional supplier fails this challenge, preserve the failure and seek
an actual filter/covariance or mean-waveform supplier, rather than interpreting
the residual as a scalar signal. If it survives, the physical premise remains
unproved; survival alone neither derives a scalar assumption nor calibrates an
independent experiment. The user-requested work-back program still requires a
distinct observation-supported action, initial-state, scale and environmental
bridge. This block is a bounded attempt to remove one measurement import.
