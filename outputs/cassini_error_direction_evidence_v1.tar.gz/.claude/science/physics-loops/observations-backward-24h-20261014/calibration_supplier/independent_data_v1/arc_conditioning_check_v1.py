"""Narrow post-exposure conditioning check on five preserved comparison failures."""
from pathlib import Path
import importlib.util,json,math,hashlib
OUT=Path(__file__).resolve().parent;WT=OUT.parents[5]
spec=importlib.util.spec_from_file_location('independent_direction_frozen',OUT/'independent_direction_v1.py')
ind=importlib.util.module_from_spec(spec);spec.loader.exec_module(ind)
def rows(p):return [json.loads(s) for s in p.read_text().splitlines()]
def main():
    author={(r['band'],r['record_index']):r for r in rows(OUT/'author_inputs_v1/DIRECTION_ROWS_v1.jsonl')}
    own={(r['band'],r['record_index']):r for r in rows(OUT/'DIRECTION_ROWS_v1.jsonl')}
    path=WT/'outputs/cassini_rsr_inputs/c32easc2002_169_1335x54k25d.1b1'
    result=[]
    with path.open('rb') as raw:
        for index,level,alevel in [(324,'family_record','family_1200'),(512,'per_record','pointwise'),(566,'per_record','pointwise'),(586,'family_record','family_1200'),(595,'family_record','family_1200')]:
            a=author['Ka',index]['result'];b=own['Ka',index];g=a['training_frequency_Hz'];h=b['training']['frequency_Hz']
            raw.seek(index*4260);record=raw.read(4260);assert hashlib.sha256(record).hexdigest()==b['raw_record_sha256']
            iq,z=ind.raw_decode(record);assert hashlib.sha256(iq.astype('>i4').tobytes()).hexdigest()==b['corrected_IQ_sha256']
            same=ind.exclude(z[500:],g,level);prior=b['direction_exclusion'][level];aresult=a['direction_challenge'][alevel]
            # No new optimizer or broad run: only use authored g as a fixed input.
            assert same['cell_count']==aresult['cells']==prior['cell_count']
            norm=same['norm_z'];tau=max(same['high_over_low_tau'],same['low_over_high_tau'])
            L=(1+tau)*2*math.pi*same['tnorm']/norm
            delta_g=abs(g-h);delta_D=abs(same['D_Hz']-prior['D_Hz']);delta_half=delta_D/same['cell_count']
            normalized_bound=L*(delta_g+delta_D+delta_half)
            observed=abs(same['minimum_normalized_score']-prior['minimum_normalized_score'])
            assert observed<=normalized_bound+1e-12
            common_D_rel=abs(same['D_Hz']/aresult['arc']['half_width_Hz']-1)
            common_score=abs(same['minimum_normalized_score']-aresult['normalized_lower_score'])
            assert common_D_rel<1e-10 and common_score<1e-10
            assert same['numerical_global_exclusion']==prior['numerical_global_exclusion']==aresult['numerically_excluded']
            m=prior['m'];x=1/(500*.999*m)
            derivative=-1000/math.pi*x/(m*math.sqrt(1-x*x))
            predicted=derivative*(same['m']-prior['m'])
            result.append({'band':'Ka','record_index':index,'level':level,'original_training_frequency_difference_Hz':g-h,'m_independent':m,'m_at_author_g':same['m'],'D_independent_Hz':prior['D_Hz'],'D_at_author_g_Hz':same['D_Hz'],'D_derivative_wrt_m':derivative,'first_order_D_change_prediction_Hz':predicted,'actual_D_change_Hz':same['D_Hz']-prior['D_Hz'],'same_g_D_relative_difference_from_author':common_D_rel,'same_g_normalized_score_difference_from_author':common_score,'original_normalized_score':prior['minimum_normalized_score'],'at_author_g_normalized_score':same['minimum_normalized_score'],'observed_normalized_score_change':observed,'paired_mesh_Lipschitz_change_bound':normalized_bound,'cell_count':same['cell_count'],'decision_unchanged':True,'original_tolerance_failures_retained':True})
    out={'scope':'Five-record post-exposure conditioning diagnosis only; no new training fit or replacement original rows','hypothesis':'Small allowed training-optimizer differences propagate through subtraction-small m and the Dirichlet arcs; same-g evaluation should agree','results':result,'author_code_executed':False,'original_failures_cleared':False,'interval_certified':False}
    with (OUT/'ARC_CONDITIONING_RESULTS_v1.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
    print(json.dumps(out,indent=2))
if __name__=='__main__':main()
