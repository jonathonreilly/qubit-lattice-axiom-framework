"""Read-only frozen-source and existing-product binding; no scientific rerun."""
from pathlib import Path
import ast, hashlib, json
from datetime import datetime, timezone
P=Path(__file__).resolve().parent
WT=P.parents[5]
C=P/'canonical_inputs_v1'
O=C/'outputs/cassini_error_direction'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text())
def emit(n,v): (P/n).write_text(json.dumps(v,indent=2)+'\n')
m=read(P/'CANONICAL_INPUTS_v1.json')
for r in m['files']:
 p=Path(r['snapshot']); assert p.stat().st_size==r['bytes'] and digest(p)==r['sha256'],r
primary=C/'scripts/cassini_error_direction_check.py'
tree=ast.parse(primary.read_text())
assign={t.id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) for t in n.targets if isinstance(t,ast.Name) and t.id in ('AUDIT_TIMEOUT_SEC','AUDIT_INPUT_PATHS')}
paths=assign['AUDIT_INPUT_PATHS']; assert paths==m['declared_input_paths'] and len(paths)==7 and assign['AUDIT_TIMEOUT_SEC']==180
h=hashlib.sha256(b'runner-cache-input-fingerprint-v1\0')
for rel in paths:
 name=rel.encode();data=(C/rel).read_bytes();h.update(len(name).to_bytes(8,'big'));h.update(name);h.update(len(data).to_bytes(8,'big'));h.update(data)
fp=h.hexdigest()
cache=C/'logs/runner-cache/cassini_error_direction_check.txt'
head,rest=cache.read_text().split('----- stdout -----\n',1)
header={x.split(': ',1)[0]:x.split(': ',1)[1] for x in head.splitlines() if ': ' in x}
stdout,stderr=rest.split('----- stderr -----\n',1)
assert header['runner_sha256']==digest(primary) and header['input_fingerprint_sha256']==fp
assert header['timeout_sec']=='180' and header['exit_code']=='0' and header['status']=='ok'
receipt=read(C/'runtime/M11_CANONICAL_EXECUTION_v1.json');run=receipt['result']
assert receipt['cache_status']=='fresh' and receipt['cache_sha256']==digest(cache)
assert run['exit_code']==0 and run['status']=='ok' and run['timeout_sec']==180 and run['elapsed_sec']<180
assert run['stderr']=='' and not stderr.strip()
assert stdout.strip()==run['stdout'].strip()
summary=read(O/'SUMMARY_v1.json')
start=stdout.index('{\n  "status": "conditional-support"')
assert json.loads(stdout[start:])==summary
assert summary['primary_sha256']==digest(primary)
assert list(summary['source_inputs'])==paths
for rel,sha in summary['source_inputs'].items(): assert digest(C/rel)==sha
for rel,sha in summary['products'].items(): assert digest(O/rel)==sha
source=read(O/'SOURCE_FREEZE_v1.json')
assert len(source['source_inputs'])==5
for rel,sha in source['source_inputs'].items(): assert digest(C/rel)==sha
manifest=read(C/'scripts/cassini_error_direction_inputs.json')
assert source['raw_inputs']==manifest['products']
raw=[]
for r in manifest['products']:
 p=WT/'outputs/cassini_rsr_inputs'/r['filename'];sha=digest(p);assert sha==r['sha256'];raw.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha})
imports={}
for f in (C/'scripts').glob('*.py'):
 tr=ast.parse(f.read_text());imports[f.name]=[ast.unparse(n) for n in ast.walk(tr) if isinstance(n,(ast.Import,ast.ImportFrom))]
 local=[]
 for n in ast.walk(tr):
  if isinstance(n,ast.Import): local.extend(x.name for x in n.names if x.name.startswith('cassini_'))
  if isinstance(n,ast.ImportFrom) and (n.module or '').startswith('cassini_'): local.append(n.module)
 assert set(local)<={'cassini_error_direction','cassini_error_direction_development','cassini_error_direction_sampling'}
a=ast.parse((P/'author_inputs_v1/direction_geometry_v1.py').read_text());b=ast.parse((C/'scripts/cassini_error_direction.py').read_text())
fa={n.name:ast.dump(n,include_attributes=False) for n in a.body if isinstance(n,ast.FunctionDef)}
fb={n.name:ast.dump(n,include_attributes=False) for n in b.body if isinstance(n,ast.FunctionDef)}
assert fa.keys()==fb.keys(); same=[n for n in fa if fa[n]==fb[n]];changed=[n for n in fa if fa[n]!=fb[n]];assert changed==['controls']
working=P/'author_inputs_v1/DIRECTION_ROWS_v1.jsonl';canon=O/'DIRECTION_ROWS_v1.jsonl'
assert working.read_bytes()==canon.read_bytes()
rows=[json.loads(x) for x in canon.read_text().splitlines()];assert len(rows)==1200
old=read(P/'author_inputs_v1/DIRECTION_SUMMARY_v1.json');new=read(O/'DIRECTION_SUMMARY_v1.json')
diffs={k:[old.get(k),new.get(k)] for k in old.keys()|new.keys() if old.get(k)!=new.get(k)}
assert set(diffs)=={'elapsed_seconds','source_freeze_sha256'}
assert new['source_freeze_sha256']==digest(O/'SOURCE_FREEZE_v1.json')
comparison=read(P/'CANONICAL_COMPARISON_RESULTS_v1.json');oldcomp=read(P/'AUTHOR_COMPARISON_RESULTS_v1.json');assert comparison==oldcomp
assert (P/'CANONICAL_ROW_DIFFERENCES_v1.jsonl').read_bytes()==(P/'AUTHOR_ROW_DIFFERENCES_v1.jsonl').read_bytes()
assert len(comparison['failures'])==6 and comparison['all_discrete_decisions_equal'] and comparison['IQ_hashes_exact']==1200
counts={k:len(summary[k]) for k in ['geometry_controls','sampling_controls','receiver_controls','development_checks']}
assert counts=={'geometry_controls':26,'sampling_controls':9,'receiver_controls':6,'development_checks':10}
assert sum(counts.values())==summary['passed']==51 and summary['failed']==0
changes=[]
for row in m['files']:
 p=Path(row['path'])
 if p.is_file() and digest(p)!=row['sha256']:changes.append({'path':str(p),'frozen_sha256':row['sha256'],'current_sha256':digest(p)})
emit('CANONICAL_BINDING_RESULTS_v1.json',{'at':datetime.now(timezone.utc).isoformat(),'scope':'Frozen v1 source/product/cache binding only; no raw decoding, numerical fit, geometry evaluation, sampling or scientific aggregate rerun. v1 becomes historical when parent publishes correction.','snapshot_count':len(m['files']),'declared_input_count':len(paths),'cache_sha256':digest(cache),'input_fingerprint_sha256':fp,'run':{k:run[k] for k in ['status','exit_code','elapsed_sec','timeout_sec']},'author_control_counts':counts,'source_inputs':summary['source_inputs'],'products':summary['products'],'raw_current_hashes':raw,'imports':imports,'working_geometry_functions_AST_equal':same,'working_geometry_functions_changed':changed,'working_to_canonical_row_ledger_byte_equal':True,'canonical_vs_independent_comparison_byte_and_object_equal_to_original':True,'retained_tolerance_failures':comparison['failures'],'working_to_canonical_summary_changes':diffs,'live_changes_since_freeze_not_reviewed_here':changes,'open_v1_interpretation_issue':'If R may depend on U, c*u_f is a specified signal/location center, not necessarily E[y]. Parent notified correction is in progress.','independent_empirical_tests':0,'formal_audit':False})
print(json.dumps({'binding':'ok','files':len(m['files']),'input_fingerprint':fp,'controls':counts,'unchanged_geometry_functions':same,'retained_failures':len(comparison['failures']),'current_changed_paths':len(changes)},indent=2))
