"""Narrow source/cache/output v1-to-v2 binding. No scientific routine executed."""
from pathlib import Path
import ast, difflib, hashlib, json
from datetime import datetime, timezone
P=Path(__file__).resolve().parent
A=P/'canonical_inputs_v1'; B=P/'canonical_inputs_v2'
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def store(n,v): (P/n).write_text(json.dumps(v,indent=2)+'\n')
f=read(P/'CANONICAL_INPUTS_v2.json')
for x in f['files']:
 p=Path(x['snapshot']);assert p.stat().st_size==x['bytes'] and sha(p)==x['sha256']
paths=f['declared_input_paths'];assert len(paths)==7
primary='scripts/cassini_error_direction_check.py';note='docs/CASSINI_ERROR_DIRECTION_MODEL_BOUNDED_THEOREM_NOTE_2026-10-15.md'
old=(A/primary).read_text();new=(B/primary).read_text()
assert new==old.replace('supplied mean/direction/cadence/ADC premises','supplied signal/direction/cadence/ADC premises')
nt=(A/note).read_text()
anchor='even direction-radius independence is unnecessary for the ratios below.\n'
paragraph='''The term c u_f specifies a tone signal component (a location), not necessarily
E[y]. Neither zero error mean nor finite moments is required for these ratios.
For example, let U be uniform on the complex unit sphere and choose
R=1+kappa Re(U_1), with0<kappa<1. Then R>0 and U remains the direction, but
E[R U]=kappa e_1/(2N), since E[U]=0 and E[Re(U_1)U_j]=delta_(1j)/(2N).
Identifying c u_f with the statistical mean would require an additional moment
condition, which is not supplied or used here.

'''
assert nt.count(anchor)==1
nt=nt.replace(anchor,anchor+paragraph)
replacements=[('mean-waveform','signal-waveform'),('joint mean/error/measurement','joint signal/error/measurement'),('candidate mean model','candidate signal model'),('mean, direction and measurement model','signal, direction and measurement model'),('includes mean, conditional direction','includes signal, conditional direction'),('Correct mean / direction law','Correct signal / direction law'),('varying coherent mean or known','varying coherent signal or known'),('response/mean model','response/signal model')]
for x,y in replacements:assert nt.count(x)==1;nt=nt.replace(x,y)
assert nt==(B/note).read_text()
for rel in paths:
 if rel!=note:assert (A/rel).read_bytes()==(B/rel).read_bytes(),rel
patch=''.join(''.join(difflib.unified_diff((A/r).read_text().splitlines(keepends=True),(B/r).read_text().splitlines(keepends=True),fromfile='frozen-v1/'+r,tofile='final-v2/'+r)) for r in [primary,note])
(P/'CANONICAL_SOURCE_DELTA_v2.patch').write_text(patch)
h=hashlib.sha256(b'runner-cache-input-fingerprint-v1\0')
for rel in paths:
 name=rel.encode();b=(B/rel).read_bytes();h.update(len(name).to_bytes(8,'big'));h.update(name);h.update(len(b).to_bytes(8,'big'));h.update(b)
fp=h.hexdigest();cache=B/'logs/runner-cache/cassini_error_direction_check.txt'
head,rest=cache.read_text().split('----- stdout -----\n',1);header={x.split(': ',1)[0]:x.split(': ',1)[1] for x in head.splitlines() if ': ' in x}
stdout,stderr=rest.split('----- stderr -----\n',1)
assert header['runner_sha256']==sha(B/primary) and header['input_fingerprint_sha256']==fp
assert header['timeout_sec']=='180' and header['exit_code']=='0' and header['status']=='ok'
receipt=read(B/'runtime/M11_CANONICAL_EXECUTION_v2.json');run=receipt['result']
assert receipt['cache_status']=='fresh' and receipt['cache_sha256']==sha(cache)
assert run['exit_code']==0 and run['status']=='ok' and run['timeout_sec']==180 and run['elapsed_sec']<180 and run['stderr']==''
assert not stderr.strip() and stdout.strip()==run['stdout'].strip()
relout='outputs/cassini_error_direction'
s1=read(A/relout/'SUMMARY_v1.json');s2=read(B/relout/'SUMMARY_v1.json')
start=stdout.index('{\n  "status": "conditional-support"');assert json.loads(stdout[start:])==s2
assert s2['primary_sha256']==sha(B/primary) and list(s2['source_inputs'])==paths
for rel,hash_ in s2['source_inputs'].items():assert sha(B/rel)==hash_
for rel,hash_ in s2['products'].items():assert sha(B/relout/rel)==hash_
assert s2['passed']==51 and s2['failed']==0
for key in ['geometry_controls','sampling_controls','receiver_controls','development_checks','empirical_statistics']:
 assert s1[key]==s2[key],key
summary_changes={k:[s1.get(k),s2.get(k)] for k in s1.keys()|s2.keys() if s1.get(k)!=s2.get(k)}
assert set(summary_changes)=={'primary_sha256','source_inputs','probability_interpretation','products'}
assert s2['probability_interpretation']==s1['probability_interpretation'].replace('supplied mean/','supplied signal/')
for name in ['DIRECTION_ROWS_v1.jsonl','SOURCE_FREEZE_v1.json']:
 assert (A/relout/name).read_bytes()==(B/relout/name).read_bytes()
d1=read(A/relout/'DIRECTION_SUMMARY_v1.json');d2=read(B/relout/'DIRECTION_SUMMARY_v1.json')
dc={k:[d1.get(k),d2.get(k)] for k in d1.keys()|d2.keys() if d1.get(k)!=d2.get(k)};assert set(dc)=={'elapsed_seconds'}
for name in ['SUMMARY_v1.json','DIRECTION_ROWS_v1.jsonl','SOURCE_FREEZE_v1.json','DIRECTION_SUMMARY_v1.json']:
 assert (B/relout/name).read_bytes()==(B/'pack_copies'/('CANONICAL_v2_'+name)).read_bytes()
assert (B/'runtime/M11_CANONICAL_EXECUTION_v2.json').read_bytes()==(B/'pack_copies/EXECUTION_RESULT_v2.json').read_bytes()
for x in f['files']:
 assert sha(Path(x['path']))==x['sha256'],'Live source changed after v2 freeze: '+x['path']
assert sha(P/'CANONICAL_REVIEW_v1.md')=='bf5b72f13a3b2bd9e6c8114247b03d6312aeab6c60e6f64bdfebca7047511a79'
assert sha(P/'CANONICAL_IDENTITY_v1.json')=='abb13a5a088980cfe57caf3a4f8a85be323c909038e9cee8b21f5c5a5dd3518a'
store('CANONICAL_DELTA_BINDING_RESULTS_v2.json',{'at':datetime.now(timezone.utc).isoformat(),'scope':'Only signal-center wording, current source/cache/product bindings, old-product byte identity; no scientific or raw rerun.','snapshot_files':len(f['files']),'primary_sha256':sha(B/primary),'note_sha256':sha(B/note),'cache_sha256':sha(cache),'input_fingerprint_sha256':fp,'summary_sha256':sha(B/relout/'SUMMARY_v1.json'),'execution':{k:run[k] for k in ['status','exit_code','elapsed_sec','timeout_sec']},'control_count':51,'failed':0,'helpers_protocols_manifest_unchanged':True,'ledger_source_freeze_unchanged':True,'development_summary_delta':dc,'primary_summary_changed_keys':sorted(summary_changes),'all_pack_copies_exact':True,'current_live_bytes_equal_snapshot':True,'signal_center_witness':'For U uniform in complex unit sphere, E[U]=0, E[Re(U1) Uj]=delta_1j/(2N); positive R=1+kappa Re(U1) gives E[R U]=kappa e1/(2N).','v1_wording_issue_resolved':True,'original_six_comparison_failures_retained':read(P/'CANONICAL_COMPARISON_RESULTS_v1.json')['failures'],'formal_audit':False,'independent_empirical_tests':0})
print(json.dumps({'delta_binding':'ok','cache':sha(cache),'input_fingerprint':fp,'summary':sha(B/relout/'SUMMARY_v1.json'),'row_ledger':sha(B/relout/'DIRECTION_ROWS_v1.jsonl'),'checks':51,'unchanged_helpers':3,'retained_comparison_failures':6},indent=2))
