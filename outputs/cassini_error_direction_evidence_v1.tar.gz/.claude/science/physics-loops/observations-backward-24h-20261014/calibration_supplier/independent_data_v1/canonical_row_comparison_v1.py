"""Canonical-row replay of the preserved comparison; no raw extraction or author imports."""
from pathlib import Path
from collections import Counter,defaultdict
import hashlib,json,math
OUT=Path(__file__).resolve().parent;WT=OUT.parents[5];AUTHOR=OUT/'canonical_inputs_v1/outputs/cassini_error_direction'
def read(p):return json.loads(p.read_text())
def rows(p):return [json.loads(x) for x in p.read_text().splitlines()]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    for x in read(OUT/'INDEPENDENT_IDENTITY_v1.json')['files']:assert sha(Path(x['path']))==x['sha256']
    for x in read(OUT/'AUTHOR_INPUTS_v1.json')['files']:assert sha(Path(x['snapshot']))==x['sha256']
    inputs=read(AUTHOR/'SOURCE_FREEZE_v1.json')
    for rel,s in inputs['source_inputs'].items():assert sha(WT/rel)==s
    ours={(r['band'],r['record_index']):r for r in rows(OUT/'DIRECTION_ROWS_v1.jsonl')}
    ah=rows(AUTHOR/'DIRECTION_ROWS_v1.jsonl');headers={(h['band'],h['record_index']):h['fields'] for h in rows(OUT/'HEADERS_v1.jsonl')}
    assert len(ah)==len(ours)==1200
    differences=[];failures=[];maxima=defaultdict(float);matches=Counter();hist=defaultdict(lambda:defaultdict(Counter));counts=defaultdict(Counter)
    def close(metric,delta,limit,ident):
        delta=abs(float(delta));maxima[metric]=max(maxima[metric],delta)
        if delta>limit:failures.append({'record':ident,'metric':metric,'absolute_difference':delta,'limit':limit})
    for a in ah:
        key=(a['band'],a['record_index']);b=ours[key];h=headers[key];v=a['result'];d=b['diagnostics'];identity={'band':key[0],'record_index':key[1]}
        assert a['iq_sha256']==b['corrected_IQ_sha256'] and a['second']==b['second']==48900+key[1]
        assert a['error_count']==h['DATA ERROR COUNT']==0 and a['extremes']==b['extreme_components']==0
        for field in ['FGAIN','FGAIN IF BANDWIDTH','DIG ATTENUATION','TRACKING MODE','DATA ERROR COUNT']:hist[key[0]][field][str(h[field])]+=1
        matches['raw_IQ_hashes']+=1;assert v['training_fit_success']
        df=(v['training_frequency_Hz']-b['training']['frequency_Hz']+500)%1000-500;close('training_frequency_Hz',df,2e-5,identity)
        E=d['validation_energy'];norm=math.sqrt(E)
        close('residual_energy_relative_to_validation_energy',(v['validation_residual_energy']-d['residual_energy'])/E,5e-7,identity)
        amp=abs(complex(*v['validation_amplitude_at_training_frequency'])-complex(*d['projected_complex_amplitude']))/math.sqrt(E/500)
        close('amplitude_relative_to_validation_rms',amp,5e-7,identity)
        ldiff={}
        for lag in ['1','2','3','4','5','10','20']:
            delta=complex(*v['lag_correlations'][lag])-complex(*d['lags'][lag]['biased_normalized'])
            ldiff[lag]=[delta.real,delta.imag]
            close('biased_normalized_covariance_component',delta.real,1e-6,identity);close('biased_normalized_covariance_component',delta.imag,1e-6,identity)
        pseudo=complex(*v['residual_pseudocovariance'])-complex(*d['normalized_pseudo_covariance'])
        close('normalized_pseudocovariance_component',pseudo.real,1e-6,identity);close('normalized_pseudocovariance_component',pseudo.imag,1e-6,identity)
        ac=v['color_at_training_frequency'];bc=d['color'];assert ac['low_rank']==bc['low_rank']==248 and ac['high_rank']==bc['high_rank']==251
        for k in ['low_energy','high_energy']:close(k+'_relative_to_validation_energy',(ac[k]-bc[k])/E,5e-7,identity)
        ratio=1/bc['rank_normalized_high_over_low'];close('rank_normalized_color_ratio_relative',ac['low_per_rank_over_high_per_rank']/ratio-1,5e-7,identity)
        levels={}
        for an,bn in [('pointwise','per_record'),('family_1200','family_record')]:
            aa=v['direction_challenge'][an];bb=b['direction_exclusion'][bn]
            enc=aa['arc']['half_width_Hz']<500
            if enc!=bb['global_frequency_enclosure']:failures.append({'record':identity,'level':an,'metric':'enclosure_decision'})
            if aa['numerically_excluded']!=bb['numerical_global_exclusion']:failures.append({'record':identity,'level':an,'metric':'exclusion_decision'})
            counts[(key[0],an)]['enclosure']+=enc;counts[(key[0],an)]['exclusion']+=aa['numerically_excluded']
            close(an+'_R',aa['arc']['R']-bb['R'],5e-7,identity);close(an+'_m',aa['arc']['m']-bb['m'],5e-7,identity)
            if enc:
                if aa['cells']!=bb['cell_count']:failures.append({'record':identity,'level':an,'metric':'cell_count','author':aa['cells'],'independent':bb['cell_count']})
                close(an+'_D_relative',aa['arc']['half_width_Hz']/bb['D_Hz']-1,5e-7,identity)
                close(an+'_normalized_lower_score',aa['normalized_lower_score']-bb['minimum_normalized_score'],5e-7,identity)
                close(an+'_strict_margin',aa['arc']['strict_margin']-(bb['m']-bb['k']),5e-7,identity)
                close(an+'_tau_high',aa['tau_high']-bb['high_over_low_tau'],1e-12,identity);close(an+'_tau_low',aa['tau_low']-bb['low_over_high_tau'],1e-12,identity)
                assert aa['color_low_rank']==248 and aa['color_high_rank']==251 and aa['roundoff_certified'] is False
                levels[an]={'D_difference_Hz':aa['arc']['half_width_Hz']-bb['D_Hz'],'normalized_score_difference':aa['normalized_lower_score']-bb['minimum_normalized_score'],'cells_equal':aa['cells']==bb['cell_count'],'enclosure_equal':enc==bb['global_frequency_enclosure'],'exclusion_equal':aa['numerically_excluded']==bb['numerical_global_exclusion']}
            else:levels[an]={'both_no_enclosure':not bb['global_frequency_enclosure'],'exclusion_equal':aa['numerically_excluded']==bb['numerical_global_exclusion']}
        differences.append({**identity,'training_frequency_author_minus_independent_Hz':df,'lag_component_differences':ldiff,'pseudo_component_differences':[pseudo.real,pseudo.imag],'levels':levels})
    summary=read(AUTHOR/'DIRECTION_SUMMARY_v1.json');assert summary['ledger_sha256']==sha(AUTHOR/'DIRECTION_ROWS_v1.jsonl') and summary['source_freeze_sha256']==sha(AUTHOR/'SOURCE_FREEZE_v1.json')
    for band in ['X','Ka']:
        assert summary['headers'][band]=={k:dict(v) for k,v in hist[band].items()}
        for level in ['pointwise','family_1200']:
            a=summary['statistics'][band]['direction_challenge'][level];assert a['numerically_excluded']==counts[(band,level)]['exclusion'] and a['no_arc']==600-counts[(band,level)]['enclosure']
    result={'scope':'Post-freeze full raw-hash, training estimator, diagnostic and continuous-domain output correspondence; no author code executed','rows':len(ah),'IQ_hashes_exact':matches['raw_IQ_hashes'],'levels_per_row':2,'all_discrete_decisions_equal':not any(x['metric'] in ['enclosure_decision','exclusion_decision','cell_count'] for x in failures),'maximum_absolute_differences':dict(maxima),'failures':failures,'counts':{band:{level:dict(counts[(band,level)]) for level in ['pointwise','family_1200']} for band in ['X','Ka']},'normalization_mapping':'Author lag correlations use sum/N-residual-energy, matching independent biased_normalized; independent unbiased normalization also retained. Author low/high rank ratio is the reciprocal of independent high/low ratio.','author_aggregate_counts_match_rows':True,'author_header_histograms_match_independent_headers':True,'new_fit_or_selected_covariance':False,'interval_certified':False,'independent_empirical_tests':0}
    with (OUT/'CANONICAL_ROW_DIFFERENCES_v1.jsonl').open('x') as f:
        for d in differences:f.write(json.dumps(d,separators=(',',':'))+'\n')
    with (OUT/'CANONICAL_COMPARISON_RESULTS_v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
