"""Independent raw reconstruction and conditional direction geometry; no author imports."""
from pathlib import Path
from collections import Counter
import hashlib,json,math,struct,time
import numpy as np
from scipy.special import betaincinv, betainc

OUT=Path(__file__).resolve().parent
PACK=OUT.parents[1]
WT=OUT.parents[5]
SCHEMA_PATH=PACK/'channel_quotient/independent_rsr_v1/PRIMARY_LABEL_SCHEMA_v1.json'
SCHEMA=json.loads(SCHEMA_PATH.read_text())
N=500; FS=1000.; GRID=16000; RECORD=4260; HEADER=260
T=(np.arange(N,dtype=float)-(N-1)/2)/FS
FREQ=np.fft.fftfreq(N,1/FS)
LOW=(np.abs(FREQ)>0)&(np.abs(FREQ)<250)
HIGH=np.abs(FREQ)>=250
LAGS=(1,2,3,4,5,10,20)
LEVELS=(('per_record',.01),('family_record',.01/1200))

def sha(b): return hashlib.sha256(b).hexdigest()
def load(p): return json.loads(p.read_text())
def cpair(z): return [float(np.real(z)),float(np.imag(z))]
def dump(p,v):
    with p.open('x') as f: json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
def headers(record):
    h={}
    for c in SCHEMA[:-1]:
        a=c['START_BYTE']-1; b=record[a:a+c['BYTES']];typ=c['DATA_TYPE']
        if typ=='CHARACTER': value=b.decode('ascii')
        elif typ=='IEEE_REAL':value=struct.unpack('>d',b)[0]
        elif 'ITEMS' in c:
            value=[int.from_bytes(b[i*c['ITEM_OFFSET']:i*c['ITEM_OFFSET']+c['ITEM_BYTES']],'big',signed=typ=='MSB_INTEGER') for i in range(c['ITEMS'])]
        else:value=int.from_bytes(b,'big',signed=typ=='MSB_INTEGER')
        h[c['NAME']]=value
    return h

def raw_decode(record):
    iq=[]
    for q,i in struct.iter_unpack('>hh',record[HEADER:]):iq.append((2*i+1,2*q+1))
    assert len(iq)==1000
    a=np.array(iq,dtype=np.int32)
    z=a[:,0].astype(float)+1j*a[:,1].astype(float)
    return a,z

def correlation_power(z,f):
    return float(abs(np.dot(z,np.exp(-2j*np.pi*f*T)))**2)

def training(z):
    fft=np.fft.fft(z,n=GRID);idx=int(np.argmax(np.abs(fft)))
    grid=float(np.fft.fftfreq(GRID,1/FS)[idx]);lo=grid-FS/GRID;hi=grid+FS/GRID
    initial=(lo,hi);rho=(math.sqrt(5)-1)/2
    x=hi-rho*(hi-lo);y=lo+rho*(hi-lo);fx=correlation_power(z,x);fy=correlation_power(z,y)
    iterations=0
    while hi-lo>2e-10 and iterations<100:
        if fx<fy:
            lo=x;x=y;fx=fy;y=lo+rho*(hi-lo);fy=correlation_power(z,y)
        else:
            hi=y;y=x;fy=fx;x=hi-rho*(hi-lo);fx=correlation_power(z,x)
        iterations+=1
    choices=[(x,fx),(y,fy),((lo+hi)/2,correlation_power(z,(lo+hi)/2))]
    f,power=max(choices,key=lambda p:p[1]);wrapped=(f+FS/2)%FS-FS/2
    finalpower=correlation_power(z,wrapped)
    return {'frequency_Hz':wrapped,'grid_frequency_Hz':grid,'grid_index':idx,'grid_size':GRID,'initial_interval_Hz':initial,'final_interval_Hz':[lo,hi],'iterations':iterations,'correlation_power':finalpower,'training_energy':float(np.vdot(z,z).real),'local_maximum_only':True}

def diagnostics(z,g):
    u=np.exp(2j*np.pi*g*T);amp=np.vdot(u,z)/N;r=z-amp*u
    E=float(np.vdot(r,r).real);v=E/N
    result={'N':N,'time_center_seconds':0.,'validation_energy':float(np.vdot(z,z).real),'projected_complex_amplitude':cpair(amp),'residual_energy':E,'residual_variance':v,'pseudo_covariance':cpair(np.dot(r,r)/N),'normalized_pseudo_covariance':cpair(np.dot(r,r)/E),'lags':{}}
    for lag in LAGS:
        s=np.vdot(r[:-lag],r[lag:])
        result['lags'][str(lag)]={'sample_pairs':N-lag,'covariance':cpair(s/(N-lag)),'normalized':cpair(s/((N-lag)*v)),'biased_normalized':cpair(s/E)}
    rd=r*np.conj(u)
    result['derotated_pseudo_covariance']=cpair(np.dot(rd,rd)/N)
    result['derotated_normalized_pseudo_covariance']=cpair(np.dot(rd,rd)/E)
    result['derotated_lags']={str(lag):cpair(np.vdot(rd[:-lag],rd[lag:])/((N-lag)*v)) for lag in LAGS}
    a=np.fft.fft(z*np.conj(u),norm='ortho');el=float(np.vdot(a[LOW],a[LOW]).real);eh=float(np.vdot(a[HIGH],a[HIGH]).real)
    result['color']={'low_rank':int(LOW.sum()),'high_rank':int(HIGH.sum()),'low_energy':el,'high_energy':eh,'high_over_low_energy':eh/el,'rank_normalized_high_over_low':(eh/HIGH.sum())/(el/LOW.sum()),'low_plus_high_minus_residual':el+eh-E}
    return result

def thresholds(alpha):
    carrier=math.sqrt(math.expm1(-math.log(alpha/2)/(N-2)))
    h,l=int(HIGH.sum()),int(LOW.sum())
    bh=float(betaincinv(h,l,1-alpha/4));bl=float(betaincinv(l,h,1-alpha/4))
    return carrier,math.sqrt(bh/(1-bh)),math.sqrt(bl/(1-bl))

THRESH={name:thresholds(alpha) for name,alpha in LEVELS}
def exclude(z,g,name):
    tc,th,tl=THRESH[name];norm=float(np.linalg.norm(z));q=math.sqrt(2*N)
    R=abs(np.dot(z,np.exp(-2j*np.pi*g*T)))/(math.sqrt(N)*norm)
    m=R-tc-q*math.sqrt(1+tc*tc)/norm;k=.999*m
    row={'alpha':dict(LEVELS)[name],'carrier_tau':tc,'high_over_low_tau':th,'low_over_high_tau':tl,'R':float(R),'m':float(m),'k':float(k),'quantization_radius':q,'norm_z':norm,'global_frequency_enclosure':False,'numerical_global_exclusion':False,'interval_certified':False}
    if m<=1/N or k<=1/N:
        row['fallback_reason']='m or k no greater than 1/N';return row
    D=FS/math.pi*math.asin(1/(N*k));outside=(R-k-tc)*norm-q*math.sqrt(1+tc*tc)
    if outside<=0:
        row['fallback_reason']='strict outside-arc lower score not positive';return row
    cells=int(math.ceil(2*D/.01));half=D/cells
    centers=g-D+(np.arange(cells)+.5)*2*half
    tnorm=float(np.linalg.norm(T*z));margin_h=(1+th)*2*math.pi*tnorm*half+q*math.sqrt(1+th*th);margin_l=(1+tl)*2*math.pi*tnorm*half+q*math.sqrt(1+tl*tl)
    derotated=z[None,:]*np.exp(-2j*np.pi*centers[:,None]*T[None,:])
    spectrum=np.fft.fft(derotated,axis=1,norm='ortho')
    low=np.linalg.norm(spectrum[:,LOW],axis=1);high=np.linalg.norm(spectrum[:,HIGH],axis=1)
    sh=high-th*low-margin_h;sl=low-tl*high-margin_l;best=np.maximum(sh,sl);idx=int(np.argmin(best))
    row.update(global_frequency_enclosure=True,D_Hz=D,outside_arc_lower_score=float(outside),cell_count=cells,cell_width_Hz=2*half,tnorm=tnorm,high_margin=margin_h,low_margin=margin_l,minimum_over_cells_max_two_tail_scores=float(best[idx]),minimum_normalized_score=float(best[idx]/norm),limiting_cell_index=idx,limiting_cell_midpoint_Hz=float(centers[idx]),limiting_cell_high_score=float(sh[idx]),limiting_cell_low_score=float(sl[idx]),high_tail_positive_cells=int(np.sum(sh>0)),low_tail_positive_cells=int(np.sum(sl>0)),numerical_global_exclusion=bool(best[idx]>0))
    return row

def controls():
    assert int(LOW.sum())==248 and int(HIGH.sum())==251
    assert list(struct.iter_unpack('>hh',bytes.fromhex('ffff8000')))==[(-1,-32768)]
    assert raw_decode(bytes(HEADER)+bytes.fromhex('ffff8000')*1000)[0][0].tolist()==[-65535,-1]
    tests=['independent_word_IQ_sign','nonDC_partition_ranks']
    for f in [0.,.2345,-2.21,499.99]:
        z=(2+3j)*np.exp(2j*np.pi*f*T);fit=training(z);err=(fit['frequency_Hz']-f+500)%1000-500
        assert abs(err)<1e-5,(f,err)
        tests.append('training_tone_'+str(f))
    z=np.arange(N)+1j*np.arange(N)[::-1];g=.31;d=diagnostics(z,g)
    assert abs(d['color']['low_plus_high_minus_residual'])<1e-6
    tests.append('Parseval_projected_partition')
    for name,alpha in LEVELS:
        tc,th,tl=THRESH[name]
        assert abs(math.exp(-(N-2)*math.log1p(tc*tc))-alpha/2)<1e-12
        for a,b,t in [(251,248,th),(248,251,tl)]:
            assert abs(float(betainc(a,b,t*t/(1+t*t)))-(1-alpha/4))<1e-12
        tests.append('independent_beta_threshold_'+name)
    return {'passed':len(tests),'checks':tests,'claim':'Algebra/numerical implementation controls only; no empirical directional-law validation'}

def main():
    start=time.monotonic();freeze=load(OUT/'PRECOMPUTE_FREEZE_v1.json')
    for item in freeze['reviewer_files']+freeze['metadata_files']:
        assert sha(Path(item['path']).read_bytes())==item['sha256'],item['path']
    manifest=load(WT/'scripts/cassini_rsr_development_inputs.json');entries={p['filename']:p for p in manifest['products']}
    cache=WT/'outputs/cassini_rsr_inputs'
    for name,entry in entries.items(): assert sha((cache/name).read_bytes())==entry['sha256'],name
    cont=controls();dump(OUT/'CONTROLS_v1.json',cont)
    results=[];anomalies=[];counts=Counter();headers_out=OUT/'HEADERS_v1.jsonl';rows_out=OUT/'DIRECTION_ROWS_v1.jsonl'
    with headers_out.open('x') as hf,rows_out.open('x') as rf:
        for band,filename in [('X','c32easc2002_169_1335x54x25d.1a1'),('Ka','c32easc2002_169_1335x54k25d.1b1')]:
            path=cache/filename
            assert path.stat().st_size==8941*RECORD
            with path.open('rb') as stream:
                for idx in range(600):
                    record=stream.read(RECORD);h=headers(record);iq,z=raw_decode(record)
                    flags=[]
                    for field,value in [('SAMPLE RESOLUTION',16),('SAMPLE RATE',1),('SFDU YEAR',2002),('SFDU DAY OF YEAR',169),('SFDU SECOND',48900+idx),('DATA CHDO LENGTH',4000),('RECORD SEQUENCE NUMBER',idx)]:
                        if h[field]!=value:flags.append({'field':field,'expected':value,'actual':h[field]})
                    for field in ['DATA ERROR COUNT','FROV FLAG']:
                        if h[field]:flags.append({'field':field,'actual':h[field]})
                    assert h['SAMPLE RESOLUTION']==16 and h['SAMPLE RATE']==1 and h['DATA CHDO LENGTH']==4000
                    extreme=int(np.count_nonzero(np.abs(iq)==65535));origin=int(np.count_nonzero(np.all(np.abs(iq)==1,axis=1)))
                    if extreme: flags.append({'extreme_components':extreme})
                    corrected=iq.astype('>i4').tobytes();fit=training(z[:N]);g=fit['frequency_Hz'];validation=z[N:]
                    diagnostic=diagnostics(validation,g);exclusions={name:exclude(validation,g,name) for name,alpha in LEVELS}
                    row={'band':band,'record_index':idx,'second':h['SFDU SECOND'],'raw_record_sha256':sha(record),'raw_payload_sha256':sha(record[HEADER:]),'corrected_IQ_sha256':sha(corrected),'training_IQ_sha256':sha(corrected[:N*8]),'validation_IQ_sha256':sha(corrected[N*8:]),'anomalies':flags,'extreme_components':extreme,'origin_touching_cells':origin,'training':fit,'diagnostics':diagnostic,'direction_exclusion':exclusions}
                    hf.write(json.dumps({'band':band,'record_index':idx,'raw_record_sha256':sha(record),'fields':h},separators=(',',':'),allow_nan=False)+'\n');rf.write(json.dumps(row,separators=(',',':'),allow_nan=False)+'\n')
                    results.append(row);counts[band]+=1
                    if flags:anomalies.append({'band':band,'record_index':idx,'anomalies':flags})
    aggregate={name:{'enclosures':sum(r['direction_exclusion'][name]['global_frequency_enclosure'] for r in results),'numerical_exclusions':sum(r['direction_exclusion'][name]['numerical_global_exclusion'] for r in results),'non_enclosures':[{'band':r['band'],'record_index':r['record_index'],'reason':r['direction_exclusion'][name].get('fallback_reason')} for r in results if not r['direction_exclusion'][name]['global_frequency_enclosure']],'non_exclusions':[{'band':r['band'],'record_index':r['record_index']} for r in results if not r['direction_exclusion'][name]['numerical_global_exclusion']]} for name,alpha in LEVELS}
    summary={'scope':'Independent previously exposed raw reconstruction and conditional numerical model challenge; no independent empirical test','source_sha256':sha(Path(__file__).read_bytes()),'raw_manifest_sha256':sha((WT/'scripts/cassini_rsr_development_inputs.json').read_bytes()),'thresholds':{name:dict(zip(['carrier','high_over_low','low_over_high'],ts)) for name,ts in THRESH.items()},'controls':cont,'record_counts':dict(counts),'anomalies':anomalies,'aggregate':aggregate,'products':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in [headers_out,rows_out]},'elapsed_sec':time.monotonic()-start,'author_sources_or_results_read':False,'interval_certified':False,'physical_covariance_derived':False,'independent_empirical_tests':0}
    dump(OUT/'RESULTS_v1.json',summary);print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
