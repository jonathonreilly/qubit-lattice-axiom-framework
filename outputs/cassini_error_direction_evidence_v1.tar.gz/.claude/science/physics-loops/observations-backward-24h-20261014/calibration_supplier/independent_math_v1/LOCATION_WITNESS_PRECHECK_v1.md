# Independent location-versus-mean witness precheck, v1

This is a narrow proof from the parent-supplied witness, before inspecting its new canonical wording. It does not change the earlier independent proof or rerun any aggregate. Let U be uniform on the complex unit sphere in C^N and let 0<kappa<1. Define R=1+kappa*Re(U_1) and epsilon=R*U.

Since |Re(U_1)|<=1, we have 0<1-kappa<=R<=1+kappa<infinity. Thus epsilon/||epsilon||=U exactly, R has the required strict positivity, and this bounded example has every finite absolute moment. Its nonzero mean is not due to a moment-existence pathology.

Unitary invariance gives E[U]=0 and E[U_j conjugate(U_k)]=delta_jk/N: off-diagonal terms vanish under a coordinate phase rotation and all diagonal moments are equal with sum1. Global phase invariance also gives E[U_j U_k]=0. Therefore

    E[U_j Re(U_1)]
      = (E[U_j U_1] + E[U_j conjugate(U_1)])/2
      = delta_j1/(2N),

and consequently E[epsilon]=kappa*e_1/(2N), which is nonzero. The same argument holds conditional on training if the uniform angular law is conditional and kappa is a fixed admissible value (or a training-measurable admissible value).

Thus uniform direction with arbitrary direction-dependent positive radius does not imply zero mean, even when moments exist. In y=c*u_f+epsilon, the specified c*u_f is a signal/location center around which the angular law is stated, not automatically E[y]. In the general theorem no error moments need exist at all. If the radial law happens to be independent of U and has a finite first moment, then zero mean follows, but that stronger assumption is not required or supplied for the scale-free pivots.

The carrier and amplitude proofs remain valid: the signal/location vector is annihilated or subtracted pointwise, the positive radius cancels, and only the conditional direction law is used. Replacing c*u_f by an expectation without a new hypothesis would be an extra import. This correction changes interpretation, not the F laws, cone geometry, quantization enlargement or coverage proof. It does not derive a receiver mean, physical noise budget, scalar state or new field theory.
