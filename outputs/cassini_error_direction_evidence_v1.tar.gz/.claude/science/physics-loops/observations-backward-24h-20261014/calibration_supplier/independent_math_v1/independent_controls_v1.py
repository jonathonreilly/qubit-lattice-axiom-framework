#!/usr/bin/env python3
"""Pre-author-source controls for conditional complex-direction inference.

No observations, author imports, numerical F library, network, or Monte Carlo.
Exact Fraction witnesses and independently integrated beta/simplex probabilities
are separated from illustrative floating deterministic Fourier controls.
"""
from fractions import Fraction as F
from itertools import product
from math import comb, factorial, sqrt, pi, sin, exp
import cmath
import json
import sys
import traceback

CASES=[]
def check(name, ok, detail, kind="exact"):
    CASES.append({"name":name,"passed":bool(ok),"kind":kind,"detail":detail})
    if not ok:
        raise AssertionError(name)

def pair(a=0,b=0): return (F(a),F(b))
def add(a,b): return (a[0]+b[0],a[1]+b[1])
def mul(a,b): return (a[0]*b[0]-a[1]*b[1], a[0]*b[1]+a[1]*b[0])
def conj(a): return (a[0],-a[1])
def scale(a,s): return (a[0]*s,a[1]*s)
def n2(a): return a[0]*a[0]+a[1]*a[1]
def mean(xs):
    s=pair()
    for x in xs:s=add(s,x)
    return scale(s,F(1,len(xs)))

def beta_integral(r,s,x):
    # Expand (1-v)^(s-1), integrate normalized gamma-change density.
    k=F(factorial(r+s-1),factorial(r-1)*factorial(s-1))
    return k*sum((F((-1)**j*comb(s-1,j))*x**(r+j)/F(r+j)
                  for j in range(s)), F(0))

def beta_binomial(r,s,x):
    # Independent finite binomial-tail expression for comparison.
    m=r+s-1
    return sum((F(comb(m,j))*x**j*(1-x)**(m-j)
                for j in range(r,m+1)),F(0))

def inner(x,y): return sum(a.conjugate()*b for a,b in zip(x,y))
def norm(x): return sqrt(max(0.,inner(x,x).real))
def vmul(s,x): return [s*a for a in x]
def vadd(x,y): return [a+b for a,b in zip(x,y)]
def vsub(x,y): return [a-b for a,b in zip(x,y)]
def dft(x):
    n=len(x)
    return [sum(x[j]*cmath.exp(-2j*pi*k*j/n) for j in range(n))/sqrt(n)
            for k in range(n)]
def bins(n):
    signed=[k if 2*k<=n else k-n for k in range(n)]
    low=[k for k,j in enumerate(signed) if 0<4*abs(j)<n]
    high=[k for k,j in enumerate(signed) if 4*abs(j)>=n]
    return low,high
def subnorm(x,ind): return sqrt(sum(abs(x[j])**2 for j in ind))
def tone(f,t): return [cmath.exp(2j*pi*f*x) for x in t]
def project(q,z): return vmul(inner(q,z),q)
def ranktwo(f,g,t,z):
    qf=vmul(1/sqrt(len(t)),tone(f,t))
    qg=vmul(1/sqrt(len(t)),tone(g,t))
    v0=vsub(qg,project(qf,qg))
    vn=norm(v0)
    if vn<1e-12:
        raise ValueError("rank-zero contrast")
    v=vmul(1/vn,v0)
    az=project(v,z)
    bz=vsub(vsub(z,project(qf,z)),az)
    return norm(az),norm(bz),abs(inner(qf,qg)),abs(inner(qg,z))/norm(z)
def color_score(f,z,t,tau,q):
    low,high=bins(len(z))
    w=dft([a*cmath.exp(-2j*pi*f*x) for a,x in zip(z,t)])
    return subnorm(w,low)-tau*subnorm(w,high)-q*sqrt(1+tau*tau)
def close(a,b,tol=1e-11):return abs(a-b)<=tol*max(1.,abs(a),abs(b))

def run():
    phases=[pair(1),pair(0,1),pair(-1),pair(0,-1)]
    magnitudes=[(F(1),F(7,5),F(1,5)),(F(1),F(1,5),F(7,5))]
    cloud=[[scale(p,m) for p,m in zip(ps,ms)]
           for ms in magnitudes for ps in product(phases,repeat=3)]
    means=[mean([z[i] for z in cloud]) for i in range(3)]
    covariance=[[mean([mul(z[i],conj(z[j])) for z in cloud])
                 for j in range(3)] for i in range(3)]
    pseudo=[[mean([mul(z[i],z[j]) for z in cloud])
             for j in range(3)] for i in range(3)]
    check("proper_white_covariance_counterexample_moments",
          means==[pair()]*3
          and covariance==[[pair(int(i==j)) for j in range(3)] for i in range(3)]
          and pseudo==[[pair()]*3 for _ in range(3)]
          and all(sum(map(n2,z))==3 for z in cloud),
          {"support_size":len(cloud),"mean":"0","covariance":"I",
           "pseudo_covariance":"0","radius_squared":"3"})
    reject=sum(n2(z[1])/n2(z[2])>19 for z in cloud)
    check("covariance_is_not_spherical_direction",
          F(reject,len(cloud))==F(1,2),
          {"nominal_alpha":"1/20","actual_rejection":str(F(reject,len(cloud))),
           "F_2_2_critical":"19","ratios":["49","1/49"]})
    for r,s in [(1,1),(1,2),(2,1),(2,3),(3,2)]:
        for x in [F(1,5),F(1,2),F(4,5)]:
            a=beta_integral(r,s,x); b=beta_binomial(r,s,x)
            check(f"beta_integral_r{r}_s{s}_v{x}",a==b and 0<a<1,
                  {"integral":str(a),"binomial_tail":str(b)})
    r,s,h=2,3,F(7,3)
    correct_v=F(r)*h/(F(s)+r*h)
    wrong_v=h/(1+h)
    check("rank_scaling_changes_F_probability",
          beta_integral(r,s,correct_v)!=beta_integral(r,s,wrong_v),
          {"correct_v":str(correct_v),"wrong_unscaled_v":str(wrong_v),
           "correct_cdf":str(beta_integral(r,s,correct_v)),
           "wrong_cdf":str(beta_integral(r,s,wrong_v))})
    alpha=F(1,10); h=(1-alpha)/alpha
    check("validation_adaptive_g_doubles_tail",
          F(2)/(1+h)==2*alpha and F(1)/(1+h)==alpha,
          {"fixed_tail":str(alpha),"adaptive_max_tail":str(2*alpha),
           "critical":str(h),"derivation":"disjoint exponential ratio tails"})

    # Dirichlet(1,1,1) uniform simplex: integrate directly in
    # C = signal energy fraction, X = first residual fraction.
    for ag,cmax in [(F(1,10),F(1,2)),(F(1,4),F(1,2)),(F(1,5),F(3,4))]:
        vmax=1-ag
        joint=2*vmax*(cmax-cmax*cmax/2)
        ac=(1-cmax)**2
        check(f"direct_simplex_joint_ag{ag}_cmax{cmax}",
              joint==(1-ag)*(1-ac),
              {"simplex_integral":str(joint),"product":str((1-ag)*(1-ac)),
               "alpha_amplitude":str(ac)})
    check("same_alpha_is_not_joint_alpha",
          F(9,16)<F(3,4),
          {"both_alpha":"1/4","joint_coverage":"9/16",
           "incorrect_single_level_claim":"3/4"})
    for s,kappa2 in [(1,F(3)),(2,F(1)),(3,F(3)),(4,F(1,3))]:
        endpoint=kappa2/(1+kappa2)
        # Direct Beta(1,s) density integral versus Laplace-derived formula.
        ac=1/(1+kappa2)**s
        check(f"amplitude_tail_s{s}_k2{kappa2}",
              1-beta_integral(1,s,endpoint)==ac,
              {"alpha":str(ac),"squared_disk_multiplier":str(kappa2)})
    # Both pivots are pointwise unchanged by direction-dependent positive R.
    base=[pair(F(2,3),F(1,5)),pair(F(4,7),F(-3,8)),pair(F(5,4),F(2,9))]
    radial=1+n2(base[1])**2
    scaled=[scale(a,radial) for a in base]
    check("arbitrary_positive_radius_cancels_both_pivots",
          n2(base[1])/n2(base[2])==n2(scaled[1])/n2(scaled[2])
          and n2(base[0])/(n2(base[1])+n2(base[2]))
          ==n2(scaled[0])/(n2(scaled[1])+n2(scaled[2])),
          {"chosen_radius":"1+|A U|^4 (direction dependent)","radius":str(radial)})

    tau=F(3,4); hyp=F(5,4)
    cone_cases=[(F(5,4),F(0)),(F(3),F(1)),(F(1),F(2)),
                (F(0),F(0)),(F(0),F(2)),(F(9,4),F(3)),
                (F(2,3),F(1,7))]
    for idx,(a,b) in enumerate(cone_cases):
        if a<=tau*b:
            x,w=a,b
        else:
            w=(tau*a+b)/(1+tau*tau); x=tau*w
        d2=(a-x)**2+(b-w)**2
        proposed=max(F(0),a-tau*b)**2/(1+tau*tau)
        grid_ok=all((a-X)**2+(b-W)**2>=d2
                    for W in [F(k,8) for k in range(65)]
                    for X in [F(j,4)*tau*W for j in range(5)])
        # Exact alignment witnesses in non-collinear complex directions.
        za,zb=pair(0,a),pair(-b,0)
        ya,yb=pair(0,x),pair(-w,0)
        vector_dist=n2(add(za,scale(ya,-1)))+n2(add(zb,scale(yb,-1)))
        check(f"cone_attainment_and_feasible_radial_grid_{idx}",
              x<=tau*w and d2==proposed==vector_dist and grid_ok,
              {"a":str(a),"b":str(b),"x_star":str(x),"w_star":str(w),
               "distance_squared":str(d2),"sampled_feasible_pairs":325})
    a,b,q=F(5,4),F(0),F(1)
    x,w=F(9,20),F(3,5)
    check("joint_component_quantization_orientation",
          x==tau*w and (a-x)**2+(b-w)**2==q*q
          and a-tau*b==q*hyp and a>tau*b+q,
          {"z_A":"5/4","z_B":"0","y_A":"9/20","y_B":"3/5",
           "error_A":"4/5","error_B":"-3/5",
           "exact_ball_accepts":True,"unsafe_q_only_rejects":True})
    check("zero_B_rank_counterexample",
          a*a != a*a/(1+tau*tau),
          {"rank_B":"0","actual_distance":"5/4","invalid_formula":"1"})
    check("quantized_amplitude_ball_disk_orientation",
          a==tau*b+q*hyp and a>tau*b+q and x==tau*w,
          {"coordinate":"beta=sqrt(N)*(c_hat-c)",
           "same_ball_witness_demonstrates_residual_radius_change":True})

    # Floating calculations below are deterministic controls, not certificates.
    n=8; fs=8.; t=[(j-(n-1)/2)/fs for j in range(n)]
    z=[complex(1+j/7, ((j*j+3*j)%7-3)/5) for j in range(n)]
    low,high=bins(n)
    w=dft(z)
    check("DFT_orthogonal_color_rank_and_norm",
          len(low)==2 and len(high)==5 and
          set(low+high+[0])==set(range(n)) and close(norm(w),norm(z)),
          {"N":n,"low_rank":len(low),"high_rank":len(high),
           "parseval_error":abs(norm(w)-norm(z))},"floating_control")
    for m in [3,4]:
        lo,hi=bins(m)
        check(f"empty_color_numerator_N{m}",len(lo)==0 and len(hi)==m-1,
              {"low_rank":len(lo),"high_rank":len(hi),"F_ratio":"undefined"})
    g=.37
    for f in [-2.7,-.2,.9,3.5]:
        a,b,k,R=ranktwo(f,g,t,z)
        delta=abs(f-g)%fs; delta=min(delta,fs-delta)
        formula=abs(sin(pi*n*delta/fs))/(n*sin(pi*delta/fs))
        lower=max(0.,R-k)*norm(z)/sqrt(1-k*k)
        check(f"direct_projection_Dirichlet_far_bound_f{f}",
              close(k,formula) and a+1e-11>=lower and b<=norm(z)+1e-11,
              {"direct_k":k,"Dirichlet_k":formula,"A_norm":a,
               "stronger_lower":lower,"B_norm":b},"floating_control")
    D=.7
    env=min(1.,1/(n*sin(pi*D/fs)))
    overlaps=[]
    for delta in [D,1.1,1.9,2.4,3.7,fs/2]:
        q0=vmul(1/sqrt(n),tone(0.,t))
        qd=vmul(1/sqrt(n),tone(delta,t))
        overlaps.append(abs(inner(q0,qd)))
    check("uniform_cadence_far_envelope_samples",
          all(k<=env+1e-12 for k in overlaps),
          {"D":D,"bound":env,"direct_overlaps":overlaps},"floating_control")
    ta=.75;q=.13
    tznorm=norm([x*a for x,a in zip(t,z)])
    L=(1+ta)*2*pi*tznorm
    Lsharp=sqrt(1+ta*ta)*2*pi*tznorm
    for f,g in [(.31,.4),(-3.9,3.9),(1.1,1.10001)]:
        delta=abs(f-g)%fs; delta=min(delta,fs-delta)
        diff=abs(color_score(f,z,t,ta,q)-color_score(g,z,t,ta,q))
        check(f"color_score_centered_Lipschitz_{f}_{g}",
              diff<=L*delta+1e-11 and diff<=Lsharp*delta+1e-11,
              {"score_difference":diff,"circular_distance":delta,
               "proposed_bound":L*delta,"sharper_bound":Lsharp*delta},
              "floating_control")
    check("centered_time_alias_periodic_norms",
          close(color_score(.31,z,t,ta,q),color_score(.31+fs,z,t,ta,q)),
          {"frequency":.31,"aliased_frequency":.31+fs,
           "centered_waveform_common_phase":"-1 for N=8"},"floating_control")
    try:
        ranktwo(.31,.31+fs,t,z)
    except ValueError:
        rejected=True
    else:
        rejected=False
    check("exact_alias_rank_degeneracy_detected",rejected,
          {"g_minus_f":"fs","rank_two_statistic":"not evaluated"},
          "floating_control")

if __name__=="__main__":
    failed=None
    try: run()
    except BaseException as exc:
        failed={"type":type(exc).__name__,"message":str(exc)}
        traceback.print_exc(file=sys.stderr)
    counts={k:sum(c["kind"]==k for c in CASES)
            for k in sorted({c["kind"] for c in CASES})}
    print(json.dumps({
        "purpose":"Independent pre-author-source mathematical controls",
        "author_source_opened":False,"observations_opened":False,
        "network_used":False,"Monte_Carlo_used":False,
        "all_passed":failed is None,"failure":failed,
        "check_count":len(CASES),"kinds":counts,"checks":CASES,
        "limits":["Floating cases are controls, not outward-rounded certificates.",
                  "No empirical noise/calibration/direction law was validated.",
                  "No author implementation was invoked."]},indent=2))
    sys.exit(1 if failed else 0)
