from pathlib import Path
import json,hashlib,subprocess,tempfile,time,os
ROOT=Path.cwd();OUT=ROOT/'.claude/science/physics-loops/observations-backward-24h-20261014/calibration_supplier'
names=['cassini_error_direction.py','cassini_error_direction_sampling.py','cassini_error_direction_development.py']
source={n:(ROOT/'scripts'/n).read_text() for n in names}
mutations=[
 ('cone_denominator','cassini_error_direction.py','max(0.,a-tau*b)/math.hypot(1.,tau)','max(0.,a-tau*b)'),
 ('complex_projection','cassini_error_direction.py','d=np.vdot(v,z)','d=np.dot(v,z)'),
 ('carrier_residual_rank','cassini_error_direction.py','-math.log(alpha)/s','-math.log(alpha)/(s+1)'),
 ('missing_second_projection','cassini_error_direction.py','res=z-uf*np.vdot(uf,z)/n-v*d','res=z-uf*np.vdot(uf,z)/n'),
 ('amplitude_normalization','cassini_error_direction.py','radius=(tau*b+q*math.hypot(1.,tau))/math.sqrt(n)','radius=(tau*b+q*math.hypot(1.,tau))/n'),
 ('amplitude_adc_margin','cassini_error_direction.py','radius=(tau*b+q*math.hypot(1.,tau))/math.sqrt(n)','radius=(tau*b+q)/math.sqrt(n)'),
 ('unitary_dft','cassini_error_direction.py','coeff=np.fft.fft(z*np.exp(-2j*np.pi*f*t))/math.sqrt(n)','coeff=np.fft.fft(z*np.exp(-2j*np.pi*f*t))'),
 ('carrier_adc_ignored','cassini_error_direction.py',"cone_distance(r['a'],r['b'],tau)<=q","cone_distance(r['a'],r['b'],tau)<=0"),
 ('outer_strict_margin','cassini_error_direction.py','k=.999*m','k=1.1*m'),
 ('complex_degrees_freedom','cassini_error_direction.py','f_law.isf(alpha, 2*r, 2*s)','f_law.isf(alpha, r, s)'),
 ('iq_order','cassini_error_direction_development.py','return i,q','return q,i'),
 ('validation_leakage','cassini_error_direction_development.py','train=z[:500];valid=z[500:]','train=z[500:];valid=z[500:]'),
 ('lipschitz_margin_omission','cassini_error_direction.py','lipschitz_base=2*math.pi*float(np.linalg.norm(times(len(z),fs)*z))','lipschitz_base=0.'),
]
check="""import numpy as np
import cassini_error_direction as g,cassini_error_direction_sampling as s,cassini_error_direction_development as d
g.controls();s.run();d.receiver_controls()
t=g.times(500,1000.);a=(20+5j)*np.exp(2j*np.pi*.123*t);b=(3-17j)*np.exp(2j*np.pi*9.87*t)
assert d.diagnose(np.concatenate([a,a]))['training_frequency_Hz']==d.diagnose(np.concatenate([a,b]))['training_frequency_Hz']
"""
rows=[]
for label,filename,old,new in mutations:
 assert source[filename].count(old)==1,(label,source[filename].count(old))
 with tempfile.TemporaryDirectory(prefix='cassini-direction-mutation-') as td:
  dest=Path(td)
  for name,txt in source.items(): (dest/name).write_text(txt.replace(old,new,1) if name==filename else txt)
  start=time.monotonic();run=subprocess.run(['/usr/local/bin/python3','-c',check],cwd=td,capture_output=True,text=True,timeout=90,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
  assertion=run.returncode!=0 and 'AssertionError' in run.stderr
  (OUT/(label+'_MUTATION_v1.stderr')).write_text(run.stderr)
  rows.append(dict(label=label,source=filename,original=old,mutation=new,mutant_sha256=hashlib.sha256((dest/filename).read_bytes()).hexdigest(),exit_code=run.returncode,assertion_rejected=assertion,elapsed_seconds=time.monotonic()-start,stderr_sha256=hashlib.sha256(run.stderr.encode()).hexdigest()))
  print(label,run.returncode,assertion,flush=True)
result=dict(source_sha256={n:hashlib.sha256(t.encode()).hexdigest() for n,t in source.items()},mutations=rows,assertion_rejected=sum(r['assertion_rejected'] for r in rows),survived=[r['label'] for r in rows if r['exit_code']==0],setup_failure=[r['label'] for r in rows if r['exit_code']!=0 and not r['assertion_rejected']])
(OUT/'CANONICAL_MUTATIONS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
