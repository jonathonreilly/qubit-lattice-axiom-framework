# Equal-time covariance lift without a common-transfer premise

Root derivation, 2026-10-15. Conditional exact support. This extends, rather
than retracts, STATISTICAL_INPUT_v1: P and gW alone did not supply the missing
partial derivative. A larger equal-time input collection can eliminate it.
The actual measured collection and calibration remain unproved.

At a common epoch on the full linear single-scalar/dust background define
V=H_J v_J=W/(K/H_J)^2 and J=3 exp(-3N)/E^2. For each fixed nonzero comoving
mode, define real equal-time covariances C_AB=Re E[A B*], with common time
and derivatives commuting with expectation. No Gaussianity, common growing
transfer or initial scalar covariance is assumed. Let T=Psi-Phi and S=Psi+Phi.
The exact Euler and momentum equations are

    V' = h V -(S+T)/2,
    S' = -(1+x/2)S - y T/2 - J R V,
    x=F'/F, y=x/q, R=rhoJ aJ^3/(3H0^2 F).

Eliminate T without dividing by y:

    S'-y V' = a S+c V,
    a=(y-x-2)/2, c=-h y-J R.                         (1)

Multiply (1) by the complex conjugate of S-yV and take the real expectation.
At this single epoch, y is a coefficient: do not differentiate it. Antisymmetric
partial derivatives cancel, leaving only total derivatives of equal-time powers:

    (C_SS' -2y C_SV' +y^2 C_VV')/2
       =a C_SS+(c-a y)C_SV-c y C_VV.                (2)

Set z=(x,y,y^2,J R-x y/2,J R y). Equation (2) is linear in these five lifted
unknowns, with each mode supplying one row

    [C_SS/2,
     -C_SS/2-C_SV'+(h-1)C_SV,
     C_VV'/2+C_SV/2-h C_VV,
     C_SV,
     -C_VV] z = -C_SS'/2-C_SS.                    (3)

Five independent rows uniquely determine z. Require z3=z2^2 and
z5=(z4+z1*z2/2)*z2, and put x=z1,y=z2,R=(z4+x*y/2)/J.
For J>0,R>0,y!=0,x/y>0, q=x/y. Further rows test the same inferred values.
The two monomial consistency relations are essential: an arbitrary lifted
linear solution is not a physical inverse. Matrix rank and ratio domains
remain input conditions. Turning points still leave q unidentified here.
No individual Fourier phase, direct slip covariance or unequal-time derivative
is needed by this larger construction. This is not supplied by a single E_G
summary or its error bar.

Rank is available, rather than enforced: substitute the physical equations into
the five row columns. They become

    [C_SS/2,
     x C_SV/2+C_ST/2+y C_VT/2+J R C_VV,
     -C_VT/2,
     C_SV,
     -C_VV].                                      (4)

This is an invertible linear transformation of
(C_SS,C_SV,C_VV,C_ST,C_VT), with nonzero constant coefficients on C_ST and
C_VT. Admissible positive-definite covariances of (S,V,T) form an open set;
their projection to these five entries contains an open set. Five independent
rows therefore exist. Equivalently, finite real ensembles realize positive
semidefinite covariance matrices, and arbitrary finite phi,v,X (and free Z)
are admissible local perturbation data with n fixed by the 00 constraint.
Small common amplitude scaling preserves rank and the linear regime.
This proves availability under the adopted perturbation model, not cosmic
preparation, actual measured rank, statistical independence of bands, or a
whole-history solution test. Explicit rational witnesses and independent
algebra are to be checked before downstream use.

Real data require jointly calibrated equal-time Weyl/physical-velocity auto and
cross covariances, their total derivatives on the same N and comoving-mode
coordinate, E,h and window operators. Noise deconvolution, bias, shot noise,
projection and stochasticity cannot be discarded. Cross-mode correlations can
be retained in the measurement covariance; they do not invalidate the algebra.
These are supplied physical inputs, not yet derived from ACT/BOSS products.
