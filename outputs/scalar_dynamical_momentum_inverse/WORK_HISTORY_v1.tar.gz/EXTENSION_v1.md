# Rank, background closure and finite-error scope

Root extension to WORKING_v1. All statements are conditional on its explicitly
defined metric, dust and single-scalar equations. No survey likelihood is added.

## Observable rank and preparation

At a common time set c=2A aE^3(H+bs)/(3H0^2), which is nonzero on the declared
expanding chart. Then P_i=-c phi_i/v_i and P_i r_i=-c b X_i/v_i. Therefore
the three-row matrix [1,-P_i/2,-P_i r_i/2] is nonsingular exactly when the
rows [v_i,phi_i,X_i] are independent, given b!=0 and each v_i!=0.
No evolution equation forces this determinant to vanish: choose finite phi_i,
v_i,X_i with independent rows, any finite Z_i, and obtain n_i from the 00
constraint because rho>0. Overall amplitude scaling makes all perturbations
small on a fixed finite interval. This establishes availability within the
conditional initial-value model, not a guaranteed or observed preparation.
The initial scalar states are retained in the readouts, not fixed by inversion.

Counterexamples remain: proportional [v,phi,X] rows give rank deficiency;
b=0 is outside the q>0 chart; s=0 gives x=y=0 and leaves q unidentified by
this one constraint even if the matrix is invertible. A nearly zero y makes
the ratio ill-conditioned. Zeros of W or S invalidate the normalized readout
chart; use the undivided metric constraint there instead of dividing through.
If all modes trace the same growing transfer shape, diversity of wave numbers
alone does not guarantee independent rows.

## Exact conditional error bound

Let L have rows [1,-P_i/2,-P_i r_i/2] and z=(R,x,y), Lz=M.
Given measured hats and justified absolute envelopes ePi, eri, eMi, take

    d=max_i {ePi/2 + (abs(Phat_i)eri+abs(rhat_i)ePi+ePi eri)/2},
    e=max_i eMi, n=||Lhat^-1||_infinity, eta=n d.

If Lhat is invertible and eta<1, the true matrix is invertible and

    ||z-zhat||_infinity <= eps=n(e+d||zhat||_infinity)/(1-eta).

This follows from the matrix inverse perturbation bound and
L(z-zhat)=(M-Mhat)+(Lhat-L)zhat. If abs(yhat)>eps,

    abs(q-qhat) <= (eps+abs(qhat)eps)/(abs(yhat)-eps), qhat=xhat/yhat.

Rhat>eps and qhat greater than its error bound certify positive R and q.
Failed sufficient inequalities are inconclusive, not empirical model rejection.
Noise, survey windows, numerical differentiation, calibration and quadrature
must be covered by the supplied envelopes. The theorem does not derive them.
This standard linear-algebra envelope is an application, not claimed novelty.

## Relative background and potential from inferred quantities

Since R=rho0/(3H0^2F), a candidate history must satisfy R'/R=-x. An equivalent
integral check is R(N2)/R(N1)=exp[-integral_N1^N2 x dN]; no scalar initial
state is chosen. The ratio fixes relative F while its absolute normalization
remains tied to the unknown rho0/F ruler. Put omega=(1/q-3)/2.
For the supplied single-scalar Jordan action
F Rmetric/2 -omega(F)(partial F)^2/(2F)-V(F), the background equations give

    x'+(h-1)x+(omega+1)x^2+2h+3R exp(-3N)/E^2=0,          (3)
    vpot=V/(F H0^2)=3E^2(1+x)-omega E^2 x^2/2-3R exp(-3N). (4)

Thus measured ideal histories reconstruct the kinetic coupling and normalized
potential along a rolling trajectory without positing a quasistatic pole or
initial perturbation. Off-trajectory action extensions and absolute scales are
not identified. At scalar turning points the F-coordinate formulation may
require a limiting chart even though the original canonical equations are regular.

For candidate membership, two nondegenerate epochs solve
q/beta+R(1-3q)kappa=1. If an exact candidate satisfies this relation,
the determinant of its two rows is (q1-q2)/kappa. Hence varying q suffices for
uniqueness of beta and kappa within this specified chart. Constant q does not
select a pair. Require beta in (1/4,1/3), kappa>0, q in (0,beta), and the
identity at every tested epoch; sampled checks do not prove an interval identity.

Recover the specified branch parameter
k=[1-2sqrt(1-3beta)]/3. With alpha=sqrt(beta), s=(1+k)/(k(1-3k)),
exp(2alpha u)=(beta/q-1)/[(1-3beta)s]. This fixes u only inside the chosen
functional family. A^2=C=(1+s)exp(2alpha u)/(1+s exp(2alpha u)).
Write its supplied potential U=U0+nu U1, with

    U0=3/2+3s(exp(2alpha u)-1)^2/[2(1+s exp(2alpha u))^2],
    U1=(1+s)u^2/[2(1+s exp(2alpha u))^2].

Equation (4) gives

    vpot C/2 = gamma U0 + gamma nu U1, gamma=(Hv/H0)^2.    (5)

Two linearly independent basis rows solve for (gamma,gamma nu); further epochs
are no-refit membership tests. Require gamma>0 and nu>0. This tests an adopted
potential family; it is not an action selector or an explanation of a scale.
Near u=0, U1 is tiny, so nu can be severely ill-conditioned even when beta is
well determined. Preserve numerical failures and conditioning rather than
interpreting rounded-readout inversion as exact physical inference.

## Radial sector and metric-label question

In the full candidate action, K_uu depends only on u; K_ux=K_uy=0;
the transverse fields vanish in the background; A_x=A_y=0; and U_x=U_y=0
at x=y=0. All first variations of background scalar energy/momentum in a
transverse perturbation therefore vanish, and the u equation has no term
linear in transverse perturbations. The arbitrary transverse linear modes
decouple from this metric/dust inverse. This says nothing about their quadratic
backreaction or nonlinear cosmological realization. It does not select them.

For explicit metric slots, the conformal map is always Psi_J=phi_E+bX,
Phi_J=phi_E-bX. The older vacuum note's displayed pair has Phi_J in the time
slot and Psi_J in the spatial slot if read consistently with this map. Its
numerical inverse measures the same time-minus-space ratio k y. Its own note
does not explicitly give the metric-slot dictionary, so label ambiguity is a
documentation issue; no changed physics is inferred from symbol names alone.
