# From individual modes to measured correlations

Root derivation. Ideal coefficient-level identities are not automatically survey
estimators. Work at fixed comoving wave number, with real cross covariance
C_AB=Re E[A B*], and assume the stated derivatives commute with this expectation.
This is an explicit regularity and ensemble premise; Gaussianity is unnecessary.
All coefficients below are evaluated on one common physical background and time.
Let S=Phi+Psi, T=Psi-Phi, W be the dust velocity divergence convention of
WORKING_v1, D=a^3K^2/(3H0^2)>0, and x,y,R as there. The undivided identity is

    D(S'+S)+R W+(D/2)(x S+y T)=0.

Correlate with W and take the real part:

    C_WW R+(D/2)C_SW x+(D/2)C_TW y=-D(C_S'W+C_SW).        (1)

Three independent rows reconstruct R,x,y without individual-mode phase ratios,
and without setting the free initial scalar covariance. The same rank and chart
restrictions remain. One may average over exact equal-K shells; broad-k windows
require their K-dependent D inside the known operator, not at a chosen center.

Where C_WW>0 and C_SW!=0 define

    P=-D C_SW/C_WW, r=C_TW/C_SW,
    M=-D(C_S'W+C_SW)/C_WW.

Then (1) reduces to the same normalized matrix as the coefficient inverse.
Jordan Euler implies, with gW=C_W'W/C_WW=(ln C_WW)'/2,

    r=2E^2 a^3[gW+2+h]/(3P)-1.

But the other required derivative is not supplied by P and gW alone. Since
(C_SW)'=C_S'W+C_SW' and D'=D,

    M=P'+P(2gW-eta), eta=C_SW'/C_SW.                    (2)

The common deterministic-transfer replacement eta=gW is an additional premise.
For example, the identity holds if W'=gW W for every realization, but arbitrary
free scalar/dust preparations need not have that property. In general
C_S'W is the derivative with respect to the first argument of an unequal-time
cross covariance C_SW(N1,N2), evaluated on the diagonal. Knowing its diagonal
and total derivative alone does not identify this separate partial derivative.

This is an input obligation rather than a claim that such information can never
be measured or modelled. The actual lensing projection, velocity estimator,
bias/stochasticity, unequal-time tomography and shared background calibration
require a physical inference model. Existing exposed E_G summary numbers are
not treated as these full ideal inputs. This extension prevents replacing a
coherent-mode derivation by a ratio of ensemble summaries without explanation.
