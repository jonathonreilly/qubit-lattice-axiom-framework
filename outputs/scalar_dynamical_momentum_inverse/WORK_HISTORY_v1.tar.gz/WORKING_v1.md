# Full rolling scalar/dust response and a momentum inverse

Root derivation, 2026-10-15. Working conditional support, not a formal audit or
an observational fit. No initial perturbation is selected by the inverse.

## Target and premises

Retire the supplied light/quasistatic perturbation closure from M13's physical
input map. Keep a supplied single canonical Einstein scalar, conformal dust,
flat rolling background and linear scalar perturbations. The full candidate
action, radial sector, scales, actual background and measurement map remain
conditional. Transverse perturbations are not included by silently setting
their observed amplitudes to zero: on the candidate radial background their
linear scalar stress and matter coupling vanish; this decoupling must be checked.

Use S=int sqrt(-gE)[Q R/2 -(partial chi)^2/2 -V(chi)] + Sm[A(chi)^2 gE],
Q>0, b=d ln A/dchi. Einstein proper time t; gE00=-(1+2phi),
gEij=aE^2(1-2phi)deltaij; absence of linear anisotropic stress gives equal
Einstein potentials. Dust covariant velocity ui=partial_i v, particle-number
contrast n, scalar perturbation X=delta chi and Z=delta chi_dot. p=kcom/aE.
All fields refer to one fixed comoving Fourier mode, kcom>0.

## Personally derived complete first-order system

Background, s=chi_dot:

    chi_dot=s; s_dot=-3Hs-Vchi-b rho;
    rho_dot=(-3H+b s)rho; H_dot=-(s^2+rho)/(2Q);
    3QH^2=s^2/2+V+rho; aE_dot=HaE.

Linear perturbations, deltaE=n+bX:

    phi_dot=-Hphi+(sX-rho v)/(2Q),
    X_dot=Z,
    Z_dot=-3HZ-(p^2+Vchichi+bchi rho)X
          +4s phi_dot-2(Vchi+b rho)phi-b rho(n+bX),
    n_dot=p^2 v+3phi_dot,
    v_dot=-phi-bX-bs v.

The separately checked 00 constraint is

    (2Qp^2-s^2)phi+rho n+sZ+(Vchi+b rho+3Hs)X-3Hrho v=0.

It is imposed on initial data, then its propagation is a check, not a repeated
constraint projection. X and Z remain independently free. The scalar equation
comes from delta(box chi-Vchi-b rho)=0, with
delta(box chi)=-Xddot-3HXdot-p^2X+2phi(sdot+3Hs)+4phidot s.

## Physical-frame map and exact momentum equation

dtJ=A dt; aJ=A aE; HJ=(H+bs)/A; F=Q/A^2.
Define metric gJ00=-(1+2Psi), gJij=aJ^2(1-2Phi)deltaij:

    Psi=phi+bX; Phi=phi-bX; S=Phi+Psi=2phi;
    D=Phi-Psi=-2bX; vJ=A v; deltaJ=n-3bX;
    K=kcom/aJ; N=ln aJ; W=K^2 vJ/HJ.

These give exact linear dust continuity deltaJ'=W+3Phi' and Euler
W'+(2+h)W=-K^2 Psi/HJ^2, h=HJ'/HJ. Primes follow the same comoving
mode. The Jordan chart must have A>0 and H+bs>0.

Let q=2Q b^2>0, x=F'/F, and rhoJ=rho/A^4. Transforming the Einstein
momentum constraint gives, with dots now Jordan time only in this equation,

    Sdot+HJ S= -rhoJ vJ/F +(Fdot/F)[D/(2q)-S/2].

No scalar mass or quasistatic limit occurs here. Define aJ=1 at the reference,
H0=HJ(reference), E=HJ/H0, and the ideal calibrated same-mode readouts

    P=-aJ^3 K^2 S/(3H0^2 W), r=(Psi-Phi)/S,
    P3=W'/W, M=P'+P P3=P(1+S'/S),
    R=rhoJ aJ^3/(3H0^2 F)>0.

Where denominators exist, Euler gives
r=2E^2 aJ^3(P3+2+h)/(3P)-1. The momentum equation gives the exact relation

    R=M+(P/2)x+(P r/2)y, y=x/q.                         (1)

At one epoch, three modes with invertible rows [1,-P_i/2,-P_i r_i/2]
determine (R,x,y) from M_i. If y!=0 and x/y>0, q=x/y. A fourth mode is a
reserved no-refit equation. The inverse uses no initial matter contrast or
scalar-wave data. It needs observed rank, calibrated common time/modes and
derivatives; those are not guaranteed by an action. The frozen point x=y=0
does not determine q by this relation. R'/R=-x is an additional whole-history
consistency requirement, not enforced by three isolated rows.

For the supplied radial candidate, beta=(1-k)(1+3k)/4 in (1/4,1/3),
F>Fc>0, q=beta(F-Fc)/(F-3beta Fc), and
kappa=3H0^2 Fc/(rhoJ aJ^3)>0 is constant. Thus

    q/beta + R(1-3q)kappa=1.                           (2)

Two nondegenerate epochs solve linearly for (1/beta,kappa); later epochs
must test the same pair. This replaces r=q by an exact momentum reconstruction.
It does not derive a unique fundamental action or absolute normalization.

## Candidate forward implementation, to be checked

Keep the given radial u action with kinetic -QK(u)(partial u)^2,
chi_u=sqrt(2QK), V=2Q Hv^2 U, b=(ln A)_u/chi_u. Use u as background
coordinate without numerically integrating the canonical field chart:

    udot=v_u;
    v_u_dot=-3Hv_u-K_u v_u^2/(2K)-Hv^2 U_u/K
            -(ln A)_u rho/(2QK).

Derivatives with respect to chi mean chi_u^-1 d/du. Algebraically computing H
from Friedmann does not substitute for checking Hdot and linear constraints.
The working system should be tested by an independent derivation before large
downstream use and by independent numerical evolution, including strong free
scalar modes and scales where r differs materially from q.

## Prior results and unresolved items

Current main bbada1fe09b2d10d610560864d86b68c24a59713 searched and refreshed.
The earlier exact vacuum finite-mode inverse retains free scalar preparation
but freezes the background at de Sitter and uses a prescribed first-order
cold source. The earlier material inverse is a frozen local NR patch. Neither
contains (1) on a rolling gravitating dust background. Both complete notes
were read. Their mechanisms remain prior art, not rediscovered novelty.

The vacuum note does not explicitly attach its Phi_J/Psi_J labels to time and
spatial metric slots. Its displayed pair is compatible with the opposite
symbol naming to this note. This is not yet an established sign defect and no
older source is modified. Equations here are tied to explicit metric slots.

Actual ACT/BOSS E_G summaries remain exposed development context. They do not
supply these continuous same-mode histories. No survey likelihood or empirical
calibration is imported from them. Need full geometry/sign check, constraint
propagation proof, rank/zero domain analysis and controlled synthetic examples.
