"""One-time canonical consolidation; all working versions remain unchanged."""
from pathlib import Path
import textwrap
root=Path.cwd();d=root/'.claude/science/physics-loops/observations-backward-24h-20261014/dynamical_response'
scripts=root/'scripts'
f=(d/'forward_v1.py').read_text().split("if __name__=='__main__':")[0]
f=f.replace('def experiment(case,protocol):\n','def experiment(case,protocol):\n    if protocol["units"] != {"Q":1.0,"Hv":1.0} or protocol["inverse_modes"] != [0,1,2] or protocol["reserved_mode"] != 3:\n        raise ValueError("This fixed numerical protocol is specialized to Q=Hv=1 and its declared four modes")\n')
f=f.replace("'H_J':HJ,'H0_J'", "'H_J':HJ,'h_J':h,'H0_J'")
(scripts/'scalar_dynamical_forward.py').write_text(f)
g=(d/'geometry_v1.py').read_text();body=g[g.index('t,x,y,z,ep,k='):g.index("out=Path(__file__)")]
(scripts/'scalar_dynamical_geometry.py').write_text('"""Direct first-order metric geometry; no forward-solver imports."""\nimport sympy as s\n\ndef checks():\n'+textwrap.indent(body,'    ')+'    return rows\n')
p=(d/'postprocess_v1.py').read_text();a=p.index('rows=[]');end=p.index('# Numerical potential inference')
exact=p[a:end]
potential=p[p.index("potentials=[]",end):p.index("result={'counts'",end)]
(scripts/'scalar_dynamical_extensions.py').write_text('"""Exact covariance/background identities and conditional potential diagnostics."""\nimport math\nimport sympy as s\nimport numpy as np\n\ndef checks():\n'+textwrap.indent(exact,'    ')+'    return rows\n\ndef potential_diagnostics(old):\n'+textwrap.indent(potential,'    ')+'    return potentials\n')
x=(d/'domains_v1.py').read_text().split("if __name__=='__main__':")[0]
x=x.replace("'positive chart certified'", "'positive coefficients certified'").replace("'positive chart inconclusive'", "'positive coefficients inconclusive'")
x=x.replace('This does not certify observational input uncertainties or floating ODE error.', 'This does not certify observational input uncertainties, observable denominators, or floating ODE error.\nCoefficient envelopes presume already admitted normalized physical inputs.')
(scripts/'scalar_dynamical_domains.py').write_text(x)
x=(d/'covariance_lift_v1.py').read_text().split("if __name__=='__main__':")[0].replace('from domains_v1 import rational','from scalar_dynamical_domains import rational')
(scripts/'scalar_dynamical_covariance.py').write_text(x)
