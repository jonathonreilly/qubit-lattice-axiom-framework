"""Actual current-source damage controls, each in an isolated temporary tree."""
from pathlib import Path
import json,hashlib,shutil,tempfile,subprocess,sys,os,datetime
root=Path.cwd();d=root/'.claude/science/physics-loops/observations-backward-24h-20261014/dynamical_response';out=d/'mutation_v3';out.mkdir(exist_ok=False)
mutations=[
 ('constraint_scalar_momentum','scalar_dynamical_forward.py','pd=-H*phi+(s*X-rho*v)/(2*Q)','pd=-H*phi+(s*X+rho*v)/(2*Q)'),
 ('scalar_number_mass','scalar_dynamical_forward.py','-b*rho*(n+b*X)','-b*rho*n'),
 ('matter_lapse_source','scalar_dynamical_forward.py','-2*(V1+b*rho)*phi','-2*V1*phi'),
 ('physical_velocity_map','scalar_dynamical_forward.py','dt(A*v)/A+Psi','dt(A*v)/A-Psi'),
 ('momentum_conformal_sign','scalar_dynamical_forward.py','D=-2*b*X','D=2*b*X'),
 ('full_forward_force','scalar_dynamical_forward.py','-phi-c[\'b\']*X-c[\'b\']*ss*v','-phi+c[\'b\']*X-c[\'b\']*ss*v'),
 ('numerical_inverse_ratio','scalar_dynamical_forward.py','qi=x/yy','qi=yy/x'),
 ('Euler_slip_factor','scalar_dynamical_forward.py','robs=2*(HJ/H0)**2','robs=(HJ/H0)**2'),
 ('geometry_lapse','scalar_dynamical_geometry.py','-(1+2*ep*f*wave)','-(1+ep*f*wave)'),
 ('geometry_wave_metric','scalar_dynamical_geometry.py','sqrtg=a**3*(1-2*ep*f*wave)','sqrtg=a**3*(1-ep*f*wave)'),
 ('candidate_epoch_determinant','scalar_dynamical_extensions.py','-(q1-q2)/kap','+(q1-q2)/kap'),
 ('single_time_leg_factor','scalar_dynamical_extensions.py','MM-PPd-PP*(2*g-eta)','MM-PPd-PP*(g-eta)'),
 ('background_kinetic_term','scalar_dynamical_extensions.py','omega=(1/q-3)/2','omega=(1/q+3)/2'),
 ('potential_decoder_normalization','scalar_dynamical_extensions.py',"'target':vp*CC/2","'target':vp*CC"),
 ('potential_shape_basis','scalar_dynamical_extensions.py','U1=(1+st)*uu*uu/(2*FF**2)','U1=(1+st)*uu*uu/(FF**2)'),
 ('domain_zero_q','scalar_dynamical_domains.py','if q <= 0:','if q < 0:'),
 ('error_norm_denominator','scalar_dynamical_domains.py','/(1-eta)','/(1+eta)'),
 ('error_ratio_denominator','scalar_dynamical_domains.py','/(abs(zhat[2])-eps)','/(abs(zhat[2])+eps)'),
 ('overbroad_certificate_label','scalar_dynamical_domains.py',"reason='positive coefficients certified' if ok", "reason='positive chart certified' if ok"),
 ('covariance_row_time_leg','scalar_dynamical_covariance.py','return [SS/2,-SS/2-SVp+(h-1)*SV','return [SS/2,-SS/2+SVp+(h-1)*SV'),
 ('covariance_square_gate','scalar_dynamical_covariance.py','if z3!=y*y or z5!=(z4+x*y/2)*y:', 'if z5!=(z4+x*y/2)*y:'),
 ('covariance_product_gate','scalar_dynamical_covariance.py','if z3!=y*y or z5!=(z4+x*y/2)*y:', 'if z3!=y*y:'),
 ('covariance_PSD_gate','scalar_dynamical_covariance.py','if SS<0 or VV<0 or SS*VV-SV**2<0:', 'if False:'),
 ('covariance_density_recovery','scalar_dynamical_covariance.py','R=(z4+x*y/2)/J','R=(z4-x*y/2)/J'),
]
files=[*sorted((root/'scripts').glob('scalar_dynamical*.py')),root/'docs/SCALAR_DYNAMICAL_MOMENTUM_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-15.md',d/'FORWARD_PROTOCOL_v1.json',d/'NO_GO_DISCIPLINE_CHECKLIST.md']
sourcehash={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
(out/'SOURCE_FREEZE.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':sourcehash},indent=2)+'\n')
# A mutation rejection is meaningful only after the same source baseline passes.
baseproc=subprocess.run([sys.executable,str(root/'scripts/scalar_dynamical_momentum_inverse_check.py'),'--output-dir',str(out/'baseline')],cwd=root,capture_output=True,text=True,timeout=180,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
(out/'BASELINE.stdout').write_text(baseproc.stdout);(out/'BASELINE.stderr').write_text(baseproc.stderr)
if baseproc.returncode:raise RuntimeError('Unmutated baseline failed; no mutation runs authorized by this harness')
base=json.loads((out/'baseline/RESULTS_v1.json').read_text())
assert base['counts']['failed']==0
results=[]
for name,filename,old,new in mutations:
 src=(root/'scripts'/filename).read_text();count=src.count(old)
 if count!=1:
  row={'name':name,'status':'selector_setup_failure','matches':count};results.append(row);print(row,flush=True);continue
 changed=src.replace(old,new);(out/(name+'.source')).write_text(changed)
 with tempfile.TemporaryDirectory(prefix='scalar-momentum-mutation-') as td:
  tmp=Path(td)
  for f in files:
   dst=tmp/f.relative_to(root);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dst)
  (tmp/'scripts'/filename).write_text(changed)
  proc=subprocess.run([sys.executable,str(tmp/'scripts/scalar_dynamical_momentum_inverse_check.py')],cwd=tmp,capture_output=True,text=True,timeout=20,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
  (out/(name+'.stdout')).write_text(proc.stdout);(out/(name+'.stderr')).write_text(proc.stderr)
  rp=tmp/'outputs/scalar_dynamical_momentum_inverse/RESULTS_v1.json'
  data=json.loads(rp.read_text()) if rp.exists() else None
  failed=[r['name'] for r in data['checks'] if not r['passed']] if data else []
  status='failed_checks' if proc.returncode and failed else 'exception' if proc.returncode else 'survived'
  row={'name':name,'source':filename,'old':old,'new':new,'status':status,'exit_code':proc.returncode,'failed_checks':failed,'source_sha256':hashlib.sha256(changed.encode()).hexdigest()};results.append(row);print(json.dumps(row),flush=True)
(out/'RESULTS.json').write_text(json.dumps({'source_sha256':sourcehash,'mutations':results,'counts':{s:sum(r['status']==s for r in results) for s in ['failed_checks','exception','survived','selector_setup_failure']}},indent=2)+'\n')
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==sha for p,sha in sourcehash.items())
raise SystemExit(any(r['status'] in ['survived','selector_setup_failure'] for r in results))
