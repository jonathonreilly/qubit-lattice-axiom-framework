#!/usr/local/bin/python3
"""Only affected canonical source checks; no aggregate/ODE invocation."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import hashlib,json,datetime,ast,importlib.util,math
import sympy as s
p=Path(__file__).resolve().parent
checks=[]
def ck(n,v,**kw):checks.append({'name':n,'passed':bool(v),**kw})
def load(name,file):
 spec=importlib.util.spec_from_file_location(name,p/file);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
D=load('scalar_dynamical_domains','CANONICAL_EXPOSURE_v1__scalar_dynamical_domains.py')
C=load('copied_covariance_v2','CANONICAL_EXPOSURE_v2__scalar_dynamical_covariance.py')
E=load('copied_extensions_v2','CANONICAL_EXPOSURE_v2__scalar_dynamical_extensions.py')
def funcs(filename):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse((p/filename).read_text()).body if isinstance(n,ast.FunctionDef)}
for family,names in [('covariance',['lift_row','inverse']),('extensions',['checks','background_checks'])]:
 old=funcs('CANONICAL_EXPOSURE_v1__scalar_dynamical_'+family+'.py');new=funcs('CANONICAL_EXPOSURE_v2__scalar_dynamical_'+family+'.py')
 for name in names:ck('unchanged_'+family+'_'+name,old[name]==new[name])
# Independently evaluated exact event in the new decoder control; no ODE.
k=s.Rational(1,6);beta=(1-k)*(1+3*k)/4;ss=(1+k)/(k*(1-3*k));ex=s.Integer(2);jj=1+(1-3*beta)*ss*ex;qq=beta/jj
u=s.log(ex)/(2*s.sqrt(beta));ff=1+ss*ex;cc=(1+ss)*ex/ff
EE=s.Rational(13,10);xx=s.Rational(3,50);RR=s.Rational(2,5);omega=(1/qq-3)/2
vpot=3*EE**2*(1+xx)-omega*EE**2*xx**2/2-3*RR
expected={'u_inferred':u,'U0':s.Rational(3,2)+3*ss*(ex-1)**2/(2*ff**2),'U1':(1+ss)*u*u/(2*ff**2),'target':vpot*cc/2}
got=E.potential_readout(float(beta),float(qq),float(RR),float(xx),float(EE),1.0)
errors={n:abs(got[n]-float(v)) for n,v in expected.items()}
ck('extracted_potential_on_exact_candidate_event',max(errors.values())<1e-13,exact={'beta':str(beta),'s':str(ss),'q':str(qq),'C':str(cc)},errors=errors)
# Recreate the changed negative-covariance fixture; prove it is not accidentally a monomial failure.
x=s.Rational(3,50);y=s.Rational(2,5);R=s.Rational(4,5);J=s.Rational(7,3);h=s.Rational(-2,7)
covs=[s.eye(3)]
for ij,change in [((0,0),s.Rational(1,2)),((0,1),s.Rational(1,4)),((0,2),s.Rational(1,5)),((1,2),s.Rational(1,6))]:
 mat=s.eye(3);i,j=ij;mat[i,j]+=change
 if i!=j:mat[j,i]+=change
 covs.append(mat)
covs[0]=s.Matrix([[1,2,0],[2,1,0],[0,0,1]])
data=[];rows=[];rhs=[]
for mat in covs:
 A,B,V,ST,VT=mat[0,0],mat[0,1],mat[1,1],mat[0,2],mat[1,2]
 Ap=-(2+x)*A-y*ST-2*J*R*B
 Bp=(h-1-x/2)*B-A/2-ST/2-y*VT/2-J*R*V
 Vp=2*h*V-B-VT
 data.append([A,B,V,Ap,Bp,Vp]);rows.append([A/2,-A/2-Bp+(h-1)*B,Vp/2+B/2-h*V,B,-V]);rhs.append(-Ap/2-A)
L=s.Matrix(rows);sol=L.inv()*s.Matrix(rhs);target=s.Matrix([x,y,y*y,J*R-x*y/2,J*R*y])
ck('negative_PSD_fixture_otherwise_valid_lift',sol==target and L.det()!=0,determinant=str(L.det()),negative_principal_minor=str(covs[0][:2,:2].det()))
try:C.inverse(data,h,J)
except ValueError as err:ck('negative_PSD_fixture_hits_intended_gate',str(err)=='equal-time covariance must be positive semidefinite',exception=str(err))
else:ck('negative_PSD_fixture_hits_intended_gate',False)
record={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Post-exposure affected source/API controls only; no aggregate/ODE or new data','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':checks,'counts':{'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks)}}
f=p/'CANONICAL_DELTA_RESULTS_v2.json'
if f.exists():raise RuntimeError('immutable output exists')
f.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2));raise SystemExit(record['counts']['failed']!=0)
