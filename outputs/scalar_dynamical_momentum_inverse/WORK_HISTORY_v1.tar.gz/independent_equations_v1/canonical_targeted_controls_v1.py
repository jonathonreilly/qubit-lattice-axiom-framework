#!/usr/local/bin/python3
"""Post-exposure canonical algebra/API correspondence, no aggregate or ODE."""
import sys
sys.dont_write_bytecode=True
import importlib.util,hashlib,json,datetime,ast,difflib
from pathlib import Path
import sympy as s
p=Path(__file__).resolve().parent

def load(name,file):
 spec=importlib.util.spec_from_file_location(name,p/file);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
D=load('scalar_dynamical_domains','CANONICAL_EXPOSURE_v1__scalar_dynamical_domains.py')
C=load('canonical_covariance_copy','CANONICAL_EXPOSURE_v1__scalar_dynamical_covariance.py')
checks=[]
def ck(name,value,**details):checks.append({'name':name,'passed':bool(value),**details})
def refuse(name,fn):
 try:fn()
 except ValueError as ex:ck(name,True,exception=str(ex))
 else:ck(name,False)
x,y,R,J,h=s.symbols('x y R J h',real=True)
A,B,V,Ap,Bp,Vp=s.symbols('A B V Ap Bp Vp',real=True)
alpha=1+(x-y)/2;gamma=J*R+h*y
z_author=s.Matrix([x,y,y*y,J*R-x*y/2,J*R*y])
z_ind=s.Matrix([alpha,y,y*y,gamma-alpha*y,gamma*y])
row_author=s.Matrix([[A/2,-A/2-Bp+(h-1)*B,Vp/2+B/2-h*V,B,-V]])
row_ind=s.Matrix([[A,-Bp,Vp/2,B,-V]])
ck('independent_and_author_lifts_same_residual',s.expand((row_author*z_author)[0]+Ap/2+A-(row_ind*z_ind)[0]-Ap/2)==0)
ST,VT=s.symbols('ST VT',real=True)
subs={Ap:-(2+x)*A-y*ST-2*J*R*B,Bp:(h-1-x/2)*B-A/2-ST/2-y*VT/2-J*R*V,Vp:2*h*V-B-VT}
physical=row_author.subs(subs)
ck('canonical_covariance_column_determinant',s.factor(physical.jacobian([A,B,V,ST,VT]).det())==s.Rational(1,8))

def fixture(xx,yy,rr,jj=s.Rational(7,3),hh=s.Rational(-2,7)):
 aa=1+(xx-yy)/2;gg=jj*rr+hh*yy;data=[]
 for r,w in [(-1,0),(-2,0),(-3,0),(-1,1),(-2,1)]:
  t=s.Matrix([r,1,w]);cov=t*t.T+s.eye(3)/7
  a,b,v,u,z=cov[0,0],cov[0,1],cov[1,1],cov[0,2],cov[1,2]
  data.append([a,b,v,2*yy*u-2*aa*a-2*gg*b,u+yy*z-aa*b-gg*v,2*z])
 return data
xx=s.Rational(3,50);yy=s.Rational(2,5);rr=s.Rational(4,5);jj=s.Rational(7,3);hh=s.Rational(-2,7)
data=fixture(xx,yy,rr);got=C.inverse(data,hh,jj)
ck('canonical_five_row_on_independent_covariance_witness',all(got[k]==v for k,v in [('x',xx),('y',yy),('R',rr),('q',s.Rational(3,20))]))
ck('independent_covariance_witness_rank',got['determinant']==s.Rational(8,7),determinant=str(got['determinant']))
for name,par in [('zero_y', (0,0,rr)),('negative_q',(-xx,yy,rr)),('zero_R',(xx,yy,0)),('negative_R',(xx,yy,-rr))]:
 refuse('canonical_covariance_'+name,lambda par=par:C.inverse(fixture(*par),hh,jj))
for at in [2,4]:
 badz=s.Matrix(got['lift']);badz[at]+=s.Rational(1,100);bad=[]
 for d in data:
  row,_=C.lift_row(d,hh);new=list(d);new[3]=-2*((s.Matrix([row])*badz)[0]+d[0]);bad.append(new)
 refuse('canonical_monomial_'+str(at+1)+'_required',lambda bad=bad:C.inverse(bad,hh,jj))
refuse('canonical_covariance_nonfinite_h',lambda:C.inverse(data,float('nan'),jj))
refuse('canonical_covariance_nonpositive_J',lambda:C.inverse(data,hh,0))
refuse('canonical_covariance_rank_gate',lambda:C.inverse([data[0]]*5,hh,jj))
refuse('canonical_covariance_nonfinite_moment',lambda:C.inverse([[float('inf')]+data[0][1:]]+data[1:],hh,jj))
P=[s.Rational(1,10**6),s.Integer(1),s.Integer(2)];r=[s.Integer(0),s.Integer(1),s.Integer(-1)]
M=[1-a/s.Integer(20)-a*b/s.Integer(10) for a,b in zip(P,r)]
env=D.error_envelope(P,r,M,[s.Rational(1,500000),0,0],[0]*3,[0]*3)
ck('P_crossing_certificate_is_explicitly_coefficients',env['certified'] and env['reason']=='positive coefficients certified' and P[0]-s.Rational(1,500000)<0)
# AST equality for all unchanged API functions; error_envelope differs only in terminal label strings.
old=ast.parse((p/'AUTHOR_domains_v1.py').read_text());new=ast.parse((p/'CANONICAL_EXPOSURE_v1__scalar_dynamical_domains.py').read_text())
funcs=lambda tree:{n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
a,b=funcs(old),funcs(new)
for name in ['rational','vector3','system','inverse','norm_inf']:
 ck('domain_API_AST_unchanged_'+name,ast.dump(a[name],include_attributes=False)==ast.dump(b[name],include_attributes=False))
class Labels(ast.NodeTransformer):
 def visit_Constant(self,node):
  if isinstance(node.value,str):
   return ast.copy_location(ast.Constant(node.value.replace('positive chart','positive coefficients')),node)
  return node
old_error=Labels().visit(a['error_envelope'])
ck('error_formula_AST_unchanged_after_label_map',ast.dump(old_error,include_attributes=False)==ast.dump(b['error_envelope'],include_attributes=False))
record={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Post-exposure targeted algebra/API checks; imported immutable copied canonical helpers, no checks()/controls()/ODE run','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':checks,'counts':{'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks)}}
f=p/'CANONICAL_TARGETED_RESULTS_v1.json'
if f.exists():raise RuntimeError('immutable result exists')
f.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2));raise SystemExit(record['counts']['failed']!=0)
