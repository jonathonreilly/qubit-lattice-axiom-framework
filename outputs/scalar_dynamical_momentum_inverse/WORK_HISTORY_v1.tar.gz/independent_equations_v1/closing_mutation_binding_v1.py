#!/usr/local/bin/python3
"""Read-only source/log binding checks; never imports or runs science/harnesses."""
from pathlib import Path
import ast,hashlib,json,datetime,collections
root=Path.cwd();base=root/'.claude/science/physics-loops/observations-backward-24h-20261014/dynamical_response';out=base/'independent_equations_v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identities={};issues=[]
def rd(path):
 p=Path(path);data=p.read_bytes();identities[str(p.relative_to(root))]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)};return data.decode()
def js(path):return json.loads(rd(path))
def ensure(ok,msg):
 if not ok:issues.append(msg)
def payload(text):
 if not text.strip():return None
 start=text.find('{');return json.loads(text[start:]) if start>=0 else None
# Build exact baseline source bank from previous immutable review snapshots, plus final current files.
sourcebank={}
for p in out.iterdir():
 if p.is_file() and (p.name.startswith('CANONICAL_EXPOSURE') or p.name in ['CANONICAL_DOMAINS_SHARP_SOURCE_v1.py','AUTHOR_DOMAIN_SHARP_FIXTURE_FAILED_v1.source']):
  b=p.read_bytes();sourcebank[hashlib.sha256(b).hexdigest()]=b.decode()
freeze=js(base/'CANONICAL_SOURCE_FREEZE_v2.json')
for name,info in freeze['files'].items():
 p=Path(name) if name.startswith('/') else root/name
 raw=rd(p);h=hashlib.sha256(raw.encode()).hexdigest();ensure(h==info['sha256'],'final freeze mismatch '+name);ensure(len(raw.encode())==info['bytes'],'final byte count '+name);sourcebank[h]=raw
versions={}
for ver in ['v1','v2','v3']:
 folder=base/('mutation_'+ver);harness_path=base/('mutation_check_'+ver+'.py');harness=rd(harness_path);tree=ast.parse(harness)
 assignments=[n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='mutations' for t in n.targets)]
 specs=ast.literal_eval(assignments[0].value);specdict={r[0]:r for r in specs}
 record=js(folder/'RESULTS.json');sf=js(folder/'SOURCE_FREEZE.json');ensure(sf['files']==record['source_sha256'],ver+' source manifest mismatch')
 ensure(len(specs)==24 and len(specdict)==24,ver+' specs not 24 unique')
 rows=record['mutations'];ensure(len(rows)==24 and {r['name'] for r in rows}==set(specdict),ver+' result names missing/repeated')
 ensure(len({r['name'] for r in rows})==24,ver+' duplicate result names')
 counts=dict(collections.Counter(r['status'] for r in rows));ensure(all(record['counts'][k]==counts.get(k,0) for k in record['counts']),ver+' counts mismatch')
 boundrows=[]
 for r in rows:
  name=r['name'];_,filename,old,new=specdict[name];srcpath='scripts/'+filename;basehash=sf['files'][srcpath];src=sourcebank.get(basehash)
  ensure(src is not None,ver+' missing baseline bytes '+srcpath)
  if src is None:continue
  matches=src.count(old)
  if r['status']=='selector_setup_failure':
   ensure(matches==r['matches'] and matches!=1,ver+' selector count mismatch '+name)
   boundrows.append({'name':name,'status':r['status'],'matches':matches,'baseline_sha256':basehash});continue
  ensure(matches==1,ver+' selector not unique '+name)
  ensure((filename,old,new)==(r['source'],r['old'],r['new']),ver+' pattern differs '+name)
  mutated=rd(folder/(name+'.source'));expected=src.replace(old,new)
  ensure(mutated==expected,ver+' mutant is not exact specified replacement '+name)
  mh=hashlib.sha256(mutated.encode()).hexdigest();ensure(mh==r['source_sha256'],ver+' mutant hash mismatch '+name)
  stdout=rd(folder/(name+'.stdout'));stderr=rd(folder/(name+'.stderr'));summary=payload(stdout)
  outcome={'name':name,'status':r['status'],'baseline_sha256':basehash,'mutant_sha256':mh,'unique_selector':matches,'exit_code':r['exit_code'],'stdout_summary_present':summary is not None,'failed_checks':r['failed_checks']}
  if r['status']=='failed_checks':
   ensure(r['exit_code']!=0 and summary is not None,ver+' no failure receipt '+name)
   if summary is not None:
    fn=[v['name'] for v in summary['failed_checks']];ensure(fn==r['failed_checks'] and fn,ver+' failed names mismatch '+name)
    ensure(summary['counts']['failed']==len(fn),ver+' failed count mismatch '+name)
    ensure(summary['input_sha256'][srcpath]==mh,ver+' output lacks mutant source binding '+name)
    unchanged={k:v for k,v in sf['files'].items() if k!=srcpath and k!='scripts/scalar_dynamical_momentum_inverse_check.py'}
    ensure(all(summary['input_sha256'][k]==v for k,v in unchanged.items()),ver+' other source binding changed '+name)
    ensure(summary['primary_sha256']==sf['files']['scripts/scalar_dynamical_momentum_inverse_check.py'],ver+' primary mismatch '+name)
   ensure(not stderr.strip(),ver+' unexpected failure stderr '+name)
  elif r['status']=='survived':
   ensure(r['exit_code']==0 and summary is not None and summary['counts']['failed']==0 and not summary['failed_checks'],ver+' survival outcome mismatch '+name)
   ensure(not stderr.strip(),ver+' survivor stderr '+name)
  elif r['status']=='exception':
   ensure(r['exit_code']!=0 and not r['failed_checks'] and 'Traceback (most recent call last):' in stderr,ver+' exception receipt mismatch '+name)
   ensure(not any(t in stderr for t in ['ModuleNotFoundError','ImportError','SyntaxError']),ver+' exception is setup '+name)
   outcome['exception_tail']=stderr.strip().splitlines()[-1]
  else:ensure(False,ver+' unknown status '+name)
  boundrows.append(outcome)
 versions[ver]={'harness_sha256':identities[str(harness_path.relative_to(root))]['sha256'],'counts':record['counts'],'rows':boundrows}
# v3 baseline is independently recorded, checked before mutation loop by the read harness.
base_summary=js(base/'mutation_v3/baseline/SUMMARY_v1.json');base_result=js(base/'mutation_v3/baseline/RESULTS_v1.json');base_stdout=payload(rd(base/'mutation_v3/BASELINE.stdout'));base_stderr=rd(base/'mutation_v3/BASELINE.stderr');v3=js(base/'mutation_v3/SOURCE_FREEZE.json')['files']
ensure(base_summary==base_stdout,'v3 baseline stdout/summary mismatch');ensure(base_summary['counts']=={'passed':85,'failed':0},'v3 baseline count');ensure(not base_stderr.strip(),'v3 baseline stderr');ensure(not base_summary['failed_checks'],'v3 baseline has failures')
ensure(base_result['counts']==base_summary['counts'] and len(base_result['checks'])==85,'v3 baseline result count');ensure(all(c['passed'] for c in base_result['checks']),'v3 baseline false check')
ensure(base_summary['primary_sha256']==v3['scripts/scalar_dynamical_momentum_inverse_check.py'],'v3 baseline primary')
ensure(all(base_summary['input_sha256'][k]==v for k,v in v3.items() if k!='scripts/scalar_dynamical_momentum_inverse_check.py'),'v3 baseline input hashes')
# Final note/cache revision differs from mutation baseline only by the reviewed history paragraph.
final_summary=js(root/'outputs/scalar_dynamical_momentum_inverse/SUMMARY_v1.json');final_result=js(root/'outputs/scalar_dynamical_momentum_inverse/RESULTS_v1.json');cache=rd(Path(freeze['cache']))
ensure(final_summary['counts']=={'passed':85,'failed':0} and final_result['counts']==final_summary['counts'],'final counts');ensure(not final_summary['failed_checks'],'final failures')
ensure(all(c['passed'] for c in final_result['checks']) and len(final_result['checks'])==85,'final result check content')
ensure(payload(cache.split('----- stdout -----\n',1)[1].split('----- stderr -----',1)[0])==final_summary,'cache/summary mismatch')
ensure(freeze['execution']['exit_code']==0 and freeze['execution']['elapsed_sec']<freeze['execution']['timeout_sec']==180,'final execution receipt');ensure(freeze['cache_status']=='fresh','final fresh receipt')
ensure('exit_code: 0\n' in cache and 'timeout_sec: 180\n' in cache and 'status: ok\n' in cache,'final cache headers')
ensure(payload(freeze['execution']['stdout'])==final_summary,'execution stdout/final summary mismatch')
for k,v in final_summary['input_sha256'].items():ensure(sha(root/k)==v,'current final input differs '+k)
ensure(sha(root/'scripts/scalar_dynamical_momentum_inverse_check.py')==final_summary['primary_sha256'],'current primary differs')
for k,v in v3.items():
 if k.startswith('scripts/'):ensure(sha(root/k)==v,'scientific source differs from mutation '+k)
correction=js(base/'MUTATION_V2_COMPLETION_CORRECTION.json');interrupt=js(base/'MUTATION_V2_INTERRUPTED.json')
ensure(correction['original_baseline']['failed']==1 and correction['original_baseline']['failure']=='sharp_ratio_error','v2 baseline failure correction missing')
# Preserve compact receipts, not copied bulk science/observations.
for rel in ['CANONICAL_SOURCE_FREEZE_v2.json','mutation_check_v3.py','MUTATION_V2_INTERRUPTED.json','MUTATION_V2_COMPLETION_CORRECTION.json','mutation_v1/RESULTS.json','mutation_v2/RESULTS.json','mutation_v3/RESULTS.json','mutation_v3/SOURCE_FREEZE.json']:
 p=base/rel;dest=out/('CLOSING_EVIDENCE_v1__'+rel.replace('/','__'))
 if dest.exists():raise RuntimeError('immutable snapshot exists '+str(dest))
 dest.write_bytes(p.read_bytes())
receipt={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only full saved mutation source/pattern/log identity binding, no harness or science execution','versions':versions,'v2_disposition':'INVALID: baseline failure, completion correction read; no rejections counted','v3_baseline':{'counts':base_summary['counts'],'stdout_summary_equal':base_summary==base_stdout,'stderr_empty':not base_stderr.strip()},'final_source':{'note_sha256':sha(root/'docs/SCALAR_DYNAMICAL_MOMENTUM_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-15.md'),'primary_sha256':final_summary['primary_sha256'],'counts':final_summary['counts'],'cache_sha256':sha(Path(freeze['cache'])),'cache_status_from_receipt':freeze['cache_status'],'elapsed_sec':freeze['execution']['elapsed_sec'],'timeout_sec':freeze['execution']['timeout_sec']},'issues':issues,'inspected_file_identities':identities}
f=out/'CLOSING_MUTATION_BINDING_v1.json'
if f.exists():raise RuntimeError('immutable receipt exists')
f.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'versions':{v:x['counts'] for v,x in versions.items()},'v3_baseline':receipt['v3_baseline'],'final_source':receipt['final_source'],'issues':issues,'inspected_files':len(identities)},indent=2));raise SystemExit(bool(issues))
