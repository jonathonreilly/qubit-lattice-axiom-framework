#!/usr/local/bin/python3
"""Focused post-exposure API/covariance probes; no aggregate or physical data."""
import sys
sys.dont_write_bytecode=True
import importlib.util,hashlib,json,datetime
from pathlib import Path
import sympy as s
p=Path(__file__).resolve().parent
src=p/'AUTHOR_domains_v1.py'
spec=importlib.util.spec_from_file_location('copied_domain_api',src);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
records=[]
P=[s.Rational(1,10**6),s.S.One,s.Integer(2)];r=[s.S.Zero,s.S.One,-s.S.One]
state=[s.S.One,s.Rational(1,10),s.Rational(1,5)]
M=[state[0]-a*state[1]/2-a*b*state[2]/2 for a,b in zip(P,r)]
env=m.error_envelope(P,r,M,[s.Rational(2,10**6),0,0],[0,0,0],[0,0,0])
records.append({'name':'coefficient_certificate_does_not_exclude_true_P_zero','certified':env['certified'],'P_hat':list(map(str,P)),'eP':['1/500000','0','0'],'zero_first_P_is_within_error':True,'envelope':{k:str(v) for k,v in env.items()},'meaning':'Correct R/q perturbation certificate conditional on valid input chart; not certification that every original observable denominator remains nonzero.'})
# Formula identities at a fixed epoch; all covariance components are real.
D,C,Cp,Cp1,Cp2,V,Vp=s.symbols('D C Cp Cp1 Cp2 V Vp',nonzero=True,real=True)
Pdef=-D*C/V;g=Vp/(2*V);eta=Cp2/C
Pd=s.diff(Pdef,D)*D+s.diff(Pdef,C)*(Cp1+Cp2)+s.diff(Pdef,V)*Vp
Mdef=-D*(Cp1+C)/V
records.append({'name':'statistical_M_separate_time_leg_identity','pass':s.simplify(Mdef-Pd-Pdef*(2*g-eta))==0})
# Independent centered unit variance amplitudes xi,zeta. W=xi, W'=zeta, S=xi+zeta.
W=s.Matrix([1,0]);Wp=s.Matrix([0,1]);S=s.Matrix([1,1]);cov=lambda a,b:(a.T*b)[0]
records.append({'name':'eta_need_not_equal_gW','pass':cov(S,Wp)/cov(S,W)==1 and cov(Wp,W)/cov(W,W)==0,'eta':'1','gW':'0','ensemble':'Two independent centered unit-variance real amplitudes; no Gaussianity required.'})
# Equal-time C_SW and its total derivative do not fix its first time leg.
Sa=s.Matrix([2,3]);Wpa=Wp
Sb=s.Matrix([3,3]);Wpb=s.zeros(2,1)
records.append({'name':'same_diagonal_derivative_different_first_leg','pass':cov(Sa,W)+cov(S,Wpa)==cov(Sb,W)+cov(S,Wpb) and cov(Sa,W)!=cov(Sb,W),'case_A_first_leg':str(cov(Sa,W)),'case_B_first_leg':str(cov(Sb,W)),'same_total_derivative':str(cov(Sa,W)+cov(S,Wpa)),'same_W_auto_derivative':str(2*cov(W,Wpa))})
for rcd in records:
 if 'pass' in rcd:rcd['pass']=bool(rcd['pass'])
out={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'POST_EXPOSURE focused mathematical source probes; no author checks() or ODE invocation','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'records':records}
f=p/'EXTENSION_PROBE_RESULT_v1.json'
if f.exists():raise RuntimeError('immutable result exists')
f.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
