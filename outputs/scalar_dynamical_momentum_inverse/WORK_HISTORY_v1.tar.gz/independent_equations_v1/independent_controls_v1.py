#!/usr/local/bin/python3
"""Independent exact controls; authored before M14 root-source exposure."""
from pathlib import Path
import hashlib, json, datetime
import sympy as s
OUT=Path(__file__).resolve().parent
checks=[]
def ident(name, expr):
    value=s.simplify(expr)
    checks.append({'name':name,'kind':'exact_identity','pass':value==0,'residual':str(value)})
def witness(name, condition, details):
    checks.append({'name':name,'kind':'decisive_witness','pass':bool(condition),'details':details})
Q,H,pi,rho,Vp,Vpp,b,bp,K2,phi,sig,p,n,v,A=s.symbols('Q H pi rho Vp Vpp b bp K2 phi sig p n v A', nonzero=True, real=True)
Hd=-(rho+pi*pi)/(2*Q)
pid=-3*H*pi-Vp-b*rho
rd=(b*pi-3*H)*rho
phid=(pi*sig-rho*v)/(2*Q)-H*phi
pd=-3*H*p-(K2+Vpp+rho*(bp+b*b))*sig+4*pi*phid-2*(Vp+b*rho)*phi-b*rho*n
flow={H:Hd,pi:pid,rho:rd,Vp:Vpp*pi,b:bp*pi,K2:-2*H*K2,phi:phid,sig:p,p:pd,n:K2*v+3*phid,v:-phi-b*sig-b*pi*v,A:b*pi*A}
def dt(expr, supplied_flow=flow):
    return s.expand(sum(s.diff(expr,x)*val for x,val in supplied_flow.items()))
V=s.symbols('V',real=True)
ident('background_friedmann_propagation',6*Q*H*Hd-rd-pi*pid-Vp*pi)
C=(2*Q*K2-pi*pi)*phi+pi*p+(3*H*pi+Vp+b*rho)*sig+rho*n-3*H*rho*v
ident('constraint_Cdot_plus_3HC',dt(C)+3*H*C)
ident('spatial_trace_from_momentum',dt(phid)+4*H*phid+(2*Hd+3*H*H)*phi-(pi*p-pi*pi*phi-Vp*sig)/(2*Q))
for name, delta in [('omit_number_contrast_b_squared_mass',rho*b*b*sig),('omit_matter_lapse_source',2*b*rho*phi)]:
    mutated=dict(flow);mutated[p]=pd+delta
    failure=s.factor(dt(C,mutated)+3*H*C)
    witness(name,failure!=0,{'failed_constraint_residual':str(failure)})
# Wave operator expanded independently as a density divergence.
e=s.symbols('e');t=s.symbols('t',real=True)
af=s.Function('a')(t);cf=s.Function('chi')(t);sf=s.Function('sigma')(t)
Ps=s.Function('Psi')(t);Ph=s.Function('Phi')(t)
sqrtg=af**3*(1+e*(Ps-3*Ph))
ginv00=-(1-2*e*Ps)
box_time=s.series(s.diff(sqrtg*ginv00*s.diff(cf+e*sf,t),t)/sqrtg,e,0,2).removeO().expand().coeff(e,1)
expected=-s.diff(sf,t,2)-3*s.diff(af,t)/af*s.diff(sf,t)+2*Ps*(s.diff(cf,t,2)+3*s.diff(af,t)/af*s.diff(cf,t))+(s.diff(Ps,t)+3*s.diff(Ph,t))*s.diff(cf,t)
ident('metric_wave_operator_time_and_space_slots',box_time-expected)
Ps0,Ph0=s.symbols('Psi Phi')
ident('proper_number_density_lapse_cancellation',s.expand((1+e*(Ps0-3*Ph0))*(1+e*n)*(1-e*Ps0)).coeff(e,1)-(n-3*Ph0))
ident('conformal_time_potential',s.expand((1+2*e*b*sig)*(1+2*e*Ps0)).coeff(e,1)/2-(Ps0+b*sig))
ident('conformal_spatial_potential',-s.expand((1+2*e*b*sig)*(1-2*e*Ph0)).coeff(e,1)/2-(Ph0-b*sig))
ident('weyl_sum_conformal_invariance',(Ps0+b*sig)+(Ph0-b*sig)-Ps0-Ph0)
ident('coordinate_number_contrast_invariance',(n-3*b*sig)-3*(Ph0-b*sig)-(n-3*Ph0))
ident('einstein_energy_contrast_jordan_map',n+b*sig-((n-3*b*sig)+4*b*sig))
ident('jordan_dust_euler',dt(A*v)/A+phi+b*sig)
ident('jordan_dust_continuity',dt(n-3*b*sig)/A-K2/A**2*(A*v)-3*dt(phi-b*sig)/A)
HJ=(H+b*pi)/A;lam=b*pi/A;q=2*Q*b*b;Gamma=rho/(2*Q*A*A)
ident('jordan_dust_background',dt(rho/A**4)/A+3*HJ*rho/A**4)
h=b*sig;vJ=A*v;y=phid/A+HJ*phi
ident('jordan_momentum_inverse',y-lam*phi-(lam/q)*h+Gamma*vJ)
ident('relative_F_history',dt(Q/A**2)/A/(Q/A**2)+2*lam)
ident('Gamma_conservation_consistency',dt(Gamma)/A/Gamma-2*lam+3*HJ)
ident('potential_independent_background_gate',dt(HJ)/A-dt(lam)/A+lam*HJ+Gamma+lam*lam*(1/q-1))
ident('relative_potential',((3*Q*H*H-rho-pi*pi/2)/(Q*A*A))-(3*(HJ-lam)**2-2*Gamma-lam*lam/q))
M=s.Matrix([[1,2,-1],[2,-1,-3],[-1,1,-2]])/1000
c=s.Matrix([s.Rational(3,40),s.Rational(3,10),s.Rational(1,5)])
sol=M.inv()*(M*c)
witness('rank_three_recovers_momentum_coefficients',M.det()!=0 and sol==c and sol[0]/sol[1]==s.Rational(1,4),{'det':str(M.det()),'solution':list(map(str,sol)),'q':str(sol[0]/sol[1])})
scale=s.diag(s.Rational(2,3),s.Rational(-5,4),s.Rational(7,2))
witness('per_mode_constant_amplitudes_cancel',(scale*M).inv()*(scale*M*c)==c,{'row_scales':list(map(str,scale.diagonal()))})
c_turn=s.Matrix([0,0,s.Rational(1,5)])
turns=[M*s.Matrix([0,0,c_turn[2]]) for _q in [s.Rational(1,5),s.Rational(3,10)]]
witness('turning_point_does_not_recover_q',turns[0]==turns[1] and M.det()!=0,{'distinct_q':['1/5','3/10'],'same_y':list(map(str,turns[0]))})
rank_lost=s.Matrix([[1,2,3],[2,4,6],[3,6,9]])
witness('three_labels_do_not_guarantee_rank',rank_lost.rank()==1,{'rank':rank_lost.rank()})
# Constraint-compatible triples are independent even at the dangerous metric divisor.
n_constraint=s.solve(C,n)[0]
ident('rank_availability_constraint_completion',C.subs(n,n_constraint))
ident('vanishing_metric_divisor_does_not_prevent_n_completion',C.subs(n,n_constraint).subs(K2,pi*pi/(2*Q)))
u,x,yy,k,alpha,Hv,Kuu,Lnu=s.symbols('u x yy k alpha Hv Kuu Lnu',positive=True)
Ur=s.Function('Ur')(u)
Ut=Ur+k*x*x*s.exp(-(1-k)*u/alpha)/2+k*yy*yy*s.exp(-(1+k)*u/alpha)/3
ident('radial_transverse_potential_mixed_x',s.diff(Ut,u,x).subs({x:0,yy:0}))
ident('radial_transverse_potential_mixed_y',s.diff(Ut,u,yy).subs({x:0,yy:0}))
ident('canonical_radial_q_normalization',2*Q*(Lnu/s.sqrt(2*Q*Kuu))**2-Lnu*Lnu/Kuu)
# A deliberately nonradial potential source does not decouple at first order.
witness('nonradial_background_is_not_covered',s.diff(Ut,u,x).subs(x,1)!=0,{'mixed_derivative':str(s.diff(Ut,u,x).subs(x,1))})
record={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author_new_M14_source_exposed':False,'scope':'Independent exact algebra; no root code/ODE/raw observations','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':checks,'count':len(checks),'passed':sum(c['pass'] for c in checks),'failed':sum(not c['pass'] for c in checks)}
path=OUT/'CONTROL_RESULTS_v1.json'
if path.exists(): raise RuntimeError('Immutable output already exists')
path.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['count','passed','failed','script_sha256']}))
raise SystemExit(bool(record['failed']))
