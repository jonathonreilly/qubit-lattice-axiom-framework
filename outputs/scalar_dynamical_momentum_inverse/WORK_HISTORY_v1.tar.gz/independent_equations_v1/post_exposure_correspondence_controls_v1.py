#!/usr/local/bin/python3
"""Small source-correspondence controls, AFTER author-note exposure; no author code."""
from pathlib import Path
import hashlib,json,datetime
import sympy as s
out=Path(__file__).resolve().parent
checks=[]
def check(name,expr):
 r=s.simplify(expr);checks.append({'name':name,'residual':str(r),'pass':r==0})
a,K2,H,H0,S,Sn,W,Wn,r,x,y,q,R,lam,Gamma,v,Psi,h=s.symbols('a K2 H H0 S Sn W Wn r x y q R lam Gamma v Psi h',nonzero=True,real=True)
P=-a**3*K2*S/(3*H0**2*W)
Pn=s.diff(P,a)*a+s.diff(P,K2)*(-2*K2)+s.diff(P,S)*Sn+s.diff(P,W)*Wn
check('normalized_M_identity',Pn+P*Wn/W-P*(1+Sn/S))
Wdef=K2*v/H
Wprime=s.diff(Wdef,K2)*(-2*K2)+s.diff(Wdef,v)*(-Psi/H)+s.diff(Wdef,H)*(h*H)
check('normalized_euler',Wprime+(2+h)*Wdef+K2*Psi/H**2)
# r = 2Psi/S - 1 and Euler eliminate the time metric potential.
check('slip_from_Euler',2*H**2*a**3*(Wn/W+2+h)/(3*H0**2*P)-1-(2*Psi/S-1).subs(Psi,-H**2/K2*(Wn+(2+h)*W)))
# Direct normalized momentum: S_N+S = -rhoJ v/(FH) -x*S*(1+r/q)/2.
B=s.symbols('rho_over_F',real=True)
Sn_mom=-S-B*v/H-x*S*(1+r/q)/2
M=(Pn+P*Wn/W).subs(Sn,Sn_mom).subs(W,K2*v/H)
Pphys=P.subs(W,K2*v/H)
Rphys=B*a**3/(3*H0**2)
check('normalized_momentum_R_M_x_y',Rphys-M-Pphys*x/2-Pphys*r*x/(2*q))
# Exact determinant factor for the root observable chart.
v1,v2,v3,f1,f2,f3,X1,X2,X3,c,b=s.symbols('v1 v2 v3 f1 f2 f3 X1 X2 X3 c b',nonzero=True,real=True)
base=s.Matrix([[v1,f1,X1],[v2,f2,X2],[v3,f3,X3]])
L=s.Matrix([[1,c*f1/(2*v1),c*b*X1/(2*v1)],[1,c*f2/(2*v2),c*b*X2/(2*v2)],[1,c*f3/(2*v3),c*b*X3/(2*v3)]])
check('rank_chart_determinant',L.det()-c*c*b/(4*v1*v2*v3)*base.det())
# Convert the independent Jordan-time background identities to the N form.
xx,xn,omega,E,N=s.symbols('x xn omega E N',real=True)
l=-H*xx/2
ld=-H*H*(xn+h*xx)/2
GammaH=3*R*s.exp(-3*N)/(2*E**2)
indbg=h-ld/H**2+l/H+GammaH+l*l/H**2*(1/q-1)
rootbg=xn+(h-1)*xx+((1/q-3)/2+1)*xx*xx+2*h+3*R*s.exp(-3*N)/E**2
check('background_equation_3_conversion',2*indbg-rootbg)
indpot=3*E**2*(1+xx/2)**2-3*R*s.exp(-3*N)-E**2*xx**2/(4*q)
rootpot=3*E**2*(1+xx)-(1/q-3)/2*E**2*xx**2/2-3*R*s.exp(-3*N)
check('relative_potential_equation_4_conversion',indpot-rootpot)
beta,kappa,q1,q2=s.symbols('beta kappa q1 q2',nonzero=True,real=True)
R1=(1-q1/beta)/(kappa*(1-3*q1));R2=(1-q2/beta)/(kappa*(1-3*q2))
check('candidate_two_epoch_determinant',q1*R2*(1-3*q2)-q2*R1*(1-3*q1)-(q1-q2)/kappa)
Fc,F=s.symbols('Fc F',nonzero=True,real=True)
qgeom=beta*(F-Fc)/(F-3*beta*Fc)
check('candidate_relation_from_shape',qgeom/beta+Fc/F*(1-3*qgeom)-1)
ss,Ex=s.symbols('ss Ex',positive=True)
Fexpression=Fc+Fc/(ss*Ex)
check('candidate_exponential_chart',s.factor((beta/qgeom-1)/((1-3*beta)*ss)).subs(F,Fexpression)-Ex)
gam,nu,U0,U1,C=s.symbols('gam nu U0 U1 C',real=True)
check('candidate_potential_normalization',((2*gam*(U0+nu*U1)/C)*C/2)-(gam*U0+gam*nu*U1))
# Error orientation: L(z-zhat)=deltaM-deltaL*zhat, with deltaL=L-Lhat.
z1,z2,z3=s.symbols('z1 z2 z3');dh1,dh2,dh3=s.symbols('dh1 dh2 dh3')
Lc=s.Matrix([[1,s.Rational(2,5),s.Rational(-3,7)],[1,s.Rational(-1,3),s.Rational(2,7)],[1,s.Rational(4,5),s.Rational(1,2)]])
dL=s.Matrix([[0,s.Rational(1,100),s.Rational(-1,120)],[0,s.Rational(-1,130),s.Rational(1,140)],[0,s.Rational(1,150),s.Rational(1,160)]])
zh=s.Matrix([s.Rational(3,4),s.Rational(1,5),s.Rational(2,3)]);dm=s.Matrix([s.Rational(1,200),s.Rational(-1,210),s.Rational(1,220)])
Lh=Lc-dL;Mh=Lh*zh;z=Lc.inv()*(Mh+dm)
check('error_bound_exact_orientation',sum((Lc*(z-zh)-dm+dL*zh).applyfunc(lambda t:t*t)))
norm=lambda m:max(sum(abs(m[i,j]) for j in range(m.cols)) for i in range(m.rows))
d=norm(dL);nn=norm(Lh.inv());ee=max(abs(a) for a in dm);eta=nn*d
eps=nn*(ee+d*max(abs(a) for a in zh))/(1-eta)
checks.append({'name':'rational_matrix_perturbation_enclosure','pass':eta<1 and max(abs(a) for a in z-zh)<=eps,'eta':str(eta),'actual_error':str(max(abs(a) for a in z-zh)),'certified_error':str(eps)})
qhat=zh[1]/zh[2];qtrue=z[1]/z[2];eq=eps*(1+abs(qhat))/(abs(zh[2])-eps)
checks.append({'name':'rational_ratio_perturbation_enclosure','pass':abs(zh[2])>eps and abs(qtrue-qhat)<=eq,'actual_error':str(abs(qtrue-qhat)),'certified_error':str(eq)})
r={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exposure':'POST_AUTHOR_NOTE; independent script, no author code/ODE run','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':checks,'count':len(checks),'passed':sum(c['pass'] for c in checks),'failed':sum(not c['pass'] for c in checks)}
f=out/'POST_EXPOSURE_CONTROLS_v1.json'
if f.exists(): raise RuntimeError('immutable output exists')
f.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['count','passed','failed','script_sha256']}));raise SystemExit(bool(r['failed']))
