#!/usr/local/bin/python3
"""Independent sharp envelope witnesses before exposure to new author controls."""
from pathlib import Path
import hashlib,json,datetime
import sympy as s
p=Path(__file__).resolve().parent
checks=[]
def ck(name,value,**details):checks.append({'name':name,'passed':bool(value),**details})
def mat(P,r):return s.Matrix([[1,-pi/2,-pi*ri/2] for pi,ri in zip(P,r)])
def ni(M):return max(sum(abs(M[i,j]) for j in range(M.cols)) for i in range(M.rows))
d=s.Rational(1,100);P=list(map(s.Integer,[2,4,6]));r=[s.S.Zero,s.S.Zero,s.Rational(1,3)];zh=s.Matrix([s.Rational(9,10),s.Rational(1,2),s.S.One])
L=mat(P,r);err=[2*d/pi for pi in P];rt=[ri+sg*ee for ri,sg,ee in zip(r,[-1,1,-1],err)];T=mat(P,rt);z=T.inv()*L*zh;n=ni(L.inv());eta=n*d;bound=n*d*ni(zh)/(1-eta);wrong=n*d*ni(zh)/(1+eta)
ck('matrix_inverse_norm_four',n==4)
ck('matrix_rank_one_displacement',z-zh==s.Matrix([-s.Rational(1,32),-s.Rational(1,48),s.Rational(1,24)]))
ck('matrix_bound_attained',ni(z-zh)==bound==s.Rational(1,24),actual=str(ni(z-zh)),bound=str(bound))
ck('wrong_matrix_plus_denominator_rejected',ni(z-zh)>wrong==s.Rational(1,26),wrong_bound=str(wrong))
P=[-s.Rational(7,3),s.Rational(2,3),s.Rational(5,3)];r=[s.Rational(6,7),s.S.Zero,s.Rational(6,5)];zh=s.Matrix([s.S.One,s.Rational(1,2),s.S.One]);L=mat(P,r);dm=d*s.Matrix([1,-1,1]);z=zh+L.inv()*dm;n=ni(L.inv());eps=n*d;qhat=zh[1]/zh[2];q=z[1]/z[2];bound=eps*(1+abs(qhat))/(abs(zh[2])-eps);wrong=eps*(1+abs(qhat))/(abs(zh[2])+eps)
ck('ratio_inverse_norm_four',n==4)
ck('ratio_state_displacement',z-zh==s.Matrix([s.Rational(1,300),s.Rational(1,25),-s.Rational(1,25)]))
ck('ratio_bound_attained',abs(q-qhat)==bound==s.Rational(1,16),actual=str(abs(q-qhat)),bound=str(bound))
ck('wrong_ratio_plus_denominator_rejected',abs(q-qhat)>wrong==s.Rational(3,52),wrong_bound=str(wrong))
ck('ratio_true_coefficient_domain',z[0]>0 and z[2]!=0 and q>0)
r={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_author_controls_opened':False,'scope':'Independent exact supplied-rational witness calculations; no observational error inference','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':checks,'counts':{'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks)}}
f=p/'SHARP_ENVELOPE_INDEPENDENT_RESULTS_v1.json'
if f.exists():raise RuntimeError('immutable result exists')
f.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));raise SystemExit(r['counts']['failed']!=0)
