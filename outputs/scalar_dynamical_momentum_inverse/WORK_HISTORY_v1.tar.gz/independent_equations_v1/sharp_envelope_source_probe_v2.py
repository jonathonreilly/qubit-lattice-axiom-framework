#!/usr/local/bin/python3
"""Narrow post-exposure correspondence to the two added domain controls."""
import sys
sys.dont_write_bytecode=True
from pathlib import Path
import hashlib,json,datetime,ast,importlib.util,difflib
import sympy as s
p=Path(__file__).resolve().parent
source=p/'CANONICAL_DOMAINS_SHARP_SOURCE_v1.py'
spec=importlib.util.spec_from_file_location('sharp_domain_copy',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
checks=[]
def ck(name,v,**kw):checks.append({'name':name,'passed':bool(v),**kw})
def funcs(path):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)}
a=funcs(p/'CANONICAL_EXPOSURE_v1__scalar_dynamical_domains.py');b=funcs(source)
ck('all_noncontrol_APIs_unchanged',all(a[n]==b[n] for n in a if n!='checks'))
d=s.Rational(1,100);P=[s.Integer(2),s.Integer(4),s.Integer(6)];r=[0,0,s.Rational(1,3)];z=[s.Rational(9,10),s.Rational(1,2),s.Integer(1)]
M=[z[0]-pi*z[1]/2-pi*ri*z[2]/2 for pi,ri in zip(P,r)];er=[2*d/pi for pi in P]
env=m.error_envelope(P,r,M,[0]*3,er,[0]*3);actual=m.inverse(P,[ri+sg*ei for ri,sg,ei in zip(r,[-1,1,-1],er)],M)
e=max(abs(actual[k]-v) for k,v in zip(['R','x','y'],z))
ck('author_matrix_control_matches_independent_witness',e==env['state_error']==s.Rational(1,24),actual_error=str(e),bound=str(env['state_error']))
P=[-s.Rational(7,3),s.Rational(2,3),s.Rational(5,3)];r=[s.Rational(6,7),0,s.Rational(6,5)];z=[s.Integer(1),s.Rational(1,2),s.Integer(1)]
M=[z[0]-pi*z[1]/2-pi*ri*z[2]/2 for pi,ri in zip(P,r)];env=m.error_envelope(P,r,M,[0]*3,[0]*3,[d]*3);actual=m.inverse(P,r,[mi+sg*d for mi,sg in zip(M,[1,-1,1])]);e=abs(actual['q']-s.Rational(1,2))
ck('author_ratio_control_matches_independent_witness',e==env['q_error']==s.Rational(1,16),actual_error=str(e),bound=str(env['q_error']))
failed=(p/'AUTHOR_DOMAIN_SHARP_FIXTURE_FAILED_v1.source').read_text();current=source.read_text()
ck('failed_fixture_only_first_r_sign_changed',failed.replace('rr=[sp.Rational(-6,7),0,sp.Rational(6,5)]','rr=[sp.Rational(6,7),0,sp.Rational(6,5)]')==current)
diff=''.join(difflib.unified_diff(failed.splitlines(True),current.splitlines(True),fromfile='failed_fixture',tofile='corrected_fixture'))
(p/'SHARP_FAILED_FIXTURE_DELTA_v2.diff').write_text(diff)
r={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Post-exposure two API witnesses plus source-diff checks; no full domains checks() or mutation run','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':checks,'counts':{'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks)}}
f=p/'SHARP_ENVELOPE_SOURCE_RESULTS_v2.json'
if f.exists():raise RuntimeError('immutable result exists')
f.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2));raise SystemExit(r['counts']['failed']!=0)
