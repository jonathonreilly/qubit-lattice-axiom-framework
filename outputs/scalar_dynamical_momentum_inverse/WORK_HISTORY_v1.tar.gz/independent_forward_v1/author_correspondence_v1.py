"""Post-freeze source/result correspondence; no numerical evolution."""
from pathlib import Path
import hashlib,json,math
HERE=Path(__file__).resolve().parent
own=json.loads((HERE/'INDEPENDENT_DYNAMICAL_RESULTS_v1.json').read_text())
author=json.loads((HERE/'author_source_v1/run_v1/RESULTS.json').read_text())
protocol=json.loads((HERE/'FORWARD_PROTOCOL_v1.json').read_text())
input_ids=json.loads((HERE/'author_source_v1/run_v1/INPUT_IDENTITIES.json').read_text())
checks=[]
def check(n,v,d=None):checks.append({'name':n,'passed':bool(v),'detail':d})
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,expected in input_ids['sha256'].items():
    path=HERE/'FORWARD_PROTOCOL_v1.json' if name=='FORWARD_PROTOCOL_v1.json' else HERE/'author_source_v1'/name
    check('author_input_identity:'+name,sha(path)==expected)
maxima={};where={};mode_count=epoch_count=0;cases=[]
def compare(key,a,b,location):
    delta=abs(float(a)-float(b))
    if key not in maxima or delta>maxima[key]:maxima[key]=delta;where[key]=location
for hist,src in zip(own['histories'],author['cases']):
    check(hist['id']+'_case_identity',hist['case']==src['case'])
    check(hist['id']+'_same_epoch_count',len(hist['epochs'])==len(src['epochs'])==len(protocol['sample_fractions']))
    check(hist['id']+'_same_physical_modes',max(abs(a/hist['A0']-b) for a,b in zip(hist['kcoms'],src['comoving_modes']))<1e-13)
    for j,(e,a) in enumerate(zip(hist['epochs'],src['epochs'])):
        epoch_count+=1;loc={'case':hist['id'],'epoch':j}
        bg=e['background'];mapping={'t':e['timeE'],'N':e['N'],'u':bg['u'],'u_dot':bg['w']/bg['sqrt_metric'],'rho_E':bg['rho'],'H_E':bg['H'],'H_J':e['HJ'],'H0_J':hist['HJ0'],'a_J':e['a'],'F':e['F'],'q_true':e['q'],'x_true':e['g'],'R_true':e['R'],'y_true':e['g']/e['q']}
        for key,value in mapping.items():compare('background:'+key,value,a[key],loc)
        inv=e['inverse']
        for k,ownkey in [('R','R'),('x','g'),('y','g_over_q'),('q','q')]:compare('inferred:'+k,inv[ownkey],a['inferred'][k],loc)
        for m,r in zip(e['modes'],a['rows']):
            mode_count+=1;mloc={**loc,'mode':m['mode']}
            mapping={'K_over_HJ':math.sqrt(m['KJ2'])/e['HJ'],'phi_E':m['phiE'],'X':m['X'],'Xdot':m['Z'],'number_contrast':m['number_contrast'],'velocity':m['vE'],'W':m['W'],'W_N':m['W_prime'],'P':m['P'],'P3':m['W_prime']/m['W'],'r':m['r_Euler'],'r_metric':m['r'],'M':m['P']*m['momentum_rhs']/2}
            for key,value in mapping.items():compare('mode:'+key,value,r[key],mloc)
            compare('diagnostic:opposite_sign_constraint',-m['C00'],r['constraint'],mloc)
            compare('diagnostic:slip_metric_vs_Euler',m['r'],m['r_Euler'],mloc)
        r=e['modes'][protocol['reserved_mode']]
        own_abs_reserved=inv['R']-r['P']*r['momentum_rhs']/2-r['P']*inv['g']/2-r['P']*r['r']*inv['g_over_q']/2
        compare('diagnostic:absolute_reserved',own_abs_reserved,a['reserved_mode_residual'],loc)
    candidate=hist['candidate'];cp=src['candidate'];kap=1/candidate['B'];kaptrue=1/hist['source_truth']['B']
    compare('candidate:beta',candidate['beta'],cp['beta_inferred'],{'case':hist['id']})
    compare('candidate:kappa',kap,cp['kappa_inferred'],{'case':hist['id']})
    check(hist['id']+'_beta_recovery_fixed_threshold',abs(candidate['beta']-cp['beta_true'])<protocol['checks']['candidate_absolute_max'])
    check(hist['id']+'_kappa_recovery_fixed_threshold',abs(kap-kaptrue)<protocol['checks']['candidate_absolute_max'])
    later=[]
    for index in protocol['candidate_reserved_epoch_indices']:
        inv=hist['epochs'][index]['inverse'];res=inv['q']/candidate['beta']+inv['R']*(1-3*inv['q'])*kap-1
        later.append(res)
    check(hist['id']+'_absolute_candidate_later_fixed_threshold',max(map(abs,later))<protocol['checks']['reserved_scaled_max'])
    caseinfo={'case':hist['id'],'beta':candidate['beta'],'kappa':kap,'beta_author':cp['beta_inferred'],'kappa_author':cp['kappa_inferred'],'kappa_truth':kaptrue,'absolute_kappa_error':abs(kap-kaptrue),'later_absolute_residuals':later,'own_row_scaled_conditions':[e['inverse']['condition'] for e in hist['epochs']],'author_conditions':[e['condition_number'] for e in src['epochs']],'minimum_abs_g_over_q':min(abs(e['inverse']['g_over_q']) for e in hist['epochs']),'q_calibration_gap':candidate['calibration_delta_q']}
    cases.append(caseinfo)
check('all_56_mode_rows_and_14_epochs_compared',mode_count==56 and epoch_count==14)
check('author_all_22_controls_pass',author['counts']=={'passed':22,'failed':0} and len(author['checks'])==22 and all(c['passed'] for c in author['checks']))
record={'scope':'Post-freeze value correspondence, not a root rerun or new physics test.','checker_sha256':sha(Path(__file__)),'independent_result_sha256':sha(HERE/'INDEPENDENT_DYNAMICAL_RESULTS_v1.json'),'author_result_sha256':sha(HERE/'author_source_v1/run_v1/RESULTS.json'),'checks':checks,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'compared_epochs':epoch_count,'compared_mode_rows':mode_count,'maximum_absolute_differences':maxima,'max_difference_locations':where,'cases':cases,'coordinate_dictionary':'Independent aE0=1, normalized Jordan a=A*aE/A0; author aE0=1/A0 and aJ=A*aE. Therefore author kcom=independent kcom/A0, same physical K_E/K_J. Scalar covariant velocity potential v is unchanged.','inverse_dictionary':'Independent row [2/P,-1,-r_metric] is author row multiplied by 2/P; author r comes from Euler readout, independently also checked against metric slip. Independent B=1/author kappa. Condition numbers of differently row-scaled matrices should not be equated.','residual_scope':'Author reserved_mode and candidate_later controls use absolute dimensionless residuals despite protocol key reserved_scaled_max. Independent initial report uses normalized residuals; this correspondence checks the same absolute candidate residual separately. Author 00 max samples301 epochs/background; independent 00 max covers seven saved epochs/background.'}
(HERE/'AUTHOR_CORRESPONDENCE_RESULTS_v1.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ['checks','max_difference_locations']},indent=2))
for c in checks:
    if not c['passed']:print('FAILED',c)
assert all(c['passed'] for c in checks)
