"""Final saved-byte/value comparison only: never imports or executes science modules."""
from pathlib import Path
from collections import Counter
import ast,hashlib,json
P=Path(__file__).resolve().parent;W=P.parents[5];A=P/'canonical_source_v1';B=P/'canonical_source_v2';D=P.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
checks=[]
def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
primary='scripts/scalar_dynamical_momentum_inverse_check.py'
r1=read(A/'outputs/scalar_dynamical_momentum_inverse/RESULTS_v1.json');r2=read(B/'outputs/scalar_dynamical_momentum_inverse/RESULTS_v1.json');summary=read(B/'outputs/scalar_dynamical_momentum_inverse/SUMMARY_v1.json')
paths=None
for node in ast.parse((B/primary).read_text()).body:
 if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in node.targets):paths=ast.literal_eval(node.value)
check('same_eight_declared_input_paths',paths==list(r1['input_sha256']) or set(paths)==set(r1['input_sha256']))
input_ids={p:sha(B/p) for p in paths};check('result_source_ids_match_v2_snapshots',input_ids==r2['input_sha256'] and sha(B/primary)==r2['primary_sha256'])
h=hashlib.sha256(b'runner-cache-input-fingerprint-v1\0')
for p in paths:
 rb=p.encode();bb=(B/p).read_bytes();h.update(len(rb).to_bytes(8,'big'));h.update(rb);h.update(len(bb).to_bytes(8,'big'));h.update(bb)
cachepath=B/'logs/runner-cache/scalar_dynamical_momentum_inverse_check.txt';cache=cachepath.read_text();header=cache.split('----- stdout -----')[0];hdr={ln.split(': ',1)[0]:ln.split(': ',1)[1] for ln in header.splitlines() if ': ' in ln}
check('cache_input_fingerprint_current',h.hexdigest()==hdr['input_fingerprint_sha256']);check('cache_primary_current',sha(B/primary)==hdr['runner_sha256']);check('cache_success_within_timeout',hdr['status']=='ok' and hdr['exit_code']=='0' and hdr['timeout_sec']=='180' and float(hdr['elapsed_sec'])<180)
stdout=cache.split('----- stdout -----\n',1)[1].split('----- stderr -----',1)[0];decoded=json.JSONDecoder().raw_decode(stdout[stdout.index('{'):])[0];check('cache_stdout_exact_summary',decoded==summary)
expected={k:r2[k] for k in ['actual_current_surface_status','target_claim_type','scope','counts','empirical_tests','primary_sha256','input_sha256','read_inventory','history_scope']};expected['failed_checks']=[v for v in r2['checks'] if not v['passed']];expected['cases']=[{k:c[k] for k in ['case','candidate','constraint_max','maximum_abs_r_minus_q','turning_diagnostic']} for c in r2['cases']];expected['potential_diagnostics']=[{k:v for k,v in p.items() if k!='epoch_rows'} for p in r2['potential_diagnostics']]
check('summary_exact_result_projection',summary==expected)
check('85_true_controls_0_false',r2['counts']=={'passed':85,'failed':0} and len(r2['checks'])==85 and all(v['passed'] for v in r2['checks']))
check('all_saved_cases_56_modes_14_epochs_exactly_unchanged',r1['cases']==r2['cases'] and sum(len(e['rows']) for c in r2['cases'] for e in c['epochs'])==56 and sum(len(c['epochs']) for c in r2['cases'])==14)
check('all_potential_rows_and_diagnostics_exactly_unchanged',r1['potential_diagnostics']==r2['potential_diagnostics'])
check('scope_read_inventory_history_unchanged',all(r1[k]==r2[k] for k in ['scope','read_inventory','history_scope','empirical_tests','actual_current_surface_status','target_claim_type']) and r2['empirical_tests']==0)
old={v['name']:v for v in r1['checks']};new={v['name']:v for v in r2['checks']};added=set(new)-set(old);removed=set(old)-set(new)
expected_added={'background.potential_decoder_exact_event','domains.sharp_matrix_inverse_error','domains.sharp_ratio_error','equal_time_covariance.square_monomial_inconsistent_lift_not_physics','equal_time_covariance.product_monomial_inconsistent_lift_not_physics'}
check('precise_control_delta_81_plus4',added==expected_added and removed=={'equal_time_covariance.inconsistent_lift_not_physics'} and all(old[k]==new[k] for k in set(old)&set(new)),{'added':sorted(added),'removed':sorted(removed)})
for rel in ['scripts/scalar_dynamical_forward.py','scripts/scalar_dynamical_geometry.py',paths[6],paths[7]]:check('unchanged_bytes:'+rel,(A/rel).read_bytes()==(B/rel).read_bytes())
def functions(path):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_text()).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
for rel,exclude in [('scripts/scalar_dynamical_domains.py','checks'),('scripts/scalar_dynamical_covariance.py','controls')]:
 a=functions(A/rel);b=functions(B/rel);check('production_function_AST_unchanged:'+rel,{k:v for k,v in a.items() if k!=exclude}=={k:v for k,v in b.items() if k!=exclude})
for k in ['six_covariance_inputs','event','reconstruction','scope']:check('covariance_product_unchanged:'+k,r1['covariance_examples'][k]==r2['covariance_examples'][k])
freeze_rel='.claude/science/physics-loops/observations-backward-24h-20261014/dynamical_response/CANONICAL_SOURCE_FREEZE_v2.json';freeze=read(B/freeze_rel)
check('freeze_execution_stdout_plus_cache_separator',freeze['execution']['stdout']+'\n'==stdout and freeze['execution']['exit_code']==0 and freeze['execution']['timeout_sec']==180 and freeze['execution']['elapsed_sec']<180)
# Final live-byte check does not execute or import any runner.
for rel in [primary,*paths,'outputs/scalar_dynamical_momentum_inverse/RESULTS_v1.json','outputs/scalar_dynamical_momentum_inverse/SUMMARY_v1.json','logs/runner-cache/scalar_dynamical_momentum_inverse_check.txt']:check('live_equals_snapshot:'+rel,(W/rel).read_bytes()==(B/rel).read_bytes())
def events(file):
 out=[]
 for line in file.read_text().splitlines():
  if not line.strip():continue
  try:v=json.loads(line)
  except json.JSONDecodeError:v=ast.literal_eval(line)
  out.append(v)
 return out
history={}
for v in [1,3]:
 path=D/f'MUTATION_STDOUT_v{v}.txt';allrows=events(path);rows=[r for r in allrows if 'name' in r and 'status' in r];history[str(v)]={'sha256':sha(path),'variant_count':len(rows),'status_counts':dict(Counter(r['status'] for r in rows)),'scope':'Parsed root-owned historical log classifications only; no mutation execution or independent rejection proof.'}
check('v3_history_21_failed_checks_3_exceptions',history['3']['variant_count']==24 and history['3']['status_counts']=={'failed_checks':21,'exception':3})
record={'scope':'Narrow v1-to-v2 source/cache/product confirmation. No ODE, mathematical aggregate or mutation rerun.','checks':checks,'passed':sum(v['passed'] for v in checks),'failed':sum(not v['passed'] for v in checks),'checker_sha256':sha(Path(__file__)),'source_and_product_sha256':{str(p.relative_to(B)):sha(p) for p in B.rglob('*') if p.is_file()},'cache_header':hdr,'recomputed_input_fingerprint':h.hexdigest(),'exact_elapsed_seconds':freeze['execution']['elapsed_sec'],'mutation_history_classifications':history,'prior_report_sha256':sha(P/'CANONICAL_REVIEW_v1.md'),'prior_identity_sha256':sha(P/'CANONICAL_IDENTITY_v1.json')}
(P/'CANONICAL_BINDING_RESULTS_v2_1.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
print(json.dumps({'passed':record['passed'],'failed':record['failed'],'failed_checks':[v for v in checks if not v['passed']],'cache':hdr,'history':history},indent=2))
assert all(v['passed'] for v in checks)
