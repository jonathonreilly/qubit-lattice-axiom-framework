"""Read frozen sources/products only; no scientific module import or ODE execution."""
from pathlib import Path
import ast,copy,hashlib,json,math
HERE=Path(__file__).resolve().parent
SNAP=HERE/'canonical_source_v1'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
primary='scripts/scalar_dynamical_momentum_inverse_check.py'
paths=None
for node in ast.parse((SNAP/primary).read_text()).body:
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in node.targets):paths=ast.literal_eval(node.value)
assert paths and len(paths)==8
result=read(SNAP/'outputs/scalar_dynamical_momentum_inverse/RESULTS_v1.json')
summary=read(SNAP/'outputs/scalar_dynamical_momentum_inverse/SUMMARY_v1.json')
work=read(HERE/'author_source_v1/run_v1/RESULTS.json')
own=read(HERE/'INDEPENDENT_DYNAMICAL_RESULTS_v1.json')
opot=read(HERE/'INDEPENDENT_POTENTIAL_RESULTS_v1.json')
checks=[]
def check(name,ok,detail=None):checks.append(dict(name=name,passed=bool(ok),detail=detail))
inputs={p:sha(SNAP/p) for p in paths};check('input_hashes_match_frozen_sources',inputs==result['input_sha256'])
check('primary_hash_matches_frozen_source',sha(SNAP/primary)==result['primary_sha256'])
h=hashlib.sha256(b'runner-cache-input-fingerprint-v1\0')
for p in paths:
    rb=p.encode();bb=(SNAP/p).read_bytes();h.update(len(rb).to_bytes(8,'big'));h.update(rb);h.update(len(bb).to_bytes(8,'big'));h.update(bb)
cache=(SNAP/'logs/runner-cache/scalar_dynamical_momentum_inverse_check.txt').read_text()
header=cache.split('----- stdout -----')[0]
hdr={ln.split(': ',1)[0]:ln.split(': ',1)[1] for ln in header.splitlines() if ': ' in ln}
check('cache_fingerprint_matches_v1_inputs',hdr['input_fingerprint_sha256']==h.hexdigest())
check('cache_primary_identity_matches_v1',hdr['runner_sha256']==sha(SNAP/primary))
check('cache_success_declared_timeout',hdr['status']=='ok' and hdr['exit_code']=='0' and hdr['timeout_sec']=='180' and float(hdr['elapsed_sec'])<180,hdr)
stdout=cache.split('----- stdout -----\n',1)[1].split('----- stderr -----',1)[0]
cache_summary=json.JSONDecoder().raw_decode(stdout[stdout.index('{'):])[0]
check('cache_stdout_equals_summary',cache_summary==summary)
expect={k:result[k] for k in ['actual_current_surface_status','target_claim_type','scope','counts','empirical_tests','primary_sha256','input_sha256','read_inventory','history_scope']}
expect['failed_checks']=[r for r in result['checks'] if not r['passed']]
expect['cases']=[{k:c[k] for k in ['case','candidate','constraint_max','maximum_abs_r_minus_q','turning_diagnostic']} for c in result['cases']]
expect['potential_diagnostics']=[{k:v for k,v in p.items() if k!='epoch_rows'} for p in result['potential_diagnostics']]
check('summary_is_declared_result_projection',summary==expect)
check('all_81_v1_checks_accounted',result['counts']=={'passed':81,'failed':0} and len(result['checks'])==81 and all(c['passed'] for c in result['checks']))
check('no_empirical_test_claim',result['empirical_tests']==0)
maxdiff={};where={};count=epochs=0

def difference(k,a,b,loc):
    d=abs(float(a)-float(b))
    if k not in maxdiff or d>maxdiff[k]:maxdiff[k]=d;where[k]=loc

for c,w,o in zip(result['cases'],work['cases'],own['histories']):
    clone=copy.deepcopy(c);clone.pop('turning_diagnostic');gate=clone['checks'].pop()
    for ep in clone['epochs']:ep.pop('h_J')
    check(c['case']['id']+'_all_legacy_forward_values_exactly_unchanged',clone==w)
    check(c['case']['id']+'_sampled_domain_gate_recorded',gate=={'name':'finite_saved_epoch_domains','passed':True})
    check(c['case']['id']+'_turning_between_indices_1_2',[(v['left_index'],v['right_index']) for v in c['turning_diagnostic']['saved_sign_changes']]==[(1,2)])
    for j,(r,e) in enumerate(zip(c['epochs'],o['epochs'])):
        epochs+=1;loc={'case':c['case']['id'],'epoch':j};bg=e['background']
        mapping={'t':e['timeE'],'N':e['N'],'u':bg['u'],'u_dot':bg['w']/bg['sqrt_metric'],'rho_E':bg['rho'],'H_E':bg['H'],'H_J':e['HJ'],'h_J':e['hJ'],'H0_J':o['HJ0'],'a_J':e['a'],'F':e['F'],'q_true':e['q'],'x_true':e['g'],'R_true':e['R'],'y_true':e['g']/e['q']}
        for k,v in mapping.items():difference('background:'+k,r[k],v,loc)
        for k,ok in [('R','R'),('x','g'),('y','g_over_q'),('q','q')]:difference('inverse:'+k,r['inferred'][k],e['inverse'][ok],loc)
        for row,m in zip(r['rows'],e['modes']):
            count+=1;mapping={'K_over_HJ':math.sqrt(m['KJ2'])/e['HJ'],'phi_E':m['phiE'],'X':m['X'],'Xdot':m['Z'],'number_contrast':m['number_contrast'],'velocity':m['vE'],'W':m['W'],'W_N':m['W_prime'],'P':m['P'],'P3':m['W_prime']/m['W'],'r':m['r_Euler'],'r_metric':m['r'],'M':m['P']*m['momentum_rhs']/2}
            for k,v in mapping.items():difference('mode:'+k,row[k],v,{**loc,'mode':m['mode']})
check('all_56_mode_rows_and_14_epochs_compared',count==56 and epochs==14)
pot=[]
for r,o in zip(result['potential_diagnostics'],opot['cases']):
    deltas={}
    for k,ok in [('gamma_inferred','lambda'),('nu_inferred','nu'),('basis_condition','condition_2')]:deltas[k]=float(r[k])-float(o[ok])
    rowdiff={}
    for rr,oo in zip(r['epoch_rows'],o['rows']):
        for k,ok in [('u_inferred','u'),('U0','U0'),('U1','U1'),('target','target')]:rowdiff[k]=max(rowdiff.get(k,0),abs(rr[k]-oo[ok]))
    pot.append({'case':r['case'],'root':{k:v for k,v in r.items() if k!='epoch_rows'},'independent':{k:o[k] for k in ['lambda','mu','nu','condition_2','column_normalized_condition_2','errors_after_fit','later']},'root_minus_independent':deltas,'maximum_epoch_absolute_difference':rowdiff,'residual_convention':'Root target minus prediction; independent prediction minus target. No new potential tolerance applied.'})
record={'scope':'Post-exposure source and saved-product correspondence only. V1 snapshot historical after author affected-source update; no trajectory or aggregate rerun.','checker_sha256':sha(Path(__file__)),'source_and_output_sha256':{str(p.relative_to(SNAP)):sha(p) for p in SNAP.rglob('*') if p.is_file()},'checks':checks,'passed':sum(v['passed'] for v in checks),'failed':sum(not v['passed'] for v in checks),'cache_header':hdr,'recomputed_input_fingerprint':h.hexdigest(),'compared_mode_rows':count,'compared_epochs':epochs,'maximum_absolute_difference_vs_independent':maxdiff,'difference_locations':where,'potential_diagnostic_comparison':pot,'independent_evidence_sha256':{p:sha(HERE/p) for p in ['DYNAMICAL_FORWARD_REVIEW_v1.md','INDEPENDENT_DYNAMICAL_RESULTS_v1.json','POTENTIAL_REVIEW_v1.md','INDEPENDENT_POTENTIAL_RESULTS_v1.json']}}
(HERE/'CANONICAL_CORRESPONDENCE_RESULTS_v1.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
print(json.dumps({'passed':record['passed'],'failed':record['failed'],'max_differences':maxdiff,'potential_deltas':[{k:v for k,v in p.items() if k in ['case','root_minus_independent','maximum_epoch_absolute_difference']} for p in pot]},indent=2))
assert all(v['passed'] for v in checks)
