"""Blind independent canonical-state full radial linear forward computation.
No parent implementation or results are imported. Einstein time is normalized
by HE(0); Radau is an explicitly independent solver choice at fixed tolerances.
"""
from pathlib import Path
import hashlib,json,math,time
import numpy as np
from scipy.integrate import solve_ivp
HERE=Path(__file__).resolve().parent
PROTOCOL=HERE/'FORWARD_PROTOCOL_v1.json'
protocol=json.loads(PROTOCOL.read_text())
Q=float(protocol['units']['Q']);Hv=float(protocol['units']['Hv'])

def geometry(u,k,nu):
    beta=(1-k)*(1+3*k)/4;alpha=math.sqrt(beta);ss=(1+k)/(k*(1-3*k))
    e=math.exp(2*alpha*u);T=1+ss*e;J=1+(1-3*beta)*ss*e
    Tp=2*alpha*(T-1);Tpp=4*alpha*alpha*(T-1)
    Jp=2*alpha*(J-1)
    kin=J/T**2;kinp=kin*(Jp/J-2*Tp/T)
    n=1.5*ss*(e-1)**2+.5*nu*(1+ss)*u*u
    np_=6*ss*alpha*e*(e-1)+nu*(1+ss)*u
    npp=12*ss*alpha*alpha*e*(2*e-1)+nu*(1+ss)
    U=1.5+n/T**2
    Up=np_/T**2-2*n*Tp/T**3
    Upp=npp/T**2-4*np_*Tp/T**3-2*n*Tpp/T**3+6*n*Tp**2/T**4
    A=math.sqrt((1+ss)*e/T)
    metric=math.sqrt(2*Q*kin)
    b=alpha/math.sqrt(2*Q*J)
    bc=-beta*T*(J-1)/(2*Q*J**2)
    V=2*Q*Hv*Hv*U;Vc=2*Q*Hv*Hv*Up/metric
    Vcc=Hv*Hv*(Upp/kin-Up*kinp/(2*kin*kin))
    return {'K':kin,'sqrt_metric':metric,'A':A,'b':b,'bc':bc,'V':V,'Vc':Vc,'Vcc':Vcc,'q':2*Q*b*b,'beta':beta,'Fc':Q*ss/(1+ss)}

def background(y,case):
    u,w,rho,lnAE=map(float,y[:4]);g=geometry(u,case['kappa_model'],case['nu'])
    H=math.sqrt((.5*w*w+g['V']+rho)/(3*Q));Hd=-(w*w+rho)/(2*Q)
    wd=-3*H*w-g['Vc']-g['b']*rho;rd=(-3*H+g['b']*w)*rho
    G=H+g['b']*w;Gd=Hd+g['bc']*w*w+g['b']*wd
    return {**g,'u':u,'w':w,'rho':rho,'lnAE':lnAE,'aE':math.exp(lnAE),'H':H,'Hd':Hd,'wd':wd,'rd':rd,'G':G,'Gd':Gd}

def perturbation(y,b,kcom):
    phi,D,v,X,Z=map(float,y);K2=(kcom/b['aE'])**2
    pd=-b['H']*phi+(b['w']*X-b['rho']*v)/(2*Q)
    dd=K2*v+3*pd;vd=-phi-b['b']*X-b['b']*b['w']*v
    zd=-3*b['H']*Z-(K2+b['Vcc']+b['rho']*(b['bc']+b['b']**2))*X+4*b['w']*pd-2*(b['Vc']+b['b']*b['rho'])*phi-b['b']*b['rho']*D
    return np.array([pd,dd,vd,Z,zd]),K2

def norm_residual(terms):return abs(sum(terms))/max(sum(abs(x) for x in terms),1e-30)
def safe_json(v):
    if isinstance(v,np.generic):return v.item()
    if isinstance(v,np.ndarray):return v.tolist()
    raise TypeError(type(v).__name__)

start=time.monotonic();histories=[];checks=[]
def check(name,passed,detail):checks.append({'name':name,'passed':bool(passed),'detail':detail})
for case in protocol['backgrounds']:
    g0=geometry(case['u'],case['kappa_model'],case['nu'])
    initial=[case['u'],g0['sqrt_metric']*case['u_dot'],case['rho_E'],0.]
    b0=background(initial,case);HE0=b0['H'];A0=b0['A'];H0=b0['G']/A0
    rhoJ0=case['rho_E']/A0**4;Btruth=rhoJ0/(3*H0**2*b0['Fc'])
    kcoms=[f*HE0 for f in protocol['mode_K_over_HE0']]
    for i,kcom in enumerate(kcoms):
        phi=protocol['initial_phi_E'];X=protocol['initial_bX_over_phi'][i]*phi/b0['b']
        Z=protocol['initial_bZ_over_HE_phi'][i]*HE0*phi/b0['b']
        v=-protocol['initial_minus_v_HE_over_phi'][i]*phi/HE0
        D=((-2*Q*kcom*kcom+b0['w']**2)*phi+3*HE0*case['rho_E']*v-b0['w']*Z-(3*HE0*b0['w']+b0['Vc']+b0['b']*case['rho_E'])*X)/case['rho_E']
        initial.extend([phi,D,v,X,Z])
    def ode(tau,y):
        b=background(y,case)
        derivative=[b['w']/b['sqrt_metric'],b['wd'],b['rd'],b['H']]
        for i,kcom in enumerate(kcoms):derivative.extend(perturbation(y[4+5*i:9+5*i],b,kcom)[0])
        return np.array(derivative)/HE0
    duration=protocol['duration_times_HE0'];settings=protocol['solver']
    solution=solve_ivp(ode,[0,duration],initial,method='Radau',rtol=settings['rtol'],atol=settings['atol'],max_step=duration*settings['max_step_fraction'],dense_output=True)
    check(case['id']+'_solver',solution.success,solution.message)
    hist={'id':case['id'],'case':case,'HE0':HE0,'HJ0':H0,'A0':A0,'rhoJ0':rhoJ0,'kcoms':kcoms,'source_truth':{'beta':b0['beta'],'B':Btruth,'Fc':b0['Fc']},'solver':{'method':'Radau','nfev':solution.nfev,'njev':solution.njev,'nlu':solution.nlu,'success':bool(solution.success)},'epochs':[]}
    if not solution.success:histories.append(hist);continue
    for epoch,fraction in enumerate(protocol['sample_fractions']):
        tau=duration*fraction;y=solution.sol(tau);b=background(y,case)
        A=b['A'];G=b['G'];N=math.log(A/A0)+b['lnAE'];a=math.exp(N)
        HJ=G/A;hJ=(b['Gd']-b['b']*b['w']*G)/G**2
        F=Q/A**2;g=-2*b['b']*b['w']/G;R=rhoJ0/(3*H0*H0*F)
        erow={'index':epoch,'tau':tau,'timeE':tau/HE0,'N':N,'a':a,'background':b,'HJ':HJ,'E2':(HJ/H0)**2,'hJ':hJ,'F':F,'g':g,'R':R,'q':b['q'],'modes':[]}
        for i,kcom in enumerate(kcoms):
            phi,D,v,X,Z=map(float,y[4+5*i:9+5*i]);dy,K2=perturbation(y[4+5*i:9+5*i],b,kcom)
            pd,dd,vd,xd,zd=map(float,dy)
            scalar_shift=b['b']*X;shift_dot=b['bc']*b['w']*X+b['b']*Z
            Phi=phi-scalar_shift;Psi=phi+scalar_shift;Phip=(pd-shift_dot)/G;Psip=(pd+shift_dot)/G
            W=K2*v/G;Wp=K2/G**2*(vd-(2*b['H']+b['Gd']/G)*v)
            KJ2=K2/A**2;P=-2*a**3*KJ2*phi/(3*H0**2*W)
            deltaJ=D-3*scalar_shift;deltaJp=(dd-3*shift_dot)/G
            cterms=[-2*Q*K2*phi,-6*Q*b['H']*(pd+b['H']*phi),-b['rho']*(D+scalar_shift),-b['w']*Z,b['w']**2*phi,-b['Vc']*X]
            pdd=-b['Hd']*phi-b['H']*pd+(b['wd']*X+b['w']*Z-b['rd']*v-b['rho']*vd)/(2*Q)
            trace=[pdd,4*b['H']*pd,(2*b['Hd']+3*b['H']**2)*phi,-(b['w']*Z-b['w']**2*phi-b['Vc']*X)/(2*Q)]
            r=scalar_shift/phi;rhs=2+2*pd/(G*phi)
            rEuler=2*(HJ/H0)**2*a**3*(Wp/W+2+hJ)/(3*P)-1
            mode={'mode':i,'kcom':kcom,'KE2':K2,'KJ2':KJ2,'phiE':phi,'phiE_dot':pd,'number_contrast':D,'vE':v,'X':X,'Z':Z,'D_dot':dd,'vE_dot':vd,'Z_dot':zd,'PhiJ':Phi,'PsiJ':Psi,'PhiJ_prime':Phip,'PsiJ_prime':Psip,'deltaJ':deltaJ,'deltaJ_prime':deltaJp,'W':W,'W_prime':Wp,'P':P,'r':r,'r_Euler':rEuler,'momentum_rhs':rhs,'C00':sum(cterms),'C00_scaled':norm_residual(cterms),'trace_scaled':norm_residual(trace),'continuity_scaled':norm_residual([deltaJp,-W,-3*Phip]),'Euler_scaled':norm_residual([Wp,(2+hJ)*W,KJ2*Psi/HJ**2])}
            erow['modes'].append(mode)
        fit=[erow['modes'][i] for i in protocol['inverse_modes']]
        matrix=np.array([[2/m['P'],-1,-m['r']] for m in fit]);rhs=np.array([m['momentum_rhs'] for m in fit])
        determinant=float(np.linalg.det(matrix));condition=float(np.linalg.cond(matrix))
        try:
            estimate=np.linalg.solve(matrix,rhs);Rfit,gfit,hfit=map(float,estimate);qfit=gfit/hfit
            reserved=erow['modes'][protocol['reserved_mode']]
            terms=[2*Rfit/reserved['P'],-gfit,-reserved['r']*hfit,-reserved['momentum_rhs']]
            erow['inverse']={'R':Rfit,'g':gfit,'g_over_q':hfit,'q':qfit,'determinant':determinant,'condition':condition,'absolute_errors':{'R':abs(Rfit-R),'g':abs(gfit-g),'g_over_q':abs(hfit-g/b['q']),'q':abs(qfit-b['q'])},'reserved_scaled':norm_residual(terms)}
        except (np.linalg.LinAlgError,ZeroDivisionError) as error:
            erow['inverse']={'failure':repr(error),'determinant':determinant,'condition':condition}
        hist['epochs'].append(erow)
    ca,cb=[hist['epochs'][i]['inverse'] for i in protocol['candidate_calibration_epoch_indices']]
    try:
        qa,qb=ca['q'],cb['q'];ya=ca['R']*(1-3*qa);yb=cb['R']*(1-3*qb)
        slope=(yb-ya)/(qb-qa);Bfit=ya-slope*qa;betafit=-Bfit/slope
        later=[]
        for i in protocol['candidate_reserved_epoch_indices']:
            obs=hist['epochs'][i]['inverse'];lhs=obs['R']*(1-3*obs['q']);rhs=Bfit*(1-obs['q']/betafit)
            later.append({'index':i,'absolute_residual':abs(lhs-rhs),'scaled_residual':norm_residual([lhs,-rhs])})
        hist['candidate']={'beta':betafit,'B':Bfit,'kappa_model':(1-math.sqrt(4-12*betafit))/3,'calibration_delta_q':qb-qa,'absolute_errors':{'beta':abs(betafit-b0['beta']),'B':abs(Bfit-Btruth)},'later':later}
    except (KeyError,ZeroDivisionError,ValueError) as error:hist['candidate']={'failure':repr(error)}
    maxima={key:max(m[key] for e in hist['epochs'] for m in e['modes']) for key in ['C00_scaled','trace_scaled','continuity_scaled','Euler_scaled']}
    maxima['inverse_absolute']=max(v for e in hist['epochs'] if 'absolute_errors' in e['inverse'] for v in e['inverse']['absolute_errors'].values())
    maxima['reserved_scaled']=max(e['inverse'].get('reserved_scaled',math.inf) for e in hist['epochs'])
    maxima['candidate_absolute']=max(hist['candidate'].get('absolute_errors',{'failure':math.inf}).values())
    hist['maxima']=maxima
    for name in ['C00_scaled','trace_scaled','continuity_scaled','Euler_scaled']:
        check(case['id']+'_'+name,maxima[name]<protocol['checks']['constraint_scaled_max'],maxima[name])
    check(case['id']+'_inverse',maxima['inverse_absolute']<protocol['checks']['inverse_absolute_max'],maxima['inverse_absolute'])
    check(case['id']+'_candidate',maxima['candidate_absolute']<protocol['checks']['candidate_absolute_max'],maxima['candidate_absolute'])
    check(case['id']+'_reserved',maxima['reserved_scaled']<protocol['checks']['reserved_scaled_max'],maxima['reserved_scaled'])
    histories.append(hist)
result={'scope':'Independent blind implementation of supplied full radial linear scalar+dust system; no empirical validation or initial-state selection.','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'protocol_sha256':hashlib.sha256(PROTOCOL.read_bytes()).hexdigest(),'solver_difference':'Independent Radau versus supplied protocol DOP853, with unchanged rtol/atol and max physical step. No root outputs accessed before source/result freeze.','elapsed_seconds':time.monotonic()-start,'checks':checks,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'histories':histories}
(HERE/'INDEPENDENT_DYNAMICAL_RESULTS_v1.json').write_text(json.dumps(result,indent=2,default=safe_json,allow_nan=False)+'\n')
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'elapsed_seconds':result['elapsed_seconds'],'backgrounds':[{'id':h['id'],'maxima':h.get('maxima'),'candidate':h.get('candidate'),'conditioning':[e['inverse']['condition'] for e in h['epochs']]} for h in histories]},indent=2))
