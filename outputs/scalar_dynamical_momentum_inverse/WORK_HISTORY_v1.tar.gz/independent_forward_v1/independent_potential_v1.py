"""Independent potential readout on previously frozen reconstructed epochs.
No parent source/results or ODE solver are used; truth is diagnostic after fit.
"""
from pathlib import Path
import json,hashlib,math
import numpy as np
HERE=Path(__file__).resolve().parent
source=HERE/'INDEPENDENT_DYNAMICAL_RESULTS_v1.json'
protocol=json.loads((HERE/'FORWARD_PROTOCOL_v1.json').read_text())
data=json.loads(source.read_text())

def chart(beta,q):
    if not .25<beta<1/3 or not 0<q<beta:raise ValueError('radial chart domain')
    k=(1-math.sqrt(4-12*beta))/3
    alpha=math.sqrt(beta);ss=(1+k)/(k*(1-3*k))
    X=(beta/q-1)/((1-3*beta)*ss);u=math.log(X)/(2*alpha);T=1+ss*X
    return {'k':k,'u':u,'X':X,'A2':(1+ss)*X/T,'U0':1.5+1.5*ss*(X-1)**2/T**2,'U1':.5*(1+ss)*u*u/T**2}
results=[]
for history in data['histories']:
    beta=history['candidate']['beta'];rows=[]
    for epoch in history['epochs']:
        inv=epoch['inverse'];R,g,q=inv['R'],inv['g'],inv['q']
        c=chart(beta,q);omega=.5*(1/q-3)
        terms=[3*epoch['E2'],3*epoch['E2']*g,-.5*omega*epoch['E2']*g*g,-3*R*math.exp(-3*epoch['N'])]
        vbar=sum(terms);target=.5*c['A2']*vbar
        rows.append({'index':epoch['index'],'N':epoch['N'],'R':R,'g':g,'q':q,'E2':epoch['E2'],**c,'potential_terms':terms,'vbar':vbar,'target':target})
    a,b=[rows[i] for i in protocol['candidate_calibration_epoch_indices']]
    matrix=np.array([[a['U0'],a['U1']],[b['U0'],b['U1']]])
    rhs=np.array([a['target'],b['target']])
    lam,mu=map(float,np.linalg.solve(matrix,rhs));nu=mu/lam
    # Independent closed two-by-two arithmetic check at the same input precision.
    determinant=a['U0']*b['U1']-b['U0']*a['U1']
    lam_direct=(a['target']*b['U1']-b['target']*a['U1'])/determinant
    mu_direct=(a['U0']*b['target']-b['U0']*a['target'])/determinant
    norms=np.linalg.norm(matrix,axis=0)
    later=[]
    for i in protocol['candidate_reserved_epoch_indices']:
        row=rows[i];pred=lam*row['U0']+mu*row['U1'];error=pred-row['target']
        later.append({'index':i,'prediction':pred,'target':row['target'],'residual':error,'relative_target_residual':error/max(abs(row['target']),1e-30),'term_scaled_residual':error/max(abs(lam*row['U0'])+abs(mu*row['U1'])+abs(row['target']),1e-30)})
    # All source-parameter comparisons below occur only after fit completion.
    truth_lambda=float(protocol['units']['Hv'])**2/history['HJ0']**2
    truth_nu=history['case']['nu']
    for row,epoch in zip(rows,history['epochs']):
        row['u_reconstruction_error']=row['u']-epoch['background']['u']
        row['A2_reconstruction_error']=row['A2']-epoch['background']['A']**2
        true_vbar=epoch['background']['V']/(float(protocol['units']['Q'])*epoch['background']['A']**2*history['HJ0']**2)
        row['vbar_source_readout_error']=row['vbar']-true_vbar
    results.append({'case':history['id'],'input_beta':beta,'rows':rows,'calibration_indices':protocol['candidate_calibration_epoch_indices'],'calibration_matrix':matrix.tolist(),'calibration_rhs':rhs.tolist(),'determinant':determinant,'condition_2':float(np.linalg.cond(matrix)),'column_normalized_condition_2':float(np.linalg.cond(matrix/norms)),'column_norms':norms.tolist(),'lambda':lam,'mu':mu,'nu':nu,'truth_after_fit':{'lambda':truth_lambda,'nu':truth_nu},'errors_after_fit':{'lambda_absolute':lam-truth_lambda,'lambda_relative':lam/truth_lambda-1,'nu_absolute':nu-truth_nu,'nu_relative':nu/truth_nu-1},'closed_form_same_precision':{'lambda':lam_direct,'mu':mu_direct,'nu':mu_direct/lam_direct},'later':later,'finite_positive_parameters':bool(np.isfinite(lam) and np.isfinite(nu) and lam>0 and nu>0)})
result={'scope':'New diagnostic inverse using own previously frozen data and fixed epochs; no parent potential results read, no ODE rerun, no newly chosen pass threshold or observed-precision claim.','input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'precheck_sha256':hashlib.sha256((HERE/'POTENTIAL_PRECHECK_v1.md').read_bytes()).hexdigest(),'cases':results}
(HERE/'INDEPENDENT_POTENTIAL_RESULTS_v1.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'cases':[{k:c[k] for k in ['case','determinant','condition_2','column_normalized_condition_2','lambda','mu','nu','truth_after_fit','errors_after_fit','closed_form_same_precision','later','finite_positive_parameters']} for c in results]},indent=2))
