from pathlib import Path
import sympy as sp,json,datetime,hashlib
O=Path(__file__).resolve().parent
A,B,C,Ad,Bd,Cd,x,y,J,R,h,ST,VT=sp.symbols('A B C Ad Bd Cd x y J R h ST VT',real=True)
alpha=1+(x-y)/2;gamma=J*R+h*y
independent=Ad/2-y*Bd+y*y*Cd/2+alpha*A+(gamma-alpha*y)*B-gamma*y*C
row=sp.Matrix([[A/2,-A/2-Bd+(h-1)*B,Cd/2+B/2-h*C,B,-C]])
z=sp.Matrix([x,y,y*y,J*R-x*y/2,J*R*y]);root_expr=(row*z)[0]+Ad/2+A
checks=[]
def ck(n,e):
 e=sp.factor(e);checks.append({'name':n,'expression':str(e),'matched':e==0})
ck('author_row_equals_independent_elimination',root_expr-independent)
Bd_orig=-(1+x/2)*B-y*VT/2-J*R*C+h*B-(A+ST)/2
Cd_orig=2*h*C-B-VT
wanted=sp.Matrix([[A/2,x*B/2+ST/2+y*VT/2+J*R*C,-VT/2,B,-C]])
for i,e in enumerate(row.subs({Bd:Bd_orig,Cd:Cd_orig})-wanted):ck('author_rank_column_'+str(i+1),e)
oldrow=sp.Matrix([[A,-Bd,Cd/2,B,-C]])
transform=sp.Matrix([[sp.Rational(1,2),-sp.Rational(1,2),0,0,0],[0,1,0,0,0],[0,0,1,0,0],[0,h-1,sp.Rational(1,2),1,0],[0,0,h,0,1]])
for i,e in enumerate(row-oldrow*transform):ck('row_transform_'+str(i+1),e)
ck('row_transform_det_half',transform.det()-sp.Rational(1,2))
ck('square_closure',z[2]-z[1]**2)
ck('product_closure',z[4]-(z[3]+z[0]*z[1]/2)*z[1])
ck('reconstruct_R',(z[3]+z[0]*z[1]/2)/J-R)
# Exact feature map used in the author's open-set rank argument.
features=sp.Matrix([A,B,C,ST,VT]);mapping=wanted.jacobian(features)
det=sp.factor(mapping.det())
checks.append({'name':'physical_feature_map_invertible','expression':str(det),'matched':det!=0})
r={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Affected comparison only after independent covariance freeze; no repeat of the39 original controls and no author code/ODE run.','author_source_sha256':hashlib.sha256((O/'author_source_seen_v1/COVARIANCE_LIFT_v1.md').read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':checks,'matched':sum(c['matched'] for c in checks),'failed':sum(not c['matched'] for c in checks),'feature_map_determinant':str(det),'author_row_rank_witness_determinant':'(1+delta)*epsilon^10, by exact column transform from independent witness','author_ODE_runs':0}
p=O/'COVARIANCE_COMPARISON_RESULTS_v1.json';p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'matched':r['matched'],'failed':r['failed'],'feature_map_determinant':str(det),'unmatched':[c for c in checks if not c['matched']]},indent=2))
