from pathlib import Path
import sympy as sp
import json,datetime,hashlib
OUT=Path(__file__).resolve().parent
checks=[]
def ck(name,expr,zero=True):
 value=sp.factor(expr)
 ok=value==0 if zero else value!=0
 checks.append({'name':name,'expected':'zero' if zero else 'nonzero','expression':str(value),'matched':bool(ok)})
S,V,T,x,y,J,R,h,L=sp.symbols('S V T x y J R h L',real=True)
a=1+(x-y)/2;c=h*y+J*R
Sd=-(1+x/2)*S-y*T/2-J*R*V
Vd=h*V-(S+T)/2
W=L*V;Wd=L*Vd-2*(1+h)*L*V
ck('Euler_transformation_to_V',Wd+(2+h)*W+L*(S+T)/2)
ck('eliminated_field_identity',Sd-y*Vd+a*S+c*V)
ck('wrong_sign_yVprime_detected',Sd+y*Vd+a*S+c*V,False)
A,B,C,U,Z=sp.symbols('A B C U Z',real=True)
a0,c0=sp.symbols('a c',real=True)
# Direct second-moment product rule, U=C_(S,Vprime), Z=C_(V,Vprime).
Ad=2*y*U-2*a0*A-2*c0*B
Bd=U+y*Z-a0*B-c0*C
Cd=2*Z
constraint=Ad/2-y*Bd+y*y*Cd/2+a0*A+(c0-a0*y)*B-c0*y*C
ck('unknown_mixed_leg_eliminates',constraint)
ck('missing_variance_factor_two_detected',Ad-y*Bd+y*y*Cd/2+a0*A+(c0-a0*y)*B-c0*y*C,False)
# Independently form the moments from the original S,T,V evolution, without U,Z.
QSV,QTV=sp.symbols('C_ST C_VT',real=True)
Ad_orig=-2*(1+x/2)*A-y*QSV-2*J*R*B
Bd_orig=-(1+x/2)*B-y*QTV/2-J*R*C+h*B-(A+QSV)/2
Cd_orig=2*h*C-B-QTV
orig_constraint=Ad_orig/2-y*Bd_orig+y*y*Cd_orig/2+a*A+(c-a*y)*B-c*y*C
ck('independent_original_equation_moment_route',orig_constraint)
# Five explicitly realizable initial covariance matrices in (S,V,Vprime).
delta=sp.symbols('delta',positive=True)
points=[(-1,0),(-2,0),(-3,0),(-1,1),(-2,1)]
rows=[];rhs=[];covariances=[]
for i,(r,w) in enumerate(points):
 v=sp.Matrix([r,1,w]);cov=v*v.T+delta*sp.eye(3)
 Av,Bv,Cv=cov[0,0],cov[0,1],cov[1,1]
 Uv,Zv=cov[0,2],cov[1,2]
 Adv=Ad.subs({A:Av,B:Bv,C:Cv,U:Uv,Z:Zv})
 Bdv=Bd.subs({A:Av,B:Bv,C:Cv,U:Uv,Z:Zv})
 Cdv=Cd.subs({A:Av,B:Bv,C:Cv,U:Uv,Z:Zv})
 rows.append([Av,-Bdv,Cdv/2,Bv,-Cv]);rhs.append(-Adv/2)
 minors=[sp.factor(cov[:n,:n].det()) for n in [1,2,3]]
 covariances.append({'r':r,'w':w,'matrix':str(cov),'leading_principal_minors':[str(z) for z in minors]})
 for n,minor in enumerate(minors):
  checks.append({'name':f'covariance_{i+1}_positive_minor_{n+1}','expected':'positive for delta>0','expression':str(minor),'matched':minor.is_positive is True})
Dmat=sp.Matrix(rows);det=sp.factor(Dmat.det())
checks.append({'name':'five_row_rank_for_positive_delta','expected':'nonzero for delta>0','expression':str(det),'matched':det.is_zero is False})
z_expected=sp.Matrix([a0,y,y*y,c0-a0*y,c0*y])
for i,e in enumerate(Dmat*z_expected-sp.Matrix(rhs)):ck(f'five_row_exact_fit_{i+1}',e)
z_recovered=sp.simplify(Dmat.inv()*sp.Matrix(rhs))
for i,e in enumerate(z_recovered-z_expected):ck(f'lift_recovers_entry_{i+1}',e)
ck('lift_square_compatibility',z_recovered[2]-z_recovered[1]**2)
ck('lift_product_compatibility',z_recovered[4]-z_recovered[1]*(z_recovered[3]+z_recovered[0]*z_recovered[1]))
x_back=2*z_recovered[0]-2+z_recovered[1]
c_back=z_recovered[3]+z_recovered[0]*z_recovered[1]
R_back=(c_back-h*z_recovered[1])/J
ck('recovers_x',x_back.subs(a0,a)-x)
ck('recovers_R',R_back.subs({a0:a,c0:c})-R)
ck('frozen_point_y_zero_keeps_x_zero',x_back.subs({a0:1,y:0}))
# False lifted solution: independent square coordinate cannot silently pass closure.
ck('false_square_lift_rejected',(y*y+1)-y*y,False)
ck('false_product_lift_rejected',(c0*y+1)-y*((c0-a0*y)+a0*y),False)
result={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Independent exact covariance algebra and attainable-rank controls; no author helper or ODE, no measured data.','lift_order':['a','y','y^2','c-a*y','c*y'],'row_order':['C_SS','-C_SV_prime_total','C_VV_prime_total/2','C_SV','-C_VV'],'rank_witness_points':points,'rank_witness_covariances':covariances,'five_row_determinant':str(det),'checks':checks,'matched':sum(z['matched'] for z in checks),'failed':sum(not z['matched'] for z in checks),'author_new_covariance_source_read':False,'author_ODE_runs':0}
p=OUT/'COVARIANCE_CONTROL_RESULTS_v1.json';p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'matched':result['matched'],'failed':result['failed'],'determinant':str(det),'unmatched':[z for z in checks if not z['matched']]},indent=2))
