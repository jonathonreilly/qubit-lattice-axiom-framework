"""Read-only input binding; writes only new reviewer records/snapshots here.

This does not execute the scientific runner, validate a cache, mutate Git,
or confer a scientific/audit status.
"""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import os
import subprocess

OUT = Path(__file__).resolve().parent
WT = OUT.parents[5]
BLOCK = OUT.parent
PACK = BLOCK.parent
RT = Path('/Users/jonBridger/.codex/campaigns/observations-backward-24h-20261014')
PREV = PACK / 'growth_bridge/independent_source_v1'
CHECKS = []
IDENTITIES = {}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def record(path, scope):
    path = path.resolve()
    data = path.read_bytes()
    row = dict(path=str(path), bytes=len(data), sha256=digest(data), read_scope=scope)
    if str(path) in IDENTITIES:
        old = IDENTITIES[str(path)]
        assert old['sha256'] == row['sha256'], ('input changed within binding', str(path))
        if scope not in old['read_scope']:
            old['read_scope'] += '; ' + scope
    else:
        IDENTITIES[str(path)] = row
    return row


def check(name, actual, expected, **detail):
    CHECKS.append(dict(name=name, actual=actual, expected=expected,
                       matches=actual == expected, **detail))


def put(path, data):
    path = path.resolve()
    assert path.is_relative_to(OUT)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, ('immutable reviewer output already differs', str(path))
    else:
        with path.open('xb') as stream:
            stream.write(data)
    return path


def git(*args):
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
    return subprocess.check_output(['git', *args], cwd=WT, env=env)


refs = {r: git('rev-parse', r).decode().strip()
        for r in ['HEAD', 'origin/main', 'origin/ai/execution']}
for key, expected in {
    'HEAD': '4fa5b1497753b8a78a8dbdcbae4f025ce6a0b137',
    'origin/main': 'bbada1fe09b2d10d610560864d86b68c24a59713',
    'origin/ai/execution': '3a4b2c66a1ead7a1c48b4359627e968f681e3c39',
}.items():
    check('read-only ref', refs[key], expected, ref=key)

context = OUT / 'M14_READ_CONTEXT_v1'
for label, ref in {
    'CURRENT_MAIN_CAMPAIGN.md': 'origin/main:docs/ai_methodology/skills/physics-loop/references/CAMPAIGN.md',
    'CURRENT_MAIN_SCIENCE_WORKFLOW.md': 'origin/main:docs/ai_methodology/SCIENCE_WORKFLOW.md',
    'AI_EXECUTION_AGENTS.md': 'origin/ai/execution:AGENTS.md',
}.items():
    blob = git('show', ref)
    snap = put(context / label, blob)
    record(snap, 'Complete procedure read from pinned Git ref; no workflow/audit invoked')
    if label == 'CURRENT_MAIN_CAMPAIGN.md':
        check('CAMPAIGN brief identity', digest(blob), '172be2f4301d6f32edbf4f0bf55fdfb9e045098253c6a5b475fc4446816c6666')
record(WT / 'AGENTS.md', 'Complete root pointer read')

prior_notes = {
    'SCALAR_COSMOLOGICAL_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-15.md': 'e2873beca6af9954be49c4a9bbe8d98f05c9e69b',
    'SCALAR_GROWTH_LENSING_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-15.md': '4fa5b1497753b8a78a8dbdcbae4f025ce6a0b137',
    'EXPONENTIAL_SCALAR_FINITE_MODE_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md': refs['origin/main'],
    'EXPONENTIAL_SCALAR_DYNAMICAL_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-14.md': refs['origin/main'],
    'EXPONENTIAL_SCALAR_ACTION_SCALE_BOUNDED_THEOREM_NOTE_2026-10-14.md': refs['origin/main'],
    'EXPONENTIAL_SCALAR_STATE_COVARIANCE_BOUNDED_THEOREM_NOTE_2026-10-14.md': refs['origin/main'],
}
for name, ref in prior_notes.items():
    path = WT / 'docs' / name
    row = record(path, 'Complete actual prior note read for content comparison; not independently audited here')
    blob = git('show', f'{ref}:docs/{name}')
    check('prior source matches pinned Git', row['sha256'], digest(blob), path=str(path), ref=ref)
    record(put(context / 'prior_notes' / name, blob), 'Exact prior source snapshot')

previous_receipt = PREV / 'M13_CANONICAL_CLUSTER_IDENTITY_v1.json'
record(previous_receipt, 'Previous full-read identity evidence; old OPEN verdict not adopted')
prev = json.loads(previous_receipt.read_text())
reused_bodies = []
for old in prev['identities']:
    p = Path(old['path'])
    if '/M13_READ_CONTEXT_v1/runtime/' not in str(p) or p.name == 'PRS.json':
        continue
    actual = RT / p.name
    row = record(actual, 'Prior complete PR-body read reused after byte identity match')
    check('prior complete PR-body read reusable', row['sha256'], old['sha256'], path=str(actual))
    reused_bodies.append(row)
    record(put(context / 'runtime' / p.name, actual.read_bytes()), 'Exact reused PR-body snapshot')
check('twelve earlier campaign bodies', len(reused_bodies), 12)
for path in [RT / 'M13_PR_BODY_v1.md', RT / 'PRS.json', BLOCK / 'REPO_CONTEXT_v1.json']:
    record(path, 'Complete local context record read; not a live GitHub refresh')
    record(put(context / 'runtime' / path.name, path.read_bytes()), 'Exact current local PR/context snapshot')
check('thirteen existing local campaign entries', len(json.loads((RT / 'PRS.json').read_text())['prs']), 13)

for receipt_name in ['IDENTITY_RECEIPT_v1.json', 'COVARIANCE_IDENTITY_v1.json']:
    receipt = OUT / receipt_name
    record(receipt, 'Previously completed independent source/covariance evidence receipt')
    old = json.loads(receipt.read_text())
    rows = list(old.get('artifacts', [])) + list(old.get('reused_source_identities', []))
    for item in rows:
        if not isinstance(item, dict) or 'path' not in item or 'sha256' not in item:
            continue
        path = Path(item['path'])
        if not path.is_absolute():
            path = OUT / path
        row = record(path, 'Reused exact independent evidence or local primary source; original read limits apply')
        check('reused independent evidence identity', row['sha256'], item['sha256'], path=str(path))

for name in ['REPORT_v1.md', 'READ_SCOPE_v1.json', 'INDEPENDENT_ADMISSION_FREEZE_v1.json',
             'COVARIANCE_DERIVATION_v1.md', 'COVARIANCE_COMPARISON_v1.md',
             'COVARIANCE_FREEZE_v1.json', 'M14_CANONICAL_OBSERVATION_v1.json']:
    record(OUT / name, 'Complete reviewer conclusion/read scope or immutable source observation reused')

initial = json.loads((OUT / 'M14_CANONICAL_OBSERVATION_v1.json').read_text())
initial_rows = []
changes = []
expected_changes = {
    'docs/SCALAR_DYNAMICAL_MOMENTUM_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-15.md': '2133ec1786855f768c261f243f77c1fcc114001c4b583d1115fdec4defb6dd30',
    'scripts/scalar_dynamical_covariance.py': '091fb733a5529c3b5ea0e7f05814c00fb5a2835c31a8096619dd3170cade9d20',
    'scripts/scalar_dynamical_extensions.py': 'd74ae0ecf222446ae939b19d7e78b63cf7fda454c2a3fef3138037f7706d7a3a',
    'scripts/scalar_dynamical_momentum_inverse_check.py': 'cb233af6423d3dae7f35f2bc079df2b62c4720d599472326ff191026a645a8d0',
}
for old in initial['files']:
    snap = Path(old['snapshot'])
    row = record(snap, 'Initial exact source/output snapshot; read scopes distinguished in report')
    check('initial observed snapshot identity', row['sha256'], old['sha256'], path=str(snap))
    initial_rows.append(row)
    live = WT / old['path']
    new = record(live, 'Current byte identity only unless complete note/covariance helper or affected diff is specified in report')
    expected = expected_changes.get(old['path'], old['sha256'])
    check('closing bytes match actually read version', new['sha256'], expected, path=str(live))
    if new['sha256'] != old['sha256']:
        preserved = put(OUT / 'M14_AFFECTED_SEEN_v1' / old['path'], live.read_bytes())
        delta = ''.join(difflib.unified_diff(snap.read_text().splitlines(True), live.read_text().splitlines(True),
                                           fromfile='initial-frozen-v1/' + old['path'],
                                           tofile='subsequently-observed/' + old['path']))
        dp = put(OUT / 'M14_AFFECTED_SEEN_v1/diffs' / (live.name + '.diff'), delta.encode())
        record(preserved, 'Exact changed source snapshot; complete affected diff read')
        record(dp, 'Entire source delta read; not an execution result')
        changes.append(dict(path=old['path'], initial_sha256=old['sha256'], observed_sha256=new['sha256'],
                            snapshot=str(preserved), diff=str(dp), initial_output_covers_new_bytes=False))
check('four observed source deltas', len(changes), 4)
record(BLOCK / 'CANONICAL_SOURCE_FREEZE_v1.json', 'Complete original nine-path source freeze')
record(OUT / 'M14_CANONICAL_SEEN_v1/CANONICAL_SOURCE_FREEZE_v1.json', 'Immutable original source-freeze snapshot')

result = json.loads((OUT / 'M14_CANONICAL_SEEN_v1/outputs/scalar_dynamical_momentum_inverse/RESULTS_v1.json').read_text())
summary = json.loads((OUT / 'M14_CANONICAL_SEEN_v1/outputs/scalar_dynamical_momentum_inverse/SUMMARY_v1.json').read_text())
frozen_hashes = {r['path']: r['sha256'] for r in initial['files'] if r['frozen_sha256'] is not None}
for path, value in result['input_sha256'].items():
    check('v1 result declared input matches original source', value, frozen_hashes[path], path=path)
check('v1 result primary matches original source', result['primary_sha256'],
      frozen_hashes['scripts/scalar_dynamical_momentum_inverse_check.py'])
check('v1 check count', len(result['checks']), 81)
check('v1 author failed count', sum(not c['passed'] for c in result['checks']), 0)
check('v1 empirical tests', result['empirical_tests'], 0)
check('v1 result-summary counts', summary['counts'], result['counts'])

verdict_path = OUT / 'M14_CLUSTER_CAP_VERDICT_v1.md'
verdict = verdict_path.read_text()
words = len(verdict.split()) - 1
check('verdict first line', verdict.splitlines()[0], 'OPEN')
check('verdict requested word range', 200 <= words <= 400, True)
for p in [verdict_path, OUT / 'M14_CANONICAL_SCOPE_REVIEW_v1.md', Path(__file__)]:
    record(p, 'New reviewer-owned verdict, full scoped report or reproducible identity binder')

receipt = {
    'schema': 'm14-canonical-observation-covariance-cluster-review-v1',
    'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer': '/root/launch_check',
    'verdict': 'OPEN',
    'verdict_word_count': words,
    'verdict_scope': 'Coherent PR opening only; no scientific/audit status, empirical result, final cache or landing acceptance',
    'scope_result': 'No material observational overclaim or covariance-proof wording error in reviewed source; later executable binding pending',
    'git_refs_read_only': refs,
    'initial_note_sha256': frozen_hashes['docs/SCALAR_DYNAMICAL_MOMENTUM_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-15.md'],
    'affected_note_sha256': expected_changes['docs/SCALAR_DYNAMICAL_MOMENTUM_INVERSE_BOUNDED_THEOREM_NOTE_2026-10-15.md'],
    'source_changes_during_review': changes,
    'paired_output_read_scope': {
        'counts': result['counts'], 'empirical_tests': result['empirical_tests'],
        'complete_short_summary': True, 'all_named_checks': True,
        'six_covariance_rows_and_reconstruction': True, 'background_and_candidate_summaries': True,
        'trajectory_arrays': 'Preserved and hashed; not individually independently verified by this reviewer',
        'covers_current_changed_executables': False,
    },
    'reused_independent_controls': {'pre_author_covariance': {'matched': 39, 'failed': 0},
                                  'post_author_correspondence': {'matched': 16, 'failed': 0},
                                  'rerun_in_this_continuation': False},
    'prior_science_context': list(prior_notes),
    'prior_campaign_context': {'existing_prs_conservatively_same_family': 13,
                              'twelve_body_full_reads_reused_after_hash_match': True,
                              'm13_body_and_registry_read_now': True,
                              'fresh_live_GitHub_status_claim': False},
    'identity_checks': CHECKS,
    'identity_checks_matched': sum(c['matches'] for c in CHECKS),
    'identity_checks_failed': sum(not c['matches'] for c in CHECKS),
    'artifacts': sorted(IDENTITIES.values(), key=lambda v: v['path']),
    'artifact_count': len(IDENTITIES),
    'science_runs': 0,
    'new_source_acquisitions': 0,
    'git_mutations': 0,
    'author_source_edits': 0,
    'formal_audit_or_aggregate_gates': 0,
    'required_later_work': ['Affected executable execution/mutation closure and final cache binding',
                            'Final frozen source and evidence inventory confirmation',
                            'Integrated-current-main landing validation'],
    'publication_limit': 'External primary PDFs, extracted text and renders remain local; no full-paper republication',
    'allowed_write_root': str(OUT),
    'receipt_self_hash_excluded': True,
}
target = OUT / 'M14_CANONICAL_CLUSTER_IDENTITY_v1.json'
put(target, (json.dumps(receipt, indent=2, sort_keys=True) + '\n').encode())
closing = []
for p in [verdict_path, OUT / 'M14_CANONICAL_SCOPE_REVIEW_v1.md', target, Path(__file__)]:
    closing.append(f'{digest(p.read_bytes())}  {p.name}')
put(OUT / 'M14_CANONICAL_FINAL_SHA256_v1.txt', ('\n'.join(closing) + '\n').encode())
print(json.dumps({'identity_checks_matched': receipt['identity_checks_matched'],
                  'identity_checks_failed': receipt['identity_checks_failed'],
                  'artifact_count': receipt['artifact_count'], 'verdict_word_count': words,
                  'receipt_sha256': digest(target.read_bytes()), 'file_hashes': closing,
                  'failed_checks': [c for c in CHECKS if not c['matches']]}, indent=2))
