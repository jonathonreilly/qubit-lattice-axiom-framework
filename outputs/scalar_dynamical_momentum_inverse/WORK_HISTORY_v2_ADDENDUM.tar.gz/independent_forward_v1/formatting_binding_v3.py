"""Formatting/source/output identity comparison only; no science import or execution."""
from pathlib import Path
import ast,hashlib,json,datetime
W=Path.cwd().resolve();D=W/'.claude/science/physics-loops/observations-backward-24h-20261014/dynamical_response';O=D/'independent_forward_v1';A=O/'canonical_source_v2';B=O/'canonical_source_v3'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
freeze=read(D/'CANONICAL_SOURCE_FREEZE_v3.json');formatting=read(D/'FINAL_FORMATTING_IDENTITY_v1.json')
B.mkdir(exist_ok=False);saved={}
for rel,info in freeze['files'].items():
 p=W/rel;bb=p.read_bytes();assert hashlib.sha256(bb).hexdigest()==info['sha256'] and len(bb)==info['bytes'];rp=p.relative_to(W);q=B/rp;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(bb);saved[str(rp)]={'sha256':info['sha256'],'bytes':len(bb)}
for name in ['CANONICAL_SOURCE_FREEZE_v3.json','FINAL_FORMATTING_IDENTITY_v1.json']:
 p=D/name;q=B/p.relative_to(W);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes());saved[str(p.relative_to(W))]={'sha256':sha(p),'bytes':p.stat().st_size}
checks=[]
def check(name,ok,detail=None):checks.append({'name':name,'passed':bool(ok),'detail':detail})
primary='scripts/scalar_dynamical_momentum_inverse_check.py';tree=ast.parse((B/primary).read_text());paths=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in n.targets))
changed={v['path'] for v in formatting['changes']};actual={r for r in [primary,*paths] if (A/r).read_bytes()!=(B/r).read_bytes()}
check('exact_four_changed_paths',actual==changed and len(changed)==4)
for row in formatting['changes']:
 r=row['path'];a=(A/r).read_text();b=(B/r).read_text();check('formatting_identity_hashes:'+r,sha(A/r)==row['before_sha256'] and sha(B/r)==row['after_sha256'])
 if r.endswith('.py'):
  check('only_terminal_empty_lines:'+r,b==a.rstrip('\n')+'\n');check('AST_exact_equal:'+r,ast.dump(ast.parse(a),include_attributes=False)==ast.dump(ast.parse(b),include_attributes=False))
 else:
  old=a.splitlines(True);new=b.splitlines(True);changes=[i+1 for i,(u,v) in enumerate(zip(old,new)) if u!=v];check('only_three_metadata_hard_break_spaces',len(old)==len(new) and changes==[3,4,5] and all(old[i-1]==new[i-1].rstrip('\n')+'  \n' for i in changes),changes);check('note_word_tokens_equal',a.split()==b.split())
r2=read(A/'outputs/scalar_dynamical_momentum_inverse/RESULTS_v1.json');r3=read(B/'outputs/scalar_dynamical_momentum_inverse/RESULTS_v1.json');s2=read(A/'outputs/scalar_dynamical_momentum_inverse/SUMMARY_v1.json');s3=read(B/'outputs/scalar_dynamical_momentum_inverse/SUMMARY_v1.json')
check('all_nonidentity_results_exactly_equal',{k:v for k,v in r2.items() if k!='input_sha256'}=={k:v for k,v in r3.items() if k!='input_sha256'});check('all_nonidentity_summary_exactly_equal',{k:v for k,v in s2.items() if k!='input_sha256'}=={k:v for k,v in s3.items() if k!='input_sha256'});check('all_85_checks_unchanged_pass',r3['counts']=={'passed':85,'failed':0} and len(r3['checks'])==85 and r3['checks']==r2['checks'] and all(c['passed'] for c in r3['checks']))
check('all_56_modes_14_epochs_potential_unchanged',r2['cases']==r3['cases'] and r2['potential_diagnostics']==r3['potential_diagnostics'] and sum(len(e['rows']) for c in r3['cases'] for e in c['epochs'])==56 and sum(len(c['epochs']) for c in r3['cases'])==14)
ids={r:sha(B/r) for r in paths};check('result_input_source_ids_current',ids==r3['input_sha256'] and sha(B/primary)==r3['primary_sha256']);check('summary_input_source_ids_current',ids==s3['input_sha256'] and sha(B/primary)==s3['primary_sha256'])
h=hashlib.sha256(b'runner-cache-input-fingerprint-v1\0')
for rel in paths:
 rb=rel.encode();bb=(B/rel).read_bytes();h.update(len(rb).to_bytes(8,'big'));h.update(rb);h.update(len(bb).to_bytes(8,'big'));h.update(bb)
cache=(B/'logs/runner-cache/scalar_dynamical_momentum_inverse_check.txt').read_text();head=cache.split('----- stdout -----')[0];hdr={ln.split(': ',1)[0]:ln.split(': ',1)[1] for ln in head.splitlines() if ': ' in ln};stdout=cache.split('----- stdout -----\n',1)[1].split('----- stderr -----',1)[0];cachejson=json.JSONDecoder().raw_decode(stdout[stdout.index('{'):])[0]
check('cache_primary_fingerprint_current',hdr['runner_sha256']==sha(B/primary) and hdr['input_fingerprint_sha256']==h.hexdigest());check('cache_stdout_equals_summary',cachejson==s3);check('execution_stdout_plus_exact_separator',freeze['execution']['stdout']+'\n'==stdout);check('cache_success_receipt_within_timeout',hdr['status']=='ok' and hdr['exit_code']=='0' and hdr['timeout_sec']=='180' and freeze['execution']['status']=='ok' and freeze['execution']['exit_code']==0 and freeze['execution']['timeout_sec']==180 and freeze['execution']['elapsed_sec']<180)
check('all_final_live_bytes_equal_snapshots',all((W/rel).read_bytes()==(B/rel).read_bytes() for rel in saved))
record={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Formatting-only v2-to-v3 comparison and current source/cache/product binding. No ODE, mathematics, raw data or mutation rerun.','checker_sha256':sha(Path(__file__)),'files':saved,'checks':checks,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'recomputed_input_fingerprint':h.hexdigest(),'cache_header':hdr,'exact_elapsed_seconds':freeze['execution']['elapsed_sec'],'prior_v2_report_sha256':sha(O/'CANONICAL_SUPPLEMENT_v2.md'),'prior_v2_identity_sha256':sha(O/'CANONICAL_IDENTITY_v2.json')}
(O/'FORMATTING_BINDING_RESULTS_v3.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k] for k in ['passed','failed','recomputed_input_fingerprint','cache_header','exact_elapsed_seconds']},indent=2));assert all(c['passed'] for c in checks)
