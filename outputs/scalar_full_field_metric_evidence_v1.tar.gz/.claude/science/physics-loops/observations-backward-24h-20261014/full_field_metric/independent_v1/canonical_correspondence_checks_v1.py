"""Post-exposure formula correspondence; independent symbolic oracle, no author ODE/aggregate."""
from pathlib import Path
import ast,hashlib,json
import sympy as S
import mpmath as mp
O=Path(__file__).resolve().parent
source=(O/'CANONICAL_EXPOSURE_v1__scalar_full_field_metric.py').read_bytes()
selected={'constants','replaced','jordan','einstein','metric_parts','invert'}
tree=ast.parse(source)
ns={'mp':mp}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in selected],type_ignores=[]),'<frozen canonical functions>','exec'),ns)
mp.mp.dps=50
rows=[]
def to_mp(x):return mp.mpf(str(S.N(x,65)))
def compare(name,actual,expected):
 want=to_mp(expected);err=abs(actual-want)/max(1,abs(want))
 rows.append({'name':name,'passed':bool(err<mp.mpf('1e-43')),'scaled_error':str(err)})
r=S.symbols('r',positive=True)
e=r/S.Integer(9)+r*r/25+r**3/110
b=S.Rational(4,5)+r/20+r*r/70
A=S.diff(e,r);bp=S.diff(b,r)
gt=(b-1)/r**2+bp/r;gr=(b-1)/r**2+2*b*A/r
ga=b*(S.diff(A,r)+A*A+A/r)+bp*(A+1/r)/2
u=(ga-gt)/(b*(1/r-A));up=S.diff(u,r)
h=gr-gt-b*(up+u*u)-(bp/2-b*A)*u
wmetric=-gt-h/2-b*(up+u*u)-(bp/2+2*b/r)*u
curvature=-(gt+gr+2*ga)
fixtures=[]
for i,(rr,k,z) in enumerate([(S.Integer(1),S.Rational(1,10),S.Rational(3,4)),(S.Rational(3,2),S.Rational(11,50),S.Rational(7,5))]):
 a=(1-k)*(1+3*k)/4;s=(1+k)/(k*(1-3*k));lam=a/(1-3*a)
 hv=S.Rational(3,100);nu0=S.Rational(6,5);xx=s+z*z
 metric=[rr,b.subs(r,rr),bp.subs(r,rr),S.diff(b,r,2).subs(r,rr),A.subs(r,rr),S.diff(A,r).subs(r,rr),S.diff(A,r,2).subs(r,rr)]
 got=ns['invert'](list(map(to_mp,metric)),list(map(to_mp,[k,hv,nu0])),to_mp(xx))
 ui=u.subs(r,rr);upi=up.subs(r,rr);hi=h.subs(r,rr);bb=b.subs(r,rr);aa=A.subs(r,rr);bbp=bp.subs(r,rr)
 zp=xx*ui/(2*z);zpp=xx*(upi+ui*ui)/(2*z)-xx*xx*ui*ui/(4*z**3)
 T=xx*hi/2-bb*zp*zp/lam
 p0=hv**2*(3*(s+z**4)+nu0*z**4*S.log(z)**2/a)
 p0z=hv**2*z**3*(12+nu0*(4*S.log(z)**2+2*S.log(z))/a)
 delta=xx*wmetric.subs(r,rr)-p0
 # This oracle uses the independently derived LX form, not author Lz expression.
 LX=xx*(bb*(upi+ui*ui)+(bbp/2+bb*aa+2*bb/rr)*ui)
 E=LX/(lam*z)+z*curvature.subs(r,rr)-xx*hi/z-p0z
 lx=4*z/xx+(1-k)/(a*z);ly=4*z/xx+(1+k)/(a*z)
 Ux=(ly*delta-E)/(ly-lx);Uy=(E-lx*delta)/(ly-lx)
 Ax=hv**2*k*xx**2*z**((1-k)/a)/(1+s);Ay=2*hv**2*k*xx**2*z**((1+k)/a)/(3*(1+s))
 expect={'z':z,'zp':zp,'zpp':zpp,'T':T,'Delta':delta,'E':E,'lx':lx,'ly':ly,'Ux':Ux,'Uy':Uy,'x2':Ux/Ax,'y2':Uy/Ay}
 for key,val in expect.items():compare(f'fixture{i}:{key}',got[key],val)
 fixtures.append({'r':str(rr),'k':str(k),'z':str(z),'scope':'Supplied synthetic metric jet; no assertion of candidate solution or envelope admission'})
 # Independent full action coefficients and Einstein kinetic convention.
 vals=[z,S.Rational(2,5),S.Rational(-1,3)]
 dg=1+2*(1+k)*(vals[1]**2+vals[2]**2)/3
 q=[1/lam,(1+s)*z*z*4*k/(9*dg),(1+s)*z*z*k/(3*dg)]
 jx,jq,jp=ns['jordan'](list(map(to_mp,vals)),list(map(to_mp,[k,hv,nu0])))
 compare(f'fixture{i}:Jordan_P',jp,p0+Ax*vals[1]**2+Ay*vals[2]**2)
 for n in range(3):compare(f'fixture{i}:Jordan_q{n}',jq[n],q[n])
 eh,ep=ns['einstein'](list(map(to_mp,vals)),list(map(to_mp,[k,hv,nu0])))
 for n in range(3):compare(f'fixture{i}:Einstein_h{n}',eh[n],2*q[n]/xx+(6*z*z/xx**2 if n==0 else 0))
# Direct function-domain probes, not invoking author controls or any generator.
good_metric=list(map(to_mp,metric));good_pars=list(map(to_mp,[k,hv,nu0]));good_x=to_mp(xx)
cases=[]
for name,field,value in [('nan_metric',0,mp.nan),('negative_radius',0,mp.mpf(-1)),('negative_B',1,mp.mpf(-1))]:
 m=good_metric.copy();m[field]=value;cases.append((name,m,good_pars,good_x))
for name,index,value in [('zero_k',0,mp.mpf(0)),('upper_k',0,mp.mpf(1)/3),('zero_Hv',1,mp.mpf(0)),('negative_nu',2,mp.mpf(-1)),('infinite_nu',2,mp.inf)]:
 p=good_pars.copy();p[index]=value;cases.append((name,good_metric,p,good_x))
cases.extend([('zero_z',good_metric,good_pars,ns['constants'](good_pars[0])[1]),('complex_amplitude',good_metric,good_pars,mp.mpc(1,1))])
m=good_metric.copy();m[4]=1/m[0];cases.append(('singular_chart',m,good_pars,good_x))
for name,m,p,x in cases:
 try:ns['invert'](m,p,x);ok=False
 except ValueError:ok=True
 rows.append({'name':'domain:'+name,'passed':ok})
protocol=json.loads((O/'CANONICAL_EXPOSURE_v1__PROTOCOL_v1.json').read_text())
rows.append({'name':'current_protocol_precision_and_tolerance_match_source','passed':protocol['precision_digits']==50 and protocol['residual_tolerance']=='1e-35' and 'mp.mp.dps = 50' in source.decode() and "mp.mpf('1e-35')" in source.decode()})
result={'scope':'Post-exposure source/formula comparison using independently differentiated synthetic metric jets and frozen canonical function ASTs. No author ODE, aggregate or observed data run.','source_sha256':hashlib.sha256(source).hexdigest(),'oracle_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'fixtures':fixtures,'counts':{'passed':sum(t['passed'] for t in rows),'failed':sum(not t['passed'] for t in rows)},'checks':rows}
with (O/'CANONICAL_CORRESPONDENCE_RESULTS_v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'counts':result['counts'],'max_scaled_error':str(max(mp.mpf(t.get('scaled_error','0')) for t in rows))},indent=2))
assert not result['counts']['failed']
