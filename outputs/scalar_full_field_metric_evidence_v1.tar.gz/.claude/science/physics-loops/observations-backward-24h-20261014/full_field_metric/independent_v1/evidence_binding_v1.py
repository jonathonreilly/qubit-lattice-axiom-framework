"""Read-only binding of M20 saved source/cache/products/mutants; no scientific execution."""
from pathlib import Path
from datetime import datetime
from decimal import Decimal
import ast,hashlib,json
O=Path(__file__).resolve().parent
W=Path('/Users/jonBridger/.codex/worktrees/observations-backward-24h-20261014/New Axioms Lets Go')
A=W/'.claude/science/physics-loops/observations-backward-24h-20261014/full_field_metric'
sha=lambda b:hashlib.sha256(b).hexdigest()
files=[]
def capture(p,name):
 b=p.read_bytes()
 with (O/name).open('xb') as f:f.write(b)
 files.append({'path':str(p.relative_to(W)),'snapshot':name,'sha256':sha(b),'bytes':len(b)})
 return b
rb=capture(A/'GUARDED_EXECUTION_v1.json','EVIDENCE_EXPOSURE_v1__GUARDED_EXECUTION_v1.json');run=json.loads(rb)
mb=capture(A/'MUTATIONS_v1.json','EVIDENCE_EXPOSURE_v1__MUTATIONS_v1.json');mut=json.loads(mb)
handoff=capture(A/'HANDOFF.md','EVIDENCE_EXPOSURE_v1__HANDOFF.md').decode()
initial=json.loads(capture(A/'EXECUTION_v1.json','EVIDENCE_EXPOSURE_v1__EXECUTION_v1.json'))
result=json.loads(capture(W/'outputs/scalar_full_field_metric/RESULTS_v1.json','EVIDENCE_EXPOSURE_v1__RESULTS_v1.json'))
summary=json.loads(capture(W/'outputs/scalar_full_field_metric/SUMMARY_v1.json','EVIDENCE_EXPOSURE_v1__SUMMARY_v1.json'))
cache=capture(W/'logs/runner-cache/scalar_full_field_metric_check.txt','EVIDENCE_EXPOSURE_v1__scalar_full_field_metric_check.txt')
manifest=json.loads((O/'CANONICAL_EXPOSURE_v1.json').read_text())
for row in manifest['files']:
 assert (W/row['path']).read_bytes()==(O/row['snapshot']).read_bytes()
 assert sha((O/row['snapshot']).read_bytes())==row['sha256']
primary=(W/'scripts/scalar_full_field_metric_check.py').read_bytes()
helper=(W/'scripts/scalar_full_field_metric.py').read_bytes()
paths=next(ast.literal_eval(n.value) for n in ast.parse(primary).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in n.targets))
assert len(paths)==len(set(paths))==5
h=hashlib.sha256(b'runner-cache-input-fingerprint-v1\0');inputs={}
for path in paths:
 b=(W/path).read_bytes();pb=path.encode();inputs[path]=sha(b)
 h.update(len(pb).to_bytes(8,'big'));h.update(pb);h.update(len(b).to_bytes(8,'big'));h.update(b)
identity={'runner_sha256':sha(primary),'input_fingerprint_sha256':h.hexdigest()}
assert run['before']==run['after'] and run['before']['content']==identity
assert inputs==result['input_sha256']==summary['input_sha256']
assert result['primary_sha256']==summary['primary_sha256']==sha(primary)
assert sha(cache)==run['cache_sha256'] and run['cache_status']=='fresh'
head,tail=cache.decode().split('----- stdout -----\n',1);stdout,stderr=tail.split('\n----- stderr -----\n',1)
meta=dict(l.split(': ',1) for l in head.splitlines() if ': ' in l)
r=run['result']
assert meta['runner_sha256']==identity['runner_sha256'] and meta['input_fingerprint_sha256']==identity['input_fingerprint_sha256']
assert meta['status']==r['status']=='ok' and meta['exit_code']=='0' and r['exit_code']==0
assert meta['timeout_sec']=='120' and r['timeout_sec']==120
assert format(r['elapsed_sec'],'.2f')==meta['elapsed_sec'] and 0<r['elapsed_sec']<120
assert stdout.rstrip('\n')==r['stdout'].rstrip('\n') and not stderr.strip() and not r['stderr']
assert json.JSONDecoder().raw_decode(stdout[stdout.index('{'):])[0]==summary
assert {k:v for k,v in result.items() if k not in ['cases','checks']}=={k:v for k,v in summary.items() if k!='failed_checks'}
assert result['counts']==summary['counts']=={'passed':31,'failed':0} and summary['failed_checks']==[]
assert len(result['checks'])==31 and all(x['passed'] for x in result['checks'])
assert len({x['name'] for x in result['checks']})==31
protocol=json.loads((W/paths[2]).read_text())
assert [x['case'] for x in result['cases']]==protocol['fixed_cases']
for i,case in enumerate(result['cases']):
 assert len(case['original_equations'])==6 and len(case['metric_jets'])==7
 for j,v in enumerate(case['original_equations']):
  assert abs(Decimal(v))<Decimal('1e-35')
  assert next(x for x in result['checks'] if x['name']==f'{i}:original_full_field_equation_{j}')['error']==str(abs(Decimal(v))) or abs(Decimal(next(x for x in result['checks'] if x['name']==f'{i}:original_full_field_equation_{j}')['error'])-abs(Decimal(v)))<Decimal('1e-75')
 t=case['reconstructed'];assert Decimal(t['T'])>0 and Decimal(t['Delta'])>0
 assert Decimal(t['lx'])*Decimal(t['Delta'])<Decimal(t['E'])<Decimal(t['ly'])*Decimal(t['Delta'])
assert len([x for x in result['checks'] if x['name'].startswith('domain:')])==7
start=datetime.fromisoformat(run['started_at']);end=datetime.fromisoformat(run['completed_at'])
assert end>start and (end-start).total_seconds()>=r['elapsed_sec']
assert 'captured after the subprocess completed' in handoff and 'completion' in handoff
assert initial['exit_code']==0 and initial['timeout_seconds']==120
assert initial['stdout_sha256']==sha(r['stdout'].encode()) and initial['stderr_sha256']==sha(b'')
for path,value in initial['sources'].items():assert sha((W/path).read_bytes())==value
# All candidate bytes differ from reviewed baseline by exactly the recorded replacement.
assert mut['canonical_source_sha256']==sha(helper) and mut['rejected']==8 and mut['survivors']==[] and len(mut['variants'])==8
mutation_records=[];wrapper_reference=None
for variant in mut['variants']:
 d=A/'mutations_v1'/variant['name'];old,new=variant['replacement'];source=helper.decode()
 assert source.count(old)==1
 candidate=(d/'candidate.py').read_bytes()
 assert source.replace(old,new,1).encode()==candidate and sha(candidate)==variant['source_sha256']
 wrapper=(d/'run.py').read_bytes()
 if wrapper_reference is None:wrapper_reference=wrapper
 assert wrapper==wrapper_reference
 assert "r=candidate.controls(Path(" in wrapper.decode() and str(A/'PROTOCOL_v1.json') in wrapper.decode()
 out=(d/'stdout.txt').read_bytes();err=(d/'stderr.txt').read_bytes();raw=json.loads(out)
 assert not err and variant['exit_code']==0 and variant['exception_only'] is False and variant['rejected_by_control'] is True
 assert raw['passed']+len(raw['failed'])==31 and len(raw['failed'])==variant['failed_controls']>0
 assert all(x['passed'] is False for x in raw['failed'])
 for x in raw['failed']:
  if 'error' in x:assert Decimal(x['error'])>=Decimal('1e-35')
 mutation_records.append({'name':variant['name'],'replacement':variant['replacement'],'source_sha256':sha(candidate),'wrapper_sha256':sha(wrapper),'stdout_sha256':sha(out),'stderr_sha256':sha(err),'failed_controls':raw['failed'],'passed_count':raw['passed'],'entire_candidate_matches_single_declared_replacement':True,'exception_only':False})
receipt={'scope':'Saved evidence correspondence only; no scientific, ODE, mutation or aggregate rerun','identity':identity,'declared_inputs':inputs,'cache_sha256':sha(cache),'counts_as_saved':result['counts'],'elapsed_sec_as_saved':r['elapsed_sec'],'timeout_sec':r['timeout_sec'],'guarded_start':run['started_at'],'guarded_end':run['completed_at'],'recorded_before_after_content_and_stat_equality':True,'initial_started_at_disclosed_as_post_run':True,'mutation_records':mutation_records,'frozen_evidence_files':files,'source_sha256':sha(Path(__file__).read_bytes())}
with (O/'EVIDENCE_BINDING_RESULTS_v1.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'counts':result['counts'],'mutations_with_actual_false_controls':len(mutation_records),'cache_sha256':sha(cache),'fingerprint':h.hexdigest(),'elapsed':r['elapsed_sec']},indent=2))
