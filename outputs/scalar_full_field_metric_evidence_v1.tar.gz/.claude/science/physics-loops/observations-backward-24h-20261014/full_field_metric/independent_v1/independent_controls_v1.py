"""Independent exact controls for a necessary full-field radial metric envelope.
No author implementation, observational data, ODE or external source access.
"""
from pathlib import Path
import hashlib,json
import sympy as S
O=Path(__file__).resolve().parent
checks=[]
def exact(name,value):
 value=S.simplify(value)
 checks.append({'name':name,'passed':value==0,'residual':str(value)})
def yes(name,value,**extra):
 checks.append({'name':name,'passed':bool(value),**extra})
z,s,lam,B,A,Bp,r,u,up,H,R=S.symbols('z s lambda B A Bp r u up H R',positive=True)
k,a,h2,nu=S.symbols('k a h2 nu',positive=True)
x,y,xp,yp=S.symbols('x y xp yp',real=True,nonzero=True)
rx=(1-k)/a;ry=(1+k)/a
w=s+z*z
D=1+2*(1+k)*(x*x+y*y)/3
hx=(1+s)*z*z*4*k/(9*D);hy=(1+s)*z*z*k/(3*D)
Ax=h2*k*w*w*z**rx/(1+s);Ay=2*h2*k*w*w*z**ry/(3*(1+s))
P0=h2*(3*(s+z**4)+nu*z**4*S.log(z)**2/a)
exact('transverse_z_kinetic_x_derivative',S.diff(hx,z)-2*hx/z)
exact('transverse_z_kinetic_y_derivative',S.diff(hy,z)-2*hy/z)
ellx=4*z/w+rx/z;elly=4*z/w+ry/z
exact('positive_potential_log_derivative_x',S.diff(Ax,z)-ellx*Ax)
exact('positive_potential_log_derivative_y',S.diff(Ay,z)-elly*Ay)
exact('distinct_log_derivative_gap',elly-ellx-2*k/(a*z))
exact('base_potential_derivative',S.diff(P0,z)-h2*(12*z**3+nu*z**3*(4*S.log(z)**2+2*S.log(z))/a))
# Full physical gradient energy, i.e. B times the radial coordinate kinetic density.
T=B*(hx*xp*xp+hy*yp*yp)
exact('z_gradient_source',B*(S.diff(hx,z)*xp*xp+S.diff(hy,z)*yp*yp)-2*T/z)
# Reconstruct metric equations from the angular/time and radial/time differences.
gt,gr=S.symbols('Gt Gr',real=True)
geoD=B*(1/r-A);ga=gt+geoD*u
HH=gr-gt-B*(up+u*u)-(Bp/2-B*A)*u
KK=w*HH/2
PP=w*(-gt-HH/2-B*(up+u*u)-(Bp/2+2*B/r)*u)
Et=w*gt+KK+PP+B*w*(up+u*u)+(Bp/2+2*B/r)*w*u
Er=w*gr-KK+PP+B*(A+2/r)*w*u
Ea=w*ga+KK+PP+B*w*(up+u*u)+(Bp/2+B*A+B/r)*w*u
exact('metric_time_reconstruction',Et)
exact('metric_radial_reconstruction',Er)
exact('metric_angular_reconstruction',Ea)
# F'/F=u gives the radial field derivatives for each positive amplitude w>s.
zp=w*u/(2*z)
zpp=w*(up+u*u)/(2*z)-w*w*u*u/(4*z**3)
exact('first_field_identity',2*z*zp-w*u)
exact('second_field_identity',2*z*zpp+2*zp*zp-w*(up+u*u))
C=Bp/2+B*A+2*B/r
Lz=B*zpp+C*zp
Lw=w*(B*(up+u*u)+C*u)
Trec=w*H/2-B*zp*zp/lam
E=2*Lz/lam+z*R-2*Trec/z-S.diff(P0,z)
Esimple=Lw/(lam*z)+z*R-w*H/z-S.diff(P0,z)
exact('residual_without_explicit_second_field_derivative',E-Esimple)
# Two nonnegative potential pieces and their exact inverse.
Ux,Uy,Delta,Ee=S.symbols('Ux Uy Delta E',real=True)
ux=(elly*Delta-Ee)/(elly-ellx);uy=(Ee-ellx*Delta)/(elly-ellx)
exact('potential_sum_inverse',ux+uy-Delta)
exact('potential_z_derivative_inverse',ellx*ux+elly*uy-Ee)
exact('recover_Ux',ux.subs({Delta:Ux+Uy,Ee:ellx*Ux+elly*Uy})-Ux)
exact('recover_Uy',uy.subs({Delta:Ux+Uy,Ee:ellx*Ux+elly*Uy})-Uy)
exact('lower_envelope_remainder',(ellx*Ux+elly*Uy)-ellx*(Ux+Uy)-(elly-ellx)*Uy)
exact('upper_envelope_remainder',elly*(Ux+Uy)-(ellx*Ux+elly*Uy)-(elly-ellx)*Ux)
# Squared fields imply a further derivative/kinetic compatibility, not sufficiency.
Tfromsquares=B*(1+s)*k*z*z/D*((2*x*xp)**2/(9*x*x)+(2*y*yp)**2/(12*y*y))
exact('kinetic_compatibility_of_positive_squares',T-Tfromsquares)
# Independent exact positive rational local algebra fixture, not a spacetime solution.
ks=S.Rational(1,10);aa=(1-ks)*(1+3*ks)/4;ss=(1+ks)/(ks*(1-3*ks))
sub={k:ks,a:aa,s:ss,z:S.Integer(1),h2:S.Rational(1,100),nu:S.Rational(7,5)}
ax=S.simplify(Ax.subs(sub));ay=S.simplify(Ay.subs(sub));lx=S.simplify(ellx.subs(sub));ly=S.simplify(elly.subs(sub))
del0=4*ax+9*ay;ee0=lx*4*ax+ly*9*ay
exact('fixture_reconstructed_x_squared',(ly*del0-ee0)/(ly-lx)/ax-4)
exact('fixture_reconstructed_y_squared',(ee0-lx*del0)/(ly-lx)/ay-9)
yes('fixture_strict_lower_envelope',lx*del0<ee0)
yes('fixture_strict_upper_envelope',ee0<ly*del0)
yes('below_lower_envelope_negative_y_piece',((lx*del0-1)-lx*del0)/(ly-lx)<0)
yes('above_upper_envelope_negative_x_piece',(ly*del0-(ly*del0+1))/(ly-lx)<0)
exact('zero_potential_remainder_y',uy.subs({Delta:0,Ee:0}))
exact('zero_potential_remainder_x',ux.subs({Delta:0,Ee:0}))
yes('negative_remainder_has_empty_envelope',lx*(-1)>ly*(-1))
# The field-amplitude trial, state and positive terms have not been selected away.
yes('constant_nonzero_transverse_amplitudes_have_positive_potential',ax+4*ay>0)
exact('constant_transverse_coordinates_have_zero_kinetic',T.subs({xp:0,yp:0}))
# A discarded intermediate expression omitted B when using coordinate kinetic density.
tau=S.Rational(3,7);bb=S.Rational(3,5);zz=S.Rational(2)
wrong_minus_correct=-2*tau/zz+2*bb*tau/zz
yes('missing_B_coordinate_kinetic_witness',wrong_minus_correct!=0,difference=str(wrong_minus_correct))
# j inequality where u,H are nonzero: positivity of transverse kinetic gives lower Y.
Y,jj=S.symbols('Y j',positive=True)
TT=(s+Y)*H/2-B*(s+Y)**2*u*u/(4*lam*Y)
exact('positive_kinetic_inequality_factor',TT.subs(H,B*u*u/(2*jj))-B*u*u*(s+Y)*(lam*Y-jj*(s+Y))/(4*jj*lam*Y))
yes('all_fixture_coefficients_positive',ax>0 and ay>0 and ly>lx>0)
result={'scope':'Independent exact algebra and local witnesses only; no full solution, ODE, metric data or author source execution.','checks':checks,'counts':{'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks)},'fixture':{'k':str(ks),'a':str(aa),'s':str(ss),'Ax':str(ax),'Ay':str(ay),'ellx':str(lx),'elly':str(ly),'Delta':str(del0),'E':str(ee0),'x_squared':4,'y_squared':9},'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with (O/'INDEPENDENT_RESULTS_v1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'counts':result['counts'],'fixture':result['fixture']},indent=2))
assert result['counts']['failed']==0
