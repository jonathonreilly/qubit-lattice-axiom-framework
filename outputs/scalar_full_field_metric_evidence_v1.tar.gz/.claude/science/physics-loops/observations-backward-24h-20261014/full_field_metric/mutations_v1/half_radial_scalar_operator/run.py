import json
from pathlib import Path
import candidate
r=candidate.controls(Path('/Users/jonBridger/.codex/worktrees/observations-backward-24h-20261014/New Axioms Lets Go/.claude/science/physics-loops/observations-backward-24h-20261014/full_field_metric/PROTOCOL_v1.json'))
print(json.dumps({"failed":[c for c in r["checks"] if not c["passed"]],"passed":sum(c["passed"] for c in r["checks"])}))
