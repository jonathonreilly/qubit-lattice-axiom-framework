"""Post-exposure integration algebra, not blind discovery or observations."""
import sympy as s
import json
T=s.symbols('tau',real=True)
h,q,b=[s.Function(z)(T) for z in ['h','q','b']]
x=q/b;ell=h-q;L=s.diff(b,T)/b;G=x/b
R=-2*s.diff(ell,T)-2*q*ell-x*x
Fbar=-s.diff(x,T)-3*h*x+2*q*x
P,P1,P2,J,J1=s.symbols('P P1 P2 J J1')
trace=2*P2+2*(q+4*ell)*P1+(4*s.diff(ell,T)+4*q*ell+6*ell**2+x*x)*P-x*(J1-L*J)/b+(Fbar-b*R)*J/b
Ct=4*s.diff(q,T)+8*h*q-2*q*q-q*G
Ft=s.diff(G,T)+3*ell*G-2*s.diff(h,T)+2*s.diff(q,T)-2*h*q+2*q*q
observed=2*P2+8*h*P1+(4*s.diff(h,T)+6*h*h)*P-6*q*P1-Ct*P-G*J1-Ft*J
checks=[]
def zero(name,e):
 z=s.factor(s.cancel(s.expand(e)));checks.append({'name':name,'pass':z==0,'residual':str(z)})
zero('general pressure trace matches declared metric-only coefficients',trace-observed)
zero('dust source reconstruction equals Raychaudhuri form',R-(2*s.diff(q,T)-2*s.diff(h,T)-2*h*q+(2-1/b**2)*q*q))
# Directly differentiate constructed Friedmann potential in matter time.
# Q=V/(M^2 A^2), V_phi/(M A^2)=(Qprime+2qQ)/x.
Q=3*ell**2-x*x/2-R
Rp=-(3*h-2*q)*R
predicted=(s.diff(Q,T)+2*q*Q)/x+b*R
# Keep the Raychaudhuri source and its derivative consistent; the remainder
# equals -[Rprime+(3h-2q)R]/x and vanishes precisely with dust conservation.
zero('constructed Friedmann derivative yields original scalar force',predicted-Fbar+(s.diff(R,T)+(3*h-2*q)*R)/x)
print(json.dumps({'scope':'Three post-exposure independently assembled integration identities, no new empirical or blind-review claim','checks':checks,'passed':sum(c['pass'] for c in checks),'failed':sum(not c['pass'] for c in checks)},indent=2))
raise SystemExit(any(not c['pass'] for c in checks))
