from pathlib import Path
import sys,json,runpy
base=Path(__file__).resolve().parent
replay=base/'isolated_replay_v1'
events=[]
def observer(event,args):
    if event=='open' and isinstance(args[0],(str,bytes)):
        name=str(args[0]);mode=args[1];flags=args[2]
        if '/New Axioms Lets Go/' in name:
            events.append({'path':name,'mode':mode,'flags':flags})
sys.addaudithook(observer)
sys.path.insert(0,str(replay/'scripts'))
exit_code=0
try:
    runpy.run_path(str(replay/'scripts/scalar_metric_inverse.py'),run_name='__main__')
except SystemExit as exc:
    exit_code=exc.code or 0
finally:
    (base/'REPLAY_OPEN_EVENTS_v1.json').write_text(json.dumps(events,indent=2)+'\n')
raise SystemExit(exit_code)
