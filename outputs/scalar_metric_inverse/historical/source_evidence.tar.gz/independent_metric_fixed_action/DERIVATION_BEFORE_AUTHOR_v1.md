# Independent fixed-background metric closure before author exposure

Only the neutral question and previously checked equations are used. The new root closure note, code and results have not been read. Root remains author. This is a local smooth linear statement on one fixed action/background, not a statement about changing backgrounds, nonlinear observations or measured arrays.

## Coordinates, variables and domain

Use matter proper background time tau, a=aJ>0, h=a'/a, q=bx, ell=h-q, G=x/b and R>0. Here x=phi'/M and b=M A_phi/A are nowhere zero. The background is compatible, so R'=(2q-3h)R. Put F=-x'-(3h-2q)x and let kappa denote the given background's fixed-bare-density response. All fields may be C-infinity, a sufficient nonminimal regularity condition.

Spatial coordinates are Euclidean comoving Cartesian X, with observer-centered radius r=|X|>0 and direction n. Work on any open spacetime set containing a local product I_tau x I_r x Omega, where I_r is an open interval bounded away from zero and Omega is an open angular patch. A full sphere is unnecessary. Repeated-cone coordinates satisfy u=eta+r, d tau=a d eta. Therefore

    partial_tau at fixed X = a^-1 partial_u,
    partial_r at fixed tau,n = partial_r at fixed u,n + partial_u.

The radial derivative in Rz=-PsiJ+v_r is at fixed tau, not along a single cone. Let v=grad Vv and Z=a Vv; then v_r=Z_r/a. Scalar velocity potentials have an arbitrary time-only additive function; the uniqueness argument below does not silently fix it.

In the previously used equal-Einstein-potential system P=PsiE=PhiE and J=bw, where w=delta phi/M. The original real-space equations are

    2(P'+ell P)=xw-RZ,
    R delta=2 Delta P/a^2-6ell(P'+ell P)-xw'+x^2P-Fw,
    Z'=-P-J,
    delta'=3P'-Delta Z/a^2,
    w''+(3h-2q)w'-Delta w/a^2+kappa w
                       +bR delta-4xP'+2FP=0,

together with the Einstein spatial trace. Delta is the Euclidean spatial Laplacian. No Fourier spectrum or sign restriction on -Delta is assumed.

## Elementary homogeneous closure in that system

Take the difference of two solutions with the same P and Rz. Their P is zero. Momentum gives

    J=C Z, C=R/G=bR/x, lambda=a C !=0.

Euler and zero redshift give Z'=-C Z and Z_r=lambda Z. The Hamiltonian then gives delta=nu Z, with

    nu=6h-4q+2x'/x+C.
    Q=a^2(nu'-C nu).

Dust continuity requires

    (Delta+Q)Z=0.

At each epoch the radial equation gives Z=e^(lambda r) f(n), locally. Substitution gives

    Delta_Omega f + [(lambda^2+Q)r^2+2lambda r] f=0.

This polynomial identity holds on an open interval of r. Its linear coefficient is 2lambda f, hence f=0 because lambda!=0. Therefore Z=J=0. No boundary value, center regularity, real wave number, decay, angular harmonic decomposition or time derivative of lambda was used. In particular lambda'=0 is not an exception.

This proves uniqueness of J whenever a compatible solution exists. It does not assert that arbitrary input P,Rz is compatible.

## Local integration and anisotropic-stress kernels must be retained

Without a Fourier or spatial boundary restriction, absence of anisotropic stress gives a traceless Hessian equation, not automatically PsiE=PhiE. Write

    PsiE=P+chi, PhiE=P-chi,
    J=chi+bw,
    (partial_i partial_j-delta_ij Delta/3)chi=0.

On any connected Cartesian open patch the last equation gives

    chi=c0(tau)+c_i(tau)X_i+c2(tau)r^2.

Call this five-dimensional spatial space P2. It is closed under time differentiation and spatial Laplacian. Spatially integrated momentum and Euler can also contain time-only functions. They belong to P2 and need not be set to zero.

For a zero-data difference, P=Rz=0. The unintegrated momentum constraint and Euler imply, with unspecified members of P2,

    w=(R/x)Z+pi_w,
    J=CZ+pi_J,
    Z'=-CZ+pi_t,
    Z_r-lambda Z=S,          S in P2.

The general Hamiltonian is

    R delta=-2 Delta chi/a^2-6ell(-chi'+ell chi)
                          -xw'+x^2chi-Fw.

Hence delta=nu Z+pi_delta with pi_delta in P2. General bare continuity is
delta'=-3chi'-Delta Z/a^2, so

    (Delta+Q)Z=T,            T in P2.

The same fixed nonzero lambda and Q appear; all unknown integration and chi terms are finite spatial polynomials. No pressure or scalar equation was needed for this necessary consequence, so imposing the full action cannot weaken it.

Here is a local lemma that closes this larger system. At fixed tau write

    S=s2 r^2 + (s_vec dot n)r+s0.

The radial equation has the exact local solution

    Z=Zp+e^(lambda r) f(n),
    Zp=-s2 r^2/lambda
       -(2s2/lambda^2+(s_vec dot n)/lambda)r
       -(2s2/lambda^3+(s_vec dot n)/lambda^2+s0/lambda).

Multiplying the Helmholtz equation by r^2 gives an exponential times a degree-two polynomial, plus an ordinary polynomial of degree at most four. Apply five radial derivatives. The ordinary polynomial vanishes. If A=lambda^2+Q, the exponential coefficient of r^2 is lambda^5 A f and that of r is (10lambda^4 A+2lambda^6)f. Subtracting (10/lambda) times the former from the latter gives 2lambda^6 f=0. Thus f=0 even when A=0, and independently of Delta_Omega f.

The remaining negative powers in (Delta+Q)Zp are

    -4s2/(lambda^2 r) + 2(s_vec dot n)/(lambda^2 r^2).

Since T and QZp have no negative powers, s2=0 and s_vec dot n=0 on the open angular patch. Therefore Z=-s0/lambda is spatially constant and J=Z_r/a=0. Such a constant Z is a potential representation freedom, not a velocity. This proves uniqueness of the actual matter lapse/slip J without discarding local anisotropic or spatial-integration kernels. It does not classify all remaining homogeneous scalar/background representation modes.

The result is local on open angular sectors as well as full-sky annuli. A single direction, a single cone or isolated samples do not supply the open-domain identities used here.

## Explicit compatibility reconstruction in the supplied equal-potential system

The earlier original equations explicitly used PsiE=PhiE=P and fixed the scalar velocity-potential integration convention. In precisely that system, an explicit differential reconstruction is available. This formula must not be used to discard the local chi kernels in a broader real-space problem; uniqueness above does not need that restriction.

From known P,Rz define

    E=P'+ell P, D=2E/G, U=P+D,
    C=R/G, lambda=a C,
    S=a(Rz+U),
    W=2E/x, T0=R/x,
    nu=6h-4q+2x'/x+C,

    delta0=[2 Delta P/a^2-6ell E-xW'+R U+x^2P-FW]/R,
    Q=a^2(nu'-Cnu),
    T=a^2(3P'+nu U-delta0').

Then every compatible solution has

    Z'+CZ=-U,
    Z_r-lambda Z=S,
    (Delta+Q)Z=T,
    J=CZ+D, w=J/b, delta=nu Z+delta0.

A useful first-order commutator chart is

    lambda' Z=-S'-CS-U_r+lambda U.

It licenses division only where lambda'!=0. It is unnecessary for the general reconstruction.

Let B=(lambda^2+Q)r^2+2lambda r and

    H=r^2[T-S_r-(lambda+2/r)S],
    N=H_r-lambda H-Delta_Omega S-BS.

Using the radial and Helmholtz equations gives B_r Z=N and
N_r=(B_rr+lambda B_r)Z+B_r S. Since B_r-rB_rr=2lambda, the formula

    Z=[(1+lambda r)N-rN_r+rB_r S]/(2lambda)

is valid everywhere on the regular annulus. It needs no lambda' or B_r division, including their zero sets. Denominators are a,R,x,b,G,lambda and r; all are nonzero on the declared chart. The formula is dimensionally consistent with Z having length, lambda inverse length and Q inverse length squared in units c=1.

This is a necessary candidate, not an existence theorem for arbitrary records. Reconstruct J,w,delta and test the original momentum, Hamiltonian, Euler, continuity, spatial trace, scalar equation and Rz. Passing all those equations is sufficient for the fixed-background linear system. Smoothness must support the displayed mixed derivatives; C-infinity is an explicit sufficient choice. A broader reconstruction admitting chi must retain its five coefficient functions and the unintegrated original equations; the closed expression above is not claimed for that larger system.

## Exact controls and a geometry counterexample

Use the already derived action-consistent background

    M=1, A=aE=t, phi=ln t,
    rE=t^-2, rho=t^-3, V=3/(2t^2),
    tau=t^2/2, a=2tau,
    b=1, x=q=G=1/(2tau), R=1/(4tau^2),
    F=-1/(2tau^2), kappa=7/(4tau^2).

Here C=1/(2tau), lambda=1, nu=5/(2tau), Q=-15. The constant-lambda chart is exactly the one a commutator-only argument cannot decide.

An evanescent spherical full mode on an annulus is

    zeta=sqrt(7/5), f(r)=exp(zeta r)/r, Delta f=(7/5)f,
    P=tau^(-1/2)f, J=-P/2,
    Z=-tau^(1/2)f, delta=(23/10)P,
    Rz=-P/2-(1/2)tau^(-1/2)f_r.

It comes from the previously derived original-equation power family at exponent m=-1/2; no real Fourier k is assumed. Check all original background and perturbation equations, then reconstruct Z,J directly from P,Rz by the differential formula. Restrict to a bounded annulus/time interval and arbitrarily small amplitude for linear consistency; do not impose center regularity or decay.

Finally, replacing the observer-centered radial direction by a fixed planar direction changes the result. In the same background let

    Z=tau^(-1/2) exp(z+sqrt(14) X),
    P=0, J=Z/(2tau), w=J, delta=5Z/(2tau).

These satisfy every full original linear equation and the planar zero-redshift condition -J+Z_z/a=0, since Delta Z=15Z. They do not satisfy the observer-centered radial condition on an open angular patch. This explicit full-action null mode prevents silently replacing a finite spherical patch by a plane-parallel geometry or excluding spatially growing profiles through a real-k assumption.

