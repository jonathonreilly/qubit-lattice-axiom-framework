# Post-exposure correspondence, fixed-action radial closure

This supplement was written after the independent proof and executable results
were frozen in INDEPENDENT_OUTPUT_FREEZE_v1.json. It is not independent
before-author discovery. No author program is imported into the new controls.

The frozen root closure note and runner agree with the independent derivation on
their shared equal-Einstein-potential branch. The root uses the pressure trace
and scalar equation to constrain w; the independent route used the momentum,
Euler, Hamiltonian and bare-dust continuity equations to constrain Z.

The units before any reference-unit normalization are [h]=[x]=time^-1,
[R]=[kappa]=time^-2, [C]=comoving-length^-1 and
[Lambda]=comoving-length^-2; b and w are dimensionless. The frozen root phrase
"dimensionless matter density R" needs an explicit reference-unit convention.

## Direct correspondence from the original trace

Write ell=h-q and impose the background Raychaudhuri relation

    R=-2h'+2q'-2q(h-q)-x^2,  q=bx,  G=x/b.

The trace coefficients obey

    Ct=4q'+8hq-2q^2-x^2,
    Ft=G'+3ell G+R+x^2.

Thus the root scalar time coefficient reduces to

    nu=-b'/b-Ft/G=-x'/x-3h+2q-bR/x
       =(Fbar-bR)/x.

This is the coefficient obtained directly from the Einstein spatial trace,
with Fbar=-x'-(3h-2q)x and fixed-bare-density scalar response. Its source
coefficient 4h'+6h^2-Ct also agrees with direct frame transformation.
Substitution of the Hamiltonian into the scalar equation has damping
3(h-q), because the eliminated density contributes -bx w'=-q w'.
No quasistatic or real-wave-number restriction is needed.

The independent spherical evanescent fixture has P=tau^-1/2 exp(zeta r)/r,
zeta^2=7/5, w=-P/2. The root source formula must recover that w although its
spatial eigenvalue is positive. This is a separate fixture from the author's
regular l=2 oscillatory example.

For the author's m=1/5 example, Y=143/85, k^2=728/75 and
Vv=(Y-4m-2)P. The new correspondence controls substitute these amplitudes into
all six original Einstein-time linear equations, using the spatial eigenvalue
-k^2. The unchanged author replay separately checks that a regular l=2
spherical Bessel profile realizes this eigenvalue. Such a constructed mode is
not an observation, global stability statement or action selection.

## All-chart identity derived after author exposure

The author's identities D w=N and w_r=Cw+f, with
D=Lambda-C^2-C/r and D_r=C/r^2, imply

    w=(r^2/C)[N_r-CN-Df].

Indeed N_r-CN-Df=D_r w. This formula does not divide by D and covers the
author's exceptional D=0 radius. It requires C!=0 and r>0 and one additional
spatial derivative of the supplied sources. It does not supply a deterministic
noise bound. Root's original derivative-limit formula is also correct.

## Scope distinction that must survive integration

No anisotropic stress alone imposes the traceless-Hessian condition on
chi=(PsiE-PhiE)/2. On a local flat spatial patch its kernel is

    chi=c0(tau)+c_i(tau) X_i+c2(tau)|X|^2.

This does not imply chi=0 without a branch, sector or integration convention.
The root's C1-C5 reconstruction and uniqueness of w are conditional on its
inherited equal-Einstein-potential branch and integrated velocity/momentum
conventions. Merely stating "no extra anisotropic stress" does not replace
those conditions on an open angular patch.

The independently frozen proof retains the polynomial kernel and time-only
integration functions. It still proves uniqueness of the physical matter slip
J for fixed P,Rz on a spherical annulus. It does not prove uniqueness of w or
extend C1-C5 unchanged to that larger local class. A compatible reconstruction
there must retain the finite polynomial coefficients in the full unintegrated
system. With full-sky projection, the polynomial kernel has only l=0,1 content,
so recovered l>=2 sectors remove it and the time-only integration functions;
this is distinct from a local mask or patch.

The planar full-action null in the frozen independent controls remains a
geometry boundary: it has zero plane-parallel redshift but nonzero true radial
redshift. It does not refute the observer-centered annular uniqueness theorem.

The canonical note has been read completely for this limited integration
comparison. Its other inverse, gain, measurement, prior-art and conditioning
sections are not re-established by this focused closure check.

