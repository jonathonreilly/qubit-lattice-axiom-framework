# Independent result before new author exposure

For one fixed smooth compatible background with a>0, R>0, b!=0 and x!=0, the original linear action constraints remove the photon/Euler boundary function: J is unique whenever a compatible solution exists on an observer-centered spherical annular open spacetime patch. The proof requires neither full-sky coverage nor a boundary, real Fourier wave number, center regularity, decay, minimum tracking or small coupling.

On the standard equal-Einstein-potential branch, a zero-data difference satisfies Z_r=lambda Z and (Delta+Q)Z=0 with nonzero lambda=a b R/x. The spherical 2lambda/r term forces Z=0 locally. This includes the constant-lambda case; no division by lambda' is valid or necessary there.

The proof also retains the general local traceless-Hessian kernel PsiE-PhiE=2chi, chi=c0+c_i X_i+c2 r^2, and the time-only momentum/Euler integration terms. They yield polynomial forcing in the radial and Helmholtz equations. A local exponential-versus-polynomial argument reduces Z to a spatial constant, whose radial velocity and J vanish. Thus the uniqueness conclusion is not obtained by silently discarding these local modes. Their full homogeneous scalar/gauge classification is not claimed.

A closed differential reconstruction is given for the exact equal-Einstein-potential system used in the prior mode work. It divides by nonzero lambda but never by lambda' or the first spatial-commutator coefficient. It supplies a candidate that must pass every original constraint/evolution residual. The broader local-chi problem retains those finite coefficient functions; the same explicit candidate formula is not claimed for it.

Controls include a complete spatially growing spherical solution, with Delta f=(7/5)f, and exact recovery from its P,Rz. A complete plane-parallel zero-data solution is also constructed: it fails the actual observer-centered radial condition. This distinguishes an open finite spherical patch from replacing the geometry with a fixed planar direction.

The first bounded execution preserved a real symbolic-interface failure: 54 passed and one failed when equivalent partial derivatives remained in different SymPy Subs forms. A one-line representation repair evaluates both sides in independent eta,r coordinates. The unchanged proof and all other predicates then passed: 55/55, no timeout. Both scripts, both full stdout/stderr captures, the lossless change record and timing/source receipts remain intact. Shared Python 3.12.8/SymPy 1.14.0 is disclosed. No new author closure source was read.

Next obligation: compare the frozen author closure unit, especially its domain and spatial-kernel treatment, and replay unchanged author code from allowed local copies. No empirical or formal audit claim is made.

