# Focused fixed-action metric closure check

The root C1-C5 algebra and exceptional-radius reconstruction are consistent
with the checked fixed-background equations on the inherited
equal-Einstein-potential branch. No sign or normalization error was found.
The physical scope qualification below remains necessary in the compared
canonical draft. This is a focused research check, not a formal audit.

## Source identity and independence

The original root note is bound to SHA256
419b98cad87d7c99ff3859326796e0e48fc5101a53d5ae1875e55c80556778f7,
and its unchanged runner to
157d34a955fb2367cd523ddf760da6d27c803f6532d8160a23500949d9ee9b00.
The canonical draft read for closure integration is bound to
2151e6773f5cc2eee70c01fcb0964ec43d749feb37710435b30ddcabd9e86307.
AUTHOR_SNAPSHOT_v1.json records complete paths, byte counts and dependencies.
SOURCE_STATUS_v1.json found all seven source files unchanged at
2026-10-16T11:50:27.700466Z.

The independent argument was frozen before its implementation at
11:37:34.301099Z. The independent results were frozen at 11:41:51.679109Z
before the new root closure source was opened. The proof SHA256 is
d3b0f8120f4cb95ff973b3f47069afcaa7f0fd1cddc23a5c713da6622e98947e;
INDEPENDENT_OUTPUT_FREEZE_v1.json has SHA256
8d8020527879601f1aafdad5c4b17e0eaeebc7e81f9e03231c30cd1a93ddb9cc.
Earlier action/mode equations and the known power background were acknowledged
context, not a blind rederivation of the action. Python 3.12.8 and SymPy 1.14.0
are shared software. The later correspondence checks are expressly post-exposure.

## Main finding and scope correction

The independent route uses momentum, Euler, Hamiltonian and bare-dust
continuity rather than the root's pressure-trace/scalar elimination. It
derives radial transport plus a spatial Helmholtz equation for Z=a Vv.
Their compatibility removes the apparent boundary function on a genuine open
observer-centered spherical annulus. It remains valid when the temporal
transport coefficient has zero derivative.

It also retains the local no-anisotropic-stress kernel
chi=c0+c_i X_i+c2 r^2 and the time-only integration functions. These produce
finite polynomial forcing. A radial exponential-polynomial argument then
forces Z spatially constant for a zero-data difference, hence J=Z_r/a=0.
Thus **J is unique even in this broader local class**. This does not prove
uniqueness of w=delta(phi)/M in that class.

By contrast, root C1-C5 reconstruct w and use J=bw. They require the
equal-Einstein-potential branch and the stated integrated-potential convention.
No anisotropic stress alone does not remove chi on an open patch. The
canonical draft states equality in its action subsection, but target 2's
unqualified "scalar perturbation" and the local closure wording should retain
the branch explicitly. Full-sky recovered l>=2 sectors exclude the polynomial
kernel and time-only integration functions; a local angular mask does not
supply that projection. No general reconstruction for unknown chi is claimed
by either closed formula.

The author's C=aRb/x and D=Lambda-C^2-C/r have D_r=C/r^2. Its division away
from D=0 and derivative limit at an isolated zero are correct. After author
exposure, the additional identity

    w=(r^2/C)(N_r-CN-Df)

was verified from D w=N and w_r=Cw+f. It avoids D division everywhere on
r>0,C!=0 but uses another spatial derivative and supplies no noise bound.

A small units correction is also needed: R=rE/(M^2 A^2) has inverse-time-squared
units before reference-unit normalization. The frozen phrase "dimensionless
matter density R" requires an explicit numerical unit convention.

## Actual calculations and preserved failure

| Stage | Result | Wall time | Interpretation |
| --- | --- | --- | --- |
| Independent attempt 1 | 54 pass, 1 fail | 0.582 s | SymPy represented the same cone derivative in two different Subs forms |
| Independent attempt 2 | 55 pass, 0 fail | 0.440 s | Both derivatives pulled back to independent eta,r after differentiation |
| Post-exposure correspondence | 27 pass, 0 fail | 0.609 s | New equations/fixtures, not independent discovery |
| Unchanged copied author replay | 24 pass, 0 fail | 0.646 s | Byte-identical to the frozen author output |

Every run was bounded at 120 seconds with bytecode disabled; none timed out.
The actual failing code, stdout, stderr and run record remain unchanged.
ATTEMPT_RECOVERY_v1.json preserves the exact one-line recovery diff losslessly;
no physical equation or tolerance changed. The proof's phrase "commutator-only"
in the constant-lambda discussion means the temporal-radial commutator there,
not the later spatial spherical commutator.

Before exposure, the controls checked the actual local polynomial kernel,
the radial polynomial/exponential obstruction, an all-chart Z reconstruction,
and all six original perturbation equations for an evanescent spherical
fixture. They also verified a full-action plane-parallel zero-data mode. That
mode has nonzero observer-centered radial redshift and marks a geometry
boundary rather than a counterexample to the annular result.

After exposure, the independent calculation reduced the root trace coefficient
directly to (Fbar-bR)/x, checked its arbitrary-angular-jet identity, verified all
six original Einstein-time equations for the author's m=1/5,Y=143/85,
k^2=728/75 witness, and used the root formula to recover the independently
frozen evanescent mode. The reconstructed author density is
delta/P=-6151/255. These checks independently re-establish the witness here;
the older readout program and receipt are only byte-read integrity dependencies
of the unchanged replay and were not run.

The copied author stdout SHA256 is
8f8c9e5e7b52f2363adc2c9c551c0e5fbc799000f3e91f07989e9413f6b40731.
The post-exposure stdout SHA256 is
8c9a774ff36088cbde4f458c25d7167e42c6c9591c182988b3848bf78cf60202.
Complete individual residuals and resource records are in the paired
.stdout.json, .stderr.txt and .run.json files.

## Remaining obligations

The next integration obligation is to state the equal-potential/integration
restriction beside the w reconstruction, or explicitly use the broader
J-only result while retaining the unknown local kernel. The full-sky versus
local-patch distinction and the units qualification should remain visible.

The result is conditional on one fixed compatible action/background,
a,R>0, b,x!=0, r>0, sufficient smoothness and an open spacetime product chart
within the repeated-cone strip. No boundary, real Fourier spectrum, center
regularity or decay was imposed. Arbitrary supplied P,Rz must still pass every
original residual; the formulas do not establish existence for arbitrary data.

Distance/clock registration, angular recovery, the corrected redshift,
identification of the same pressureless dust velocity, finite/noisy derivative
bounds and selection of a background/action are unresolved input obligations.
No empirical data, measured scalar, nonlinear stability, initial-state
probability, absolute calibration, prior-art priority or wider canonical
inverse claim was established. The entire canonical draft was read only for
this bounded closure integration; its other blocks were not rechecked here.

