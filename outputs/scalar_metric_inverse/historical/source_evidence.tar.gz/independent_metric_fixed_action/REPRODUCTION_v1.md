# Reproduction

All new programs are portable within this evidence folder and declare an exact
literal repository input list. They use Python 3 with SymPy 1.14.0. Run in this
folder, retaining a fresh attempt label so earlier evidence cannot be replaced:

    python3 -B run_independent_bounded_v2.py --attempt independent_replay_new
    python3 -B run_comparison_bounded_v1.py correspondence --attempt correspondence_replay_new
    python3 -B run_comparison_bounded_v1.py author --attempt author_replay_new

Expected completed results are respectively 55/0, 27/0 and 24/0. Author replay
also requires byte-identical stdout to the copied expected receipt. Wrappers
set PYTHONDONTWRITEBYTECODE=1, impose a 120-second subprocess timeout, and save
complete stdout/stderr, resource usage and input bindings before/after.

To reproduce the preserved operational failure, use a fresh label:

    python3 -B run_independent_bounded_v1.py --attempt failure_replay_new

That original version is expected to exit 1 with 54/1: the cone derivative
comparison retains two structurally different SymPy Subs objects. The source
of the failure and exact one-line change are in ATTEMPT_RECOVERY_v1.json.

The author copy is unchanged. Its integrity-byte dependencies remain beside
it under author_snapshot_v1/. It imports SymPy and standard-library modules;
it does not execute the copied older check_metric_readout_v1.py. The independent
and correspondence computation scripts import no author code and read no
repository files. Wrappers read only their declared local binding lists.
Paths in historical receipts describe the actual original executions; no
silent path or source repinning was performed. No program needs network or
writes outside this folder.

