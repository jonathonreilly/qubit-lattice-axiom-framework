# Reproduction, final unit

All programs are portable within this evidence folder. Use Python 3 with SymPy
1.14.0 and fresh attempt labels; wrappers refuse to overwrite previous records.

    python3 -B run_independent_bounded_v2.py --attempt independent_replay_new
    python3 -B run_comparison_bounded_v1.py correspondence --attempt correspondence_replay_new
    python3 -B run_comparison_bounded_v1.py author --attempt author_replay_new
    python3 -B run_integration_bounded_v1.py root_integration --attempt kernel_replay_new
    python3 -B run_integration_bounded_v1.py canonical_helper --attempt helper_replay_new

Expected completed results: 55/0, 27/0, 24/0, 23/0, then four extraction
checks with the same 23 helper controls. Both unchanged author replays require
byte-identical stdout to their copied expected receipt. The canonical helper
check compares exact scientific ASTs and complete returned control objects.

To reproduce the preserved operational failure:

    python3 -B run_independent_bounded_v1.py --attempt failure_replay_new

This exits 1 with 54/1 under the recorded SymPy version. See
ATTEMPT_RECOVERY_v1.json for the equivalent derivative representations and
lossless one-line correction.

Every wrapper sets PYTHONDONTWRITEBYTECODE=1, invokes Python -B, applies a
120-second subprocess timeout, and preserves full stdout/stderr plus input
hashes and resource usage. Exact literal AUDIT_INPUT_PATHS lists declare local
reads; runtime and installed-library reads are software dependencies. Scripts
need no network and write only fresh evidence files within this folder.

Author copies are unchanged. Older readout code is an integrity-byte dependency
only, not executed. The new independent and post-exposure mathematical
calculations import no author code and read no repository files. The final
helper correspondence intentionally imports the copied canonical helper and
labels that execution as reproduction. Historical receipts retain actual
execution paths, versions, successes and failure; no silent repinning occurred.

