"""Check only copied kernel-unit extraction and exact helper output."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = [
    "author_integration_snapshot_v1/check_metric_kernel_integration_v1.py",
    "author_integration_snapshot_v1/scalar_metric_local_kernels.py",
    "author_integration_snapshot_v1/METRIC_KERNEL_INTEGRATION_CONTROLS_v1.json",
]
import ast,hashlib,importlib.util,json,sys
from pathlib import Path
here=Path(__file__).resolve().parent
blobs={n:(here/n).read_bytes() for n in AUDIT_INPUT_PATHS}
root=ast.parse(blobs[AUDIT_INPUT_PATHS[0]])
helper=ast.parse(blobs[AUDIT_INPUT_PATHS[1]])
def assigned(node,name):
    return isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in node.targets)
start=next(i for i,n in enumerate(root.body) if assigned(n,"checks"))
end=next(i for i,n in enumerate(root.body) if assigned(n,"names"))
root_core=root.body[start:end]
function=next(n for n in helper.body if isinstance(n,ast.FunctionDef) and n.name=="run_checks")
helper_core=function.body[:-1]
norm=lambda body:ast.dump(ast.Module(body=body,type_ignores=[]),include_attributes=False)
checks=[{"name":"canonical helper preserves exact root science AST","pass":norm(root_core)==norm(helper_core)}]
for tree,name in [(helper,"helper")]:
    imports=[ast.unparse(n) for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom))]
    checks.append({"name":"helper imports only declared SymPy dependency","pass":imports==["import sympy as s"],"imports":imports})
spec=importlib.util.spec_from_file_location("copied_scalar_metric_local_kernels",here/AUDIT_INPUT_PATHS[1])
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
actual,metadata=module.run_checks()
expected=json.loads(blobs[AUDIT_INPUT_PATHS[2]])["checks"]
checks.append({"name":"canonical helper checks match frozen root receipt exactly","pass":actual==expected})
checks.append({"name":"every copied helper physical control passes","pass":all(c["pass"] for c in actual)})
out={"stage":"Post-exposure extraction/replay correspondence, not new independent mathematics",
     "checks":checks,"summary":{"passed":sum(c["pass"] for c in checks),"failed":sum(not c["pass"] for c in checks)},
     "replayed_helper_controls":actual,"helper_control_summary":{"passed":sum(c["pass"] for c in actual),"failed":sum(not c["pass"] for c in actual)},
     "helper_metadata":metadata,"source_sha256":{n:hashlib.sha256(b).hexdigest() for n,b in blobs.items()},
     "python":sys.version.split()[0]}
print(json.dumps(out,indent=2))
raise SystemExit(int(out["summary"]["failed"]!=0))

