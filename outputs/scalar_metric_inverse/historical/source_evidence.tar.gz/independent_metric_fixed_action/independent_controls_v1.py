"""Independent fixed-background radial closure; no new author source imports."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = []
import json,sys
import sympy as s
checks=[]
def zero(name,expr):
    r=s.factor(s.cancel(s.powsimp(expr)))
    checks.append({"name":name,"pass":r==0,"residual":str(r)})
    print(("PASS " if r==0 else "FAIL ")+name,file=sys.stderr,flush=True)
def ok(name,val,detail=None):
    checks.append({"name":name,"pass":bool(val),"detail":None if detail is None else str(detail)})
    print(("PASS " if val else "FAIL ")+name,file=sys.stderr,flush=True)
r=s.symbols("r",positive=True);tau=s.symbols("tau",positive=True)
eta,u=s.symbols("eta u",real=True)
fun=s.Function("F")
obs=fun(u-r,r)
zero("fixed-time radial derivative in cone coordinates",s.diff(obs,r)+s.diff(obs,u)-s.Subs(s.Derivative(fun(eta,r),r),eta,u-r))
null=fun(u-2*r)
zero("kinematic repeated-cone transport kernel",s.diff(null,r)+2*s.diff(null,u))
# Hamiltonian/continuity reduction, independent abstract background jets.
h,q,x,xp,R,C=s.symbols("h q x xp R C",nonzero=True)
Rp=(2*q-3*h)*R;F=-xp-(3*h-2*q)*x
coefficient=-(x*(Rp/x-R*xp/x**2-C*R/x)+F*R/x)/R
nu=6*h-4*q+2*xp/x+C
zero("density coefficient from original Hamiltonian",coefficient-nu)
# First-order commutator checked without an action ansatz.
aa=s.Function("a")(tau);cc=s.Function("C")(tau);zz=s.Function("Z")(tau,r)
lam=aa*cc
UU=-s.diff(zz,tau)-cc*zz
SS=s.diff(zz,r)-lam*zz
zero("temporal-radial commutator", -s.diff(SS,tau)-cc*SS-s.diff(UU,r)+lam*UU-s.diff(lam,tau)*zz)
# Actual local traceless-Hessian kernels; do not set them to zero by Fourier convention.
X,Y,Zc=s.symbols("X Y Z",real=True)
c0,cx,cy,cz,c2=s.symbols("c0 cx cy cz c2",real=True)
chi=c0+cx*X+cy*Y+cz*Zc+c2*(X*X+Y*Y+Zc*Zc)
coords=[X,Y,Zc];lapchi=sum(s.diff(chi,z,2) for z in coords)
for i in range(3):
    for j in range(i,3):
        zero("local anisotropic kernel component "+str(i)+str(j),s.diff(chi,coords[i],coords[j])-(lapchi/3 if i==j else 0))
zero("local kernel Laplacian remains time-only",lapchi-6*c2)
# Radial lemma retaining finite spatial-polynomial forcing.
ll=s.symbols("lambda",nonzero=True,real=True);Q=s.symbols("Q",real=True)
s0,s1,s2=s.symbols("s0 dipole s2",real=True)
pmono=-s2*r*r/ll-2*s2*r/ll**2-2*s2/ll**3-s0/ll
pdip=-s1*r/ll-s1/ll**2
zero("radial particular monopole",s.diff(pmono,r)-ll*pmono-(s2*r*r+s0))
zero("radial particular dipole",s.diff(pdip,r)-ll*pdip-s1*r)
lm=s.diff(pmono,r,2)+2*s.diff(pmono,r)/r
ld=s.diff(pdip,r,2)+2*s.diff(pdip,r)/r-2*pdip/r**2
zero("monopole negative-power coefficient",s.expand(r*r*(lm+Q*pmono)).coeff(r,1)+4*s2/ll**2)
zero("dipole negative-power coefficient",s.expand(r*r*(ld+Q*pdip)).coeff(r,0)-2*s1/ll**2)
f,af=s.symbols("f angular_laplacian_f")
ex=s.exp(ll*r)*(((ll*ll+Q)*r*r+2*ll*r)*f+af)
fifth=s.expand(s.diff(ex,r,5)/s.exp(ll*r))
coeff2=fifth.coeff(r,2);coeff1=fifth.coeff(r,1)
zero("exponential-polynomial coefficient elimination",coeff1-10*coeff2/ll-2*ll**6*f)
zero("nonzero lambda also closes resonant Q=-lambda squared",coeff1.subs(Q,-ll**2)-2*ll**6*f)
# Universal local reconstruction identity with arbitrary angular Laplacian.
zr=s.Function("z")(r);ang=s.Function("DeltaOmega_z")(r)
sourceS=s.diff(zr,r)-ll*zr
sourceT=s.diff(zr,r,2)+2*s.diff(zr,r)/r+ang/r**2+Q*zr
angS=s.diff(ang,r)-ll*ang
BB=(ll*ll+Q)*r*r+2*ll*r
HH=r*r*(sourceT-s.diff(sourceS,r)-(ll+2/r)*sourceS)
NN=s.diff(HH,r)-ll*HH-angS-BB*sourceS
zero("first spatial commutator identity",NN-s.diff(BB,r)*zr)
candidate=((1+ll*r)*NN-r*s.diff(NN,r)+r*s.diff(BB,r)*sourceS)/(2*ll)
zero("all-chart differential reconstruction",candidate-zr)
zero("reconstruction denominator identity",s.diff(BB,r)-r*s.diff(BB,r,2)-2*ll)

# Fixed action background, using field differentiation before holding rho fixed.
A=s.sqrt(2*tau);aE=A;aJ=2*tau
HE=1/A;vE=1/A;rE=1/(2*tau);rho=rE/A;V=s.Rational(3,4)/tau
DE=lambda e:A*s.diff(e,tau)
DP=lambda e:DE(e)/vE
alpha=s.factor(DP(A)/A)
force=s.factor(DP(V)+rho*DP(A));mass=s.factor(DP(DP(V))+rho*DP(DP(A)))
zero("fixture original Friedmann",3*HE**2-vE**2/2-rE-V)
zero("fixture original Raychaudhuri",-2*DE(HE)-vE**2-rE)
zero("fixture original scalar",DE(vE)+3*HE*vE+force)
zero("fixture bare dust conservation",DE(rho)+3*HE*rho)
zero("fixture fixed-density scalar response",mass/A**2-s.Rational(7,4)/tau**2)
hh=1/tau;qq=1/(2*tau);xx=qq;RR=1/(4*tau*tau);gg=xx
ell=hh-qq;FF=-1/(2*tau*tau);kap=s.Rational(7,4)/tau**2
CC=RR/gg;lambda0=s.factor(aJ*CC)
nnu=s.factor(6*hh-4*qq+2*s.diff(xx,tau)/xx+CC)
QQ=s.factor(aJ**2*(s.diff(nnu,tau)-CC*nnu))
zero("fixture constant lambda",lambda0-1)
zero("fixture density coefficient",nnu-s.Rational(5,2)/tau)
zero("fixture spatial Helmholtz coefficient",QQ+15)
def radial_lap(e):return s.diff(e,r,2)+2*s.diff(e,r)/r
def original_controls(label,P,w,Z,density,lap):
    velocity=Z/A
    zero(label+" original momentum",2*(DE(P)+HE*P)-vE*w+rE*velocity)
    zero(label+" original Hamiltonian",-2*lap(P)/aE**2+6*HE*(DE(P)+HE*P)+vE*DE(w)-vE*vE*P+DP(V)*w+rE*(density+alpha*w))
    zero(label+" original spatial trace",2*(DE(DE(P))+4*HE*DE(P)+(2*DE(HE)+3*HE*HE)*P)-vE*DE(w)+vE*vE*P+DP(V)*w)
    zero(label+" original scalar",DE(DE(w))+3*HE*DE(w)-lap(w)/aE**2+mass*w-4*vE*DE(P)+2*force*P+rho*DP(A)*density)
    zero(label+" original dust continuity",DE(density)-3*DE(P)+lap(velocity)/aE**2)
    zero(label+" original dust Euler",DE(velocity)+alpha*vE*velocity+P+alpha*w)

# Spatially growing spherical mode, no real-k or center/decay condition.
zeta=s.sqrt(s.Rational(7,5));sp=s.exp(zeta*r)/r
P=tau**(-s.Rational(1,2))*sp
J=-P/2
Z=-tau**s.Rational(1,2)*sp
delta=s.Rational(23,10)*P
Rz=-P-J+s.diff(Z,r)/aJ
zero("evanescent spherical spatial equation",radial_lap(sp)-s.Rational(7,5)*sp)
original_controls("evanescent spherical",P,J,Z,delta,radial_lap)
# Reconstruct from P and Rz, not from a supplied J or velocity.
E=s.diff(P,tau)+ell*P
D=s.factor(2*E/gg);U=s.factor(P+D);W=s.factor(2*E/xx)
S=s.factor(aJ*(Rz+U))
delta0=s.factor((2*radial_lap(P)/aJ**2-6*ell*E-xx*s.diff(W,tau)+RR*U+xx*xx*P-FF*W)/RR)
T=s.factor(aJ**2*(3*s.diff(P,tau)+nnu*U-s.diff(delta0,tau)))
B=(lambda0**2+QQ)*r*r+2*lambda0*r
H=s.factor(r*r*(T-s.diff(S,r)-(lambda0+2/r)*S))
N=s.factor(s.diff(H,r)-lambda0*H-B*S)  # DeltaOmega S=0 for this exact spherical fixture.
Zrec=s.factor(((1+lambda0*r)*N-r*s.diff(N,r)+r*s.diff(B,r)*S)/(2*lambda0))
Jrec=s.factor(CC*Zrec+D)
zero("data-only local velocity recovery",Zrec-Z)
zero("data-only local matter slip recovery",Jrec-J)
zero("data-only bare density recovery",nnu*Zrec+delta0-delta)
zero("candidate obeys redshift",-P-Jrec+s.diff(Zrec,r)/aJ-Rz)
zero("candidate obeys temporal equation",s.diff(Zrec,tau)+CC*Zrec+U)
zero("candidate obeys radial equation",s.diff(Zrec,r)-lambda0*Zrec-S)
zero("candidate obeys spatial equation",radial_lap(Zrec)+QQ*Zrec-T)
rcritical=s.Rational(1,14)
zero("spatial first-commutator denominator actually vanishes",s.diff(B,r).subs(r,rcritical))
zero("all-chart candidate finite at that zero",Zrec.subs(r,rcritical)-Z.subs(r,rcritical))
# The tempting spherical null is rejected.
nullZ=tau**(-s.Rational(1,2))*s.exp(r)
zero("spherical exponential obstruction", (radial_lap(nullZ)+QQ*nullZ)/nullZ-(-14+2/r))
ok("spherical null fails on an open radial interval",(-14+2/r)!=0)

# Full-action plane-parallel counterexample; a different radial geometry.
planeZ=tau**(-s.Rational(1,2))*s.exp(Zc+s.sqrt(14)*X)
planeJ=planeZ/(2*tau);planeDelta=5*planeZ/(2*tau)
lap3=lambda e:sum(s.diff(e,v,2) for v in coords)
original_controls("planar null",s.Integer(0),planeJ,planeZ,planeDelta,lap3)
zero("planar redshift is identically zero",-planeJ+s.diff(planeZ,Zc)/aJ)
radius=s.sqrt(X*X+Y*Y+Zc*Zc)
radial_deriv=sum(v*s.diff(planeZ,v) for v in coords)/radius
radial_residual=s.factor((-planeJ+radial_deriv/aJ)/planeJ)
zero("same profile fails true radial condition at equator",radial_residual.subs({X:1,Y:0,Zc:0})-(s.sqrt(14)-1))
ok("radial and planar directions are different on an open sector",s.sqrt(14)-1!=0)

out={"stage":"Independent before new author closure exposure","author_source_reads":False,"author_code_imported":False,
     "software":{"python":sys.version.split()[0],"sympy":s.__version__},"checks":checks,
     "summary":{"passed":sum(v["pass"] for v in checks),"failed":sum(not v["pass"] for v in checks)},
     "fixed_background":{"lambda":str(lambda0),"nu":str(nnu),"Q":str(QQ),"kappa":str(kap)},
     "reconstruction":{"Z":str(Zrec),"J":str(Jrec),"first_spatial_denominator_zero_at":str(rcritical)},
     "scope":"Fixed smooth action/background, exact observer-centered spherical annulus; no empirical or real-Fourier-spectrum assumption"}
print(json.dumps(out,indent=2))
raise SystemExit(int(out["summary"]["failed"]!=0))

