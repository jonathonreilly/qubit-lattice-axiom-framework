"""Post-exposure correspondence only; no author code imports or data reads."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = []
import json, sys
import sympy as s

checks=[]
def zero(name, value):
    out=s.factor(s.cancel(s.powsimp(value)))
    checks.append({"name":name,"pass":out==0,"residual":str(out)})
    print(("PASS " if out==0 else "FAIL ")+name,file=sys.stderr,flush=True)
def nonzero(name,value):
    out=s.factor(value)
    checks.append({"name":name,"pass":out!=0,"residual":str(out)})
    print(("PASS " if out!=0 else "FAIL ")+name,file=sys.stderr,flush=True)

# Reduce the author's trace parameters using the actual background identities.
h,hp,q,qp,b,bp,x,xp=s.symbols("h hp q qp b bp x xp",nonzero=True)
R=-2*hp+2*qp-2*q*(h-q)-x*x
G=x/b;Gp=xp/b-x*bp/b**2
Ct=4*qp+8*h*q-2*q*q-q*G
Ft=Gp+3*(h-q)*G+R+x*x
nu=-bp/b-Ft/G
Fbar=-xp-(3*h-2*q)*x
zero("root scalar time coefficient from original trace",
     (nu-(Fbar-b*R)/x).subs(q,b*x))
zero("root trace source coefficient from original trace",
     (4*hp+6*h*h-Ct-(4*hp-4*qp+2*(3*h-q)*(h-q)+x*x)).subs(q,b*x))

# Full angular operator represented by an arbitrary radial angular-Laplacian jet.
r=s.symbols("r",positive=True)
C=s.symbols("C",nonzero=True,real=True);Lam=s.symbols("Lambda",real=True)
W=s.Function("W")(r);angW=s.Function("angular_laplacian_W")(r)
f=s.diff(W,r)-C*W
g=s.diff(W,r,2)+2*s.diff(W,r)/r+angW/r**2-Lam*W
angf=s.diff(angW,r)-C*angW
lapf=s.diff(f,r,2)+2*s.diff(f,r)/r+angf/r**2
D=Lam-C*C-C/r
N=r*(lapf-Lam*f-s.diff(g,r)+C*g)/2-g+C*f+s.diff(f,r)+f/r
zero("author spatial identity with arbitrary angular jet",N-D*W)
rec=r*r*(s.diff(N,r)-C*N-D*f)/C
zero("post-exposure all-chart scalar reconstruction",rec-W)
zero("all-chart reconstruction at author's D zero",rec.subs({C:1,Lam:15,r:s.Rational(1,14)})-W.subs(r,s.Rational(1,14)))
zero("negative C is an allowed chart",rec.subs({C:-2,Lam:3})-W)
nonzero("removing radial spherical term breaks identity",C*W/r)

# Common action background, independently re-established rather than imported.
tau=s.symbols("tau",positive=True)
A=s.sqrt(2*tau);aE=A;a=2*tau;HE=1/A;vE=1/A;rE=1/(2*tau)
rho=rE/A;V=s.Rational(3,4)/tau
DE=lambda e:A*s.diff(e,tau)
DP=lambda e:DE(e)/vE
alpha=s.factor(DP(A)/A)
force=s.factor(DP(V)+rho*DP(A))
mass=s.factor(DP(DP(V))+rho*DP(DP(A)))
zero("action fixture scalar force",force+1/tau)
zero("action fixture fixed-bare-density mass",mass-s.Rational(7,2)/tau)
zero("action fixture full background scalar equation",DE(vE)+3*HE*vE+force)
zero("action fixture Einstein dust conservation",DE(rE)+3*HE*rE-alpha*vE*rE)

# Re-establish all original equations for author's different oscillatory witness.
m=s.Rational(1,5);Y=s.Rational(143,85);k2=s.Rational(728,75)
P=tau**m;w=Y*P;Vv=(Y-4*m-2)*P;Z=a*Vv;U=Z/A
lap=lambda e:-k2*e
delta=s.factor((2*lap(P)/aE**2-6*HE*(DE(P)+HE*P)-vE*DE(w)+vE*vE*P-DP(V)*w)/rE-alpha*w)
zero("author fixture original Einstein momentum",2*(DE(P)+HE*P)-vE*w+rE*U)
zero("author fixture original Einstein Hamiltonian",-2*lap(P)/aE**2+6*HE*(DE(P)+HE*P)+vE*DE(w)-vE*vE*P+DP(V)*w+rE*(delta+alpha*w))
zero("author fixture original Einstein spatial trace",2*(DE(DE(P))+4*HE*DE(P)+(2*DE(HE)+3*HE*HE)*P)-vE*DE(w)+vE*vE*P+DP(V)*w)
zero("author fixture original scalar equation",DE(DE(w))+3*HE*DE(w)-lap(w)/aE**2+mass*w-4*vE*DE(P)+2*force*P+rho*DP(A)*delta)
zero("author fixture original bare-dust continuity",DE(delta)-3*DE(P)+lap(U)/aE**2)
zero("author fixture original dust Euler",DE(U)+alpha*vE*U+P+alpha*w)

# Evaluate root formula on independently frozen growing spherical fixture.
zeta=s.sqrt(s.Rational(7,5))
P=tau**(-s.Rational(1,2))*s.exp(zeta*r)/r
w=-P/2;Z=-tau**s.Rational(1,2)*s.exp(zeta*r)/r
Rz=-P-w+s.diff(Z,r)/a
hh=1/tau;qq=1/(2*tau);xx=qq;RR=1/(4*tau*tau);ell=hh-qq
kap=s.Rational(7,4)/tau**2;Fb=-1/(2*tau*tau)
Ct0=s.Rational(5,4)/tau**2;nu0=-s.Rational(3,2)/tau
laprad=lambda e:s.diff(e,r,2)+2*s.diff(e,r)/r
S=(2*s.diff(P,tau,2)+(8*hh-6*qq)*s.diff(P,tau)+(4*s.diff(hh,tau)+6*hh*hh-Ct0)*P)/xx
HP=(6*ell+4*xx)*s.diff(P,tau)-2*laprad(P)/a**2+(6*ell*ell-xx*xx-2*Fb)*P
C0=s.factor(a*RR/xx)
Lam0=s.factor(a*a*(s.diff(nu0,tau)+nu0**2+3*ell*nu0+kap-Fb))
g0=s.factor(a*a*(s.diff(S,tau)+(nu0+3*ell)*S-HP))
f0=s.factor(a*RR*(Rz+P)/xx+2*s.diff(s.diff(P,tau)+ell*P,r)/xx)
D0=Lam0-C0*C0-C0/r
N0=s.factor(r*(laprad(f0)-Lam0*f0-s.diff(g0,r)+C0*g0)/2-g0+C0*f0+s.diff(f0,r)+f0/r)
zero("independent evanescent fixture root trace",s.diff(w,tau)-nu0*w-S)
zero("independent evanescent fixture root scalar elliptic",laprad(w)-Lam0*w-g0)
zero("independent evanescent fixture root radial",s.diff(w,r)-C0*w-f0)
zero("independent evanescent fixture root numerator",N0-D0*w)
zero("independent evanescent fixture root derivative limit",
     (s.diff(N0,r)/s.diff(D0,r)-w).subs(r,s.Rational(1,14)))
wrec=s.factor(r*r*(s.diff(N0,r)-C0*N0-D0*f0)/C0)
zero("independent evanescent fixture all-chart root reconstruction",wrec-w)

# The local traceless-Hessian kernel has only full-sky l=0,1 angular content.
theta,phi=s.symbols("theta phi",real=True)
angular=lambda e:s.trigsimp(s.diff(s.sin(theta)*s.diff(e,theta),theta)/s.sin(theta)+s.diff(e,phi,2)/s.sin(theta)**2)
zero("full-sky kernel monopole has l zero",angular(s.Integer(1)))
for name,coordinate in [("nx",s.sin(theta)*s.cos(phi)),("ny",s.sin(theta)*s.sin(phi)),("nz",s.cos(theta))]:
    zero("full-sky kernel "+name+" has l one",angular(coordinate)+2*coordinate)

out={"stage":"Post-author-exposure correspondence; new controls, not independent discovery",
     "software":{"python":sys.version.split()[0],"sympy":s.__version__},
     "author_code_imported":False,"repository_data_reads":[],
     "checks":checks,"summary":{"passed":sum(c["pass"] for c in checks),"failed":sum(not c["pass"] for c in checks)},
     "author_witness_reestablished":{"m":str(m),"Y":str(Y),"k2":str(k2),"delta_over_P":str(s.factor(delta/tau**m))},
     "independent_evanescent_root_reconstruction":str(wrec),
     "scope":"Fixed compatible background and equal-Einstein-potential branch for root formula; broader J uniqueness remains the separately frozen proof"}
print(json.dumps(out,indent=2))
raise SystemExit(int(out["summary"]["failed"]!=0))

