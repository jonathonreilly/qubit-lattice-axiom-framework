"""Bounded copied-author replay or post-exposure correspondence; portable folder."""
AUDIT_TIMEOUT_SEC = 120
AUDIT_INPUT_PATHS = [
    "POST_EXPOSURE_CORRESPONDENCE_v1.md",
    "post_exposure_controls_v1.py",
    "run_comparison_bounded_v1.py",
    "AUTHOR_SNAPSHOT_v1.json",
    "INDEPENDENT_OUTPUT_FREEZE_v1.json",
    "author_snapshot_v1/METRIC_FIXED_ACTION_CLOSURE_DERIVATION_v1.md",
    "author_snapshot_v1/check_metric_fixed_action_closure_v1.py",
    "author_snapshot_v1/METRIC_FIXED_ACTION_CLOSURE_CONTROLS_v1.json",
    "author_snapshot_v1/METRIC_FIXED_ACTION_CLOSURE_FREEZE_v1.json",
    "author_snapshot_v1/check_metric_readout_v1.py",
    "author_snapshot_v1/METRIC_READOUT_CONTROLS_v1.json",
    "author_snapshot_v1/SCALAR_METRIC_RECONSTRUCTION_NOTE_2026-10-16.md",
]
import argparse,hashlib,json,os,resource,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
ap=argparse.ArgumentParser()
ap.add_argument("kind",choices=["correspondence","author"])
ap.add_argument("--attempt",required=True)
args=ap.parse_args()
if not args.attempt.replace("_","").isalnum():raise ValueError("Simple fresh attempt label required")
here=Path(__file__).resolve().parent;prefix=here/args.attempt
if prefix.with_suffix(".run.json").exists():raise FileExistsError("Earlier evidence is immutable")
def bind():
    return {n:{"sha256":hashlib.sha256((here/n).read_bytes()).hexdigest(),"bytes":(here/n).stat().st_size} for n in AUDIT_INPUT_PATHS}
before=bind()
script=here/("post_exposure_controls_v1.py" if args.kind=="correspondence" else "author_snapshot_v1/check_metric_fixed_action_closure_v1.py")
argv=[sys.executable,"-B",str(script)]
started=datetime.now(timezone.utc).isoformat();start=time.monotonic()
r0=resource.getrusage(resource.RUSAGE_CHILDREN);timeout=False
try:
    rr=subprocess.run(argv,cwd=script.parent,env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1"),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=AUDIT_TIMEOUT_SEC,check=False)
    stdout,stderr,rc=rr.stdout,rr.stderr,rr.returncode
except subprocess.TimeoutExpired as ex:
    stdout,stderr,rc=ex.stdout or b"",ex.stderr or b"",None;timeout=True
wall=time.monotonic()-start;r1=resource.getrusage(resource.RUSAGE_CHILDREN)
prefix.with_suffix(".stdout.json").write_bytes(stdout);prefix.with_suffix(".stderr.txt").write_bytes(stderr)
try:result=json.loads(stdout);error=None
except (ValueError,UnicodeDecodeError) as ex:result=None;error=repr(ex)
after=bind()
summary=(result["summary"] if args.kind=="correspondence" else {k:result[k] for k in ("passed","failed")}) if result else None
expected=(here/"author_snapshot_v1/METRIC_FIXED_ACTION_CLOSURE_CONTROLS_v1.json").read_bytes() if args.kind=="author" else None
record={"kind":args.kind,"argv":argv,"cwd":str(script.parent),"timeout_seconds":AUDIT_TIMEOUT_SEC,
        "PYTHONDONTWRITEBYTECODE":"1","start_utc":started,"end_utc":datetime.now(timezone.utc).isoformat(),
        "wall_seconds":wall,"returncode":rc,"timed_out":timeout,
        "child_user_seconds":r1.ru_utime-r0.ru_utime,"child_system_seconds":r1.ru_stime-r0.ru_stime,
        "child_peak_rss_platform_units":r1.ru_maxrss,"platform":sys.platform,
        "stdout_bytes":len(stdout),"stdout_sha256":hashlib.sha256(stdout).hexdigest(),
        "stderr_bytes":len(stderr),"stderr_sha256":hashlib.sha256(stderr).hexdigest(),
        "output_parse_error":error,"summary":summary,
        "author_expected_stdout_identical":stdout==expected if expected is not None else None,
        "author_expected_json_identical":result==json.loads(expected) if expected is not None and result else None,
        "input_binding_before":before,"input_binding_after":after,"inputs_unchanged":before==after,
        "copied_author_replay_not_independent_discovery":args.kind=="author"}
prefix.with_suffix(".run.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({k:record[k] for k in ("kind","wall_seconds","returncode","timed_out","summary","output_parse_error","inputs_unchanged","author_expected_stdout_identical")},indent=2))
if rc!=0 or timeout or before!=after or (expected is not None and stdout!=expected):raise SystemExit(1)

