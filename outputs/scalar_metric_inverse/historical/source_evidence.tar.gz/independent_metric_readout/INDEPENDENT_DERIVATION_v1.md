# Independent metric-readout proof before author exposure

Only the neutral assignment and the two expressly permitted previous inverse notes were used. No new root METRIC_READOUT note, protocol, runner or results were read. This is a conditional input-map check, not an observation, physical reconstruction, formal audit or novelty claim. Write Psi,Phi for the supplied matter-metric potentials, P=(Psi+Phi)/2, J=(Psi-Phi)/2. A dot below is matter proper-background-time derivative; partial_eta is conformal-time differentiation at fixed comoving position. a,h and distance/time registration are premises.

## Calibrated Born potential and restriction

Let observer conformal time be u and outward source radius r, direction n. The unperturbed future photon direction is -n. Define the calibrated lensing potential by

  L(u,r,n)=2 integral_0^r [(r-s)/(r s)] P(u-s,s n) ds.

This sign corresponds to source angle beta=theta-grad_Omega L: the integrated transverse null deflection is minus the transverse gradient of Psi+Phi. Perturbed paths, lens-lens coupling and higher orders are not included. At r>0 and wherever differentiation under the integral is valid,

  p(u,r,n):=P(u-r,r n) = (1/2) partial_r[r^2 partial_r L]       (A)

with both radial derivatives holding u,n fixed. A regular observer-subtracted convention or integrable kernel is required at s=0; an arbitrary nonzero observer monopole cannot simply be integrated as P/s. Alternatively (A) is local on an interior interval for a defined Born potential. Interior contributions below the interval enter as f(u,n)+g(u,n)/r and are annihilated by (A).

A measured shear is not by itself such a calibrated L. On the full sky its scalar-to-spin-two operator annihilates ell=0,1; those radial/time-dependent modes of L would produce undetermined modes of P under (A). Finite masks/boundaries add inversion and calibration issues. For example L=c(u)r^2 is shear-null but gives P=3c(u)r^2. This block must retain the calibrated-potential premise, not declare shear sufficient.

For any scalar f and restriction ftilde(u,r,n)=f(eta=u-r,r n), define D=partial_r+partial_u. Then

  (partial_eta f)tilde=partial_u ftilde,
  (partial_r at fixed eta f)tilde=D ftilde,
  (nabla_com^2 f)tilde=[D^2+(2/r)D+(1/r^2)Delta_Omega]ftilde.  (B)

Angular derivatives hold eta,r fixed, which at fixed r also holds u fixed. At an event eta=u-r,

  f_dot=a^-1 partial_u ftilde,
  f_ddot=a^-2[partial_u^2-calH partial_u]ftilde,
  calH=a_eta/a=a h.                                         (C)

The physical spatial Laplacian is a^-2 times (B). D a(u-r)=0, as required for a derivative on a coeval slice. Replacing D by partial_r would confuse light-cone radial evolution with fixed-time radial geometry and omit mixed/time derivatives.

Repeated open observer-time coverage and open radial/angular neighborhoods map to a local spacetime domain, with eta=u-r and unit (u,r)->(eta,r) Jacobian. They can supply local jets in that domain if calibrated and smooth. A single cone cannot: (eta+r-u0)f(r,n) vanishes on u=u0 but has nonzero fixed-space time derivative. At fixed eta, coeval radial coverage requires observed u=eta+r for every radius in question. Finite observer-time and survey windows do not determine global coeval fields or Fourier modes, nor extensions or global boundary terms. The derivative operations are ill-conditioned without registered derivative/calibration uncertainty; small potential errors do not bound these high derivatives.

## Local pressure-trace rows and missing information

The previously checked pressure-trace equation is local, with background coefficients depending only on tau and no spatial derivative:

  2 P_ddot+8h P_dot+(4h_dot+6h^2)P
    = Atrace P_dot+Ctrace P+Etrace J_dot+Ftrace J.              (D)

Therefore independently registered angular positions on one shell r=r0 at a common u are coeval and may supply rows [P_dot,P,J_dot,J]. Rank four, consistency and the inverse's positivity/chart conditions remain necessary; merely counting directions does not establish rank. Different-radius rows must instead use u=eta+r to be coeval. This is a local coefficient extraction and does not require global Fourier modes. It is not complete full-action compatibility: the other metric/scalar/dust equations still need local spatial derivatives from (B), source/velocity information and relevant boundary/zero-mode conventions. On fields, Fourier k^2/a^2 is replaced by -a^-2 nabla_com^2, not an assigned effective shell wave number.

Lensing supplies P, not J. It therefore does not supply the four columns in (D). No selection of J, bias or initial mode is allowed to repair that missing input. The pressure-trace route is conditional on a second, registered measurement inversion for J or Psi. A rank-four angular fixture will establish only algebraic feasibility, not a full physical forward solution.

## Observer-time gain is not an emission-time gain

If Lhat=g(u)L, (A) gives phat=g(u)p because radial inversion holds u fixed. In coeval variables this means Phat(eta,x)=g(eta+|x|)P(eta,x). Unless g is constant it is spatially varying on a coeval domain, not a homogeneous emission-time multiplier gamma(eta). For r>0,

  nabla^2 Phat = g nabla^2P+2g' partial_r|eta P+(g''+2g'/r)P,  (E)

where g derivatives are observer-conformal-time derivatives. Time derivatives similarly carry g'/a and g'' terms. A fixed shell has a common multiplier g(eta+r0); if both P and J share it, its four-column derivative transformation has determinant g^4, preserving rank for g!=0 but changing inferred coefficients. Across radii it is not a single common temporal gain. Unknown observer gain cannot be treated as removed homogeneous normalization without an additional calibration argument.

## Photon energy, redshift and dust motion

Use conformal photon momentum, e=-k_0>0, and future propagation -n. The covariant geodesic equation gives

  d ln e/deta = partial_eta(Psi+Phi)                         (F)

along the background ray at first order. A matter observer with physical peculiar velocity v=dx/deta measures E=(e/a)[1-Psi+n dot v] to first order. Thus, at actual emission/observation events, the perturbation relative to their background scale-factor ratio is

  delta ln[(1+z) a_e/a_o]
    =Psi_o-Psi_e+n dot(v_e-v_o)
       -integral_eta_e^eta_o partial_eta(Psi+Phi) deta
    =Psi_o-Psi_e+n dot(v_e-v_o)-2 integral_0^r partial_u p ds. (G)

The final integral uses the unperturbed ray for already first-order quantities. The signs agree with a receding outward source giving positive redshift, an observer moving outward toward it giving negative Doppler redshift, and a negative source potential giving positive gravitational redshift. The partial_eta integrand is not the total derivative along the ray.

Actual-event times matter. For fixed coordinate endpoints and receiver u, the radial null equation gives eta_e=u-r+integral_0^r(Psi+Phi)ds at first order. Comparing with a(u)/a(u-r) instead of actual a_o/a_e adds -calH_e delta_eta_e; moving endpoints and observer clock registration add their own terms. These shifts cannot be silently dropped when combining (G) with a radius/redshift map. Evaluating perturbed integrands on the unperturbed path does not license dropping the background scale-factor endpoint shift.

For freely falling pressureless matter, linear particle momentum gives

  partial_eta v+calH v=-grad_com Psi.

For irrotational v=grad_com Z/a, this is grad_com(Z_dot+Psi)=0, hence Z_dot=-Psi after fixing its spatially constant time function. Bare/physical source conventions in the earlier scalar inverse must remain distinguished; in the matter metric number contrast obeys deltaJ_dot=3Phi_dot-a^-2 nabla^2Z. This matches the previous Z convention and is not a direct interpretation of redshift as velocity.

Redshift drift differentiates (G) and the background/endpoint factors, including endpoint potential time derivatives, Doppler derivatives, integrated second-time derivatives, emitter time mapping, clock lapse and changing endpoints/directions. It is not a peculiar acceleration observable by itself. Even comoving sources with v=0 in de Sitter have background drift dot(z)=H z. Euler-based recovery of grad Psi requires separately registered peculiar velocities and their time derivatives, Hubble drag, and boundary conventions; radial redshifts alone do not provide that input.
