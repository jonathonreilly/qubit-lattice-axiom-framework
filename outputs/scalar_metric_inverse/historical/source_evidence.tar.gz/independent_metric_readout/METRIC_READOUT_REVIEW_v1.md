# Focused metric-readout review

The final v2 metric-readout and redshift-transport sources agree with the independent light-cone, photon-energy and dust-Euler derivation. One consequential domain omission was found in transport v1 and repaired in v2: its arbitrary angular homogeneous family is local on r>0, not generally regular at the observer. The known velocity prose typo and the open-observer-interval endpoint notation were also repaired. No remaining coefficient/sign discrepancy was found in the reviewed scope. This is conditional mathematical and implementation checking, not a formal audit, observed scalar reconstruction, same-action non-identifiability theorem or priority claim. Root remains author.

## Chronology and source scope

I first read only the neutral task and the two expressly permitted existing mode inverse notes. The independent proof, source and 41 exact controls were frozen before reading the new author note, protocol, runners or outputs: PREEXPOSURE_FREEZE_v1.json SHA 6da4d630491b78e993a36997019fbfec18cefd12107c993bfe546385d615d218; proof SHA 12eb20e092cb744ecded43eb77e56e2ba9d05a17a91f3c0f54c6662b61752519. Independent source SHA af64d0eeeebb1c72dce9eb92afb1993b2a998be6b57f502d20f1ea769f18e9ee; result SHA 05190b79a495e827a1fad4953f08b8fbb226c3deca5cc76ba5875e2e72c0f48d. The 41 controls passed in 0.570523208938539 seconds with no failures.

After authorization I read the complete author v1 metric and transport arguments, protocol, three successful runner sources and all their results. I also inspected the exact earlier numerical-source repair diffs and failure receipts. The final v2 notes were checked through their complete retained v1 text and exact v1-to-v2 deltas. Snapshots and read identities are preserved. The current note hashes are:

- METRIC_READOUT_DERIVATION_v2.md: 4255600fc15f352a944b417a0aee87dca1e29f48830950a5211e2ef4441960ea.
- METRIC_REDSHIFT_TRANSPORT_DERIVATION_v2.md: dad79a62c7e4e1fae9117c3ea5d397ca38e62ea1becfc6f3f6dbc88e05573d16.
- METRIC_READOUT_INTAKE_v2.json: b4e1fcd319fd6359cbbe54a5c392d1c6d13415070dd55286d347d304afa453a3.

The intake and its stated root literature-read scopes were read as provenance metadata. I did not independently open or visually review those papers, access new observations, inspect seven unopened Fuchs arrays, or review the separate METRIC_FIXED_ACTION_CLOSURE candidate. That separate candidate remains outside this report, including any later conclusion about eliminating the annular family. The previous inverse notes supply expressly retained premises; this was not a full re-audit of those inverses.

## Correspondence and retained conditions

For a calibrated Born lensing potential, the inverse p=(1/2)partial_r(r^2 partial_r psi) agrees in sign and normalization, with u held fixed. The independent fixture has nonconstant time/radius/angle dependence and is separately compared with a Cartesian Laplacian. The operators partial_eta=partial_u, partial_r|eta=partial_r+partial_u and the stated mixed-derivative spherical Laplacian are correct. Proper-time second differentiation retains -Hc partial_u divided by a^2. The scalar-wave cancellation does not remove the trace's P_tau_tau or every high derivative needed by the inverse.

A single cone has unrestricted-metric null functions with distinct time jets; this is not a same-action physical counterexample. Repeated open cones give local spacetime coverage, while wide coeval coverage requires the open intersection (u0-r0,u1-r1). Global Fourier histories are not supplied by a finite patch. Shear null modes, radial integration constants, observer regularity, masks and calibration are different issues. In particular shear alone does not give a fully calibrated potential, and lensing never supplies J. Derivative error models, distance registration and proper clock maps remain required.

The pressure-trace relation is local, so coeval angular rows can replace global Fourier rows for coefficient extraction when [P_tau,P,J_tau,J] actually has rank four and the background/chart conditions hold. I constructed a distinct quadrupole angular design with determinant 288/625, explicitly only an algebraic rank witness. A finite row count is not a rank guarantee. Full scalar, constraint, matter and spatial-derivative residuals still need checking; an angular shell cannot be assigned an invented wave number. Angular projections commute with the linear homogeneous-background operators on a full sky, but do not establish masked-survey or unmeasured-mode validity.

The observer gain calculation is correct: a multiplier g(u) survives radial inversion but becomes g(eta+r) on a coeval domain. Its spatial product rule includes 2g_u partial_r|eta P+(g_uu+2g_u/r)P. It is not a homogeneous emission-time multiplier. On one shell a common nonzero gain on both P and J preserves row rank by a g^4 determinant, while modifying coefficients; lensing alone does not establish that shared response or remove calibration.

The energy derivation gives Psi_o-Psi_s+n dot(v_s-v_o)-integral(Psi_eta+Phi_eta), with n outward and photons traveling -n. A separate direct null-momentum/observer contraction check verifies these signs. The background radius map also needs the emission-time shift: delta eta_s=integral(Psi+Phi)ds and epsilon_bg=epsilon-Hc_s delta eta_s. This correction was independently derived before author exposure and is present in the transport note. Euler gives partial_eta v+Hc v=-grad Psi and Z_tau=-Psi after its spatially constant time convention is fixed. Redshift drift retains background, endpoint, clock, Doppler and integrated terms and is not a direct peculiar acceleration measurement.

## Transport extension and the repaired domain

The corrected residual Rz=-Psi+v_r and Euler produce (partial_r+2partial_u+Hc)Vhat=Rz. The characteristic c=u-2r has integrating factor a(c+r); the boundary function B(c,n) is an input, not derived by choosing it to vanish. The force equation follows because the necessary coefficient commutator vanishes: partial_r Hc+partial_u Hc=0. I independently checked this and both Euler components for nonconstant Hc=3/(1+eta), separate from the author's exponential-scale fixture.

The family delta V=a^-1 F(u-2r,n), delta Psi=delta v_r=-a^-1 F_c is valid on an interior annulus. It preserves the corrected radial redshift and P kinematically there. However, at r=0 its potential limit depends on n for general F; even isotropic nonconstant F gives a radial cusp unless F_c vanishes on the relevant origin-time interval. The explicit angular family and forced one-dimensional boundary formula do not alone establish a regular observer-inclusive three-dimensional solution. v2 now states the annular restriction and observer regularity/endpoint requirements. My exact nonzero witnesses of both obstructions are retained in EXTENSION_RESULTS_v1.json.

Finite observer-time coverage may omit the characteristic boundary at u-2r, but this is a property of the stated transport construction. It is not a no-go for every measurement protocol, and the family is not asserted to satisfy the Einstein/canonical-scalar constraints. Its free tracer density initial data and source registration remain conditions.

## Full-action rank witness and numerical scope

I separately reassembled the power-mode coefficients using P=t^p, momentum U_c=Y-2p-2 and Hamiltonian delta_c=-2k^2-6p-5+(2-p)Y. Euler gives Y=(2p^2+6p+3)/(p+3); number continuity gives k^2=-p(p+2)(2p^2+4p+9)/(2p^2+4p-3). The uneliminated scalar and pressure-trace residuals both vanish. Setting p=2m gives the author's family. The action's force and fixed-density curvature are -2/t^2 and 7/t^2, respectively. These checks support the original-equation status of this constructed family, with chosen initial modes, not observed growing modes.

A different exact four-mode sample gives trace determinant 286/1231005195 and the same Vandermonde coefficient 96. The trace rank is exactly four for distinct regular m values. The author's separate five-mode rational scalar determinant is nonzero; the floating rank tables are conditioning diagnostics, not interval certificates or physical likelihoods. At k0=1000 the frozen normalization has trace condition about 6e20 and scalar condition about 1.6e21; NumPy's smallest values are dominated by precision well before that. The 80-digit calculation and the declared 1e-10 relative-threshold ranks are accurately reported, with no threshold change. Algebraic rank and usable finite-precision rank are explicitly different.

The finite-grid noise stencil and its variance were independently rederived. The reported predicted RMS is the square root of mean variance, not a confidence certificate or a measured noise level. Its strong growth under smaller radial/time steps is retained. The 27 synthetic noise cases are not 27 physical pass/fail tests; only nine zero-noise baselines and ten numerical structural checks make the 19 numerical controls. No filter, fit or tolerance was adjusted after seeing them.

## Reproduction and preserved failures

All unchanged author-code replays are exact-byte reproductions with empty stderr and 120-second limits:

- Primary v1: 53 passed, zero failed, 0.9829854159615934 seconds; result b0a4c8b8b23ef555f6c33da577b93da63805bb705e3c299650332c7b45b13963.
- Numerical v3: 19 passed, zero failed, 0.13518904196098447 seconds; result c260ce358697434d206acb0dbb6f8b290635c5d4e2739c2e9f06eb391a7c1a1f.
- Transport v1: 20 passed, zero failed, 0.45223925029858947 seconds; result f96367d7547732eb5c75086b123bdb430861479ffbde78aecf84663da1bdda0e.

These original runner outputs bind the original v1 notes, not the later v2 prose. The v2 correspondence was reviewed separately; those historical hashes were not relabeled. The 41 independent pre-exposure controls and 25 distinct post-exposure extension controls are separate from the author replays. The extension passed in 0.40969570772722363 seconds with no failures; its source is a339946d309ccc774c61f84a55f5a53839233e23730cc34e26914eac1c8a4065. No new ODE or real-array run was needed.

The author's numerical v1 matrix-negative-index failure and v2 NumPy-bool JSON-export failure remain preserved with exact original source and receipt bytes. Diff inspection confirms only the explicit final-row indexing and bool conversion changed on the path to v3; the frozen protocol and tolerances did not change. These failures were not recast as physical rank loss or successful runs. The analytic omitted-term witnesses are not separately executed source-mutant programs. Original independent proof/results and all replay stdout/stderr remain immutable in this directory.
