"""Post-exposure independent extension checks; no import of author code."""
from pathlib import Path
import hashlib,json
import sympy as s
O=Path(__file__).resolve().parent
rows=[]
def ck(name,e):
 v=s.factor(s.cancel(e));rows.append({'name':name,'passed':v==0,'residual':str(v)})
def nonzero(name,e):
 v=s.factor(s.cancel(e));rows.append({'name':name,'passed':v!=0,'expected_nonzero':str(v)})
u,r,eta,mu,c=s.symbols('u r eta mu c',real=True)
a=(1+u-r)**3;Hc=3/(1+u-r);Q=(3*mu**2-1)/2
D=lambda f:s.diff(f,r)+s.diff(f,u)
A=lambda f:s.diff(f,u)+Hc*f
T=lambda f:s.diff(f,r)+2*s.diff(f,u)+Hc*f
V=((u-r+1)*r*r*Q+(u-r)*r**3*mu)/a
Psi=-A(V);vr=D(V);R=-Psi+vr
ck('nonconstant Hc transport source',T(V)-R)
ck('nonconstant Hc force transport',T(Psi)+A(R))
ck('nonconstant Hc radial Euler',A(vr)+D(Psi))
ck('nonconstant Hc operator commutator',T(A(V))-A(T(V)))
ck('characteristic integrating factor with polynomial a',s.diff((a*V).subs(u,c+2*r),r)-(a*R).subs(u,c+2*r))
Fc=(1+(u-2*r)+(u-2*r)**2)*Q
W=Fc/a;dPsi=-A(W)
ck('annular homogeneous family with nonconstant Hc',T(W))
ck('annular same redshift residual',-dPsi+D(W))
nonzero('annular family force changes',dPsi)
We=W.subs(u,eta+r);Psie=dPsi.subs(u,eta+r);ht=3/(1+eta)
ck('annular full radial Euler',s.diff(s.diff(We,r),eta)+ht*s.diff(We,r)+s.diff(Psie,r))
ck('annular full angular Euler',s.diff(s.diff(We,mu)/r,eta)+ht*s.diff(We,mu)/r+s.diff(Psie,mu)/r)
# Explicit regular-observer obstruction, not a rejection of an annular solution.
origin=s.limit(We,r,0)
nonzero('angular family has direction-dependent observer limit',origin.subs(mu,1)-origin.subs(mu,0))
isotropic=(eta-r)**2/(1+eta)**3
nonzero('isotropic nonconstant family has radial cusp at observer',s.diff(isotropic,r).subs(r,0))
# Independently reassemble old action power coefficients with exponent p, not 2m.
p,Y,K=s.symbols('p Y K',real=True)
Uc=Y-2*p-2
Dc=-2*K-6*p-5+(2-p)*Y
Euler=(p+2)*Uc+1+Y
Ysol=s.solve(Euler,Y)[0]
continuity=p*Dc-3*p-K*Uc
Ksol=s.factor(s.solve(continuity.subs(Y,Ysol),K)[0])
scalar=(p*p+2*p+K+7)*Y+Dc-4*p-4
trace=p*p+3*p+1-((p+3)*Y-1)/2
ck('original dust Euler independently solves field ratio',Euler.subs(Y,Ysol))
ck('original number continuity independently solves dispersion',continuity.subs({Y:Ysol,K:Ksol}))
ck('uneliminated original scalar confirms dispersion',scalar.subs({Y:Ysol,K:Ksol}))
ck('original pressure trace confirms field ratio',trace.subs(Y,Ysol))
ck('original momentum amplitude',p+1-(Y-Uc)/2)
ck('original Hamiltonian density amplitude',-2*K-3*(Y-Uc)-Dc-p*Y+1+2*Y)
m=s.symbols('m',real=True);z=m*(m+1)
ck('correspondence to author growing Y',Ysol.subs(p,2*m)-(8*m*m+12*m+3)/(2*m+3))
ck('correspondence to author growing k squared',Ksol.subs(p,2*m)-4*z*(8*z+9)/(3-8*z))
# A distinct exact sample and a column-reduction derivation of the trace basis.
ms=[s.Rational(1,20),s.Rational(1,9),s.Rational(1,7),s.Rational(2,9)]
y=lambda v:4*v+3/(2*v+3)
mat=s.Matrix([[v,1,v*y(v),y(v)] for v in ms]);prod=s.prod(ms[j]-ms[i] for i in range(4) for j in range(i+1,4))
ck('distinct exact trace Vandermonde sample',mat.det()-96*prod/s.prod(2*v+3 for v in ms))
nonzero('distinct exact trace minor nonzero',mat.det())
ck('rational long division of field ratio',((8*m*m+12*m+3)/(2*m+3))-(4*m+3/(2*m+3)))
# Exact coefficient-noise variance from differentiating the stencil response to
# independent input noise symbols, without using author's source weights.
dr,du,rr,sig=s.symbols('dr du rr sig',positive=True);em,e0,ep=s.symbols('em e0 ep')
first=(ep-em)/(2*dr);second=(ep-2*e0+em)/dr**2
inv=(rr**2*second+2*rr*first)/2
var=sig**2*sum(s.diff(inv,n)**2 for n in (em,e0,ep))
ck('independent stencil noise variance',var-sig**2*rr**2*(dr**2+3*rr**2)/(2*dr**4))
ck('independent second-time noise multiplier',var*sum(q*q for q in (1,-2,1))/du**4-6*var/du**4)
result={'scope':'Independent post-exposure nonconstant-clock transport, observer regularity counterexamples, original action coefficient reassembly and stencil variance; no observational inputs','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':rows,'passed':sum(q['passed'] for q in rows),'failed':sum(not q['passed'] for q in rows),'power_ratio':str(Ysol),'dispersion':str(Ksol),'distinct_minor':str(mat.det()),'domain':'Transport fixtures on an interior annulus with eta>-1; no global regular-observer or full-action claim for kinematic family'}
(O/'EXTENSION_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':result['passed'],'failed':result['failed'],'failed_controls':[q for q in rows if not q['passed']],'power_ratio':str(Ysol),'dispersion':str(Ksol),'distinct_minor':str(mat.det())},indent=2));assert result['failed']==0
