"""Blind metric-input controls; no imports of root metric-readout implementation."""
from pathlib import Path
import hashlib,json
import sympy as s
O=Path(__file__).resolve().parent
rows=[]
def eq(name,q):
 z=s.factor(s.cancel(q));rows.append({'name':name,'passed':z==0,'residual':str(z)})
def truth(name,q,detail):rows.append({'name':name,'passed':bool(q),'detail':str(detail)})
eta,u,r,rr,m,ep,t0=s.symbols('eta u r rr m ep t0',real=True)
X,Y,Z=s.symbols('X Y Z',real=True)
Pc=eta**2*(2*Z**2-X**2-Y**2)+eta*Z**3+(eta+1)*(X**2+Y**2+Z**2)+Z**4
P=eta**2*r**2*(3*m*m-1)+eta*r**3*m**3+(eta+1)*r*r+r**4*m**4
p=P.subs(eta,u-r)
L=s.integrate(2*(r-rr)/(r*rr)*P.subs({eta:u-rr,r:rr}),(rr,0,r))
R=lambda f:s.diff(r*r*s.diff(f,r),r)/2
D=lambda f:s.diff(f,r)+s.diff(f,u)
DO=lambda f:s.diff((1-m*m)*s.diff(f,m),m)
LC=lambda f:D(D(f))+2*D(f)/r+DO(f)/r**2
eq('Born radial inversion on polynomial spacetime potential',R(L)-p)
eq('local inverse removes missing-interior constant',R(u*m)-0)
eq('local inverse removes missing-interior 1/r term',R(u*u*m/r)-0)
eq('calibrated lensing potential integration has chosen radial boundary',s.limit(r*r*s.diff(L,r),r,0))
eq('fixed-space conformal time derivative',s.diff(p,u)-s.diff(P,eta).subs(eta,u-r))
eq('fixed-time radial derivative requires both operators',D(p)-s.diff(P,r).subs(eta,u-r))
cartlap=sum(s.diff(Pc,z,2) for z in (X,Y,Z)).subs({X:0,Y:0,Z:r*m})
# This fixture's Laplacian depends only on Z, so this substitution is exact.
eq('coeval spherical Laplacian versus independent Cartesian Laplacian',LC(p)-cartlap.subs(eta,u-r))
truth('naive light-cone radial Laplacian is different',s.simplify(s.diff(p,r,2)+2*s.diff(p,r)/r+DO(p)/r**2-LC(p))!=0,'nonconstant time and radial geometry')
a=(1+eta)**2;al=a.subs(eta,u-r);calH=s.diff(a,eta)/a
Dt=lambda f:s.diff(f,u)/al
proper_second=s.diff(s.diff(P,eta)/a,eta)/a
eq('matter proper-time first derivative',Dt(p)-(s.diff(P,eta)/a).subs(eta,u-r))
eq('matter proper-time second derivative',Dt(Dt(p))-proper_second.subs(eta,u-r))
eq('second time derivative includes conformal Hubble correction',Dt(Dt(p))-(s.diff(p,u,2)-calH.subs(eta,u-r)*s.diff(p,u))/al**2)
eq('coeval spatial derivative leaves background scale factor fixed',D(al))
eq('lightcone coordinate Jacobian',s.Matrix([[1,-1],[0,1]]).det()-1)
f=(eta+r-t0)*r*r
truth('single cone has invisible time jet',f.subs(eta,t0-r)==0 and s.diff(f,eta)!=0,'(eta+r-u0)r^2 vanishes on one cone')
# Axisymmetric spin-two shear is proportional to (1-m^2) f_mm.
shear=lambda f:(1-m*m)*s.diff(f,m,2)
eq('full-sky monopole angular null',shear(r*r))
eq('full-sky dipole angular null',shear(r*r*m))
truth('shear-null potential changes recovered P',s.simplify(R(r*r)-3*r*r)==0 and R(r*r)!=0,'calibration is not delivered by shear alone')
truth('quadrupole shear is nonzero',shear(r*r*(3*m*m-1))!=0,'nonvacuous spin operator')
# Observer-time multiplicative gain.
g=1+u+u*u
eq('observer-time gain passes unchanged through radial inversion',R(g*L)-g*p)
gc=1+(eta+r)+(eta+r)**2
coeval_g=g.subs(u,eta+r)
eq('observer gain restricted to coeval coordinates',gc-coeval_g)
truth('observer gain is not homogeneous at emission time',s.diff(gc,r)!=0,'radial gradient 1+2(eta+r)')
def lapco(f):return s.diff(f,r,2)+2*s.diff(f,r)/r+DO(f)/r**2
gp=s.diff(g,u).subs(u,eta+r);gpp=s.diff(g,u,2).subs(u,eta+r)
eq('coeval gain produces spatial derivative terms',lapco(gc*P)-(gc*lapco(P)+2*gp*s.diff(P,r)+(gpp+2*gp/r)*P))
eq('homogeneous emission gain has no spatial derivative terms',lapco((1+eta+eta*eta)*P)-(1+eta+eta*eta)*lapco(P))
G,Gt=s.symbols('G Gt');gainmap=s.Matrix([[G,0,0,0],[Gt,G,0,0],[0,0,G,0],[0,0,Gt,G]])
eq('fixed-shell common metric gain rank transformation',gainmap.det()-G**4)
# Four coeval angular rows of ell=2 harmonics; this is an algebraic trace witness.
points=[(0,0,1),(1,0,0),(s.Rational(3,5),0,s.Rational(4,5)),(0,s.Rational(3,5),s.Rational(4,5))]
angular=s.Matrix([[3*z*z-1,x*z,y*z,x*x-y*y] for x,y,z in points])
truth('four angular-shell rows can have rank four',angular.rank()==4,angular.det())
h,hd,A,C,E,F=s.symbols('h hd A C E F');coef=s.Matrix([A,C,E,F]);rhs=angular*coef
Psecond=s.Matrix([(rhs[i]-8*h*angular[i,0]-(4*hd+6*h*h)*angular[i,1])/2 for i in range(4)])
y=s.Matrix([2*Psecond[i]+8*h*angular[i,0]+(4*hd+6*h*h)*angular[i,1] for i in range(4)])
truth('local trace rows recover coefficients without Fourier wave numbers',angular.inv()*y==coef,'algebraic rank/identity only; not a coupled forward solution')
rank1=s.Matrix([[j,2*j,3*j,4*j] for j in (1,2,3,4,5)])
truth('number of angular rows does not establish rank',rank1.rank()==1,'five rows, rank one')
# Photon energy from conformal null momentum, then endpoint contraction.
x=s.symbols('x',real=True);ee=s.symbols('ee',positive=True)
Psi=s.Function('Psi')(eta,x);Phi=s.Function('Phi')(eta,x);vel=s.symbols('vel',real=True)
g00=-(1+2*ep*Psi);g11=1-2*ep*Phi
kt=ee*(1-2*ep*Psi);kx=-ee*(1-ep*Psi+ep*Phi)
eq('chosen future photon null through first order',s.diff(g00*kt*kt+g11*kx*kx,ep).subs(ep,0))
k0dot=(s.diff(g00,eta)*kt**2+s.diff(g11,eta)*kx**2)/2
elnprime=-k0dot/(kt*ee)
eq('covariant photon energy partial-time derivative sign',s.diff(elnprime,ep).subs(ep,0)-s.diff(Psi+Phi,eta))
localE=-((1-ep*Psi)*(-ee)+ep*vel*g11*kx)
eq('matter photon energy Doppler and lapse signs',s.diff(localE/ee,ep).subs(ep,0)-(-Psi+vel))
psio,psie,vo,ve,I=s.symbols('psio psie vo ve I')
ratio=(1-ep*psie+ep*ve)/((1+ep*I)*(1-ep*psio+ep*vo))
eq('redshift endpoint Doppler integrated sign',s.diff(ratio,ep).subs(ep,0)-(psio-psie+ve-vo-I))
truth('outward receding source Doppler redshift positive',(psio-psie+ve-vo-I).subs({psio:0,psie:0,ve:1,vo:0,I:0})==1,'n is outward; photon propagates -n')
truth('observer toward source Doppler redshift negative',(psio-psie+ve-vo-I).subs({psio:0,psie:0,ve:0,vo:1,I:0})==-1,'observer moves outward')
truth('deep source gravitational redshift positive',(psio-psie+ve-vo-I).subs({psio:0,psie:-1,ve:0,vo:0,I:0})==1,'static potential endpoint test')
S=eta*x
partialint=s.integrate(s.diff(S,eta).subs({eta:u-rr,x:rr}),(rr,0,r))
endpointS=S.subs({eta:u,x:0})-S.subs({eta:u-r,x:r})
truth('integrated partial time derivative is not path total derivative',s.simplify(partialint-endpointS)!=0,'spatial gradients enter the path total derivative')
# Homogeneous Psi=Phi=f(eta): physical spatial scale is a(1-f).
fe,fo=s.symbols('fe fo')
eq('homogeneous time-only potential redshift agrees with spatial scale',((fo-fe)-2*(fo-fe))-(fe-fo))
nullpast=-s.sqrt((1-2*ep*Phi)/(1+2*ep*Psi))
eq('fixed-radius emission-time shift sign',s.diff(nullpast,ep).subs(ep,0)-(Psi+Phi))
shift=s.symbols('shift');af=s.Function('af');E0=u-r
scale_shift=af(E0)/af(E0+ep*shift)
eq('background redshift factor retains endpoint time shift',s.diff(scale_shift,ep).subs(ep,0)+s.diff(af(E0),u)/af(E0)*shift)
# Direct velocity-potential conversion of the pressureless Euler equation.
Zf=s.Function('Zv')(eta,x);av=s.Function('a')(eta);ps=s.Function('ps')(eta,x)
vfield=s.diff(Zf,x)/av
Euler=s.diff(vfield,eta)+s.diff(av,eta)/av*vfield+s.diff(ps,x)
eq('Euler yields proper-time velocity potential equation',Euler-s.diff(s.diff(Zf,eta)/av+ps,x))
# Background cosmological drift exists with zero peculiar acceleration.
HH=s.symbols('HH',positive=True);aDS=1/(1-HH*u);zDS=(1-HH*(u-r))/(1-HH*u)-1
eq('de Sitter comoving redshift drift is H z',s.diff(zDS,u)/aDS-HH*zDS)
truth('redshift drift is not peculiar acceleration',s.simplify(s.diff(zDS,u)/aDS)!=0,'comoving v=0; H z generally nonzero')
result={'kind':'Independent neutral-problem exact symbolic controls before new author exposure','source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'proof_sha256':hashlib.sha256((O/'INDEPENDENT_DERIVATION_v1.md').read_bytes()).hexdigest(),'checks':rows,'passed':sum(q['passed'] for q in rows),'failed':sum(not q['passed'] for q in rows),'angular_rank_fixture_determinant':str(angular.det()),'new_author_metric_sources_read':False,'limitations':['Calibrated potential and registered geometry/clocks assumed','No J supplied by lensing','Angular rank fixture is algebraic, not a full action solution','First order Born/null approximation only','No observed data, statistical significance or full audit']}
(O/'INDEPENDENT_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'passed':result['passed'],'failed':result['failed'],'failed_controls':[q for q in rows if not q['passed']],'angular_rank_fixture_determinant':str(angular.det())},indent=2))
assert result['failed']==0
