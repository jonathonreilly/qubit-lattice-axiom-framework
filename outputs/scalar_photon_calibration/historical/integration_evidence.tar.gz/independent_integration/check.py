"""Independent integration correspondence; no canonical output writes."""
AUDIT_TIMEOUT_SEC = 120
from pathlib import Path
import json,hashlib,math,sys
import sympy as s
O=Path(__file__).resolve().parent;R=O.parents[2]
P=Path('/Users/jonBridger/.codex/worktrees/observations-backward-derivation-24h-20261015/New Axioms Lets Go/.claude/science/physics-loops/observations-backward-derivation-24h-20261015/independent_reception_gain')
current=json.loads((R/'outputs/scalar_photon_calibration/result.json').read_text());old=json.loads((P/'robustness_stdout.json').read_text());res=json.loads((P/'robustness_original_residuals_stdout.json').read_text());out=[]
def check(n,b):out.append({'name':n,'pass':bool(b)})
def close(a,b):return math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-15)
c=current['units']['conditioning_and_omission']['details']
check('condition_correspondence',close(c['scaled_condition_number'],old['condition_scaled']))
check('complete_singular_spectrum',all(close(a,b) for a,b in zip(c['scaled_singular_values'],old['singular_values_scaled'])) and len(c['scaled_singular_values'])==12)
for a,b in zip(c['noise_cases'],old['noise_runs']):
 check('noise_'+str(a['epsilon']),a['epsilon']==b['epsilon'] and close(a['relative_coefficient_error'],b['relative_coefficient_error']) and close(a['recovered_beta'],b['recovered']['beta']) and close(a['unused_angular_relative_residual'],b['heldout_relative_residual']))
check('cross_shell_correspondence',c['omission_cross_shell']=={'C_difference':res['cross_shell']['C_outer_minus_inner'],'e_difference':res['cross_shell']['e_outer_minus_inner']})
for key,oldkey in [('Raychaudhuri','Raychaudhuri'),('scalar_background','original_scalar'),('bare_dust_background','bare_dust_transport'),('coefficient_k_consistency','coefficient_k_consistency')]:check('original_residual_'+key,s.simplify(s.sympify(c['omission_original_residuals'][key])-s.sympify(res['background_residuals'][oldkey]))==0)
check('shared_coefficients_correspondence',current['units']['common_reception']['details']['fixture']['theta_at_point']==['34/5','2/5','721/25','2','176/5','2484/25','19/5','1014/25','6024/125','-2/5','-16/25','77/125'])
# Independent abstract photon product rule: I'=I1/a, B=a*g*I.
a,h,g,f,I,I1,gu=s.symbols('a h g f I I1 gu',nonzero=True)
chi=f/g;beta=gu/(a*g);B=a*g*I;Bt=h*B+gu*I+g*I1
Y=s.symbols('Y');W=f*Y+2*(g-f)*I1+2*gu*I
ss=2*(chi-1);v=-ss*h-2*chi*beta
check('actual_event_separate_path_reduction',s.expand(W+ss*Bt+v*B-f*Y)==0)
check('shared_path_specialization',s.simplify(W.subs(f,g)-g*Y-2*beta*B)==0)
# Compare complete shared-gain coefficient implementation with earlier independent expansion.
sys.path.insert(0,str(R/'scripts'));import scalar_photon_reception_core as core
t=s.symbols('t');H,C,d,e,k=[s.Function(n)(t) for n in ['h','C','d','e','k']];b,bp,bpp=s.symbols('b bp bpp')
DT=lambda z:s.diff(z,t)+s.diff(z,b)*bp+s.diff(z,bp)*bpp
LC=lambda z:s.diff(z,t)+s.diff(z,b)*(2*bp+H*b)+s.diff(z,bp)*(2*bpp+2*H*bp+(DT(H)+H*H)*b)
K=DT(C)+H*C;A=H+C-b;m=DT(d)+(H-2*b)*d;v=e-d*b;n=LC(v)+(H-2*b)*v;tt=bp+b*(H+C-b);z=2*b+k
expected=[-z,C-b,LC(A)-z*A+K-DT(H),d,LC(d)+m-z*d,LC(m)-z*m-2*b,v,LC(v)+n-z*v,LC(n)-z*n-2*H*b-2*tt,-4*b,-2*LC(b)+2*z*b-4*tt,2*b*(DT(H)+H*H)-2*LC(tt)+2*H*tt+2*z*tt-2*K*b]
check('all_shared_coefficients_independent_expansion',all(s.expand(x-y)==0 for x,y in zip(expected,core.coefficients(C,d,e,H,b,k,K,DT,LC))))
manifest=json.loads((O/'frozen_sources.json').read_text());check('canonical_sources_unchanged',all(hashlib.sha256((R/f).read_bytes()).hexdigest()==v for f,v in manifest.items()))
print(json.dumps({'checks':out,'passed':sum(x['pass'] for x in out),'failed':sum(not x['pass'] for x in out),'comparison_inputs':{str(P/f):hashlib.sha256((P/f).read_bytes()).hexdigest() for f in ['robustness_stdout.json','robustness_original_residuals_stdout.json']}},indent=2))
raise SystemExit(any(not x['pass'] for x in out))
