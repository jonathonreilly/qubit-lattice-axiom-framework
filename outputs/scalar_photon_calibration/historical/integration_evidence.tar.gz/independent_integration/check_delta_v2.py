"""Independent operator-list implementation plus targeted helper reproduction."""
AUDIT_TIMEOUT_SEC=120
from pathlib import Path
import sys,json,hashlib
import sympy as s
u,r=s.symbols('u r');b=2+u-r;a=1/b;h=-s.Integer(1)
T=lambda v:s.expand(b*s.diff(v,u));L=lambda v:s.expand(b*(2*s.diff(v,u)+s.diff(v,r)))
Td=lambda v:s.expand(-T(v)-v);Ld=lambda v:s.expand(-L(v)-v)
Q=lambda v:r*r*s.diff(v,r)/2;Qd=lambda v:-s.diff(r*r*v,r)/2;Dr=lambda v:s.diff(r*r*s.diff(v,r),r)/2
lam=(u*(1-u)*r*(1-r))**6;psi=b*b*(u+2*r)**3;z=1+u*r*r+u**4
th=[s.Rational(i,7)+u*u+s.Rational(i%4,3)*r for i in range(1,15)]
termsW=[(1,[T,L]),(h+th[1],[L]),(th[0],[T]),(th[2],[])]
termsX=[(th[3],[T,L,L]),(th[4],[T,L]),(th[5],[T]),(th[6],[L,L]),(th[7],[L]),(th[8],[]),(th[9],[T,T])]
termsB=[(th[10],[T,T,T]),(th[11],[T,T]),(th[12],[T]),(th[13],[])]
def chain(v,ops):
 for op in ops:v=op(v)
 return v
adj={T:Td,L:Ld}
def apply(terms,field):return sum(c*chain(field,ops) for c,ops in terms)
def weight(terms):return sum(chain(c*lam,[adj[op] for op in reversed(ops)]) for c,ops in terms)
def integ(f):
 p=s.Poly(s.cancel(f),u,r);return sum(c/((i+1)*(j+1)) for (i,j),c in p.terms())
HW,HX,HB=map(weight,[termsW,termsX,termsB]);HP=Dr(HX)+Qd(a*HB-2*s.diff(HW,u))
strong=integ(lam*(apply(termsW,z+2*s.diff(Q(psi),u))+apply(termsX,Dr(psi))+apply(termsB,a*Q(psi))))
weak=integ(HW*z+HP*psi)
checks={'distinct_polynomial_witness_nonzero':strong!=0,'independent_operator_list_primitive_identity':strong==weak,'time_divergence':s.diff(b,u)==-h,'L_divergence':2*s.diff(b,u)+s.diff(b,r)==-h}
O=Path(__file__).resolve().parent;R=O.parents[2];sys.path.insert(0,str(R/'scripts'));import scalar_photon_weak_controls as mod
cs,details=mod.run_checks();checks['targeted_helper_all_controls']=all(c['pass'] for c in cs) and len(cs)==19
frozen=json.loads((O/'delta_v2_sources.json').read_text());checks['unchanged_frozen_delta']=all(hashlib.sha256((R/f).read_bytes()).hexdigest()==v for f,v in frozen['sha256'].items())
print(json.dumps({'independent_checks':checks,'strong_exact':str(strong),'weak_exact':str(weak),'helper_checks':cs,'helper_details':details},indent=2));raise SystemExit(not all(checks.values()))
