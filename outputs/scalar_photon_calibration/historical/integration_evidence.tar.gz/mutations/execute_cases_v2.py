"""Focused scratch-source mutation checks; not empirical science."""
AUDIT_TIMEOUT_SEC = 600
import concurrent.futures
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
CASES = json.loads((HERE / 'cases_v2.json').read_text())
CHILD = '''import importlib,json,sys,traceback
m=importlib.import_module(sys.argv[1])
exception=None
try:
 checks,details=m.run_checks()
except Exception as e:
 exception=type(e).__name__+': '+str(e)
 checks=[{'name':n,'pass':bool(v)} for n,v in getattr(m,'checks',{}).items()]
 details={'traceback':traceback.format_exc()}
record={'checks':checks,'details':details,'exception':exception}
open('result.json','w').write(json.dumps(record,indent=2,sort_keys=True)+'\\n')
failed=[c['name'] for c in checks if not c['pass']]
print(json.dumps({'failed_checks':failed,'exception':exception}))
sys.exit(1 if failed or exception else 0)
'''

def execute(case):
    folder = HERE / case['name']
    started = time.monotonic()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
    try:
        result = subprocess.run([sys.executable, '-B', '-c', CHILD, case['module']],
            cwd=folder, env=env, capture_output=True, text=True, timeout=120)
        (folder/'stdout.txt').write_text(result.stdout)
        (folder/'stderr.txt').write_text(result.stderr)
        output=json.loads((folder/'result.json').read_text())
        failed=[c['name'] for c in output['checks'] if not c['pass']]
        record=dict(case, exit_code=result.returncode, failed_checks=failed,
            exception=output['exception'], elapsed_seconds=time.monotonic()-started,
            detected=result.returncode!=0 and case['expected_failed_check'] in failed)
    except Exception as exc:
        record=dict(case, detected=False, operational_failure=repr(exc),
            elapsed_seconds=time.monotonic()-started)
    (folder/'receipt.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    print(case['name'], record['detected'], flush=True)
    return record

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    records=list(pool.map(execute, CASES))
(HERE/'RESULTS_v2.json').write_text(json.dumps(records,indent=2,sort_keys=True)+'\n')
raise SystemExit(0 if all(r['detected'] for r in records) else 1)
