# M19 personally derived working inverse, v1
Status: unverified working conditional mathematics; 2026-10-15, root.

Use inherited physical-metric action F R/2 - Z(dz)^2 - Hxx(dx)^2 - Hyy(dy)^2 - V, with F=f0(s+z²), Z=f0/lambda. Only for the inverse impose vacuum and the consistent x=y=0 sector. These premises remain supplied, not derived. Metric ds²=-N²dt²+dr²/B+r²dOmega², ell=logN, B>0.

Gt=(B-1)/r²+B'/r;
Gr=(B-1)/r²+2B ell'/r;
Ga=B(ell''+ell'^2+ell'/r)+B'/2(ell'+1/r).

With K=Z z'^2+Hxx x'^2+Hyy y'^2 and DboxF=B F''+(B'/2+B ell'+2B/r)F':
-rho=F Gt+B K+V+B F''+(B'/2+2B/r)F';
pr=F Gr-B K+V+B(ell'+2/r)F';
pt=F Ga+B K+V+B F''+(B'/2+B ell'+B/r)F'.
These define required stresses, not a matter action. Their conservation residual is minus the contraction of the scalar Euler-Lagrange residuals with (z',x',y'); it does not generally check all three equations.

In the radial vacuum sector, tangential-minus-time metric equations give
u_g := (Ga-Gt)/[B(1/r-ell')] = F'/F.
Use u below for this geometric log derivative, not the old scalar coordinate.
Let
H := Gr-Gt - B(u'+u²) - (B'/2-B ell')u,
j := B u²/(2H).
For nonzero u, H>0, exact vacuum equations give
H=B(s+Y)u²/(2lambda Y), Y=z²>0,
j=lambda Y/(s+Y), X=s+Y=s lambda/(lambda-j),
Y=s j/(lambda-j).
Since X'/X=u, j'=u(lambda-j). Hence for I_ab=int_a^b u dr and E_ab=exp(-I_ab):
lambda=(j_b-E_ab j_a)/(1-E_ab), provided E_ab !=1.
This uses third lapse and second B derivatives in H, an integral of u, and two point j values; it avoids differentiating j (fourth lapse derivative). The inferred lambda must be constant for all subintervals and exceed all j>0. The candidate requires lambda>1 and uniquely gives
k=(1-2/sqrt(1+3lambda))/3,
a=lambda/(1+3lambda), s=(1+k)/(k(1-3k)).
No scalar boundary or f0 is used by this inverse. It is not a measurement unless the complete metric/derivative/radius/error supplier and vacuum/truncation hold.

From tt equation,
Wg := V/F = -Gt-H/2-B(u'+u²)-(B'/2+2B/r)u,
P=V/f0=X Wg.
The given candidate potential on x=y=0 is
P=Hv² A(Y)+Hv² nu C(Y),
A=3(s+Y²), C=Y²(logY)²/(4a).
Two radius values with A1 C2-A2 C1 !=0 determine Hv² and Hv²nu. Both must be positive and the equality must hold across the domain. These are inverse fitted/ reconstructed values, not absolute scale derivation from axioms. Q remains absent. Metric radius normalization sets units.

Sufficiency candidate: if metric smooth on an annulus, all nondegenerate conditions hold, a single lambda satisfies the integral identity throughout, recovered positive Hv²,nu match P throughout, then reconstructed z>0,x=y=0 satisfies all three metric equations. Since u !=0, z'!=0. The vacuum Bianchi identity then forces z's scalar EOM. Evenness of full action in x,y makes x=y=0 equations vanish. This is a local static solution, not global completion, stability, preparation or selected physical sector.

Degeneracy: constant z=1 with B=1-2M/r-Hv²r²,N=sqrtB solves vacuum equations for every k,nu in their allowed ranges. There u=H=0 and j is undefined; inversion must refuse. A zero in B(1/r-ell') is a chart-specific excluded denominator; no no-go there. Full x,y gradients modify H by +2B(Hxx x'^2+Hyy y'^2)/F, so the single-sector j identity is not a general full-three-field inference. Material rho+pt or rho+pr modify both null differences. A metric alone cannot establish their absence.

Coupled local solution generator (dimensionless f0=1, chosen only for synthetic fixture): F=s+z²,Z=1/lambda. v=z'. Let
S=[Vz-2Fz V/F-Fz Bv²(Z+3Fzz/2)/F]/[2Z+3Fz²/(2F)],
ell'=[BZv²-V-F(B-1)/r²-2BFzv/r]/[B(2F/r+Fzv)],
B'=r/F[-F(B-1)/r²-B(Z+Fzz)v²-V-Fz S+B Fz ell' v],
v'=S/B-(B'/(2B)+ell'+2/r)v.
These require independent original metric/scalar residual checks, not merely self-consistent integration. Use original equations and a separately generated Einstein-frame solution if possible. Exact input profiles are synthetic and exposed; no empirical validation.
