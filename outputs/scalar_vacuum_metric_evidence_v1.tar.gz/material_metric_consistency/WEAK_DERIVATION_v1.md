# Working weak metric inverse, root derivation

Unpublished extension probe. Same supplied action, static radial vacuum sector, regular u!=0 and D!=0 chart as the canonical M19 note. Keep the same qualitative C3 lapse/C2 B class; the aim is to evaluate the inverse without direct third-lapse/second-B derivative inputs, not claim a weaker solution class. No measured metric or empirical error supplier is added.

Let q=1/r-ell', and let h(r0)=1. The angular-time equation yields

    u = -q'/q - B'/(2B) - 2/r - ell' + 1/(B r² q),
    h = [q0 sqrt(B0) r0² N0]/[q sqrt(B) r² N]
        * exp integral_(r0)^r [1/(B t² q)] dt.

Thus h=F/F(r0)>0 uses only N,N',B and an integral. Its logarithmic derivative u still uses N'' and B' when needed below. No physical scalar amplitude or boundary value is selected by h(r0)=1.

Write eta=s/X(r0)>0, X=s+z²=s h/eta and Y=z²=s(h/eta-1). Admit0<eta<inf h. For a nonnegative nonzero C1 weight w with compact support, integration of the radial-minus-time equation gives

    K[w] = integral w [2ell'/r-B'/(Br)-u²-(B'/(2B)-ell')u] + integral w' u,
    A[w;eta] = integral w u² h/(h-eta),
    K[w] = A[w;eta]/(2lambda).

Only N'' and B' appear. Choose two weights whose supports have strictly ordered, disjoint h ranges, h(supp w1)<h(supp w2). They can be ordered this way on the u!=0 chart because h is monotone. Both A positive. The derivative d(log A)/deta is a positive weighted mean of1/(h-eta), so d log(A1/A2)/deta>0. Therefore K1/K2=A1(eta)/A2(eta) has at most one eta in the admitted interval; existence and K1,K2>0 remain checks. Recover lambda=A1/(2K1)>1, k from the canonical relation, s(k), then Y=s(h/eta-1). No derivative of u or measured j is used. Two moment fits alone do not ensure the original equations: all compact weights (or equivalent full-interval identities) remain necessary for exact local membership. A finite set provides only partial checks.

For potential coefficients set X=s h/eta. Integration of the time equation gives

    T[w]=integral X[-w(Gt+Gr)/2 + (B u/2)w'
                    + w(B'/4-B ell'/2-2B/r)u],
    T[w]=Hv² integral w*3(s+Y²)
          +(Hv²nu) integral w*Y² ln²Y/(4a).

The integration-by-parts identity follows by adding derivative(w X B u/2) to w X W and using X'=uX; compact boundaries remove it. Two weights with nonzero integrated determinant recover positive coefficients, with later weights checking them without refitting. If Y>1 and the ranges are strictly ordered, the monotonic C(Y)/A(Y) gives a nonzero integrated determinant too. Interval sufficiency is inherited only after all weak equations, with the same regularity; this is not inferred from finitely many numerical moments.

Fixed weights are a chosen readout design, not an action/state selector. In finite data, metric/derivative error, numerical quadrature and inverse conditioning still need calibrated bounds. No actual second-derivative bound, vacuum test, sector selection or absolute Q/f0 is supplied. This probe is not yet part of the reviewed canonical theorem.
