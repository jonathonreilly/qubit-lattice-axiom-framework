"""Bind frozen canonical source/products and saved mutation claims; no science run."""
from pathlib import Path
import ast,hashlib,json
O=Path(__file__).resolve().parent;W=Path('/Users/jonBridger/.codex/worktrees/observations-backward-24h-20261014/New Axioms Lets Go')
def sha(b):return hashlib.sha256(b).hexdigest()
def load(n):return json.loads((O/n).read_text())
source=load('CANONICAL_EXPOSURE_v1.json');products=load('CANONICAL_PRODUCTS_EXPOSURE_v1.json')
snaps={}
for row in source['files']+products['files']:
 b=(O/row['snapshot']).read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes'];snaps[row['path']]=b
binding=load('CANONICAL_PRODUCTS_EXPOSURE_v1__CANONICAL_BINDING_v1.json');run=binding['result']
res=load('CANONICAL_PRODUCTS_EXPOSURE_v1__RESULTS_v1.json');summary=load('CANONICAL_PRODUCTS_EXPOSURE_v1__SUMMARY_v1.json')
primary=snaps['scripts/scalar_vacuum_metric_check.py'];helper=snaps['scripts/scalar_vacuum_metric_inverse.py']
paths=next(ast.literal_eval(n.value) for n in ast.parse(primary).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in n.targets))
assert len(paths)==len(set(paths))==5
h=hashlib.sha256(b'runner-cache-input-fingerprint-v1\0');ids={}
for path in paths:
 b=snaps.get(path,(W/path).read_bytes());pb=path.encode();ids[path]=sha(b)
 h.update(len(pb).to_bytes(8,'big'));h.update(pb);h.update(len(b).to_bytes(8,'big'));h.update(b)
assert ids==res['input_sha256']==summary['input_sha256']
identity={'runner_sha256':sha(primary),'input_fingerprint_sha256':h.hexdigest()}
assert identity==binding['execution_identity']['content']
assert sha(primary)==res['primary_sha256']==summary['primary_sha256']
for path,value in binding['files'].items():assert sha(snaps[path])==value
cache=snaps['logs/runner-cache/scalar_vacuum_metric_check.txt']
header,tail=cache.decode().split('----- stdout -----\n',1);stdout,stderr=tail.split('\n----- stderr -----\n',1)
meta=dict(l.split(': ',1) for l in header.splitlines() if ': ' in l)
assert meta['runner_sha256']==sha(primary) and meta['input_fingerprint_sha256']==h.hexdigest()
assert meta['status']==run['status']=='ok' and meta['exit_code']=='0' and run['exit_code']==0
assert meta['timeout_sec']=='180' and run['timeout_sec']==180
assert stdout.rstrip('\n')==run['stdout'].rstrip('\n') and not stderr.strip() and run['stderr']==''
assert format(run['elapsed_sec'],'.2f')==meta['elapsed_sec'] and 0<run['elapsed_sec']<180
assert json.JSONDecoder().raw_decode(stdout[stdout.index('{'):])[0]==summary
assert res['counts']==summary['counts']=={'passed':70,'failed':0} and len(res['checks'])==70 and all(c['passed'] for c in res['checks'])
assert summary['failed_checks']==[] and binding['cache_status']=='fresh'
assert all(res[k]==v for k,v in summary.items() if k in res)
assert next(c for c in res['checks'] if c['name']=='negative_potential_parameter_guard')['solver_success'] is True
mut=load('CANONICAL_MUTATION_REPORT_EXPOSURE_v1.json');assert mut['original_source_sha256']==sha(helper)
records=[]
for row in mut['records']:
 text=helper.decode()
 for old,new in row['replacements']:
  assert text.count(old)==1;text=text.replace(old,new,1)
 assert sha(text.encode())==row['source_sha256']
 assert row['rejected_by_false_controls'] is True and row['exception'] is None and len(row['failed_controls'])>0 and all(c['passed'] is False for c in row['failed_controls'])
 records.append({'name':row['name'],'source_sha256':row['source_sha256'],'reconstructed_source_hash_matches':True,'saved_failed_controls':[c['name'] for c in row['failed_controls']]})
assert len(records)==13
receipt={'scope':'Frozen v1 source/cache/product binding and reconstructed mutant source hashes; saved execution outcomes read, not rerun. Historical pre/post stat equality is not independently reconstructed.','identity':identity,'cache_sha256':sha(cache),'source_identities':{r['path']:r['sha256'] for r in source['files']},'product_identities':{r['path']:r['sha256'] for r in products['files']},'declared_input_identities':ids,'counts_as_saved':res['counts'],'elapsed_sec_as_saved':run['elapsed_sec'],'timeout_sec_as_saved':run['timeout_sec'],'mutation_records':records,'current_live_equality_at_check':{p:(W/p).read_bytes()==b for p,b in snaps.items()},'source_sha256':sha(Path(__file__).read_bytes())}
with (O/'CANONICAL_BINDING_RESULTS_v1.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'outcome':'frozen source/cache/product identities matched','counts':res['counts'],'fingerprint':h.hexdigest(),'mutation_hashes':len(records),'live_changed':[p for p,v in receipt['current_live_equality_at_check'].items() if not v]},indent=2))
