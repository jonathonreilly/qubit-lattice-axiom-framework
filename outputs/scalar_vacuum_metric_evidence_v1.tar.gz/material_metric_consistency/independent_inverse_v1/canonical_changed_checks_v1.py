"""Only changed guards and new exact determinant argument; no ODE/aggregate."""
from pathlib import Path
import ast, hashlib, json, warnings, difflib
import numpy as np
import sympy as S
O=Path(__file__).resolve().parent
source=O/'CANONICAL_EXPOSURE_v1__scalar_vacuum_metric_inverse.py'
old=O/'AUTHOR_EXPOSURE_v1__scalar_vacuum_metric_inverse.py'
module=ast.parse(source.read_text()); funcs={n.name:n for n in module.body if isinstance(n,ast.FunctionDef)}
rows=[]
def ck(n,b,detail=None):rows.append({'name':n,'passed':bool(b),'detail':detail})
# Unchanged source functions are compared by AST, never executed.
oldfuncs={n.name:n for n in ast.parse(old.read_text()).body if isinstance(n,ast.FunctionDef)}
for name in ['geometry_functions','make_generator']:
 ck('unchanged AST '+name,ast.dump(funcs[name])==ast.dump(oldfuncs[name]))
# Compile the actual changed scalar error function only.
ns={'np':np}
exec(compile(ast.Module(body=[funcs['lambda_error_bound']],type_ignores=[]),str(source),'exec'),ns)
error=ns['lambda_error_bound']
normal=[.2,1.1,np.log(2),.01,.02,np.log(1.1)]
for value,label in [(float('nan'),'nan'),(float('inf'),'inf')]:
 for i in range(6):
  args=normal.copy();args[i]=value
  try:error(*args);rejected=False
  except ValueError:rejected=True
  ck('finite error rejects '+label+' input '+str(i),rejected)
for i in [3,4,5]:
 args=normal.copy();args[i]=-.01
 try:error(*args);rejected=False
 except ValueError:rejected=True
 ck('finite error rejects negative bound '+str(i),rejected)
for args,label in [(normal[:2]+[-1000]+normal[3:],'overflow'),([.2,1.1,0,.01,.02,.01],'zero denominator')]:
 with warnings.catch_warnings(record=True):
  warnings.simplefilter('always')
  try:error(*args);rejected=False
  except ValueError:rejected=True
 ck('finite error rejects '+label,rejected)
lhat,bound=error(*normal)
ck('finite error keeps admitted sharp corner',abs(lhat-2)<1e-14 and abs(bound-77/300)<1e-14,{'lambda_hat':float(lhat),'bound':float(bound)})
# Execute exactly the newly added coefficient guard, not a recreated condition.
inv=funcs['invert_metric']; gate=next(n for n in inv.body if isinstance(n,ast.If) and any(isinstance(c,ast.Constant) and c.value=='Outside positive candidate potential domain' for c in ast.walk(n)))
program=compile(ast.Module(body=[gate],type_ignores=[]),str(source),'exec')
for h2,h2nu,label in [(.0009,-.00108,'negative nu'),(0,1,'zero Hv squared'),(-1,1,'negative Hv squared'),(1,0,'zero regulator'),(float('nan'),1,'nan coefficient'),(1,float('inf'),'infinite coefficient')]:
 try:exec(program,{'np':np,'h2':h2,'h2nu':h2nu});rejected=False
 except ValueError:rejected=True
 ck('potential guard rejects '+label,rejected)
try:exec(program,{'np':np,'h2':.0009,'h2nu':.00108});accepted=True
except ValueError:accepted=False
ck('potential guard admits positive finite coefficients',accepted)
# Source-order check: the guard precedes division by h2 in the result.
resultline=next(n.lineno for n in inv.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='result' for t in n.targets))
ck('potential guard precedes returned ratio',gate.lineno<resultline)
Y,s,a=S.symbols('Y s a',positive=True)
ratio=Y**2*S.log(Y)**2/(12*a*(s+Y**2))
expected=Y*S.log(Y)*(s*(S.log(Y)+1)+Y**2)/(6*a*(s+Y**2)**2)
ck('new Y greater than one monotonicity derivative',S.simplify(S.diff(ratio,Y)-expected)==0,{'derivative':str(expected),'positive_domain':'Y>1,s>0,a>0'})
diff=''.join(difflib.unified_diff(old.read_text().splitlines(True),source.read_text().splitlines(True),fromfile=old.name,tofile=source.name))
with (O/'CANONICAL_HELPER_DELTA_v1.diff').open('x') as f:f.write(diff)
out={'scope':'Changed source guards and new monotonicity argument only; no original independent suite, generator, solver, controls() or aggregate executed','checks':rows,'counts':{'passed':sum(c['passed'] for c in rows),'failed':sum(not c['passed'] for c in rows)},'helper_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with (O/'CANONICAL_CHANGED_RESULTS_v1.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({'counts':out['counts'],'failed':[c for c in rows if not c['passed']]},indent=2))
raise SystemExit(out['counts']['failed']!=0)
