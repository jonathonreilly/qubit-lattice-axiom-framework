"""Independent local Jordan inverse: exact geometry, equations and failure witnesses.
No author M19 source, observations, aggregate or solver is loaded.
"""
from pathlib import Path
import sympy as S
import json, hashlib
O=Path(__file__).resolve().parent
rows=[]
def eq(name,left,right=0):
 d=S.simplify(S.trigsimp(left-right));rows.append({'name':name,'passed':d==0,'difference':str(d)})
def ck(name,value,detail=None):rows.append({'name':name,'passed':bool(value),'detail':detail})
t,r,th,ph=S.symbols('t r theta phi',real=True)
N=S.Function('N')(r);B=S.Function('B')(r);z=S.Function('z')(r);v=S.Function('v')(r)
s,lam=S.symbols('s lambda',positive=True)
coord=[t,r,th,ph];g=S.diag(-N**2,1/B,r**2,r**2*S.sin(th)**2);gi=g.inv()
Gamma=[[[S.simplify(sum(gi[i,l]*(S.diff(g[l,k],coord[j])+S.diff(g[l,j],coord[k])-S.diff(g[j,k],coord[l])) for l in range(4))/2) for k in range(4)] for j in range(4)] for i in range(4)]
Ric=S.zeros(4)
for i in range(4):
 for j in range(4):
  Ric[i,j]=S.simplify(sum(S.diff(Gamma[k][i][j],coord[k])-S.diff(Gamma[k][i][k],coord[j])+sum(Gamma[k][i][j]*Gamma[l][k][l]-Gamma[l][i][k]*Gamma[k][j][l] for l in range(4)) for k in range(4)))
R=S.simplify(sum(gi[i,j]*Ric[i,j] for i in range(4) for j in range(4)))
G=[S.simplify(gi[i,i]*Ric[i,i]-R/2) for i in range(4)]
A=S.diff(N,r)/N
Gt=(B-1)/r**2+S.diff(B,r)/r
Gr=(B-1)/r**2+2*B*A/r
Ga=B*(S.diff(A,r)+A**2+A/r)+S.diff(B,r)*(A+1/r)/2
for name,i,target in [('time',0,Gt),('radial',1,Gr),('angular',2,Ga),('azimuthal',3,Ga)]:eq('direct Ricci '+name,G[i],target)
eq('trace Ricci scalar',R,-Gt-Gr-2*Ga)
w=s+z**2;wp=S.diff(w,r);wpp=S.diff(w,r,2)
Hess=[S.simplify(gi[i,i]*(S.diff(w,coord[i],2)-sum(Gamma[j][i][i]*S.diff(w,coord[j]) for j in range(4)))) for i in range(4)]
for name,i,target in [('time',0,B*A*wp),('radial',1,B*wpp+S.diff(B,r)*wp/2),('angular',2,B*wp/r)]:eq('direct Hessian '+name,Hess[i],target)
C=B*A+S.diff(B,r)/2+2*B/r
boxw=B*wpp+C*wp
boxz=B*S.diff(z,r,2)+C*S.diff(z,r)
eq('direct box',sum(Hess),boxw)
kin=B*S.diff(z,r)**2/lam
Et=w*Gt+kin+v+B*wpp+(S.diff(B,r)/2+2*B/r)*wp
Er=w*Gr-kin+v+B*(A+2/r)*wp
Ea=w*Ga+kin+v+B*wpp+(B*A+S.diff(B,r)/2+B/r)*wp
for name,Ei,i,ki in [('t',Et,0,kin),('r',Er,1,-kin),('a',Ea,2,kin)]:eq('metric equation from tensor '+name,Ei,w*G[i]+ki+v-Hess[i]+boxw)
eq('potential free t-angular',Et-Ea,w*(Gt-Ga)-B*(A-1/r)*wp)
eq('potential free t-radial',Et-Er,w*(Gt-Gr)+2*kin+B*wpp-(B*A-S.diff(B,r)/2)*wp)
divE=S.diff(Er,r)+A*(Er-Et)+2*(Er-Ea)/r
eq('radial Noether identity',divE+(2*boxz/lam+z*R)*S.diff(z,r)-S.diff(v,r))
# Algebraic elimination independent of a particular metric.
p,J,T,q=S.symbols('p J T q',nonzero=True)
w0=S.symbols('w0',positive=True)
eq('kinetic J expression',2/lam*(p*w0/(2*S.sqrt(w0-s)))**2/w0,p**2*w0/(2*lam*(w0-s)))
wrec=s*T/(T-1);z2rec=s/(T-1)
eq('normalization inversion',wrec/(wrec-s),T)
eq('field inversion',wrec-s,z2rec)
eq('potential inversion',B*(p*w0)**2/(4*lam*(w0-s))-B*(A+2/r)*p*w0-w0*Gr,w0*(B*p**2*w0/(4*lam*(w0-s))-B*(A+2/r)*p-Gr))
Tfun=S.Function('T')(r);wf=s*Tfun/(Tfun-1)
eq('compatibility T derivative',S.diff(wf,r)/wf,-S.diff(Tfun,r)/(Tfun*(Tfun-1)))
qfun=S.Function('q')(r);wf2=s/(1-qfun)
eq('compatibility reciprocal derivative',S.diff(wf2,r)/wf2,S.diff(qfun,r)/(1-qfun))
# Exact local solution jets from the two original metric differences, z=1+r.
AA,BB=S.symbols('AA BB',real=True);zz=1+r;ww=s+zz**2;pp=S.diff(ww,r)/ww
Bp=BB*(2*AA-(2*S.diff(zz,r)**2/lam+S.diff(ww,r,2))/(ww/r+S.diff(ww,r)/2))
Ap=(BB-1)/(BB*r**2)+(Bp/BB)*(1/(2*r)-AA/2)-AA**2-AA/r-(AA-1/r)*pp
D=lambda expr:S.diff(expr,r)+Ap*S.diff(expr,AA)+Bp*S.diff(expr,BB)
gt=(BB-1)/r**2+Bp/r;gr=(BB-1)/r**2+2*BB*AA/r
ga=BB*(Ap+AA**2+AA/r)+Bp*(AA+1/r)/2
pm=S.factor((gt-ga)/(BB*(AA-1/r)))
Jm=S.factor(-(gt-gr)/BB-D(pm)-pm**2+(AA-Bp/(2*BB))*pm)
Tm=S.factor(2*lam*Jm/pm**2)
eq('ODE jet metric p',pm,pp)
eq('ODE jet metric T',Tm,ww/(ww-s))
eq('ODE jet recovered z squared',s/(Tm-1),zz**2)
eq('ODE jet interval compatibility',D(Tm)+pm*Tm*(Tm-1))
fixture={r:1,s:1,lam:2,AA:S.Rational(1,5),BB:S.Rational(4,5)}
fixture_result={key:str(S.simplify(value.subs(fixture))) for key,value in {'p':pm,'J':Jm,'T':Tm,'z_squared':s/(Tm-1),'B_prime':Bp,'A_prime':Ap,'v':ww*(BB*Jm/2-BB*(AA+2/r)*pm-gr)}.items()}
ck('local fixture admissible',S.simplify(Tm.subs(fixture))>1 and S.simplify((AA-1/r).subs(fixture))!=0,fixture_result)
# Nonconstant Ricci-flat metric with arbitrary constant scalar: no inverse.
M,L=S.symbols('M Lambda',real=True);be=1-2*M/r-L*r**2/3;ae=S.diff(be,r)/(2*be)
Gt_e=(be-1)/r**2+S.diff(be,r)/r
Gr_e=(be-1)/r**2+2*be*ae/r
Ga_e=be*(S.diff(ae,r)+ae**2+ae/r)+S.diff(be,r)*(ae+1/r)/2
for name,e in [('t',Gt_e),('r',Gr_e),('a',Ga_e)]:eq('Einstein plateau '+name,e,-L)
eq('plateau scalar curvature',-Gt_e-Gr_e-2*Ga_e,4*L)
# H identically zero on an open interval is incompatible with positive F.
a_zero=1/r
ga_zero=B*(S.diff(a_zero,r)+a_zero**2+a_zero/r)+S.diff(B,r)*(a_zero+1/r)/2
eq('open H-zero obstruction',Gt-ga_zero,-1/r**2)
# Pointwise domain alone is not solution membership: N=1,B=2/3,lambda=1.
badp=1/(2*r);badJ=1/(4*r**2);badT=2
ck('positivity without compatibility witness',badT>1)
eq('nonzero compatibility residual for false reconstruction',S.diff(S.Integer(badT),r)+badp*badT*(badT-1),1/r)
# Regular chart with forbidden sign: N=r²,B=1.
pa=-4/r;ja=-24/r**2
eq('inadmissible metric T',2*lam*ja/pa**2,-3*lam)
# Extra positive radial kinetic density yields only a lower bound.
kperp=S.symbols('kperp',nonnegative=True)
Jperp=p**2*w0/(2*lam*(w0-s))+2*kperp/w0
Tperp=2*lam*Jperp/p**2
eq('transverse nonnegative correction',Tperp-w0/(w0-s),4*lam*kperp/(p**2*w0))
output={'scope':'Independent exact equations, local inverse, compatibility and degeneracy witnesses; no author source or data accessed','checks':rows,'counts':{'passed':sum(x['passed'] for x in rows),'failed':sum(not x['passed'] for x in rows)},'manufactured_local_jet':fixture_result,'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with (O/'INDEPENDENT_RESULTS_v1.json').open('x') as f:json.dump(output,f,indent=2);f.write('\n')
print(json.dumps({'counts':output['counts'],'fixture':fixture_result,'failed':[x for x in rows if not x['passed']]},indent=2))
raise SystemExit(bool(output['counts']['failed']))
