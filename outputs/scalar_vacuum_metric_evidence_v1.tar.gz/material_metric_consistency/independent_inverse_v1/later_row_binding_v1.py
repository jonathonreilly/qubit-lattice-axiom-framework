"""Bind frozen canonical source/products and saved mutation claims; no science run."""
from pathlib import Path
import ast,hashlib,json
O=Path(__file__).resolve().parent;W=Path('/Users/jonBridger/.codex/worktrees/observations-backward-24h-20261014/New Axioms Lets Go')
def sha(b):return hashlib.sha256(b).hexdigest()
def load(n):return json.loads((O/n).read_text())
source=load('CANONICAL_REPAIR_EXPOSURE_v2.json');products={'files':[]}
snaps={}
for row in source['files']+products['files']:
 b=(O/row['snapshot']).read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes'];snaps[row['path']]=b
binding=load('CANONICAL_REPAIR_EXPOSURE_v2__CANONICAL_BINDING_v2.json');run=binding['result']
res=load('CANONICAL_REPAIR_EXPOSURE_v2__RESULTS_v1.json');summary=load('CANONICAL_REPAIR_EXPOSURE_v2__SUMMARY_v1.json')
primary=snaps['scripts/scalar_vacuum_metric_check.py'];helper=snaps['scripts/scalar_vacuum_metric_inverse.py']
paths=next(ast.literal_eval(n.value) for n in ast.parse(primary).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='AUDIT_INPUT_PATHS' for t in n.targets))
assert len(paths)==len(set(paths))==5
h=hashlib.sha256(b'runner-cache-input-fingerprint-v1\0');ids={}
for path in paths:
 b=snaps.get(path,(W/path).read_bytes());pb=path.encode();ids[path]=sha(b)
 h.update(len(pb).to_bytes(8,'big'));h.update(pb);h.update(len(b).to_bytes(8,'big'));h.update(b)
assert ids==res['input_sha256']==summary['input_sha256']
identity={'runner_sha256':sha(primary),'input_fingerprint_sha256':h.hexdigest()}
assert identity==binding['execution_identity']['content']
assert sha(primary)==res['primary_sha256']==summary['primary_sha256']
for path,value in binding['files'].items():assert sha(snaps[path])==value
cache=snaps['logs/runner-cache/scalar_vacuum_metric_check.txt']
header,tail=cache.decode().split('----- stdout -----\n',1);stdout,stderr=tail.split('\n----- stderr -----\n',1)
meta=dict(l.split(': ',1) for l in header.splitlines() if ': ' in l)
assert meta['runner_sha256']==sha(primary) and meta['input_fingerprint_sha256']==h.hexdigest()
assert meta['status']==run['status']=='ok' and meta['exit_code']=='0' and run['exit_code']==0
assert meta['timeout_sec']=='180' and run['timeout_sec']==180
assert stdout.rstrip('\n')==run['stdout'].rstrip('\n') and not stderr.strip() and run['stderr']==''
assert format(run['elapsed_sec'],'.2f')==meta['elapsed_sec'] and 0<run['elapsed_sec']<180
assert json.JSONDecoder().raw_decode(stdout[stdout.index('{'):])[0]==summary
assert res['counts']==summary['counts']=={'passed':70,'failed':0} and len(res['checks'])==70 and all(c['passed'] for c in res['checks'])
assert summary['failed_checks']==[] and binding['cache_status']=='fresh'
assert all(res[k]==v for k,v in summary.items() if k in res)
assert next(c for c in res['checks'] if c['name']=='negative_potential_parameter_guard')['solver_success'] is True
mut=load('CANONICAL_REPAIR_EXPOSURE_v2__MUTATIONS_v2.json');assert mut['original_source_sha256']==sha(helper)
records=[]
for row in mut['records']:
 text=helper.decode()
 for old,new in row['replacements']:
  assert text.count(old)==1;text=text.replace(old,new,1)
 assert sha(text.encode())==row['source_sha256']
 assert row['rejected_by_false_controls'] is True and row['exception'] is None and len(row['failed_controls'])>0 and all(c['passed'] is False for c in row['failed_controls'])
 records.append({'name':row['name'],'source_sha256':row['source_sha256'],'reconstructed_source_hash_matches':True,'saved_failed_controls':[c['name'] for c in row['failed_controls']]})
assert len(records)==13
# Compare saved results, excluding only changed input identity and two added metrics.
import copy
prior=load('CANONICAL_PRODUCTS_EXPOSURE_v1__RESULTS_v1.json')
stripped=copy.deepcopy(res)
stripped['input_sha256']=prior['input_sha256']
for case in stripped['synthetic_fixtures']:
 for key in ['max_later_integral_identity_error','max_later_potential_residual']:
  del case['inverse'][key]
assert stripped==prior
prior_helper=(O/'CANONICAL_EXPOSURE_v1__scalar_vacuum_metric_inverse.py').read_text()
# All changes are exactly the two added metrics and three lookup substitutions.
expected=prior_helper.replace(
 "              'min_lambda_minus_j':float(np.min(lam-jj)),",
 "              'max_later_integral_identity_error':float(np.max(np.abs(jj[ib+1:]-predicted_j[ib+1:]))),\n"
 "              'max_later_potential_residual':float(np.max(np.abs((pp-h2*a0-h2nu*a1)[ib+1:]))),\n"
 "              'min_lambda_minus_j':float(np.min(lam-jj)),")
expected=expected.replace("inv['max_integral_identity_error']<1e-8", "inv['max_later_integral_identity_error']<1e-8")
expected=expected.replace("inv['max_potential_residual']<1e-9", "inv['max_later_potential_residual']<1e-9")
expected=expected.replace("inv['max_potential_residual']>1e-8", "inv['max_later_potential_residual']>1e-8")
expected=expected.replace("residual=inv['max_potential_residual']", "residual=inv['max_later_potential_residual']")
assert expected.encode()==helper
# Execute only the two extracted scalar expressions on diagnostic arrays;
# do not import/run the author helper, symbolic controls, generator or ODE.
import numpy as np
exprs={}
for node in ast.walk(ast.parse(helper)):
 if isinstance(node,ast.Dict):
  for key,val in zip(node.keys,node.values):
   if isinstance(key,ast.Constant) and key.value in ['max_later_integral_identity_error','max_later_potential_residual']:
    exprs[key.value]=val
assert len(exprs)==2
x=np.zeros(601);x[0]=99;x[200]=88;x[201]=-3;x[600]=4
scope={'np':np,'float':float,'ib':200,'jj':x,'predicted_j':np.zeros(601),'pp':x,'h2':0.,'a0':np.zeros(601),'h2nu':0.,'a1':np.zeros(601)}
assert all(eval(compile(ast.Expression(e),'<frozen slice expression>','eval'),scope)==4 for e in exprs.values())
x[201]=-5
assert all(eval(compile(ast.Expression(e),'<frozen slice expression>','eval'),scope)==5 for e in exprs.values())
later=[]
for i,case in enumerate(res['synthetic_fixtures']):
 inv=case['inverse']
 assert inv['calibration_indices']==[0,200] and inv['test_first_index']==201 and inv['test_row_count']==400 and case['rows']==601
 assert inv['max_later_integral_identity_error']<1e-8
 assert (inv['max_later_potential_residual']<1e-9 if i<2 else inv['max_later_potential_residual']>1e-8)
 later.append({'case':i,'later_rows_inclusive':[201,600],'count':400,'max_later_integral_identity_error':inv['max_later_integral_identity_error'],'max_later_potential_residual':inv['max_later_potential_residual']})
mut_fit=next(r for r in mut['records'] if r['name']=='potential_checked_only_at_fit')
assert mut_fit['replacements']==[['np.max(np.abs((pp-h2*a0-h2nu*a1)[ib+1:]))','np.max(np.abs((pp-h2*a0-h2nu*a1)[[ia,ib]]))']]
failed=next(c for c in mut_fit['failed_controls'] if c['name']=='altered_potential_fails_reserved_rows')
assert failed['residual']<1e-8 and not failed['passed']
assert res['synthetic_fixtures'][2]['inverse']['max_later_potential_residual']>failed['residual']

receipt={'scope':'Narrow v2 later-slice source correspondence, diagnostic expression controls, saved product equality, and source/cache/mutant identity binding. No aggregate, symbolic suite or ODE rerun. Historical pre/post stat equality is not independently reconstructed.','later_row_saved_results':later,'prior_scientific_output_equality_excluding_two_new_metrics':True,'slice_expression_diagnostics':{'earlier_and_calibration_outliers_excluded':True,'both_first_and_last_later_rows_included':True},'altered_fit_only_mutant':mut_fit,'identity':identity,'cache_sha256':sha(cache),'source_identities':{r['path']:r['sha256'] for r in source['files']},'product_identities':{r['path']:r['sha256'] for r in products['files']},'declared_input_identities':ids,'counts_as_saved':res['counts'],'elapsed_sec_as_saved':run['elapsed_sec'],'timeout_sec_as_saved':run['timeout_sec'],'mutation_records':records,'current_live_equality_at_check':{p:(W/p).read_bytes()==b for p,b in snaps.items()},'source_sha256':sha(Path(__file__).read_bytes())}
with (O/'LATER_ROW_BINDING_RESULTS_v1.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'outcome':'frozen source/cache/product identities matched','counts':res['counts'],'fingerprint':h.hexdigest(),'mutation_hashes':len(records),'live_changed':[p for p,v in receipt['current_live_equality_at_check'].items() if not v]},indent=2))
