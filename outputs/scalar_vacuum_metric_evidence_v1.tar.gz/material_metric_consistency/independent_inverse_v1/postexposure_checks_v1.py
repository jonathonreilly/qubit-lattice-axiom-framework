"""Post-exposure exact extension checks and two narrow implementation witnesses.
Runs no author aggregate; one short synthetic outside-candidate local ODE is
used solely to test the inverse's missing positive-potential admission guard.
"""
from pathlib import Path
import sympy as S
import numpy as np
from scipy.integrate import solve_ivp
import hashlib,json,warnings
O=Path(__file__).resolve().parent
rows=[]
def eq(n,x):
 d=S.simplify(x); rows.append({'name':n,'passed':d==0,'difference':str(d)})
def ck(n,v,detail=None):rows.append({'name':n,'passed':bool(v),'detail':detail})
r,s,lam=S.symbols('r s lambda',positive=True)
u,j,ja,jb,E=S.symbols('u j ja jb E',real=True)
Y=S.Function('Y')(r)
ug=S.diff(Y,r)/(s+Y)
eq('j differential identity',S.diff(lam*Y/(s+Y),r)-ug*(lam-lam*Y/(s+Y)))
eq('integral pair lambda',((jb-E*ja)/(1-E)-lam).subs(jb,lam+(ja-lam)*E))
J=S.Function('j')(r);X=s*lam/(lam-J)
eq('integral identity supplies field compatibility',(S.diff(X,r)/X-u).subs(S.diff(J,r),u*(lam-J)))
k=S.symbols('k',positive=True);a=(1-k)*(1+3*k)/4
# Algebraic identities plus branch conditions checked exactly at representatives.
eq('lambda k rational map',a/(1-3*a)-(1+2*k-3*k*k)/(1-3*k)**2)
eq('a lambda inverse',(a-lam/(1+3*lam)).subs(lam,a/(1-3*a)))
for kval in [S.Rational(1,100),S.Rational(1,10),S.Rational(3,10)]:
 lv=(a/(1-3*a)).subs(k,kval)
 eq('positive k inverse '+str(kval),(1-2/S.sqrt(1+3*lv))/3-kval)
 ck('candidate lambda range '+str(kval),lv>1)
z,nu=S.symbols('z nu',positive=True)
eq('potential log conversion',(Y**2*S.log(Y)**2/(4*a)).subs(Y,z*z)-z**4*S.log(z)**2/a)
# Evenness is checked on the complete supplied physical action's coefficients.
x,y,Q,Hv=S.symbols('x y Q Hv',real=True);aa,ss=S.symbols('a ss',positive=True)
D=1+2*(1+k)*(x*x+y*y)/3
Hxx=Q*z*z*4*k/(9*D);Hyy=Q*z*z*k/(3*D)
V=3*Q*Hv**2*(ss+z**4)/(1+ss)+Q*Hv**2*nu*z**4*S.log(z)**2/(aa*(1+ss))+Q*Hv**2*k*x*x*(ss+z*z)**2*z**((1-k)/aa)/(1+ss)**2+2*Q*Hv**2*k*y*y*(ss+z*z)**2*z**((1+k)/aa)/(3*(1+ss)**2)
for name,coef in [('Hxx',Hxx),('Hyy',Hyy),('V',V)]:
 for variable in [x,y]:eq('zero transverse derivative '+name+str(variable),S.diff(coef,variable).subs({x:0,y:0}))
# Positive-Hv candidate plateau, not the separate generic V=0 witness.
P=Hv**2*(3*(ss+z**4)+nu*z**4*S.log(z)**2/aa)
eq('candidate plateau potential',P.subs(z,1)-3*Hv**2*(ss+1))
eq('candidate plateau scalar',S.diff(P,z).subs(z,1)-12*Hv**2)
# Exact finite-error decomposition and a saturating corner.
eh,et,ah,bh,da,db,lh=S.symbols('Ehat Etrue ah bh da db lhat',real=True)
lt=(bh+db-et*(ah+da))/(1-et)
res=(lt-lh)-(db-et*da+(et-eh)*(lh-ah))/(1-et)
eq('finite error exact decomposition',res.subs(bh,lh*(1-eh)+eh*ah))
ehv=S.Rational(1,2);adev=S.Rational(1,100);bdev=S.Rational(1,50);Edev=S.Rational(1,20)
ahv=S.Rational(1,5);bhv=S.Rational(11,10);lhv=(bhv-ehv*ahv)/(1-ehv)
bound=(bdev+(ehv+Edev)*adev+abs(lhv-ahv)*Edev)/(abs(1-ehv)-Edev)
ltv=(bhv+bdev-(ehv+Edev)*(ahv-adev))/(1-ehv-Edev)
eq('sharp finite error bound',ltv-lhv-bound)
eq('sharp finite error value',bound-S.Rational(77,300))
# Source exposure is frozen; import by compile avoids bytecode file writes.
f=O/'AUTHOR_EXPOSURE_v1__scalar_vacuum_metric_inverse.py'
ns={'__file__':str(f),'__name__':'focused_source_snapshot'}
exec(compile(f.read_text(),str(f),'exec'),ns)
findings=[]
with warnings.catch_warnings(record=True) as w:
 warnings.simplefilter('always')
 try:
  value=ns['lambda_error_bound'](float('nan'),1.1,np.log(2),.01,.02,np.log(1.1))
  nonfinite_return=not np.all(np.isfinite(value))
  findings.append({'name':'nonfinite_error_bound_not_rejected','reproduced':nonfinite_return,'return_repr':repr(value),'warnings':[str(q.message) for q in w]})
 except ValueError:
  findings.append({'name':'nonfinite_error_bound_not_rejected','reproduced':False})
# Negative regulator is outside the candidate; original metric field equations
# still supply a valid local geometry of the general radial action.
rhs,jets,pot,source=ns['make_generator'](.1,.03,-1.2,0)
rs=np.linspace(1,1.2,121)
sol=solve_ivp(rhs,(1,1.2),[1.4,.22,.9,0],method='DOP853',rtol=2e-12,atol=2e-14,dense_output=True)
assert sol.success
states=sol.sol(rs).T;mj=np.array([jets(rr,state) for rr,state in zip(rs,states)])
try:
 inv,yy,vals=ns['invert_metric'](rs,mj,ns['geometry_functions']())
 findings.append({'name':'negative_potential_coefficient_not_rejected','reproduced':inv['Hv_squared']>0 and inv['nu']<0,'returned_inverse':inv,'source':source,'scope':'One exact-model synthetic local ODE with negative regulator; admission witness, not observed or positive-candidate solution'})
except ValueError as e:
 findings.append({'name':'negative_potential_coefficient_not_rejected','reproduced':False,'exception':str(e)})
out={'scope':'Post-exposure mathematical/source checks, not blind source validation or an author aggregate','checks':rows,'counts':{'passed':sum(c['passed'] for c in rows),'failed':sum(not c['passed'] for c in rows)},'implementation_findings':findings,'author_source_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with (O/'POSTEXPOSURE_RESULTS_v1.json').open('x') as f:json.dump(out,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'counts':out['counts'],'findings':findings},indent=2,allow_nan=False))
raise SystemExit(out['counts']['failed']!=0)
