# Independent Einstein-frame numerical precheck

Root remains scientific author. This reviewer read the complete canonical note at SHA256 97c981752e50c9be3ec9c4686d0d63704a615948567dc793531cc465b3325c70 at first tool time 2026-10-15T20:06:58Z, including its inverse formulas and reported author fixtures. The parent helper, implementation and output arrays have not been read. Independence is therefore an alternative numerical generator and assembly, not blind discovery of the inverse theorem.

Use f0=1 without loss of classical vacuum normalization, X=s+z^2, P=V/f0, Einstein metric gE=X gJ, K=2/(lambda X)+6z^2/X^2 and U=P/X^2. The action is integral sqrt(-gE)[RE/2-K(dz)^2/2-U]. In Einstein areal radius R, let dsE^2=-exp(2alpha)dt^2+dR^2/C+R^2dOmega^2, p=dz/dR. Independent equations are

C_R=(1-C)/R-R*(C*K*p^2/2+U),
alpha_R=(1-C)/(2*C*R)+R*K*p^2/4-R*U/(2*C),
p_R=U_z/(C*K)-(alpha_R+C_R/(2*C)+2/R)*p-K_z*p^2/(2*K),
z_R=p.

These follow from Einstein Gt and Gr and the noncanonical scalar Euler equation; the angular equation is an independent residual after differentiation. They are not the parent's direct Jordan evolution.

The physical coordinate and metric map is r=R/sqrt(X), eta=1-R*z*p/X, J=dr/dR=eta/sqrt(X), B=C*eta^2, ell=alpha-log(X)/2. Require C>0, z>0, eta>0. Derivatives with respect to physical areal radius use Dr=J^-1*(partial_R+p partial_z+p_R partial_p+C_R partial_C). This will generate B',B'',ell',ell'',ell''' from the independently specified vector field at saved numerical states.

The fixture chosen here is k=.1,Hv=.03,nu=1.2,z0=1.35,p0=.08,C0=.95,r0=1, alpha0=log(s+z0^2)/2. R0=sqrt(s+z0^2). Integrate R from R0 to R0+1.5,21 saved equally spaced Einstein-radius epochs. Inverse calibration uses saved epochs0 and8; epochs9..20 are subsequent checks. This fixture's p0,C0 are independently chosen; no scalar boundary is fed to the inverse. No observed data or fit is involved.

Integrate with independent SciPy DOP853 in ordinary double precision, then assemble local differential jets at50decimal digits using mpmath differentiation of the Einstein vector field, not numerical differentiation of rounded physical readouts. This is not a high-precision trajectory or an instrument precision claim. The metric-only u integral will use independent fixed Gauss-Legendre quadrature over Einstein R after multiplying by J. Recovered lambda,k,z^2,Hv^2,nu and subsequent potential residuals will be recorded, with conditioning and original Jordan equations. A tighter double trajectory and quadrature refinement may check numerical stability; no root solver or aggregate will be called.

No positive outcome is prespecified. Failures, domain exits and distinction between absolute and relative residuals will be retained. The comparison proves only local numerical consistency within the supplied action/sector, not action selection, actual vacuum/material/metric calibration, global completion, initial history, physical stability or empirical validation.
