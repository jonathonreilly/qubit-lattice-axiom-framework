# Independent weak-inverse proof precheck

Root remains author. The exposed WEAK_DERIVATION_v1.md hash is c00be0711a4eee7f9d36ff8a7055051441cc289a5781bc7519aad994e6f5c07c. Root's two-check JSON is exposed but will not be used as independent evidence. No new author numerical implementation has been read or executed.

Writing e=ell', q=1/r-e, direct Ga-Gt gives

  (Ga-Gt)/(Bq) = -q'/q-B'/(2B)-2/r-e+1/(Br²q).

Integrating gives the displayed h. On a connected D!=0 chart q retains its sign, so q0/q>0; the formula has h(r0)=1 and is unchanged by a constant rescaling of N. The fixed normalization chooses no absolute F. N in C3, B in C2 gives h in C2 and u in C1; the derivative requirement has not been reduced to weak metric regularity.

Let k0=2e/r-B'/(Br)-u²-(B'/(2B)-e)u. Then H/B=k0-u'. For compact C1 w, K[w]=integral w k0+integral w' u=integral w H/B. For general endpoint weights, the difference K-integral w H/B is [wu]. With Y=s(h/eta-1), X=s h/eta and z=sqrt(Y), 2 z'^2/(lambda X)=u²h/[2lambda(h-eta)]. This proves the given weak kinetic equation.

A>0 when w>=0 is nonzero, u!=0 and eta<inf h. A'/A is the normalized mean of1/(h-eta) with measure w u² h/(h-eta) dr. Strict separated h-ranges make this mean strictly larger for w1 than w2, so log(A1/A2) is strictly increasing. This proves at most one eta, not existence. The actual range/bracket matters: compact supports may avoid the minimum h, so the ratio need not diverge at eta=inf h. K1,K2>0, lambda>1 and all remaining positive-candidate conditions still require checking. The strict global eta<inf h is a chosen margin; a pointwise positive Y on an open annulus could approach0 at its boundary and fail that strict-margin domain.

Eliminating H from W gives

  W=-(Gt+Gr)/2-B(u'+u²)/2-(B'/4+B e/2+2B/r)u.

Since X'=uX, the proposed T density equals wXW+(w X B u/2)'. Compact support removes the boundary term. For noncompact finite-endpoint weights the term [w X B u/2] must be retained.

For A(Y)=3(s+Y²), C(Y)=Y²log²Y/(4a),

  (C/A)' = Y log(Y)[s log(Y)+s+Y²]/[6a(s+Y²)²].

It is positive for Y>1, s,a>0. Two positive weighted averages of C/A with strictly ordered Y-ranges are strictly ordered; the integrated coefficient determinant is nonzero. This is sufficient, not necessary. A profile crossing Y=1 requires an actual determinant check.

All compact weak equations imply the original continuous radial/time residuals vanish by the fundamental lemma, and the angular-time equation is already built into h. The original scalar equation follows on the same nonconstant branch via the canonical Bianchi argument and the retained regularity. Two fitted moment equations plus finitely many later moments cannot establish all such residuals vanish. A concrete nonzero compact residual orthogonal to two fixed test weights will demonstrate this logical limitation without pretending to be a full metric counterexample.

The independent controls will use exact SymPy algebra plus direct nonconstant-geometry integration by parts, including a noncompact-weight boundary witness. They will not call root code or solve a new numerical inverse. The claims are conditional mathematics; derivative-error, covariance, quadrature and inverse-conditioning suppliers remain absent.
