"""Independent Einstein-areal generator and physical metric inverse.
No parent solver/helper/results imported. MP local jets on a double trajectory.
"""
from pathlib import Path
import hashlib,json,time
import numpy as np
import mpmath as mp
from scipy.integrate import solve_ivp
from numpy.polynomial.legendre import leggauss
mp.mp.dps=50
HERE=Path(__file__).resolve().parent
k=mp.mpf('0.1'); Hv=mp.mpf('0.03'); nu=mp.mpf('1.2')
a=(1-k)*(1+3*k)/4; lam=a/(1-3*a); s=(1+k)/(k*(1-3*k))

def mp_fields(z):
    X=s+z*z; lz=mp.log(z)
    K=2/(lam*X)+6*z*z/X**2
    Kz=-4*z/(lam*X**2)+12*z/X**2-24*z**3/X**3
    P=Hv**2*(3*(s+z**4)+(nu/a)*z**4*lz**2)
    Pz=Hv**2*(12*z**3+(nu/a)*z**3*(4*lz**2+2*lz))
    return X,K,Kz,P/X**2,Pz/X**2-4*z*P/X**3

def flow(R,z,p,C):
    X,K,Kz,U,Uz=mp_fields(z)
    Cp=(1-C)/R-R*(C*K*p*p/2+U)
    ap=(1-C)/(2*C*R)+R*K*p*p/4-R*U/(2*C)
    pp=Uz/(C*K)-(ap+Cp/(2*C)+2/R)*p-Kz*p*p/(2*K)
    return p,pp,Cp,ap

def rhs(R,y):
    z,p,C,alpha=y
    aa=float(a);ss=float(s);ll=float(lam);hh=float(Hv);nn=float(nu)
    X=ss+z*z; lz=np.log(z)
    K=2/(ll*X)+6*z*z/X**2
    Kz=-4*z/(ll*X**2)+12*z/X**2-24*z**3/X**3
    P=hh*hh*(3*(ss+z**4)+(nn/aa)*z**4*lz*lz)
    Pz=hh*hh*(12*z**3+(nn/aa)*z**3*(4*lz*lz+2*lz))
    U=P/X**2;Uz=Pz/X**2-4*z*P/X**3
    Cp=(1-C)/R-R*(C*K*p*p/2+U)
    ap=(1-C)/(2*C*R)+R*K*p*p/4-R*U/(2*C)
    pp=Uz/(C*K)-(ap+Cp/(2*C)+2/R)*p-Kz*p*p/(2*K)
    return [p,pp,Cp,ap]

def D(fn,x):
    R,z,p,C=x
    z1,p1,C1,_=flow(*x);v=(mp.mpf(1),z1,p1,C1)
    total=mp.mpf(0)
    for i in range(4):
        def along(q):
            t=list(x);t[i]=q
            return fn(*t)
        total+=v[i]*mp.diff(along,x[i])
    return total

def jac(R,z,p,C):
    X=s+z*z
    return (1-R*z*p/X)/mp.sqrt(X)

def physical_B(R,z,p,C):
    return C*(1-R*z*p/(s+z*z))**2

def ell1(R,z,p,C):
    ap=flow(R,z,p,C)[3]
    return (ap-z*p/(s+z*z))/jac(R,z,p,C)

def B1(*x):return D(physical_B,x)/jac(*x)
def ell2(*x):return D(ell1,x)/jac(*x)
def B2(*x):return D(B1,x)/jac(*x)
def ell3(*x):return D(ell2,x)/jac(*x)

def basic_metric(x):
    R,z,p,C=x
    r=R/mp.sqrt(s+z*z)
    return r,physical_B(*x),B1(*x),ell1(*x),ell2(*x)

def inverse_basic(v):
    r,B,b1,l1,l2=v
    Gt=(B-1)/r**2+b1/r
    Gr=(B-1)/r**2+2*B*l1/r
    Ga=B*(l2+l1*l1+l1/r)+b1*(l1+1/r)/2
    den=B*(1/r-l1)
    return (Ga-Gt)/den,Gt,Gr,Ga,den

def metric_jet(x):
    r,B,b1,l1,l2=basic_metric(x)
    return dict(r=r,B=B,B1=b1,B2=B2(*x),ell1=l1,ell2=l2,ell3=ell3(*x))

def inverse(jet):
    r,B,b1,b2,l1,l2,l3=[jet[t] for t in ['r','B','B1','B2','ell1','ell2','ell3']]
    u,Gt,Gr,Ga,den=inverse_basic((r,B,b1,l1,l2))
    Gt1=b2/r-2*(B-1)/r**3
    Ga1=b1*(l2+l1*l1+l1/r)+B*(l3+2*l1*l2+l2/r-l1/r**2)+b2*(l1+1/r)/2+b1*(l2-1/r**2)/2
    den1=b1*(1/r-l1)+B*(-1/r**2-l2)
    up=(Ga1-Gt1-u*den1)/den
    H=Gr-Gt-B*(up+u*u)-(b1/2-B*l1)*u
    j=B*u*u/(2*H)
    W=-Gt-H/2-B*(up+u*u)-(b1/2+2*B/r)*u
    return dict(u=u,up=up,H=H,j=j,W=W,Gt=Gt,Gr=Gr,Ga=Ga,D=den,Ricci=-(Gt+Gr+2*Ga))

def state(sol,R):
    y=sol.sol(float(R))
    return (mp.mpf(float(R)),mp.mpf(float(y[0])),mp.mpf(float(y[1])),mp.mpf(float(y[2])))

def uint(sol,Ra,Rb,n):
    nodes,weights=leggauss(n)
    mid=(Ra+Rb)/2;half=(Rb-Ra)/2
    return mp.fsum(mp.mpf(float(w))*inverse_basic(basic_metric(state(sol,mid+half*float(t))))[0]*jac(*state(sol,mid+half*float(t))) for t,w in zip(nodes,weights))*mp.mpf(half)

def jord_resid(jet,z,zp,zpp,kk,hh2,nn):
    aa=(1-kk)*(1+3*kk)/4;ll=aa/(1-3*aa);ss=(1+kk)/(kk*(1-3*kk))
    X=ss+z*z;F1=2*z*zp;F2=2*(zp*zp+z*zpp);V=hh2*(3*(ss+z**4)+(nn/aa)*z**4*mp.log(z)**2)
    Vz=hh2*(12*z**3+(nn/aa)*z**3*(4*mp.log(z)**2+2*mp.log(z)))
    r=jet['r'];B=jet['B'];bp=jet['B1'];ell=jet['ell1'];g=inverse_basic((r,B,bp,ell,jet['ell2']));_,Gt,Gr,Ga,_=g;curv=-(Gt+Gr+2*Ga)
    energy=B*zp*zp/ll
    return {'tt':-X*Gt-energy-V-B*F2-(bp/2+2*B/r)*F1,
            'rr':X*Gr-energy+V+B*(ell+2/r)*F1,
            'angular':X*Ga+energy+V+B*F2+(bp/2+B*ell+B/r)*F1,
            'scalar':2/ll*(B*zpp+(B*ell+bp/2+2*B/r)*zp)+z*curv-Vz}

def serial(v):
    if isinstance(v,dict):return {str(k):serial(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [serial(x) for x in v]
    if isinstance(v,mp.mpf):return mp.nstr(v,48)
    if isinstance(v,np.generic):return v.item()
    return v

def run_case(name,rtol,atol,step,nquad):
    R0=float(mp.sqrt(s+mp.mpf('1.35')**2));Rend=R0+1.5
    y0=[1.35,.08,.95,float(mp.log(s+mp.mpf('1.35')**2)/2)]
    sol=solve_ivp(rhs,(R0,Rend),y0,method='DOP853',rtol=rtol,atol=atol,max_step=step,dense_output=True)
    if not sol.success:raise RuntimeError(sol.message)
    epochs=np.linspace(R0,Rend,21);records=[]
    for i,R in enumerate(epochs):
        x=state(sol,R);jet=metric_jet(x);q=inverse(jet);J=jac(*x);flowx=flow(*x)
        zp=x[2]/J;zpp=(flowx[1]*J-x[2]*D(jac,x))/J**3
        true_res=jord_resid(jet,x[1],zp,zpp,k,Hv**2,nu)
        records.append({'index':i,'Einstein_R':float(R),'Einstein_state':list(x[1:])+[mp.mpf(float(sol.sol(R)[3]))],
                        'metric':jet,'metric_inverse':q,'true_z':x[1],'true_zprime':zp,'true_zsecond':zpp,
                        'eta':J*mp.sqrt(s+x[1]**2),'true_equation_residuals':true_res})
    I=uint(sol,float(epochs[0]),float(epochs[8]),nquad);EE=mp.exp(-I)
    lhat=(records[8]['metric_inverse']['j']-EE*records[0]['metric_inverse']['j'])/(1-EE)
    khat=(1-2/mp.sqrt(1+3*lhat))/3;ahat=(1-khat)*(1+3*khat)/4;shat=(1+khat)/(khat*(1-3*khat))
    for r in records:
        j=r['metric_inverse']['j'];Y=shat*j/(lhat-j);X=shat+Y;z=mp.sqrt(Y);u=r['metric_inverse']['u'];up=r['metric_inverse']['up']
        zp=u*X/(2*z);zpp=X*(up+u*u)/(2*z)-X*X*u*u/(4*z**3)
        A=3*(shat+Y**2);Cc=Y**2*mp.log(Y)**2/(4*ahat);P=X*r['metric_inverse']['W']
        r['reconstructed']=dict(Y=Y,z=z,zprime=zp,zsecond=zpp,A=A,C=Cc,P=P)
    r0=records[0]['reconstructed'];r8=records[8]['reconstructed'];det=r0['A']*r8['C']-r8['A']*r0['C']
    hhat2=(r0['P']*r8['C']-r8['P']*r0['C'])/det;hnu=(r0['A']*r8['P']-r8['A']*r0['P'])/det;nhat=hnu/hhat2
    for r in records:
        rr=r['reconstructed'];rr['potential_residual']=rr['P']-hhat2*rr['A']-hnu*rr['C']
        rr['Y_error']=rr['Y']-r['true_z']**2
        rr['equation_residuals']=jord_resid(r['metric'],rr['z'],rr['zprime'],rr['zsecond'],khat,hhat2,nhat)
    Iref=uint(sol,float(epochs[0]),float(epochs[8]),2*nquad)
    later=records[9:]
    maxeq=lambda field:{key:max(abs(r[field][key]) for r in records) for key in ['tt','rr','angular','scalar']}
    recmax={key:max(abs(r['reconstructed']['equation_residuals'][key]) for r in records) for key in ['tt','rr','angular','scalar']}
    summary={'name':name,'solver':{'method':'DOP853','rtol':rtol,'atol':atol,'max_step':step,'nfev':sol.nfev,'success':sol.success},
             'physical_interval':[records[0]['metric']['r'],records[-1]['metric']['r']],
             'min_C':min(r['Einstein_state'][2] for r in records),'min_B':min(r['metric']['B'] for r in records),'min_eta':min(r['eta'] for r in records),
             'min_D_abs':min(abs(r['metric_inverse']['D']) for r in records),'min_u_abs':min(abs(r['metric_inverse']['u']) for r in records),'min_H':min(r['metric_inverse']['H'] for r in records),
             'integral_u':I,'quadrature_n':nquad,'quadrature_refinement_delta':Iref-I,'lambda_denominator':1-EE,'potential_determinant':det,
             'potential_matrix_condition_2':float(np.linalg.cond(np.array([[float(r0['A']),float(r0['C'])],[float(r8['A']),float(r8['C'])]]))),
             'lambda_recovered':lhat,'k_recovered':khat,'Hv2_recovered':hhat2,'nu_recovered':nhat,
             'k_error':khat-k,'Hv2_error':hhat2-Hv**2,'nu_error':nhat-nu,
             'max_Y_error':max(abs(r['reconstructed']['Y_error']) for r in records),
             'max_later_potential_residual':max(abs(r['reconstructed']['potential_residual']) for r in later),
             'max_later_potential_relative_residual':max(abs(r['reconstructed']['potential_residual']/r['reconstructed']['P']) for r in later),
             'max_true_equation_residuals':maxeq('true_equation_residuals'),'max_recovered_equation_residuals':recmax,
             'calibration_indices':[0,8],'later_indices':list(range(9,21)),
             'scope':'50digit local field-equation jets on double Einstein trajectory; no high-precision trajectory or physical derivative precision claim.'}
    return {'summary':summary,'records':records}

def main():
    start=time.monotonic();allruns=[]
    for spec in [('primary',2e-12,1e-14,.075,24),('refined',5e-14,1e-15,.025,48)]:
        result=run_case(*spec);allruns.append(result)
        (HERE/('EINSTEIN_'+spec[0].upper()+'_RESULTS_v1.json')).write_text(json.dumps(serial(result),indent=2,allow_nan=False)+'\n')
        print(json.dumps(serial(result['summary']),sort_keys=True),flush=True)
    out={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'mp_local_jet_digits':50,'trajectory_precision':'IEEEdouble','elapsed_seconds':time.monotonic()-start,'runs':[r['summary'] for r in allruns],
         'max_saved_state_primary_refined_difference':max(abs(a-b) for ra,rb in zip(allruns[0]['records'],allruns[1]['records']) for a,b in zip(ra['Einstein_state'],rb['Einstein_state']))}
    (HERE/'EINSTEIN_SUMMARY_v1.json').write_text(json.dumps(serial(out),indent=2,allow_nan=False)+'\n')
    print('complete elapsed',out['elapsed_seconds'],flush=True)
if __name__=='__main__':main()
