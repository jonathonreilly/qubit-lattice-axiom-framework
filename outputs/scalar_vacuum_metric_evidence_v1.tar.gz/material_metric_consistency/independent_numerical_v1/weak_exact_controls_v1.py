"""Independent exact checks of exposed weak-inverse formulas. No root imports."""
from pathlib import Path
import hashlib,json,time
import sympy as s
HERE=Path(__file__).resolve().parent
r,B,bp,e,ep,u,up,X,w,wp=s.symbols('r B bp e ep u up X w wp', nonzero=True)
q=1/r-e;qp=-1/r**2-ep
Gt=(B-1)/r**2+bp/r
Gr=(B-1)/r**2+2*B*e/r
Ga=B*(ep+e**2+e/r)+bp*(e+1/r)/2
H=Gr-Gt-B*(up+u*u)-(bp/2-B*e)*u
W=-Gt-H/2-B*(up+u*u)-(bp/2+2*B/r)*u
checks=[]
def zero(name,expr):
 v=s.factor(s.cancel(expr));checks.append({'name':name,'residual':str(v),'passed':v==0})
start=time.monotonic()
zero('shape_log_derivative',(Ga-Gt)/(B*q)-(-qp/q-bp/(2*B)-2/r-e+1/(B*r*r*q)))
k0=2*e/r-bp/(B*r)-u*u-(bp/(2*B)-e)*u
zero('kinetic_density',H/B-k0+up)
ht,eta,ss,ll=s.symbols('h eta ss lambda',positive=True)
y=ss*(ht/eta-1);xx=ss*ht/eta
zp2=(ss*ht*u/eta)**2/(4*y)
zero('kinetic_scalar_substitution',2*zp2/(ll*xx)-u*u*ht/(2*ll*(ht-eta)))
Td=X*(-w*(Gt+Gr)/2+B*u*wp/2+w*(bp/4-B*e/2-2*B/r)*u)
bound_der=(wp*X*B*u+w*X*u*B*u+w*X*bp*u+w*X*B*up)/2
zero('potential_by_parts_density',Td-w*X*W-bound_der)
h1,h2=s.symbols('h1 h2',positive=True)
zero('ratio_strict_difference',1/(h1-eta)-1/(h2-eta)-(h2-h1)/((h1-eta)*(h2-eta)))
yy,aa=s.symbols('Y a',positive=True)
ratio=yy**2*s.log(yy)**2/(12*aa*(ss+yy**2))
zero('potential_ratio_derivative',s.diff(ratio,yy)-yy*s.log(yy)*(ss*s.log(yy)+ss+yy**2)/(6*aa*(ss+yy**2)**2))
# Nonconstant geometry, coefficient and compact C1 weight. No vacuum claim for this fixture.
x= s.symbols('x',positive=True)
b=1+x/3; ee=2*x/7; uu=2/(1+x); FF=3*(1+x)**2
weight=(x-1)**2*(2-x)**2
subs={r:x,B:b,bp:s.diff(b,x),e:ee,ep:s.diff(ee,x),u:uu,up:s.diff(uu,x),X:FF,w:weight,wp:s.diff(weight,x)}
left=s.integrate(s.cancel(Td.subs(subs)),(x,1,2))
right=s.integrate(s.cancel((w*X*W).subs(subs)),(x,1,2))
zero('nonconstant_compact_integrals',left-right)
checks.append({'name':'nonconstant_integral_nonvacuous','passed':left!=0,'T':str(left),'integral_w_X_W':str(right)})
plain=subs|{w:s.Integer(1),wp:s.Integer(0)}
noncompact=s.integrate(s.cancel((Td-w*X*W).subs(plain)),(x,1,2))
boundary=(FF*b*uu/2).subs(x,2)-(FF*b*uu/2).subs(x,1)
zero('noncompact_boundary_retained',noncompact-boundary)
checks.append({'name':'omitting_boundary_fails','passed':noncompact!=0,'unretained_boundary':str(noncompact)})
# A finite moment family is not complete: w1 on[1,2], w2 on[3,4].
# Residual is w1*(x-3/2) on[1,2] and0 elsewhere, C1 and nonzero.
missed=s.integrate(weight**2*(x-s.Rational(3,2)),(x,1,2))
zero('finite_weight_misses_nonzero_residual',missed)
res_at=s.factor((weight*(x-s.Rational(3,2))).subs(x,s.Rational(5,4)))
checks.append({'name':'missed_residual_nonzero','passed':res_at!=0,'residual_at_5_over_4':str(res_at),'second_weight_moment':'0 by disjoint support; not a constructed metric solution'})
result={'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':checks,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'elapsed_seconds':time.monotonic()-start,'scope':'Exact algebra and nonconstant integration-by-parts controls; no numerical inverse or empirical validation; no root imports.'}
(HERE/'WEAK_EXACT_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
assert result['failed']==0
