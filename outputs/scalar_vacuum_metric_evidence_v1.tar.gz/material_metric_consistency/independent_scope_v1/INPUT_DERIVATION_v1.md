# Independent physical-input derivation for the proposed static metric inverse

Reviewer `/root/launch_check`. This is an input/scope derivation, not the author's theorem, an implementation review or formal audit. The protocol and inherited candidate source were read. No new M19 proof or code file was read before this file was frozen. Chronology matters: the reviewer independently sent the metric-difference equation, derivative-order requirement, surviving normalization and integrability warning to root before root disclosed its j/integral construction in a message. That message arrived before this on-disk freeze. This is not advertised as wholly blind to that disclosed algebra.

## Metric and field premises

Take signature (-+++), natural units and a connected finite annulus in physical areal radius r>0:

    ds_J^2=-N(r)^2 dt^2+dr^2/B(r)+r^2 dOmega^2.

Positive N,B, their regularity and errors are inputs. The scalar must separately be static and radial. Static or spherical geometry/stress alone does not prove that every field shares those symmetries. The candidate x=y=0 sector is a consistent truncation: its transverse source and connection terms vanish there, as already derived in the current-main density-inverse note. Consistency does not select that sector or exclude transverse states in the actual environment.

From the inherited physical action, put

    F=s+z^2, z=exp(-alpha u)>0,
    c_z=(1-3a)/a>0, lambda=1/c_z,
    W(z)=Hv^2[3(s+z^4)+(nu/a)z^4(ln z)^2],
    S=f0 integral sqrt(-g)[F R/2-c_z(dz)^2-W]+S_m[g,psi].

F is dimensionless; the gravitational coefficient is f0 F, not automatically a measured Newton constant. The equations are

    F G_mu_nu=T_mu_nu/f0+2c_z partial_mu z partial_nu z
       -c_z g_mu_nu(dz)^2-g_mu_nu W
       +nabla_mu nabla_nu F-g_mu_nu box F,
    E_z := 2c_z box z+z R-W_z=0.

These equations use a supplied action, not a derived matter equation of state.

## Vacuum and derivative information

Let ell=ln N, prime=d/dr, and write mixed Einstein components

    Gt=(B-1)/r^2+B'/r,
    Gr=(B-1)/r^2+2B ell'/r,
    Gp=B(ell''+ell'^2+ell'/r)+(B'/2)(ell'+1/r),
    box F=B F''+(2B/r+B ell'+B'/2)F'.

For material diag(-rho,p_r,p_t,p_t), differences give

    F(Gp-Gt)=(rho+p_t)/f0+B(1/r-ell')F',             (A)
    F(Gr-Gt)=(rho+p_r)/f0+2c_z B z'^2
                            +B F''+(B'/2-B ell')F'. (B)

Therefore the vacuum inverse needs material T_mu_nu=0, or an explicitly controlled replacement. Vanishing material trace is insufficient: radiation or electromagnetic stress changes these combinations. Scalar stress and the candidate potential remain in material vacuum. Ricci flatness does not define vacuum in this theory. A cosmological-constant-like material stress can cancel in the differences while changing the remaining potential equation.

In material vacuum, if D=B(1/r-ell') is nonzero, define

    L=(Gp-Gt)/D=F'/F,
    H=Gr-Gt-B(L'+L^2)-(B'/2-B ell')L.

Equation (B) implies H=(c_z B L^2/2)F/(F-s). For fixed admitted k, hence fixed c_z,s, the algebraic expression is

    z^2=s(c_z B L^2/2)/(H-c_z B L^2/2).

This exhibits the metric derivatives and denominators; it is not a converse by itself. L uses N'' and B'; L' generically uses N''' and B''. The reconstructed F still must obey F'=L F on the whole interval and the remaining metric/potential equation. Turning/constant-field points, D=0, zeros of the other denominators and failure of z^2>0 require refusal or a separate branch argument. Exact nonzero floating values are not uncertainty margins.

A fitted residual tensor is not an actual matter model. Its static conservation relation is

    p_r'+ell'(rho+p_r)+2(p_r-p_t)/r=0.

The divergence of the metric left-minus-scalar-stress expression equals -E_z partial_nu z. Actual vacuum metric equations therefore imply E_z z'=0; obtaining E_z=0 requires the varying branch. In the full multifield theory this is only a contraction, not all scalar equations. A complete matter claim additionally needs psi solving S_m, not merely a conserved tensor.

## Physical suppliers and their error requirements

For stationary physical clocks let f=N/N0. For vacuum radial ranging, an instantaneous reflection and an outward areal endpoint r>r0, the roundtrip proper time tau at r0 obeys

    tau=2 N0 integral_r0^r ds/[N(s)sqrt(B(s))],
    g=tau'=2/[f sqrt(B)]>0,   B=4/(f^2 g^2).

A constant rescaling of the static time coordinate cancels. Calibrated proper clock units and independent areal-radius information do not cancel. Declaring the same light travel time to be areal radius would assume the geometry being inferred. Apparatus motion/support, medium propagation, reflection delay, source/receiver geometry and calibration drift require their own corrections or bounds. Lensing/orbital data supply different combinations; a fitted GM or one PPN coefficient is not a complete metric/derivative profile.

For a_f=f'/f and a_g=g'/g,

    B'=-2B(a_f+a_g),
    B''=B[4(a_f+a_g)^2-2(a_f'+a_g')].

This direct metric-jet route thus needs f through its third areal derivative and tau through its third derivative, since g''=tau'''. It does not inherit the lower derivative budget of the M17 lapse ceiling. Instrument-coordinate conversion requires a calibrated monotone radius map and its derivative chain rule. Finite function samples and an arbitrary smooth interpolation do not provide derivative-error bounds; small unresolved ripples can have large derivatives. This is a kinematic supplier warning, not a candidate-solution counterexample or a universal impossibility theorem.

The full admitted domain needs sufficient derivative-error bounds, calibration covariance, positivity/nondegeneracy margins and residual coverage. A whole-interval integral can avoid differentiating a recovered j again, but not remove the N'''/B'' information already in j. An exact smooth input function is not an achieved finite-data measurement.

## Boundary, normalization and trace limits

A metric inverse may remove a separate scalar boundary value on its nondegenerate interval. The supplied metric still encodes the physical state and matching; neither it nor the ambient state is selected by inversion. No continuation through a degenerate point, horizon, center or unmeasured interval follows. A body application needs compatible interior/exterior metric and scalar junction conditions, including possible surface layers. Exterior data alone do not establish interior vacuum or curvature.

In material vacuum f0 multiplies the complete classical action and cancels. No such metric inverse can determine f0,Q or a force-calibrated Newton constant from that cancellation. Calibrated radii/times may fix Hv in physical units within this candidate, but do not select Hv before calibration or determine Hv^2/Q. Unknown length calibration leaves the common dilation of inverse lengths. The potential can be tested on the sampled interval; off-interval functions, transverse action terms, other theories and preparation remain open.

The candidate's exact constant-scalar de Sitter solution z=1 has the same metric for different nu and arbitrary overall f0, while L=0. It is a concrete excluded branch, not evidence against every static inverse. The new varying-branch hypothesis must remain visible.
