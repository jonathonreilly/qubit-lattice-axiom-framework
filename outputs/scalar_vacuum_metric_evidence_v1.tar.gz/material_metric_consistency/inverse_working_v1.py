"""Synthetic, personally authored nonlinear physical-metric inverse probe."""
from pathlib import Path
import json
import time
import numpy as np
import sympy as sp
from scipy.integrate import solve_ivp, cumulative_simpson

OUT = Path(__file__).resolve().parent


def geometry_functions():
    r, b, bp, bpp, e1, e2, e3 = sp.symbols('r b bp bpp e1 e2 e3')
    gt = (b - 1) / r**2 + bp / r
    gr = (b - 1) / r**2 + 2 * b * e1 / r
    ga = b * (e2 + e1**2 + e1 / r) + bp * (e1 + 1/r) / 2
    u = (ga - gt) / (b * (1/r - e1))
    up = sum(sp.diff(u, q) * dq for q, dq in
             [(r, 1), (b, bp), (bp, bpp), (e1, e2), (e2, e3)])
    hh = gr - gt - b * (up + u*u) - (bp/2 - b*e1)*u
    jj = b*u*u/(2*hh)
    ww = -gt - hh/2 - b*(up + u*u) - (bp/2 + 2*b/r)*u
    args = (r, b, bp, bpp, e1, e2, e3)
    return sp.lambdify(args, (u, up, hh, jj, ww, gt, gr, ga), 'numpy')


def make_generator(k_value, hv_value, nu_value):
    # Synthetic generator chooses state and parameters. Inverse below sees
    # only physical-metric jets, not these hidden source values.
    r, z, v, b = sp.symbols('r z v b', positive=True)
    q = (r, z, v, b)
    k = sp.Rational(str(k_value))
    hv = sp.Rational(str(hv_value))
    nu = sp.Rational(str(nu_value))
    aa = (1-k)*(1+3*k)/4
    lam = aa/(1-3*aa)
    ss = (1+k)/(k*(1-3*k))
    ff, zz = ss+z*z, 1/lam
    vv = hv*hv*(3*(ss+z**4)+nu*z**4*sp.log(z)**2/aa)
    fz, fzz, vz = sp.diff(ff,z), sp.diff(ff,z,2), sp.diff(vv,z)
    box = (vz-2*fz*vv/ff-fz*b*v*v*(zz+3*fzz/2)/ff)/(2*zz+3*fz*fz/(2*ff))
    ep = (b*zz*v*v-vv-ff*(b-1)/r**2-2*b*fz*v/r)/(b*(2*ff/r+fz*v))
    bd = r/ff*(-ff*(b-1)/r**2-b*(zz+fzz)*v*v-vv-fz*box+b*fz*ep*v)
    vd = box/b-(bd/(2*b)+ep+2/r)*v
    vec = sp.Matrix([1, v, vd, bd])
    fun = sp.lambdify(q, (vd, bd, ep), 'numpy', cse=True)
    epg = sp.lambdify(q, sp.Matrix([ep]).jacobian(q), 'numpy', cse=True)
    eph = sp.lambdify(q, sp.hessian(ep,q), 'numpy', cse=True)
    jac = sp.lambdify(q, vec.jacobian(q), 'numpy', cse=True)
    pot = sp.lambdify(z, (vv,vz), 'numpy', cse=True)

    def rhs(rr,state):
        z0,v0,b0,ell0 = state
        vd0,bd0,ep0 = fun(rr,z0,v0,b0)
        return [v0,vd0,bd0,ep0]

    def jets(rr,state):
        z0,v0,b0,_ = state
        args = (rr,z0,v0,b0)
        vd0,bd0,ep0 = fun(*args)
        flow = np.array([1,v0,vd0,bd0],dtype=float)
        gg = np.array(epg(*args),dtype=float).reshape(4)
        hh = np.array(eph(*args),dtype=float)
        jj = np.array(jac(*args),dtype=float)
        acc = jj@flow
        return [rr,b0,bd0,acc[3],ep0,gg@flow,flow@hh@flow+gg@acc]
    return rhs, jets, pot, {'k':float(k),'Hv':float(hv),'nu':float(nu),
                          'a':float(aa),'lambda':float(lam),'s':float(ss)}


def invert_metric(rs, metric_jets, geom):
    # No source field or parameter argument. First two calibration indices
    # reconstruct lambda; later rows check the integral identity.
    vals = np.array([geom(*row) for row in metric_jets],dtype=float).T
    u,up,hh,jj,ww,gt,gr,ga = vals
    integral = cumulative_simpson(u,x=rs,initial=0)
    ia,ib = 0,len(rs)//3
    ee = np.exp(-(integral[ib]-integral[ia]))
    lam = (jj[ib]-ee*jj[ia])/(1-ee)
    k = (1-2/np.sqrt(1+3*lam))/3
    aa = lam/(1+3*lam)
    ss = (1+k)/(k*(1-3*k))
    yy = ss*jj/(lam-jj)
    xx = ss+yy
    pp = xx*ww
    a0 = 3*(ss+yy*yy)
    a1 = yy*yy*np.log(yy)**2/(4*aa)
    # Potential coefficients use those same two radii, leaving later
    # points as synthetic validation. They are not empirical holdouts.
    mat = np.array([[a0[ia],a1[ia]],[a0[ib],a1[ib]]])
    h2,h2nu = np.linalg.solve(mat,pp[[ia,ib]])
    predicted_j = lam+(jj[0]-lam)*np.exp(-integral)
    result = {'k':float(k),'lambda':float(lam),'Hv_squared':float(h2),
              'nu':float(h2nu/h2),'potential_matrix_det':float(np.linalg.det(mat)),
              'potential_condition':float(np.linalg.cond(mat)),
              'max_integral_identity_error':float(np.max(np.abs(jj-predicted_j))),
              'max_potential_residual':float(np.max(np.abs(pp-h2*a0-h2nu*a1))),
              'min_lambda_minus_j':float(np.min(lam-jj)),
              'min_H':float(np.min(hh)),'min_abs_u':float(np.min(np.abs(u))),
              'calibration_indices':[ia,ib],'test_indices':list(range(ib+1,len(rs)))}
    return result,yy,vals


def main():
    started=time.time()
    geom=geometry_functions()
    fixtures=[]
    for k,hv,nu,z0,v0,b0 in [(0.1,0.03,1.2,1.4,0.22,0.9),
                             (0.22,0.05,0.7,1.2,-0.12,0.95)]:
        rhs,jets,pot,source=make_generator(k,hv,nu)
        rs=np.linspace(1,1.8,601)
        sol=solve_ivp(rhs,(rs[0],rs[-1]),[z0,v0,b0,0.],method='DOP853',
                      rtol=2e-12,atol=2e-14,dense_output=True)
        assert sol.success,sol.message
        states=sol.sol(rs).T
        mj=np.array([jets(rr,state) for rr,state in zip(rs,states)])
        inv,yy,vals=invert_metric(rs,mj,geom)
        # Check ORIGINAL equations, not only generator's reduced equations.
        residuals=[]
        for ii,(rr,state,row) in enumerate(zip(rs,states,mj)):
            zz,vv,bb,_=state;_,_,bp,bpp,e1,e2,e3=row
            vd=rhs(rr,state)[1]
            ff=source['s']+zz*zz;kin=1/source['lambda']
            fp=2*zz*vv;fpp=2*vv*vv+2*zz*vd
            vp,vpz=pot(zz)
            gt,gr,ga=vals[5:,ii]
            ett=ff*gt+bb*kin*vv*vv+vp+bb*fpp+(bp/2+2*bb/rr)*fp
            err=ff*gr-bb*kin*vv*vv+vp+bb*(e1+2/rr)*fp
            eaa=ff*ga+bb*kin*vv*vv+vp+bb*fpp+(bp/2+bb*e1+bb/rr)*fp
            curvature=-(gt+gr+2*ga)
            scalar=2*kin*(bb*vd+(bp/2+bb*e1+2*bb/rr)*vv)+zz*curvature-vpz
            residuals.append([ett,err,eaa,scalar])
        residuals=np.array(residuals)
        fixtures.append({'source':source,'initial':[z0,v0,b0,0.],
                         'inverse':inv,'max_original_equation_residuals':np.max(np.abs(residuals),axis=0).tolist(),
                         'max_reconstructed_field_squared_error':float(np.max(np.abs(yy-states[:,0]**2))),
                         'min_B':float(np.min(states[:,2])),
                         'max_parameter_errors':{'k':abs(inv['k']-k),'Hv2':abs(inv['Hv_squared']-hv*hv),'nu':abs(inv['nu']-nu)},
                         'radial_interval':[float(rs[0]),float(rs[-1])],'row_count':len(rs)})
        np.savez_compressed(OUT/f'working_fixture_k{str(k).replace(".","_")}_v1.npz',r=rs,metric_jets=mj,source_states=states,original_residuals=residuals,inverse_Y=yy)
    result={'scope':'synthetic coupled vacuum fixture checks; not observed data or independent tests',
            'fixtures':fixtures,'elapsed_seconds':time.time()-started}
    (OUT/'WORKING_RESULTS_v1.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
