"""Actual scratch-source mutations; no canonical source is edited."""
from pathlib import Path
import hashlib,importlib.util,json,tempfile,time
root=Path.cwd();source=root/'scripts/scalar_vacuum_metric_inverse.py';raw=source.read_text();out=Path(__file__).resolve().parent
mutations=[
('angular_metric_slot',[('ga = b * (e2 + e1**2 + e1 / r) + bp * (e1 + 1/r) / 2','ga = b * (e2 + e1**2 + e1 / r) - bp * (e1 + 1/r) / 2')]),
('null_difference_sign',[('u = (ga - gt) / (b * (1/r - e1))','u = (ga + gt) / (b * (1/r - e1))')]),
('kinetic_ratio_factor',[('jj = b*u*u/(2*hh)','jj = b*u*u/(4*hh)')]),
('pair_inverse_sign',[('lam = (jj[ib]-ee*jj[ia])/(1-ee)','lam = (jj[ib]+ee*jj[ia])/(1-ee)')]),
('candidate_k_map',[('k = (1-2/np.sqrt(1+3*lam))/3','k = (1-1.8/np.sqrt(1+3*lam))/3')]),
('potential_log_factor',[('a1 = yy*yy*np.log(yy)**2/(4*aa)','a1 = yy*yy*np.log(yy)**2/(2*aa)')]),
('potential_kinetic_slot',[('ww = -gt - hh/2 - b*(up + u*u) - (bp/2 + 2*b/r)*u','ww = -gt - hh - b*(up + u*u) - (bp/2 + 2*b/r)*u')]),
('interval_identity_sign',[('predicted_j = lam+(jj[0]-lam)*np.exp(-integral)','predicted_j = lam+(jj[0]-lam)*np.exp(integral)')]),
('potential_checked_only_at_fit',[('np.max(np.abs((pp-h2*a0-h2nu*a1)[ib+1:]))','np.max(np.abs((pp-h2*a0-h2nu*a1)[[ia,ib]]))')]),
('finite_error_term_missing',[('(ejb+(eh+ee)*eja+abs(lh-jahat)*ee)/gap','(ejb+(eh+ee)*eja)/gap')]),
('positive_potential_guard_removed',[('if not np.all(np.isfinite([h2,h2nu])) or h2 <= 0 or h2nu <= 0:','if not np.all(np.isfinite([h2,h2nu])):')]),
('nonfinite_guards_removed',[('if not np.all(np.isfinite([jahat,jbhat,ihat,eja,ejb,ei])):','if False:'),('if not np.all(np.isfinite([eh,ee,gap])) or min(eja,ejb,ei) < 0 or gap <= 0:','if min(eja,ejb,ei) < 0 or gap <= 0:'),('if not np.all(np.isfinite([lh,error])):','if False:')]),
('scalar_curvature_normalization',[('ez=2*zz*boxz+f0*z*curv-sp.diff(vv,z)','ez=2*zz*boxz+2*f0*z*curv-sp.diff(vv,z)')]),
]
records=[]
with tempfile.TemporaryDirectory(prefix='scalar-metric-mutations-') as td:
 for label,replacements in mutations:
  changed=raw
  for old,new in replacements:
   assert changed.count(old)==1,(label,old,changed.count(old))
   changed=changed.replace(old,new,1)
  q=Path(td)/(label+'.py');q.write_text(changed)
  spec=importlib.util.spec_from_file_location('mutant_'+label,q);m=importlib.util.module_from_spec(spec)
  rec={'name':label,'source_sha256':hashlib.sha256(changed.encode()).hexdigest(),'replacements':replacements};start=time.time()
  try:
   spec.loader.exec_module(m);result=m.controls();failed=[c for c in result['checks'] if not c['passed']]
   rec.update({'rejected_by_false_controls':bool(failed),'failed_controls':failed,'exception':None})
  except Exception as error:rec.update({'rejected_by_false_controls':False,'exception':repr(error)})
  rec['elapsed_seconds']=time.time()-start;records.append(rec)
  (out/'MUTATIONS_v2.json').write_text(json.dumps({'original_source_sha256':hashlib.sha256(raw.encode()).hexdigest(),'records':records},indent=2)+'\n')
print(json.dumps({'attempted':len(records),'rejected':sum(r['rejected_by_false_controls'] for r in records),'exceptions':[r['name'] for r in records if r['exception']],'survivors':[r['name'] for r in records if not r['exception'] and not r['rejected_by_false_controls']]}))
