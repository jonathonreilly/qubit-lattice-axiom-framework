"""Actual scratch-source mutations; no canonical source is edited."""
from pathlib import Path
import hashlib,importlib.util,json,tempfile,time,sys
sys.path.insert(0,str(Path.cwd()/'scripts'))
root=Path.cwd();source=root/'scripts/scalar_vacuum_metric_weak.py';raw=source.read_text();out=Path(__file__).resolve().parent
mutations=[
('shape_integral_factor',[('np.exp(e0-e+integ)','np.exp(e0-e+1.0001*integ)')]),
('shape_radial_power',[('(q*np.sqrt(b)*r*r)','(q*np.sqrt(b)*r**2.0001)')]),
('kinetic_window_derivative',[('+wp*u))','+1.0001*wp*u))')]),
('kinetic_normalization',[('lam=aa(p1,eta)/(2*p1[\'K\'])','lam=aa(p1,eta)/(2.001*p1[\'K\'])')]),
('potential_window_derivative',[('+b*u*wp/2','+1.0001*b*u*wp/2')]),
('potential_metric_derivative',[('(bp/4-b*e1/2-2*b/rs)','(bp/4.001-b*e1/2-2*b/rs)')]),
('potential_basis_factor',[('np.log(Y)**2/(4*a)','np.log(Y)**2/(4.001*a)')]),
('later_potential_replaced_by_fit',[("result['potential_residuals'][2:]","result['potential_residuals'][:2]")]),
]
records=[]
with tempfile.TemporaryDirectory(prefix='scalar-metric-mutations-') as td:
 for label,replacements in mutations:
  changed=raw
  for old,new in replacements:
   assert changed.count(old)>0,(label,old,changed.count(old))
   changed=changed.replace(old,new)
  q=Path(td)/(label+'.py');q.write_text(changed)
  spec=importlib.util.spec_from_file_location('mutant_'+label,q);m=importlib.util.module_from_spec(spec)
  rec={'name':label,'source_sha256':hashlib.sha256(changed.encode()).hexdigest(),'replacements':replacements};start=time.time()
  try:
   spec.loader.exec_module(m);result=m.controls();failed=[c for c in result['checks'] if not c['passed']]
   rec.update({'rejected_by_false_controls':bool(failed),'failed_controls':failed,'exception':None})
  except Exception as error:rec.update({'rejected_by_false_controls':False,'exception':repr(error)})
  rec['elapsed_seconds']=time.time()-start;records.append(rec)
  (out/'WEAK_MUTATIONS_v1.json').write_text(json.dumps({'original_source_sha256':hashlib.sha256(raw.encode()).hexdigest(),'records':records},indent=2)+'\n')
print(json.dumps({'attempted':len(records),'rejected':sum(r['rejected_by_false_controls'] for r in records),'exceptions':[r['name'] for r in records if r['exception']],'survivors':[r['name'] for r in records if not r['exception'] and not r['rejected_by_false_controls']]}))
